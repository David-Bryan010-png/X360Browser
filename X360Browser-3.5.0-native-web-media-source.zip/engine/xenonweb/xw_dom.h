#ifndef XW_DOM_H
#define XW_DOM_H

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/* XenonWeb's bounded DOM. Designed for consoles: no recursion is required by
 * the parser, all storage is caller-owned, and every limit fails closed. */
#define XW_DOM_MAX_NODES 1024U
#define XW_DOM_MAX_ATTRIBUTES 4096U
#define XW_DOM_STRING_POOL_SIZE 131072U
#define XW_DOM_MAX_DEPTH 64U
#define XW_DOM_NONE UINT16_MAX

typedef enum {
    XW_NODE_DOCUMENT = 0,
    XW_NODE_ELEMENT = 1,
    XW_NODE_TEXT = 2
} XwNodeType;

typedef struct {
    uint16_t parent;
    uint16_t first_child;
    uint16_t last_child;
    uint16_t next_sibling;
    uint16_t first_attribute;
    uint16_t attribute_count;
    uint32_t name_offset;
    uint32_t value_offset;
    uint8_t type;
    uint8_t flags;
} XwDomNode;

typedef struct {
    uint32_t name_offset;
    uint32_t value_offset;
    uint16_t next;
} XwDomAttribute;

typedef struct {
    XwDomNode nodes[XW_DOM_MAX_NODES];
    XwDomAttribute attributes[XW_DOM_MAX_ATTRIBUTES];
    char strings[XW_DOM_STRING_POOL_SIZE];
    size_t node_count;
    size_t attribute_count;
    size_t strings_used;
    uint16_t root;
    int truncated;
} XwDocument;

typedef struct {
    size_t input_bytes;
    size_t node_count;
    size_t attribute_count;
    size_t string_bytes;
    int truncated;
} XwDomStats;

int xw_dom_parse(XwDocument *document, const char *html, size_t html_length);
const char *xw_dom_string(const XwDocument *document, uint32_t offset);
const char *xw_dom_attribute(const XwDocument *document, uint16_t node_index,
                             const char *attribute_name);
int xw_dom_has_class(const XwDocument *document, uint16_t node_index,
                     const char *class_name);
/* Bounded mutation hooks used by the first-party XenonScript runtime. */
int xw_dom_set_attribute(XwDocument *document, uint16_t node_index,
                         const char *attribute_name, const char *value);
int xw_dom_has_attribute(const XwDocument *document, uint16_t node_index,
                         const char *attribute_name);
int xw_dom_remove_attribute(XwDocument *document, uint16_t node_index,
                            const char *attribute_name);
int xw_dom_set_text_content(XwDocument *document, uint16_t node_index,
                            const char *value);
size_t xw_dom_text_content(const XwDocument *document, uint16_t node_index,
                           char *output, size_t output_capacity);
uint16_t xw_dom_find_by_id(const XwDocument *document, const char *id);
int xw_dom_is_connected(const XwDocument *document, uint16_t node_index);
/* Bounded dynamic DOM construction used by XenonScript. */
uint16_t xw_dom_create_element(XwDocument *document, const char *tag_name);
uint16_t xw_dom_create_text_node(XwDocument *document, const char *text);
int xw_dom_append_child(XwDocument *document, uint16_t parent_index, uint16_t child_index);
int xw_dom_remove_child(XwDocument *document, uint16_t parent_index, uint16_t child_index);
void xw_dom_get_stats(const XwDocument *document, size_t input_bytes, XwDomStats *stats);

#ifdef __cplusplus
}
#endif
#endif
