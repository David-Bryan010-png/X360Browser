from http.server import BaseHTTPRequestHandler, HTTPServer
import struct
import zlib
import base64

def png_chunk(kind: bytes, payload: bytes) -> bytes:
    return struct.pack(">I", len(payload)) + kind + payload + struct.pack(">I", zlib.crc32(kind + payload) & 0xFFFFFFFF)

PNG_1X1 = (b"\x89PNG\r\n\x1a\n" +
           png_chunk(b"IHDR", struct.pack(">IIBBBBB", 1, 1, 8, 6, 0, 0, 0)) +
           png_chunk(b"IDAT", zlib.compress(b"\x00\xff\x00\x00\xff")) +
           png_chunk(b"IEND", b""))
JPEG_2X2 = base64.b64decode("/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAgGBgcGBQgHBwcJCQgKDBQNDAsLDBkSEw8UHRofHh0aHBwgJC4nICIsIxwcKDcpLDAxNDQ0Hyc5PTgyPC4zNDL/2wBDAQkJCQwLDBgNDRgyIRwhMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjL/wAARCAACAAIDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwDm6KKK+bP1I//Z")
GIF_2X2 = base64.b64decode("R0lGODdhAgACAIEAANwoFAAAAAAAAAAAACwAAAAAAgACAAAIBgABCAQQEAA7")
BMP_2X2 = base64.b64decode("Qk1GAAAAAAAAADYAAAAoAAAAAgAAAAIAAAABABgAAAAAABAAAADEDgAAxA4AAAAAAAAAAAAAFCjcFCjcAAAUKNwUKNwAAA==")

HTML = b'''<!doctype html>
<html><head>
<title>X360Browser Test</title>
<meta name="description" content="Fixture page for XenonWeb native transport">
<link rel="stylesheet" href="/site.css">
<script>console.log("inline fixture")</script><script src="/site.js"></script><script async src="/async.js"></script><script src="/large.js"></script>
</head><body>
<style>.hero { background-image: url('/assets/background.webp'); }</style>
<h1>Heading</h1><p id="external">External script pending</p><p class="remote-style">Remote CSS style probe</p><p style="background-image: url('/assets/inline.png')">Welcome to the test.</p>
<a href="/next">Next page</a>
<a href="#local-target">Local fragment</a>
<p id="local-target">Fragment target</p>
<img src="/assets/picture.png" srcset="/assets/picture-small.png 320w, /assets/picture-large.png 1280w" alt="Sample photo" width="640" height="480">
<img src="/assets/picture.jpg" alt="JPEG photo" width="20" height="20">
<img src="/assets/picture.gif" alt="GIF photo" width="20" height="20">
<img src="/assets/picture.bmp" alt="BMP photo" width="20" height="20">
<video controls><source src="/clip.mp4" type="video/mp4"><source src="/playlist.m3u8" type="application/vnd.apple.mpegurl"></video>
<audio src="/audio.mp3" type="audio/mpeg"></audio>
<iframe src="/embed"></iframe>
<form><input name="q"></form>
</body></html>'''

class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path == "/page.html":
            body, ctype = HTML, "text/html; charset=utf-8"
        elif self.path == "/site.css":
            body, ctype = b".remote-style { color: rgb(12, 34, 56); text-transform: uppercase; }", "text/css; charset=utf-8"
        elif self.path == "/wrong-mime.css":
            body, ctype = b".not-css { color: red; }", "text/plain; charset=utf-8"
        elif self.path == "/wrong-css-page.html":
            body, ctype = (b'<!doctype html><html><head><link rel="stylesheet" href="/wrong-mime.css"></head>'
                           b'<body><p id="safe-css">CSS MIME guard</p></body></html>'), "text/html; charset=utf-8"
        elif self.path == "/site.js":
            body, ctype = b"document.getElementById('external').textContent = 'External script loaded';", "application/javascript; charset=utf-8"
        elif self.path == "/large.js":
            body, ctype = b"/*" + (b"x" * 4200) + b"*/", "application/javascript; charset=utf-8"
        elif self.path == "/mime-page.html":
            body, ctype = (b'<!doctype html><html><head><title>MIME guard</title>'
                           b'<script src="/wrong-mime.js"></script></head><body>'
                           b'<p id="mime">MIME pending</p></body></html>'), "text/html; charset=utf-8"
        elif self.path == "/wrong-mime.js":
            body, ctype = b"document.getElementById('mime').textContent = 'MUST NOT RUN';", "text/plain; charset=utf-8"
        elif self.path == "/big.bin":
            body, ctype = b"x" * (2 * 1024 * 1024), "video/mp4"
        elif self.path == "/clip.mp4":
            body, ctype = b"FAKE-MP4-V1.0", "video/mp4"
        elif self.path == "/html-looks-like-video.mp4":
            body, ctype = b"<html><title>not a video</title></html>", "text/html; charset=utf-8"
        elif self.path == "/audio.mp3":
            body, ctype = b"ID3FAKE-AUDIO-FIXTURE", "audio/mpeg"
        elif self.path == "/html-looks-like-audio.mp3":
            body, ctype = b"<html><title>not audio</title></html>", "text/html; charset=utf-8"
        elif self.path == "/playlist.m3u8":
            body, ctype = (b"#EXTM3U\n#EXT-X-VERSION:3\n#EXT-X-TARGETDURATION:10\n"
                           b"#EXTINF:10,\n/assets/seg1.ts\n#EXTINF:10,\n/assets/seg2.ts\n#EXT-X-ENDLIST\n"), "application/vnd.apple.mpegurl"
        elif self.path == "/master.m3u8":
            body, ctype = (b"#EXTM3U\n#EXT-X-STREAM-INF:BANDWIDTH=400000,RESOLUTION=640x360\n/low/playlist.m3u8\n"
                           b"#EXT-X-STREAM-INF:BANDWIDTH=1200000,RESOLUTION=1280x720\n/high/playlist.m3u8\n"), "application/vnd.apple.mpegurl"
        elif self.path == "/low/playlist.m3u8":
            body, ctype = b"#EXTM3U\n#EXTINF:4,\nseg1.ts\n#EXTINF:4,\nseg2.ts\n#EXT-X-ENDLIST\n", "application/vnd.apple.mpegurl"
        elif self.path == "/high/playlist.m3u8":
            body, ctype = b"#EXTM3U\n#EXTINF:4,\nseg1.ts\n#EXT-X-ENDLIST\n", "application/vnd.apple.mpegurl"
        elif self.path == "/live.m3u8":
            body, ctype = b"#EXTM3U\n#EXTINF:10,\n/assets/seg1.ts\n", "application/vnd.apple.mpegurl"
        elif self.path == "/encrypted.m3u8":
            body, ctype = (b"#EXTM3U\n#EXT-X-KEY:METHOD=AES-128,URI=\"/key.bin\"\n"
                           b"#EXTINF:10,\n/assets/seg1.ts\n#EXT-X-ENDLIST\n"), "application/vnd.apple.mpegurl"
        elif self.path in ("/assets/seg1.ts", "/low/seg1.ts"):
            body, ctype = b"LOW-SEGMENT-1", "video/mp2t"
        elif self.path in ("/assets/seg2.ts", "/low/seg2.ts"):
            body, ctype = b"LOW-SEGMENT-2", "video/mp2t"
        elif self.path == "/high/seg1.ts":
            body, ctype = b"HIGH-SEGMENT", "video/mp2t"
        elif self.path == "/assets/picture.png":
            body, ctype = PNG_1X1, "image/png"
        elif self.path == "/assets/picture.jpg":
            body, ctype = JPEG_2X2, "image/jpeg"
        elif self.path == "/assets/picture.gif":
            body, ctype = GIF_2X2, "image/gif"
        elif self.path == "/assets/picture.bmp":
            body, ctype = BMP_2X2, "image/bmp"
        elif self.path.endswith((".png", ".webp", ".mp4", ".mp3", ".css", ".js")):
            body, ctype = b"x", ("video/mp4" if self.path.endswith(".mp4") else
                                   "audio/mpeg" if self.path.endswith(".mp3") else
                                   "image/webp" if self.path.endswith(".webp") else
                                   "image/png" if self.path.endswith(".png") else
                                   "text/css" if self.path.endswith(".css") else
                                   "application/javascript")
        else:
            body, ctype = b"not found", "text/plain; charset=utf-8"
        self.send_response(200 if self.path in ("/page.html", "/site.css", "/wrong-css-page.html", "/wrong-mime.css", "/site.js", "/large.js", "/mime-page.html", "/wrong-mime.js", "/big.bin", "/clip.mp4", "/html-looks-like-video.mp4", "/audio.mp3", "/html-looks-like-audio.mp3", "/playlist.m3u8", "/master.m3u8", "/low/playlist.m3u8", "/high/playlist.m3u8", "/live.m3u8", "/encrypted.m3u8", "/assets/seg1.ts", "/assets/seg2.ts", "/low/seg1.ts", "/low/seg2.ts", "/high/seg1.ts", "/assets/picture.png", "/assets/picture.jpg", "/assets/picture.gif", "/assets/picture.bmp") else 404)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        try:
            self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def log_message(self, *_args):
        pass

if __name__ == "__main__":
    HTTPServer(("127.0.0.1", 18765), Handler).serve_forever()
