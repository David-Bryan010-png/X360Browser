#ifndef X360BROWSER_WEB_ENGINE_H
#define X360BROWSER_WEB_ENGINE_H

#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

#define WEB_ENGINE_URL_CAP 512
#define WEB_ENGINE_TITLE_CAP 160
#define WEB_ENGINE_TEXT_CAP 32768
#define WEB_ENGINE_DESCRIPTION_CAP 256
#define WEB_ENGINE_CONTENT_TYPE_CAP 96
#define WEB_ENGINE_LINK_COUNT 64
#define WEB_ENGINE_LINK_URL_CAP 512
#define WEB_ENGINE_LINK_LABEL_CAP 112
#define WEB_ENGINE_IMAGE_COUNT 20
#define WEB_ENGINE_MEDIA_COUNT 12
#define WEB_ENGINE_RESOURCE_URL_CAP 512
#define WEB_ENGINE_RESOURCE_LABEL_CAP 96
#define WEB_ENGINE_RESOURCE_TYPE_CAP 64
#define WEB_ENGINE_FALLBACK_REASON_CAP 128
#define WEB_ENGINE_SOURCE_HTML_CAP 65536
#define WEB_ENGINE_IMAGE_CACHE_PATH_CAP 128

typedef enum {
    WEB_ENGINE_BACKEND_NONE = 0,
    WEB_ENGINE_BACKEND_XENONWEB = 2
} WebEngineBackend;
/* Source-compatibility alias for older UI/test integrations. */
#define WEB_ENGINE_BACKEND_NATIVE_PLUS WEB_ENGINE_BACKEND_XENONWEB

typedef struct {
    char url[WEB_ENGINE_LINK_URL_CAP];
    char label[WEB_ENGINE_LINK_LABEL_CAP];
    int is_video;
    int is_audio;
} WebEngineLink;

typedef struct {
    char url[WEB_ENGINE_RESOURCE_URL_CAP];
    char alt[WEB_ENGINE_RESOURCE_LABEL_CAP];
    unsigned int width;
    unsigned int height;
    /* Non-empty only when a bounded PNG download was verified and cached. */
    char cache_path[WEB_ENGINE_IMAGE_CACHE_PATH_CAP];
} WebEngineImage;

typedef struct {
    char url[WEB_ENGINE_RESOURCE_URL_CAP];
    char kind[16];
    char mime_type[WEB_ENGINE_RESOURCE_TYPE_CAP];
} WebEngineMedia;

typedef struct {
    char page_url[WEB_ENGINE_URL_CAP];
    char title[WEB_ENGINE_TITLE_CAP];
    char description[WEB_ENGINE_DESCRIPTION_CAP];
    char content_type[WEB_ENGINE_CONTENT_TYPE_CAP];
    /* Bounded original HTML retained for the static visual layout path. */
    char source_html[WEB_ENGINE_SOURCE_HTML_CAP];
    size_t source_html_length;
    char text[WEB_ENGINE_TEXT_CAP];
    size_t text_length;
    WebEngineLink links[WEB_ENGINE_LINK_COUNT];
    size_t link_count;
    WebEngineImage images[WEB_ENGINE_IMAGE_COUNT];
    size_t image_count;
    WebEngineMedia media[WEB_ENGINE_MEDIA_COUNT];
    size_t media_count;
    size_t html_bytes;
    size_t stylesheet_count;
    size_t script_count;
    size_t form_count;
    size_t heading_count;
    size_t iframe_count;
    long http_status;
    WebEngineBackend backend_used;
    int used_fallback;
    char fallback_reason[WEB_ENGINE_FALLBACK_REASON_CAP];
    int is_direct_resource;
} WebEnginePage;

/* Public engine dispatcher: use the first-party XenonWeb page engine only.
 * Transport/TLS support libraries do not provide HTML/CSS layout. */
int web_engine_init(void);
void web_engine_shutdown(void);
int web_engine_fetch(const char *url, WebEnginePage *page, char *error, size_t error_capacity);
int web_engine_download_media(const char *url, const char *destination, const char *media_kind,
                               char *error, size_t error_capacity);
/* Backward-compatible video-only wrapper used by older integrations. */
int web_engine_download_video(const char *url, const char *destination, char *error, size_t error_capacity);
const char *web_engine_backend_label(void);

/* In-project native page-fetch/transport path feeding XenonWeb. */
int web_engine_native_init(void);
void web_engine_native_shutdown(void);
int web_engine_native_fetch(const char *url, WebEnginePage *page, char *error, size_t error_capacity);

#ifdef __cplusplus
}
#endif

#endif
