# X360Browser 3.5.0 — Native Web & Media

X360Browser is an experimental Xbox 360 homebrew browser. The active page engine is the in-project **XenonWeb** (HTML/DOM/CSS/layout), scripting is **XenonScript** (a bounded experimental subset), and image/media parsing and elementary decoding live in **XenonMedia**. The inactive NetSurf stub has been removed; there is no Chromium/WebKit/NetSurf engine or third-party media player linked as the primary renderer.

## Engineering advances in 3.5.0

- **CSS custom properties:** root-level `--name` and `var(--name[, fallback])` resolution, nested fallback and substitution in shorthands, with fixed memory/output/recursion bounds. Per-element custom-property scope and full inheritance are still pending.
- **WAV Microsoft IMA ADPCM:** parses validated mono/stereo WAV blocks and decodes ADPCM samples to signed interleaved PCM16. Actual Xbox audio-device output is not connected yet.
- **WebVTT cues:** bounded parser skips `NOTE` blocks, supports cue identifiers and multiline text slices, and finds the cue active at a supplied timestamp. Subtitle overlay/synchronization is not yet integrated into the renderer.
- **One first-party engine route:** the empty NetSurf adapter and its fake fallback dispatch were removed. Dispatcher tests now verify the single-engine path.
- **Safety:** media decoders use caller-supplied input/output lengths, limits and reject malformed/truncated data.

## Dependencies we do and do not own

XenonWeb, XenonScript, XenonMedia parsers and listed elementary decoders are source code in this repository. The Xbox HTTP/HTTPS transport still uses libcurl and Mbed TLS, the CA trust bundle, and xSDK/platform APIs use the PowerPC toolchain. These are supporting transport, security and platform components, not third-party browser/media engines. We do not claim to have implemented audited TLS from scratch. External media-player launch is disabled by default.

## Compatibility boundaries

This is not yet a complete modern browser. XenonScript is not a full ECMAScript runtime; CSS variables are root-scope only; the WebVTT parser does not draw subtitles; WAV ADPCM decode does not route samples to an Xbox audio device. Full MP4 demux, H.264/HEVC/VP9/AV1 video decode, compressed MP3/AAC decode, Canvas/WebGL/WebAssembly, modern media-element timing, A/V sync, and YouTube watch-page support remain incomplete.

See:
- [`docs/XENONWEB-ENGINE.md`](docs/XENONWEB-ENGINE.md) — HTML/CSS/layout subset.
- [`docs/XENONMEDIA-ENGINE.md`](docs/XENONMEDIA-ENGINE.md) — first-party decoders and media primitives.
- [`docs/ENGINE-GAP-AUDIT-3.5.0.md`](docs/ENGINE-GAP-AUDIT-3.5.0.md) — 164 gaps/partial capabilities.
- [`docs/50-LACUNAS-PRIORITARIAS-pt-BR.md`](docs/50-LACUNAS-PRIORITARIAS-pt-BR.md) — 50 priorities in Portuguese.
- [`docs/COMPATIBILITY-3.5.0-native-web-media.md`](docs/COMPATIBILITY-3.5.0-native-web-media.md) — compatibility and ownership boundary.
- [`docs/MEDIA-PLAYBACK.md`](docs/MEDIA-PLAYBACK.md) — current playback boundary.
- [`docs/XBOX_BUILD.md`](docs/XBOX_BUILD.md) — build workflow.

## Host validation

```sh
python3 tests/validate_project_integrity.py
python3 tests/run_host_tests.py
cmake -S . -B build -DX360BROWSER_BUILD_TESTS=ON -DX360BROWSER_BUILD_DEMO=ON
cmake --build build --parallel 2
ctest --test-dir build --output-on-failure
```

The GitHub Actions workflow validates the source by default and leaves `build_xex=false`. No PowerPC/xSDK cross-build or physical-console test is asserted for this milestone.
