> **Historical snapshot:** this document records the 3.4.0 milestone; for current status see `COMPATIBILITY-3.5.0-native-web-media.md` and `ENGINE-GAP-AUDIT-3.5.0.md`.

# X360Browser 3.4.0 — compatibility and first-party boundary

## Goal

The browser's own code is being extended under the XenonWeb (HTML/DOM/CSS/layout), XenonScript (limited page scripting), XenonNet-facing adapters, and XenonMedia (container parsing and elementary decoders) names. This is **not** a claim that every web standard or media codec is implemented, and host tests are not proof of Xbox hardware compatibility.

## First-party image support in 3.4.0

The platform renderer uses the in-tree XenonMedia signature dispatcher; no third-party image decoder fallback is linked. Native decoder primitives included in this release:

- BMP BI_RGB: indexed 1/4/8-bit palettes and 24/32-bit true-colour images.
- QOI, PPM P3/P6.
- PNG: 8-bit, non-interlaced grayscale, RGB, palette, grayscale-alpha, and RGBA; first-party zlib/DEFLATE for stored, fixed-Huffman, and dynamic-Huffman blocks; CRC/Adler validation and row filters.
- GIF: first frame only, with palette, LZW, transparency, and interlaced row mapping.
- JPEG: 8-bit baseline sequential SOF0, grayscale and 3-component color, common chroma sampling including 4:2:0, restart intervals, quantization/Huffman tables and inverse DCT.

The Xbox visual renderer now routes supported raster inputs through the same `xm_media_decode_image_rgba` first-party signature dispatcher. All raster decode entry points are bounded by input/output lengths, image dimensions, and pixel caps. Progressive JPEG, interlaced PNG, animated GIF, WebP, AVIF and other raster formats are not supported by the first-party path in this milestone.

## First-party media primitives

XenonMedia also includes PCM WAV parsing/decoding, bounded MP4 box/metadata scanning, MP3/AAC header inspection, MPEG-TS packet parsing, HLS manifest analysis, an AVI structure parser and uncompressed BI_RGB frame extraction, and a deterministic playback timeline/state machine. These are primitives, **not a complete audio/video pipeline**. The browser does not yet have an integrated audio output device, H.264/AAC/VP9/AV1 decoder, full MP4 sample-table demuxer, subtitle renderer, or frame/audio clock synchronizer. Existing media URL launch support is still a compatibility handoff, not proof of native inline playback.

## Third-party components that remain

The current engine path no longer includes or fetches `stb_image` or links a third-party image decoder. The current Xbox web transport and HTTPS trust chain still rely on libcurl, Mbed TLS, a CA bundle, and the xSDK/toolchain. Replacing TLS/cryptography with a home-grown implementation would create a serious security risk; a fully first-party socket/HTTP/TLS stack has not been implemented. Those boundaries are inventoried in `ENGINE-GAP-AUDIT-3.4.0.md`.

## Runtime status

- XenonScript remains a constrained interpreter, not ECMAScript 2025 or full JavaScript.
- HTML/CSS are implemented subsets. Media queries, selected Flexbox/Grid behavior, CSS cascade, DOM mutations, classList, selectors and inline handlers are partial implementations.
- NetSurf integration remains a stub. Chromium, WebKit and other browser engines are not linked as the primary renderer.
- `.xex` cross-compilation and physical Xbox 360 execution have **not** been performed for 3.4.0.
