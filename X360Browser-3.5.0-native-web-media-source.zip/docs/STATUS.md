# X360Browser 3.5.0 — implementation status

## First-party components

- XenonWeb: fixed-capacity HTML/DOM/CSS/layout subset and primary page-rendering route, now with bounded root CSS custom variables and fallback substitution.
- XenonScript: experimental first-party subset with variables, conditions, limited loops, DOM mutation/query/classList and supported inline handlers; not full ECMAScript.
- XenonMedia: first-party image decoders for supported profiles, WAV PCM and IMA ADPCM to PCM16, raw AVI frame extraction and bounded containers/playlist/WebVTT parsers.
- Dispatcher: only the project's page-engine path remains active; the nonfunctional NetSurf stub has been removed.
- External player: launch disabled by default and no player binary shipped.

## Gaps

No production-quality JavaScript runtime, full HTML/CSS compliance, Canvas/WebGL/WebAssembly, modern compressed video/audio decoder set, full MP4 demux, Xbox audio output, subtitle overlay or A/V synchronization. HTTP/HTTPS currently uses libcurl/Mbed TLS and a CA bundle; these are support dependencies, not alternate engines.

## Validation boundary

Host suite and CMake/CTest validate portable code. This milestone has not been cross-compiled with PowerPC/xSDK and has not been smoke-tested on physical Xbox 360 hardware. See `ENGINE-GAP-AUDIT-3.5.0.md` for 164 gap IDs.
