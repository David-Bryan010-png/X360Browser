# Changelog

## 3.5.0-native-web-media — CSS variables, WAV ADPCM and WebVTT

- Added bounded `:root` CSS custom-property collection and `var()` resolution, including nested fallback values and declarations/shorthands. Per-element scope and full custom-property inheritance remain future work.
- Added native Microsoft IMA ADPCM WAV parsing and block decoding to interleaved signed PCM16 for validated mono/stereo files. Audio-device output remains unconnected.
- Added bounded WebVTT cue parsing, multiline cue text slices, `NOTE` skipping, and active-cue lookup by timestamp. Subtitle overlay remains future work.
- Removed the nonfunctional NetSurf adapter and its fake fallback from the active CMake/Xbox dispatch path. The browser uses one first-party page-engine path.
- Updated source integrity checks, compatibility audit, docs, and workflow for 3.5.0. XEX compilation remains opt-in and was not run.

## 3.4.0-first-party-engine — first-party raster decoder expansion

- Added a native baseline sequential JPEG decoder for 8-bit grayscale and three-component images, including common 4:2:0 chroma sampling, restart markers, baseline Huffman tables and IDCT.
- Extended the native BMP decoder to 1/4/8-bit indexed palettes as well as 24/32-bit BI_RGB.
- Routed first-party image decoding through the XenonMedia signature dispatcher and removed the third-party raster fallback.
- Added the 164-item compatibility/ownership audit and strict malformed-input regression tests.
- Disabled external media-player launch by default; no XEX build was run.
