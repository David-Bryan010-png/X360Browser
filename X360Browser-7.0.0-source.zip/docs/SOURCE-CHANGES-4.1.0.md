# X360Browser 4.1.0 — mudanças reais na fonte

Esta versão parte da árvore completa 4.0.0, não de um patcher.

## Código alterado

- `src/url.cpp`: `valid_port()` verifica o limite antes de multiplicar e somar cada dígito, evitando wraparound de `unsigned int` com portas maliciosamente longas.
- `src/url.cpp`: nova verificação de escapes `%HH` em `is_http_url()`, para que `%`, `%2` ou `%GG` não sejam tratados como URL HTTP válida.
- `tests/test_main.cpp`: testes para porta excessiva, escape válido e escapes incompletos/malformados.
- Metadados de versão, README, changelog e CMake atualizados para 4.1.0.

## Escopo honesto

A 4.1.0 é uma atualização de robustez e manutenção, não um salto para Chromium. Não inventa suporte a codec nem declara que o YouTube ou jogos Poki funcionam no console sem teste físico.
