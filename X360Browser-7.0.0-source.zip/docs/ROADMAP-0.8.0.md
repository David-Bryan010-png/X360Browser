# Roadmap after X360Browser 0.8.0

This historical roadmap is superseded by `ROADMAP-1.0.0.md`. Static HTML/CSS rendering is not a foundation for claiming compatibility with modern games or YouTube; a real motor, script runtime, browser graphics APIs and a media decode pipeline are required.
