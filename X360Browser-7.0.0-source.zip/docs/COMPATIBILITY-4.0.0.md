# X360Browser 4.0.0 — compatibilidade real

## O que mudou

- Aumentaram os limites delimitados do DOM, CSS, layout e XenonScript para páginas com mais nós, regras, links e scripts pequenos. Isso amplia o subconjunto suportado; não transforma XenonScript em ECMAScript completo.
- A captura de HTML/CSS/JavaScript passa a negociar os métodos de compressão que a build do libcurl realmente suportar, mantendo os limites de tamanho após a descompressão.
- O motor busca até quatro scripts externos pequenos, dentro de orçamento total de 32 KiB; cada script segue sujeito à verificação de MIME, TLS, timeout e limite rígido.
- O renderizador tenta textura tiled e faz fallback para textura linear; erros continuam causando fallback ao leitor em vez de travar a inicialização inteira.
- A cache de imagens verifica tamanho e data de modificação e invalida rasterizações antigas após recarga.
- Links conhecidos do YouTube (`watch`, `youtu.be`, `shorts`, `embed`, `live`) podem tentar resolver uma URL MP4 muxada até 480p usando a API de instâncias públicas do Invidious. A resolução é HTTPS com verificação de certificado, limite de resposta de 256 KiB, timeout curto e host final restrito a `googlevideo.com` na porta HTTPS padrão. A transferência continua limitada a 512 MiB e o arquivo é validado pelo cabeçalho MP4 (`ftyp`) antes de ser passado ao player externo.
- O parser de URL do YouTube rejeita portas malformadas e continua reconhecendo URLs `watch` com parâmetros reordenados e fragmentos. O parser JSON recusa respostas incompletas em vez de escolher um stream de uma lista truncada.
- A descoberta de imagens reconhece mais atributos comuns de lazy loading, além de `src`, `data-src` e `srcset` tradicionais.

## Limitações críticas

Este é um navegador homebrew experimental; não é Chromium nem um navegador moderno completo. XenonScript não transforma o motor em ECMAScript completo.

- YouTube depende de instâncias Invidious públicas, da disponibilidade da API e da existência de stream MP4 muxado até 480p. As instâncias são de terceiros e podem recusar, limitar ou deixar de resolver vídeos.
- A reprodução continua sendo delegada a um player externo configurado no `X360Browser-video-config.txt`; o X360Browser não ganhou um decodificador completo H.264/AAC com sincronização audiovisual nativa nesta versão. Não é prometida reprodução dentro da própria interface.
- Poki e outros jogos web modernos **não são declarados compatíveis**. XenonScript é um subconjunto limitado, sem motor ECMAScript completo, Canvas 2D/WebGL, WebAssembly, timers/event-loop completos ou as APIs de navegador requeridas por muitos jogos.
- Sites modernos ainda podem depender de cookies complexos, service workers, módulos ES, CORS, CSP, APIs de autenticação, layouts CSS avançados ou iframes executáveis não implementados.
- Alterações de limites aumentam o consumo de memória potencial. O projeto mantém limites explícitos para reduzir o risco em um console com memória restrita.

## Validação

A validação final exige rodar os testes host, compilar a toolchain XSDK/PowerPC e testar o `.xex` num Xbox 360 RGH conectado à rede. A existência deste documento não implica que a build XEX 4.0.0 tenha sido compilada ou testada fisicamente.
