# X360Browser 5.3.0 — compatibilidade

| Área | Situação na fonte |
|---|---|
| HTTP/HTTPS e validação TLS | Implementado via libcurl/Mbed TLS; requer o bundle `cacert.pem` no pacote de runtime |
| HTML/DOM | Subconjunto próprio com limites de memória |
| CSS/layout | Subconjunto próprio, com caixas, cores, bordas, imagens e partes de flex/grid/media queries |
| JavaScript | XenonScript; subconjunto limitado, não ECMAScript completo |
| Renderização Xenos | Caminho gráfico xSDK, renderizador de textura e texto; necessita teste no XEX/console |
| Imagens | Decodificadores próprios delimitados para perfis suportados; não cobre todos os formatos/perfis |
| Gamepad/cursor | Controles próprios do app, com hit-test para links e alguns controles |
| YouTube | Experimental; resolução MP4 e player externo opcional, sem DRM nem pipeline HTML5 geral |
| Poki/jogos web modernos | Sem garantia; dependem de JavaScript/APIs/CSS que o motor não implementa totalmente |
| Chromium/WebKit/WebGL/WebAssembly | Não implementados como motores completos |

Os logs de 5.3.0 distinguem `view=GRAPHICAL` e `GRAPHICAL FRAME` de um simples estado de inicialização. Isso melhora o diagnóstico; não equivale à confirmação de um teste visual de hardware.
