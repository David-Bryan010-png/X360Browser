# Compatibility — X360Browser 2.1.0-xenonscript-dev

| Feature | Status |
|---|---|
| HTTP/HTTPS transport | Implemented in NativePlus/libcurl support path; console validation pending |
| Own bounded HTML DOM | Partial, explicit memory/node/depth limits |
| Own embedded CSS parser | Partial: tag/class/ID, descendant, direct child, attribute selectors and selected pseudo-classes |
| Text/layout/link focus | Partial, built by XenonWeb and drawn by Xbox visual renderer; device test pending |
| Inline script execution | Experimental subset through XenonScript; **not full JavaScript/ECMAScript** |
| Basic script variables/expressions/if/else | Supported subset only |
| `textContent`, selected attributes, `getElementById`, simple `querySelector` | Partial XenonScript DOM binding |
| Inline anchor `onclick` | Partial; only supported syntax, no full DOM event model |
| Fragment anchors | Retained in extracted link table; local handler dispatch supported in host tests |
| Raster images | Bounded common-raster support in inherited image path; browser-wide image compliance not implied |
| Complete HTML5/CSS, CSS external sheets, flex/grid | Not implemented |
| Full forms, iframe runtime, DOM event loop, external JS | Not implemented |
| Canvas/WebGL/WebAssembly/WebSockets/service workers | Not implemented |
| Modern web games, Roblox web client, YouTube watch playback | Not supported/verified |
| Real NetSurf integration | Not implemented; only a stub exists |
| PowerPC/XEX and physical Xbox validation | Pending for this source package |

This is an experimental development package. Host-test success does not establish standards compliance, console performance, or successful XEX startup. See `XENONWEB-ENGINE.md` and `XENONSCRIPT.md`.
