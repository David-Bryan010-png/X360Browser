# Source changes — 6.2.0

## Build/distribution

- Preservado o target xSDK `X360Browser` para não alterar a macro `xsdk_add_xex`; o script de build cria e valida `build-xbox360/default.xex` como nome final obrigatório.
- O pacote de instalação contém `default.xex`, CA bundle, config de mídia, favoritos, README, licenças e `SHA256SUMS.txt`; não empacota `X360Browser.xex` como alternativa.
- O workflow verifica `default.xex`, publica o asset e checksum sob esses nomes, compara re-publicações de versão pelo mesmo arquivo e só publica depois do cross-build.

## Atualização

- O cliente consome os assets `default.xex` e `default.xex.sha256` da GitHub Release estável.
- O caminho de destino é estritamente `game:\default.xex`; temporário, estágio e backup agora mantêm o prefixo `default`.
- O parser rejeita o asset legado `X360Browser.xex` para impedir que release e launcher discordem do nome.
- O parser do número de versão foi tornado estrito, com verificação de overflow e sem zero à esquerda.

## Engine

- `resolve_link_url` foi reconstruída para tratar caminhos relativos, root-relative, scheme-relative, query-only e remoção de segmentos literais `.`/`..` com buffers limitados.
- A normalização não decodifica escapes percentuais; `%2e` não é reclassificado como segmento literal `.`.
- Adicionados testes de contrato para o nome de arquivo em build, aplicação, manifesto e publicação, e regressões de URLs na fixture HTTP nativa.

## Status

Os testes no host verificam parser, transporte, layout e contratos. O cross-build xSDK e o teste em console continuam a exigir execução real do workflow e instalação da saída `default.xex`.
