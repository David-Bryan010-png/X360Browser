# Auditoria de engenharia — X360Browser 6.2.0

## Escopo da revisão

A revisão desta versão não afirma reescrever do zero 17 mil linhas, nem transformar uma engine própria em Chromium. Ela trabalha sobre os caminhos críticos que atravessam o produto: nome final de executável, pacote de distribuição, cliente de update, parser de versão, resolução de URL e regressões do transporte.

## Auditoria por subsistema

### XenonNet / resolução de URL

- **Absolutas HTTP/HTTPS:** preservadas para o transporte normal.
- **Scheme-relative (`//host/path`):** herda o esquema da página.
- **Root-relative (`/path`):** usa apenas a origem da página.
- **Relativas (`image.png`, `./image.png`):** usa o diretório do documento.
- **Parent-relative (`../image.png`):** normaliza segmentos literais e não atravessa a raiz da URL.
- **Query-only (`?q=value`):** preserva o caminho atual e substitui a query anterior.
- **Fragment-only:** é mantida pelo caminho específico de âncoras, não baixada como recurso.
- **Esquemas ativos/perigosos (`javascript:`, `vbscript:`, `data:` em caminhos de rede):** rejeitados pelo resolver de recursos; o transporte continua HTTP/HTTPS.
- **Memória:** buffers fixos derivados de `WEB_ENGINE_URL_CAP`; o resolver recusa resultados que não cabem em vez de emitir URL truncada.
- **Percent encoding:** não decodifica `%2e` durante a remoção de segmentos, evitando transformar uma sequência escapada numa instrução de traversal.

### DOM / CSS / layout

Os módulos existentes mantêm limites de nodes, atributos, pool de strings, regras CSS, depth, elementos visuais e custo de scripts. Os testes existentes cobrem DOM aninhado, entidades, raw text de script, fechamento implícito comum, cascade/specificity, `!important`, atributos, pseudo-classes básicas, custom properties, media queries limitadas, flex/grid limitados, formulário/controlos e invalidation do DOM. Isso não equivale a validação completa dos padrões HTML Living Standard/CSS.

### XenonScript

Runtime first-party limitado por orçamento de instruções, variáveis, tokens, tamanho de fonte e iterações de loop. Não é ECMAScript completo: módulos, async/await, promises completas, event loop, APIs de browser, JIT e execution contexts de iframe não são implementados.

### XenonMedia

Testes existentes cobrem probing de contêineres, WAV PCM/IMA ADPCM, raster BMP/QOI/PPM/PNG baseline/JPEG baseline/GIF primeiro frame, AVI sem compressão e WebVTT. Isso não implementa o pipeline moderno completo MP4/H.264/AAC, renderização acelerada de vídeo, sincronização áudio/vídeo ou DRM.

### Renderizador de Xbox

A renderização depende de xSDK/Xenos, contrato POSITION0/TEXCOORD0, textura e vertex layout. Host tests verificam o contrato e a estrutura de frame; não substituem execução na GPU do Xbox. A compilação cruzada e o teste físico são obrigatórios.

### GitHub updater / release

- Actions de checkout, cache, upload/download e publicação estão fixadas em versões explícitas revisadas em 28/10/2026; as versões oficiais foram conferidas nas páginas de Releases upstream.

A saída publicável é `default.xex` com SHA-256. Release, asset parser, downloader, instalação e launcher devem manter o mesmo nome. O cliente verifica versão, origem do asset, TLS e digest. O sistema de arquivos pode impedir o rename do executável ativo; nesse caso a atualização é staged, não substituição instantânea garantida.

## Validações exigidas

- `python3 tests/validate_project_integrity.py`
- `python3 tests/test_default_xex_contract.py`
- `python3 tests/test_auto_update_contract.py`
- `python3 tests/test_auto_release_contract.py`
- `python3 tests/run_host_tests.py`
- CMake + CTest host
- GitHub Actions cross-build xSDK
- Teste físico com `default.xex`, navegando por página HTML, CSS, links relativos, imagens, erros e update log

## Posição técnica

Este trabalho melhora e testa camadas existentes; não afirma que todos os motores estão completos. O maior ganho demonstrado deve vir dos testes executados. Cada lacuna não implementada deve continuar declarada para evitar confundir renderização HTML limitada com compatibilidade total com sites atuais.
