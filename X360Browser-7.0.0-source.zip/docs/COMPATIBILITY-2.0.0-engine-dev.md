# Compatibility — X360Browser 2.0.0-engine-dev (historical)

This matrix describes the prior XenonWeb DOM/CSS milestone. It is superseded by [`COMPATIBILITY-2.2.0-xenonscript-external-dev.md`](COMPATIBILITY-2.2.0-xenonscript-external-dev.md), which adds the experimental XenonScript subset, additional CSS selectors and inline anchor handler dispatch.

The 2.0.0 build had a bounded DOM tree and static CSS/layout subset but did not execute scripts. The new 2.1.0 interpreter is still not full ECMAScript; neither version is a modern web browser or has a validated physical-console XEX in the current development package.
