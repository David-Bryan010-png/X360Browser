# X360Browser 5.2.0 — resumo técnico de alterações

## Renderização gráfica

- Viewport do renderizador expandido de 1152×500 para 1280×544, com coordenadas do cursor e da página alinhadas à largura integral.
- `WebVisualImage.stretch` permite que imagens de fundo CSS preencham o elemento. Imagens de conteúdo preservam o comportamento de proporção.
- XenonWeb reconhece `background-image: url(...)` e `background` com URL; o layout reserva a camada de fundo antes dos filhos e atualiza sua altura depois do layout do conteúdo.
- Pré-carregamento raster tenta primeiro imagens de conteúdo e depois fundos CSS; folhas de estilo externas também têm URLs de imagem descobertas.
- Adicionados testes para parse de `background-image` e para camada visual de fundo.

## Atualização direta do GitHub

- Nova unidade `update_manifest.c/.h` para analisar tag/version, localizar `X360Browser.xex`, aceitar digest SHA-256 do asset e fallback `X360Browser.xex.sha256`.
- Só aceita URL de download sob o domínio e caminho oficial de releases do repositório `David-Bryan010-png/X360Browser`.
- Cliente consulta `/releases/latest` com TLS/certificado verificado, limita tamanho, valida hash e tenta rollback.
- Removida dependência de URL Vercel e arquivo `X360Browser-update-config.txt` do pacote de runtime.

## Verificação e limites

- Incluído teste C nativo para o parser do manifesto e cenários de hash/host recusado.
- Suíte host cobre XenonWeb, XenonScript, XenonMedia, transporte, URLs YouTube e contratos do atualizador.
- Build local host não prova que o SDK PowerPC esteja disponível nem que o XEX inicie no console. A compilação Xbox deve ocorrer no workflow, e testes em RGH/JTAG ainda são necessários.
