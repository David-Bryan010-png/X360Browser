# X360Browser 2.3.0 — release hardening and compatibility

This release focuses on reproducible host checks, correcting source-root discovery in GitHub Actions, and keeping source/build artifact names consistent. It does not represent a completed modern browser engine.

## Implemented in the source tree

- First-party XenonWeb DOM/CSS parser and bounded layout path, with VisualLite as a fallback.
- XenonScript's experimental, limited inline-script subset and the tested path for up to two small synchronous external scripts.
- NativePlus network transport with TLS support supplied by the linked dependencies.
- Local automated tests for DOM/CSS/layout/script behavior, HTTP fixtures, bounded media resource handling, and portable C++ core.
- CI project-root discovery, an actionable missing-source diagnostic, and a fallback that can reconstruct the host-test runner when its accompanying tests and fixture exist.

## Still not implemented / not verified

- XenonScript is not ECMAScript or a complete JavaScript runtime; no promises, modules, general functions/closures, event loop, or modern framework compatibility.
- Complete standards-compatible HTML/CSS, forms, storage, service workers, Canvas/WebGL, WebAssembly, and browser security isolation.
- In-page video decoding/audio synchronization or modern YouTube playback. The existing direct/HLS download path is separate from embedded playback.
- Real NetSurf frontend integration; `netsurf_backend_stub.c` remains an availability stub.
- Successful PowerPC/xSDK cross-build or successful launch on physical Xbox 360 hardware. The GitHub cross-build must complete, and the output must be tested on the target console.

## Validation status

Host tests and the portable CMake/CTest suite are run locally for this package. CI's PowerPC/XEX job is separate and can fail due to toolchain/dependency availability or build incompatibilities. Do not advertise an XEX as functional unless the cross-build artifact exists and boot/input/network behavior is tested on-console.
