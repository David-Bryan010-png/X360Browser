# Compatibility matrix — X360Browser 0.9.0

Historical reference only. See `COMPATIBILITY-3.6.0-web-compatibility-preview.md` for the current development matrix. In 0.9.0, the visual renderer was PNG-only; 1.0.0-preview expands raster formats and adds limited unencrypted HLS VOD download/handoff. Neither version implements a full browser engine, JavaScript, modern web games, or YouTube playback.
