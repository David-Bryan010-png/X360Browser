# X360Browser 3.5.0 — 50 lacunas prioritárias

Este arquivo traduz para português uma primeira lista de 50 lacunas de compatibilidade registradas na auditoria técnica `ENGINE-GAP-AUDIT-3.5.0.md`. **São recursos ainda pendentes ou parciais, não recursos declarados como concluídos nesta versão.** A coluna “estado” reflete a situação atual do código.

## HTML e semântica

| ID | Recurso em falta | Estado |
|---|---|---|
| GAP-001 | Parser HTML completo compatível com WHATWG (tokenização e construção da árvore) | PENDENTE |
| GAP-002 | Recuperação completa de tags de formatação mal aninhadas | PENDENTE |
| GAP-003 | Algoritmos de tabelas, modos de inserção e reposicionamento de nós | PENDENTE |
| GAP-004 | Regras completas de fechamento implícito de todos os elementos HTML | PARCIAL |
| GAP-005 | Tabela completa de referências de caracteres HTML nomeadas e numéricas | PARCIAL |
| GAP-006 | Modos DOCTYPE: quirks, limited-quirks e standards | PENDENTE |
| GAP-007 | Seleção responsiva de imagens com `picture`, `srcset` e `sizes` | PENDENTE |
| GAP-008 | Fragmentos de documento de `template.content` | PENDENTE |
| GAP-009 | Comportamento interativo de `details` e `summary` | PENDENTE |
| GAP-010 | Comportamento modal e não modal de `dialog` | PENDENTE |
| GAP-011 | Ciclo de vida de Custom Elements | PENDENTE |
| GAP-012 | Shadow DOM e distribuição por `slot` | PENDENTE |
| GAP-013 | `iframe`, contextos de navegação isolados e `srcdoc` | PENDENTE |
| GAP-014 | Comportamento de fallback de `object` e `embed` sem plugins | PENDENTE |
| GAP-015 | Import maps e `modulepreload` | PENDENTE |

## Formulários, acessibilidade e entrada

| ID | Recurso em falta | Estado |
|---|---|---|
| GAP-016 | Envio completo de formulários e codificação de URLs | PENDENTE |
| GAP-017 | Validação nativa de restrições e estados de validade | PENDENTE |
| GAP-018 | Exclusividade de grupos de radio entre formulários | PENDENTE |
| GAP-019 | Seleção de `select`/`option` e navegação por controle/teclado | PENDENTE |
| GAP-020 | Campos de arquivo e corpos de upload | PENDENTE |
| GAP-021 | Semântica dos campos de data, hora e número | PENDENTE |
| GAP-022 | Interação com trilho e cursor do campo `range` | PENDENTE |
| GAP-023 | Comportamento de edição de `contenteditable` | PENDENTE |
| GAP-024 | Selection API, caret e intervalos de seleção de texto | PENDENTE |
| GAP-025 | Árvore de acessibilidade e papéis semânticos | PENDENTE |
| GAP-026 | Cálculo de nome e descrição acessíveis | PENDENTE |
| GAP-027 | Ordem de foco por teclado em todos os elementos interativos | PARCIAL |
| GAP-028 | Regras completas de reset, submitter e submissão de formulários | PENDENTE |
| GAP-029 | Preenchimento automático e gerenciador de senhas | PENDENTE |
| GAP-030 | Integração com leitores de tela e regiões `aria-live` | PENDENTE |

## CSS, layout e renderização

| ID | Recurso em falta | Estado |
|---|---|---|
| GAP-031 | Tokenizador de sintaxe CSS completo e recuperação de erros | PENDENTE |
| GAP-032 | Propriedades personalizadas CSS e substituição por `var()` | PARCIAL — suporte limitado a `:root` e fallback |
| GAP-033 | Aritmética de `calc()`, `min()`, `max()` e `clamp()` | PENDENTE |
| GAP-034 | Camadas de cascata CSS com `@layer` | PENDENTE |
| GAP-035 | Especificidade completa e semântica integral de listas de seletores | PARCIAL |
| GAP-036 | Seletor relacional `:has()` | PENDENTE |
| GAP-037 | Semântica completa de `:is()`, `:where()` e `:scope` | PENDENTE |
| GAP-038 | Pseudo-elementos `::before` e `::after` | PENDENTE |
| GAP-039 | Contadores CSS e estilos de contadores | PENDENTE |
| GAP-040 | Consultas de recursos `@supports` | PENDENTE |
| GAP-041 | Container queries | PENDENTE |
| GAP-042 | Gramática integral de media queries, incluindo intervalos | PARCIAL |
| GAP-043 | Variáveis CSS em shorthands e valores herdados | PARCIAL — substituição em shorthands, escopo/herança pendentes |
| GAP-044 | Serialização de estilos computados compatível com navegadores | PENDENTE |
| GAP-045 | APIs de mutação de regras CSSOM | PENDENTE |
| GAP-046 | Contexto de formatação inline compatível com padrões | PENDENTE |
| GAP-047 | Geometria de `float`, `clear` e exclusões | PENDENTE |
| GAP-048 | Algoritmo completo de dimensionamento Flexbox e `min-content` | PARCIAL |
| GAP-049 | Auto-posicionamento Grid, linhas nomeadas e `minmax()` | PARCIAL |
| GAP-050 | Dimensionamento intrínseco `min-content`/`max-content` | PENDENTE |

## Observação de implementação

Esta lista foi adicionada ao repositório para orientar o trabalho seguinte e evitar alegações indevidas de compatibilidade. A versão 3.5.0 acrescenta `var()` limitado em `:root`, decodificação WAV IMA ADPCM e primitivas de WebVTT, além dos decodificadores raster próprios; ainda assim, **não implementa automaticamente os 50 itens acima**. O estado de cada item só deve mudar após implementação, teste de regressão e validação no alvo quando aplicável.
