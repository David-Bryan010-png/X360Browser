# Motor gráfico — X360Browser 6.0.0

O XenonWeb continua sendo um motor próprio e limitado, com DOM/CSS/XenonScript e uma composição gráfica através da GPU do Xbox 360. Nesta versão a navegação não apresenta mais o texto extraído como se fosse a página. O desenho usa `web_visual_renderer_draw`; falhas viram diagnóstico gráfico da aplicação.

`GRAPHICAL FRAME` demonstra que o caminho de desenho foi chamado; isso não prova que todos os recursos HTML/CSS do site são suportados ou que a tela física foi validada. Para evidência, combine o log com uma captura do Xbox.
