# X360Browser 7.0.0 — alterações da fonte

## Arquivos de motor alterados

### `engine/xenonweb/xw_layout.c`

- `xw_append_fragment()` agora usa a largura disponível para calcular quantos caracteres cabem em uma linha. Palavras que cabem em uma linha são mantidas juntas quando possível; palavras maiores que a caixa são divididas em múltiplos runs visuais. A rotina respeita o limite do buffer e tenta não dividir uma sequência UTF-8 no meio de um ponto de código.
- `xw_control_inner_text()` recupera texto interno limitado para controles e escolhe o texto da opção selecionada de um `select`, recorrendo à primeira opção quando nenhuma está marcada.
- `button`, `textarea` e `select` são renderizados uma vez como controles gráficos. Seus descendentes não são desenhados novamente como texto de página.
- O placeholder de uma imagem não carregada é formatado como `[Image: alt]`, com comprimento limitado ao buffer de saída.
- O tamanho mínimo de controles não força um campo a ultrapassar um contêiner que tenha menos de 48 px de largura.

### `engine/xenonweb/xw_css.c`

- Parser hex validado para `#RGB`, `#RGBA`, `#RRGGBB` e `#RRGGBBAA`. A forma CSS `#RRGGBBAA` é rearranjada para ARGB, layout consumido pelos frames atuais.
- Comprimentos hex não suportados e dígitos inválidos caem no valor fallback sem ler fora do array temporário.
- Adicionadas palavras-chave de cor que aparecem com frequência em CSS real.

### `engine/xenonweb/xw_script.c`

- Inclui `<math.h>` para declarações de `isfinite()` e `isnan()`, necessárias ao build C17 estrito.
- Um `while` reavalia a condição terminal no limite de iterações: loops finitos que terminam exatamente no limite são aceitos, enquanto loops que continuam verdadeiros definem `budget_exhausted` e falham de forma explícita.

## Arquivos de validação alterados

### `tests/test_xenonweb_layout.c`

- Regressoes para `#RGBA`, `#RRGGBBAA`, a cor `coral`, rótulos de botão, valor inicial de textarea, opção selecionada de select e palavras longas sem espaços.
- A fixture de palavra longa reutiliza os frames grandes já alocados pelo teste para não aumentar excessivamente o uso da stack.

### `tests/test_default_xex_contract.py`

- O contrato de versão semântica exige `7.0.0`, mantendo `default.xex` como nome único de instalação.

### Metadados e documentação

- `VERSION`, `include/x360browser/version.hpp`, README, changelog e relatório de testes estão sincronizados para 7.0.0.
