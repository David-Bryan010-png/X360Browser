# X360Browser 3.3.0 — compatibility and validation boundaries

## Implemented and host-tested

- First-party XenonWeb bounded DOM, CSS subset, responsive `@media`, limited Flexbox/Grid layout, dynamic DOM, and the first-party XenonScript subset.
- NativePlus HTTP/HTTPS transport, MIME checks for selected resource types, bounded resource downloads and PNG/JPEG/GIF/BMP cache path.
- Extraction and selection of HTML audio/video source links; focusable PLAY VIDEO/PLAY AUDIO cards in the primary renderer.
- External-player handoff for direct media downloads and an optional URL-forwarding mode; bounded finished/unencrypted HLS VOD download path.
- Host C tests, strict warning checks for the tested units, CMake/CTest for the portable C++ core and package-integrity validation.

## Media support: important distinction

Audio/video is **not decoded inside XenonWeb**. The project hands the media path or URL to an external XEX through its `VideoLaunchInfo` contract. The external player must be supplied separately and must understand this handoff. Neither direct playback nor `stream-url` mode has been confirmed on an Xbox 360 physical console in this milestone.

The direct-download path accepts HTTP/HTTPS with a successful response and bounds media to 512 MiB. The HLS VOD path bounds manifests to 128 KiB and playlists to 256 segments and refuses live playlists, encryption/DRM, and byte-range playlists. MPEG-DASH, YouTube watch pages and protected streams are not implemented.

## Not implemented or not verified

- Full ECMAScript/modern JavaScript compatibility, Canvas/WebGL, WebAssembly, service workers, full DOM/event loop semantics and broad web platform APIs.
- Full standards-compliant HTML/CSS, iframe browsing, modern login/SPA behavior, or modern game compatibility.
- In-page media decoding, subtitles/caption selection, DRM, DASH, direct YouTube page playback, or verified external-player compatibility.
- PowerPC/xSDK XEX build and launch on a physical Xbox 360. The build workflow remains validation-only by default; its XEX stage is an explicit opt-in.

A host test passing is not proof of real Xbox execution. Treat all compatibility beyond the tested subset as experimental.
