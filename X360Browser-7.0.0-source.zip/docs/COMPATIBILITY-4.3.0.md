# X360Browser 4.3.0 — compatibilidade real

## Correções desta versão

- Corrige o workflow que falhava em `Extract validated source`: o upload anterior misturava o ZIP e o log em diretórios diferentes, fazendo o GitHub Actions preservar `x360browser-dist/` dentro do artefato. O build agora publica ZIP e checksum separados dos logs, procura o arquivo recursivamente e verifica o SHA-256 antes de extrair.
- A extração de fonte faz validação de integridade, limite de quantidade/tamanho, rejeição de caminhos absolutos, `..`, barras invertidas e links simbólicos, e confirmação explícita de `VERSION=4.3.0`.
- Adiciona teste de regressão para layouts planos e aninhados do artefato do Actions.
- Atualiza a barra de título que ainda mostrava `X360 BROWSER 3.3`.
- Inicializa o buffer de endereço, limpa ponteiros temporários de estatística/código do parser global sem quebrar variáveis entre eventos e protege helpers CSS contra ponteiros nulos.
- Mantém a correção crítica do contrato do shader da 4.2.0: `POSITION0` em location 0 e `TEXCOORD0` em location 2.

## Limites que continuam válidos

X360Browser continua usando XenonWeb/XenonScript próprios e limitados. Não transforma XenonScript em ECMAScript completo. Não é Chromium; JavaScript moderno, Canvas/WebGL/WebAssembly, iframes modernos, DRM, H.264/AAC nativos e compatibilidade universal de sites ou jogos não são garantidos. O host-test não equivale a compilação PowerPC real nem a teste num console Xbox 360.

Recursos não implementados ou não validados neste release incluem WebGL, WebAssembly, APIs de navegador modernas, execução de iframes de terceiros e reprodução nativa completa de vídeo/áudio.

A resolução de URLs do YouTube é experimental, depende de serviços externos de terceiros e não constitui suporte de reprodução garantido.
