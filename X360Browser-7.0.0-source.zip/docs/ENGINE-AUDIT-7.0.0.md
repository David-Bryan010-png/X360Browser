# Auditoria de engenharia — X360Browser 7.0.0

## Escopo

Esta versão é uma atualização direta da fonte 6.5.0 enviada ao projeto. Não é uma reescrita integral de navegador moderno; é uma correção de caminhos visuais prioritários com testes de regressão.

## Mudanças verificadas

- Layout: palavras longas quebram em runs que cabem na largura de linha calculada.
- CSS: cores `#RGBA` e `#RRGGBBAA` são validadas, convertidas em ARGB e verificadas no frame gerado; cores inválidas não podem escrever além do buffer.
- Formulários: o texto de button/textarea/select passa a aparecer no controle, com escolha da opção selecionada no select, e não é desenhado novamente pelos nós descendentes.
- Imagens: o marcador de recurso não carregado é legível.
- XenonScript: declarações de math são incluídas corretamente e o limite de `while` é tratado como falha segura de execução.
- Release: versão sincronizada em `VERSION`, cabeçalho C++ e teste de contrato do executável `default.xex`.

## Testes executados localmente

- `tests/run_host_tests.py`: passou, incluindo XenonWeb DOM/CSS, layout gráfico, XenonScript, XenonMedia, transporte, dispatch e compatibilidade de URL/YouTube.
- `tests/validate_project_integrity.py`: passou; 88 entradas de fonte exigidas e 164 IDs históricos de lacunas continuam íntegros.
- `tests/test_default_xex_contract.py`: 10/10.
- `tests/test_xbox_shader_contract.py`: 14/14.
- `tests/test_runtime_view_contract.py`: 11/11.
- `tests/test_workflow_artifact_paths.py`: 15/15.
- `tests/test_auto_update_contract.py`: 14/14.
- `tests/test_auto_release_contract.py`: 12/12.
- CMake build host concluído; CTest 3/3.

## Não verificado neste ambiente

- O XEX para Xbox 360 não foi compilado nesta sessão.
- Não houve execução em console físico; GPU Xenos, xSDK, rede, controle e auto-update precisam ser testados no hardware.
- Não se afirma compatibilidade completa com HTML, CSS, ECMAScript, vídeo moderno, WebGL ou jogos web.
