# Source changes — 6.1.0

- Bumped application version to 6.1.0 so clients with prior versions can recognize this release as newer.
- Changed the build workflow to publish a stable GitHub Release only after validation and Xbox 360 XEX build succeed on the project's release branches.
- Uploaded the bare `X360Browser.xex` and its SHA-256 sidecar alongside the install ZIP and ZIP checksum; these are the assets consumed by the startup updater.
- Added a release guard that rejects changed binaries under an already-published semantic version and skips publishing when the same XEX is already present.
- Upgraded `softprops/action-gh-release` to v3 and made the resulting release the latest stable release.
- Fixed self-updater destination selection for the common `game:\\default.xex` install path, with fallback to `game:\\X360Browser.xex`.
- Documented that replacement can be blocked while a title is running; the updater verifies and stages the file instead of claiming an unattended self-restart.
