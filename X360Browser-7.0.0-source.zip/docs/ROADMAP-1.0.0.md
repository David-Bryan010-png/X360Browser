# Roadmap to a stable 1.0.0

Historical roadmap for the 1.0.0-preview milestone. The roadmap below is retained as a historical checklist from the preview era. The current milestone is `3.6.0-web-compatibility-preview`; see `COMPATIBILITY-3.6.0-web-compatibility-preview.md` and `ENGINE-GAP-AUDIT-3.5.0.md`. Items recommending NetSurf are obsolete: this project now follows a first-party XenonWeb engine strategy. Suggested release gates:

1. **Build gate:** run the ZIP workflow with the exact source archive, fix any PowerPC/xSDK errors, preserve build logs and package the XEX plus certificates/licences.
2. **Hardware gate:** boot on an Xbox 360 RGH/JTAG; verify text, link focus, scrolling, DNS/HTTPS, cache writes, memory usage, and return from the external player.
3. **Engine gate (updated):** keep the first-party XenonWeb/XenonScript/XenonMedia path as the only page engine; close parser, runtime, layout, painting and media gaps using targeted tests. The old no-op NetSurf stub has been removed and should not be reinstated as a fake fallback.
4. **Script gate:** add an execution engine with a bounded runtime, a working DOM/event loop, timers and basic ES compatibility. Merely evaluating inline scripts is not enough for games.
5. **Canvas/game gate:** implement Canvas 2D, keyboard/gamepad events, requestAnimationFrame, timing and per-frame repaint; consider WebGL/WebAssembly only if memory and runtime feasibility is demonstrated.
6. **Media gate:** add actual audio/video demux/decode/presentation, audio output, seeking, buffering and adaptive streaming. Current direct-file/HLS VOD downloads and optional URL forwarding are external-player handoff, not in-page playback.
7. **YouTube gate:** test the official watch/embed page with its current scripts and streaming requirements. Do not claim support until it plays from the ordinary URL on hardware.
8. **Release gate:** complete a documented test matrix, confirm licences, checksums and reproducible artifacts, and publish only after no critical crash/security defects remain.

The Xbox 360 is a constrained PowerPC/512 MiB platform. Chromium/WebKit is not a drop-in dependency. Chromium/WebKit are not drop-in dependencies for this memory-constrained target. A first-party path reduces engine substitution, but modern JavaScript, Canvas and codec features still require substantial implementation and real hardware testing.
