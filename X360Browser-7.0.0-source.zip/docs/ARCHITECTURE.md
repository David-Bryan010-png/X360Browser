# X360Browser architecture (3.5.0)

- **X360Browser UI:** Xbox controls, address/navigation state, page focus and visual frame integration.
- **XenonNet-facing transport adapter:** project-owned request/orchestration code over libcurl and Mbed TLS. The transport/TLS libraries are supporting dependencies; they do not parse HTML or lay out pages.
- **XenonWeb:** project-owned bounded HTML tokenizer/tree, DOM, CSS subset, root custom properties, selected responsive queries, layout and visual records.
- **XenonScript:** bounded project-owned experimental script interpreter integrated with DOM mutation. It is not full ECMAScript.
- **XenonMedia:** first-party image raster decoding, WAV PCM/IMA ADPCM, AVI raw frame extraction, container metadata and WebVTT cue parsing.
- **Xbox target adapter:** xSDK platform, GPU and input interfaces.

The NetSurf stub was removed from the active build. No Chromium/WebKit/NetSurf browser engine or third-party player is linked as the primary engine. The platform still relies on xSDK, libcurl, Mbed TLS and a CA bundle.

HTML/CSS/JS support are intentionally incomplete. Progressive JPEG, interlaced PNG, animated GIF, modern compressed audio/video codecs, Canvas/WebGL, WebAssembly, full MP4 sample demux, complete HTMLMediaElement behavior, subtitle overlay and A/V synchronization are not implemented. `ENGINE-GAP-AUDIT-3.5.0.md` inventories 164 gaps/partial capabilities, including hardware validation.
