# X360Browser 4.1.0 — compatibilidade real

## Mudanças desta versão

- A validação de porta rejeita valores longos antes de multiplicar/acumular, evitando overflow inteiro.
- URLs HTTP/HTTPS com escapes percentuais incompletos ou não hexadecimais são rejeitadas; escapes válidos como `%2F` e `%20` são preservados.
- Foram adicionados testes de regressão para as duas classes de falha.
- Permanecem as melhorias 4.0.0: parser e validação experimental de streams do YouTube, detecção de assinatura MP4 antes do handoff, atributos lazy-load de imagem, compressão HTTP negociada e limites defensivos de documentos/scripts.

## Limitações que continuam

- Não é Chromium e não transforma XenonScript em ECMAScript completo; XenonScript não implementa ECMAScript moderno completo.
- O caminho de vídeo do YouTube continua experimental, depende de instâncias públicas de terceiros e entrega o arquivo a um player externo configurado. Encontrar/baixar um MP4 não prova que o Xbox 360 consiga decodificá-lo e exibi-lo.
- Não há promessa de reprodução nativa de H.264/AAC nem de sincronização audiovisual completa.
- Timers completos, APIs modernas de navegador e módulos ES continuam não implementados. Jogos modernos do Poki continuam sem compatibilidade garantida: faltam APIs completas de JavaScript, Canvas 2D/WebGL, WebAssembly, timers/event-loop e APIs web modernas.
- A compilação PowerPC/XEX e o teste físico no Xbox 360 RGH ainda precisam ser feitos separadamente. Os testes de host não substituem essa validação.
