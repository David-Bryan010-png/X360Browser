# X360Browser 7.0.0 — estado da fonte

## Alterações atuais

- A fonte 6.5.0 enviada pelo usuário foi atualizada diretamente para a versão 7.0.0.
- XenonWeb quebra palavras longas pela largura da linha e valida cores CSS hex com alpha.
- Campos button, textarea e select exibem rótulos/valor inicial dentro do controle sem pintar novamente os nós descendentes.
- XenonScript compila em modo C17 estrito por incluir `<math.h>` para `isfinite`/`isnan`; loops `while` que atingem o limite de iteração falham explicitamente.
- `VERSION`, `include/x360browser/version.hpp` e o contrato de release estão sincronizados para 7.0.0.

## Validação local

- Host suite: passou (DOM/CSS/layout, formulários, palavras longas, XenonScript, XenonMedia, transport/dispatch e URLs).
- Contratos de versão/XEX: 10/10; shader/runtime: 14/14; runtime view: 11/11; artifact paths: 15/15; auto-update: 14/14; auto-release: 12/12.
- CMake/CTest host: 3/3.

## Exige validação externa

- O GitHub Actions ainda precisa executar a compilação cruzada PowerPC/xSDK e publicar a release.
- O `default.xex` resultante deve ser testado no Xbox 360 RGH/JTAG real para validar GPU, shaders, gamepad, rede e auto-update.
- O motor continua sendo um subconjunto próprio: não é Chromium/WebKit e não promete compatibilidade universal com sites atuais.

---

## Histórico do estado anterior (6.0.0)

# X360Browser 6.0.0 — estado da fonte

## Alterações desta versão

- A navegação usa o caminho gráfico como modo padrão em páginas HTML.
- O leitor textual de páginas foi removido do caminho principal; o corpo de uma resposta não é mais desenhado por `draw_scrolled_page_text`.
- X percorre página gráfica, links e recursos.
- Falhas do renderer, recursos binários e erros de rede recebem superfícies de diagnóstico em vez de uma página textual disfarçada de navegador.
- O estado visual é invalidado quando uma resposta é atribuída à página ativa.
- Atualizador continua usando GitHub Releases e validação SHA-256; não exige Vercel nem arquivo de configuração de URL.

## Validação realizada neste ambiente

- Integridade do pacote: 76 arquivos obrigatórios, versão 6.0.0.
- Contratos de visualização: 11/11.
- Contratos shader/runtime: 14/14.
- Contratos de paths do workflow: 13/13.
- Contratos do atualizador: 12/12.
- Testes de host XenonWeb, XenonScript, XenonMedia, transporte, dispatch, layout e compatibilidade de URL passaram.
- CMake/CTest de host: 3/3 testes passaram.

## Ainda exige validação externa

- O GitHub Actions precisa compilar o XEX usando o toolchain PowerPC/xSDK.
- O executável deve ser testado em Xbox 360 RGH/JTAG real para validar GPU, shaders, teclado/gamepad, rede e navegação.
- Sites atuais e jogos web ainda excedem o subconjunto de HTML/CSS/JavaScript deste motor. O objetivo de navegador moderno completo não foi alcançado por este marco.
