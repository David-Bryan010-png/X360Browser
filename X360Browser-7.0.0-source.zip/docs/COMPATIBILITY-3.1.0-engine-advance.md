# X360Browser 3.1.0-engine-advance — matriz de compatibilidade

| Área | Estado nesta versão |
|---|---|
| HTML/DOM | Parser próprio limitado; recuperação de algumas tags finais omitidas; RCDATA em `title`/`textarea`; DOM dinâmico, `nodeValue`/`textContent`, parent/siblings e classList limitados |
| CSS | Folhas externas pequenas com MIME validado; subconjunto ampliado: seletores compostos/descendentes, atributos, pseudoclasses selecionadas, RGB/RGBA, margem shorthand, linha, transformação e decoração de texto |
| Layout | Texto, blocos, backgrounds, margens/larguras limitadas, links focáveis, caixas/placeholder de mídia e controles |
| XenonScript | Interpretador próprio limitado; expressões, `if/else`, `for` limitado, DOM dinâmico, `classList`, `querySelector`/`closest`/`matches`, relações de nós, atributos básicos de formulários, mutação DOM/style e onclick selecionado |
| Rede | HTTP/HTTPS via NativePlus/libcurl; TLS e limites de recursos; scripts externos síncronos pequenos em subset experimental |
| Imagens | Pipeline raster auxiliar com limites de download/dimensões, conforme build e disponibilidade do decodificador |
| XEX | Não confirmado por esta entrega; o workflow tenta compilar com PowerPC/xSDK |

## Ainda ausente

- JavaScript/ECMAScript completo, event loop, callbacks, frameworks, promises e APIs de rede no JavaScript.
- HTML5/CSS completos, Flexbox/Grid, media queries, layout inline avançado, validação/submissão de forms e iframes funcionais.
- Canvas 2D, WebGL, WebAssembly, WebSockets e service workers.
- Reprodução de vídeo embutida/YouTube e compatibilidade com jogos web modernos; Roblox não suportado.
- Integração real do NetSurf; o arquivo atual permanece um stub.
- Teste de arranque no Xbox 360 físico.

Esta matriz descreve a implementação e os testes disponíveis, não uma promessa de compatibilidade de sites.
