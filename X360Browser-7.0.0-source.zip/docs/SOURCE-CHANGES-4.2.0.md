# X360Browser 4.2.0 — correção da tela de texto e melhorias

## Causa identificada no log real

O log registrava:

```text
shader: the vertex layout lacks an input the shader fetches
X360Browser visual: shader/texture init failed 0xC000000D
X360Browser: visual renderer unavailable; continuing in text-reader mode.
```

O renderizador não falhava por causa do HTML de `example.com`/Google primeiro; ele falhava durante a inicialização do layout de vértices. Quando isso acontecia, a aplicação selecionava explicitamente o leitor de texto, que é a tela azul-escura com texto/código.

## Correção principal

- `platform/xbox360/xsdk/page.vert`: a entrada `a_texcoord` passou de GLSL `location = 1` para `location = 2`.
- O xSDK define o contrato das entradas GLSL por localização: `0 = POSITION`, `1 = COLOR`, `2 = TEXCOORD0`, `3+ = TEXCOORD` adicional. A antiga `location = 1` não correspondia à entrada `XSDK_USAGE_TEXCOORD` da declaração, fazendo `xsdk_shader_set_vertex_layout()` rejeitar o layout.
- O formato de vértice permanece intercalado em 16 bytes: posição `float2` no offset 0 e UV `float2` no offset 8, ligados agora às localizações/semânticas corretas.
- Adicionado `tests/test_xbox_shader_contract.py` para validar o contrato entre shader, layout, stride e arquivos de primeira execução, e integrado o teste à suíte de host.

## Outras correções

- A inicialização gráfica agora distingue no log falhas de carregamento do vertex shader, pixel shader, vertex layout e textura. Se um build futuro regredir, o log aponta a etapa exata.
- O build do xEX cria `X360Browser-video-config.txt` a partir da configuração de exemplo e cria `X360Browser-bookmarks.txt` vazio. A configuração mantém o player externo desativado por padrão.
- A remoção redundante do arquivo de cache antes de abrir a imagem em modo de escrita foi eliminada; `fopen(..., "wb")` já cria/substitui o arquivo. Isso evita mensagens de arquivo inexistente na primeira descarga de cada imagem.
- `copy_text()` passa a fazer cópia com limite explícito e terminação NUL, preservando truncamento seguro sem o padrão que gerava o aviso `%s directive output may be truncated`.
- User-Agent, nome do título, documentação e empacotamento foram atualizados para 4.2.0.
- Workflow de Actions refatorado: testes/validação primeiro; XEX gerado automaticamente no job seguinte, com limite de 90 minutos e artefato contendo configuração, favoritos, certificado e licenças.

## Validação feita neste ambiente

- `tests/validate_project_integrity.py`: aprovado.
- `tests/test_xbox_shader_contract.py`: 12/12 verificações aprovadas.
- `tests/run_host_tests.py`: suíte XenonWeb/XenonScript/XenonMedia, rede e regressões aprovada; XenonMedia marcou 98 checks e zero falhas.
- CMake host build: aprovado; CTest: 2/2 testes aprovados.
- Sintaxe C estrita dos componentes da interface/engine: aprovada.
- Bash syntax e YAML parse/estrutura do workflow: aprovados; 11 blocos `run` passaram `bash -n`.

## Limites e próximo teste

A ferramenta deste ambiente não conseguiu compilar o XEX final nem executar a GPU num Xbox 360 físico. A correção foi guiada pela mensagem do log do console e pela convenção de interfaces do xSDK, e os testes de fonte previnem regressão. O próximo teste precisa ser feito com o XEX novo no RGH/JTAG. O log esperado é `X360Browser visual: XenonWeb DOM/CSS/XenonScript renderer initialized`; a mensagem `visual renderer unavailable; continuing in text-reader mode` não deve aparecer por causa desse contrato de entradas.

A versão continua sendo um motor próprio limitado, não Chromium; WebGL/WebAssembly, JavaScript moderno e reprodução de H.264/AAC com áudio nativo não são declarados como suportados.
