> **Historical snapshot:** this inventory is frozen at 3.4.0. The current 164-item audit is `ENGINE-GAP-AUDIT-3.5.0.md`.

# X360Browser 3.4.0 — ENGINE GAP AUDIT

Esta auditoria lista **mais de 100 capacidades** que ainda faltam ou só existem como subconjuntos. A coluna de estado é deliberadamente explícita: “IMPLEMENTADO” significa que há código e teste em 3.4.0 para a primitiva indicada; “PARCIAL” não significa compatibilidade de padrão completa. Os itens pendentes são backlog, não recursos que este ZIP declara já concluídos.

## Salto real incluído na 3.4.0

- Decoder JPEG baseline sequencial escrito no projeto: grayscale e RGB, amostragem 4:4:4 e 4:2:0, Huffman, tabelas de quantização, DCT inversa e restart markers; detecta buffers pequenos e fluxos truncados.
- Decoder BMP próprio ampliado para paletas 1/4/8-bit junto aos modos 24/32-bit BI_RGB.
- O caminho de renderização chama o dispatcher próprio `xm_media_decode_image_rgba`, que roteia por assinatura para os decoders XenonMedia de BMP/QOI/PPM/PNG/GIF primeiro quadro/JPEG baseline. A rota principal não contém integração com decodificador raster de terceiros.
- O fallback `stb_image` foi removido do caminho atual do renderizador e do build; formatos fora do subconjunto próprio falham de modo controlado.
- Suite de testes própria ampliada com fixtures JPEG estáticas, roteamento da imagem por assinatura e validações de corrupção/capacidade.
- Auditoria de dependências e workflow foram atualizados; a compilação XEX não está habilitada por padrão.

## Lacunas por subsistema

### HTML parser and semantics

| ID | Capacidade / lacuna | Estado em 3.4.0 |
|---|---|---|
| GAP-001 | WHATWG-compliant HTML tokenizer and tree builder | PENDENTE |
| GAP-002 | Complete adoption-agency recovery for misnested formatting tags | PENDENTE |
| GAP-003 | Table foster-parenting and parser insertion modes | PENDENTE |
| GAP-004 | Full optional-end-tag rules across all HTML elements | PARCIAL |
| GAP-005 | Complete named/numeric character-reference table | PARCIAL |
| GAP-006 | DOCTYPE quirks/limited-quirks/standards mode | PENDENTE |
| GAP-007 | picture/srcset/sizes responsive image selection | PENDENTE |
| GAP-008 | template.content document fragments | PENDENTE |
| GAP-009 | details/summary disclosure behavior | PENDENTE |
| GAP-010 | dialog modal/non-modal behavior | PENDENTE |
| GAP-011 | custom elements lifecycle callbacks | PENDENTE |
| GAP-012 | Shadow DOM and slot distribution | PENDENTE |
| GAP-013 | iframe nesting, browsing contexts and srcdoc | PENDENTE |
| GAP-014 | object/embed plugin-free fallback semantics | PENDENTE |
| GAP-015 | HTML import maps and modulepreload | PENDENTE |

### Forms, input and accessibility semantics

| ID | Capacidade / lacuna | Estado em 3.4.0 |
|---|---|---|
| GAP-016 | Complete form submission and URL encoding | PENDENTE |
| GAP-017 | Native constraint validation and validity states | PENDENTE |
| GAP-018 | Radio-group exclusivity across form owners | PENDENTE |
| GAP-019 | Select/option selection model and keyboard interaction | PENDENTE |
| GAP-020 | File inputs and upload bodies | PENDENTE |
| GAP-021 | Date/time/number input type semantics | PENDENTE |
| GAP-022 | Range input track/thumb interaction | PENDENTE |
| GAP-023 | Contenteditable editing host behavior | PENDENTE |
| GAP-024 | Selection API and caret ranges | PENDENTE |
| GAP-025 | Browser accessibility tree and roles | PENDENTE |
| GAP-026 | Accessible name and description computation | PENDENTE |
| GAP-027 | Keyboard focus order for every interactive element | PARCIAL |
| GAP-028 | Form reset and submitter button rules | PENDENTE |
| GAP-029 | Autofill and password manager | PENDENTE |
| GAP-030 | Screen-reader/live-region integration | PENDENTE |

### CSS parsing, cascade and selectors

| ID | Capacidade / lacuna | Estado em 3.4.0 |
|---|---|---|
| GAP-031 | Full CSS Syntax tokenizer and error recovery | PENDENTE |
| GAP-032 | CSS custom properties and var() substitution | PENDENTE |
| GAP-033 | calc()/min()/max()/clamp() arithmetic | PENDENTE |
| GAP-034 | Cascade layers (@layer) | PENDENTE |
| GAP-035 | Complete specificity and selector-list semantics | PARCIAL |
| GAP-036 | :has() relational selector | PENDENTE |
| GAP-037 | :is()/:where()/:scope() full semantics | PENDENTE |
| GAP-038 | Pseudo-elements ::before and ::after | PENDENTE |
| GAP-039 | CSS counters and counter styles | PENDENTE |
| GAP-040 | @supports feature queries | PENDENTE |
| GAP-041 | Container queries | PENDENTE |
| GAP-042 | Full media-query grammar and range syntax | PARCIAL |
| GAP-043 | CSS variables in shorthands and inherited values | PENDENTE |
| GAP-044 | Computed style serialization parity | PENDENTE |
| GAP-045 | CSSOM rule mutation APIs | PENDENTE |

### Layout and painting

| ID | Capacidade / lacuna | Estado em 3.4.0 |
|---|---|---|
| GAP-046 | Standards-grade inline formatting context | PENDENTE |
| GAP-047 | Float/clear and exclusion geometry | PENDENTE |
| GAP-048 | Complete Flexbox sizing algorithm and min-content | PARCIAL |
| GAP-049 | Grid auto-placement, named lines and minmax | PARCIAL |
| GAP-050 | Intrinsic sizing and min-content/max-content | PENDENTE |
| GAP-051 | Margin collapsing and block formatting contexts | PENDENTE |
| GAP-052 | Position: fixed/sticky and containing blocks | PENDENTE |
| GAP-053 | Stacking contexts and z-index correctness | PENDENTE |
| GAP-054 | Transforms and transform-origin | PENDENTE |
| GAP-055 | Transitions and animation timing | PENDENTE |
| GAP-056 | @keyframes and animation fill/direction | PENDENTE |
| GAP-057 | Gradients, shadows and filters | PENDENTE |
| GAP-058 | Border radius clipping and border-image | PENDENTE |
| GAP-059 | Background image layering and object-fit/position | PENDENTE |
| GAP-060 | Full font shaping, fallback and @font-face | PENDENTE |

### JavaScript language runtime

| ID | Capacidade / lacuna | Estado em 3.4.0 |
|---|---|---|
| GAP-061 | ECMAScript-compliant lexer/parser | PENDENTE |
| GAP-062 | Lexical environments, closures and block scope | PENDENTE |
| GAP-063 | Prototype chain and property descriptors | PENDENTE |
| GAP-064 | Arrays and complete standard array methods | PENDENTE |
| GAP-065 | Object literals, accessors and spread syntax | PENDENTE |
| GAP-066 | Arrow functions and lexical this | PENDENTE |
| GAP-067 | Exception values, try/catch/finally | PENDENTE |
| GAP-068 | RegExp engine | PENDENTE |
| GAP-069 | JSON parse/stringify specification behavior | PENDENTE |
| GAP-070 | Promise jobs/microtask queue | PENDENTE |
| GAP-071 | async/await and async generators | PENDENTE |
| GAP-072 | ES modules and module graph | PENDENTE |
| GAP-073 | Garbage collector and cycle collection | PENDENTE |
| GAP-074 | Intl/date/time-zone and locale formatting | PENDENTE |
| GAP-075 | Complete Math/Number/String/Map/Set built-ins | PENDENTE |

### DOM events and web APIs

| ID | Capacidade / lacuna | Estado em 3.4.0 |
|---|---|---|
| GAP-076 | Capture/bubble phases and stopImmediatePropagation | PENDENTE |
| GAP-077 | Trusted vs synthetic event semantics | PENDENTE |
| GAP-078 | MutationObserver delivery queue | PENDENTE |
| GAP-079 | ResizeObserver and IntersectionObserver | PENDENTE |
| GAP-080 | Complete DocumentFragment/range APIs | PENDENTE |
| GAP-081 | Node cloning/importing and adoption | PENDENTE |
| GAP-082 | getComputedStyle serialization and live views | PENDENTE |
| GAP-083 | Form-associated elements and submit events | PENDENTE |
| GAP-084 | History API pushState/replaceState/popstate | PENDENTE |
| GAP-085 | URL/URLSearchParams full parser and serializer | PENDENTE |
| GAP-086 | fetch Request/Response/Headers semantics | PENDENTE |
| GAP-087 | AbortController/AbortSignal | PENDENTE |
| GAP-088 | localStorage/sessionStorage quota and events | PENDENTE |
| GAP-089 | IndexedDB transactions and indexes | PENDENTE |
| GAP-090 | Service Worker lifecycle and cache API | PENDENTE |

### First-party image and graphics compatibility

| ID | Capacidade / lacuna | Estado em 3.4.0 |
|---|---|---|
| GAP-091 | BMP 1/4/8-bit palette decoding | IMPLEMENTADO 3.4.0 |
| GAP-092 | BMP RLE4/RLE8 compression | PENDENTE |
| GAP-093 | BMP bitfield masks and alpha bitfields | PENDENTE |
| GAP-094 | PNG 8-bit non-interlaced decoder with own DEFLATE | IMPLEMENTADO 3.4.0 |
| GAP-095 | PNG Adam7 interlaced passes | PENDENTE |
| GAP-096 | PNG 16-bit channel down-conversion and color management | PENDENTE |
| GAP-097 | GIF first-frame LZW and transparency | IMPLEMENTADO 3.4.0 |
| GAP-098 | Animated GIF timing/disposal/compositing | PENDENTE |
| GAP-099 | JPEG baseline grayscale/RGB/Huffman/IDCT | IMPLEMENTADO 3.4.0 |
| GAP-100 | Progressive and multi-scan JPEG | PENDENTE |
| GAP-101 | CMYK/YCCK and arithmetic JPEG | PENDENTE |
| GAP-102 | WebP VP8/VP8L/animation decoder | PENDENTE |
| GAP-103 | AVIF/HEIF/AV1 image decoder | PENDENTE |
| GAP-104 | SVG XML/style/path rasterization | PENDENTE |
| GAP-105 | Canvas 2D state, paths, text and images | PENDENTE |
| GAP-106 | WebGL 1/2 and GPU resource model | PENDENTE |
| GAP-107 | WebGPU | PENDENTE |
| GAP-108 | Image decoding workers and async decode | PENDENTE |

### Audio/video engine and playback

| ID | Capacidade / lacuna | Estado em 3.4.0 |
|---|---|---|
| GAP-109 | WAV PCM U8/S16LE sample decoder | IMPLEMENTADO (decoder primitive) |
| GAP-110 | AVI uncompressed BI_RGB frame extraction | IMPLEMENTADO (demux/decode primitive) |
| GAP-111 | MP4 complete sample-table demux (stts/stsc/stsz/stco/co64) | PENDENTE |
| GAP-112 | H.264/AVC software decoder | PENDENTE |
| GAP-113 | HEVC/H.265 software decoder | PENDENTE |
| GAP-114 | VP8/VP9 software decoder | PENDENTE |
| GAP-115 | AV1 software decoder | PENDENTE |
| GAP-116 | AAC-LC/HE-AAC sample decoder | PENDENTE |
| GAP-117 | MP3 Layer III sample decoder | PENDENTE |
| GAP-118 | Vorbis/Opus/FLAC compressed audio decoders | PENDENTE |
| GAP-119 | Xbox audio output device integration | PENDENTE |
| GAP-120 | Video frame presentation and audio-master clock sync | PENDENTE |
| GAP-121 | Frame queue, pacing and late-frame dropping | PENDENTE |
| GAP-122 | Native HTMLMediaElement play/pause/seek UI | PENDENTE |
| GAP-123 | Progressive HTTP media streaming with range requests | PARCIAL |
| GAP-124 | HLS live playlist refresh/adaptation | PENDENTE |
| GAP-125 | HLS AES-128 decryption and key lifecycle | PENDENTE |
| GAP-126 | MPEG-DASH manifest and segment pipeline | PENDENTE |
| GAP-127 | WebVTT cue parsing and subtitle overlay | PENDENTE |
| GAP-128 | Closed captions and subtitle track selection | PENDENTE |
| GAP-129 | Media Source Extensions | PENDENTE |
| GAP-130 | Encrypted Media Extensions/DRM | PENDENTE |
| GAP-131 | Hardware video decode or Xbox GPU-assisted decode | PENDENTE |

### Network, origins and security

| ID | Capacidade / lacuna | Estado em 3.4.0 |
|---|---|---|
| GAP-132 | First-party TCP socket abstraction for Xbox | PENDENTE |
| GAP-133 | First-party HTTP/1.1 request/response engine | PENDENTE |
| GAP-134 | First-party TLS 1.2/1.3 protocol and audited cryptography | PENDENTE |
| GAP-135 | Owned CA store/update pipeline | PENDENTE |
| GAP-136 | HTTP/2 multiplexing | PENDENTE |
| GAP-137 | HTTP/3/QUIC | PENDENTE |
| GAP-138 | Brotli content decoding | PENDENTE |
| GAP-139 | Cookie jar with SameSite/Secure/HttpOnly rules | PENDENTE |
| GAP-140 | Same-origin policy coverage across APIs | PENDENTE |
| GAP-141 | CORS preflight/credentials/opaque responses | PENDENTE |
| GAP-142 | Content Security Policy enforcement | PENDENTE |
| GAP-143 | Redirect policy and HTTPS downgrade protection across all resources | PARCIAL |
| GAP-144 | ETag/Last-Modified revalidation cache | PENDENTE |
| GAP-145 | Disk cache eviction and quota manager | PENDENTE |
| GAP-146 | DNS cache and connection pool | PENDENTE |
| GAP-147 | WebSocket protocol stack | PENDENTE |
| GAP-148 | WebRTC/media capture | PENDENTE |

### Browser integration and developer validation

| ID | Capacidade / lacuna | Estado em 3.4.0 |
|---|---|---|
| GAP-149 | Tabbed browsing with independent page contexts | PENDENTE |
| GAP-150 | Download manager and resumable downloads | PENDENTE |
| GAP-151 | Private session / ephemeral storage | PENDENTE |
| GAP-152 | Crash recovery and per-page failure isolation | PENDENTE |
| GAP-153 | Per-origin memory and execution quotas | PARCIAL |
| GAP-154 | Controller focus navigation for complex widgets | PARCIAL |
| GAP-155 | Zoom/reflow and device scale control | PENDENTE |
| GAP-156 | Full keyboard mapping and text-entry UI | PENDENTE |
| GAP-157 | Developer tools/console/network inspector | PENDENTE |
| GAP-158 | Remote debugging protocol | PENDENTE |
| GAP-159 | Golden screenshot comparison suite | PENDENTE |
| GAP-160 | Web Platform Tests selected-test runner | PENDENTE |
| GAP-161 | Fuzzing for HTML/CSS/JS/media parsers | PENDENTE |
| GAP-162 | Long-running leak/performance tests on real console | PENDENTE |
| GAP-163 | PowerPC/xSDK cross-build reproducibility verified | PENDENTE |
| GAP-164 | Physical Xbox 360 boot/network/media smoke tests | PENDENTE |

## Como ler esta lista

- O inventário é uma lista de engenharia: cada item precisa de implementação, testes direcionados, análise de memória e validação no Xbox quando aplicável.
- Um decoder que gera pixels/frames não significa que a página tenha controle de reprodução HTML5, sincronização ou áudio no hardware.
- A decodificação JPEG baseline de 3.4.0 não cobre JPEG progressivo; PNG não cobre Adam7; GIF não anima; MP3/AAC são analisados por cabeçalho, não decodificados.
- A rede ainda depende de libcurl e Mbed TLS. Não substituí criptografia com uma implementação caseira não auditada, pois isso prejudicaria a segurança HTTPS.
- O runtime XenonScript ainda não é ECMAScript completo. Chromium, WebKit e NetSurf não são o motor principal; o adapter NetSurf continua stub.
- Nenhum XEX foi compilado nem testado em console nesta entrega.

**Total inventariado: 164 itens.** Este número inclui capacidades parciais já presentes e pendências futuras; não significa que 164 funcionalidades foram implementadas nesta versão.
