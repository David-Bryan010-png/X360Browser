# X360Browser 5.1.0 — compatibilidade e validação

## Implementado no código-fonte

- A superfície do renderizador muda de 1152×384 para 1152×500 e passa a iniciar na coordenada Y=126; isso fornece 116 px adicionais à página renderizada.
- A faixa superior tem título, URL e status compactos; o fundo externo usa cinza-escuro neutro. Não existe ainda barra HTML com todos os controles de navegadores desktop.
- RS ativa o cursor de controle na vista visual; D-pad move a posição; A faz hit-test contra links e retângulos de controles visíveis. Links abrem a URL. `input` e `textarea` abrem o teclado virtual do Xbox e atualizam o DOM; `button` e outros controles podem executar um atributo `onclick` limitado. Ainda não há seletor nativo de opções, eventos `change` completos, validação nativa ou submissão tradicional de formulários. A também abre o teclado de endereço quando o cursor está na faixa URL.
- O cliente de atualização só aceita endpoint HTTPS, manifesto limitado e versão `x.y.z`. A URL do XEX precisa ser HTTPS; o tamanho máximo de download é 64 MiB; o hash é verificado com Mbed TLS. A troca mantém cópia anterior e tenta rollback se a segunda renomeação falhar.
- `vercel/api/update.js` consulta a última release estável do repositório de código e extrai versão, URL do `.xex` e SHA-256 dos assets.
- O workflow publica binário e checksum quando executado num push de tag `v*` cuja fonte passa pelos testes/build.

## O que exige configuração e teste real

- A URL Vercel não pode ser presumida: cada usuário/projeto recebe seu próprio domínio. A configuração incluída está desabilitada até preencher `X360Browser-update-config.txt`.
- O endpoint requer uma GitHub Release estável com assets exatamente chamados `X360Browser.xex` e `X360Browser.xex.sha256`. Antes disso responde 503, sem uma atualização falsa.
- A troca de um XEX que está sendo executado pode ser recusada pelo filesystem ou loader do console. Nesse caso o instalador deixa `X360Browser.update.xex`; não afirma ter aplicado o binário. Mesmo quando a troca funciona, a nova versão só é executada ao abrir o app novamente.
- Requer versão de libcurl com `CURLOPT_PROTOCOLS_STR`, bundle `cacert.pem` e suporte ao Mbed TLS usado na compilação.

## Limitações do motor

Isto não é Chromium nem WebKit; a atualização não transforma XenonScript em ECMAScript completo. XenonScript não implementa ECMAScript completo; Canvas 2D, WebGL, WebAssembly, workers, módulos/promises completos, APIs modernas, DRM e a maioria dos jogos web atuais permanecem não implementados e sem compatibilidade garantida. YouTube continua em caminho experimental de resolução de MP4/player externo, não vídeo HTML5 interno.

## O que os testes significam

Os testes de host e validação de pacote conseguem verificar arquivos, engine, contratos do renderer e workflow; não provam que o Vercel esteja implantado, que a release publicada existe, que o XEX PowerPC compile nessa revisão, nem que a operação de troca funcione em um Xbox 360 físico.
