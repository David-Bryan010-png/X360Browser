# X360Browser 4.2.0 — compatibilidade real

## Mudanças desta versão

- A validação de porta rejeita valores longos antes de multiplicar/acumular, evitando overflow inteiro.
- URLs HTTP/HTTPS com escapes percentuais incompletos ou não hexadecimais são rejeitadas; escapes válidos como `%2F` e `%20` são preservados.
- Foram adicionados testes de regressão para as duas classes de falha.
- Permanecem as melhorias 4.0.0: parser e validação experimental de streams do YouTube, detecção de assinatura MP4 antes do handoff, atributos lazy-load de imagem, compressão HTTP negociada e limites defensivos de documentos/scripts.

## Limitações que continuam

- Não é Chromium e não transforma XenonScript em ECMAScript completo; XenonScript não implementa ECMAScript moderno completo.
- O caminho de vídeo do YouTube continua experimental, depende de instâncias públicas de terceiros e entrega o arquivo a um player externo configurado. Encontrar/baixar um MP4 não prova que o Xbox 360 consiga decodificá-lo e exibi-lo.
- Não há promessa de reprodução nativa de H.264/AAC nem de sincronização audiovisual completa.
- Timers completos, APIs modernas de navegador e módulos ES continuam não implementados. Jogos modernos do Poki continuam sem compatibilidade garantida: faltam APIs completas de JavaScript, Canvas 2D/WebGL, WebAssembly, timers/event-loop e APIs web modernas.
- A compilação PowerPC/XEX e o teste físico no Xbox 360 RGH ainda precisam ser feitos separadamente. Os testes de host não substituem essa validação.


## Correção de renderização 4.2.0

A 4.2.0 corrige o contrato de entradas GLSL do xSDK no shader principal: localização 0 é POSITION, localização 1 é COLOR e localização 2 é TEXCOORD0. A coordenada de textura da página agora usa a localização 2, evitando a falha `vertex layout lacks an input the shader fetches` observada no log do console. O renderizador passa a registrar separadamente falhas de carregamento dos shaders, de layout de vértices e de alocação de textura.

O build agora disponibiliza `X360Browser-video-config.txt` e um `X360Browser-bookmarks.txt` vazio ao lado do XEX. A configuração mantém o player externo desativado por padrão. A correção de shader ainda precisa ser confirmada em execução no Xbox 360 físico; os testes de host verificam o contrato de fonte, não substituem o teste de GPU no console.
