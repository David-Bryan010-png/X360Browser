# X360Browser 5.0.0 — matriz de compatibilidade real

## Confirmado por código nesta release

- Identidade 5.0.0 sincronizada em VERSION, cabeçalho de versão, CMake, UI, logs e workflow.
- XenonWeb mantém o renderizador próprio de HTML/CSS; XenonScript executa um subconjunto limitado de JavaScript inline/eventos e helpers comuns de strings; XenonMedia mantém decodificação/parsing com limites explícitos.
- Renderização visual utiliza `WebVisualFrame` estático/cacheado, em vez de criar a grande estrutura local na pilha em cada quadro.
- O hash de conteúdo e a verificação de arquivos de imagem ficam em cache até invalidação; o hash de scroll é composto sem percorrer novamente o HTML inteiro em quadros estáticos.
- A navegação e o despacho de ações DOM invalidam layout/superfície para evitar exibição de conteúdo antigo.
- A rota de falha de layout chama diretamente o renderizador legado, sem reentrar desnecessariamente na mesma função de layout.
- Busca por endereço com DuckDuckGo como padrão e prefixos opcionais `!g `, `!b ` e `!d `.
- XenonScript acrescenta `length`, `trim`, conversão de caixa ASCII, busca, teste de prefixo/sufixo e recortes de string, cobertos por teste de host.
- Diagnósticos de erro de YouTube, mídia, HTTP e carregamento passam a usar a cor de erro da interface.
- O modo `stream-url` resolve links comuns de vídeo do YouTube para uma URL MP4 antes do handoff, em worker de rede, evitando bloquear o loop do controle durante a busca.
- `auto` tenta localizar FFPlay.xex em caminhos locais comuns; caminho explícito e `disabled` continuam disponíveis.
- O fluxo de download verifica que o resultado de um stream YouTube tem assinatura MP4 e descarta arquivo incompatível.

## Limites que continuam reais

- **Isto não é Chromium nem WebKit.** não transforma XenonScript em ECMAScript completo; há limites de sintaxe, APIs, orçamento e execução.
- Canvas 2D, WebGL, WebAssembly, workers, módulos, Promises/event loop modernos, timers reais e muitas Web APIs continuam não implementados.
- A página normal do YouTube depende intensamente de JavaScript moderno e pode aparecer incompleta. A reprodução de vídeo é um caminho separado de resolução MP4 e player externo, não um `<video>` HTML5 interno.
- O resolvedor consulta instâncias públicas de Invidious, que podem estar indisponíveis ou impor limites. A lista oficial atual dessas instâncias é curta e pode mudar: https://docs.invidious.io/instances/.
- Não há garantia de H.264/AAC, DASH, HLS ao vivo/encriptado, DRM, todos os vídeos, áudio/vídeo sincronizados, legendas sincronizadas, ou jogos modernos do Poki.
- O player FFPlay não é fornecido com o X360Browser. A detecção automática procura o XEX, mas não consegue instalar nem reparar um player ausente.
- Testes host e build CI não substituem execução e validação num Xbox 360 RGH/JTAG real.

## Checklist físico recomendado

1. Abrir `X360Browser.xex` junto com `cacert.pem`, arquivo de configuração e diretório de escrita permitido.
2. Confirmar que páginas comuns iniciam em vista visual, que rolagem não fica presa e que D-pad pode mover o foco de links.
3. Testar Google, Bing, DuckDuckGo e buscas longas com caracteres codificados.
4. Testar um link YouTube público que ofereça MP4 muxado compatível em modo `download`.
5. Testar `stream-url` com um FFPlay XEX que comprovadamente suporte HTTPS e o codec retornado.
6. Gravar o log e o status de tela para falhas de TLS, player ou instância pública; não declarar sucesso sem observar áudio e vídeo.
