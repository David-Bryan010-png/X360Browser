# Auditoria da fonte 4.0.0

Transformação local aplicada sobre o ZIP corrigido 3.6.0 obtido do artefato oficial do workflow do repositório.

- [x] version
- [x] script_source_64k
- [x] script_30k_tokens
- [x] youtube_resolver
- [x] youtube_url_dispatch
- [x] texture_fallback
- [x] cache_reload_invalidation
- [x] docs

## Não declarado como pronto

- Build do XEX PowerPC após estas alterações.
- Teste no hardware Xbox 360.
- Reprodução interna completa do YouTube.
- Compatibilidade geral com jogos modernos do Poki.


## Correções adicionais da revisão 4.0.0

- Portas de URLs YouTube agora são validadas numericamente; portas vazias, textos e valores acima de 65535 são recusados. Para os streams resolvidos, só é permitido TLS pela porta padrão 443.
- A identificação de vídeo ignora fragmentos na query de `watch`.
- O parser da resposta de instância Invidious exige JSON externo completo e fechamento do array `formatStreams`.
- O download resolvido deve conter uma caixa MP4 `ftyp` válida e dentro do tamanho do arquivo antes de ser considerado concluído.
- Foram adicionados testes para portas inválidas, links com fragmentos, JSON truncado, URL de stream com porta não padrão e assinatura MP4.
