# X360Browser 7.0.0 — compatibilidade e limites

## Implementado nesta versão

- Quebra de palavras longas em segmentos limitados à largura disponível do bloco/viewport.
- Cores CSS hexadecimais `#RGB`, `#RGBA`, `#RRGGBB` e `#RRGGBBAA`, com validação de dígitos e conversão para ARGB no frame visual.
- Palavras-chave de cor CSS adicionais: `aliceblue`, `antiquewhite`, `beige`, `coral`, `crimson`, `darkblue`, `darkgreen`, `gold`, `hotpink`, `khaki`, `lightblue`, `lightgreen`, `darkslategray`/`darkslategrey`, `steelblue`, `tomato` e `whitesmoke`.
- Os botões HTML mostram seu rótulo interno uma única vez; o texto inicial do `textarea` aparece dentro do controle; `select` mostra o rótulo da opção selecionada ou, na ausência dela, da primeira opção.
- `input type=hidden` permanece invisível, e os controles continuam registrados em retângulos de hit-test para controle pelo gamepad.
- XenonScript inclui `<math.h>` explicitamente para `isfinite`/`isnan`, e uma instrução `while` é reavaliada no limite; loops finitos que encerram na última iteração permitida funcionam, e loops que continuam verdadeiros falham de forma explícita.
- O marcador de imagem não carregada volta a ser um placeholder gráfico legível `[Image: alt]`.

## Limitações que permanecem

- XenonWeb não implementa o padrão HTML completo nem a cascata/box model completos de CSS.
- Medidas de texto ainda são estimativas baseadas em bytes/tamanho de fonte, não métricas reais de uma fonte web completa.
- `float`, `position`, flexbox/grid, tabelas, pseudoelementos e eventos continuam em subconjuntos limitados.
- XenonScript não é ECMAScript completo e não oferece todas as APIs de navegador modernas, event loop, workers, WebAssembly ou um motor WebGL.
- O parser de cores acrescenta formas hexadecimais e nomes específicos, mas não representa todas as funções/cores definidas pelo CSS Color 4.
- Os testes de host não substituem o cross-build PowerPC nem o teste no Xbox 360 real.

## Resultado esperado

O objetivo desta versão é reduzir os defeitos visuais concretos (palavras que saíam dos limites, controles com texto duplicado ou externo e cores alpha não reconhecidas) sem alterar o nome canônico do executável, `default.xex`.
