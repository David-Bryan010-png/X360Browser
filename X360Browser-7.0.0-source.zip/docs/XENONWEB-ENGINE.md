# XenonWeb — integração do renderizador na versão 4.0.0

A renderização do Xbox tenta primeiro `xw_layout_page()` para gerar a saída baseada no DOM/CSS/XenonScript e usa o renderizador legado VisualLite como fallback quando o caminho novo não consegue layout. A 4.0.0 amplia os limites fixos de DOM, folhas CSS, propriedades personalizadas, nós de layout e registros visuais, além de melhorar a invalidação da cache raster e o fallback da textura gráfica.

O motor continua limitado: não é uma implementação completa do HTML Living Standard, CSS ou ECMAScript. CSS Grid/flexbox e seletores são subconjuntos; iframes podem ser abertos como navegação de topo, mas não se tornam contextos aninhados completos. Canvas 2D/WebGL, WebAssembly, workers, timers/event-loop, módulos ES e muitas APIs de navegadores modernos não estão implementados.

Para o estado atual de mídia e sites, consulte `COMPATIBILITY-4.0.0.md`; `COMPATIBILITY-3.6.0-web-compatibility-preview.md` é histórico.
