# Auditoria do motor gráfico — X360Browser 5.2.0

## Caminho atual de renderização

1. A camada de rede coleta HTML e recursos acessíveis por libcurl/Mbed TLS.
2. XenonWeb cria uma árvore DOM limitada e calcula estilos computados com as regras CSS implementadas.
3. O layout produz caixas de elementos, texto, imagens e suas coordenadas.
4. O renderizador prepara/desenha a superfície gráfica e a compõe no Xenos/xSDK. O texto é desenhado sobre a superfície; a página não deve ser confundida com um leitor de texto puro.
5. O hit-test mapeia o cursor controlado pelo gamepad para links e controles desenhados.

## Melhorias 5.2.0

- Superfície de página de 1280×544; posição de desenho alinhada a x=0 e y=112 no layout de UI 720p.
- Suporte a imagens `background-image` e URLs presentes em folhas CSS externas.
- Imagens HTML priorizadas antes de fundos CSS para reduzir a possibilidade de decorações ocuparem os limites de pré-carregamento antes do conteúdo.
- Separação entre ajuste de imagens de conteúdo (preserva proporção) e fundos CSS (podem preencher a caixa).
- Atualizador consulta o GitHub diretamente, sem servidor Vercel.

## O que ainda falta para equivaler a um navegador de desktop

O motor atual não tem engine JavaScript completa nem implementação abrangente de padrões web. CSS moderno, formulários complexos, SVG, Canvas/WebGL, WebAssembly, iframe ativo, APIs web recentes e codecs modernos não são garantidos. O YouTube ainda depende de resolver uma URL MP4 e de um player compatível externo. O cursor não é um ponteiro de mouse USB nativo; é controlado pelo gamepad.

## Como validar a mudança

- Rodar `tests/run_host_tests.py` e os validadores de contrato.
- Compilar pelo workflow com o toolchain Xbox 360 correto.
- Testar páginas de referência no console real: HTML/CSS estático, imagem `<img>`, imagem de fundo CSS, input/button, scroll, redirecionamento HTTPS e comportamento de falha de atualização.
- Só anunciar a atualização automática como operacional depois de confirmar rede TLS, API GitHub, validação SHA-256, staging/rollback e reinício/loader no Xbox físico.
