# X360Browser — mídia e limites de reprodução

## 5.0.0 — correção do handoff de YouTube

No modo `stream-url`, o navegador agora reconhece um watch URL do YouTube, resolve uma URL MP4 compatível em um worker de rede e só então abre o player. Isso evita mandar `youtube.com/watch?...` diretamente para FFPlay e evita fazer a consulta de instância dentro do loop de entrada/controlador. O modo `download` continua resolvendo e baixando o arquivo antes de iniciar o player.

O valor `auto` na primeira linha da configuração procura `FFPlay.xex` em locais comuns. Se não encontrar o executável, reprodução fica indisponível e a tela informa que o player precisa ser instalado/configurado. O XEX FFPlay não é incluído no pacote. Uma configuração já presente no console que diga `disabled` continua desativando o player — altere para `auto` ou informe o caminho do player.

A otimização da 5.0.0 cacheia a estrutura visual e o hash do HTML entre quadros, reduzindo custo de CPU e stack no renderer. Isso melhora a responsividade de páginas estáticas, mas não elimina o custo do download, o tempo de resolver vídeo nem os limites do Xbox e do codec.


## O que a versão realmente acrescenta

XenonMedia continua oferecendo decodificadores limitados para BMP, QOI, PPM, alguns perfis de PNG/GIF/JPEG, WAV PCM/IMA ADPCM e parsers de AVI/MP4/MP3/AAC/TS/HLS, além de primitivas de sessão e WebVTT. O download de mídia continua limitado e não é, por si só, um player integrado. These components are not yet an integrated in-browser media playback pipeline.

A 4.0.0 reconhece links do YouTube em formatos comuns (`watch`, `youtu.be`, `shorts`, `embed`, `live`) e tenta consultar instâncias públicas do Invidious para encontrar um stream MP4 muxado até 480p. A escolha do stream tem limites de tamanho/tempo, validação TLS e restrição ao domínio `googlevideo.com`; redirecionamentos da URL resolvida aceitam apenas HTTPS. É uma rota experimental baseada em serviço de terceiros, por isso pode falhar por indisponibilidade, restrição geográfica, vídeo privado/live, política da instância ou falta de stream MP4 compatível.

## YouTube não é reprodução interna

O player HTML5 do YouTube não é executado dentro do X360Browser. O player externo é fornecido pelo usuário: a configuração `auto` procura um XEX compatível em caminhos comuns; se não encontrar, a reprodução fica desativada até o usuário instalar ou configurar o player. Isso não é um pipeline de reprodução nativo, não garante áudio/vídeo sincronizados e não suporta todos os vídeos.

A API pública consultada é documentada por instâncias Invidious, mas as instâncias são serviço de terceiros e sua disponibilidade muda. Não são usadas chaves privadas nem tentativa de contornar DRM; vídeos DRM/privados não são reivindicados como suportados.

## Poki e jogos web

Não é declarada compatibilidade geral com Poki. XenonScript continua sendo um subconjunto JavaScript limitado, sem ECMAScript completo, event loop/Promises/módulos completos, Canvas 2D/WebGL, WebAssembly ou workers. Muitos jogos atuais não iniciam ou falham no primeiro recurso que exige essas APIs. Aumentar os limites do parser permite páginas maiores, mas não substitui essas APIs.

## Primitivas internas e lacunas

Os decodificadores e parsers de XenonMedia são testados isoladamente, mas o Xbox não tem nesta versão o pipeline completo de saída de áudio PCM, apresentação de quadros com relógio sincronizado, demux MP4 completo, codecs modernos H.264/AAC/VP9/AV1, HLS adaptativo/live, sobreposição (subtitle overlay) de legendas sincronizadas nem um `HTMLMediaElement` compatível com páginas modernas.

O arquivo de exemplo usa `auto`: o browser procura um FFPlay.xex em caminhos comuns e deixa a reprodução indisponível apenas se o player não for encontrado. Um retorno de sucesso do launch externo não é prova de reprodução correta. O build PowerPC/XSDK e o teste em hardware ainda são necessários.
