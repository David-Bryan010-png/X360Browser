# X360Browser 3.5.0 — native web/media milestone

## What is first-party

- **XenonWeb** owns the bounded HTML/DOM/CSS/layout path, including viewport-aware media-query subsets, selected Flexbox/Grid behavior, and root CSS variables with `var()` fallback.
- **XenonScript** owns a bounded experimental script interpreter; it is not full ECMAScript/modern JavaScript.
- **XenonMedia** owns the listed raster decoders and media parsing/decoding primitives, including BMP, QOI, PPM, selected PNG/GIF/JPEG profiles, WAV PCM U8/S16LE and Microsoft IMA ADPCM -> PCM16, raw AVI frame extraction and WebVTT cue parsing.
- The NetSurf stub was removed from the active build. No Chromium/WebKit/NetSurf browser engine, `stb_image`, or external media player is used as the primary engine. External-player handoff remains opt-in and disabled by default.

## New in 3.5.0

- CSS root-level custom properties `--name`, `var(--name)`, nested values and fallback values, with bounded names, values and recursion. This is **partial**: custom-property scope per element, inheritance, computed-style CSSOM and full tokenization are not implemented.
- WAV Microsoft IMA ADPCM parsing and decoding for validated mono/stereo blocks to interleaved PCM16. The player/audio-device path is not yet connected.
- WebVTT bounded cue parsing, multiline cue text slices, and lookup of the active cue for a timestamp. Subtitle drawing/synchronization is not yet wired into the renderer.
- Page-engine dispatch now uses only the project-owned XenonWeb/native path; a nonfunctional NetSurf adapter was removed instead of being advertised as a fallback.

## External support dependencies

The browser/page/media engines above are first-party code. HTTP/HTTPS transport and certificate validation still use libcurl and Mbed TLS with a CA bundle; the PowerPC build and console APIs use the xSDK/toolchain. These are supporting transport/security/platform dependencies, **not** alternative browser engines. A home-grown unaudited TLS implementation would be unsafe and is not claimed.

## Still incomplete

There is no full WHATWG HTML tree builder, standards-complete CSS engine, modern JavaScript runtime, Canvas/WebGL/WebAssembly, full MP4 sample-table demux, H.264/HEVC/VP9/AV1 video decoder, compressed MP3/AAC/Opus decoder, Xbox audio-device integration, subtitle overlay, A/V sync, or complete `HTMLMediaElement`. YouTube watch pages and modern web games are not claimed compatible.

## Validation boundary

Host tests and CMake/CTest validate portable logic only. The PowerPC/xSDK cross-build and physical Xbox 360 execution have not been performed for 3.5.0. See `ENGINE-GAP-AUDIT-3.5.0.md` for the 164-item inventory and status of all major gaps.
