# X360Browser 5.0.0 — mudanças implementadas

## Performance/estabilidade

- A estrutura `WebVisualFrame` agora é residente no estado do renderizador, não na pilha do caminho de desenho.
- O HTML e os metadados de imagem são hashados uma vez por invalidação; quadros estáticos reutilizam layout e hash.
- O cálculo do hash para diferentes offsets de scroll reutiliza a base já computada.
- A chamada de fallback não reexecuta a rota DOM/CSS que falhou; chama o renderer legado diretamente.
- O renderizador expõe `web_visual_renderer_invalidate()` e a navegação a chama ao trocar a página; mutações de DOM também invalidam o cache.

## Navegação/pesquisa/controles/UI

- Versão e rótulos 5.0.0 sincronizados no binário, logs, workflow e interface.
- UI inicial apresenta os controles essenciais e descreve explicitamente as capacidades e limitações de mídia.
- Pesquisa normal continua em DuckDuckGo; `!g ` seleciona Google, `!b ` seleciona Bing e `!d ` força DuckDuckGo.
- D-pad left/right é documentado como foco de links na vista visual; cima/baixo rola ou seleciona listas e LB/RB rola em blocos.

## YouTube/mídia

- `web_engine_resolve_youtube_stream()` foi exposto para integração com o launcher.
- O modo `stream-url` passa a resolver watch/shorts/embed/live antes de iniciar FFPlay. O resolvedor roda em worker de rede, não no loop do controlador.
- A detecção opcional de player `auto` tenta `game:\FFPlay.xex`, variantes de caixa e subdiretório `game:\Apps\FFPlay`.
- Se a detecção falha, o navegador fornece instrução explícita para fornecer FFPlay.xex ou configurar o caminho; `disabled` continua funcionando como desligamento explícito.
- A verificação do MP4 e os limites de rede/codec existentes continuam ativos.

## O que não foi alegado

Esta release não afirma implementar 500 novos recursos independentes, ECMAScript completo, Chromium, video playback HTML5 interno, suporte garantido a jogos atuais, nem validar um XEX em hardware físico. O workflow fornece a etapa de compilação do console; o resultado precisa ser produzido e testado no GitHub Actions e no Xbox do usuário.
