# Atualização automática GitHub — X360Browser 6.2.0

## Contrato de publicação

A release é gerada somente depois que validação, testes host e cross-build do xSDK passam numa branch configurada (`main`, `master` ou `principal`). O nome de artefato executável é `default.xex`. Também são publicados `default.xex.sha256`, `X360Browser-6.2.0-Xbox360.zip` e checksum do ZIP.

O repositório precisa ser público porque o console consulta `https://api.github.com/repos/David-Bryan010-png/X360Browser/releases/latest` sem token de usuário. O workflow usa `GITHUB_TOKEN` com `contents: write`; não é necessário Vercel ou segredo manual.

## Cliente no console

1. Lê a última release estável da API GitHub por HTTPS com verificação de certificado.
2. Confere a versão semântica e só considera o asset exato `default.xex` do caminho de Releases deste repositório.
3. Lê digest SHA-256 da API ou baixa `default.xex.sha256`.
4. Baixa o XEX com limite máximo de 64 MiB, calcula SHA-256 local por Mbed TLS e rejeita qualquer divergência.
5. Tenta substituir `game:\default.xex` com backup/rollback.
6. Se o arquivo ativo estiver bloqueado, mantém a cópia verificada `game:\default.update.xex`; o usuário deve sair do navegador e aplicar a atualização.

## Publicação a partir do celular

1. Coloque `X360Browser-6.2.0-source.zip` na raiz do repositório.
2. Substitua `.github/workflows/build-xex-from-zip.yml` pelo workflow `build-xex-from-zip-6.2.0.yml`.
3. Faça commit numa branch configurada e observe Actions até validar e compilar.
4. Confirme em Releases que existe `v6.2.0` e que o arquivo se chama exatamente `default.xex`.
5. Instale essa versão manualmente uma vez; a versão que procura assets antigos não pode usar o novo contrato de nomes.

Nunca reutilize uma tag publicada para binários diferentes. Aumente `VERSION` e `include/x360browser/version.hpp` antes de uma nova versão.


### Dependências do workflow

As actions de checkout, upload/download de artefatos e publicação de releases usam versões específicas no YAML para evitar depender de uma tag móvel. Atualize essas versões deliberadamente junto com uma revisão e execução de teste do workflow.
