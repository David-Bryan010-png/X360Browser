# Source changes — 6.0.0

- Removed `g_show_reader` and the text-reader body branch from `main.c`.
- The view cycle is graphical page -> links -> resources -> graphical page.
- HTML responses select the visual page even if graphics failed to initialize; the draw routine shows a visible renderer error instead of rendering `page->text`.
- Direct resources get a resource card, not the text-reader path.
- Network failures get an error surface while address/reload/home controls remain available.
- `web_visual_renderer_invalidate()` is called after response assignment under the page-state lock.
- Added static regression coverage to prevent the old reader labels and text-dump call from reappearing.
