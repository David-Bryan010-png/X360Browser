# Compatibilidade — X360Browser 6.2.0

## Alterações verificáveis

- A distribuição usa `default.xex` como nome único do executável do Xbox 360. O target interno do CMake ainda pode aparecer como `X360Browser` durante a compilação, mas a saída empacotada e o asset da Release são `default.xex`.
- O cliente de update consulta a última GitHub Release pública, aceita exclusivamente assets do caminho oficial deste repositório, exige HTTPS/TLS validado e confere SHA-256.
- XenonNet resolve URLs HTTP relativas, caminhos `./` e `../`, query-only e URLs scheme-relative; o resolver é limitado a buffers fixos e esquemas HTTP/HTTPS.
- Versões de release devem estar no formato estrito `MAJOR.MINOR.PATCH`, sem zeros à esquerda (exceto o próprio zero), sufixo ou overflow.

## Compatibilidade parcial declarada

XenonWeb não é Chromium, WebKit ou NetSurf. Seu tokenizer/DOM, subconjunto CSS, layout gráfico, execução XenonScript, interação com formulários e decodificadores XenonMedia são implementações próprias, limitadas e sujeitas a diferenças dos navegadores completos.

Não há garantia de execução correta para React/Vue/Angular atuais, módulos JS completos, promises/event-loop completo, Canvas, WebGL, WebAssembly, Service Workers, WebRTC, iframes com contexto próprio, DRM, jogos web complexos ou codecs modernos. YouTube continua experimental e pode exigir resolução externa e um player compatível. Decodificar metadados de MP4 não equivale a decodificar todos os frames de H.264/AAC.

## Atualização

A publicação automática exige que a compilação cruzada para Xbox 360 passe. O console precisa acessar a API pública do GitHub. A aplicação verifica o asset e seu hash; isso não torna possível substituir qualquer executável em execução em todos os sistemas de arquivos/launchers. Se a troca for bloqueada, `default.update.xex` precisa ser aplicada após sair do programa.

## Validação necessária

Host tests e análise estática não comprovam funcionamento em hardware. A release só deve ser chamada de testada no Xbox depois de instalar `default.xex` num RGH/JTAG real, navegar para páginas de controle e inspecionar `game:\default.log`.
