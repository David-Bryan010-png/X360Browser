# X360Browser 4.0.0 — mudanças de código

Esta árvore foi construída sobre o artefato corrigido da fonte 3.6.0 gerado pela execução mais recente do workflow do repositório em 2026-10-27. O objetivo do marco 4.0.0 é ampliar a compatibilidade prática sem declarar um motor Chromium/WHATWG que o projeto não possui.

## Alterações do motor

- Aumenta limites explícitos de DOM, atributos, string pool, CSS, propriedades customizadas, XenonScript, profundidade de layout e records visuais.
- Negocia a compressão HTTP disponível na build de libcurl para HTML, CSS e JavaScript, mantendo os tetos dos corpos já descomprimidos.
- Busca até quatro scripts externos pequenos em vez de dois, com teto de 16 KiB por script e 32 KiB no total; continuam ativos limites de MIME, TLS, tamanho e tempo.
- Atualiza User-Agent e metadados para 4.0.0.
- A cache raster valida tamanho e mtime antes de reutilizar a imagem; a criação da textura tenta tiled e, se falhar, linear.
- Reconhece links YouTube em formatos comuns e tenta obter um stream MP4 muxado até 480p via `formatStreams` de instâncias públicas Invidious. A resposta JSON é limitada, certificados são verificados, URLs de stream são restringidas a `googlevideo.com` e o redirect desse fluxo só aceita HTTPS.
- Adiciona testes de reconhecimento URL e seleção do stream, incluindo host falso, codecs AV1-only e escape JSON `\\u0026`.
- Atualiza workflow, documento de compatibilidade, instruções de build e notas de mídia para refletir o código de verdade.

## Não implementado nesta versão

- Não há V8/ECMAScript completo, Canvas 2D/WebGL, WebAssembly, workers, event loop moderno ou iframe de contexto completo.
- A resolução do YouTube é experimental, usa serviços públicos de terceiros e requer player externo configurado; não é reprodução HTML5 interna.
- Não existe compatibilidade geral garantida com jogos atuais do Poki.
- XEX PowerPC e execução no console precisam ser testados separadamente.

## Testes reproduzíveis

- `python3 tests/validate_project_integrity.py`
- `python3 tests/run_host_tests.py`
- `cmake -S . -B build -DCMAKE_BUILD_TYPE=Release -DX360BROWSER_BUILD_TESTS=ON -DX360BROWSER_BUILD_DEMO=ON -DBUILD_TESTING=ON`
- `cmake --build build --parallel 2`
- `ctest --test-dir build --output-on-failure`
- `bash -n tools/build_xbox_shell.sh`

Consulte `TEST-RESULTS.txt` para o resultado mais recente e as verificações que ainda faltam.
