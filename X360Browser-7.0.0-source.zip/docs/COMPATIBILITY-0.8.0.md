# Compatibility matrix — 0.8.0

Historical reference only. X360Browser 0.8.0 uses a static VisualLite renderer with partial HTML/CSS and PNG-only image decoding. See `COMPATIBILITY-2.3.0-release-hardening.md` for current development support and limitations.
