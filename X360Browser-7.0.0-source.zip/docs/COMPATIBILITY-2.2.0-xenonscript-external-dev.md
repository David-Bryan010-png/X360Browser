# X360Browser 2.2.0-xenonscript-external-dev — compatibility matrix

This is an experimental, source-only development build until the PowerPC/xSDK workflow succeeds and the resulting `.xex` is tested on a physical Xbox 360. Host tests are not proof of console boot or rendering behaviour.

| Capability | Status in this version | Boundary |
|---|---|---|
| Navigation via HTTP/HTTPS | Implemented in NativePlus transport | Transport/HTML inventory are bounded; TLS requires `cacert.pem` beside the XEX. |
| HTML DOM / CSS / visual layout | Partial, first-party XenonWeb | Limited parser, selector set, styles and frame capacity; VisualLite is fallback. |
| External stylesheets | Partial | Small CSS sheets are fetched under byte/time caps and appended to the page for the CSS subset. |
| Inline JavaScript-like code | Partial, first-party XenonScript | Variables, expressions, `if/else`, selected DOM queries/mutations and instruction budget only. |
| External scripts | Experimental, tightly bounded | At most two synchronous scripts per page, 4 KiB each, recognized JavaScript MIME; inserted at source position and run in document order after the DOM parse. This is not parser-blocking JavaScript semantics. `async`, `defer`, `module`, `nomodule`, SRI, MIME mismatch, HTTPS downgrade and dangerous closing sequence are rejected. |
| Links and inline `onclick` | Partial | Link focus and handlers only for the supported XenonScript subset; no full DOM event model. |
| Raster images | Partial | Bounded download/cache and decoder support; SVG, modern formats and responsive selection remain limited. |
| Forms | Visual placeholders | Text entry, submission algorithms and full control semantics are not implemented. |
| Audio/video in document | Not implemented | Some direct resources can be listed/downloaded/handed off; this is not inline playback. |
| Canvas / WebGL / WebAssembly / WebSockets / service workers | Not implemented | No modern web-game or SPA compatibility claim. |
| Real NetSurf backend | Not integrated | `netsurf_backend_stub.c` is a capability stub, not a renderer. |
| PowerPC cross-build / XEX | Pending | Run the workflow; build packaging occurs only if the cross-build produces the expected files. |
| Physical Xbox validation | Pending | Cold start, controller, network, TLS, memory and page behaviour need real hardware testing. |

## Host validation

Run:

```sh
python3 tests/run_host_tests.py
cmake -S . -B build -DX360BROWSER_BUILD_TESTS=ON -DCMAKE_BUILD_TYPE=Release
cmake --build build --parallel 2
ctest --test-dir build --output-on-failure
```

The host suite covers the external-script integration end to end using a local HTTP fixture. It does not exercise the Xbox GPU, PowerPC ABI, XEX loader or console TLS store.
