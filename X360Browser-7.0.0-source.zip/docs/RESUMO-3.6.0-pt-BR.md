# X360Browser 3.6.0 — resumo em português

## Mudanças desta versão

- O renderizador do Xbox agora chama primeiro `xw_layout_page()`, usando a árvore DOM, o CSS e o runtime XenonScript para gerar o quadro visual. O renderizador antigo fica apenas como fallback se o novo caminho falhar.
- Limite de download HTML aumentado de 512 KiB para 4 MiB; a fonte HTML retida também tem orçamento de 4 MiB.
- Aumentados os limites de nós/atributos DOM, regras CSS, folhas externas, links, imagens e elementos visuais.
- Teste de regressão para HTML de 700 KiB, CSS externo acima de 4 KiB e iframe navegável pelo controle.
- Um iframe sem suporte interno agora apresenta um alvo selecionável para abrir seu endereço como uma página principal.

## Limites importantes

Esta versão não é um navegador moderno completo. O XenonScript não é ECMAScript completo, e Canvas/WebGL/WebAssembly/workers ainda não formam um ambiente de jogos web. Portanto, a maioria dos jogos atuais do Poki não deve funcionar.

Vídeos podem ser identificados como recursos e existe um caminho opcional para entregar arquivos a um player externo configurado pelo usuário. A reprodução dentro da página, incluindo o player atual do YouTube, ainda não está integrada. Abrir um endereço de iframe em separado não significa que o vídeo do YouTube vai tocar.

## Validação feita

Passaram os testes de host, os testes CMake/CTest, a verificação de integridade do pacote, a verificação estrita de sintaxe do renderizador/UI Xbox com cabeçalhos mock do xSDK e a análise de sintaxe do workflow YAML. A compilação final PowerPC/xSDK e o teste em console físico ainda precisam acontecer.
