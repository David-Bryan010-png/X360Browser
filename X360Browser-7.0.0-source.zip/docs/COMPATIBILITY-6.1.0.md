# Compatibilidade — X360Browser 6.1.0

## Mudanças desta versão
- Publicação automática de uma GitHub Release estável após validação e compilação cruzada bem-sucedidas, quando o workflow é executado na branch principal configurada (`main`, `master` ou `principal`).
- O artefato de release inclui `X360Browser.xex`, `X360Browser.xex.sha256`, o ZIP de instalação do Xbox 360 e seu checksum.
- O atualizador usa a API pública `/releases/latest`, exige HTTPS com validação TLS, limita o tamanho baixado e verifica SHA-256 antes de tentar instalar.
- O destino local agora prioriza `game:\\default.xex`, se existir, e usa `game:\\X360Browser.xex` como alternativa. Se o console bloquear a troca do executável aberto, o arquivo verificado permanece em `X360Browser.update.xex` para aplicação manual após sair do navegador.
- O workflow impede republicar bytes diferentes sob uma versão já publicada; é necessário incrementar `VERSION` e a versão de compilação antes de lançar uma atualização real.

## Limites
- A execução do workflow não constitui teste em console físico.
- O sistema de arquivos pode bloquear a substituição de um XEX que está em execução. Nesse caso a atualização é baixada e verificada, mas requer que o usuário saia do navegador e instale o arquivo preparado; não se pode garantir reinicialização automática do console.
- XenonWeb/XenonScript são implementações próprias de subconjuntos de HTML/CSS/JavaScript, não Chromium/WebKit.
