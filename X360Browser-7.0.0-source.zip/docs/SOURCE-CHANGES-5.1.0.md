# X360Browser 5.1.0 — alterações de fonte

## Interface e navegação

- Superfície visual 1152×500, com PAGE_SCREEN_Y=126.
- Cabeçalho simplificado com título, endereço atual e status de navegação.
- Fundo externo cinza-escuro.
- Adicionado `web_visual_renderer_hit_test()` para mapear coordenadas do cursor para links renderizados e hit-test separado dos controles HTML.
- RS liga/desliga o cursor; D-pad move; A ativa o link sob cursor ou abre o teclado de endereço quando aponta para a faixa superior.
- `input` e `textarea` editam via teclado virtual do Xbox e sincronizam o valor no DOM; botões executam `onclick` apenas no subconjunto XenonScript.

## Atualizador

- `update_manager.c/.h` contém leitura HTTPs do manifesto, parse limitado de três campos, comparação semântica de versão, download limitado, SHA-256 Mbed TLS, staging e troca com rollback.
- `X360Browser-update-config.txt` configura o endpoint; fica `disabled` por padrão até existir uma URL real.
- `vercel/api/update.js` oferece um manifesto da última release GitHub com version, xex_url e sha256.
- Workflow permite publicar os assets XEX/checksum/package numa tag `v*`.

## Verificações de segurança e limites

- Apenas HTTPS, verificação de certificado/hostname, redirects HTTPS limitados e tamanho máximo de arquivo.
- O hash detecta corrupção, mas não substitui assinatura criptográfica do editor; a origem GitHub/Vercel ainda precisa ser confiável.
- O instalador preserva uma cópia anterior e tenta rollback. Se renomear o XEX atual for negado, mantém o XEX validado em `X360Browser.update.xex` e informa que o usuário deve fechar o app.
- O endpoint Vercel precisa ser implantado pelo usuário e só responde com a release quando os assets requeridos estiverem publicados.
