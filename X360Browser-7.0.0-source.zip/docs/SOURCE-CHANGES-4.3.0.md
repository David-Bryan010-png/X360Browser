# X360Browser 4.3.0 — mudanças da fonte

## Correção primária

O erro `Extract validated source` vinha do caminho de arquivo presumido no segundo job. O artefato de source era carregado com o log fora da pasta `x360browser-dist`, e o `upload-artifact` preservava a árvore comum do caminho. O job seguinte esperava o ZIP diretamente em `validated/`, mas em algumas execuções ele ficava dentro de `validated/x360browser-dist/`.

## Alterações concretas

- Artefato de fonte agora contém apenas `X360Browser-4.3.0-source.zip` e seu checksum, ambos no mesmo diretório; log é um artefato separado.
- Extração procura o arquivo por nome de forma recursiva e exige exatamente um resultado.
- Verificação SHA-256 executada antes da extração.
- Validação preventiva do arquivo ZIP contra caminhos absolutos, `..`, barras invertidas, symlinks, número excessivo de entradas e tamanho descompactado excessivo.
- A etapa cria o log de build antes da verificação e imprime o conteúdo do download quando o ZIP esperado não existe.
- Novo `tests/test_workflow_artifact_paths.py` simula layouts de artefato plano e aninhado.
- Corrigido título da interface com versão antiga `3.3`.
- Buffer de entrada de endereço agora inicia zerado e usa um comprimento calculado uma única vez.
- XenonScript limpa os ponteiros temporários `stats` e `source` antes de retornar, evitando referências de stack/código expiradas, mas mantém a identidade do documento e as variáveis para os próximos eventos da mesma página.
- Helpers de parse de valores CSS passam a retornar fallback quando recebem ponteiro nulo.
- Mantida correção do shader da 4.2.0 e respectivas verificações.

## Não afirmado

Esta atualização não representa um build XEX executado por nós, nem um teste do console. O workflow agora tem o caminho da extração corrigido e vai tentar gerar o executável depois de a fonte passar na validação.
