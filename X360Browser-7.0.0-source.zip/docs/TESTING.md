# X360Browser 3.5.0 — host validation

Run from the project root:

```sh
python3 tests/validate_project_integrity.py
python3 tests/run_host_tests.py
cmake -S . -B build -DX360BROWSER_BUILD_TESTS=ON -DX360BROWSER_BUILD_DEMO=ON
cmake --build build --parallel 2
ctest --test-dir build --output-on-failure
```

`tests/run_host_tests.py` uses strict C17 flags (`-Wall -Wextra -Wshadow -Wconversion -Werror`) to build the DOM/CSS, layout, XenonScript, media and local-network fixture tests. The portable CMake tests cover the C++ application core and XenonMedia. GitHub Actions also checks Xbox UI/engine syntax with mock xSDK headers.

Passing host tests does not establish a successful PowerPC/xSDK build, Xbox ABI correctness, 512 MiB console behavior or physical-console playback. The workflow defaults to `build_xex=false`; no XEX is compiled unless deliberately opted in.
