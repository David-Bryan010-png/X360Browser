# X360Browser 3.6.0 — Web Compatibility Preview

This is the current source-package compatibility contract. “Supported” below means the host-side implementation has code and targeted tests; it does not mean every modern site is compatible.

## Visual browser path

The Xbox GPU renderer now calls `xw_layout_page()` first. XenonWeb parses the retained HTML into a bounded DOM, computes supported CSS, executes supported XenonScript mutations and emits rectangles, text runs, image placeholders and focusable link geometry. `web_visual_layout()` is a guarded fallback. This is actual visual layout rather than using extracted page text as the primary page renderer.

### Capacity limits

- HTML network body: maximum 4 MiB. Larger responses are rejected by the bounded transport.
- Retained HTML source: 4 MiB including NUL termination; larger source is marked truncated. The renderer shows a partial-page warning when applicable.
- External stylesheets: at most 8; each download is limited to 64 KiB. CSS parser input is bounded to 256 KiB.
- DOM: 4096 nodes, 8192 attributes and a 512 KiB string pool.
- Visual frame: 384 rectangles, 320 text runs, 24 images and 256 focusable link rectangles.
- Resource URL/link capacities are bounded; images retain their existing dimension, pixel and encoded-byte caps.

These are hard resource limits, not a promise that every document of that size will render in full: the DOM or output frame may reach its own cap earlier.

## Feature matrix

| Feature | Status in 3.6.0 |
|---|---|
| HTML download above 612 KiB | Supported through 4 MiB transport/retained-source budgets; regression test uses 700 KiB |
| Visual DOM/CSS layout on Xbox | Enabled by default; limited HTML tree construction and CSS subset |
| Block/text, headings, inline styling, links, images and form controls | Partial, bounded support |
| CSS flexbox and bounded grid | Partial implementation with host tests |
| JavaScript | XenonScript subset only; not ECMAScript-complete |
| Iframe navigation | URL becomes a focusable link to open top-level; nested frames are not rendered inline |
| Canvas/WebGL/WebAssembly/workers/service workers | Not implemented as browser APIs |
| Simple browser games | May work only if they avoid unsupported modern APIs; no blanket compatibility claim |
| Poki game pages | Site shell may load, but most games are not supported because Canvas/WebGL/modern JS/WASM requirements are missing |
| MP4/MP3/HLS detection and bounded transfer | Partial support; encrypted or unsupported streaming cases are rejected or surfaced as unsupported |
| Integrated HTML video/audio playback | Not implemented; no complete HTMLMediaElement, codec pipeline, audio output or A/V sync |
| YouTube current watch page/player | Not supported for in-page playback; iframe can only be opened as a top-level navigation fallback |
| H.264/AAC, MSE/DASH, WebRTC, WebGPU | Not integrated/supported |

## Why YouTube and Poki are not “just a JavaScript switch”

Modern games and media players depend on language/runtime features, DOM events, asynchronous APIs, Canvas/WebGL/WebAssembly, storage, browser security and—in the video case—media codecs, buffers, clocks and audio/video output. XenonScript is a small bounded interpreter for a subset of script operations. Enabling more syntax alone would not make those platform APIs exist.

## Validation

The host test suite verifies source transport, the >612 KiB regression fixture, stylesheet injection, DOM/CSS matching, bounded script mutations, visual layout, resource limits and media parsing primitives. Host tests do not prove that the Xbox-specific GPU path works on physical hardware. A PowerPC/xSDK build and console testing are separate release gates.
