# Roadmap after X360Browser 0.9.0

The 0.9.0 visual navigation and scroll fixes were followed by the common-raster image and HLS VOD work documented in `CHANGELOG.md`. Future stable 1.0.0 work is in `ROADMAP-1.0.0.md`.
