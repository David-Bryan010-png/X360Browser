# Atualização automática pelo GitHub — 6.1.0

## Caminho da publicação

1. Faça commit da fonte `X360Browser-6.1.0-source.zip` e substitua `.github/workflows/build-xex-from-zip.yml` pelo workflow desta versão.
2. Execute na branch principal `main`, `master` ou `principal` (ou envie o commit com alterações cobertas pelo filtro `paths`).
3. O workflow valida e testa a fonte, compila o XEX para Xbox 360 e só depois cria a release estável `v6.1.0`.
4. A release publica `X360Browser.xex`, `X360Browser.xex.sha256`, o ZIP com arquivos de runtime e o checksum desse ZIP.
5. Na inicialização, o navegador consulta `https://api.github.com/repos/David-Bryan010-png/X360Browser/releases/latest`. Se a versão publicada for maior que a versão embutida, baixa somente o XEX do repositório oficial, valida o SHA-256 e tenta instalá-lo no destino local.

## Regras de versão

- Para cada versão nova, atualize o arquivo `VERSION` e `include/x360browser/version.hpp` para a mesma versão semântica (`MAJOR.MINOR.PATCH`).
- Não mude os bytes do executável mantendo a mesma versão. O workflow bloqueia esse caso; aumente o patch (ex.: 6.1.0 → 6.1.1) e compile de novo.
- O workflow não é disparado por tags criadas pela etapa de publicação, evitando uma segunda compilação em loop.
- Para criar uma release de produção, execute a workflow na branch principal configurada. O `workflow_dispatch` em outra branch pode compilar artefatos, mas não publica release estável.

## Instalação e limitação de arquivo em uso

O atualizador procura primeiro `game:\\default.xex` e depois `game:\\X360Browser.xex`. Ele salva cópia anterior e tenta uma troca com rollback. O Xbox pode impedir renomear ou substituir o XEX em execução. Nesse caso, a atualização validada fica como `game:\\X360Browser.update.xex` e será necessário sair do programa e substituir o executável com gerenciador de arquivos/USB. Não se deve prometer atualização sem reinício ou sem ação manual enquanto o arquivo estiver bloqueado.

## Segurança

- HTTPS e validação de certificado TLS.
- Download limitado a 64 MiB.
- URLs dos assets limitadas ao caminho `github.com/David-Bryan010-png/X360Browser/releases/download/`.
- Comparação SHA-256 antes da instalação e rollback quando a substituição falha.

O workflow usa `GITHUB_TOKEN` com `contents: write`, já declarado pelo arquivo YAML. Se as permissões de Actions do repositório tiverem sido restringidas por configuração administrativa, habilite `read and write permissions` para o workflow.
