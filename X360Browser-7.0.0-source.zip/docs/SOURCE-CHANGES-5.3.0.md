# X360Browser 5.3.0 — mudanças de runtime

## Evidência observada

O log do Xbox informa que o renderizador gráfico foi inicializado, mas isso não mostra se a página carregada selecionou essa vista nem se a função de desenho foi chamada. As mensagens de abertura de `FFPlay.xex` aparecem porque o modo `auto` procurava um player externo durante a inicialização.

## Correções

- Acrescentado log `page ready` com código HTTP, MIME, bytes, classificação de recurso, estado do renderizador e vista efetivamente escolhida.
- Acrescentado log `GRAPHICAL FRAME` no primeiro quadro de cada URL quando a vista gráfica é executada.
- Acrescentado log de falha com URL e erro informado pela camada HTTP/TLS.
- Descoberta do player externo adiada para o momento em que se solicita reprodução. A navegação normal não precisa de `FFPlay.xex`.
- Mantido o workflow CMake/xSDK/PowerPC e a estrutura dos artefatos para não alterar o procedimento de compilação.

## Não prometido

Não foi executado um cross-build PowerPC neste ambiente e não houve teste visual num console Xbox 360 nesta sessão. Testes host e verificações estáticas passaram, mas o XEX gerado pelo GitHub Actions precisa ser validado no console. A engine continua sendo um subconjunto proprietário de HTML/CSS/JavaScript, não Chromium/WebKit.
