# X360Browser 3.2.0 — compatibility and test boundaries

This matrix describes the code that is actually present in the repository. It does not imply that a website will render correctly on every page or that the Xbox build has been tested.

| Area | Current state | Boundary |
|---|---|---|
| HTML | Bounded DOM parsing, common omitted end tags, raw script/style handling, RCDATA-like title/textarea behavior | Not a full HTML Living Standard parser; malformed complex markup may differ |
| DOM | IDs/classes/attributes, dynamic element/text creation, append/remove, scoped selectors, selected node relations and `classList` | No complete browser DOM; mutation/event semantics are partial |
| CSS cascade | Type/class/ID/attribute and selected pseudo/relationship selectors; source-order/specificity and bounded `!important` | Selector and inheritance coverage remains partial |
| Responsive CSS | `@media` subset for min/max width/height, orientation and comma/`and`/`not` combinations | Only evaluated for the engine's known viewport; many media features are unsupported |
| Box sizing | Pixel and percentage `width`, bounded `min-width`/`max-width`, four-side padding, horizontal `margin:auto` centering, line-height and colours | No complete box model, `calc()`, intrinsic sizing, float, table layout or margin-auto centering |
| Flex | Bounded row/column layout, gap, simple `justify-content`, `flex-wrap` | Approximation only; full flex-basis/grow/shrink, cross-axis alignment and writing modes are absent |
| Grid | Bounded 1–4 equal columns, gap and row wrapping | Not complete CSS Grid; no named/implicit tracks, fractions beyond equal distribution, placement or subgrid |
| JavaScript | First-party XenonScript interpreter with bounded variables/expressions, `if/else`, limited `for`, DOM/style/class mutations and inline click handlers | XenonScript is **not a complete ECMAScript runtime**; no promises, modules, `async/await`, event loop, broad built-ins or browser APIs |
| External scripts | Very small synchronous scripts with allowlisted MIME and byte/count limits | No full parser-blocking semantics; `async`, `defer`, modules and `integrity` scripts are skipped |
| Network | HTTP(S) through the existing transport, resource limits, MIME/redirect checks for selected resources | No full browser networking stack, service workers, WebSocket, HTTP/3 or full cookie/origin policy |
| Raster images | Raster decode/cache and accessible visual placeholders | No complete SVG/vector pipeline; large or unsupported content can be rejected |
| Media / games | Media URLs and some HLS VOD download/handoff paths exist | Inline video/audio, iframe browsing, Canvas/WebGL, WebAssembly and modern web-game compatibility are not implemented end-to-end |
| NetSurf | Current backend is a stub | NetSurf is not linked as the primary engine |
| Xbox target | Sources and workflow are present | The XEX is **not yet built or validated** in this milestone; no physical-console test claimed |

## 3.2.0 advancement

- Viewport-aware `@media` evaluation and tests at narrow/wide viewports.
- `!important` precedence in the bounded CSS cascade.
- `:first-of-type`, `:last-of-type`, `:nth-of-type`.
- Bounded Flexbox-like row/column, wrapping, gap and justification.
- Bounded CSS Grid equal-track layout.
- Percentage width and `min-width` / `max-width` flow through computed styles into actual block layout.

The minimum success criterion for the next milestone is to keep host regressions green, increase compatibility through focused test pages, and measure memory/time budgets before targeting the console build.
