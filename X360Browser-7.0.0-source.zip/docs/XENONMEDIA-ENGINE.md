# XenonMedia — first-party media engine (3.5.0)

XenonMedia is in-tree C code. Parsing functions and decoders consume caller-owned buffers and enforce input length, output capacity, dimensions, nesting, block, segment and pixel caps. There is no third-party raster or media decoder fallback.

## Raster decoders

| Format | Native behavior | Important limits |
|---|---|---|
| BMP | BI_RGB 1/4/8-bit indexed palettes, 24/32-bit | No RLE or bitfield compression |
| QOI | RGB/RGBA opcode decode | QOI only |
| PPM | P3/P6 8-bit RGB | No PPM 16-bit samples/PAM |
| PNG | 8-bit non-interlaced grayscale/RGB/indexed/alpha; in-tree DEFLATE, CRC/Adler and row filters | No Adam7 or 16-bit channels |
| GIF | First frame, LZW, palette, transparency, interlaced rows | No animation timeline/disposal composition |
| JPEG | Baseline sequential 8-bit grayscale/RGB; Huffman, quantization, restart markers, common chroma sampling and IDCT | No progressive/arithmetic/lossless/12-bit/CMYK profiles |

The renderer calls `xm_media_decode_image_rgba`, which validates signatures before dispatch. Unknown and unsupported profiles fail closed.

## Audio, video containers and subtitles

- **WAV PCM U8/S16LE:** decoded to interleaved signed PCM16.
- **WAV Microsoft IMA ADPCM:** mono/stereo format tag `0x0011`, bounded block metadata and block decoding to interleaved PCM16; malformed predictor/index, partial block and undersized output are rejected.
- **AVI:** parses stream metadata and extracts uncompressed BI_RGB 24/32-bit frames. This is not a compressed AVI codec pipeline.
- **MP4/ISO-BMFF:** validates bounded box structure and selected track/duration/video-handler metadata, but does not yet perform full `stbl` sample-table demux and sample extraction.
- **MP3 and AAC ADTS:** header/frame metadata parsing only; compressed samples are not decoded.
- **MPEG-TS:** validates a 188-byte packet and safe payload offset; no complete PID/program/A/V assembly.
- **HLS:** bounded manifest parser flags encrypted/live/byte-range/master-list cases. It is not a native HLS player.
- **WebVTT:** cue parsing supports a bounded header, optional identifiers, multiline cue text, `NOTE` blocks and active cue lookup by timestamp. Cue text is a slice of caller-owned input. Subtitle rendering, styling, track selection and synchronization are not connected to the Xbox render loop.
- **Playback state:** caller-clock timeline with play/pause/seek/end semantics. It does not by itself output audio/video.

## Security invariants

1. Never write past the caller-supplied output capacity.
2. Reject zero dimensions, arithmetic overflow, oversized images, malformed lengths, partial compressed blocks and truncated data.
3. Do not decode a payload solely from its extension; validate its signature and internal structure.
4. Fail closed on unsupported profiles and malformed media.
5. Keep untrusted media bytes separate from decoder state; do not send them to a shell or external command line.

## Regression coverage

`tests/test_xenonmedia.c` exercises image signatures and malformed decoders, PNG DEFLATE/filters, GIF transparency, baseline JPEG, raw AVI frames, WAV PCM and IMA ADPCM mono/stereo decoding, MP4 boxes, MP3/AAC headers, MPEG-TS, HLS, WebVTT cues and playback-state transitions. Host validation does not establish Xbox-specific performance or actual audio-device output.
