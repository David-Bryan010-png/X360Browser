# X360Browser 5.2.0 — matriz de compatibilidade

## O que é implementado

- Renderizador próprio XenonWeb em superfície gráfica 1280×544.
- Subconjunto de HTML e CSS com layout de blocos/elementos, texto, imagens e fundos CSS por `background-image`.
- Busca de imagens `<img>` e de URLs raster referenciadas por CSS externo, com imagens de conteúdo priorizadas sobre fundos decorativos.
- Cursor por controle, hit-testing de links/controles, formulários básicos e subconjunto de `onclick`.
- XenonScript, runtime limitado; XenonMedia, decodificadores próprios compatíveis com os formatos implementados pela biblioteca.
- Atualizador direto pelo GitHub Releases API com allowlist do repositório, download limitado, SHA-256 e tentativa de rollback.

## Suporte parcial ou não garantido

- CSS: propriedades de layout e pintura são um subconjunto. Não presuma suporte integral a flexbox/grid moderno, filtros, transformações, animações, fontes remotas complexas ou todas as regras de cascata.
- JavaScript: não é ECMAScript completo; módulos, promises, APIs Web modernas e muitos handlers podem não funcionar.
- Não implementados integralmente: SVG, WebP, AVIF, Canvas, WebGL e WebAssembly; não são garantidos pelo pipeline atual.
- Iframes não são contextos completos de navegação executável.
- YouTube: fluxo experimental dependente de MP4 compatível e player externo; não equivale ao YouTube num navegador de desktop.
- Atualizações: o console precisa alcançar o GitHub por HTTPS com certificados válidos. O sistema de arquivos/loader pode impedir troca do XEX em uso; nesse caso o arquivo pode ficar preparado para troca manual/reabertura.

O navegador **não é Chromium** e **não transforma XenonScript em ECMAScript completo**. “Renderizar graficamente” significa compor pixels de elementos suportados — não garante a estética de todo site moderno. Este documento não afirma validação em hardware Xbox 360.
