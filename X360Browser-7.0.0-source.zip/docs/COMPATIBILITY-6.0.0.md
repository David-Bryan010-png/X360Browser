# Compatibilidade — X360Browser 6.0.0

## Comportamento implementado
- A interface usa página gráfica como modo padrão para documentos HTML.
- O modo `NATIVEPLUS TEXT READER VIEW` foi removido do fluxo de navegação.
- X alterna página gráfica, lista de links e lista de recursos.
- Falhas de renderer e respostas de recursos recebem telas/cartões diagnósticos; o texto extraído da página não é exibido como substituto do site.
- O renderer gráfico e o parser de XenonWeb continuam usando um subconjunto próprio de HTML/CSS/JavaScript.

## Limites
Não é Chromium/WebKit. Não promete compatibilidade universal com layouts CSS avançados, ECMAScript moderno, canvas/WebGL/WebAssembly, DRM, iframes completos ou jogos web atuais. Mídia/YouTube permanece experimental e pode depender de player externo. O teste de host não valida GPU/shaders ou rede no Xbox físico.
