# X360Browser 5.3.0 — diagnóstico de renderização no console

## Por que esta revisão existe

O log informado pelo console mostra que a inicialização do renderizador gráfico concluiu. Isso não garantia, sozinho, que cada documento carregado tivesse entrado na vista gráfica. A 5.3.0 acrescenta logs explícitos do MIME/HTTP, classificação do recurso, vista escolhida e primeiro quadro gráfico por URL.

## Correções

- O log `page ready` informa HTTP, tipo de conteúdo, bytes, classificação como recurso direto, estado do renderizador e vista selecionada.
- A primeira apresentação gráfica de cada URL gera `GRAPHICAL FRAME`, incluindo altura do layout e viewport. Isso permite diferenciar renderizador inicializado de página realmente enviada para desenho.
- Falhas de carregamento produzem um log com URL e erro da camada de rede.
- A procura por `FFPlay.xex` foi adiada até uma ação de reprodução. A ausência do player externo não deve gerar quatro tentativas de abertura em toda inicialização nem impedir a navegação comum.
- Mantém a interface de compilação existente: CMake + toolchain xSDK/PowerPC via GitHub Actions, com o mesmo workflow e caminhos de artefato.

## Como ler o log

- `renderer=ready view=GRAPHICAL`: o app escolheu a vista gráfica para um documento HTML.
- `GRAPHICAL FRAME`: a função do renderizador foi chamada para desenhar esse URL.
- `view=READER/RESOURCE`: a página foi classificada como recurso direto ou o renderizador não estava disponível.
- `Playback unavailable`: só significa que não há player externo compatível configurado/encontrado; não é falha de navegação.

## Limites reais

Esta revisão melhora o caminho de renderização e o diagnóstico, mas não transforma XenonWeb em Chromium/WebKit nem implementa toda a JavaScript/CSS moderna. Sites como YouTube e Poki são dinâmicos e podem continuar incompletos; jogos Web modernos, DRM, WebGL/WebAssembly e vídeo HTML5 universal não são garantidos. Um log não substitui um teste visual no Xbox físico.
