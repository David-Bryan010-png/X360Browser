#include "xw_dom.h"
#include "xw_script.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static int failures;
static void check(int condition, const char *name)
{
    if (condition) printf("PASS: %s\n", name);
    else { printf("FAIL: %s\n", name); ++failures; }
}

int main(void)
{
    static const char html[] =
        "<html><head><title>Before</title>"
        "<script>var n = 5; if (n > 3) { document.getElementById('message').textContent = 'Changed ' + n; } else { document.getElementById('message').textContent = 'Wrong'; }</script>"
        "<script>var target = document.querySelector('#message'); target.setAttribute('style', 'color:red'); console.log('ready');</script>"
        "<script>var styled = document.querySelector('section p.target'); styled.style.color = 'rgb(255, 0, 0)';"
        " styled.style.fontSize = '22px'; styled.setAttribute('data-ready','yes');"
        " if (styled.hasAttribute('data-ready')) { styled.textContent = styled.getAttribute('data-ready') + ' active'; }"
        " styled.removeAttribute('data-ready');</script>"
        "<script>var sum = 0; for (var i = 0; i < 4; i++) { sum += i; }"
        " document.getElementById('loop-result').textContent = 'sum=' + sum;</script>"
        "<script>var phrase = '  XenonWeb NEXT  '; var lower = phrase.trim().toLowerCase();"
        " var upper = 'Browser'.toUpperCase(); var offset = phrase.indexOf('Web');"
        " if (phrase.length == 17 && lower.includes('xenonweb') && upper == 'BROWSER'"
        " && upper.charAt(0) == 'B' && upper.charAt(-1) == ''"
        " && phrase.startsWith('  ') && phrase.endsWith('  ')"
        " && phrase.slice(2,10) == 'XenonWeb' && phrase.substring(2,10) == 'XenonWeb'"
        " && phrase.slice(-6,-2) == 'NEXT' && offset >= 0)"
        " { document.getElementById('message').setAttribute('string-methods','ok'); }</script>"
        "<script>var dynamic = document.createElement('p'); dynamic.id = 'dynamic';"
        " dynamic.classList.add('note', 'active'); dynamic.textContent = 'Created dynamically';"
        " document.body.appendChild(dynamic); if (dynamic.classList.contains('active')) { dynamic.classList.toggle('visible'); }"
        " dynamic.classList.remove('note'); var probe = document.createElement('span');"
        " probe.id = 'probe'; if (document.body.querySelector('.active').matches('p')) {"
        " probe.textContent = dynamic.tagName + '/' + dynamic.closest('body').tagName; }"
        " if (!dynamic.querySelector('body')) { dynamic.setAttribute('scope-ok','yes'); }"
        " document.body.appendChild(probe); var txt = document.createTextNode('!'); probe.appendChild(txt);"
        " if (document.nodeType == 9 && dynamic.nodeType == 1 && dynamic.parentNode.tagName == 'BODY'"
        " && dynamic.firstChild.nodeType == 3 && dynamic.firstElementChild == undefined"
        " && dynamic.nextElementSibling.id == 'probe' && probe.previousElementSibling.id == 'dynamic'"
        " && probe.firstChild.nodeValue == 'P/BODY') { probe.setAttribute('node-relations','ok'); }"
        " txt.nodeValue = '?'; if (txt.textContent == '?' && txt.nodeValue == '?') probe.setAttribute('node-value-mutation','ok');"
        " var emptyText = document.createTextNode('nonempty'); document.body.appendChild(emptyText); emptyText.nodeValue='';"
        " if (emptyText.nodeValue == '' && emptyText.textContent == '') probe.setAttribute('empty-text-node','ok');"
        " var cleanup = document.createElement('div'); cleanup.id='cleanup';"
        " var stale = document.createElement('span'); stale.id='stale-child'; cleanup.appendChild(stale);"
        " document.body.appendChild(cleanup); cleanup.textContent='';"
        " var input = document.createElement('input'); input.id='form-input'; input.type='text';"
        " input.name='q'; input.placeholder='Search'; input.value='hello'; input.required=true;"
        " input.checked=true; input.checked=false; input.disabled=true; input.disabled=false;"
        " input.readOnly=true; input.readOnly=false; input.multiple=true; input.multiple=false;"
        " input.selected=true; input.selected=false; document.body.appendChild(input);"
        " if (input.value == 'hello' && input.type == 'text' && input.name == 'q'"
        " && input.placeholder == 'Search' && input.required) { input.setAttribute('form-properties','ok'); }"
        " if (!input.checked && !input.disabled && !input.readOnly && !input.multiple && !input.selected)"
        " { input.setAttribute('form-booleans','ok'); }"
        " var trash = document.createElement('i'); trash.id='trash'; document.body.appendChild(trash); trash.remove();"
        " var trash2 = document.createElement('i'); trash2.id='trash2'; document.body.appendChild(trash2); document.body.removeChild(trash2);</script>"
        "</head><body><p id='message'>Initial</p><p id='other'>Keep</p>"
        "<section><p id='styled' class='target'>Style me</p></section>"
        "<p id='loop-result'>loop pending</p></body></html>";
    XwDocument *document = (XwDocument *)calloc(1U, sizeof(*document));
    XwScriptStats stats;
    uint16_t message;
    char text[128];
    int ok;
    if (document == NULL) return 2;
    check(xw_dom_parse(document, html, sizeof(html) - 1U), "DOM parsed before script execution");
    ok = xw_script_run_document(document, 1000U, &stats);
    check(ok, "bounded XenonScript executes supported inline scripts");
    message = xw_dom_find_by_id(document, "message");
    (void)xw_dom_text_content(document, message, text, sizeof(text));
    check(strcmp(text, "Changed 5") == 0, "if/else, variables, addition and textContent mutation work");
    check(strcmp(xw_dom_attribute(document, message, "style"), "color:red") == 0,
          "setAttribute writes a DOM attribute used by style recalculation");
    check(stats.script_elements == 6U && stats.executed_scripts == 6U,
          "multiple inline scripts execute in document order with shared globals");
    check(stats.dom_mutations >= 2U && stats.console_calls == 1U && stats.errors == 0U,
          "script telemetry records mutations and console calls");
    check(strcmp(xw_dom_attribute(document, message, "string-methods") != NULL ?
                 xw_dom_attribute(document, message, "string-methods") : "", "ok") == 0,
          "bounded JavaScript string length/case/trim/search/prefix/suffix/slice helpers work");
    {
        uint16_t styled = xw_dom_find_by_id(document, "styled");
        const char *style = xw_dom_attribute(document, styled, "style");
        const char *data = xw_dom_attribute(document, styled, "data-ready");
        (void)xw_dom_text_content(document, styled, text, sizeof(text));
        check(style != NULL && strstr(style, "color: rgb(255, 0, 0)") != NULL &&
              strstr(style, "font-size: 22px") != NULL,
              "style proxy writes CSS properties and preserves sibling declarations");
        check(strcmp(text, "yes active") == 0 && data == NULL,
              "querySelector supports descendant selectors; get/has/removeAttribute and DOM text mutation work");
        {
            uint16_t loop_result = xw_dom_find_by_id(document, "loop-result");
            (void)xw_dom_text_content(document, loop_result, text, sizeof(text));
            check(strcmp(text, "sum=6") == 0,
                  "bounded for loops, postfix increment and compound assignment execute correctly");
        }
        {
            uint16_t dynamic = xw_dom_find_by_id(document, "dynamic");
            uint16_t probe = xw_dom_find_by_id(document, "probe");
            const char *classes = xw_dom_attribute(document, dynamic, "class");
            (void)xw_dom_text_content(document, dynamic, text, sizeof(text));
            check(dynamic != XW_DOM_NONE && strcmp(text, "Created dynamically") == 0 &&
                  classes != NULL && strstr(classes, "active") != NULL &&
                  strstr(classes, "visible") != NULL && strstr(classes, "note") == NULL,
                  "createElement, appendChild, classList.add/remove/contains/toggle and textContent work");
            (void)xw_dom_text_content(document, probe, text, sizeof(text));
            check(probe != XW_DOM_NONE && strcmp(text, "P/BODY?") == 0,
                  "element querySelector/matches/closest, tagName, createTextNode and appendChild work");
            check(xw_dom_find_by_id(document, "trash") == XW_DOM_NONE &&
                  xw_dom_find_by_id(document, "trash2") == XW_DOM_NONE &&
                  strcmp(xw_dom_attribute(document, dynamic, "scope-ok") != NULL ?
                         xw_dom_attribute(document, dynamic, "scope-ok") : "", "yes") == 0,
                  "remove/removeChild detach elements from connected DOM queries and scoped queries stay within root");
            check(strcmp(xw_dom_attribute(document, probe, "node-relations") != NULL ?
                         xw_dom_attribute(document, probe, "node-relations") : "", "ok") == 0,
                  "nodeType, parentNode, firstChild, adjacent element siblings and text-node value work");
            check(strcmp(xw_dom_attribute(document, probe, "node-value-mutation") != NULL ?
                         xw_dom_attribute(document, probe, "node-value-mutation") : "", "ok") == 0,
                  "text-node nodeValue/textContent can be changed without allocating an unbounded node");
            check(xw_dom_find_by_id(document, "stale-child") == XW_DOM_NONE,
                  "setting element textContent detaches all replaced descendants from global DOM lookup");
            check(strcmp(xw_dom_attribute(document, probe, "empty-text-node") != NULL ?
                         xw_dom_attribute(document, probe, "empty-text-node") : "", "ok") == 0,
                  "empty text node values use a real empty-string slot rather than an unrelated string-pool offset");
            check(strcmp(xw_dom_attribute(document, xw_dom_find_by_id(document, "form-input"),
                         "form-properties") != NULL ? xw_dom_attribute(document,
                         xw_dom_find_by_id(document, "form-input"), "form-properties") : "", "ok") == 0,
                  "common input value/type/name/placeholder/required properties reflect bounded attributes");
            check(strcmp(xw_dom_attribute(document, xw_dom_find_by_id(document, "form-input"),
                         "form-booleans") != NULL ? xw_dom_attribute(document,
                         xw_dom_find_by_id(document, "form-input"), "form-booleans") : "", "ok") == 0,
                  "checked/disabled/selected/readOnly/multiple boolean properties add and remove attributes");
        }
    }
    {
        static const char unsafe_html[] =
            "<html><script>while (true) { }</script><body><p>Safe fallback</p></body></html>";
        XwScriptStats unsafe_stats;
        check(xw_dom_parse(document, unsafe_html, sizeof(unsafe_html) - 1U), "second document resets bounded DOM");
        check(!xw_script_run_document(document, 100U, &unsafe_stats) && unsafe_stats.errors == 1U,
              "unsupported unbounded loops fail closed instead of hanging the console");
    }
    {
        static const char bounded_while_html[] =
            "<html><script>var boundedCount = 0; while (boundedCount < 96) { boundedCount++; }</script></html>";
        XwScriptStats bounded_stats;
        check(xw_dom_parse(document, bounded_while_html, sizeof(bounded_while_html) - 1U),
              "bounded while document parsed");
        check(xw_script_run_document(document, 10000U, &bounded_stats),
              "finite while loop ending at the iteration cap exits without false failure");
    }
    {
        static const char state_html[] = "<html><body><p id='counter-output'>pending</p></body></html>";
        static const char declare_state[] = "var eventCounter = 40;";
        static const char update_state[] = "eventCounter += 2; document.getElementById('counter-output').textContent = eventCounter;";
        XwScriptStats state_stats;
        uint16_t counter_node;
        check(xw_dom_parse(document, state_html, sizeof(state_html) - 1U), "event-state document parsed");
        check(xw_script_run_document(document, 100U, &state_stats), "empty inline-script pass initializes the page script context");
        check(xw_script_execute_code(document, declare_state, sizeof(declare_state) - 1U, 100U, &state_stats),
              "event-handler script can declare page state");
        check(xw_script_execute_code(document, update_state, sizeof(update_state) - 1U, 100U, &state_stats),
              "subsequent event-handler script reuses the page state");
        counter_node = xw_dom_find_by_id(document, "counter-output");
        (void)xw_dom_text_content(document, counter_node, text, sizeof(text));
        check(counter_node != XW_DOM_NONE && strcmp(text, "42") == 0,
              "bounded script variables persist between handlers for the same document");
    }
    free(document);
    if (failures) { printf("%d XenonScript test(s) failed\n", failures); return 1; }
    printf("All XenonScript tests passed\n");
    return 0;
}
