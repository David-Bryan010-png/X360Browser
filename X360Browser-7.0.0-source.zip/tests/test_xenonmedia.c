#include "xm_media.h"
#include "xm_playback.h"
#include "jpeg_baseline_fixture.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static int checks=0, failures=0;
static void check(int ok,const char *name){++checks;if(ok)printf("PASS: %s\n",name);else{printf("FAIL: %s\n",name);++failures;}}
static void put16le(unsigned char*p,unsigned v){p[0]=(unsigned char)v;p[1]=(unsigned char)(v>>8U);}
static void put32le(unsigned char*p,unsigned v){p[0]=(unsigned char)v;p[1]=(unsigned char)(v>>8U);p[2]=(unsigned char)(v>>16U);p[3]=(unsigned char)(v>>24U);}
static void put32be(unsigned char*p,unsigned v){p[0]=(unsigned char)(v>>24U);p[1]=(unsigned char)(v>>16U);p[2]=(unsigned char)(v>>8U);p[3]=(unsigned char)v;}


static uint32_t test_crc32(const unsigned char *data, size_t length) {
    uint32_t crc = 0xFFFFFFFFU;
    size_t i; unsigned bit;
    for (i = 0U; i < length; ++i) {
        crc ^= data[i];
        for (bit = 0U; bit < 8U; ++bit) crc = (crc & 1U) ? (crc >> 1U) ^ 0xEDB88320U : crc >> 1U;
    }
    return crc ^ 0xFFFFFFFFU;
}
static size_t append_png_chunk(unsigned char *png, size_t pos, const char type[4], const unsigned char *data, size_t length) {
    unsigned char crc_data[1024];
    put32be(png + pos, (unsigned)length); memcpy(png + pos + 4U, type, 4U);
    if (length != 0U) memcpy(png + pos + 8U, data, length);
    memcpy(crc_data, type, 4U); if (length != 0U) memcpy(crc_data + 4U, data, length);
    put32be(png + pos + 8U + length, test_crc32(crc_data, length + 4U));
    return pos + 12U + length;
}
static size_t append_avi_chunk(unsigned char *avi, size_t pos, const char tag[4], const unsigned char *data, size_t length) {
    memcpy(avi + pos, tag, 4U); put32le(avi + pos + 4U, (unsigned)length);
    if (length != 0U) memcpy(avi + pos + 8U, data, length);
    if ((length & 1U) != 0U) avi[pos + 8U + length] = 0U;
    return pos + 8U + length + (length & 1U);
}
static size_t start_avi_list(unsigned char *avi, size_t pos, const char type[4]) {
    memcpy(avi + pos, "LIST", 4U); put32le(avi + pos + 4U, 0U); memcpy(avi + pos + 8U, type, 4U); return pos;
}
static size_t finish_avi_list(unsigned char *avi, size_t list_start, size_t pos) {
    put32le(avi + list_start + 4U, (unsigned)(pos - (list_start + 8U))); return pos;
}
static size_t build_small_avi(unsigned char *avi, size_t capacity) {
    size_t pos = 12U, hdrl, strl, movi; unsigned char avih[56]={0}, strh[56]={0}, strf[40]={0}, frame[16]={0};
    if (capacity < 256U) return 0U;
    memcpy(avi, "RIFF", 4U); put32le(avi + 4U, 0U); memcpy(avi + 8U, "AVI ", 4U);
    put32le(avih, 40000U); put32le(avih + 16U, 1U); put32le(avih + 24U, 1U); put32le(avih + 32U, 2U); put32le(avih + 36U, 2U);
    hdrl = start_avi_list(avi, pos, "hdrl"); pos += 12U; pos = append_avi_chunk(avi, pos, "avih", avih, sizeof(avih));
    strl = start_avi_list(avi, pos, "strl"); pos += 12U;
    memcpy(strh, "vids", 4U); memcpy(strh + 4U, "DIB ", 4U); put32le(strh + 20U, 1U); put32le(strh + 24U, 25U); put32le(strh + 32U, 1U);
    pos = append_avi_chunk(avi, pos, "strh", strh, sizeof(strh));
    put32le(strf, 40U); put32le(strf + 4U, 2U); put32le(strf + 8U, 2U); put16le(strf + 12U, 1U); put16le(strf + 14U, 24U); put32le(strf + 20U, 16U);
    pos = append_avi_chunk(avi, pos, "strf", strf, sizeof(strf));
    pos = finish_avi_list(avi, strl, pos); pos = finish_avi_list(avi, hdrl, pos);
    /* Bottom-up 2x2 BGR24, 8-byte aligned rows. */
    frame[0]=255U; frame[3]=255U; frame[4]=255U; frame[5]=255U;
    frame[10]=255U; frame[13]=255U;
    movi = start_avi_list(avi, pos, "movi"); pos += 12U; pos = append_avi_chunk(avi, pos, "00db", frame, sizeof(frame));
    pos = finish_avi_list(avi, movi, pos); put32le(avi + 4U, (unsigned)(pos - 8U)); return pos;
}

int main(void){
    XmMediaInfo media; XmWavInfo wav; XmImageInfo image; XmMpegAudioFrameInfo mp3; XmAdtsInfo adts; XmTsPacketInfo ts; XmHlsInfo hls; XmPlaybackSession session; XmWebVttCue cue;
    unsigned char wavb[48]={0}; int16_t pcm[8]={0}; size_t written=0U;
    unsigned char bmp[70]={0}, bmp_index[70]={0}, rgba[4096]={0};
    unsigned char qoi[27]={0};
    unsigned char gif[] = {'G','I','F','8','9','a',1U,0U,1U,0U,0x80U,0U,0U, 0U,0U,0U, 255U,255U,255U,
                           0x21U,0xF9U,4U,1U,0U,0U,0U,0U,
                           0x2CU,0U,0U,0U,0U,1U,0U,1U,0U,0U,2U,2U,0x44U,0x01U,0U,0x3BU};
    unsigned char ppm3[] = "P3\n1 1\n255\n255 0 128\n";
    unsigned char ppm6[] = {'P','6','\r','\n','1',' ','1','\n','2','5','5','\r','\n',255U,0U,64U};
    unsigned char png[256]={0}, png_ihdr[13]={0}; size_t png_len=0U;
    unsigned char avi[256]={0}; size_t avi_len=0U, avi_cursor=0U; XmAviInfo avi_info;
    unsigned char mp4[40]={0};
    unsigned char mp3h[4]={0xFF,0xFB,0x90,0x64};
    unsigned char adtsh[7]={0xFF,0xF1,0x50,0x80,0x00,0xFF,0xFC};
    unsigned char tsb[188]={0x47,0x41,0x00,0x10};
    const char *playlist="#EXTM3U\n#EXT-X-TARGETDURATION:6\n#EXT-X-MEDIA-SEQUENCE:7\n#EXTINF:5.5,\nseg1.ts\n#EXTINF:5.0,\nseg2.ts\n#EXT-X-ENDLIST\n";
    check(strcmp(xm_container_name(XM_CONTAINER_ISO_BMFF),"ISO-BMFF/MP4")==0,"container names are available without third-party code");
    check(strcmp(xm_codec_name(XM_CODEC_AVC),"H.264/AVC")==0,"codec names are available without third-party code");
    {const unsigned char sig[]={0,0,0,16,'f','t','y','p','i','s','o','m',0,0,0,0};check(xm_media_probe(sig,sizeof(sig),NULL,NULL,&media)&&media.container==XM_CONTAINER_ISO_BMFF,"signature probe detects ISO-BMFF independent of extension");}
    {unsigned char sig[188]={0x47,0x41,0x00,0x10};check(xm_media_probe(sig,sizeof(sig),"x.ts",NULL,&media)&&media.container==XM_CONTAINER_MPEG_TS,"transport-stream sniff uses a full packet and extension fallback");}
    {const unsigned char sig[]="#EXTM3U\n";check(xm_media_probe(sig,sizeof(sig)-1U,"index.m3u8",NULL,&media)&&media.container==XM_CONTAINER_HLS,"HLS manifests are detected by URL when body is not passed as media payload");}
    check(xm_media_probe(NULL,0U,"/clip.MP4?token=abc",NULL,&media)&&media.container==XM_CONTAINER_ISO_BMFF,"URL sniff ignores query strings and matches extensions case-insensitively");
    check(xm_media_probe(NULL,0U,NULL,"audio/mpeg",&media)&&media.audio_codec==XM_CODEC_MP3,"MIME-only MP3 detection works");
    check(!xm_media_probe(NULL,0U,NULL,NULL,&media),"empty/unclassified payload is rejected");

    memcpy(wavb,"RIFF",4U);put32le(wavb+4U,40U);memcpy(wavb+8U,"WAVEfmt ",8U);put32le(wavb+16U,16U);put16le(wavb+20U,1U);put16le(wavb+22U,1U);put32le(wavb+24U,8000U);put32le(wavb+28U,16000U);put16le(wavb+32U,2U);put16le(wavb+34U,16U);memcpy(wavb+36U,"data",4U);put32le(wavb+40U,4U);put16le(wavb+44U,0x7FFFU);put16le(wavb+46U,0x8000U);
    check(xm_media_parse_wav(wavb,sizeof(wavb),&wav)&&wav.sample_rate==8000U&&wav.channels==1U&&wav.duration_ms==0U,"WAVE parser validates PCM structure and short-duration rounding");
    check(xm_media_decode_wav_pcm16(wavb,sizeof(wavb),pcm,8U,&written,&wav)&&written==2U&&pcm[0]==32767&&pcm[1]==(-32768),"first-party WAV PCM16 decoder preserves signed sample values");
    check(!xm_media_decode_wav_pcm16(wavb,sizeof(wavb),pcm,1U,&written,NULL),"WAV decoder rejects output buffers that are too small");
    {unsigned char bad[48];memcpy(bad,wavb,sizeof(bad));put16le(bad+20U,3U);check(!xm_media_parse_wav(bad,sizeof(bad),&wav),"WAV parser rejects non-PCM codecs instead of mis-decoding them");}
    {unsigned char bad[48];memcpy(bad,wavb,sizeof(bad));put32le(bad+4U,0xFFFFFFFFU);check(!xm_media_parse_wav(bad,sizeof(bad),&wav),"WAV parser rejects RIFF sizes beyond the supplied buffer");}
    {unsigned char u8[46]={0};memcpy(u8,wavb,44U);put16le(u8+34U,8U);put16le(u8+32U,1U);put32le(u8+28U,8000U);put32le(u8+40U,2U);u8[44]=0U;u8[45]=255U;put32le(u8+4U,38U);check(xm_media_decode_wav_pcm16(u8,sizeof(u8),pcm,8U,&written,&wav)&&pcm[0]==-32768&&pcm[1]==32512,"WAV unsigned 8-bit samples convert to signed PCM16");}
    {unsigned char ima[56]={0};int16_t decoded[16]={0};size_t decoded_count=0U;memcpy(ima,"RIFF",4U);put32le(ima+4U,48U);memcpy(ima+8U,"WAVEfmt ",8U);put32le(ima+16U,20U);put16le(ima+20U,0x11U);put16le(ima+22U,1U);put32le(ima+24U,8000U);put32le(ima+28U,7111U);put16le(ima+32U,8U);put16le(ima+34U,4U);put16le(ima+36U,2U);put16le(ima+38U,9U);memcpy(ima+40U,"data",4U);put32le(ima+44U,8U);put16le(ima+48U,1000U);ima[50U]=0U;ima[51U]=0U;ima[52U]=0x11U;ima[53U]=0x22U;ima[54U]=0x33U;ima[55U]=0x44U;check(xm_media_parse_wav(ima,sizeof(ima),&wav)&&wav.format_tag==0x11U&&wav.samples_per_block==9U&&wav.total_samples==9U,"WAV parser recognizes bounded IMA ADPCM block metadata");check(xm_media_decode_wav_pcm16(ima,sizeof(ima),decoded,16U,&decoded_count,&wav)&&decoded_count==9U&&decoded[0]==1000&&decoded[1]==1001&&decoded[2]==1002,"first-party IMA ADPCM decoder reconstructs bounded PCM16 samples");check(!xm_media_decode_wav_pcm16(ima,sizeof(ima),decoded,8U,&decoded_count,NULL),"IMA ADPCM decoder rejects undersized output buffers");check(xm_media_probe(ima,sizeof(ima),NULL,NULL,&media)&&media.audio_codec==XM_CODEC_IMA_ADPCM&&media.supported_for_native_decode,"media probe reports native IMA ADPCM support only after validating WAV metadata");{unsigned char stereo[64]={0};int16_t stereo_out[32]={0};size_t stereo_count=0U;memcpy(stereo,"RIFF",4U);put32le(stereo+4U,56U);memcpy(stereo+8U,"WAVEfmt ",8U);put32le(stereo+16U,20U);put16le(stereo+20U,0x11U);put16le(stereo+22U,2U);put32le(stereo+24U,8000U);put32le(stereo+28U,14222U);put16le(stereo+32U,16U);put16le(stereo+34U,4U);put16le(stereo+36U,2U);put16le(stereo+38U,9U);memcpy(stereo+40U,"data",4U);put32le(stereo+44U,16U);put16le(stereo+48U,1000U);stereo[50U]=0U;stereo[51U]=0U;put16le(stereo+52U,0xFC18U);stereo[54U]=0U;stereo[55U]=0U;stereo[56U]=0x11U;stereo[57U]=0x22U;stereo[58U]=0x33U;stereo[59U]=0x44U;stereo[60U]=0x11U;stereo[61U]=0x22U;stereo[62U]=0x33U;stereo[63U]=0x44U;check(xm_media_decode_wav_pcm16(stereo,sizeof(stereo),stereo_out,32U,&stereo_count,&wav)&&stereo_count==18U&&stereo_out[0]==1000&&stereo_out[1]==-1000&&stereo_out[2]==1001&&stereo_out[3]==-999,"IMA ADPCM stereo blocks decode into correctly interleaved PCM16");} }

    memcpy(bmp,"BM",2U);put32le(bmp+2U,70U);put32le(bmp+10U,54U);put32le(bmp+14U,40U);put32le(bmp+18U,2U);put32le(bmp+22U,2U);put16le(bmp+26U,1U);put16le(bmp+28U,24U);put32le(bmp+34U,16U);
    /* Bottom-up, 24-bit rows each padded to 8 bytes: BGR red, green; then blue, white. */
    bmp[54]=255U;bmp[55]=0U;bmp[56]=0U;bmp[57]=0U;bmp[58]=255U;bmp[59]=0U;bmp[62]=0U;bmp[63]=0U;bmp[64]=255U;bmp[65]=255U;bmp[66]=255U;bmp[67]=255U;
    check(xm_media_decode_bmp_rgba(bmp,sizeof(bmp),rgba,sizeof(rgba),&image)&&image.width==2U&&image.height==2U,"first-party BMP decoder accepts bounded 24-bit raster");
    check(rgba[0]==255U&&rgba[1]==0U&&rgba[2]==0U&&rgba[3]==255U,"BMP decoder flips bottom-up rows and emits opaque RGBA");
    check(!xm_media_decode_bmp_rgba(bmp,sizeof(bmp),rgba,4U,&image),"BMP decoder rejects undersized output memory");
    {unsigned char bad[70];memcpy(bad,bmp,sizeof(bad));put32le(bad+30U,1U);check(!xm_media_decode_bmp_rgba(bad,sizeof(bad),rgba,sizeof(rgba),&image),"BMP decoder rejects compressed/unknown DIB modes safely");}
    memcpy(bmp_index,"BM",2U);put32le(bmp_index+2U,66U);put32le(bmp_index+10U,62U);put32le(bmp_index+14U,40U);put32le(bmp_index+18U,2U);put32le(bmp_index+22U,1U);put16le(bmp_index+26U,1U);put16le(bmp_index+28U,1U);put32le(bmp_index+34U,4U);put32le(bmp_index+46U,2U);bmp_index[56]=255U;bmp_index[59]=255U;bmp_index[60]=0U;bmp_index[62]=0x40U;
    check(xm_media_decode_bmp_rgba(bmp_index,66U,rgba,sizeof(rgba),&image)&&image.width==2U&&image.height==1U&&rgba[0]==255U&&rgba[1]==0U&&rgba[4]==0U&&rgba[5]==255U,"first-party BMP decoder handles indexed 1-bit palettes");
    { unsigned char bad[70];memcpy(bad,bmp_index,sizeof(bad));put32le(bad+46U,3U);check(!xm_media_decode_bmp_rgba(bad,66U,rgba,sizeof(rgba),&image),"indexed BMP decoder rejects palette counts beyond bit depth"); }

    memcpy(qoi,"qoif",4U);put32be(qoi+4U,1U);put32be(qoi+8U,1U);qoi[12]=4U;qoi[13]=0U;qoi[14]=0xFFU;qoi[15]=255U;qoi[16]=0U;qoi[17]=0U;qoi[18]=255U;memcpy(qoi+19U,"\0\0\0\0\0\0\0\1",8U);
    check(xm_media_decode_qoi_rgba(qoi,sizeof(qoi),rgba,sizeof(rgba),&image)&&image.width==1U&&rgba[0]==255U&&rgba[1]==0U&&rgba[2]==0U&&rgba[3]==255U,"first-party QOI decoder decodes RGBA opcode");
    {unsigned char bad[27];memcpy(bad,qoi,sizeof(bad));bad[12]=2U;check(!xm_media_decode_qoi_rgba(bad,sizeof(bad),rgba,sizeof(rgba),&image),"QOI decoder rejects invalid channel metadata");}
    check(!xm_media_decode_qoi_rgba(qoi,sizeof(qoi),rgba,3U,&image),"QOI decoder rejects pixel output overrun");
    check(xm_media_decode_ppm_rgba(ppm3,sizeof(ppm3)-1U,rgba,sizeof(rgba),&image)&&image.width==1U&&rgba[0]==255U&&rgba[1]==0U&&rgba[2]==128U,"first-party PPM P3 decoder reads ASCII RGB and scales pixels");
    check(xm_media_decode_ppm_rgba(ppm6,sizeof(ppm6),rgba,sizeof(rgba),&image)&&rgba[0]==255U&&rgba[1]==0U&&rgba[2]==64U,"first-party PPM P6 decoder handles CRLF and binary samples");
    {const unsigned char bad[]="P6\n1 1\n256\nabc";check(!xm_media_decode_ppm_rgba(bad,sizeof(bad)-1U,rgba,sizeof(rgba),&image),"PPM decoder rejects unsupported 16-bit sample depths");}
    check(xm_media_decode_gif_rgba(gif,sizeof(gif),rgba,sizeof(rgba),&image)&&image.width==1U&&image.height==1U&&rgba[0]==0U&&rgba[3]==0U,"first-party GIF LZW decoder handles first-frame palette transparency");
    {unsigned char bad[sizeof(gif)];memcpy(bad,gif,sizeof(gif));bad[10U]=0xFFU;check(!xm_media_decode_gif_rgba(bad,sizeof(bad),rgba,sizeof(rgba),&image),"GIF decoder rejects truncated/invalid global palette metadata");}

    memcpy(png,"\x89PNG\r\n\x1a\n",8U); put32be(png_ihdr,1U); put32be(png_ihdr+4U,1U); png_ihdr[8]=8U; png_ihdr[9]=6U;
    png_len=append_png_chunk(png,8U,"IHDR",png_ihdr,sizeof(png_ihdr));
    {const unsigned char zlib_rgba[]={0x78U,0x01U,0x01U,0x05U,0x00U,0xFAU,0xFFU,0x00U,0xFFU,0x00U,0x00U,0xFFU,0x05U,0x00U,0x01U,0xFFU};png_len=append_png_chunk(png,png_len,"IDAT",zlib_rgba,sizeof(zlib_rgba));}
    png_len=append_png_chunk(png,png_len,"IEND",NULL,0U);
    check(xm_media_decode_png_rgba(png,png_len,rgba,sizeof(rgba),&image)&&image.width==1U&&rgba[0]==255U&&rgba[1]==0U&&rgba[2]==0U&&rgba[3]==255U,"first-party PNG decoder handles zlib stored DEFLATE and RGBA pixels");
    {unsigned char bad[128];memcpy(bad,png,png_len);bad[29]^=1U;check(!xm_media_decode_png_rgba(bad,png_len,rgba,sizeof(rgba),&image),"PNG decoder rejects CRC corruption");}
    check(xm_media_decode_jpeg_rgba(xm_test_baseline_jpeg,xm_test_baseline_jpeg_size,rgba,sizeof(rgba),&image)&&image.width==8U&&image.height==8U&&rgba[0]>180U&&rgba[1]<100U&&rgba[2]<100U&&rgba[3]==255U,"first-party baseline JPEG decoder reconstructs an RGB image");
    check(!xm_media_decode_jpeg_rgba(xm_test_baseline_420_jpeg,xm_test_baseline_420_jpeg_size,rgba,32U,&image),"baseline JPEG decoder rejects dimensions that exceed caller output capacity");
    { unsigned char large_rgba[17U*13U*4U]; check(xm_media_decode_jpeg_rgba(xm_test_baseline_420_jpeg,xm_test_baseline_420_jpeg_size,large_rgba,sizeof(large_rgba),&image)&&image.width==17U&&image.height==13U&&large_rgba[0]<100U&&large_rgba[1]>100U&&large_rgba[2]>140U,"baseline JPEG decoder handles 4:2:0 chroma sampling and non-multiple-of-eight dimensions"); }
    { unsigned char gray[9U*7U*4U]; check(xm_media_decode_jpeg_rgba(xm_test_baseline_gray_jpeg,xm_test_baseline_gray_jpeg_size,gray,sizeof(gray),&image)&&image.width==9U&&image.height==7U&&gray[0]>100U&&gray[0]==gray[1]&&gray[1]==gray[2]&&gray[3]==255U,"baseline JPEG decoder handles grayscale and partial edge blocks"); }
    { unsigned char progressive[sizeof(xm_test_baseline_jpeg)]; memcpy(progressive,xm_test_baseline_jpeg,sizeof(progressive)); for(size_t j=2U;j+1U<sizeof(progressive);++j) if(progressive[j]==0xFFU&&progressive[j+1U]==0xC0U){progressive[j+1U]=0xC2U;break;} check(!xm_media_decode_jpeg_rgba(progressive,sizeof(progressive),rgba,sizeof(rgba),&image),"baseline-only JPEG decoder explicitly rejects progressive SOF2 profile"); }
    check(!xm_media_decode_jpeg_rgba(xm_test_baseline_jpeg,xm_test_baseline_jpeg_size,rgba,8U,&image),"baseline JPEG decoder rejects a too-small destination buffer");
    { unsigned char truncated[64]; size_t take=xm_test_baseline_jpeg_size<sizeof(truncated)?xm_test_baseline_jpeg_size:sizeof(truncated); memcpy(truncated,xm_test_baseline_jpeg,take); check(!xm_media_decode_jpeg_rgba(truncated,take,rgba,sizeof(rgba),&image),"baseline JPEG decoder rejects a truncated stream"); }
    {
        const unsigned char dynamic_zlib[]={0x78U,0x9CU,0xEDU,0xCEU,0x21U,0x01U,0x00U,0x00U,0x0CU,0x04U,0xA1U,0xEBU,0x5FU,0x7AU,0x8BU,0xF1U,0x06U,0x81U,0xA7U,0xABU,0x5BU,0x4AU,0x40U,0x40U,0x40U,0x40U,0x40U,0x40U,0x40U,0x40U,0x40U,0x40U,0x40U,0x40U,0x40U,0x40U,0x60U,0x1DU,0x78U,0x54U,0x0DU,0xF8U,0x6AU};
        memset(png,0,sizeof(png)); memcpy(png,"\x89PNG\r\n\x1a\n",8U); put32be(png_ihdr,32U); put32be(png_ihdr+4U,32U); png_ihdr[8]=8U; png_ihdr[9]=6U;
        png_len=append_png_chunk(png,8U,"IHDR",png_ihdr,sizeof(png_ihdr)); png_len=append_png_chunk(png,png_len,"IDAT",dynamic_zlib,sizeof(dynamic_zlib)); png_len=append_png_chunk(png,png_len,"IEND",NULL,0U);
        check(xm_media_decode_png_rgba(png,png_len,rgba,sizeof(rgba),&image)&&image.width==32U&&image.height==32U&&rgba[0]==255U&&rgba[1]==0U&&rgba[2]==0U&&rgba[3]==255U&&rgba[31U*4U]==255U,"PNG decoder supports first-party dynamic-Huffman DEFLATE and row filters");
    }

    avi_len=build_small_avi(avi,sizeof(avi));
    check(avi_len>0U&&xm_media_parse_avi(avi,avi_len,&avi_info)&&avi_info.width==2U&&avi_info.height==2U&&avi_info.frame_count==1U&&avi_info.native_raw_video,"first-party AVI parser identifies uncompressed 24-bit video and frame timing");
    check(xm_media_avi_decode_next_frame(avi,avi_len,&avi_info,&avi_cursor,rgba,sizeof(rgba),&image)==1&&image.width==2U&&image.height==2U&&rgba[0]==255U&&rgba[1]==0U&&rgba[2]==0U,"first-party AVI demux decodes a BGR24 frame into RGBA");
    check(xm_media_avi_decode_next_frame(avi,avi_len,&avi_info,&avi_cursor,rgba,sizeof(rgba),&image)==0,"AVI frame iterator reports clean EOF");
    {unsigned char bad[256];memcpy(bad,avi,avi_len);put32le(bad+4U,0xFFFFFFFFU);check(!xm_media_parse_avi(bad,avi_len,&avi_info),"AVI parser rejects RIFF size beyond the available file");}


    /* Construct ftyp + moov(mvhd + trak(mdia(hdlr))): 40 bytes of valid, small metadata. */
    put32be(mp4,16U);memcpy(mp4+4U,"ftyp",4U);memcpy(mp4+8U,"isom",4U);put32be(mp4+12U,0U);
    /* This minimal file only validates top-level structural scanning; missing moov is still a valid zero-duration fragmented header. */
    check(xm_media_parse_mp4(mp4,16U,&media)&&media.complete==1U,"MP4 parser validates ftyp and bounded top-level box lengths");
    {unsigned char bad[16];memcpy(bad,mp4,sizeof(bad));put32be(bad,99U);check(!xm_media_parse_mp4(bad,sizeof(bad),&media),"MP4 parser rejects box lengths outside the supplied buffer");}
    {
        unsigned char full[100]={0};
        put32be(full,16U);memcpy(full+4U,"ftyp",4U);memcpy(full+8U,"isom",4U);
        put32be(full+16U,84U);memcpy(full+20U,"moov",4U);
        put32be(full+24U,28U);memcpy(full+28U,"mvhd",4U);put32be(full+44U,1000U);put32be(full+48U,60000U);
        put32be(full+52U,48U);memcpy(full+56U,"trak",4U);
        put32be(full+60U,40U);memcpy(full+64U,"mdia",4U);
        put32be(full+68U,32U);memcpy(full+72U,"hdlr",4U);memcpy(full+84U,"vide",4U);
        check(xm_media_parse_mp4(full,sizeof(full),&media)&&media.has_video==1U&&media.duration_ms==60000U,"MP4 parser walks bounded containers and reads movie duration/video handler");
    }

    check(xm_media_parse_mp3_header(mp3h,sizeof(mp3h),&mp3)&&mp3.sample_rate==44100U&&mp3.layer==3U&&mp3.frame_bytes>100U,"MP3 parser reads MPEG-1 Layer III frame metadata");
    {unsigned char bad[4]={0,0,0,0};check(!xm_media_parse_mp3_header(bad,sizeof(bad),&mp3),"MP3 parser rejects invalid sync headers");}
    check(xm_media_parse_adts_header(adtsh,sizeof(adtsh),&adts)&&adts.sample_rate==44100U&&adts.channels==2U&&adts.frame_bytes==7U,"AAC ADTS parser reads sampling/channel/frame metadata");
    {unsigned char bad[7];memcpy(bad,adtsh,sizeof(bad));bad[2]=(unsigned char)((bad[2]&0xC3U)|0x3CU);check(!xm_media_parse_adts_header(bad,sizeof(bad),&adts),"AAC ADTS parser rejects reserved sample-rate index");}
    check(xm_media_parse_ts_packet(tsb,sizeof(tsb),&ts)&&ts.pid==0x100U&&ts.has_payload==1U&&ts.payload_offset==4U,"MPEG-TS parser validates one 188-byte packet and exposes payload offset");
    {unsigned char bad[188];memcpy(bad,tsb,sizeof(bad));bad[0]=0U;check(!xm_media_parse_ts_packet(bad,sizeof(bad),&ts),"MPEG-TS parser rejects invalid packet sync");}

    check(xm_media_parse_hls(playlist,strlen(playlist),&hls)&&hls.segment_count==2U&&hls.has_endlist==1U&&hls.duration_ms==10500U&&hls.media_sequence==7U,"HLS parser reports VOD duration, sequence and segment count");
    {const char *live="#EXTM3U\n#EXTINF:6,\na.ts\n";check(xm_media_parse_hls(live,strlen(live),&hls)&&hls.is_live==1U,"HLS parser identifies playlists without ENDLIST as live");}
    {const char *key="#EXTM3U\n#EXT-X-KEY:METHOD=AES-128,URI=\"key\"\n#EXTINF:1,\na.ts\n#EXT-X-ENDLIST\n";check(xm_media_parse_hls(key,strlen(key),&hls)&&hls.encrypted==1U,"HLS parser flags encrypted playlists rather than bypassing protection");}
    {const char *key="#EXTM3U\n#EXT-X-KEY:METHOD=NONE\n#EXTINF:1,\na.ts\n#EXT-X-ENDLIST\n";check(xm_media_parse_hls(key,strlen(key),&hls)&&hls.encrypted==0U,"HLS METHOD=NONE is not misclassified as encrypted");}
    {char raw[]={'#','E','X','T','M','3','U','\n','#','E','X','T','I','N','F',':','1',',','x','\n','a','.','t','s','\n','#','E','X','T','-','X','-','E','N','D','L','I','S','T','\n'};check(xm_media_parse_hls(raw,sizeof(raw),&hls)&&hls.segment_count==1U,"HLS parser respects explicit length for non-NUL-terminated input");}
    {const char *range="#EXTM3U\n#EXT-X-BYTERANGE:100@0\n#EXTINF:1,\na.ts\n#EXT-X-ENDLIST\n";check(xm_media_parse_hls(range,strlen(range),&hls)&&hls.has_byterange==1U,"HLS parser flags byte-range segments for explicit policy handling");}
    {const char *master="#EXTM3U\n#EXT-X-STREAM-INF:BANDWIDTH=300000\nlow.m3u8\n#EXT-X-STREAM-INF:BANDWIDTH=800000\nhigh.m3u8\n";check(xm_media_parse_hls(master,strlen(master),&hls)&&hls.is_master==1U&&hls.variant_count==2U,"HLS parser counts master playlist variants");}
    check(!xm_media_parse_hls("not a playlist",14U,&hls),"HLS parser rejects bodies without EXTM3U header");
    {char big[XM_MAX_HLS_BYTES+1U];memset(big,'x',sizeof(big));check(!xm_media_parse_hls(big,sizeof(big),&hls),"HLS parser rejects manifests over the hard memory cap");}

    {unsigned char bad[188];memcpy(bad,tsb,sizeof(bad));bad[3]=0x00U;check(!xm_media_parse_ts_packet(bad,sizeof(bad),&ts),"MPEG-TS parser rejects reserved adaptation control");}
    {unsigned char bad[188];memcpy(bad,tsb,sizeof(bad));bad[3]=0x30U;bad[4]=184U;check(!xm_media_parse_ts_packet(bad,sizeof(bad),&ts),"MPEG-TS parser rejects adaptation fields beyond packet end");}
    {unsigned char bad[70];memcpy(bad,bmp,sizeof(bad));put32le(bad+10U,20U);check(!xm_media_decode_bmp_rgba(bad,sizeof(bad),rgba,sizeof(rgba),&image),"BMP decoder refuses pixel data overlapping the header");}
    {unsigned char bad[27];memcpy(bad,qoi,sizeof(bad));bad[26]=0U;check(!xm_media_decode_qoi_rgba(bad,sizeof(bad),rgba,sizeof(rgba),&image),"QOI decoder validates the required end marker");}
    {unsigned char bad[27];memcpy(bad,qoi,sizeof(bad));put32be(bad+4U,0xFFFFFFFFU);check(!xm_media_decode_qoi_rgba(bad,sizeof(bad),rgba,sizeof(rgba),&image),"QOI decoder rejects pixel-count overflow");}
    {const unsigned char sig[]="WEBVTT\n";check(xm_media_probe(sig,sizeof(sig)-1U,NULL,NULL,&media)&&media.container==XM_CONTAINER_WEBVTT,"WebVTT subtitles are detected from content signature");}
    {const char *vtt="WEBVTT\r\n\r\nNOTE generated fixture\r\nnot a cue\r\n\r\nintro\r\n00:00:01.000 --> 00:00:02.500 line:90%\r\nHello subtitle\r\nsecond line\r\n\r\n00:02.500 --> 00:03.000\r\nNext cue\r\n\r\n";check(xm_media_webvtt_get_cue(vtt,strlen(vtt),0U,&cue)==1&&cue.start_ms==1000U&&cue.end_ms==2500U&&cue.text_length>strlen("Hello subtitle")&&memcmp(vtt+cue.text_offset,"Hello subtitle",strlen("Hello subtitle"))==0,"WebVTT parser skips NOTE blocks and returns multiline cue timing/text slice");check(xm_media_webvtt_find_active_cue(vtt,strlen(vtt),2000U,&cue)==1&&cue.start_ms==1000U,"WebVTT active-cue lookup selects a cue by playback timestamp");check(xm_media_webvtt_find_active_cue(vtt,strlen(vtt),2500U,&cue)==1&&cue.start_ms==2500U,"WebVTT cue end is exclusive and the next cue begins at its start");check(xm_media_webvtt_find_active_cue(vtt,strlen(vtt),4000U,&cue)==0,"WebVTT active-cue lookup returns no cue outside all intervals");check(xm_media_webvtt_get_cue("not VTT",7U,0U,&cue)==-1,"WebVTT parser rejects input without a valid header");}
    {const unsigned char sig[]="RIFFxxxxAVI ";check(xm_media_probe(sig,sizeof(sig)-1U,NULL,NULL,&media)&&media.container==XM_CONTAINER_AVI,"AVI is detected from RIFF form type");}
    {const unsigned char sig[]={0xFF,0xD8,0xFF,0xE0,0,0,0,0,0,0,0,0};check(xm_media_probe(sig,sizeof(sig),NULL,NULL,&media)&&media.container==XM_CONTAINER_JPEG,"JPEG is detected from file signature");}
    {const unsigned char sig[]="GIF89a123456";check(xm_media_probe(sig,sizeof(sig)-1U,NULL,NULL,&media)&&media.container==XM_CONTAINER_GIF,"GIF is detected from file signature");}

    xm_playback_init(&session);check(session.state==XM_PLAYBACK_EMPTY,"playback session initializes empty");
    memset(&media,0,sizeof(media));media.container=XM_CONTAINER_WAVE;media.kind=XM_KIND_AUDIO;media.has_audio=1U;media.duration_ms=1000U;
    check(xm_playback_load(&session,&media)&&session.state==XM_PLAYBACK_READY,"playback state machine loads a validated media description");
    check(xm_playback_play(&session,100U)&&session.state==XM_PLAYBACK_PLAYING,"playback transitions ready to playing");
    check(xm_playback_update(&session,350U)&&session.position_ms==250U,"playback timeline advances from caller-owned monotonic clock");
    check(xm_playback_pause(&session,500U)&&session.state==XM_PLAYBACK_PAUSED&&session.position_ms==400U,"pause snapshots the playback clock");
    check(xm_playback_seek(&session,900U,510U)&&session.position_ms==900U,"seek clamps and updates timeline");
    check(xm_playback_play(&session,600U)&&xm_playback_update(&session,2000U)&&session.state==XM_PLAYBACK_ENDED&&session.position_ms==1000U,"playback reaches ended state and clamps to duration");
    xm_playback_stop(&session);check(session.state==XM_PLAYBACK_READY&&session.position_ms==0U,"stop rewinds a loaded session");
    check(!xm_playback_load(&session,NULL),"playback rejects null media descriptors");
    check(!xm_playback_pause(&session,2010U),"playback rejects pause when not playing");
    check(xm_playback_seek(&session,100000U,2020U)&&session.state==XM_PLAYBACK_ENDED&&session.position_ms==1000U,"seek clamps beyond-end requests to duration");
    xm_playback_stop(&session);check(xm_playback_play(&session,3000U)&&xm_playback_update(&session,2000U)&&session.position_ms==0U,"clock rollback does not underflow playback time");

    check(xm_media_decode_image_rgba(bmp,sizeof(bmp),rgba,sizeof(rgba),&image)&&image.width==2U,"first-party raster dispatcher selects BMP by signature");
    check(xm_media_decode_image_rgba(qoi,sizeof(qoi),rgba,sizeof(rgba),&image)&&image.width==1U,"first-party raster dispatcher selects QOI by signature");
    check(xm_media_decode_image_rgba(ppm3,sizeof(ppm3)-1U,rgba,sizeof(rgba),&image)&&image.width==1U,"first-party raster dispatcher selects PPM by signature");
    check(xm_media_decode_image_rgba(png,png_len,rgba,sizeof(rgba),&image)&&image.width>0U,"first-party raster dispatcher selects PNG by signature");
    check(xm_media_decode_image_rgba(gif,sizeof(gif),rgba,sizeof(rgba),&image)&&image.width==1U,"first-party raster dispatcher selects GIF by signature");
    check(xm_media_decode_image_rgba(xm_test_baseline_jpeg,xm_test_baseline_jpeg_size,rgba,sizeof(rgba),&image)&&image.width==8U,"first-party raster dispatcher selects baseline JPEG by signature");
    {const unsigned char unknown[]={0U,1U,2U,3U};check(!xm_media_decode_image_rgba(unknown,sizeof(unknown),rgba,sizeof(rgba),&image),"first-party raster dispatcher rejects unknown signatures");}

    printf("XenonMedia checks: %d; failures: %d\n",checks,failures);
    return failures==0?EXIT_SUCCESS:EXIT_FAILURE;
}
