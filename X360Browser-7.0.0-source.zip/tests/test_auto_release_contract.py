#!/usr/bin/env python3
"""Regression checks for the automatic post-build GitHub release pipeline."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
workflow = (ROOT / ".github/workflows/build-xex-from-zip.yml").read_text(encoding="utf-8")
updater = (ROOT / "platform/xbox360/xsdk/update_manager.c").read_text(encoding="utf-8")
manifest = (ROOT / "platform/xbox360/xsdk/update_manifest.c").read_text(encoding="utf-8")
version_h = (ROOT / "include/x360browser/version.hpp").read_text(encoding="utf-8")
version = (ROOT / "VERSION").read_text(encoding="utf-8").strip()

checks = {
    "source and embedded app versions match": f'X360BROWSER_VERSION_STRING "{version}"' in version_h,
    "release step is after the XEX package stage": workflow.index("Package XEX and all first-run runtime files") < workflow.index("Publish GitHub Release after successful XEX build"),
    "release is automatic on configured mainline branches": "refs/heads/main" in workflow and "refs/heads/master" in workflow and "refs/heads/principal" in workflow,
    "release uploads default.xex and SHA-256 sidecar": "default.xex" in workflow and "default.xex.sha256" in workflow,
    "release uploads install ZIP and SHA-256": "X360Browser-${{ needs.validate.outputs.version }}-Xbox360.zip" in workflow and "Xbox360.zip.sha256" in workflow,
    "release uses built-in writable token permissions": "contents: write" in workflow and "GH_TOKEN: ${{ github.token }}" in workflow,
    "release target tag derives from validated source version": "tag_name: v${{ needs.validate.outputs.version }}" in workflow,
    "existing tag cannot silently receive different XEX bytes": "has already been published with different bytes" in workflow and "cmp -s" in workflow,
    "client checks latest stable release automatically": "api.github.com/repos/David-Bryan010-png/X360Browser/releases/latest" in updater,
    "client validates release asset host and SHA-256": "X360Browser/releases/download/" in manifest and "sha256_file_hex" in updater,
    "client handles default.xex install names": 'UPDATE_XEX_DEFAULT "game:\\\\default.xex"' in updater,
    "workflow uses explicitly versioned trusted actions": all(item in workflow for item in ("actions/checkout@v7.0.1", "actions/cache@v6.1.0", "actions/upload-artifact@v7.0.2", "actions/download-artifact@v8.0.2", "softprops/action-gh-release@v3.0.3")),
}
failed = [label for label, ok in checks.items() if not ok]
for label, ok in checks.items():
    print(("PASS" if ok else "FAIL") + ": " + label)
if failed:
    raise SystemExit(f"FAIL: {len(failed)} automatic-release contract(s) failed")
print(f"PASS: all {len(checks)} automatic-release contracts")
