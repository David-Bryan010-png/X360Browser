#include "../platform/xbox360/xsdk/web_engine.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(void)
{
    WebEnginePage *page = (WebEnginePage *)calloc(1U, sizeof(*page));
    char error[192] = {0};
    int ok;
    if (page == NULL) {
        fputs("FAIL: page allocation\n", stderr);
        return 1;
    }
    if (!web_engine_init()) {
        fputs("FAIL: dispatcher initialization\n", stderr);
        free(page);
        return 1;
    }
    ok = web_engine_fetch("http://127.0.0.1:18765/page.html", page, error, sizeof(error));
    if (!ok) {
        fprintf(stderr, "FAIL: dispatcher fetch: %s\n", error);
        web_engine_shutdown();
        free(page);
        return 1;
    }
    if (page->backend_used != WEB_ENGINE_BACKEND_XENONWEB) {
        fputs("FAIL: XenonWeb first-party path was not selected\n", stderr);
        web_engine_shutdown();
        free(page);
        return 1;
    }
    if (page->used_fallback != 0) {
        fputs("FAIL: startup selection must not be reported as page-level fallback\n", stderr);
        web_engine_shutdown();
        free(page);
        return 1;
    }
    if (page->fallback_reason[0] != '\0') {
        fputs("FAIL: first-party single-engine path must not claim a fallback\n", stderr);
        web_engine_shutdown();
        free(page);
        return 1;
    }
    if (strcmp(web_engine_backend_label(), "XenonWeb + XenonNet transport (first-party page engine)") != 0) {
        fputs("FAIL: backend label does not describe the first-party engine\n", stderr);
        web_engine_shutdown();
        free(page);
        return 1;
    }
    web_engine_shutdown();
    free(page);
    puts("PASS: dispatcher uses only the first-party XenonWeb page engine");
    return 0;
}
