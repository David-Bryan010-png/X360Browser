#include "web_engine.h"
#include <stdio.h>
#include <string.h>

#ifdef X360BROWSER_TESTING
int web_engine_test_youtube_pick_stream(const char *json, size_t json_length, char *stream_url, size_t stream_capacity);
int web_engine_test_youtube_file_is_mp4(const char *path);
#endif

static int check(const char *url, int expected, const char *label)
{
    int actual = web_engine_is_youtube_url(url);
    if (actual != expected) {
        (void)fprintf(stderr, "FAIL: %s: %s (expected %d, got %d)\n", label, url, expected, actual);
        return 1;
    }
    (void)printf("PASS: YouTube URL recognition: %s\n", label);
    return 0;
}

int main(void)
{
    int failures = 0;
    failures += check("https://www.youtube.com/watch?v=dQw4w9WgXcQ", 1, "watch URL");
    failures += check("https://youtube.com/watch?list=abc&v=aqz-KE-bpKQ", 1, "watch URL with reordered query");
    failures += check("https://youtu.be/dQw4w9WgXcQ?si=share", 1, "short host URL");
    failures += check("https://m.youtube.com/shorts/dQw4w9WgXcQ?feature=share", 1, "mobile shorts URL");
    failures += check("https://www.youtube-nocookie.com/embed/dQw4w9WgXcQ", 1, "privacy embed URL");
    failures += check("https://youtube.com/live/dQw4w9WgXcQ", 1, "live URL");
    failures += check("http://youtu.be/dQw4w9WgXcQ", 1, "HTTP watch URL forwarded to HTTPS API");
    failures += check("https://youtube.com:443/watch?v=dQw4w9WgXcQ", 1, "valid default HTTPS port");
    failures += check("https://youtube.com/watch?v=dQw4w9WgXcQ#t=30", 1, "watch URL with time fragment");
    failures += check("https://youtube.com/watch?list=abc&v=aqz-KE-bpKQ#t=30", 1, "reordered query with fragment");
    failures += check("https://music.youtube.com/watch?v=dQw4w9WgXcQ", 1, "YouTube Music watch URL");
    failures += check("https://youtube.com:evil/watch?v=dQw4w9WgXcQ", 0, "reject nonnumeric port");
    failures += check("https://youtube.com:/watch?v=dQw4w9WgXcQ", 0, "reject empty port");
    failures += check("https://youtube.com:99999/watch?v=dQw4w9WgXcQ", 0, "reject port overflow");
    failures += check("https://youtube.com:443evil/watch?v=dQw4w9WgXcQ", 0, "reject malformed port suffix");
    failures += check("https://youtube.com/watch?v=short", 0, "reject short video ID");
    failures += check("https://youtube.com.evil.example/watch?v=dQw4w9WgXcQ", 0, "reject lookalike hostname");
    failures += check("https://notyoutube.example/watch?v=dQw4w9WgXcQ", 0, "reject unrelated hostname");
    failures += check("https://user@youtube.com/watch?v=dQw4w9WgXcQ", 0, "reject userinfo hostname ambiguity");
    failures += check("javascript:alert(1)", 0, "reject script URL");
    failures += check("https://youtube.com/watch", 0, "reject watch URL without video ID");
#ifdef X360BROWSER_TESTING
    {
        static const char formats[] =
            "{\"videoId\":\"dQw4w9WgXcQ\",\"formatStreams\":["
            "{\"url\":\"https://r1.googlevideo.com/videoplayback?itag=18\\u0026x=1\","
            "\"type\":\"video/mp4; codecs=\\\"avc1.64001F, mp4a.40.2\\\"\","
            "\"container\":\"mp4\",\"qualityLabel\":\"360p\"},"
            "{\"url\":\"https://r2.googlevideo.com/videoplayback?itag=22\\u0026x=1\","
            "\"type\":\"video/mp4; codecs=\\\"avc1.64001F, mp4a.40.2\\\"\","
            "\"container\":\"mp4\",\"qualityLabel\":\"480p\"},"
            "{\"url\":\"https://r3.googlevideo.com/videoplayback?itag=37\","
            "\"type\":\"video/mp4; codecs=\\\"avc1.64001F, mp4a.40.2\\\"\","
            "\"container\":\"mp4\",\"qualityLabel\":\"1080p\"}]}";
        char stream[2048] = {0};
        if (web_engine_test_youtube_pick_stream(formats, sizeof(formats) - 1U, stream, sizeof(stream)) &&
            strstr(stream, "r2.googlevideo.com") != NULL && strstr(stream, "itag=22") != NULL &&
            strstr(stream, "&x=1") != NULL) {
            (void)printf("PASS: YouTube stream parser chooses highest compatible <=480p muxed MP4\n");
        } else {
            (void)fprintf(stderr, "FAIL: YouTube stream parser should select 480p MP4, got %s\n", stream);
            ++failures;
        }
        {
            static const char evil[] =
                "{\"formatStreams\":[{\"url\":\"https://googlevideo.com.evil.test/videoplayback\","
                "\"type\":\"video/mp4; codecs=\\\"avc1, mp4a\\\"\","
                "\"container\":\"mp4\",\"qualityLabel\":\"360p\"}]}";
            if (!web_engine_test_youtube_pick_stream(evil, sizeof(evil) - 1U, stream, sizeof(stream)))
                (void)printf("PASS: YouTube stream parser rejects lookalike googlevideo hostname\n");
            else { (void)fprintf(stderr, "FAIL: rejected YouTube media host was accepted\n"); ++failures; }
        }
        {
            static const char unsupported[] =
                "{\"formatStreams\":[{\"url\":\"https://r1.googlevideo.com/videoplayback\","
                "\"type\":\"video/mp4; codecs=\\\"av01, mp4a\\\"\","
                "\"container\":\"mp4\",\"qualityLabel\":\"360p\"}]}";
            if (!web_engine_test_youtube_pick_stream(unsupported, sizeof(unsupported) - 1U, stream, sizeof(stream)))
                (void)printf("PASS: YouTube stream parser rejects AV1-only streams\n");
            else { (void)fprintf(stderr, "FAIL: unsupported AV1 stream was accepted\n"); ++failures; }
        }
        {
            static const char bad_port[] =
                "{\"formatStreams\":[{\"url\":\"https://r2.googlevideo.com:444/videoplayback\","
                "\"type\":\"video/mp4; codecs=\\\"avc1, mp4a\\\"\","
                "\"container\":\"mp4\",\"qualityLabel\":\"480p\"}]}";
            if (!web_engine_test_youtube_pick_stream(bad_port, sizeof(bad_port) - 1U, stream, sizeof(stream)))
                (void)printf("PASS: YouTube stream parser rejects nonstandard HTTPS ports\n");
            else { (void)fprintf(stderr, "FAIL: nonstandard stream port was accepted\n"); ++failures; }
        }
        {
            static const char truncated[] =
                "{\"formatStreams\":[{\"url\":\"https://r2.googlevideo.com/videoplayback\","
                "\"type\":\"video/mp4; codecs=\\\"avc1, mp4a\\\"\","
                "\"container\":\"mp4\",\"qualityLabel\":\"480p\"}";
            if (!web_engine_test_youtube_pick_stream(truncated, sizeof(truncated) - 1U, stream, sizeof(stream)))
                (void)printf("PASS: YouTube stream parser rejects truncated JSON/arrays\n");
            else { (void)fprintf(stderr, "FAIL: truncated JSON was accepted\n"); ++failures; }
        }
        {
            static const unsigned char good_mp4[] = {
                0x00U, 0x00U, 0x00U, 0x10U, 'f', 't', 'y', 'p', 'i', 's', 'o', 'm', 0x00U, 0x00U, 0x02U, 0x00U
            };
            static const unsigned char bad_mp4[] = "<html>not mp4</html>";
            const char *path = "youtube-mp4-signature-test.bin";
            FILE *file = fopen(path, "wb");
            if (file == NULL || fwrite(good_mp4, 1U, sizeof(good_mp4), file) != sizeof(good_mp4)) {
                (void)fprintf(stderr, "FAIL: could not write MP4 signature fixture\n");
                ++failures;
            }
            if (file != NULL) (void)fclose(file);
            if (web_engine_test_youtube_file_is_mp4(path))
                (void)printf("PASS: YouTube media accepts a valid MP4 ftyp box\n");
            else { (void)fprintf(stderr, "FAIL: valid MP4 ftyp header was rejected\n"); ++failures; }
            file = fopen(path, "wb");
            if (file == NULL || fwrite(bad_mp4, 1U, sizeof(bad_mp4) - 1U, file) != sizeof(bad_mp4) - 1U) {
                (void)fprintf(stderr, "FAIL: could not write bad-media fixture\n");
                ++failures;
            }
            if (file != NULL) (void)fclose(file);
            if (!web_engine_test_youtube_file_is_mp4(path))
                (void)printf("PASS: YouTube media rejects an HTML payload with misleading extension\n");
            else { (void)fprintf(stderr, "FAIL: non-MP4 payload passed signature check\n"); ++failures; }
            (void)remove(path);
        }
    }
#endif
    if (failures != 0) (void)fprintf(stderr, "YouTube compatibility checks failed: %d\n", failures);
    return failures == 0 ? 0 : 1;
}
