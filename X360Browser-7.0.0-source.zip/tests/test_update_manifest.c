#include "../platform/xbox360/xsdk/update_manifest.h"
#include <stdio.h>
#include <string.h>

static int failures;
static void check(int condition, const char *name)
{
    if (condition) printf("PASS: %s\n", name);
    else { printf("FAIL: %s\n", name); ++failures; }
}

int main(void)
{
    static const char json_digest[] =
        "{\"tag_name\":\"v5.2.1\",\"assets\":["
        "{\"name\":\"default.xex\",\"digest\":\"sha256:0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef\","
        "\"browser_download_url\":\"https://github.com/David-Bryan010-png/X360Browser/releases/download/v5.2.1/default.xex\"}] }";
    static const char json_checksum[] =
        "{\"tag_name\":\"5.2.2\",\"assets\":["
        "{\"name\":\"default.xex\",\"digest\":null,\"browser_download_url\":\"https://github.com/David-Bryan010-png/X360Browser/releases/download/5.2.2/default.xex\"},"
        "{\"name\":\"default.xex.sha256\",\"browser_download_url\":\"https://github.com/David-Bryan010-png/X360Browser/releases/download/5.2.2/default.xex.sha256\"}] }";
    static const char json_untrusted[] =
        "{\"tag_name\":\"5.2.3\",\"assets\":["
        "{\"name\":\"default.xex\",\"digest\":\"sha256:0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef\","
        "\"browser_download_url\":\"https://example.org/evil.xex\"}]}";
    static const char checksum[] = "0123456789ABCDEF0123456789ABCDEF0123456789ABCDEF0123456789ABCDEF *default.xex\n";
    static const char bad_leading_zero[] = "{\"tag_name\":\"v06.2.0\",\"assets\":[{\"name\":\"default.xex\",\"digest\":\"sha256:0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef\",\"browser_download_url\":\"https://github.com/David-Bryan010-png/X360Browser/releases/download/v06.2.0/default.xex\"}]}";
    static const char bad_legacy_name[] = "{\"tag_name\":\"v6.2.0\",\"assets\":[{\"name\":\"X360Browser.xex\",\"digest\":\"sha256:0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef\",\"browser_download_url\":\"https://github.com/David-Bryan010-png/X360Browser/releases/download/v6.2.0/X360Browser.xex\"}]}";
    X360UpdateManifest manifest;
    char parsed_hash[65] = {0};
    check(x360_update_parse_github_release(json_digest, &manifest), "GitHub latest-release JSON parses digest-based XEX asset");
    check(strcmp(manifest.version, "5.2.1") == 0, "release tag strips leading v and yields semantic version");
    check(strlen(manifest.sha256) == 64U && manifest.sha256[0] == '0', "SHA-256 digest field is normalized");
    check(x360_update_parse_github_release(json_checksum, &manifest), "release asset fallback checksum URL is recognized");
    check(manifest.sha256[0] == '\0' && strstr(manifest.checksum_url, "default.xex.sha256") != NULL,
          "checksum fallback remains available when GitHub digest is null");
    check(x360_update_parse_checksum(checksum, parsed_hash), "sha256sum text parses");
    check(parsed_hash[10] == 'a', "checksum is normalized to lowercase hex");
    check(!x360_update_parse_github_release(json_untrusted, &manifest), "untrusted executable URL is rejected");
    check(!x360_update_parse_github_release(bad_leading_zero, &manifest), "noncanonical semantic versions with leading zeroes are rejected");
    check(!x360_update_parse_github_release(bad_legacy_name, &manifest), "legacy X360Browser.xex asset is rejected; releases must provide default.xex");
    check(!x360_update_parse_checksum("not a sha256 hash", parsed_hash), "malformed checksum is rejected");
    if (failures != 0) return 1;
    puts("PASS: all GitHub update-manifest tests passed");
    return 0;
}
