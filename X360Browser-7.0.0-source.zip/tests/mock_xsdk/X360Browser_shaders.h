#ifndef MOCK_X360BROWSER_SHADERS_H
#define MOCK_X360BROWSER_SHADERS_H
#include <stdint.h>
#include "xsdk/gpu.h"
#include "xsdk/shader.h"
typedef struct { uint32_t reg; float values[4]; } XsdkShaderLiteral;
typedef struct {
    const uint32_t *container;
    uint32_t container_bytes;
    uint32_t type;
    const XsdkShaderLiteral *literals;
    uint32_t literal_count;
} XsdkBuiltShader;
static inline void xsdk_built_shader_set_literals(const XsdkBuiltShader *shader)
{
    for (uint32_t i = 0; i < shader->literal_count; ++i) {
        if (shader->type == XSDK_SHADER_VERTEX)
            xsdk_gpu_set_vertex_constants(shader->literals[i].reg, shader->literals[i].values, 1U);
        else xsdk_gpu_set_pixel_constants(shader->literals[i].reg, shader->literals[i].values, 1U);
    }
}
static const uint32_t page_vert_container[] = {0U};
static const XsdkBuiltShader page_vert = {page_vert_container,sizeof(page_vert_container),XSDK_SHADER_VERTEX,0,0};
static const uint32_t page_frag_container[] = {0U};
static const XsdkBuiltShader page_frag = {page_frag_container,sizeof(page_frag_container),XSDK_SHADER_PIXEL,0,0};
enum { PAGE_FRAG_SAMPLER_0_0 = 0 };
#endif
