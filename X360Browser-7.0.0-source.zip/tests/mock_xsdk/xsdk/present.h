#include "kernel.h"
enum { XSDK_DISPLAY_720P=1 }; NTSTATUS xsdk_present_open(uint32_t,uint32_t,uint32_t,uint32_t*,uint32_t*); NTSTATUS xsdk_present_begin(uint32_t*,uint32_t); void xsdk_present_end(void); void xsdk_present_close(void);
