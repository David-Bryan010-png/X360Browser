#include "kernel.h"
NTSTATUS xsdk_text_open(void); void xsdk_text_close(void); void xsdk_text_draw(int32_t,int32_t,uint32_t,uint32_t,const char*);
