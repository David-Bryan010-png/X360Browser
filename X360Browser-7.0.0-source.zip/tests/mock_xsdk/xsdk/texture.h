#ifndef MOCK_XSDK_TEXTURE_H
#define MOCK_XSDK_TEXTURE_H
#include <stdbool.h>
#include <stdint.h>
#include "kernel.h"
enum { XSDK_FORMAT_A8R8G8B8 = 0, XSDK_FILTER_POINT = 0, XSDK_FILTER_LINEAR = 1,
       XSDK_ADDRESS_CLAMP = 2, XSDK_BORDER_BLACK = 0 };
typedef struct XsdkTexture {
    volatile uint32_t *texels;
    uint32_t address, size_bytes, format, width, height, levels, dimension, depth, pitch;
    bool tiled;
    uint32_t mip_offset_bytes;
    uint32_t fetch[6];
} XsdkTexture;
typedef struct {
    uint32_t mag_filter, min_filter, mip_filter, address_u, address_v;
    float lod_bias;
    uint32_t max_anisotropy, min_level, level_count, address_w, border;
} XsdkSampler;
typedef struct XsdkSamplerState { uint32_t fetch[6]; } XsdkSamplerState;
NTSTATUS xsdk_texture_create(XsdkTexture *texture, uint32_t format, uint32_t width,
                             uint32_t height, uint32_t levels, bool tiled);
void xsdk_texture_upload(XsdkTexture *texture, uint32_t level, const void *data, uint32_t row_bytes);
void xsdk_texture_sampler_state(XsdkSamplerState *state, const XsdkSampler *sampler);
void xsdk_texture_free(XsdkTexture *texture);
#endif
