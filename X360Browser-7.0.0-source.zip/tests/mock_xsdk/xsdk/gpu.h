#ifndef MOCK_XSDK_GPU_H
#define MOCK_XSDK_GPU_H
#include <stdbool.h>
#include <stdint.h>
#include "kernel.h"
typedef struct XsdkShader XsdkShader;
typedef struct XsdkTexture XsdkTexture;
typedef struct XsdkSamplerState XsdkSamplerState;
enum { XSDK_PRIMITIVE_TRIANGLE_STRIP = 6 };
NTSTATUS xsdk_gpu_open(void);
NTSTATUS xsdk_gpu_close(void);
void xsdk_gpu_set_target(uint32_t width, uint32_t height);
void xsdk_gpu_resolve(uint32_t address, uint32_t width, uint32_t height, uint32_t clear_argb);
volatile uint32_t *xsdk_gpu_alloc(uint32_t size_bytes);
void xsdk_gpu_free(volatile uint32_t *memory);
uint32_t xsdk_gpu_address(volatile const uint32_t *memory);
void xsdk_gpu_invalidate(uint32_t address, uint32_t size_bytes);
uint32_t xsdk_gpu_fence(void);
NTSTATUS xsdk_gpu_wait(uint32_t fence, uint32_t timeout_ms);
void xsdk_gpu_set_shaders(const XsdkShader *vertex, const XsdkShader *pixel);
void xsdk_gpu_set_texture(uint32_t slot, const XsdkTexture *texture, const XsdkSamplerState *sampler);
void xsdk_gpu_set_vertices(uint32_t stream, uint32_t address, uint32_t size_bytes);
void xsdk_gpu_draw(uint32_t primitive_type, uint32_t vertex_count);
void xsdk_gpu_set_vertex_constants(uint32_t first, const float *values, uint32_t count);
void xsdk_gpu_set_pixel_constants(uint32_t first, const float *values, uint32_t count);
#endif
