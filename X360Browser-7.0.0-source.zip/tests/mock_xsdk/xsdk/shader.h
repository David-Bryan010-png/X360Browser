#ifndef MOCK_XSDK_SHADER_H
#define MOCK_XSDK_SHADER_H
#include <stdbool.h>
#include <stdint.h>
#include "kernel.h"
enum { XSDK_SHADER_VERTEX = 0, XSDK_SHADER_PIXEL = 1, XSDK_USAGE_POSITION = 0, XSDK_USAGE_TEXCOORD = 5,
       XSDK_VERTEX_FLOAT1 = 0, XSDK_VERTEX_FLOAT2 = 1, XSDK_VERTEX_FLOAT3 = 2, XSDK_VERTEX_FLOAT4 = 3 };
typedef struct XsdkShader {
    volatile uint32_t *microcode;
    uint32_t address;
    uint32_t dword_count;
    uint32_t type;
    uint32_t program_control;
    uint32_t context_misc;
    const uint32_t *fetches;
    uint32_t fetch_count;
    const uint32_t *interpolators;
    uint32_t interpolator_count;
    const uint32_t *export_slots;
    uint32_t export_slot_count;
    const uint32_t *source;
    const uint32_t *table;
    uint32_t table_bytes;
    bool instanced;
    uint32_t instance_constant;
} XsdkShader;
typedef struct {
    uint32_t usage, usage_index, format, stream, offset_bytes;
    uint8_t components[4];
    bool per_instance;
} XsdkVertexElement;
NTSTATUS xsdk_shader_load(XsdkShader *shader, const uint32_t *container, uint32_t size_bytes);
NTSTATUS xsdk_shader_set_vertex_layout(XsdkShader *shader, const XsdkVertexElement *elements,
                                      uint32_t element_count, const uint32_t *stream_strides);
void xsdk_shader_free(XsdkShader *shader);
#endif
