#include "kernel.h"
#include <stddef.h>
enum { XSDK_XAM_USER_NONE=254, XSDK_XAM_GAMERTAG_BYTES=16 };
typedef struct { uint32_t opaque[8]; } XAM_OVERLAPPED;
bool xsdk_system_ui_open(void); void xsdk_xam_prepare(XAM_OVERLAPPED*); uint32_t xsdk_xam_signed_in_user(uint32_t*,char[16]); uint32_t xsdk_xam_keyboard(uint32_t,const uint16_t*,const uint16_t*,const uint16_t*,uint16_t*,uint32_t,XAM_OVERLAPPED*); uint32_t xsdk_xam_returned(XAM_OVERLAPPED*,uint32_t); uint32_t xsdk_xam_wait(XAM_OVERLAPPED*,uint32_t,uint32_t*); int xsdk_launch(const char*,const void*,size_t);
