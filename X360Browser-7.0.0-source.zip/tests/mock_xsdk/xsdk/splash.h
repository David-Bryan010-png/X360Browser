#include <stdint.h>
void xsdk_splash_show(uint32_t);
