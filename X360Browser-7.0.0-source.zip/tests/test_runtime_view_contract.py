#!/usr/bin/env python3
"""Static regressions: graphical-first page flow, no text dump fallback."""
from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[1]
main = (ROOT / "platform/xbox360/xsdk/main.c").read_text(encoding="utf-8")
checks = {
    "successful HTML page selects graphical mode independent of renderer readiness": "g_show_visual = !g_page.is_direct_resource;" in main,
    "text-reader state was removed": "g_show_reader" not in main and "show_reader" not in main,
    "legacy text-reader label was removed": "NATIVEPLUS TEXT READER VIEW" not in main and "NATIVEPLUS READER VIEW" not in main,
    "page body is never drawn from extracted plain-text field": "draw_scrolled_page_text(page->text" not in main,
    "graphical frame is logged": '"X360Browser: GRAPHICAL FRAME URL=' in main,
    "navigation failures have a dedicated error surface": '"PAGE COULD NOT BE LOADED"' in main,
    "renderer failure is explicit and does not switch to reader": '"GRAPHICAL RENDERER UNAVAILABLE"' in main and "text-reader fallback disabled" in main,
    "resource URLs are shown as resource cards": '"WEB RESOURCE"' in main,
    "player lookup stays deferred until playback": 'if (strcasecmp(g_video_player_path, "auto") == 0) resolve_auto_media_player();' in main,
    "page state invalidates graphics after response assignment": "g_page = *downloaded;\n        web_visual_renderer_invalidate();" in main,
    "same-URL reload resets graphical frame telemetry": "g_logged_visual_url[0] = '\\0';" in main,
}
failed=[]
for label, ok in checks.items():
    print(f'{"PASS" if ok else "FAIL"}: {label}')
    if not ok: failed.append(label)
if failed:
    print(f"FAIL: {len(failed)} runtime view contract checks failed", file=sys.stderr)
    raise SystemExit(1)
print(f"PASS: all {len(checks)} runtime view contract checks")
