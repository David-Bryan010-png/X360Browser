#include "xm_playback.h"
#include <string.h>

void xm_playback_init(XmPlaybackSession *s) { if (s != NULL) memset(s, 0, sizeof(*s)); }
int xm_playback_load(XmPlaybackSession *s, const XmMediaInfo *m) {
    if (s == NULL || m == NULL || m->container == XM_CONTAINER_UNKNOWN || (m->has_audio == 0U && m->has_video == 0U && m->kind != XM_KIND_AUDIO && m->kind != XM_KIND_VIDEO)) return 0;
    memset(s, 0, sizeof(*s)); s->media = *m; s->duration_ms = m->duration_ms; s->has_audio = m->has_audio; s->has_video = m->has_video; s->state = XM_PLAYBACK_READY; return 1;
}
int xm_playback_play(XmPlaybackSession *s, uint64_t now) {
    if (s == NULL || (s->state != XM_PLAYBACK_READY && s->state != XM_PLAYBACK_PAUSED)) return 0;
    if (s->duration_ms != 0U && s->position_ms >= s->duration_ms) s->position_ms = 0U;
    s->last_clock_ms = now; s->state = XM_PLAYBACK_PLAYING; return 1;
}
int xm_playback_pause(XmPlaybackSession *s, uint64_t now) {
    if (s == NULL || s->state != XM_PLAYBACK_PLAYING) return 0;
    (void)xm_playback_update(s, now); if (s->state == XM_PLAYBACK_PLAYING) s->state = XM_PLAYBACK_PAUSED; return 1;
}
int xm_playback_seek(XmPlaybackSession *s, uint64_t target, uint64_t now) {
    if (s == NULL || s->state == XM_PLAYBACK_EMPTY || s->state == XM_PLAYBACK_FAILED) return 0;
    if (s->duration_ms != 0U && target > s->duration_ms) target = s->duration_ms;
    s->position_ms = target; s->last_clock_ms = now;
    if (s->duration_ms != 0U && target >= s->duration_ms) s->state = XM_PLAYBACK_ENDED;
    else if (s->state == XM_PLAYBACK_ENDED) s->state = XM_PLAYBACK_PAUSED;
    return 1;
}
void xm_playback_stop(XmPlaybackSession *s) { if (s == NULL) return; s->position_ms=0U; s->last_clock_ms=0U; if(s->state!=XM_PLAYBACK_EMPTY)s->state=XM_PLAYBACK_READY; }
int xm_playback_update(XmPlaybackSession *s, uint64_t now) {
    uint64_t delta;
    if(s==NULL||s->state!=XM_PLAYBACK_PLAYING)return 0;
    if(now<s->last_clock_ms){s->last_clock_ms=now;return 1;}
    delta=now-s->last_clock_ms;
    /* Large debugger/suspend jumps are not replayed as an unbounded catch-up burst. */
    if(delta>10000U)delta=10000U;
    if(UINT64_MAX-s->position_ms<delta)s->position_ms=UINT64_MAX;else s->position_ms+=delta;
    s->last_clock_ms=now;
    if(s->duration_ms!=0U&&s->position_ms>=s->duration_ms){s->position_ms=s->duration_ms;s->state=XM_PLAYBACK_ENDED;}
    return 1;
}
