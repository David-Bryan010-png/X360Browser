#ifndef XENONMEDIA_XM_MEDIA_H
#define XENONMEDIA_XM_MEDIA_H

/* First-party, bounded media inspection and elementary decoding primitives.
 * This module intentionally has no codec, browser-engine, or player dependency.
 * Parsing is defensive and callers own all buffers. */
#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#define XM_MAX_DIMENSION 4096U
#define XM_MAX_PIXELS (4096U * 4096U)
#define XM_MAX_BOXES 4096U
#define XM_MAX_HLS_SEGMENTS 512U
#define XM_MAX_HLS_BYTES (256U * 1024U)
#define XM_MAX_NESTING 12U

typedef enum {
    XM_KIND_UNKNOWN = 0,
    XM_KIND_IMAGE,
    XM_KIND_AUDIO,
    XM_KIND_VIDEO,
    XM_KIND_PLAYLIST,
    XM_KIND_SUBTITLE
} XmMediaKind;

typedef enum {
    XM_CONTAINER_UNKNOWN = 0,
    XM_CONTAINER_WAVE,
    XM_CONTAINER_AVI,
    XM_CONTAINER_ISO_BMFF,
    XM_CONTAINER_MPEG_TS,
    XM_CONTAINER_MATROSKA,
    XM_CONTAINER_MP3,
    XM_CONTAINER_AAC_ADTS,
    XM_CONTAINER_OGG,
    XM_CONTAINER_FLAC,
    XM_CONTAINER_HLS,
    XM_CONTAINER_MPEG_DASH,
    XM_CONTAINER_WEBVTT,
    XM_CONTAINER_BMP,
    XM_CONTAINER_PNG,
    XM_CONTAINER_JPEG,
    XM_CONTAINER_GIF,
    XM_CONTAINER_QOI,
    XM_CONTAINER_PPM
} XmContainer;

typedef enum {
    XM_CODEC_UNKNOWN = 0,
    XM_CODEC_PCM_U8,
    XM_CODEC_PCM_S16LE,
    XM_CODEC_IMA_ADPCM,
    XM_CODEC_MP3,
    XM_CODEC_AAC,
    XM_CODEC_AVC,
    XM_CODEC_HEVC,
    XM_CODEC_AV1,
    XM_CODEC_VP8,
    XM_CODEC_VP9,
    XM_CODEC_VORBIS,
    XM_CODEC_OPUS,
    XM_CODEC_FLAC,
    XM_CODEC_MJPEG,
    XM_CODEC_RAW_RGB
} XmCodec;

typedef struct {
    XmMediaKind kind;
    XmContainer container;
    XmCodec audio_codec;
    XmCodec video_codec;
    uint32_t width;
    uint32_t height;
    uint32_t sample_rate;
    uint32_t channels;
    uint32_t bits_per_sample;
    uint64_t duration_ms;
    uint64_t data_offset;
    uint64_t data_bytes;
    uint32_t frame_rate_num;
    uint32_t frame_rate_den;
    uint32_t stream_count;
    uint32_t segment_count;
    uint32_t variant_count;
    uint8_t has_audio;
    uint8_t has_video;
    uint8_t encrypted;
    uint8_t live;
    uint8_t complete;
    uint8_t supported_for_native_decode;
    uint8_t malformed;
} XmMediaInfo;

typedef struct {
    uint32_t width;
    uint32_t height;
    uint32_t frame_rate_num;
    uint32_t frame_rate_den;
    uint32_t frame_count;
    uint32_t frame_bytes;
    uint32_t video_stream_index;
    uint32_t bits_per_pixel;
    uint32_t compression;
    uint64_t duration_ms;
    size_t movi_offset;
    size_t movi_end;
    uint8_t native_raw_video;
    uint8_t top_down;
} XmAviInfo;

typedef struct {
    uint32_t sample_rate;
    uint16_t channels;
    uint16_t bits_per_sample;
    uint16_t block_align;
    uint16_t format_tag;
    uint16_t samples_per_block; /* nonzero for Microsoft IMA ADPCM format tag 0x0011 */
    uint64_t data_offset;
    uint64_t data_bytes;
    uint64_t total_samples;
    uint64_t duration_ms;
} XmWavInfo;

typedef struct {
    uint32_t width;
    uint32_t height;
    uint8_t channels;
} XmImageInfo;

typedef struct {
    uint16_t pid;
    uint8_t payload_unit_start;
    uint8_t adaptation_field_control;
    uint8_t continuity_counter;
    uint8_t has_payload;
    uint8_t has_adaptation;
    uint8_t discontinuity;
    size_t payload_offset;
} XmTsPacketInfo;

typedef struct {
    uint32_t sample_rate;
    uint32_t bitrate_kbps;
    uint32_t frame_bytes;
    uint32_t samples_per_frame;
    uint8_t channels;
    uint8_t mpeg_version; /* 1, 2, or 25 for MPEG 2.5 */
    uint8_t layer;        /* 1, 2, or 3 */
    uint8_t has_crc;
} XmMpegAudioFrameInfo;

typedef struct {
    uint32_t sample_rate;
    uint32_t frame_bytes;
    uint16_t channels;
    uint8_t profile;
    uint8_t samples_per_frame_index;
} XmAdtsInfo;

typedef struct {
    uint64_t start_ms;
    uint64_t end_ms;
    size_t text_offset; /* byte offset into the original, caller-owned WebVTT buffer */
    size_t text_length; /* cue text, may span lines; trailing line break is excluded */
} XmWebVttCue;

typedef struct {
    uint64_t duration_ms;
    uint32_t target_duration_s;
    uint32_t media_sequence;
    uint32_t segment_count;
    uint32_t variant_count;
    uint8_t is_master;
    uint8_t has_endlist;
    uint8_t is_live;
    uint8_t encrypted;
    uint8_t has_byterange;
    uint8_t has_map;
    uint8_t malformed;
} XmHlsInfo;

const char *xm_container_name(XmContainer container);
const char *xm_codec_name(XmCodec codec);
/* Sniff by signatures first, then MIME and URL extension. Does not decode. */
int xm_media_probe(const uint8_t *bytes, size_t length, const char *url,
                   const char *content_type, XmMediaInfo *info);
/* Parse common ISO-BMFF/MP4 headers and bounded track metadata. */
int xm_media_parse_mp4(const uint8_t *bytes, size_t length, XmMediaInfo *info);
/* Native AVI demux for uncompressed BI_RGB video (24/32 bpp). Returns one RGBA frame, 0 at EOF, -1 on malformed input. */
int xm_media_parse_avi(const uint8_t *bytes, size_t length, XmAviInfo *info);
int xm_media_avi_decode_next_frame(const uint8_t *bytes, size_t length, const XmAviInfo *info,
                                   size_t *cursor, uint8_t *rgba, size_t rgba_capacity,
                                   XmImageInfo *frame_info);
/* Parse RIFF/WAVE PCM format and data chunk with strict bounds. */
int xm_media_parse_wav(const uint8_t *bytes, size_t length, XmWavInfo *info);
/* Decode WAV PCM U8/S16LE or Microsoft IMA ADPCM (format tag 0x0011) into
 * caller-provided interleaved signed 16-bit samples. All output is capacity-bounded. */
int xm_media_decode_wav_pcm16(const uint8_t *bytes, size_t length,
                              int16_t *output, size_t output_capacity_samples,
                              size_t *samples_written, XmWavInfo *info);
/* First-party signature dispatcher for supported raster formats. It validates
 * signatures instead of trusting URLs/extensions, then calls the bounded decoder. */
int xm_media_decode_image_rgba(const uint8_t *bytes, size_t length,
                               uint8_t *rgba, size_t rgba_capacity,
                               XmImageInfo *info);
/* Decode uncompressed 24/32-bit BMP to RGBA8. Output must fit all pixels. */
int xm_media_decode_bmp_rgba(const uint8_t *bytes, size_t length,
                             uint8_t *rgba, size_t rgba_capacity,
                             XmImageInfo *info);
/* Decode QOI image (first-party decoder) to RGBA8. */
int xm_media_decode_qoi_rgba(const uint8_t *bytes, size_t length,
                             uint8_t *rgba, size_t rgba_capacity,
                             XmImageInfo *info);
/* Native PNG decoder: non-interlaced 8-bit grayscale/RGB/indexed/alpha PNG. */
int xm_media_decode_png_rgba(const uint8_t *bytes, size_t length,
                             uint8_t *rgba, size_t rgba_capacity,
                             XmImageInfo *info);
/* Decode the first GIF frame, including palette, transparency and interlace. */
int xm_media_decode_gif_rgba(const uint8_t *bytes, size_t length,
                             uint8_t *rgba, size_t rgba_capacity,
                             XmImageInfo *info);
/* Native 8-bit baseline sequential JPEG decoder (non-progressive, 1 or 3 components). */
int xm_media_decode_jpeg_rgba(const uint8_t *bytes, size_t length,
                              uint8_t *rgba, size_t rgba_capacity,
                              XmImageInfo *info);
/* Native PPM P3/P6 decoder, RGB8 only. */
int xm_media_decode_ppm_rgba(const uint8_t *bytes, size_t length,
                             uint8_t *rgba, size_t rgba_capacity,
                             XmImageInfo *info);
/* Parse an MPEG audio frame header (not the compressed audio payload). */
int xm_media_parse_mp3_header(const uint8_t *bytes, size_t length,
                              XmMpegAudioFrameInfo *info);
/* Parse an AAC ADTS frame header (not the compressed audio payload). */
int xm_media_parse_adts_header(const uint8_t *bytes, size_t length, XmAdtsInfo *info);
/* Validate one 188-byte MPEG-TS packet and expose the safe payload offset. */
int xm_media_parse_ts_packet(const uint8_t *bytes, size_t length, XmTsPacketInfo *info);
/* Analyze bounded HLS playlist metadata; encrypted/live/ranged streams are flagged. */
int xm_media_parse_hls(const char *text, size_t length, XmHlsInfo *info);
/* Parse one WebVTT cue by index (zero-based). Returns 1 for a cue, 0 at EOF,
 * and -1 for invalid input/header. Cue text references the original input buffer. */
int xm_media_webvtt_get_cue(const char *text, size_t length, size_t cue_index, XmWebVttCue *cue);
/* Find a cue active at timestamp_ms. Returns 1 when found, 0 when no cue is active,
 * and -1 for invalid input. */
int xm_media_webvtt_find_active_cue(const char *text, size_t length, uint64_t timestamp_ms,
                                    XmWebVttCue *cue);

#ifdef __cplusplus
}
#endif
#endif
