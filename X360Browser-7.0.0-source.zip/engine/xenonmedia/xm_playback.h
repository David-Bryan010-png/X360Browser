#ifndef XENONMEDIA_XM_PLAYBACK_H
#define XENONMEDIA_XM_PLAYBACK_H
#include <stdint.h>
#include "xm_media.h"
#ifdef __cplusplus
extern "C" {
#endif

typedef enum {
    XM_PLAYBACK_EMPTY = 0,
    XM_PLAYBACK_READY,
    XM_PLAYBACK_PLAYING,
    XM_PLAYBACK_PAUSED,
    XM_PLAYBACK_ENDED,
    XM_PLAYBACK_FAILED
} XmPlaybackState;

typedef struct {
    XmMediaInfo media;
    XmPlaybackState state;
    uint64_t position_ms;
    uint64_t duration_ms;
    uint64_t last_clock_ms;
    uint64_t bytes_consumed;
    uint32_t dropped_video_frames;
    uint32_t underruns;
    uint8_t has_audio;
    uint8_t has_video;
} XmPlaybackSession;

void xm_playback_init(XmPlaybackSession *session);
int xm_playback_load(XmPlaybackSession *session, const XmMediaInfo *media);
int xm_playback_play(XmPlaybackSession *session, uint64_t monotonic_ms);
int xm_playback_pause(XmPlaybackSession *session, uint64_t monotonic_ms);
int xm_playback_seek(XmPlaybackSession *session, uint64_t target_ms, uint64_t monotonic_ms);
void xm_playback_stop(XmPlaybackSession *session);
/* Advances timeline from a caller-supplied monotonic clock; no hidden timer/thread. */
int xm_playback_update(XmPlaybackSession *session, uint64_t monotonic_ms);
#ifdef __cplusplus
}
#endif
#endif
