# NativePlus + VisualLite compatibility path

This is the inherited fetch/resource path and legacy fallback renderer. XenonWeb is now the first layout path for supported simple pages, with `web_visual_layout_legacy()` retained as fallback. The network code and image/media download support do not imply that JavaScript, modern web app APIs, or inline video work. See `../xenonweb/README.md` and `../../docs/XENONWEB-ENGINE.md`.
