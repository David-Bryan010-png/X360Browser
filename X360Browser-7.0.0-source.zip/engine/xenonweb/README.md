# XenonWeb + XenonScript

XenonWeb is X360Browser's first-party HTML DOM, CSS-subset and visual-layout engine. XenonScript is the related first-party bounded interpreter for a small subset of inline script syntax. Neither claims standards-complete browser compatibility.

- `xw_dom.*`: bounded DOM representation/parser, lookup and text/attribute mutation.
- `xw_css.*`: CSS subset, selector matching and simplified computed styles.
- `xw_script.*`: bounded inline interpreter with variables/expressions/conditionals and restricted DOM bindings.
- `xw_layout.*`: adapter into the Xbox visual renderer, link-focus mapping, and limited inline anchor handler dispatch.

See [`../../docs/XENONWEB-ENGINE.md`](../../docs/XENONWEB-ENGINE.md) and [`../../docs/XENONSCRIPT.md`](../../docs/XENONSCRIPT.md) for exact capabilities and limitations. A real Xbox 360 cross-build and console test are still required.


The 2.2.0 integration permits the network layer to materialize at most two external synchronous scripts of up to 4 KiB each into the document in their source position. This is not a standards-complete script loader: `async`, `defer`, modules and SRI-protected scripts are intentionally skipped, and all accepted code is still limited by XenonScript's grammar and instruction budget.
