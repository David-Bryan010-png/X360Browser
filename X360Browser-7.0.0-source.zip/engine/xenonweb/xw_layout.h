#ifndef XW_LAYOUT_H
#define XW_LAYOUT_H
#include "../../platform/xbox360/xsdk/visual_layout.h"
int xw_layout_page(const WebEnginePage *page, size_t scroll_pixels, WebVisualFrame *frame);
/* Dispatch an anchor's inline onclick handler; navigation_consumed is set for # links. */
int xw_layout_dispatch_link(const WebEnginePage *page, size_t page_link_index,
                            int *navigation_consumed);
int xw_layout_dispatch_control(const WebEnginePage *page, uint16_t dom_node_index);
int xw_layout_get_control_value(const WebEnginePage *page, uint16_t dom_node_index,
                                char *output, size_t output_capacity);
int xw_layout_set_control_value(const WebEnginePage *page, uint16_t dom_node_index,
                                const char *value);
#endif
