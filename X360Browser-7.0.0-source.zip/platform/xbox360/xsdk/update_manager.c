#include "update_manager.h"
#include "update_manifest.h"
#include "../../../include/x360browser/version.hpp"

#include <curl/curl.h>
#include <mbedtls/md.h>
#include <ctype.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>

#define UPDATE_MANIFEST_CAP 32768U
#define UPDATE_XEX_MAX_BYTES (64U * 1024U * 1024U)
#define UPDATE_GITHUB_RELEASE_URL "https://api.github.com/repos/David-Bryan010-png/X360Browser/releases/latest"
#define UPDATE_GITHUB_RELEASE_PREFIX "https://github.com/David-Bryan010-png/X360Browser/releases/download/"
#define UPDATE_XEX_DEFAULT "game:\\default.xex"
#define UPDATE_XEX_TEMP "game:\\default.update.tmp"
#define UPDATE_XEX_STAGE "game:\\default.update.xex"
#define UPDATE_XEX_BACKUP "game:\\default.previous.xex"
#define UPDATE_XEX_BACKUP_OLD "game:\\default.previous.old.xex"

typedef struct { char *data; size_t length; size_t capacity; int overflow; } MemorySink;
typedef struct { FILE *file; size_t bytes; int overflow; } FileSink;

static void set_message(char *out, size_t cap, const char *text)
{
    if (out == NULL || cap == 0U) return;
    (void)snprintf(out, cap, "%s", text != NULL ? text : "");
}

static int file_exists(const char *path)
{
    FILE *file;
    if (path == NULL || path[0] == '\0') return 0;
    file = fopen(path, "rb");
    if (file == NULL) return 0;
    fclose(file);
    return 1;
}

/* default.xex is the canonical launch filename for this project. Never choose a
 * second, differently named executable: the packaged name and updater target must match. */
static int select_install_target(char *path, size_t capacity)
{
    static const char selected[] = UPDATE_XEX_DEFAULT;
    if (path == NULL || capacity == 0U || !file_exists(selected)) return 0;
    if (strlen(selected) >= capacity) { path[0] = '\0'; return 0; }
    memcpy(path, selected, sizeof(selected));
    return 1;
}

static size_t receive_memory(char *data, size_t size, size_t count, void *user)
{
    MemorySink *sink = (MemorySink *)user;
    size_t bytes;
    if (size != 0U && count > SIZE_MAX / size) return 0U;
    bytes = size * count;
    if (sink == NULL || sink->length > sink->capacity || bytes > sink->capacity - sink->length) {
        if (sink != NULL) sink->overflow = 1;
        return 0U;
    }
    memcpy(sink->data + sink->length, data, bytes);
    sink->length += bytes;
    return bytes;
}

static size_t receive_file(char *data, size_t size, size_t count, void *user)
{
    FileSink *sink = (FileSink *)user;
    size_t bytes, wrote;
    if (size != 0U && count > SIZE_MAX / size) return 0U;
    bytes = size * count;
    if (sink == NULL || sink->file == NULL || sink->bytes > UPDATE_XEX_MAX_BYTES ||
        bytes > UPDATE_XEX_MAX_BYTES - sink->bytes) {
        if (sink != NULL) sink->overflow = 1;
        return 0U;
    }
    wrote = fwrite(data, 1U, bytes, sink->file);
    sink->bytes += wrote;
    return wrote;
}

static int curl_get_memory(const char *url, MemorySink *sink, long timeout_seconds)
{
    CURL *curl;
    CURLcode result;
    long status = 0L;
    struct curl_slist *headers = NULL;
    if (url == NULL || sink == NULL || strncasecmp(url, "https://", 8U) != 0) return 0;
    curl = curl_easy_init();
    if (curl == NULL) return 0;
    headers = curl_slist_append(headers, "Accept: application/vnd.github+json");
    if (headers != NULL) headers = curl_slist_append(headers, "X-GitHub-Api-Version: 2022-11-28");
    (void)curl_easy_setopt(curl, CURLOPT_URL, url);
    (void)curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
    (void)curl_easy_setopt(curl, CURLOPT_USERAGENT, "X360Browser/" X360BROWSER_VERSION_STRING " update-client");
    (void)curl_easy_setopt(curl, CURLOPT_NOSIGNAL, 1L);
    (void)curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, receive_memory);
    (void)curl_easy_setopt(curl, CURLOPT_WRITEDATA, sink);
    (void)curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1L);
    (void)curl_easy_setopt(curl, CURLOPT_MAXREDIRS, 3L);
    (void)curl_easy_setopt(curl, CURLOPT_CONNECTTIMEOUT, 8L);
    (void)curl_easy_setopt(curl, CURLOPT_TIMEOUT, timeout_seconds);
    (void)curl_easy_setopt(curl, CURLOPT_CAINFO, "cacert.pem");
    (void)curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 1L);
    (void)curl_easy_setopt(curl, CURLOPT_SSL_VERIFYHOST, 2L);
    (void)curl_easy_setopt(curl, CURLOPT_PROTOCOLS_STR, "https");
    (void)curl_easy_setopt(curl, CURLOPT_REDIR_PROTOCOLS_STR, "https");
    result = curl_easy_perform(curl);
    (void)curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &status);
    curl_slist_free_all(headers);
    curl_easy_cleanup(curl);
    return result == CURLE_OK && status >= 200L && status < 300L && !sink->overflow;
}

static int parse_version_parts(const char *version, unsigned long parts[3])
{
    const char *p = version;
    size_t component;
    if (version == NULL || version[0] == '\0' || strchr(version, '-') != NULL || strchr(version, '+') != NULL) return 0;
    for (component = 0U; component < 3U; ++component) {
        unsigned long value = 0UL;
        size_t digits = 0U;
        const char *start = p;
        while (*p >= '0' && *p <= '9') {
            unsigned long digit = (unsigned long)(*p - '0');
            if (value > (ULONG_MAX - digit) / 10UL) return 0;
            value = value * 10UL + digit;
            ++p;
            ++digits;
        }
        if (digits == 0U || (digits > 1U && *start == '0')) return 0;
        parts[component] = value;
        if (component < 2U) {
            if (*p != '.') return 0;
            ++p;
        }
    }
    return *p == '\0';
}

static int compare_version(const char *a, const char *b)
{
    unsigned long av[3] = {0UL,0UL,0UL}, bv[3] = {0UL,0UL,0UL};
    size_t i;
    if (!parse_version_parts(a, av) || !parse_version_parts(b, bv)) return 0;
    for (i = 0U; i < 3U; ++i) {
        if (av[i] > bv[i]) return 1;
        if (av[i] < bv[i]) return -1;
    }
    return 0;
}

static int sha256_file_hex(const char *path, char out[65])
{
    FILE *file = fopen(path, "rb");
    const mbedtls_md_info_t *info = mbedtls_md_info_from_type(MBEDTLS_MD_SHA256);
    mbedtls_md_context_t ctx;
    unsigned char buffer[8192], digest[32];
    size_t got, i;
    int result = 0;
    static const char hex[] = "0123456789abcdef";
    if (file == NULL || info == NULL) { if (file != NULL) fclose(file); return 0; }
    mbedtls_md_init(&ctx);
    if (mbedtls_md_setup(&ctx, info, 0) != 0 || mbedtls_md_starts(&ctx) != 0) goto done;
    while ((got = fread(buffer, 1U, sizeof(buffer), file)) > 0U)
        if (mbedtls_md_update(&ctx, buffer, got) != 0) goto done;
    if (ferror(file) || mbedtls_md_finish(&ctx, digest) != 0) goto done;
    for (i = 0U; i < sizeof(digest); ++i) { out[i * 2U] = hex[digest[i] >> 4U]; out[i * 2U + 1U] = hex[digest[i] & 15U]; }
    out[64] = '\0';
    result = 1;
done:
    mbedtls_md_free(&ctx);
    fclose(file);
    return result;
}

static int download_xex(const char *url, const char *path)
{
    CURL *curl;
    CURLcode result;
    long status = 0L;
    FileSink sink;
    sink.file = fopen(path, "wb"); sink.bytes = 0U; sink.overflow = 0;
    if (sink.file == NULL) return 0;
    curl = curl_easy_init();
    if (curl == NULL) { fclose(sink.file); remove(path); return 0; }
    (void)curl_easy_setopt(curl, CURLOPT_URL, url);
    (void)curl_easy_setopt(curl, CURLOPT_USERAGENT, "X360Browser/" X360BROWSER_VERSION_STRING " update-client");
    (void)curl_easy_setopt(curl, CURLOPT_NOSIGNAL, 1L);
    (void)curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, receive_file);
    (void)curl_easy_setopt(curl, CURLOPT_WRITEDATA, &sink);
    (void)curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1L);
    (void)curl_easy_setopt(curl, CURLOPT_MAXREDIRS, 4L);
    (void)curl_easy_setopt(curl, CURLOPT_CONNECTTIMEOUT, 8L);
    (void)curl_easy_setopt(curl, CURLOPT_TIMEOUT, 180L);
    (void)curl_easy_setopt(curl, CURLOPT_LOW_SPEED_LIMIT, 128L);
    (void)curl_easy_setopt(curl, CURLOPT_LOW_SPEED_TIME, 15L);
    (void)curl_easy_setopt(curl, CURLOPT_CAINFO, "cacert.pem");
    (void)curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 1L);
    (void)curl_easy_setopt(curl, CURLOPT_SSL_VERIFYHOST, 2L);
    (void)curl_easy_setopt(curl, CURLOPT_PROTOCOLS_STR, "https");
    (void)curl_easy_setopt(curl, CURLOPT_REDIR_PROTOCOLS_STR, "https");
    result = curl_easy_perform(curl);
    (void)curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &status);
    curl_easy_cleanup(curl);
    if (fclose(sink.file) != 0) result = CURLE_WRITE_ERROR;
    if (result != CURLE_OK || status < 200L || status >= 300L || sink.bytes < 1024U || sink.overflow) {
        remove(path); return 0;
    }
    return 1;
}

X360UpdateResult x360_update_check_and_install(const char *current_version,
                                               char *message, size_t message_capacity)
{
    char release_data[UPDATE_MANIFEST_CAP + 1U] = {0};
    MemorySink sink = { release_data, 0U, UPDATE_MANIFEST_CAP, 0 };
    X360UpdateManifest manifest;
    char calculated_hash[65] = {0};
    char install_target[260] = {0};
    int compare;
    if (current_version == NULL || current_version[0] == '\0') {
        set_message(message, message_capacity, "Update skipped: local version unavailable.");
        return X360_UPDATE_DISABLED;
    }
    set_message(message, message_capacity, "Checking GitHub Releases...");
    if (!curl_get_memory(UPDATE_GITHUB_RELEASE_URL, &sink, 18L) || sink.length == 0U) {
        set_message(message, message_capacity, "GitHub update check failed; browser remains available.");
        return X360_UPDATE_ERROR;
    }
    release_data[sink.length] = '\0';
    memset(&manifest, 0, sizeof(manifest));
    if (!x360_update_parse_github_release(release_data, &manifest)) {
        set_message(message, message_capacity, "No valid stable release asset found; no files changed.");
        return X360_UPDATE_ERROR;
    }
    if (strncasecmp(manifest.xex_url, UPDATE_GITHUB_RELEASE_PREFIX,
                    sizeof(UPDATE_GITHUB_RELEASE_PREFIX) - 1U) != 0) {
        set_message(message, message_capacity, "Release asset host rejected; no files changed.");
        return X360_UPDATE_ERROR;
    }
    if (manifest.sha256[0] == '\0') {
        char checksum_text[512] = {0};
        MemorySink checksum_sink = { checksum_text, 0U, sizeof(checksum_text) - 1U, 0 };
        if (manifest.checksum_url[0] == '\0' ||
            strncasecmp(manifest.checksum_url, UPDATE_GITHUB_RELEASE_PREFIX,
                        sizeof(UPDATE_GITHUB_RELEASE_PREFIX) - 1U) != 0 ||
            !curl_get_memory(manifest.checksum_url, &checksum_sink, 12L)) {
            set_message(message, message_capacity, "Release has no usable SHA-256 digest/checksum; update rejected.");
            return X360_UPDATE_ERROR;
        }
        checksum_text[checksum_sink.length] = '\0';
        if (!x360_update_parse_checksum(checksum_text, manifest.sha256)) {
            set_message(message, message_capacity, "Release checksum is invalid; update rejected.");
            return X360_UPDATE_ERROR;
        }
    }
    compare = compare_version(manifest.version, current_version);
    if (compare <= 0) {
        set_message(message, message_capacity, "X360Browser is up to date.");
        return X360_UPDATE_CURRENT;
    }
    remove(UPDATE_XEX_TEMP);
    remove(UPDATE_XEX_STAGE);
    if (!download_xex(manifest.xex_url, UPDATE_XEX_TEMP)) {
        set_message(message, message_capacity, "New version found, but XEX download failed.");
        return X360_UPDATE_ERROR;
    }
    if (!sha256_file_hex(UPDATE_XEX_TEMP, calculated_hash) || strcasecmp(calculated_hash, manifest.sha256) != 0) {
        remove(UPDATE_XEX_TEMP);
        set_message(message, message_capacity, "Update SHA-256 mismatch; download rejected safely.");
        return X360_UPDATE_ERROR;
    }
    if (rename(UPDATE_XEX_TEMP, UPDATE_XEX_STAGE) != 0) {
        remove(UPDATE_XEX_TEMP);
        set_message(message, message_capacity, "Verified update saved but could not stage it on this device.");
        return X360_UPDATE_STAGED;
    }
    /* The filesystem may refuse to rename an executable while it is running.
     * Only the canonical default.xex launch path is supported. */
    if (!select_install_target(install_target, sizeof(install_target))) {
        set_message(message, message_capacity, "Verified update staged; game:\\default.xex was not found.");
        return X360_UPDATE_STAGED;
    }
    remove(UPDATE_XEX_BACKUP_OLD);
    if (rename(UPDATE_XEX_BACKUP, UPDATE_XEX_BACKUP_OLD) != 0) {
        FILE *backup = fopen(UPDATE_XEX_BACKUP, "rb");
        if (backup != NULL) {
            fclose(backup);
            set_message(message, message_capacity, "Verified update staged; previous backup preserved.");
            return X360_UPDATE_STAGED;
        }
    }
    if (rename(install_target, UPDATE_XEX_BACKUP) != 0) {
        (void)rename(UPDATE_XEX_BACKUP_OLD, UPDATE_XEX_BACKUP);
        set_message(message, message_capacity, "Verified update staged as default.update.xex; the running default.xex could not be replaced. Restart/replace it when the console allows.");
        return X360_UPDATE_STAGED;
    }
    if (rename(UPDATE_XEX_STAGE, install_target) != 0) {
        (void)rename(UPDATE_XEX_BACKUP, install_target);
        (void)rename(UPDATE_XEX_BACKUP_OLD, UPDATE_XEX_BACKUP);
        set_message(message, message_capacity, "Update install failed; previous executable restored.");
        return X360_UPDATE_ERROR;
    }
    remove(UPDATE_XEX_BACKUP_OLD);
    set_message(message, message_capacity, "Update installed to the launcher's XEX path. Restart X360Browser to run the new version.");
    return X360_UPDATE_INSTALLED;
}
