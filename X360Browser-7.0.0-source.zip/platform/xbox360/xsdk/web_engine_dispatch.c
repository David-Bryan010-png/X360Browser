#include "web_engine.h"

#include <stdio.h>

static int g_native_ready;

int web_engine_init(void)
{
    g_native_ready = web_engine_native_init();
    return g_native_ready;
}

void web_engine_shutdown(void)
{
    if (g_native_ready)
        web_engine_native_shutdown();
    g_native_ready = 0;
}

int web_engine_fetch(const char *url, WebEnginePage *page,
                     char *error, size_t error_capacity)
{
    int result;
    if (page == NULL) {
        if (error != NULL && error_capacity > 0U)
            (void)snprintf(error, error_capacity, "No page buffer provided");
        return 0;
    }
    if (!g_native_ready) {
        if (error != NULL && error_capacity > 0U)
            (void)snprintf(error, error_capacity, "XenonWeb transport is not initialized");
        return 0;
    }

    /* XenonWeb is the only page engine. Network/TLS libraries are supporting
       transport dependencies, not alternate HTML/CSS engines. */
    result = web_engine_native_fetch(url, page, error, error_capacity);
    if (result != 0) {
        if (page->page_url[0] == '\0')
            (void)snprintf(page->page_url, sizeof(page->page_url), "%s", url);
        page->backend_used = WEB_ENGINE_BACKEND_XENONWEB;
        page->used_fallback = 0;
        page->fallback_reason[0] = '\0';
    }
    return result;
}

const char *web_engine_backend_label(void)
{
    return "XenonWeb + XenonNet transport (first-party page engine)";
}
