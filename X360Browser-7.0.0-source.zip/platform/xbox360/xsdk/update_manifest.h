#ifndef X360BROWSER_UPDATE_MANIFEST_H
#define X360BROWSER_UPDATE_MANIFEST_H

#include <stddef.h>

typedef struct {
    char version[32];
    char xex_url[1024];
    char sha256[65];
    char checksum_url[1024];
} X360UpdateManifest;

/* Parse only the official latest-release API shape for this repository. */
int x360_update_parse_github_release(const char *json, X360UpdateManifest *manifest);
int x360_update_parse_checksum(const char *text, char output[65]);

#endif
