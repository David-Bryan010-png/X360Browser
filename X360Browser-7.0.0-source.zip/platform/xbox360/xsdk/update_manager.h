#ifndef X360BROWSER_UPDATE_MANAGER_H
#define X360BROWSER_UPDATE_MANAGER_H

#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef enum {
    X360_UPDATE_DISABLED = 0,
    X360_UPDATE_CURRENT = 1,
    X360_UPDATE_INSTALLED = 2,
    X360_UPDATE_STAGED = 3,
    X360_UPDATE_ERROR = -1
} X360UpdateResult;

/* Checks GitHub latest stable release, verifies the asset SHA-256, and attempts
 * a rollback-capable swap. No Vercel URL or USB config file is required. */
X360UpdateResult x360_update_check_and_install(const char *current_version,
                                               char *message, size_t message_capacity);

#ifdef __cplusplus
}
#endif
#endif
