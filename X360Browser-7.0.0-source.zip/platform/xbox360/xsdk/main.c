#include <stdbool.h>
#include <ctype.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <pthread.h>

#include "xsdk/gpu.h"
#include "xsdk/kernel.h"
#include "xsdk/log.h"
#include "xsdk/net.h"
#include "xsdk/present.h"
#include "xsdk/splash.h"
#include "xsdk/text.h"
#include "xsdk/xam.h"
#include "web_engine.h"
#include "visual_renderer.h"
#include "update_manager.h"
#include "../../../include/x360browser/version.hpp"

enum {
    SPLASH_MS = 900,
    BUFFERS = 2,
    SWAP_INTERVAL = 1,
    BEGIN_TIMEOUT_MS = 5000,
    CLEAR_ARGB = 0xFF17191D,
    COLOR_WHITE = 0xFFFFFFFF,
    COLOR_MUTED = 0xFFB9C6D8,
    COLOR_BLUE = 0xFF70B7FF,
    COLOR_GOLD = 0xFFFFD166,
    COLOR_GREEN = 0xFF79D49A,
    COLOR_RED = 0xFFFF8585,
    VISIBLE_LINES = 20,
    PAGE_LINE_BYTES = 108,
    HISTORY_COUNT = 16,
    BOOKMARK_COUNT = 24
};

static const char DEFAULT_URL[] = "https://example.com/";

static WebEnginePage g_page;
static char g_current_url[WEB_ENGINE_URL_CAP] = "https://example.com/";
static char g_status[224] = "Starting browser engine...";
static pthread_mutex_t g_state_lock = PTHREAD_MUTEX_INITIALIZER;
static pthread_t g_fetch_thread;
static bool g_fetch_thread_valid;
static bool g_fetch_running;
static bool g_fetch_finished;
static bool g_page_loaded;
static bool g_media_downloading;
static bool g_media_download_done;
static bool g_media_download_ok;
static bool g_media_download_is_audio;
static bool g_media_stream_url_mode;
static bool g_media_stream_resolve_done;
static bool g_media_stream_resolve_ok;
static bool g_video_player_auto_missing;
static char g_media_resolved_stream_url[WEB_ENGINE_RESOURCE_URL_CAP];
static char g_last_media_path[260] = "game:\\X360Browser-video.mp4";
static bool g_show_bookmarks;
static bool g_engine_ready;
static bool g_show_links;
static bool g_show_resources;
static bool g_show_visual;
static bool g_visual_renderer_ready;
static char g_logged_visual_url[WEB_ENGINE_URL_CAP];
static bool g_pointer_mode;
static int g_cursor_x = 640;
static int g_cursor_y = 260;
static bool g_update_running;
static bool g_update_done;
static pthread_t g_update_thread;
static bool g_update_thread_valid;

static char g_update_result_message[224] = "Checking GitHub Releases...";
static size_t g_visual_content_height;
static size_t g_scroll_line;
static size_t g_selected_link;
static size_t g_selected_resource;
static size_t g_selected_bookmark;
static char g_history[HISTORY_COUNT][WEB_ENGINE_URL_CAP];
static size_t g_history_count;
static char g_forward[HISTORY_COUNT][WEB_ENGINE_URL_CAP];
static size_t g_forward_count;

typedef struct {
    char url[WEB_ENGINE_URL_CAP];
    char title[WEB_ENGINE_TITLE_CAP];
} BrowserBookmark;

static BrowserBookmark g_bookmarks[BOOKMARK_COUNT];
static size_t g_bookmark_count;

static XAM_OVERLAPPED g_keyboard_overlapped;
static uint16_t g_keyboard_text[WEB_ENGINE_URL_CAP];
static uint16_t g_keyboard_default[WEB_ENGINE_URL_CAP];
static bool g_keyboard_active;
static bool g_keyboard_control_mode;
static uint16_t g_keyboard_control_node = UINT16_MAX;

struct FetchTask {
    char url[WEB_ENGINE_URL_CAP];
    bool is_media;
    bool is_audio;
    bool resolve_only;
    char destination[260];
};

typedef struct {
    char filename[260];
    char callingapp[260];
} VideoLaunchInfo;

#define VIDEO_FILE_PATH "game:\\X360Browser-video.mp4"
#define AUDIO_FILE_PATH "game:\\X360Browser-audio.mp3"
#define HLS_VIDEO_FILE_PATH "game:\\X360Browser-video-hls.ts"
#define HLS_AUDIO_FILE_PATH "game:\\X360Browser-audio-hls.ts"
#define VIDEO_PLAYER_PATH "auto"
#define BROWSER_XEX_PATH "game:\\default.xex"

static char g_video_file_path[260] = VIDEO_FILE_PATH;
static char g_audio_file_path[260] = AUDIO_FILE_PATH;
static char g_video_player_path[260] = VIDEO_PLAYER_PATH;
static char g_browser_xex_path[260] = BROWSER_XEX_PATH;

static void draw_bookmarks(size_t selected);
static void start_update_check(void);
static void poll_update_check(void);
static void launch_external_media_url(const char *url, const char *media_kind);

static void copy_text(char *destination, size_t capacity, const char *source)
{
    size_t length;
    if (destination == NULL || capacity == 0U)
        return;
    if (source == NULL)
        source = "";
    length = strlen(source);
    if (length >= capacity)
        length = capacity - 1U;
    if (length != 0U)
        memmove(destination, source, length);
    destination[length] = '\0';
}

static void *update_check_worker(void *unused)
{
    char message[sizeof(g_update_result_message)] = {0};
    (void)unused;
    (void)x360_update_check_and_install(X360BROWSER_VERSION_STRING, message, sizeof(message));
    pthread_mutex_lock(&g_state_lock);
    copy_text(g_update_result_message, sizeof(g_update_result_message), message);
    g_update_running = false;
    g_update_done = true;
    pthread_mutex_unlock(&g_state_lock);
    return NULL;
}

static void start_update_check(void)
{
    pthread_mutex_lock(&g_state_lock);
    if (g_update_running || g_update_thread_valid) { pthread_mutex_unlock(&g_state_lock); return; }
    g_update_running = true;
    copy_text(g_update_result_message, sizeof(g_update_result_message), "Checking GitHub Releases securely...");
    pthread_mutex_unlock(&g_state_lock);
    if (pthread_create(&g_update_thread, NULL, update_check_worker, NULL) == 0) {
        g_update_thread_valid = true;
        (void)pthread_detach(g_update_thread);
    } else {
        pthread_mutex_lock(&g_state_lock);
        g_update_running = false;
        copy_text(g_update_result_message, sizeof(g_update_result_message), "Could not start update-check thread.");
        pthread_mutex_unlock(&g_state_lock);
    }
}

static void poll_update_check(void)
{
    pthread_mutex_lock(&g_state_lock);
    if (g_update_done) {
        copy_text(g_status, sizeof(g_status), g_update_result_message);
        g_update_done = false;
    } else if (g_update_running && !g_page_loaded && !g_fetch_running) {
        copy_text(g_status, sizeof(g_status), "Checking for updates securely in the background...");
    }
    pthread_mutex_unlock(&g_state_lock);
}

static int external_media_player_enabled(void)
{
    return g_video_player_path[0] != '\0' && strcasecmp(g_video_player_path, "disabled") != 0;
}

static int media_player_file_exists(const char *path)
{
    FILE *file;
    if (path == NULL || path[0] == '\0') return 0;
    file = fopen(path, "rb");
    if (file == NULL) return 0;
    (void)fclose(file);
    return 1;
}

static void resolve_auto_media_player(void)
{
    static const char *const candidates[] = {
        "game:\\FFPlay.xex", "game:\\ffplay.xex",
        "game:\\Apps\\FFPlay\\FFPlay.xex", "game:\\Apps\\FFplay\\FFplay.xex"
    };
    size_t i;
    if (strcasecmp(g_video_player_path, "auto") != 0) return;
    for (i = 0U; i < sizeof(candidates) / sizeof(candidates[0]); ++i) {
        if (media_player_file_exists(candidates[i])) {
            copy_text(g_video_player_path, sizeof(g_video_player_path), candidates[i]);
            g_video_player_auto_missing = false;
            return;
        }
    }
    copy_text(g_video_player_path, sizeof(g_video_player_path), "disabled");
    g_video_player_auto_missing = true;
}

static void load_video_config(void)
{
    FILE *file = fopen("X360Browser-video-config.txt", "r");
    char line[512];
    char *targets[4] = { g_video_player_path, g_browser_xex_path, g_video_file_path, g_audio_file_path };
    const size_t capacities[4] = { sizeof(g_video_player_path), sizeof(g_browser_xex_path),
                                   sizeof(g_video_file_path), sizeof(g_audio_file_path) };
    size_t setting_index = 0U;
    if (file != NULL) {
        while (setting_index < 5U && fgets(line, sizeof(line), file) != NULL) {
            char *start = line;
            char *end = strpbrk(line, "\r\n");
            size_t length;
            if (end != NULL) *end = '\0';
            while (*start != '\0' && isspace((unsigned char)*start)) ++start;
            length = strlen(start);
            while (length > 0U && isspace((unsigned char)start[length - 1U]))
                start[--length] = '\0';
            /* Blank lines and comments do not consume positional settings. */
            if (length == 0U || start[0] == '#' || start[0] == ';') continue;
            if (setting_index < 4U) {
                if (length < capacities[setting_index])
                    copy_text(targets[setting_index], capacities[setting_index], start);
            } else {
                g_media_stream_url_mode = strcasecmp(start, "stream-url") == 0 ||
                                          strcasecmp(start, "url") == 0;
            }
            ++setting_index;
        }
        (void)fclose(file);
    }
    /* Do not probe optional player XEX files during browser startup. In auto mode,
     * discovery is deferred until media playback is actually requested so a normal
     * browsing session does not produce noisy NtCreateFile failures. */
}

static bool encode_search_address(const char *input, size_t input_length,
                                  char *output, size_t capacity)
{
    static const char ddg_prefix[] = "https://html.duckduckgo.com/html/?q=";
    static const char google_prefix[] = "https://www.google.com/search?q=";
    static const char bing_prefix[] = "https://www.bing.com/search?q=";
    static const char hex[] = "0123456789ABCDEF";
    const char *prefix = ddg_prefix;
    size_t prefix_length;
    size_t used;
    size_t i;
    if (input == NULL || output == NULL) return false;
    if (input_length >= 3U && input[0] == '!' && input[2] == ' ') {
        if (input[1] == 'g' || input[1] == 'G') prefix = google_prefix;
        else if (input[1] == 'b' || input[1] == 'B') prefix = bing_prefix;
        else if (input[1] == 'd' || input[1] == 'D') prefix = ddg_prefix;
        if (input[1] == 'g' || input[1] == 'G' || input[1] == 'b' || input[1] == 'B' ||
            input[1] == 'd' || input[1] == 'D') {
            input += 3U;
            input_length -= 3U;
        }
    }
    prefix_length = strlen(prefix);
    used = prefix_length;
    if (capacity <= used) return false;
    memcpy(output, prefix, used);
    for (i = 0U; i < input_length; ++i) {
        unsigned char ch = (unsigned char)input[i];
        if (ch == ' ' || ch == '\t') {
            if (used + 1U >= capacity) return false;
            output[used++] = '+';
        } else if ((ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z') ||
                   (ch >= '0' && ch <= '9') || ch == '-' || ch == '_' || ch == '.' || ch == '~') {
            if (used + 1U >= capacity) return false;
            output[used++] = (char)ch;
        } else {
            if (used + 3U >= capacity) return false;
            output[used++] = '%';
            output[used++] = hex[ch >> 4U];
            output[used++] = hex[ch & 0x0FU];
        }
    }
    output[used] = '\0';
    return true;
}

static bool normalize_address(const char *input, char *output, size_t capacity)
{
    const char *start = input;
    size_t length;
    size_t i;
    bool has_dot = false;
    bool has_colon = false;
    if (input == NULL || output == NULL || capacity < 9U) return false;
    while (*start != '\0' && isspace((unsigned char)*start)) ++start;
    length = strlen(start);
    while (length > 0U && isspace((unsigned char)start[length - 1U])) --length;
    if (length == 0U || length >= capacity) return false;

    for (i = 0U; i < length; ++i) {
        unsigned char ch = (unsigned char)start[i];
        if (ch == '.') has_dot = true;
        if (ch == ':') has_colon = true;
        if (ch < 0x20U || ch == 0x7FU) return false;
    }
    if (strstr(start, "://") == NULL) {
        for (i = 0U; i < length; ++i) {
            if (isspace((unsigned char)start[i]))
                return encode_search_address(start, length, output, capacity);
        }
        if (!has_dot && !has_colon && strcasecmp(start, "localhost") != 0)
            return encode_search_address(start, length, output, capacity);
        if (length + 8U >= capacity) return false;
        (void)snprintf(output, capacity, "https://%.*s", (int)length, start);
    } else {
        (void)snprintf(output, capacity, "%.*s", (int)length, start);
    }
    if (strncasecmp(output, "http://", 7U) != 0 && strncasecmp(output, "https://", 8U) != 0)
        return false;
    {
        const char *authority = strstr(output, "://");
        const char *host = authority != NULL ? authority + 3 : output;
        if (host[0] == '\0' || host[0] == '/' || host[0] == '?' || host[0] == '#') return false;
        for (i = 0U; output[i] != '\0'; ++i) {
            if (isspace((unsigned char)output[i])) return false;
        }
    }
    return true;
}

static bool is_direct_video_url(const char *url)
{
    const char *end;
    const char *path_start;
    const char *dot;
    size_t n;
    if (url == NULL) return false;
    end = strpbrk(url, "?#");
    if (end == NULL) end = url + strlen(url);
    path_start = end;
    while (path_start > url && path_start[-1] != '/' && path_start[-1] != '\\') --path_start;
    dot = end;
    while (dot > path_start && dot[-1] != '.') --dot;
    if (dot <= path_start || dot[-1] != '.') return false;
    n = (size_t)(end - dot);
    return (n == 3U && (strncasecmp(dot, "mp4", 3U) == 0 || strncasecmp(dot, "mkv", 3U) == 0 ||
            strncasecmp(dot, "avi", 3U) == 0 || strncasecmp(dot, "mov", 3U) == 0 ||
            strncasecmp(dot, "wmv", 3U) == 0 || strncasecmp(dot, "m4v", 3U) == 0 ||
            strncasecmp(dot, "mpg", 3U) == 0 || strncasecmp(dot, "ogv", 3U) == 0)) ||
           (n == 4U && (strncasecmp(dot, "webm", 4U) == 0 || strncasecmp(dot, "mpeg", 4U) == 0 ||
                        strncasecmp(dot, "m2ts", 4U) == 0)) ||
           (n == 3U && (strncasecmp(dot, "3gp", 3U) == 0 || strncasecmp(dot, "3g2", 3U) == 0 ||
                        strncasecmp(dot, "m2t", 3U) == 0 || strncasecmp(dot, "m2v", 3U) == 0 ||
                        strncasecmp(dot, "mts", 3U) == 0 || strncasecmp(dot, "vob", 3U) == 0 ||
                        strncasecmp(dot, "flv", 3U) == 0 || strncasecmp(dot, "f4v", 3U) == 0 ||
                        strncasecmp(dot, "mxf", 3U) == 0)) ||
           (n == 2U && strncasecmp(dot, "ts", 2U) == 0);
}

static bool is_direct_audio_url(const char *url)
{
    const char *end;
    const char *path_start;
    const char *dot;
    size_t n;
    if (url == NULL) return false;
    end = strpbrk(url, "?#");
    if (end == NULL) end = url + strlen(url);
    path_start = end;
    while (path_start > url && path_start[-1] != '/' && path_start[-1] != '\\') --path_start;
    dot = end;
    while (dot > path_start && dot[-1] != '.') --dot;
    if (dot <= path_start || dot[-1] != '.') return false;
    n = (size_t)(end - dot);
    return (n == 2U && strncasecmp(dot, "au", 2U) == 0) ||
           (n == 3U && (strncasecmp(dot, "mp3", 3U) == 0 || strncasecmp(dot, "aac", 3U) == 0 ||
                        strncasecmp(dot, "ogg", 3U) == 0 || strncasecmp(dot, "oga", 3U) == 0 ||
                        strncasecmp(dot, "wav", 3U) == 0 || strncasecmp(dot, "m4a", 3U) == 0 ||
                        strncasecmp(dot, "aif", 3U) == 0 || strncasecmp(dot, "amr", 3U) == 0 ||
                        strncasecmp(dot, "caf", 3U) == 0 || strncasecmp(dot, "ac3", 3U) == 0 ||
                        strncasecmp(dot, "dts", 3U) == 0 || strncasecmp(dot, "wma", 3U) == 0 ||
                        strncasecmp(dot, "ape", 3U) == 0 || strncasecmp(dot, "m4b", 3U) == 0)) ||
           (n == 4U && (strncasecmp(dot, "opus", 4U) == 0 || strncasecmp(dot, "flac", 4U) == 0 ||
                        strncasecmp(dot, "aiff", 4U) == 0 || strncasecmp(dot, "aifc", 4U) == 0));
}

static bool contains_ci(const char *text, const char *needle)
{
    size_t n;
    const char *p;
    if (text == NULL || needle == NULL || needle[0] == '\0') return false;
    n = strlen(needle);
    for (p = text; *p != '\0'; ++p)
        if (strncasecmp(p, needle, n) == 0) return true;
    return false;
}

static bool is_dash_manifest(const char *url, const char *mime)
{
    const char *end;
    const char *dot;
    if (mime != NULL && contains_ci(mime, "dash+xml")) return true;
    if (url == NULL) return false;
    end = strpbrk(url, "?#");
    if (end == NULL) end = url + strlen(url);
    dot = end;
    while (dot > url && dot[-1] != '.' && dot[-1] != '/' && dot[-1] != '\\') --dot;
    if (dot <= url || dot[-1] != '.') return false;
    return (size_t)(end - dot) == 3U && strncasecmp(dot, "mpd", 3U) == 0;
}

static bool is_hls_manifest(const char *url, const char *mime)
{
    const char *end;
    const char *dot;
    if (mime != NULL && contains_ci(mime, "mpegurl")) return true;
    if (url == NULL) return false;
    end = strpbrk(url, "?#");
    if (end == NULL) end = url + strlen(url);
    dot = end;
    while (dot > url && dot[-1] != '.' && dot[-1] != '/' && dot[-1] != '\\') --dot;
    return dot > url && dot[-1] == '.' && (size_t)(end - dot) == 4U && strncasecmp(dot, "m3u8", 4U) == 0;
}

static bool is_direct_video_mime(const char *mime)
{
    return mime != NULL && (strncasecmp(mime, "video/", 6U) == 0 ||
           strncasecmp(mime, "application/octet-stream", 24U) == 0 ||
           strncasecmp(mime, "application/mp4", 15U) == 0 ||
           strncasecmp(mime, "application/x-matroska", 22U) == 0);
}

static bool is_direct_audio_mime(const char *mime)
{
    return mime != NULL && (strncasecmp(mime, "audio/", 6U) == 0 ||
           strncasecmp(mime, "application/ogg", 15U) == 0 ||
           strncasecmp(mime, "application/octet-stream", 24U) == 0);
}

static bool append_utf8(char *out, size_t capacity, size_t *length, uint32_t cp)
{
    char encoded[4];
    size_t n = 0U;
    if (cp < 0x80U) encoded[n++] = (char)cp;
    else if (cp < 0x800U) { encoded[n++] = (char)(0xC0U | (cp >> 6U)); encoded[n++] = (char)(0x80U | (cp & 0x3FU)); }
    else if (cp < 0x10000U) { encoded[n++] = (char)(0xE0U | (cp >> 12U)); encoded[n++] = (char)(0x80U | ((cp >> 6U) & 0x3FU)); encoded[n++] = (char)(0x80U | (cp & 0x3FU)); }
    else if (cp <= 0x10FFFFU) { encoded[n++] = (char)(0xF0U | (cp >> 18U)); encoded[n++] = (char)(0x80U | ((cp >> 12U) & 0x3FU)); encoded[n++] = (char)(0x80U | ((cp >> 6U) & 0x3FU)); encoded[n++] = (char)(0x80U | (cp & 0x3FU)); }
    else return false;
    if (*length + n >= capacity) return false;
    memcpy(out + *length, encoded, n);
    *length += n;
    out[*length] = '\0';
    return true;
}

static void history_push(const char *url)
{
    if (url == NULL || url[0] == '\0') return;
    if (g_history_count > 0U && strcmp(g_history[g_history_count - 1U], url) == 0) return;
    if (g_history_count == HISTORY_COUNT) {
        memmove(&g_history[0], &g_history[1], (HISTORY_COUNT - 1U) * sizeof(g_history[0]));
        --g_history_count;
    }
    copy_text(g_history[g_history_count++], WEB_ENGINE_URL_CAP, url);
}

static void forward_push(const char *url)
{
    if (url == NULL || url[0] == '\0') return;
    if (g_forward_count > 0U && strcmp(g_forward[g_forward_count - 1U], url) == 0) return;
    if (g_forward_count == HISTORY_COUNT) {
        memmove(&g_forward[0], &g_forward[1], (HISTORY_COUNT - 1U) * sizeof(g_forward[0]));
        --g_forward_count;
    }
    copy_text(g_forward[g_forward_count++], WEB_ENGINE_URL_CAP, url);
}

static void load_bookmarks(void)
{
    FILE *file = fopen("X360Browser-bookmarks.txt", "r");
    char line[WEB_ENGINE_URL_CAP + WEB_ENGINE_TITLE_CAP + 4];
    if (file == NULL) return;
    while (g_bookmark_count < BOOKMARK_COUNT && fgets(line, sizeof(line), file) != NULL) {
        char *end = strpbrk(line, "\r\n");
        char *tab;
        if (end != NULL) *end = '\0';
        tab = strchr(line, '\t');
        if (tab == NULL || tab == line) continue;
        *tab++ = '\0';
        if (strncmp(line, "http://", 7U) != 0 && strncmp(line, "https://", 8U) != 0) continue;
        copy_text(g_bookmarks[g_bookmark_count].url, sizeof(g_bookmarks[g_bookmark_count].url), line);
        copy_text(g_bookmarks[g_bookmark_count].title, sizeof(g_bookmarks[g_bookmark_count].title), tab);
        ++g_bookmark_count;
    }
    (void)fclose(file);
}

static bool save_bookmarks(void)
{
    FILE *file = fopen("X360Browser-bookmarks.tmp", "w");
    size_t i;
    if (file == NULL) return false;
    for (i = 0U; i < g_bookmark_count; ++i) {
        char title[WEB_ENGINE_TITLE_CAP];
        size_t j;
        copy_text(title, sizeof(title), g_bookmarks[i].title);
        for (j = 0U; title[j] != '\0'; ++j)
            if (title[j] == '\t' || title[j] == '\r' || title[j] == '\n') title[j] = ' ';
        if (fprintf(file, "%s\t%s\n", g_bookmarks[i].url, title) < 0) {
            (void)fclose(file); (void)remove("X360Browser-bookmarks.tmp"); return false;
        }
    }
    if (fclose(file) != 0) { (void)remove("X360Browser-bookmarks.tmp"); return false; }
    (void)remove("X360Browser-bookmarks.txt");
    if (rename("X360Browser-bookmarks.tmp", "X360Browser-bookmarks.txt") != 0) {
        (void)remove("X360Browser-bookmarks.tmp");
        return false;
    }
    return true;
}

static void add_current_bookmark(void)
{
    size_t i;
    pthread_mutex_lock(&g_state_lock);
    if (!g_page_loaded) {
        copy_text(g_status, sizeof(g_status), "Load a page before saving a favorite.");
        pthread_mutex_unlock(&g_state_lock); return;
    }
    for (i = 0U; i < g_bookmark_count; ++i) {
        if (strcmp(g_bookmarks[i].url, g_current_url) == 0) {
            copy_text(g_bookmarks[i].title, sizeof(g_bookmarks[i].title), g_page.title);
            g_selected_bookmark = i; g_show_bookmarks = true;
            g_show_links = false; g_show_resources = false; g_show_visual = false;
            copy_text(g_status, sizeof(g_status), "Favorite refreshed.");
            pthread_mutex_unlock(&g_state_lock);
            if (!save_bookmarks()) { pthread_mutex_lock(&g_state_lock); copy_text(g_status, sizeof(g_status), "Favorite saved for this session only: storage unavailable."); pthread_mutex_unlock(&g_state_lock); }
            return;
        }
    }
    if (g_bookmark_count == BOOKMARK_COUNT) {
        memmove(&g_bookmarks[0], &g_bookmarks[1], (BOOKMARK_COUNT - 1U) * sizeof(g_bookmarks[0]));
        --g_bookmark_count;
    }
    copy_text(g_bookmarks[g_bookmark_count].url, sizeof(g_bookmarks[g_bookmark_count].url), g_current_url);
    copy_text(g_bookmarks[g_bookmark_count].title, sizeof(g_bookmarks[g_bookmark_count].title), g_page.title);
    g_selected_bookmark = g_bookmark_count++;
    g_show_bookmarks = true; g_show_links = false; g_show_resources = false; g_show_visual = false;
    copy_text(g_status, sizeof(g_status), "Favorite saved.");
    pthread_mutex_unlock(&g_state_lock);
    if (!save_bookmarks()) { pthread_mutex_lock(&g_state_lock); copy_text(g_status, sizeof(g_status), "Favorite saved for this session only: storage unavailable."); pthread_mutex_unlock(&g_state_lock); }
}

static void toggle_bookmarks(void)
{
    pthread_mutex_lock(&g_state_lock);
    g_show_bookmarks = !g_show_bookmarks;
    if (g_show_bookmarks) {
        g_show_links = false; g_show_resources = false; g_show_visual = false; g_selected_bookmark = 0U;
        copy_text(g_status, sizeof(g_status), g_bookmark_count == 0U ? "No favorites yet. Press LEFT THUMB on a page to save one." : "Saved favorites.");
    }
    pthread_mutex_unlock(&g_state_lock);
}

static void remove_selected_bookmark(void)
{
    pthread_mutex_lock(&g_state_lock);
    if (!g_show_bookmarks || g_bookmark_count == 0U || g_selected_bookmark >= g_bookmark_count) {
        pthread_mutex_unlock(&g_state_lock); return;
    }
    memmove(&g_bookmarks[g_selected_bookmark], &g_bookmarks[g_selected_bookmark + 1U],
            (g_bookmark_count - g_selected_bookmark - 1U) * sizeof(g_bookmarks[0]));
    --g_bookmark_count;
    if (g_selected_bookmark >= g_bookmark_count && g_bookmark_count > 0U) --g_selected_bookmark;
    copy_text(g_status, sizeof(g_status), "Favorite removed.");
    pthread_mutex_unlock(&g_state_lock);
    if (!save_bookmarks()) { pthread_mutex_lock(&g_state_lock); copy_text(g_status, sizeof(g_status), "Favorite removed for this session; storage could not be updated."); pthread_mutex_unlock(&g_state_lock); }
}

static void *fetch_worker(void *argument)
{
    struct FetchTask *task = (struct FetchTask *)argument;
    WebEnginePage *downloaded = NULL;
    char error[192] = { 0 };
    char resolved_stream[WEB_ENGINE_RESOURCE_URL_CAP] = { 0 };
    int result = 0;
    const bool is_media = task->is_media;
    const bool is_audio = task->is_audio;
    const bool resolve_only = task->resolve_only;

    if (resolve_only) {
        /* Resolving a public YouTube instance may take seconds; never block the UI loop. */
        result = web_engine_resolve_youtube_stream(task->url, resolved_stream,
                                                   sizeof(resolved_stream), error, sizeof(error));
    } else if (is_media) {
        result = web_engine_download_media(task->url, task->destination,
                                           is_audio ? "audio" : "video",
                                           error, sizeof(error));
    } else {
        downloaded = (WebEnginePage *)calloc(1U, sizeof(*downloaded));
        if (downloaded != NULL)
            result = web_engine_fetch(task->url, downloaded, error, sizeof(error));
        else
            copy_text(error, sizeof(error), "Not enough memory for a web page");
    }

    pthread_mutex_lock(&g_state_lock);
    if (resolve_only) {
        g_media_stream_resolve_done = true;
        g_media_stream_resolve_ok = result != 0;
        if (result != 0) {
            copy_text(g_media_resolved_stream_url, sizeof(g_media_resolved_stream_url), resolved_stream);
            copy_text(g_status, sizeof(g_status), "YouTube MP4 resolved. Opening the configured external player...");
        } else {
            (void)snprintf(g_status, sizeof(g_status), "YOUTUBE ERROR: %.160s",
                           error[0] != '\0' ? error : "no compatible MP4 stream was returned");
        }
    } else if (is_media) {
        g_media_download_done = true;
        g_media_download_ok = result != 0;
        g_media_download_is_audio = is_audio;
        g_media_downloading = false;
        if (result != 0)
            (void)snprintf(g_status, sizeof(g_status), "%s downloaded. Opening external player...",
                           is_audio ? "Audio" : "Video");
        else
            (void)snprintf(g_status, sizeof(g_status), "MEDIA ERROR: %.170s",
                           error[0] != '\0' ? error : "download failed");
    } else if (result != 0 && downloaded != NULL) {
        g_page = *downloaded;
        web_visual_renderer_invalidate();
        g_page_loaded = true;
        if (error[0] != '\0')
            (void)snprintf(g_status, sizeof(g_status), "%.78s | links %lu | imgs %lu | media %lu",
                           error, (unsigned long)g_page.link_count,
                           (unsigned long)g_page.image_count, (unsigned long)g_page.media_count);
        else
            (void)snprintf(g_status, sizeof(g_status), "HTTP %ld | links %lu | imgs %lu | media %lu",
                           g_page.http_status, (unsigned long)g_page.link_count,
                           (unsigned long)g_page.image_count, (unsigned long)g_page.media_count);
        g_selected_link = 0U; g_selected_resource = 0U; g_scroll_line = 0U;
        g_show_links = false; g_show_resources = false; g_show_bookmarks = false;
        g_show_visual = !g_page.is_direct_resource;
        xsdk_log_write(
            "X360Browser: page ready HTTP=%ld type=%.72s bytes=%lu direct=%d renderer=%s view=%s links=%lu images=%lu media=%lu forms=%lu",
            g_page.http_status, g_page.content_type[0] != '\0' ? g_page.content_type : "unknown",
            (unsigned long)g_page.html_bytes, (int)g_page.is_direct_resource,
            g_visual_renderer_ready ? "ready" : "unavailable",
            g_show_visual ? "GRAPHICAL" : "RESOURCE-CARD",
            (unsigned long)g_page.link_count, (unsigned long)g_page.image_count,
            (unsigned long)g_page.media_count, (unsigned long)g_page.form_count);
    } else {
        (void)snprintf(g_status, sizeof(g_status), "LOAD FAILED: %.170s", error[0] != '\0' ? error : "unknown network error");
        xsdk_log_write("X360Browser: page load failed URL=%.150s error=%.120s", task->url,
                       error[0] != '\0' ? error : "unknown network error");
    }
    g_fetch_running = false;
    g_fetch_finished = true;
    pthread_mutex_unlock(&g_state_lock);
    free(downloaded);
    free(task);
    return NULL;
}

static void poll_fetch_thread(void)
{
    bool finished;
    bool launch_media = false;
    bool was_audio = false;
    bool launch_resolved_stream = false;
    char path[260];
    char resolved_stream[WEB_ENGINE_RESOURCE_URL_CAP] = { 0 };
    pthread_mutex_lock(&g_state_lock);
    finished = g_fetch_finished;
    pthread_mutex_unlock(&g_state_lock);
    if (finished && g_fetch_thread_valid) {
        (void)pthread_join(g_fetch_thread, NULL);
        g_fetch_thread_valid = false;
        pthread_mutex_lock(&g_state_lock);
        g_fetch_finished = false;
        if (g_media_download_done) {
            launch_media = g_media_download_ok;
            was_audio = g_media_download_is_audio;
            g_media_download_done = false;
        }
        if (g_media_stream_resolve_done) {
            launch_resolved_stream = g_media_stream_resolve_ok;
            g_media_stream_resolve_done = false;
            g_media_stream_resolve_ok = false;
            if (launch_resolved_stream)
                copy_text(resolved_stream, sizeof(resolved_stream), g_media_resolved_stream_url);
            g_media_resolved_stream_url[0] = '\0';
        }
        copy_text(path, sizeof(path), g_last_media_path);
        pthread_mutex_unlock(&g_state_lock);
        if (launch_resolved_stream)
            launch_external_media_url(resolved_stream, "video");
        if (launch_media) {
            VideoLaunchInfo info;
            int launch_result;
            memset(&info, 0, sizeof(info));
            (void)snprintf(info.filename, sizeof(info.filename), "%s", path);
            (void)snprintf(info.callingapp, sizeof(info.callingapp), "%s", g_browser_xex_path);
            launch_result = xsdk_launch(g_video_player_path, &info, sizeof(info));
            pthread_mutex_lock(&g_state_lock);
            if (NT_SUCCESS((NTSTATUS)launch_result)) {
                (void)snprintf(g_status, sizeof(g_status), "%s handed off to external player. Playback is outside the browser.",
                               was_audio ? "Audio" : "Video");
            } else {
                (void)snprintf(g_status, sizeof(g_status), "Player launch failed (error %d). Check FFPlay.xex and X360Browser-video-config.txt.", launch_result);
            }
            pthread_mutex_unlock(&g_state_lock);
        }
    }
}

static void start_navigation(const char *address, bool remember_current)
{
    char normalized[WEB_ENGINE_URL_CAP];
    struct FetchTask *task;
    int thread_result;

    if (!g_engine_ready) {
        pthread_mutex_lock(&g_state_lock);
        copy_text(g_status, sizeof(g_status), "Network engine is unavailable: libcurl failed to initialize.");
        pthread_mutex_unlock(&g_state_lock);
        return;
    }
    if (!normalize_address(address, normalized, sizeof(normalized))) {
        pthread_mutex_lock(&g_state_lock);
        copy_text(g_status, sizeof(g_status), "Invalid URL. Use http:// or https://.");
        pthread_mutex_unlock(&g_state_lock);
        return;
    }

    pthread_mutex_lock(&g_state_lock);
    if (g_fetch_running || g_fetch_thread_valid) {
        copy_text(g_status, sizeof(g_status), "A network operation is still running or finishing.");
        pthread_mutex_unlock(&g_state_lock);
        return;
    }
    if (remember_current && g_page_loaded) {
        history_push(g_current_url);
        g_forward_count = 0U;
    }
    copy_text(g_current_url, sizeof(g_current_url), normalized);
    /* Reset per-URL frame telemetry even when reloading the same URL. */
    g_logged_visual_url[0] = '\0';
    memset(&g_page, 0, sizeof(g_page));
    g_page_loaded = false;
    (void)snprintf(g_status, sizeof(g_status), "Connecting to %.160s", normalized);
    g_fetch_running = true;
    g_fetch_finished = false;
    g_show_links = false;
    g_show_resources = false;
    g_show_bookmarks = false;
    g_show_visual = false;
   
    g_selected_resource = 0U;
    g_scroll_line = 0U;
    pthread_mutex_unlock(&g_state_lock);
    web_visual_renderer_invalidate();

    task = (struct FetchTask *)calloc(1U, sizeof(*task));
    if (task == NULL) {
        pthread_mutex_lock(&g_state_lock);
        g_fetch_running = false;
        copy_text(g_status, sizeof(g_status), "Not enough memory to start the request.");
        pthread_mutex_unlock(&g_state_lock);
        return;
    }
    copy_text(task->url, sizeof(task->url), normalized);
    task->is_media = false;
    thread_result = pthread_create(&g_fetch_thread, NULL, fetch_worker, task);
    if (thread_result != 0) {
        free(task);
        pthread_mutex_lock(&g_state_lock);
        g_fetch_running = false;
        (void)snprintf(g_status, sizeof(g_status), "Could not start network worker (%d).", thread_result);
        pthread_mutex_unlock(&g_state_lock);
        return;
    }
    g_fetch_thread_valid = true;
    xsdk_log_write("X360Browser: fetching %.160s", normalized);
}

static void launch_external_media_url(const char *url, const char *media_kind)
{
    VideoLaunchInfo info;
    int launch_result;
    if (strcasecmp(g_video_player_path, "auto") == 0) resolve_auto_media_player();
    if (!external_media_player_enabled()) {
        pthread_mutex_lock(&g_state_lock);
        copy_text(g_status, sizeof(g_status), "Native playback is limited; external-player handoff is disabled. Configure a player path explicitly to opt in.");
        pthread_mutex_unlock(&g_state_lock);
        return;
    }
    if (url == NULL || strlen(url) >= sizeof(info.filename)) {
        pthread_mutex_lock(&g_state_lock);
        copy_text(g_status, sizeof(g_status), "Streaming URL is too long for the external-player launch interface.");
        pthread_mutex_unlock(&g_state_lock);
        return;
    }
    memset(&info, 0, sizeof(info));
    copy_text(info.filename, sizeof(info.filename), url);
    copy_text(info.callingapp, sizeof(info.callingapp), g_browser_xex_path);
    launch_result = xsdk_launch(g_video_player_path, &info, sizeof(info));
    pthread_mutex_lock(&g_state_lock);
    if (NT_SUCCESS((NTSTATUS)launch_result)) {
        (void)snprintf(g_status, sizeof(g_status), "Streaming %s URL handed to player; player must support HTTP/HTTPS and the stream codec.",
                       media_kind != NULL && strcmp(media_kind, "audio") == 0 ? "audio" : "video");
    } else {
        (void)snprintf(g_status, sizeof(g_status), "Player launch failed (error %d). Check the configured external player.", launch_result);
    }
    pthread_mutex_unlock(&g_state_lock);
}

static void start_media_playback(const char *url, const char *media_kind)
{
    struct FetchTask *task;
    int result;
    bool is_audio = media_kind != NULL && strcmp(media_kind, "audio") == 0;
    const char *destination = is_audio ? g_audio_file_path : g_video_file_path;
    if (strcasecmp(g_video_player_path, "auto") == 0) resolve_auto_media_player();
    if (!external_media_player_enabled()) {
        pthread_mutex_lock(&g_state_lock);
        copy_text(g_status, sizeof(g_status), g_video_player_auto_missing ?
                  "Playback unavailable: copy a compatible FFPlay.xex beside default.xex or set its path in X360Browser-video-config.txt." :
                  "Playback disabled by configuration. Set player path to auto or a compatible XEX in X360Browser-video-config.txt.");
        pthread_mutex_unlock(&g_state_lock);
        return;
    }
    if (url == NULL ||
        (strncasecmp(url, "http://", 7U) != 0 && strncasecmp(url, "https://", 8U) != 0)) {
        pthread_mutex_lock(&g_state_lock);
        copy_text(g_status, sizeof(g_status), "Media playback supports HTTP/HTTPS URLs only.");
        pthread_mutex_unlock(&g_state_lock);
        return;
    }
    if (is_hls_manifest(url, NULL))
        destination = is_audio ? HLS_AUDIO_FILE_PATH : HLS_VIDEO_FILE_PATH;

    pthread_mutex_lock(&g_state_lock);
    if (g_fetch_running || g_fetch_thread_valid) {
        copy_text(g_status, sizeof(g_status), "Another network operation is still running.");
        pthread_mutex_unlock(&g_state_lock);
        return;
    }
    if (!g_engine_ready && (!g_media_stream_url_mode || (!is_audio && web_engine_is_youtube_url(url)))) {
        copy_text(g_status, sizeof(g_status), "Network engine is unavailable for media download/YouTube resolution.");
        pthread_mutex_unlock(&g_state_lock);
        return;
    }
    if (g_media_stream_url_mode) {
        bool resolve_youtube = !is_audio && web_engine_is_youtube_url(url);
        if (!resolve_youtube) {
            pthread_mutex_unlock(&g_state_lock);
            launch_external_media_url(url, is_audio ? "audio" : "video");
            return;
        }
        g_fetch_running = true;
        g_fetch_finished = false;
        g_media_stream_resolve_done = false;
        g_media_stream_resolve_ok = false;
        g_media_resolved_stream_url[0] = '\0';
        copy_text(g_status, sizeof(g_status), "Resolving YouTube MP4 URL in background; controller remains responsive...");
        pthread_mutex_unlock(&g_state_lock);
        task = (struct FetchTask *)calloc(1U, sizeof(*task));
        if (task == NULL) {
            pthread_mutex_lock(&g_state_lock);
            g_fetch_running = false;
            copy_text(g_status, sizeof(g_status), "Not enough memory to resolve the YouTube stream.");
            pthread_mutex_unlock(&g_state_lock);
            return;
        }
        copy_text(task->url, sizeof(task->url), url);
        task->resolve_only = true;
        task->is_media = false;
        task->is_audio = false;
        result = pthread_create(&g_fetch_thread, NULL, fetch_worker, task);
        if (result != 0) {
            free(task);
            pthread_mutex_lock(&g_state_lock);
            g_fetch_running = false;
            (void)snprintf(g_status, sizeof(g_status), "Could not start YouTube resolver worker (%d).", result);
            pthread_mutex_unlock(&g_state_lock);
            return;
        }
        g_fetch_thread_valid = true;
        return;
    }
    g_fetch_running = true;
    g_fetch_finished = false;
    g_media_downloading = true;
    g_media_download_done = false;
    g_media_download_ok = false;
    g_media_download_is_audio = is_audio;
    copy_text(g_last_media_path, sizeof(g_last_media_path), destination);
    (void)snprintf(g_status, sizeof(g_status), "%s", is_hls_manifest(url, NULL) ?
                   (is_audio ? "Downloading audio HLS VOD playlist..." : "Downloading video HLS VOD playlist...") :
                   (is_audio ? "Downloading audio for external playback..." : "Downloading video for external playback..."));
    pthread_mutex_unlock(&g_state_lock);
    task = (struct FetchTask *)calloc(1U, sizeof(*task));
    if (task == NULL) {
        pthread_mutex_lock(&g_state_lock);
        g_fetch_running = false; g_media_downloading = false;
        copy_text(g_status, sizeof(g_status), "Not enough memory for a media download.");
        pthread_mutex_unlock(&g_state_lock);
        return;
    }
    copy_text(task->url, sizeof(task->url), url);
    copy_text(task->destination, sizeof(task->destination), destination);
    task->is_media = true;
    task->is_audio = is_audio;
    result = pthread_create(&g_fetch_thread, NULL, fetch_worker, task);
    if (result != 0) {
        free(task);
        pthread_mutex_lock(&g_state_lock);
        g_fetch_running = false; g_media_downloading = false;
        (void)snprintf(g_status, sizeof(g_status), "Could not start media worker (%d).", result);
        pthread_mutex_unlock(&g_state_lock);
        return;
    }
    g_fetch_thread_valid = true;
}

static void keyboard_submit(void)
{
    char address[WEB_ENGINE_URL_CAP] = { 0 };
    size_t i;
    size_t out = 0U;
    for (i = 0U; i < WEB_ENGINE_URL_CAP - 1U && g_keyboard_text[i] != 0U; ++i) {
        uint32_t cp = g_keyboard_text[i];
        if (cp >= 0xD800U && cp <= 0xDBFFU && i + 1U < WEB_ENGINE_URL_CAP &&
            g_keyboard_text[i + 1U] >= 0xDC00U && g_keyboard_text[i + 1U] <= 0xDFFFU) {
            cp = 0x10000U + ((cp - 0xD800U) << 10U) + ((uint32_t)g_keyboard_text[++i] - 0xDC00U);
        } else if (cp >= 0xD800U && cp <= 0xDFFFU) {
            cp = '?';
        }
        if (!append_utf8(address, sizeof(address), &out, cp)) break;
    }
    if (g_keyboard_control_mode) {
        int updated = web_visual_renderer_set_control_value(&g_page, g_keyboard_control_node, address);
        g_keyboard_control_mode = false;
        g_keyboard_control_node = UINT16_MAX;
        pthread_mutex_lock(&g_state_lock);
        copy_text(g_status, sizeof(g_status), updated ?
            "Web field updated. Activate its button to run page actions." :
            "Could not update this webpage field; DOM limit reached or field stale.");
        pthread_mutex_unlock(&g_state_lock);
        return;
    }
    if (out > 0U) {
        char normalized[WEB_ENGINE_URL_CAP];
        if (normalize_address(address, normalized, sizeof(normalized)) &&
            (is_direct_audio_url(normalized) || is_direct_video_url(normalized) ||
             web_engine_is_youtube_url(normalized) || is_hls_manifest(normalized, NULL)))
            start_media_playback(normalized, is_direct_audio_url(normalized) ? "audio" : "video");
        else
            start_navigation(address, true);
    } else {
        pthread_mutex_lock(&g_state_lock); copy_text(g_status, sizeof(g_status), "Address entry cancelled or too long."); pthread_mutex_unlock(&g_state_lock);
    }
}

static void begin_address_keyboard(void)
{
    uint32_t user_index = XSDK_XAM_USER_NONE;
    char gamertag[XSDK_XAM_GAMERTAG_BYTES] = { 0 };
    uint32_t result;
    size_t i;
    size_t initial_length;
    char initial[WEB_ENGINE_URL_CAP] = { 0 };
    static const uint16_t title[] = { 'G','o',' ','t','o',' ','w','e','b',' ','a','d','d','r','e','s','s',0 };
    static const uint16_t description[] = { 'T','y','p','e',' ','U','R','L',' ','o','r',' ','s','e','a','r','c','h',' ','t','e','r','m','s',0 };

    if (g_keyboard_active)
        return;
    pthread_mutex_lock(&g_state_lock);
    copy_text(initial, sizeof(initial), g_current_url);
    pthread_mutex_unlock(&g_state_lock);
    /* copy_text always terminates initial; initialize the remaining tail as well for analyzers. */
    initial_length = strlen(initial);
    if (initial_length > WEB_ENGINE_URL_CAP - 1U) initial_length = WEB_ENGINE_URL_CAP - 1U;
    memset(g_keyboard_text, 0, sizeof(g_keyboard_text));
    memset(g_keyboard_default, 0, sizeof(g_keyboard_default));
    for (i = 0U; i < initial_length; ++i)
        g_keyboard_default[i] = (uint16_t)(unsigned char)initial[i];
    (void)xsdk_xam_signed_in_user(&user_index, gamertag);
    xsdk_xam_prepare(&g_keyboard_overlapped);
    result = xsdk_xam_keyboard(user_index, title, description, g_keyboard_default,
                               g_keyboard_text, WEB_ENGINE_URL_CAP, &g_keyboard_overlapped);
    result = xsdk_xam_returned(&g_keyboard_overlapped, result);
    if (result == ERROR_IO_PENDING) {
        g_keyboard_active = true;
    } else if (result == ERROR_SUCCESS) {
        keyboard_submit();
    } else {
        pthread_mutex_lock(&g_state_lock);
        (void)snprintf(g_status, sizeof(g_status), "Address keyboard failed: 0x%08X", (unsigned)result);
        pthread_mutex_unlock(&g_state_lock);
    }
}

static void begin_control_keyboard(uint16_t node_index)
{
    uint32_t user_index = XSDK_XAM_USER_NONE;
    char gamertag[XSDK_XAM_GAMERTAG_BYTES] = { 0 };
    uint32_t result;
    size_t i, length;
    char initial[WEB_ENGINE_URL_CAP] = { 0 };
    static const uint16_t title[] = { 'E','d','i','t',' ','w','e','b',' ','f','i','e','l','d',0 };
    static const uint16_t description[] = { 'E','n','t','e','r',' ','t','e','x','t',' ','f','o','r',' ','t','h','i','s',' ','f','i','e','l','d',0 };
    if (g_keyboard_active) return;
    if (!web_visual_renderer_get_control_value(&g_page, node_index, initial, sizeof(initial))) {
        pthread_mutex_lock(&g_state_lock);
        copy_text(g_status, sizeof(g_status), "Could not read this webpage field.");
        pthread_mutex_unlock(&g_state_lock);
        return;
    }
    length = strlen(initial);
    if (length >= WEB_ENGINE_URL_CAP) length = WEB_ENGINE_URL_CAP - 1U;
    memset(g_keyboard_text, 0, sizeof(g_keyboard_text));
    memset(g_keyboard_default, 0, sizeof(g_keyboard_default));
    for (i = 0U; i < length; ++i) g_keyboard_default[i] = (uint16_t)(unsigned char)initial[i];
    (void)xsdk_xam_signed_in_user(&user_index, gamertag);
    xsdk_xam_prepare(&g_keyboard_overlapped);
    g_keyboard_control_mode = true;
    g_keyboard_control_node = node_index;
    result = xsdk_xam_keyboard(user_index, title, description, g_keyboard_default,
                               g_keyboard_text, WEB_ENGINE_URL_CAP, &g_keyboard_overlapped);
    result = xsdk_xam_returned(&g_keyboard_overlapped, result);
    if (result == ERROR_IO_PENDING) {
        g_keyboard_active = true;
    } else if (result == ERROR_SUCCESS) {
        keyboard_submit();
    } else {
        g_keyboard_control_mode = false;
        g_keyboard_control_node = UINT16_MAX;
        pthread_mutex_lock(&g_state_lock);
        (void)snprintf(g_status, sizeof(g_status), "Web field keyboard failed: 0x%08X", (unsigned)result);
        pthread_mutex_unlock(&g_state_lock);
    }
}

static void poll_address_keyboard(void)
{
    uint32_t result;
    if (!g_keyboard_active)
        return;
    result = xsdk_xam_wait(&g_keyboard_overlapped, 0U, NULL);
    if (result == ERROR_IO_INCOMPLETE)
        return;
    g_keyboard_active = false;
    if (result == ERROR_SUCCESS)
        keyboard_submit();
    else {
        g_keyboard_control_mode = false;
        g_keyboard_control_node = UINT16_MAX;
        pthread_mutex_lock(&g_state_lock);
        copy_text(g_status, sizeof(g_status), "Keyboard entry cancelled or unavailable.");
        pthread_mutex_unlock(&g_state_lock);
    }
}

static void draw_link_list(const WebEnginePage *page, size_t first, size_t selected)
{
    size_t i;
    size_t end = first + VISIBLE_LINES;
    char line[WEB_ENGINE_LINK_LABEL_CAP + 24U];
    if (end > page->link_count)
        end = page->link_count;
    if (page->link_count == 0U) {
        xsdk_text_draw(64, 218, 1U, COLOR_MUTED, "No links were found in this page.");
        return;
    }
    for (i = first; i < end; ++i) {
        const WebEngineLink *link = &page->links[i];
        (void)snprintf(line, sizeof(line), "%c %02lu. %.104s",
                       i == selected ? '>' : ' ', (unsigned long)(i + 1U), link->label);
        xsdk_text_draw(60, 202 + (int32_t)((i - first) * 20U), 1U,
                       i == selected ? COLOR_GOLD : COLOR_WHITE, line);
    }
    xsdk_text_draw(64, 610, 1U, COLOR_MUTED, "A: OPEN LINK   X: NEXT VIEW   UP/DOWN: SELECT");
}

static size_t page_resource_count(const WebEnginePage *page)
{
    return page->image_count + page->media_count;
}

static void draw_resource_list(const WebEnginePage *page, size_t first, size_t selected)
{
    size_t i;
    size_t total = page_resource_count(page);
    size_t end = first + VISIBLE_LINES;
    char line[180];
    if (end > total)
        end = total;
    if (total == 0U) {
        xsdk_text_draw(64, 218, 1U, COLOR_MUTED,
                       "No image or embedded-resource URLs were found.");
        xsdk_text_draw(64, 248, 1U, COLOR_MUTED,
                       "Some sites create resources with JavaScript; this fallback cannot see those.");
        return;
    }
    for (i = first; i < end; ++i) {
        if (i < page->image_count) {
            const WebEngineImage *image = &page->images[i];
            (void)snprintf(line, sizeof(line), "%c [IMG] %.70s | %.78s",
                           i == selected ? '>' : ' ', image->alt, image->url);
        } else {
            const WebEngineMedia *media = &page->media[i - page->image_count];
            (void)snprintf(line, sizeof(line), "%c [%s] %.24s | %.90s",
                           i == selected ? '>' : ' ', media->kind,
                           media->mime_type, media->url);
        }
        xsdk_text_draw(58, 202 + (int32_t)((i - first) * 20U), 1U,
                       i == selected ? COLOR_GOLD : COLOR_WHITE, line);
    }
    xsdk_text_draw(64, 610, 1U, COLOR_MUTED,
                   "A: OPEN/PLAY MEDIA   X: NEXT VIEW   UP/DOWN: SELECT");
}

static void draw_screen(uint32_t width, uint32_t height)
{
    uint32_t address = 0U;
    NTSTATUS present_status = xsdk_present_begin(&address, BEGIN_TIMEOUT_MS);
    char url_line[176];
    char title_line[176];
    char status_line[232];
    char engine_line[160];
    bool loading;
    bool loaded;
    bool show_links;
    bool show_resources;
    bool show_bookmarks;
    bool show_visual;
    size_t selected_bookmark;
    uint32_t status_color;
    size_t scroll;
    size_t selected;
    size_t selected_resource;
    WebEnginePage *page = &g_page;

    if (!NT_SUCCESS(present_status)) {
        xsdk_log_write("X360Browser: present begin failed: 0x%08X", (unsigned)present_status);
        return;
    }
    xsdk_gpu_set_target(width, height);

    pthread_mutex_lock(&g_state_lock);
    loading = g_fetch_running;
    loaded = g_page_loaded;
    show_links = g_show_links;
    show_resources = g_show_resources;
    show_bookmarks = g_show_bookmarks;
    show_visual = g_show_visual;
    selected_bookmark = g_selected_bookmark;
    scroll = g_scroll_line;
    selected = g_selected_link;
    selected_resource = g_selected_resource;
    (void)snprintf(url_line, sizeof(url_line), "[ %s ]  %.150s", "ADDRESS / SEARCH", g_current_url);
    (void)snprintf(title_line, sizeof(title_line), "%.164s",
                   loaded ? page->title : "X360Browser " X360BROWSER_VERSION_STRING " - XenonWeb Next");
    (void)snprintf(status_line, sizeof(status_line), "%.220s", g_status);
    (void)snprintf(engine_line, sizeof(engine_line), "%.150s", web_engine_backend_label());
    status_color = loading ? COLOR_GOLD : COLOR_GREEN;
    if (!g_engine_ready || strncmp(status_line, "LOAD FAILED", 11U) == 0 ||
        strncmp(status_line, "HTTP 4", 6U) == 0 || strncmp(status_line, "HTTP 5", 6U) == 0 ||
        strstr(status_line, "ERROR") != NULL || strstr(status_line, "failed") != NULL ||
        strstr(status_line, "FAILED") != NULL)
        status_color = COLOR_RED;

    xsdk_text_draw(36, 12, 2U, COLOR_WHITE, "X360Browser " X360BROWSER_VERSION_STRING);
    xsdk_text_draw(295, 18, 1U, COLOR_MUTED, "HOME: START  BACK: B  RELOAD: Y");
    xsdk_text_draw(900, 18, 1U, COLOR_BLUE, engine_line);
    xsdk_text_draw(36, 48, 1U, COLOR_BLUE, url_line);
    xsdk_text_draw(36, 76, 1U, status_color, status_line);
    xsdk_text_draw(36, 101, 1U, COLOR_GOLD, title_line);

    if (loading) {
        xsdk_text_draw(64, 236, 2U, COLOR_WHITE, g_media_downloading ? "Preparing media for external playback..." : "Loading page...");
        xsdk_text_draw(64, 282, 1U, COLOR_MUTED,
                       "XenonWeb is the project-owned HTML/CSS layout engine.");
        xsdk_text_draw(64, 312, 1U, COLOR_MUTED,
                       "Network/TLS uses the project request adapter; VisualLite is an in-project layout fallback.");
    } else if (show_bookmarks) {
        xsdk_text_draw(58, 176, 1U, COLOR_BLUE, "SAVED FAVORITES  |  UP/DOWN SELECT  |  A OPEN  |  Y REMOVE");
        draw_bookmarks(selected_bookmark);
    } else if (!loaded) {
        if (strstr(status_line, "LOAD FAILED") != NULL) {
            xsdk_text_draw(58, 184, 2U, COLOR_RED, "PAGE COULD NOT BE LOADED");
            xsdk_text_draw(58, 224, 1U, COLOR_WHITE, "This is a browser error surface, not a text dump of the response.");
            xsdk_text_draw(58, 254, 1U, COLOR_MUTED, "Check the URL, TLS/network access, or the cause shown in default.log.");
            xsdk_text_draw(58, 284, 1U, COLOR_GOLD, "A: ADDRESS/SEARCH   Y: RETRY   START: HOME");
        } else {
            xsdk_text_draw(64, 210, 2U, COLOR_WHITE, "WELCOME TO X360BROWSER " X360BROWSER_VERSION_STRING);
            xsdk_text_draw(64, 253, 1U, COLOR_MUTED,
                           "XENONWEB  |  GRAPHICAL-FIRST HTML/CSS RENDERER");
            xsdk_text_draw(64, 282, 1U, COLOR_MUTED,
                           "DOM, CSS subset, bounded scripts, forms, links and image rasterization.");
            xsdk_text_draw(64, 312, 1U, COLOR_MUTED,
                           "The browser keeps a graphical page surface; no text-reader fallback is used.");
            xsdk_text_draw(64, 342, 1U, COLOR_MUTED,
                           "Media support is experimental; YouTube playback may need an external player.");
            xsdk_text_draw(64, 378, 1U, COLOR_GOLD,
                           "START: home   A: address/search   X: views   B: back   Y: reload");
            xsdk_text_draw(64, 406, 1U, COLOR_MUTED,
                           "LEFT/RIGHT: link focus | UP/DOWN: scroll | LB/RB: page scroll");
        }
    } else if (show_links) {
        xsdk_text_draw(58, 176, 1U, COLOR_BLUE, "PAGE LINKS (YouTube MP4 fallback / compatible media needs configured player)");
        draw_link_list(page, selected >= VISIBLE_LINES ? selected - VISIBLE_LINES + 1U : 0U, selected);
    } else if (show_resources) {
        xsdk_text_draw(58, 176, 1U, COLOR_BLUE, "RESOURCES (MEDIA: native formats limited; optional player only if configured)");
        draw_resource_list(page,
                           selected_resource >= VISIBLE_LINES ? selected_resource - VISIBLE_LINES + 1U : 0U,
                           selected_resource);
    } else if (show_visual && g_visual_renderer_ready) {
        g_visual_content_height = web_visual_renderer_draw(page, scroll * 20U, width, height);
        if (strcmp(g_logged_visual_url, g_current_url) != 0) {
            copy_text(g_logged_visual_url, sizeof(g_logged_visual_url), g_current_url);
            xsdk_log_write("X360Browser: GRAPHICAL FRAME URL=%.150s content-height=%lu viewport=1280x544",
                           g_current_url, (unsigned long)g_visual_content_height);
        }
        if (g_pointer_mode)
            xsdk_text_draw(g_cursor_x, g_cursor_y, 2U, COLOR_GOLD, "+");
        (void)snprintf(status_line, sizeof(status_line),
                       "GRAPHICAL VIEW | links %lu | images %lu | media %lu | forms %lu | scroll %lu",
                       (unsigned long)page->link_count, (unsigned long)page->image_count,
                       (unsigned long)page->media_count, (unsigned long)page->form_count,
                       (unsigned long)(scroll * 20U));
        xsdk_text_draw(8, 660, 1U, COLOR_MUTED, status_line);
    } else {
        /* This surface deliberately never prints page->text. The old text-reader
         * fallback hid renderer failures and made web pages look like raw dumps. */
        if (page->is_direct_resource) {
            xsdk_text_draw(58, 176, 2U, COLOR_BLUE, "WEB RESOURCE");
            xsdk_text_draw(58, 218, 1U, COLOR_WHITE, page->content_type[0] ? page->content_type : "Unknown resource type");
            xsdk_text_draw(58, 250, 1U, COLOR_MUTED, "This URL is a resource, not an HTML document.");
            xsdk_text_draw(58, 282, 1U, COLOR_MUTED, "Native preview is unavailable for this resource type.");
            xsdk_text_draw(58, 318, 1U, COLOR_GOLD, "A: OPEN ADDRESS   B: BACK   Y: RELOAD");
            (void)snprintf(status_line, sizeof(status_line), "RESOURCE CARD | links %lu | media %lu",
                           (unsigned long)page->link_count, (unsigned long)page->media_count);
        } else if (!g_visual_renderer_ready) {
            xsdk_text_draw(58, 176, 2U, COLOR_RED, "GRAPHICAL RENDERER UNAVAILABLE");
            xsdk_text_draw(58, 220, 1U, COLOR_WHITE, "The page was fetched, but the graphics pipeline did not initialize.");
            xsdk_text_draw(58, 250, 1U, COLOR_MUTED, "Text-only page fallback is disabled in this release.");
            xsdk_text_draw(58, 280, 1U, COLOR_MUTED, "See renderer shader/texture errors in game:\\default.log.");
            xsdk_text_draw(58, 316, 1U, COLOR_GOLD, "Press Y to retry the page or A to enter another address.");
            (void)snprintf(status_line, sizeof(status_line), "GRAPHICS ERROR | HTTP %ld", page->http_status);
        } else {
            xsdk_text_draw(58, 176, 2U, COLOR_RED, "GRAPHICAL PAGE SURFACE UNAVAILABLE");
            xsdk_text_draw(58, 220, 1U, COLOR_WHITE, "The document could not be drawn as a visual page.");
            xsdk_text_draw(58, 250, 1U, COLOR_MUTED, "The browser will not expose the page as a plain-text dump.");
            xsdk_text_draw(58, 280, 1U, COLOR_MUTED, "Check the GRAPHICAL FRAME entry and XenonWeb layout diagnostics.");
            (void)snprintf(status_line, sizeof(status_line), "GRAPHICS ERROR | HTTP %ld", page->http_status);
        }
        xsdk_text_draw(8, 660, 1U, COLOR_MUTED, status_line);
    }

    xsdk_text_draw(36, 690, 1U, COLOR_WHITE,
                   "A: OPEN/ADDRESS   X: VIEW   Y: RELOAD   B: BACK   START: HOME   LS: SAVE   RS: CURSOR/FAVORITES   LB/RB: SCROLL");
    pthread_mutex_unlock(&g_state_lock);
    xsdk_gpu_resolve(address, width, height, CLEAR_ARGB);
    xsdk_present_end();
}

static void change_scroll(int direction)
{
    size_t total;
    pthread_mutex_lock(&g_state_lock);
    if (g_show_bookmarks) {
        if (direction < 0 && g_selected_bookmark > 0U) --g_selected_bookmark;
        else if (direction > 0 && g_selected_bookmark + 1U < g_bookmark_count) ++g_selected_bookmark;
        pthread_mutex_unlock(&g_state_lock);
        return;
    }
    if (!g_page_loaded) {
        pthread_mutex_unlock(&g_state_lock);
        return;
    }
    if (g_show_links) {
        total = g_page.link_count;
        if (direction < 0 && g_selected_link > 0U)
            --g_selected_link;
        else if (direction > 0 && g_selected_link + 1U < total)
            ++g_selected_link;
        pthread_mutex_unlock(&g_state_lock);
        return;
    }
    if (g_show_resources) {
        total = page_resource_count(&g_page);
        if (direction < 0 && g_selected_resource > 0U)
            --g_selected_resource;
        else if (direction > 0 && g_selected_resource + 1U < total)
            ++g_selected_resource;
        pthread_mutex_unlock(&g_state_lock);
        return;
    }
    if (!g_show_visual && g_page.is_direct_resource) {
        pthread_mutex_unlock(&g_state_lock);
        return;
    }
    total = g_show_visual ? ((g_visual_content_height + 19U) / 20U) : 1U;
    if (direction < 0) {
        if (g_scroll_line > 0U)
            --g_scroll_line;
    } else if (g_scroll_line + VISIBLE_LINES < total) {
        ++g_scroll_line;
    }
    pthread_mutex_unlock(&g_state_lock);
}

static void activate_link_index(size_t selected_index)
{
    char url[WEB_ENGINE_LINK_URL_CAP];
    bool have_link = false;
    bool is_video = false;
    bool is_audio = false;
    pthread_mutex_lock(&g_state_lock);
    if (selected_index < g_page.link_count) {
        copy_text(url, sizeof(url), g_page.links[selected_index].url);
        is_video = g_page.links[selected_index].is_video != 0;
        is_audio = g_page.links[selected_index].is_audio != 0;
        have_link = true;
    }
    pthread_mutex_unlock(&g_state_lock);
    if (have_link) {
        if (is_dash_manifest(url, NULL)) {
            pthread_mutex_lock(&g_state_lock); copy_text(g_status, sizeof(g_status), "MPEG-DASH playback is not supported yet."); pthread_mutex_unlock(&g_state_lock);
        } else if (is_audio || is_direct_audio_url(url)) {
            start_media_playback(url, "audio");
        } else if (is_video || is_direct_video_url(url) || web_engine_is_youtube_url(url) ||
                   is_hls_manifest(url, NULL)) {
            start_media_playback(url, "video");
        } else {
            start_navigation(url, true);
        }
    } else {
        begin_address_keyboard();
    }
}

static void activate_selected_link(void)
{
    size_t selected_index;
    pthread_mutex_lock(&g_state_lock);
    selected_index = g_selected_link;
    pthread_mutex_unlock(&g_state_lock);
    activate_link_index(selected_index);
}

static void activate_selected_resource(void)
{
    char url[WEB_ENGINE_RESOURCE_URL_CAP] = { 0 };
    char kind[16] = { 0 };
    char mime[WEB_ENGINE_RESOURCE_TYPE_CAP] = { 0 };
    bool have_resource = false;
    bool from_bookmark = false;
    pthread_mutex_lock(&g_state_lock);
    if (g_show_bookmarks && g_selected_bookmark < g_bookmark_count) {
        copy_text(url, sizeof(url), g_bookmarks[g_selected_bookmark].url);
        have_resource = true; from_bookmark = true;
    } else if (g_selected_resource < g_page.image_count) {
        copy_text(url, sizeof(url), g_page.images[g_selected_resource].url); have_resource = true;
    } else if (g_selected_resource < page_resource_count(&g_page)) {
        size_t index = g_selected_resource - g_page.image_count;
        copy_text(url, sizeof(url), g_page.media[index].url);
        copy_text(kind, sizeof(kind), g_page.media[index].kind);
        copy_text(mime, sizeof(mime), g_page.media[index].mime_type);
        have_resource = true;
    }
    if (from_bookmark) g_show_bookmarks = false;
    pthread_mutex_unlock(&g_state_lock);
    if (!have_resource) return;
    if (is_dash_manifest(url, mime)) {
        pthread_mutex_lock(&g_state_lock); copy_text(g_status, sizeof(g_status), "MPEG-DASH is not supported yet; this stream needs a compatible media pipeline."); pthread_mutex_unlock(&g_state_lock);
    } else if (strcasecmp(kind, "audio") == 0 || is_direct_audio_url(url) ||
               is_direct_audio_mime(mime)) {
        start_media_playback(url, "audio");
    } else if (is_direct_video_url(url) || is_hls_manifest(url, mime) ||
               (strcasecmp(kind, "video") == 0 && is_direct_video_mime(mime))) {
        start_media_playback(url, "video");
    } else {
        start_navigation(url, true);
    }
}

static void draw_bookmarks(size_t selected)
{
    size_t first = selected >= VISIBLE_LINES ? selected - VISIBLE_LINES + 1U : 0U;
    size_t end = first + VISIBLE_LINES;
    size_t i;
    char line[WEB_ENGINE_TITLE_CAP + 24U];
    if (end > g_bookmark_count) end = g_bookmark_count;
    if (g_bookmark_count == 0U) {
        xsdk_text_draw(64, 218, 1U, COLOR_MUTED, "No favorites yet. Open a page and press LEFT THUMB.");
        return;
    }
    for (i = first; i < end; ++i) {
        (void)snprintf(line, sizeof(line), "%c %02lu. %.148s", i == selected ? '>' : ' ', (unsigned long)(i + 1U), g_bookmarks[i].title);
        xsdk_text_draw(58, 202 + (int32_t)((i - first) * 20U), 1U, i == selected ? COLOR_GOLD : COLOR_WHITE, line);
    }
    xsdk_text_draw(64, 610, 1U, COLOR_MUTED, "A: OPEN   Y: REMOVE   UP/DOWN: SELECT   RIGHT THUMB: RETURN");
}

static void go_back(void)
{
    char previous[WEB_ENGINE_URL_CAP];
    bool have_previous = false;
    pthread_mutex_lock(&g_state_lock);
    if (g_history_count > 0U) {
        forward_push(g_current_url);
        --g_history_count;
        copy_text(previous, sizeof(previous), g_history[g_history_count]);
        have_previous = true;
    } else {
        copy_text(g_status, sizeof(g_status), "No previous page in this session.");
    }
    pthread_mutex_unlock(&g_state_lock);
    if (have_previous) start_navigation(previous, false);
}

static void go_forward(void)
{
    char next[WEB_ENGINE_URL_CAP];
    bool have_next = false;
    pthread_mutex_lock(&g_state_lock);
    if (g_forward_count > 0U) {
        history_push(g_current_url);
        --g_forward_count;
        copy_text(next, sizeof(next), g_forward[g_forward_count]);
        have_next = true;
    } else {
        copy_text(g_status, sizeof(g_status), "No forward page in this session.");
    }
    pthread_mutex_unlock(&g_state_lock);
    if (have_next) start_navigation(next, false);
}

static void cycle_view(void)
{
    pthread_mutex_lock(&g_state_lock);
    g_show_bookmarks = false;
    if (g_page_loaded) {
        if (g_show_visual) {
            g_show_visual = false;
            g_show_links = true;
            g_show_resources = false;
        } else if (g_show_links) {
            g_show_visual = false;
            g_show_links = false;
            g_show_resources = true;
        } else {
            /* Return to the visual document surface; never fall back to a text dump. */
            g_show_visual = !g_page.is_direct_resource;
            g_show_links = false;
            g_show_resources = false;
        }
        g_scroll_line = 0U;
        g_selected_link = 0U;
        g_selected_resource = 0U;
    }
    pthread_mutex_unlock(&g_state_lock);
}

static void run_loop(uint32_t width, uint32_t height)
{
    uint16_t previous_buttons = 0U;
    for (;;) {
        INPUT_STATE input = { 0 };
        bool xam_open;
        uint16_t buttons;
        poll_fetch_thread();
        poll_update_check();
        poll_address_keyboard();
        xam_open = xsdk_system_ui_open();
        (void)XamInputGetState(0U, 0U, &input);
        buttons = input.gamepad.buttons;

        if (!xam_open && (buttons & INPUT_GAMEPAD_BACK) != 0U &&
            (previous_buttons & INPUT_GAMEPAD_BACK) == 0U)
            break;

        if (!xam_open && !g_keyboard_active) {
            if ((buttons & INPUT_GAMEPAD_DPAD_UP) != 0U &&
                (previous_buttons & INPUT_GAMEPAD_DPAD_UP) == 0U) {
                if (g_pointer_mode && g_show_visual) { if (g_cursor_y > 116) g_cursor_y -= 18; }
                else change_scroll(-1);
            }
            if ((buttons & INPUT_GAMEPAD_DPAD_DOWN) != 0U &&
                (previous_buttons & INPUT_GAMEPAD_DPAD_DOWN) == 0U) {
                if (g_pointer_mode && g_show_visual) { if (g_cursor_y < 648) g_cursor_y += 18; }
                else change_scroll(1);
            }
            if ((buttons & INPUT_GAMEPAD_LEFT_SHOULDER) != 0U &&
                (previous_buttons & INPUT_GAMEPAD_LEFT_SHOULDER) == 0U) {
                pthread_mutex_lock(&g_state_lock);
                if (!g_show_links && !g_show_resources)
                    g_scroll_line = g_scroll_line > VISIBLE_LINES ? g_scroll_line - VISIBLE_LINES : 0U;
                pthread_mutex_unlock(&g_state_lock);
            }
            if ((buttons & INPUT_GAMEPAD_RIGHT_SHOULDER) != 0U &&
                (previous_buttons & INPUT_GAMEPAD_RIGHT_SHOULDER) == 0U) {
                pthread_mutex_lock(&g_state_lock);
                if (g_page_loaded && !g_show_links && !g_show_resources) {
                    size_t lines = g_show_visual ? ((g_visual_content_height + 19U) / 20U) : 1U;
                    if (g_scroll_line + VISIBLE_LINES < lines) {
                        g_scroll_line += VISIBLE_LINES;
                        if (g_scroll_line + VISIBLE_LINES > lines)
                            g_scroll_line = lines > VISIBLE_LINES ? lines - VISIBLE_LINES : 0U;
                    }
                }
                pthread_mutex_unlock(&g_state_lock);
            }
            if ((buttons & INPUT_GAMEPAD_A) != 0U && (previous_buttons & INPUT_GAMEPAD_A) == 0U) {
                bool show_links;
                bool show_resources;
                bool show_bookmarks;
                bool show_visual;
                size_t focused_link = SIZE_MAX;
                pthread_mutex_lock(&g_state_lock);
                show_links = g_show_links; show_resources = g_show_resources; show_bookmarks = g_show_bookmarks;
                show_visual = g_show_visual;
                pthread_mutex_unlock(&g_state_lock);
                if (show_visual && g_pointer_mode && g_visual_renderer_ready) {
                    size_t clicked_link = SIZE_MAX;
                    if (g_cursor_y >= 40 && g_cursor_y <= 70 && g_cursor_x >= 8 && g_cursor_x < 1272) {
                        begin_address_keyboard();
                    } else if (g_cursor_x >= 0 && g_cursor_x < 1280 &&
                               g_cursor_y >= 112 && g_cursor_y < 656 &&
                               web_visual_renderer_hit_test(g_cursor_x, g_cursor_y - 112, &clicked_link)) {
                        activate_link_index(clicked_link);
                    } else if (g_cursor_x >= 0 && g_cursor_x < 1280 &&
                               g_cursor_y >= 112 && g_cursor_y < 656) {
                        uint16_t clicked_control = UINT16_MAX;
                        uint8_t control_kind = 0U;
                        if (web_visual_renderer_hit_test_control(g_cursor_x, g_cursor_y - 112,
                                                                 &clicked_control, &control_kind)) {
                            if (control_kind == 1U || control_kind == 3U) {
                                begin_control_keyboard(clicked_control);
                            } else if (control_kind == 4U) {
                                if (!web_visual_renderer_dispatch_control(&g_page, clicked_control))
                                    (void)snprintf(g_status, sizeof(g_status),
                                        "Select values can be scripted; native option picker is not implemented.");
                            } else if (!web_visual_renderer_dispatch_control(&g_page, clicked_control)) {
                                (void)snprintf(g_status, sizeof(g_status),
                                    "Button has no supported onclick handler.");
                            }
                        }
                    }
                }
                else if (show_links) activate_selected_link();
                else if (show_resources || show_bookmarks) activate_selected_resource();
                else if (show_visual && g_visual_renderer_ready &&
                         web_visual_renderer_get_focused_link(&focused_link, NULL)) {
                    int navigation_consumed = 0;
                    int handler_dispatched = web_visual_renderer_dispatch_link(&g_page, focused_link,
                                                                               &navigation_consumed);
                    if (!handler_dispatched || !navigation_consumed) activate_link_index(focused_link);
                }
                else begin_address_keyboard();
            }
            if ((buttons & INPUT_GAMEPAD_X) != 0U && (previous_buttons & INPUT_GAMEPAD_X) == 0U)
                cycle_view();
            if ((buttons & INPUT_GAMEPAD_Y) != 0U && (previous_buttons & INPUT_GAMEPAD_Y) == 0U) {
                bool showing_bookmarks;
                char current[WEB_ENGINE_URL_CAP];
                pthread_mutex_lock(&g_state_lock); showing_bookmarks = g_show_bookmarks; copy_text(current, sizeof(current), g_current_url); pthread_mutex_unlock(&g_state_lock);
                if (showing_bookmarks) remove_selected_bookmark();
                else start_navigation(current, false);
            }
            if ((buttons & INPUT_GAMEPAD_B) != 0U && (previous_buttons & INPUT_GAMEPAD_B) == 0U)
                go_back();
            if ((buttons & INPUT_GAMEPAD_DPAD_LEFT) != 0U && (previous_buttons & INPUT_GAMEPAD_DPAD_LEFT) == 0U) {
                bool visual_mode;
                if (g_pointer_mode && g_show_visual) { if (g_cursor_x > 8) g_cursor_x -= 24; previous_buttons = buttons; continue; }
                pthread_mutex_lock(&g_state_lock); visual_mode = g_show_visual && g_page_loaded; pthread_mutex_unlock(&g_state_lock);
                if (visual_mode && g_visual_renderer_ready) {
                    size_t link_index, content_y;
                    if (web_visual_renderer_move_link_focus(-1, &link_index, &content_y)) {
                        size_t wanted_scroll = content_y > 300U ? (content_y - 300U) / 20U : 0U;
                        pthread_mutex_lock(&g_state_lock); g_scroll_line = wanted_scroll; pthread_mutex_unlock(&g_state_lock);
                    }
                } else go_back();
            }
            if ((buttons & INPUT_GAMEPAD_DPAD_RIGHT) != 0U && (previous_buttons & INPUT_GAMEPAD_DPAD_RIGHT) == 0U) {
                bool visual_mode;
                if (g_pointer_mode && g_show_visual) { if (g_cursor_x < 1264) g_cursor_x += 24; previous_buttons = buttons; continue; }
                pthread_mutex_lock(&g_state_lock); visual_mode = g_show_visual && g_page_loaded; pthread_mutex_unlock(&g_state_lock);
                if (visual_mode && g_visual_renderer_ready) {
                    size_t link_index, content_y;
                    if (web_visual_renderer_move_link_focus(1, &link_index, &content_y)) {
                        size_t wanted_scroll = content_y > 300U ? (content_y - 300U) / 20U : 0U;
                        pthread_mutex_lock(&g_state_lock); g_scroll_line = wanted_scroll; pthread_mutex_unlock(&g_state_lock);
                    }
                } else go_forward();
            }
            if ((buttons & INPUT_GAMEPAD_LEFT_THUMB) != 0U && (previous_buttons & INPUT_GAMEPAD_LEFT_THUMB) == 0U)
                add_current_bookmark();
            if ((buttons & INPUT_GAMEPAD_RIGHT_THUMB) != 0U && (previous_buttons & INPUT_GAMEPAD_RIGHT_THUMB) == 0U) {
                bool visual_now;
                pthread_mutex_lock(&g_state_lock); visual_now = g_show_visual && g_page_loaded; pthread_mutex_unlock(&g_state_lock);
                if (visual_now) g_pointer_mode = !g_pointer_mode;
                else toggle_bookmarks();
            }
            if ((buttons & INPUT_GAMEPAD_START) != 0U && (previous_buttons & INPUT_GAMEPAD_START) == 0U)
                start_navigation(DEFAULT_URL, true);
        }

        previous_buttons = buttons;
        draw_screen(width, height);
    }
}

int main(void)
{
    NTSTATUS status;
    uint32_t width = 0U;
    uint32_t height = 0U;

    load_video_config();
    load_bookmarks();
    xsdk_log_write("X360Browser " X360BROWSER_VERSION_STRING " - XenonWeb Browser: own XenonWeb engine, cursor and verified update client starting.");
    g_engine_ready = web_engine_init() != 0;
    if (!g_engine_ready) {
        copy_text(g_status, sizeof(g_status), "libcurl initialization failed.");
        xsdk_log_write("X360Browser: curl_global_init failed.");
    } else {
        pthread_mutex_lock(&g_state_lock);
        copy_text(g_status, sizeof(g_status), "Engine dispatcher ready. Fetching example.com...");
        pthread_mutex_unlock(&g_state_lock);
    }

    (void)xsdk_splash_show(SPLASH_MS);
    status = xsdk_gpu_open();
    if (!NT_SUCCESS(status)) {
        xsdk_log_write("X360Browser: xsdk_gpu_open failed: 0x%08X", (unsigned)status);
        if (g_engine_ready) web_engine_shutdown();
        return 1;
    }
    status = xsdk_present_open(XSDK_DISPLAY_720P, BUFFERS, SWAP_INTERVAL, &width, &height);
    if (!NT_SUCCESS(status)) {
        xsdk_log_write("X360Browser: xsdk_present_open failed: 0x%08X", (unsigned)status);
        (void)xsdk_gpu_close();
        if (g_engine_ready) web_engine_shutdown();
        return 1;
    }
    status = xsdk_text_open();
    if (!NT_SUCCESS(status)) {
        xsdk_log_write("X360Browser: xsdk_text_open failed: 0x%08X", (unsigned)status);
        xsdk_present_close();
        (void)xsdk_gpu_close();
        if (g_engine_ready) web_engine_shutdown();
        return 1;
    }

    g_visual_renderer_ready = web_visual_renderer_init() != 0;
    if (g_engine_ready) start_update_check();
    if (!g_visual_renderer_ready)
        xsdk_log_write("X360Browser: visual renderer unavailable; text-reader fallback disabled, graphical error surface active.");
    xsdk_log_write("X360Browser: display is %ux%u", (unsigned)width, (unsigned)height);
    if (g_engine_ready) {
        /* The first navigation starts after the drawing loop is ready. */
        start_navigation(DEFAULT_URL, false);
    }
    run_loop(width, height);
    poll_fetch_thread();
    if (g_fetch_thread_valid) {
        (void)pthread_join(g_fetch_thread, NULL);
        g_fetch_thread_valid = false;
    }
    if (g_engine_ready) web_engine_shutdown();
    web_visual_renderer_shutdown();
    xsdk_text_close();
    xsdk_present_close();
    status = xsdk_gpu_close();
    if (!NT_SUCCESS(status))
        xsdk_log_write("X360Browser: xsdk_gpu_close failed: 0x%08X", (unsigned)status);
    xsdk_log_write("X360Browser: web engine exited.");
    return 0;
}
