# X360Browser 7.0.0 — XenonWeb layout and form rendering update

X360Browser is an experimental homebrew browser for Xbox 360 using its own bounded HTML/DOM/CSS/JavaScript subset and the console's xSDK graphics path. It is not Chromium/WebKit and does not claim full compatibility with modern web standards.

## What's new in 7.0.0

- Long unbroken text is split into viewport-width visual runs instead of being allowed to spill beyond the page.
- CSS colour parsing supports `#RGB`, `#RGBA`, `#RRGGBB`, and `#RRGGBBAA`, with invalid hex digits rejected rather than silently misread.
- Additional common colour keywords are supported.
- `button` and `textarea` initial text is painted inside their native graphical control; `select` displays the selected option label or the first option. Controls are no longer followed by a second text rendering of their children.
- Regression cases cover these rendering behaviours.
- The final Xbox executable remains named `default.xex`; the workflow contract verifies that name across the build and release pipeline.

## Build and test on a host

```sh
cmake -S . -B build -G Ninja -DCMAKE_BUILD_TYPE=Release
cmake --build build
ctest --test-dir build --output-on-failure
python3 tests/validate_project_integrity.py
python3 tests/test_default_xex_contract.py
python3 tests/run_host_tests.py
```

The host tests do not replace the Xbox 360 cross-build. The actual PowerPC XEX and runtime rendering still need to be confirmed by GitHub Actions and the physical console.

## GitHub Actions

Place the workflow at `.github/workflows/build-xex-from-zip.yml`. It validates the source, runs host tests, cross-compiles for Xbox 360, and only then publishes a release when permissions and the workflow configuration allow it. The canonical downloadable executable is `default.xex`.

## Limitations

XenonWeb, XenonScript, and XenonMedia remain bounded first-party implementations with partial standards support. Complex responsive layouts, modern JavaScript frameworks, WebGL games, cross-origin embedded players, DRM, and a number of modern video codecs may not work.
