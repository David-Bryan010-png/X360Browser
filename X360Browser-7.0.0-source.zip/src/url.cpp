#include "x360browser/url.hpp"

#include <cctype>
#include <limits>
#include <string_view>

namespace x360browser {
namespace {

std::string trim(const std::string& value) {
    std::size_t first = 0;
    while (first < value.size() && std::isspace(static_cast<unsigned char>(value[first]))) ++first;
    std::size_t last = value.size();
    while (last > first && std::isspace(static_cast<unsigned char>(value[last - 1]))) --last;
    return value.substr(first, last - first);
}

std::string lower_ascii(std::string value) {
    for (char& ch : value) ch = static_cast<char>(std::tolower(static_cast<unsigned char>(ch)));
    return value;
}

bool starts_with_case_insensitive(const std::string& value, const std::string& prefix) {
    if (value.size() < prefix.size()) return false;
    return lower_ascii(value.substr(0, prefix.size())) == prefix;
}

bool has_whitespace_or_control(const std::string& value) {
    for (unsigned char ch : value) {
        if (std::isspace(ch) || ch < 0x20 || ch == 0x7F) return true;
    }
    return false;
}

bool has_valid_percent_escapes(const std::string& value) {
    const auto hex = [](unsigned char ch) {
        return (ch >= '0' && ch <= '9') || (ch >= 'a' && ch <= 'f') ||
               (ch >= 'A' && ch <= 'F');
    };
    for (std::size_t i = 0; i < value.size(); ++i) {
        if (value[i] != '%') continue;
        if (i + 2 >= value.size() || !hex(static_cast<unsigned char>(value[i + 1])) ||
            !hex(static_cast<unsigned char>(value[i + 2]))) return false;
        i += 2;
    }
    return true;
}

bool valid_port(const std::string& port) {
    if (port.empty()) return false;
    unsigned int value = 0;
    for (unsigned char ch : port) {
        if (!std::isdigit(ch)) return false;
        const unsigned int digit = static_cast<unsigned int>(ch - '0');
        // Check before multiplying so a huge attacker-controlled port cannot wrap.
        if (value > (65535U - digit) / 10U) return false;
        value = value * 10U + digit;
    }
    return value > 0U;
}

bool valid_domain_or_ipv4(const std::string& host) {
    if (host.empty() || host.size() > 253 || host.front() == '.' || host.back() == '.') return false;
    bool has_alpha = false;
    bool only_digits_and_dots = true;
    std::size_t label_start = 0;
    for (std::size_t i = 0; i <= host.size(); ++i) {
        if (i == host.size() || host[i] == '.') {
            const std::size_t length = i - label_start;
            if (length == 0 || length > 63) return false;
            if (host[label_start] == '-' || host[i - 1] == '-') return false;
            label_start = i + 1;
            continue;
        }
        const unsigned char ch = static_cast<unsigned char>(host[i]);
        if (std::isalpha(ch)) has_alpha = true;
        if (!(std::isdigit(ch) || ch == '.')) only_digits_and_dots = false;
        if (!(std::isalnum(ch) || ch == '-')) return false;
    }
    // A dotted numeric literal must look like IPv4, not an arbitrary number of octets.
    if (only_digits_and_dots) {
        unsigned int octets = 0;
        std::size_t start = 0;
        while (start < host.size()) {
            const std::size_t end = host.find('.', start);
            const std::string part = host.substr(start, end == std::string::npos ? std::string::npos : end - start);
            if (part.empty() || part.size() > 3) return false;
            unsigned int value = 0;
            for (unsigned char ch : part) value = value * 10U + static_cast<unsigned int>(ch - '0');
            if (value > 255U) return false;
            ++octets;
            if (end == std::string::npos) break;
            start = end + 1;
        }
        return octets == 4;
    }
    return has_alpha || host == "localhost";
}

bool valid_ipv6_literal(const std::string& host) {
    if (host.empty() || host.find(":::") != std::string::npos) return false;
    const std::size_t compression = host.find("::");
    const bool compressed = compression != std::string::npos;
    if (compressed && host.find("::", compression + 2) != std::string::npos) return false;
    if (!compressed && (host.front() == ':' || host.back() == ':')) return false;

    std::size_t groups = 0;
    std::size_t start = 0;
    while (start < host.size()) {
        const std::size_t end = host.find(':', start);
        const std::size_t finish = end == std::string::npos ? host.size() : end;
        if (finish > start) {
            const std::size_t length = finish - start;
            if (length > 4) return false;
            for (std::size_t i = start; i < finish; ++i) {
                if (!std::isxdigit(static_cast<unsigned char>(host[i]))) return false;
            }
            ++groups;
        }
        if (end == std::string::npos) break;
        start = end + 1;
    }
    return compressed ? groups < 8 : groups == 8;
}

bool valid_host_port(const std::string& authority) {
    if (authority.empty() || authority.find('@') != std::string::npos) return false; // No embedded credentials.

    std::string host;
    std::string port;
    if (authority.front() == '[') {
        const std::size_t close = authority.find(']');
        if (close == std::string::npos || close == 1) return false;
        host = authority.substr(1, close - 1);
        // IPv4-mapped IPv6 is intentionally not accepted in this first parser.
        if (!valid_ipv6_literal(host)) return false;
        if (close + 1 < authority.size()) {
            if (authority[close + 1] != ':') return false;
            port = authority.substr(close + 2);
            if (!valid_port(port)) return false;
        }
        return true;
    }

    const std::size_t colon = authority.rfind(':');
    if (colon != std::string::npos) {
        if (authority.find(':') != colon) return false; // IPv6 literals must be bracketed.
        host = authority.substr(0, colon);
        port = authority.substr(colon + 1);
        if (!valid_port(port)) return false;
    } else {
        host = authority;
    }
    return valid_domain_or_ipv4(lower_ascii(host));
}

std::string normalize_scheme_and_host(const std::string& url) {
    const std::size_t scheme_end = url.find("://");
    const std::size_t authority_start = scheme_end + 3;
    const std::size_t authority_end = url.find_first_of("/?#", authority_start);
    const std::size_t end = authority_end == std::string::npos ? url.size() : authority_end;
    std::string result = lower_ascii(url.substr(0, scheme_end)) + "://";
    std::string authority = url.substr(authority_start, end - authority_start);
    if (!authority.empty() && authority.front() == '[') {
        const std::size_t close = authority.find(']');
        if (close != std::string::npos) {
            result += "[" + lower_ascii(authority.substr(1, close - 1)) + "]" + authority.substr(close + 1);
        } else {
            result += authority;
        }
    } else {
        const std::size_t colon = authority.rfind(':');
        if (colon == std::string::npos) result += lower_ascii(authority);
        else result += lower_ascii(authority.substr(0, colon)) + authority.substr(colon);
    }
    result += url.substr(end);
    return result;
}

bool looks_like_host(const std::string& value) {
    if (value == "localhost") return true;
    if (!value.empty() && value.front() == '[' && value.back() == ']') return true;
    if (value.find('.') != std::string::npos) return true;
    return false;
}

bool looks_like_host_or_host_port(const std::string& input) {
    if (looks_like_host(input)) return true;
    const std::size_t colon = input.rfind(':');
    if (colon == std::string::npos || colon == 0 || colon + 1 >= input.size()) return false;
    return looks_like_host(input.substr(0, colon)) && valid_port(input.substr(colon + 1));
}

bool valid_search_prefix(const std::string& prefix) {
    return is_http_url(prefix + "x");
}

} // namespace

std::string percent_encode_query(const std::string& value) {
    static constexpr char hex[] = "0123456789ABCDEF";
    std::string out;
    out.reserve(value.size() * 3U);
    for (unsigned char ch : value) {
        const bool unreserved = (ch >= 'A' && ch <= 'Z') || (ch >= 'a' && ch <= 'z') ||
            (ch >= '0' && ch <= '9') || ch == '-' || ch == '_' || ch == '.' || ch == '~';
        if (unreserved) out.push_back(static_cast<char>(ch));
        else {
            out.push_back('%');
            out.push_back(hex[ch >> 4]);
            out.push_back(hex[ch & 0x0F]);
        }
    }
    return out;
}

bool is_http_url(const std::string& raw_url) {
    if (raw_url.empty() || has_whitespace_or_control(raw_url) ||
        !has_valid_percent_escapes(raw_url)) return false;
    const std::size_t scheme_end = raw_url.find("://");
    if (scheme_end == std::string::npos) return false;
    const std::string scheme = lower_ascii(raw_url.substr(0, scheme_end));
    if (scheme != "http" && scheme != "https") return false;
    const std::size_t authority_start = scheme_end + 3;
    const std::size_t authority_end = raw_url.find_first_of("/?#", authority_start);
    const std::string authority = raw_url.substr(authority_start,
        authority_end == std::string::npos ? std::string::npos : authority_end - authority_start);
    return valid_host_port(authority);
}

NormalizedInput normalize_input(const std::string& raw_input, const std::string& search_prefix) {
    const std::string input = trim(raw_input);
    if (input.empty()) return {{}, false, "Digite um endereço ou uma pesquisa."};
    if (!valid_search_prefix(search_prefix)) return {{}, false, "Configuração do mecanismo de pesquisa inválida."};

    if (starts_with_case_insensitive(input, "https://") || starts_with_case_insensitive(input, "http://")) {
        if (!is_http_url(input)) return {{}, false, "Endereço HTTP/HTTPS inválido."};
        return {normalize_scheme_and_host(input), false, {}};
    }

    // A bare host/path can be opened directly; text with spaces becomes a search.
    // Check only the authority first, so localhost:3000/path is not mistaken for a scheme.
    if (!has_whitespace_or_control(input)) {
        const std::size_t authority_end = input.find_first_of("/?#");
        const std::string authority = input.substr(0, authority_end);
        if (looks_like_host_or_host_port(authority) && valid_host_port(authority)) {
            const std::string url = normalize_scheme_and_host("https://" + input);
            if (!is_http_url(url)) return {{}, false, "Endereço inválido."};
            return {url, false, {}};
        }
    }

    // Explicit URL schemes other than HTTP(S) are rejected, never silently searched.
    const std::size_t colon = input.find(':');
    const std::size_t slash = input.find('/');
    const std::size_t dot = input.find('.');
    if (colon != std::string::npos && (slash == std::string::npos || colon < slash) &&
        (dot == std::string::npos || colon < dot)) {
        bool scheme_like = colon > 0 && std::isalpha(static_cast<unsigned char>(input[0]));
        for (std::size_t i = 1; scheme_like && i < colon; ++i) {
            const unsigned char ch = static_cast<unsigned char>(input[i]);
            scheme_like = std::isalnum(ch) || ch == '+' || ch == '-' || ch == '.';
        }
        if (scheme_like) return {{}, false, "Somente endereços HTTP e HTTPS são aceitos."};
    }

    return {search_prefix + percent_encode_query(input), true, {}};
}

} // namespace x360browser
