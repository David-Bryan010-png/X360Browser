# X360Browser Xbox UI

Controller-focused shell retained from the earlier preview. Page layout now routes through the experimental XenonWeb subset where possible and falls back to VisualLite. For supported behavior and limitations, read `../docs/XENONWEB-ENGINE.md`.
