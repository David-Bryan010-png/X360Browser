# Third-party dependency inventory and first-party policy

The active **page engine (XenonWeb), bounded script interpreter (XenonScript), media parsers, supported raster decoders, WAV PCM/IMA ADPCM decoder, WebVTT parser and AVI raw-frame path are source code in this project**. The active dispatch path does not link Chromium, WebKit, NetSurf, stb_image or a third-party media player as an engine. The old nonfunctional NetSurf stub was removed in 3.5.0.

## External supporting components that remain

- **xSDK / PowerPC toolchain** — platform SDK, compilers and Xbox-specific APIs.
- **curl / libcurl (curl-xenon)** — HTTP/HTTPS transport.
- **Mbed TLS (mbedtls-xenon)** — TLS and certificate validation.
- **Mozilla CA certificate bundle** — trust-store data for HTTPS.
- **glslang-xenon** — shader compiler/build-time tool.

These are external transport/security/platform components, not page-rendering or media-codec engines. The project has **not** implemented a production-grade first-party TLS/cryptographic library; replacing audited cryptography with a home-made unaudited implementation would be unsafe.

## Media player boundary

No external player executable is shipped, and the handoff path is disabled by default. The project does not yet include full compressed-video/audio decoding or a complete in-page media presentation pipeline.
