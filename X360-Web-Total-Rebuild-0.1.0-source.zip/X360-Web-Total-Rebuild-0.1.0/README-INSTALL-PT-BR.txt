X360 WEB TOTAL — RECONSTRUCAO INDEPENDENTE — ALPHA 0.1.0

ANTES DE TUDO
Esta e uma base inicial, nao um navegador completo. A alpha tenta HTTP sem HTTPS/TLS. Sites atuais normalmente exigem HTTPS e JavaScript.

INSTALACAO DO PENDRIVE
1. Use um pendrive FAT32.
2. Extraia o conteudo completo deste ZIP para a RAIZ do pendrive.
3. Confirme que os arquivos abaixo estao na raiz:
      XellLaunch2.xex
      xenon.elf
      X360WebTotal/
4. Ligue o Xbox 360 e entre no dashboard/homebrew.
5. Execute XellLaunch2.xex.
6. O XellLaunch2 deve iniciar XeLL; XeLL deve carregar xenon.elf.

NAO FACA
- Nao renomeie xenon.elf.
- Nao coloque xenon.elf dentro de X360WebTotal; ele fica na raiz.
- Nao grave NAND ou atualize XeLL por este pacote.
- Nao assuma que o boot funciona em todo RGH/JTAG sem validar a versao do XeLL.

CONTROLES DA ALPHA
- D-pad: escolher tecla do teclado virtual.
- A: inserir caractere.
- X: apagar caractere.
- START: navegar para o endereco digitado.
- B: voltar ao inicio/cancelar carregamento.
- BACK: sair.

LIMITACOES
- Somente HTTP simples nesta alpha; HTTPS/TLS ainda nao foi integrado.
- HTML e renderizado como texto estrutural.
- CSS, JavaScript, clique em links, imagens reais, audio, video, abas e historico ainda nao estao implementados.
- Ethernet e o alvo inicial da rede LibXenon; adaptadores Wi-Fi USB nao sao presumidos.
- O build cruzado e a inicializacao ainda precisam ser testados no Xbox fisico.

Verifique SHA256SUMS.txt para conferir os binarios do pacote.
