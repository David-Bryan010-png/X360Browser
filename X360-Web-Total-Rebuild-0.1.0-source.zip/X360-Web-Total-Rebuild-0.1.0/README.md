# X360 Web Total — reconstrução independente

Projeto novo de navegador para Xbox 360 RGH/JTAG. Nenhum código das versões anteriores do X360Browser é usado como base deste marco. A primeira entrega estabelece o boot via XeLL Reloaded, a aplicação LibXenon, a interface de controle, a camada HTTP inicial e testes de host.

## Arquitetura de inicialização

```text
Aurora / Freestyle / XeXMenu
        │ executar XellLaunch2.xex
        ▼
XellLaunch2 2.2.0 (utilitário externo, SHA-256 fixado)
        │ inicia XeLL compatível
        ▼
XeLL Reloaded
        │ carrega xenon.elf pela USB FAT
        ▼
X360 Web Total (LibXenon)
```

`XellLaunch2.xex` é o XEX que o usuário executa. Não criamos outro XEX só para chamar o XellLaunch2: isso adicionaria uma etapa sem necessidade. O workflow baixa o binário oficial XellLaunch2 2.2.0 e confere o hash antes de montar o pendrive.

O fluxo não desliga fisicamente o console e não descarrega o kernel do Xbox. Ele usa a transição do XellLaunch2 para XeLL; o XeLL, por sua vez, inicia a aplicação LibXenon `xenon.elf`.

## Build e testes

No GitHub Actions, execute `.github/workflows/build-x360-web-total.yml`. O workflow executa testes de host, compila o ELF com a imagem `free60/libxenon:latest`, valida o cabeçalho ELF32 PowerPC big-endian e monta `X360-Web-Total-USB.zip`.

Testes portáveis locais:

```bash
cmake -S browser -B build-host
cmake --build build-host
ctest --test-dir build-host --output-on-failure
```

Build LibXenon manual:

```bash
make -C browser clean all DEVKITXENON=/usr/local/xenon
```

## O que esta alpha realmente contém

- parser de URL para HTTP/HTTPS (o parser reconhece ambos; transporte HTTPS ainda não existe);
- cliente HTTP/1.0 experimental usando DNS e TCP bruto do lwIP/LibXenon, sem depender de sockets BSD;
- leitura limitada de cabeçalhos HTTP, `Content-Length` e `Transfer-Encoding: chunked`;
- parser HTML estrutural próprio e limitado: títulos, parágrafos, listas, links, `pre`, imagens como texto alternativo e separadores;
- layout textual com quebra de linha;
- interface textual LibXenon com barra de endereço e teclado virtual pelo controle;
- inicialização de vídeo, USB/FAT, armazenamento, controle e rede;
- testes de host para URL, HTML, layout e decodificação de resposta HTTP.

## O que ainda NÃO existe

Esta alpha **não é ainda um navegador moderno completo**. Ela só tenta HTTP sem TLS. Não há HTTPS, validação de certificados, CSS, JavaScript, DOM interativo, clique em links, histórico, abas, cookies, cache HTTP funcional, decodificação real de imagens, áudio ou vídeo. Também não há compatibilidade ampla com páginas atuais, que normalmente exigem HTTPS e JavaScript.

O trabalho deve avançar em marcos testáveis: TLS/certificados; redirecionamentos e links relativos; DOM e CSS; desenho 2D acelerado; imagens; JavaScript limitado; áudio/vídeo compatíveis. Não será declarado suporte a um recurso antes de existir implementação e teste.

## Requisitos e limites

- Xbox 360 com RGH/JTAG e XeLL funcional.
- Pendrive FAT32; `XellLaunch2.xex` e `xenon.elf` ficam na raiz.
- Ethernet suportada pela pilha LibXenon é o alvo inicial; não presumir compatibilidade de adaptadores Wi-Fi USB.
- XellLaunch2 2.2.0 precisa ser compatível com o XeLL/NAND instalado. A nota de versão do projeto impõe condição específica para determinadas builds `xell-gggggg`.
- O ELF e o fluxo de inicialização ainda precisam ser testados no console físico; testes de host não provam funcionamento no hardware.

Leia `docs/BOOT-FLOW.md` e `docs/ENGINE-STATUS.md` antes de instalar.
