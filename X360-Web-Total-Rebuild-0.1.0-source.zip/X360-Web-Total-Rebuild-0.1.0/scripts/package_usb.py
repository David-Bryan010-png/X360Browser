#!/usr/bin/env python3
"""Assemble a verified X360 Web Total FAT32 USB package."""
from __future__ import annotations

import argparse
import hashlib
import shutil
import struct
import tempfile
import zipfile
from pathlib import Path

VERSION = "0.1.0-alpha.1"
XELLLAUNCH2_SHA256 = "49dd8666b83a7c7b37597affc46513fe2cb9ab5cb2fe1fb71da1b13175276bb0"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def validate_elf(path: Path) -> None:
    data = path.read_bytes()[:20]
    if len(data) < 20 or data[:4] != b"\x7fELF":
        raise ValueError("browser ELF has an invalid or missing ELF header")
    if data[4] != 1 or data[5] != 2:
        raise ValueError("expected a 32-bit, big-endian ELF")
    machine = struct.unpack(">H", data[18:20])[0]
    if machine != 20:
        raise ValueError(f"expected PowerPC ELF (EM_PPC=20), got machine={machine}")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--elf", type=Path, required=True, help="compiled LibXenon xenon.elf")
    parser.add_argument("--xell", type=Path, required=True, help="official XellLaunch2 2.2.0 XEX")
    parser.add_argument("--project", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--output", type=Path, default=Path("X360-Web-Total-USB.zip"))
    args = parser.parse_args()

    for required in (args.elf, args.xell):
        if not required.is_file():
            raise FileNotFoundError(required)
    validate_elf(args.elf)
    actual_xell_hash = sha256(args.xell)
    if actual_xell_hash != XELLLAUNCH2_SHA256:
        raise ValueError(f"XellLaunch2 hash mismatch: {actual_xell_hash}")

    project = args.project.resolve()
    output = args.output.resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="x360-web-total-") as temp_dir:
        stage = Path(temp_dir) / "usb-root"
        data_dir = stage / "X360WebTotal"
        runtime_dirs = (data_dir / "config", data_dir / "data", data_dir / "cache", data_dir / "logs")
        for folder in runtime_dirs:
            folder.mkdir(parents=True, exist_ok=True)
            if folder.name != "config":
                (folder / ".keep").write_text("reserved\n", encoding="ascii")
        shutil.copy2(args.elf, stage / "xenon.elf")
        shutil.copy2(args.xell, stage / "XellLaunch2.xex")
        shutil.copy2(project / "usb/X360WebTotal/config/browser.ini", data_dir / "config/browser.ini")
        shutil.copy2(project / "README-INSTALL-PT-BR.txt", stage / "LEIA-ME.txt")
        shutil.copy2(project / "docs/BOOT-FLOW.md", stage / "FLUXO-DE-INICIALIZACAO.txt")
        (stage / "VERSION.txt").write_text(VERSION + "\n", encoding="utf-8")
        sums = (
            f"{sha256(stage / 'XellLaunch2.xex')}  XellLaunch2.xex\n"
            f"{sha256(stage / 'xenon.elf')}  xenon.elf\n"
        )
        (stage / "SHA256SUMS.txt").write_text(sums, encoding="ascii")
        with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
            for path in sorted(stage.rglob("*")):
                if path.is_file():
                    archive.write(path, path.relative_to(stage).as_posix())
    print(f"Created {output} ({output.stat().st_size} bytes)")
    print(f"XellLaunch2 SHA-256 verified: {actual_xell_hash}")
    print(f"ELF SHA-256: {sha256(args.elf)}")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (FileNotFoundError, ValueError, OSError) as exc:
        raise SystemExit(f"package error: {exc}")
