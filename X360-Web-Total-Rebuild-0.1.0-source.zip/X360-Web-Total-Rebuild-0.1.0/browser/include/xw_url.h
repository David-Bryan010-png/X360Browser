#ifndef XW_URL_H
#define XW_URL_H

#include <stddef.h>
#include <stdint.h>

#define XW_URL_HOST_MAX 256
#define XW_URL_PATH_MAX 768
#define XW_URL_INPUT_MAX 1024

typedef struct {
    char scheme[6];
    char host[XW_URL_HOST_MAX];
    char path[XW_URL_PATH_MAX];
    uint16_t port;
    uint8_t tls;
} XwUrl;

int xw_url_parse(const char *input, XwUrl *out, char *error, size_t error_size);

#endif
