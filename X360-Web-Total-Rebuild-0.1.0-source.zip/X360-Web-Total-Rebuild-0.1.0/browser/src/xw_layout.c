#include "xw_layout.h"

#include <stdio.h>
#include <string.h>

static void push_line(XwLayout *layout, const char *text, unsigned indent, unsigned block, int link)
{
    XwVisualLine *line;
    if (layout->line_count >= sizeof(layout->lines) / sizeof(layout->lines[0])) {
        ++layout->dropped_lines;
        return;
    }
    line = &layout->lines[layout->line_count++];
    memset(line, 0, sizeof(*line));
    (void)snprintf(line->text, sizeof(line->text), "%s", text);
    line->indent = indent;
    line->source_block = block;
    line->is_link = link;
}

static unsigned spaces_before(XwBlockType type, unsigned level)
{
    if (type == XW_BLOCK_HEADING) return level > 1 ? 1 : 0;
    if (type == XW_BLOCK_LIST_ITEM) return 2;
    if (type == XW_BLOCK_LINK) return 1;
    return 0;
}

int xw_layout_build(const XwHtmlDocument *doc, unsigned columns, XwLayout *layout)
{
    if (doc == NULL || layout == NULL || columns < 12) return -1;
    memset(layout, 0, sizeof(*layout));
    for (size_t i = 0; i < doc->block_count; ++i) {
        const XwHtmlBlock *block = &doc->blocks[i];
        const char *src = block->text;
        unsigned indent = spaces_before(block->type, block->level);
        unsigned limit = columns > indent ? columns - indent : columns;
        char line[128];
        size_t used = 0, pos = 0, n = strlen(src);
        if (block->type == XW_BLOCK_RULE) {
            push_line(layout, "----------------------------------------------------------------------------", 0, (unsigned)i, 0);
            push_line(layout, "", 0, (unsigned)i, 0);
            continue;
        }
        if (block->type == XW_BLOCK_HEADING || block->type == XW_BLOCK_PARAGRAPH || block->type == XW_BLOCK_LIST_ITEM || block->type == XW_BLOCK_IMAGE || block->type == XW_BLOCK_PREFORMATTED) {
            push_line(layout, "", 0, (unsigned)i, 0);
        }
        if (block->type == XW_BLOCK_LIST_ITEM) {
            memcpy(line, "* ", 2); used = 2;
        } else if (block->type == XW_BLOCK_LINK) {
            memcpy(line, "[LINK] ", 7); used = 7;
            limit = columns > 7 ? columns - 7 : columns;
        } else if (block->type == XW_BLOCK_IMAGE) {
            memcpy(line, "[IMG] ", 6); used = 6;
            limit = columns > 6 ? columns - 6 : columns;
        } else if (block->type == XW_BLOCK_HEADING) {
            memcpy(line, "# ", 2); used = 2;
        }
        while (pos < n) {
            size_t word_start, word_len;
            while (pos < n && src[pos] == ' ') ++pos;
            word_start = pos;
            while (pos < n && src[pos] != ' ') ++pos;
            word_len = pos - word_start;
            if (!word_len) continue;
            if (used && used + 1 + word_len > limit) {
                line[used] = '\0';
                push_line(layout, line, indent, (unsigned)i, block->type == XW_BLOCK_LINK);
                used = 0;
            }
            if (used && used + 1 < sizeof(line)) line[used++] = ' ';
            for (size_t k = 0; k < word_len && used + 1 < sizeof(line); ++k) line[used++] = src[word_start + k];
        }
        if (used || n == 0) {
            line[used] = '\0';
            push_line(layout, line, indent, (unsigned)i, block->type == XW_BLOCK_LINK);
        }
        if (block->type == XW_BLOCK_LINK && block->href[0]) {
            char hrefline[128];
            (void)snprintf(hrefline, sizeof(hrefline), "  -> %.118s", block->href);
            push_line(layout, hrefline, indent, (unsigned)i, 1);
        }
        if (block->type == XW_BLOCK_IMAGE && block->href[0]) {
            char imageline[128];
            (void)snprintf(imageline, sizeof(imageline), "  src: %.117s", block->href);
            push_line(layout, imageline, indent, (unsigned)i, 0);
        }
    }
    return 0;
}
