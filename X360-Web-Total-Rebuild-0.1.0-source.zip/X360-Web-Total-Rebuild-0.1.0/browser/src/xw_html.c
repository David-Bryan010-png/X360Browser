#include "xw_html.h"

#include <ctype.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

typedef struct {
    char name[12];
    XwHtmlBlock *block;
    int preserve_whitespace;
} HtmlFrame;

static int equal_ci(const char *a, size_t n, const char *b)
{
    size_t i;
    if (strlen(b) != n) return 0;
    for (i = 0; i < n; ++i)
        if (tolower((unsigned char)a[i]) != tolower((unsigned char)b[i])) return 0;
    return 1;
}

static void append_utf8(char *out, size_t cap, size_t *used, uint32_t cp)
{
    unsigned char bytes[4];
    size_t n;
    if (cp <= 0x7f) { bytes[0] = (unsigned char)cp; n = 1; }
    else if (cp <= 0x7ff) {
        bytes[0] = (unsigned char)(0xc0 | (cp >> 6));
        bytes[1] = (unsigned char)(0x80 | (cp & 0x3f)); n = 2;
    } else if (cp <= 0xffff && !(cp >= 0xd800 && cp <= 0xdfff)) {
        bytes[0] = (unsigned char)(0xe0 | (cp >> 12));
        bytes[1] = (unsigned char)(0x80 | ((cp >> 6) & 0x3f));
        bytes[2] = (unsigned char)(0x80 | (cp & 0x3f)); n = 3;
    } else if (cp <= 0x10ffff) {
        bytes[0] = (unsigned char)(0xf0 | (cp >> 18));
        bytes[1] = (unsigned char)(0x80 | ((cp >> 12) & 0x3f));
        bytes[2] = (unsigned char)(0x80 | ((cp >> 6) & 0x3f));
        bytes[3] = (unsigned char)(0x80 | (cp & 0x3f)); n = 4;
    } else return;
    if (*used + n >= cap) return;
    memcpy(out + *used, bytes, n);
    *used += n;
}

static size_t decode_entities(char *out, size_t cap, const char *src, size_t len)
{
    size_t i = 0, used = 0;
    while (i < len && used + 1 < cap) {
        if (src[i] == '&') {
            const char *semi = memchr(src + i + 1, ';', len - i - 1);
            if (semi != NULL && (size_t)(semi - (src + i)) <= 12) {
                size_t n = (size_t)(semi - (src + i + 1));
                const char *name = src + i + 1;
                uint32_t cp = 0;
                int recognized = 1;
                if (n == 3 && memcmp(name, "amp", 3) == 0) cp = '&';
                else if (n == 2 && memcmp(name, "lt", 2) == 0) cp = '<';
                else if (n == 2 && memcmp(name, "gt", 2) == 0) cp = '>';
                else if (n == 4 && memcmp(name, "quot", 4) == 0) cp = '"';
                else if (n == 4 && memcmp(name, "apos", 4) == 0) cp = '\'';
                else if (n == 4 && memcmp(name, "nbsp", 4) == 0) cp = ' ';
                else if (n >= 2 && name[0] == '#') {
                    size_t k = 1;
                    unsigned base = 10;
                    unsigned long value = 0;
                    if (k < n && (name[k] == 'x' || name[k] == 'X')) { base = 16; ++k; }
                    if (k == n) recognized = 0;
                    for (; recognized && k < n; ++k) {
                        unsigned char c = (unsigned char)name[k];
                        unsigned digit;
                        if (c >= '0' && c <= '9') digit = (unsigned)(c - '0');
                        else if (base == 16 && tolower(c) >= 'a' && tolower(c) <= 'f') digit = (unsigned)(tolower(c) - 'a' + 10);
                        else { recognized = 0; break; }
                        if (value > 0x10ffffUL / base) { recognized = 0; break; }
                        value = value * base + digit;
                        if (value > 0x10ffffUL) { recognized = 0; break; }
                    }
                    cp = (uint32_t)value;
                } else recognized = 0;
                if (recognized) {
                    append_utf8(out, cap, &used, cp);
                    i = (size_t)(semi - src) + 1;
                    continue;
                }
            }
        }
        out[used++] = src[i++];
    }
    out[used] = '\0';
    return used;
}

static void trim(char *s)
{
    size_t n = strlen(s), start = 0;
    while (start < n && isspace((unsigned char)s[start])) ++start;
    while (n > start && isspace((unsigned char)s[n - 1])) --n;
    if (start) memmove(s, s + start, n - start);
    s[n - start] = '\0';
}

static void append_text(char *dst, size_t cap, const char *text, size_t len, int preserve)
{
    size_t used = strlen(dst);
    for (size_t i = 0; i < len && used + 1 < cap; ++i) {
        unsigned char c = (unsigned char)text[i];
        if (!preserve && isspace(c)) {
            if (used && dst[used - 1] != ' ') dst[used++] = ' ';
        } else if (preserve && c == '\r') {
            continue;
        } else dst[used++] = (char)c;
    }
    dst[used] = '\0';
}

static XwHtmlBlock *new_block(XwHtmlDocument *doc, XwBlockType type, unsigned level)
{
    XwHtmlBlock *b;
    if (doc->block_count >= XW_HTML_MAX_BLOCKS) {
        doc->truncated = 1;
        ++doc->dropped_blocks;
        return NULL;
    }
    b = &doc->blocks[doc->block_count++];
    memset(b, 0, sizeof(*b));
    b->type = type;
    b->level = level;
    return b;
}

static void copy_attribute(const char *tag, size_t tag_len, const char *wanted, char *out, size_t cap)
{
    size_t i = 0, wanted_len = strlen(wanted);
    (void)wanted_len;
    if (cap == 0) return;
    out[0] = '\0';
    while (i < tag_len) {
        size_t name_start, name_len, value_start, value_len;
        while (i < tag_len && (isspace((unsigned char)tag[i]) || tag[i] == '/' || tag[i] == '<' || tag[i] == '>')) ++i;
        name_start = i;
        while (i < tag_len && (isalnum((unsigned char)tag[i]) || tag[i] == '-' || tag[i] == '_' || tag[i] == ':')) ++i;
        name_len = i - name_start;
        if (!name_len) { ++i; continue; }
        while (i < tag_len && isspace((unsigned char)tag[i])) ++i;
        if (i >= tag_len || tag[i] != '=') continue;
        ++i;
        while (i < tag_len && isspace((unsigned char)tag[i])) ++i;
        if (i >= tag_len) break;
        if (tag[i] == '\'' || tag[i] == '"') {
            char quote = tag[i++];
            value_start = i;
            while (i < tag_len && tag[i] != quote) ++i;
            value_len = i - value_start;
            if (i < tag_len) ++i;
        } else {
            value_start = i;
            while (i < tag_len && !isspace((unsigned char)tag[i]) && tag[i] != '>') ++i;
            value_len = i - value_start;
        }
        if (equal_ci(tag + name_start, name_len, wanted)) {
            (void)decode_entities(out, cap, tag + value_start, value_len);
            return;
        }
    }
}

static int block_tag(const char *name, size_t len, XwBlockType *type, unsigned *level)
{
    if (len == 2 && tolower((unsigned char)name[0]) == 'h' && name[1] >= '1' && name[1] <= '6') {
        *type = XW_BLOCK_HEADING; *level = (unsigned)(name[1] - '0'); return 1;
    }
    if (equal_ci(name, len, "p") || equal_ci(name, len, "div") || equal_ci(name, len, "section") || equal_ci(name, len, "article") || equal_ci(name, len, "main")) {
        *type = XW_BLOCK_PARAGRAPH; *level = 0; return 1;
    }
    if (equal_ci(name, len, "li")) { *type = XW_BLOCK_LIST_ITEM; *level = 0; return 1; }
    if (equal_ci(name, len, "a")) { *type = XW_BLOCK_LINK; *level = 0; return 1; }
    if (equal_ci(name, len, "pre")) { *type = XW_BLOCK_PREFORMATTED; *level = 0; return 1; }
    return 0;
}

int xw_html_parse(const char *html, size_t length, XwHtmlDocument *doc)
{
    HtmlFrame stack[16];
    size_t stack_count = 0, pos = 0;
    int in_title = 0, in_script = 0, in_style = 0;
    if (html == NULL || doc == NULL) return -1;
    memset(doc, 0, sizeof(*doc));
    memset(stack, 0, sizeof(stack));
    doc->source_bytes = length;

    while (pos < length) {
        if (html[pos] == '<') {
            size_t end = pos + 1;
            if (pos + 4 <= length && memcmp(html + pos, "<!--", 4) == 0) {
                const char *close = NULL;
                for (size_t k = pos + 4; k + 3 <= length; ++k) {
                    if (memcmp(html + k, "-->", 3) == 0) { close = html + k; break; }
                }
                pos = close ? (size_t)(close - html) + 3 : length;
                continue;
            }
            while (end < length && html[end] != '>') ++end;
            if (end >= length) break;
            {
                const char *tag = html + pos + 1;
                size_t tag_len = end - pos - 1, name_start = 0, name_end;
                int closing = 0;
                XwBlockType type = XW_BLOCK_TEXT;
                unsigned level = 0;
                while (name_start < tag_len && isspace((unsigned char)tag[name_start])) ++name_start;
                if (name_start < tag_len && tag[name_start] == '/') { closing = 1; ++name_start; }
                while (name_start < tag_len && isspace((unsigned char)tag[name_start])) ++name_start;
                name_end = name_start;
                while (name_end < tag_len && (isalnum((unsigned char)tag[name_end]) || tag[name_end] == '-')) ++name_end;
                size_t name_len = name_end - name_start;
                int is_script = equal_ci(tag + name_start, name_len, "script");
                int is_style = equal_ci(tag + name_start, name_len, "style");
                int is_title = equal_ci(tag + name_start, name_len, "title");

                if (is_script) in_script = !closing;
                else if (is_style) in_style = !closing;
                else if (is_title) in_title = !closing;
                else if (!in_script && !in_style && !closing) {
                    if (block_tag(tag + name_start, name_len, &type, &level)) {
                        if (stack_count < sizeof(stack) / sizeof(stack[0])) {
                            HtmlFrame *frame = &stack[stack_count++];
                            memset(frame, 0, sizeof(*frame));
                            (void)snprintf(frame->name, sizeof(frame->name), "%.*s", (int)name_len, tag + name_start);
                            frame->block = new_block(doc, type, level);
                            frame->preserve_whitespace = (type == XW_BLOCK_PREFORMATTED);
                            if (frame->block && type == XW_BLOCK_LINK)
                                copy_attribute(tag + name_start, tag_len - name_start, "href", frame->block->href, sizeof(frame->block->href));
                        }
                    } else if (equal_ci(tag + name_start, name_len, "img")) {
                        XwHtmlBlock *image = new_block(doc, XW_BLOCK_IMAGE, 0);
                        if (image) {
                            copy_attribute(tag + name_start, tag_len - name_start, "alt", image->text, sizeof(image->text));
                            copy_attribute(tag + name_start, tag_len - name_start, "src", image->href, sizeof(image->href));
                            if (image->text[0] == '\0') (void)snprintf(image->text, sizeof(image->text), "[imagem]");
                        }
                    } else if (equal_ci(tag + name_start, name_len, "hr")) {
                        (void)new_block(doc, XW_BLOCK_RULE, 0);
                    } else if (equal_ci(tag + name_start, name_len, "br")) {
                        if (stack_count && stack[stack_count - 1].block)
                            append_text(stack[stack_count - 1].block->text, sizeof(stack[stack_count - 1].block->text), " ", 1, 0);
                    }
                } else if (!in_script && !in_style && closing) {
                    for (size_t k = stack_count; k > 0; --k) {
                        if (name_len == strlen(stack[k - 1].name) && equal_ci(stack[k - 1].name, name_len, tag + name_start)) {
                            while (stack_count >= k) {
                                HtmlFrame *frame = &stack[--stack_count];
                                if (frame->block) trim(frame->block->text);
                            }
                            break;
                        }
                    }
                }
            }
            pos = end + 1;
        } else {
            size_t end = pos;
            char decoded[XW_HTML_TEXT_BYTES];
            while (end < length && html[end] != '<') ++end;
            if (!in_script && !in_style && end > pos) {
                if (in_title) {
                    char temp[XW_HTML_TEXT_BYTES];
                    (void)decode_entities(temp, sizeof(temp), html + pos, end - pos);
                    trim(temp);
                    if (temp[0]) {
                        if (doc->title[0]) append_text(doc->title, sizeof(doc->title), " ", 1, 0);
                        append_text(doc->title, sizeof(doc->title), temp, strlen(temp), 0);
                    }
                } else if (stack_count && stack[stack_count - 1].block) {
                    size_t n = decode_entities(decoded, sizeof(decoded), html + pos, end - pos);
                    append_text(stack[stack_count - 1].block->text, sizeof(stack[stack_count - 1].block->text), decoded, n,
                                stack[stack_count - 1].preserve_whitespace);
                }
            }
            pos = end;
        }
    }
    for (size_t i = 0; i < stack_count; ++i) if (stack[i].block) trim(stack[i].block->text);
    return 0;
}
