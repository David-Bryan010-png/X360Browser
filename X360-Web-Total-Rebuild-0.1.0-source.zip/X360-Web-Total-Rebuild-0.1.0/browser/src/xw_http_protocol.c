#include "xw_http_protocol.h"

#include <ctype.h>
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

static int ci_equal(const char *a, size_t n, const char *b)
{
    size_t i;
    if (strlen(b) != n) return 0;
    for (i = 0; i < n; ++i)
        if (tolower((unsigned char)a[i]) != tolower((unsigned char)b[i])) return 0;
    return 1;
}

static int set_error(char *out, size_t cap, const char *message)
{
    if (out && cap) (void)snprintf(out, cap, "%s", message);
    return -1;
}

static const unsigned char *find_bytes(const unsigned char *data, size_t len, const char *needle, size_t needle_len)
{
    if (needle_len > len) return NULL;
    for (size_t i = 0; i + needle_len <= len; ++i)
        if (memcmp(data + i, needle, needle_len) == 0) return data + i;
    return NULL;
}

static void copy_trimmed(char *out, size_t cap, const unsigned char *src, size_t len)
{
    while (len && (*src == ' ' || *src == '\t')) { ++src; --len; }
    while (len && (src[len - 1] == ' ' || src[len - 1] == '\t' || src[len - 1] == '\r')) --len;
    if (!cap) return;
    if (len >= cap) len = cap - 1;
    memcpy(out, src, len);
    out[len] = '\0';
}

static int contains_ci(const char *text, const char *needle)
{
    size_t n = strlen(needle), len = strlen(text);
    if (n > len) return 0;
    for (size_t i = 0; i + n <= len; ++i)
        if (ci_equal(text + i, n, needle)) return 1;
    return 0;
}

static int parse_headers(const unsigned char *data, size_t len, XwHttpHeaders *h)
{
    const unsigned char *line_end;
    size_t pos = 0;
    line_end = find_bytes(data, len, "\r\n", 2);
    if (!line_end) return -1;
    {
        char status[64];
        size_t status_len = (size_t)(line_end - data);
        if (status_len >= sizeof(status)) return -1;
        memcpy(status, data, status_len);
        status[status_len] = '\0';
        if (sscanf(status, "HTTP/%*u.%*u %d", &h->status_code) != 1) return -1;
    }
    pos = (size_t)(line_end - data) + 2;
    while (pos < len) {
        size_t end = pos;
        const unsigned char *colon;
        while (end + 1 < len && !(data[end] == '\r' && data[end + 1] == '\n')) ++end;
        if (end + 1 >= len) return -1;
        if (end == pos) return 0;
        colon = memchr(data + pos, ':', end - pos);
        if (colon) {
            size_t name_len = (size_t)(colon - (data + pos));
            const unsigned char *value = colon + 1;
            size_t value_len = end - (size_t)(value - data);
            if (ci_equal((const char *)data + pos, name_len, "content-length")) {
                char temp[32], *tail = NULL;
                unsigned long long v;
                copy_trimmed(temp, sizeof(temp), value, value_len);
                v = strtoull(temp, &tail, 10);
                if (tail == temp || *tail != '\0' || v > (unsigned long long)SIZE_MAX) return -1;
                h->content_length = (size_t)v;
                h->has_content_length = 1;
            } else if (ci_equal((const char *)data + pos, name_len, "transfer-encoding")) {
                char temp[96];
                copy_trimmed(temp, sizeof(temp), value, value_len);
                if (contains_ci(temp, "chunked")) h->chunked = 1;
            } else if (ci_equal((const char *)data + pos, name_len, "content-type")) {
                copy_trimmed(h->content_type, sizeof(h->content_type), value, value_len);
            } else if (ci_equal((const char *)data + pos, name_len, "location")) {
                copy_trimmed(h->location, sizeof(h->location), value, value_len);
            }
        }
        pos = end + 2;
    }
    return -1;
}

static int decode_chunked(const unsigned char *src, size_t len, unsigned char *out, size_t cap, size_t *out_len)
{
    size_t pos = 0, used = 0;
    while (pos < len) {
        size_t line_end = pos;
        unsigned long chunk_size;
        char size_text[24], *tail = NULL;
        while (line_end + 1 < len && !(src[line_end] == '\r' && src[line_end + 1] == '\n')) ++line_end;
        if (line_end + 1 >= len || line_end - pos >= sizeof(size_text)) return -1;
        memcpy(size_text, src + pos, line_end - pos);
        size_text[line_end - pos] = '\0';
        {
            char *extension = strchr(size_text, ';');
            if (extension) *extension = '\0';
        }
        chunk_size = strtoul(size_text, &tail, 16);
        if (tail == size_text || *tail != '\0') return -1;
        pos = line_end + 2;
        if (chunk_size == 0) {
            while (pos + 1 < len) {
                size_t trailer_end = pos;
                while (trailer_end + 1 < len && !(src[trailer_end] == '\r' && src[trailer_end + 1] == '\n')) ++trailer_end;
                if (trailer_end + 1 >= len) return -1;
                if (trailer_end == pos) { *out_len = used; return 0; }
                pos = trailer_end + 2;
            }
            return -1;
        }
        if (chunk_size > cap - used || chunk_size > len - pos) return -1;
        memcpy(out + used, src + pos, chunk_size);
        used += chunk_size;
        pos += chunk_size;
        if (pos + 2 > len || src[pos] != '\r' || src[pos + 1] != '\n') return -1;
        pos += 2;
    }
    return -1;
}

int xw_http_decode_response(const unsigned char *raw, size_t raw_len,
                            XwHttpHeaders *headers,
                            unsigned char *output, size_t output_cap,
                            size_t *output_len,
                            char *error, size_t error_cap)
{
    const unsigned char *separator;
    size_t header_len, body_len;
    XwHttpHeaders local;
    if (!raw || !headers || !output || !output_len) return set_error(error, error_cap, "argumento nulo");
    memset(&local, 0, sizeof(local));
    separator = find_bytes(raw, raw_len, "\r\n\r\n", 4);
    if (!separator) return set_error(error, error_cap, "cabecalho HTTP incompleto");
    header_len = (size_t)(separator - raw) + 4;
    if (header_len > XW_HTTP_HEADER_BYTES) return set_error(error, error_cap, "cabecalho HTTP grande demais");
    if (parse_headers(raw, header_len, &local) != 0) return set_error(error, error_cap, "resposta HTTP invalida");
    body_len = raw_len - header_len;
    if (local.has_content_length && local.content_length > body_len)
        return set_error(error, error_cap, "corpo HTTP incompleto");
    if (local.chunked) {
        if (decode_chunked(separator + 4, body_len, output, output_cap, output_len) != 0)
            return set_error(error, error_cap, "corpo chunked invalido ou grande demais");
    } else {
        if (local.has_content_length) body_len = local.content_length;
        if (body_len > output_cap) return set_error(error, error_cap, "pagina excede limite de memoria");
        memcpy(output, separator + 4, body_len);
        *output_len = body_len;
    }
    *headers = local;
    if (error && error_cap) error[0] = '\0';
    return 0;
}
