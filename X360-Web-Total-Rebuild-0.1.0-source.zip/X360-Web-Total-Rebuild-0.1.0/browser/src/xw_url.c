#include "xw_url.h"

#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static int fail(char *error, size_t size, const char *message)
{
    if (error != NULL && size > 0) {
        (void)snprintf(error, size, "%s", message);
    }
    return -1;
}

static int copy_range(char *destination, size_t capacity, const char *begin, size_t length)
{
    if (length + 1 > capacity) return -1;
    memcpy(destination, begin, length);
    destination[length] = '\0';
    return 0;
}

static int equal_ci(const char *a, size_t n, const char *b)
{
    size_t i;
    if (strlen(b) != n) return 0;
    for (i = 0; i < n; ++i)
        if (tolower((unsigned char)a[i]) != tolower((unsigned char)b[i])) return 0;
    return 1;
}

static int parse_port(const char *begin, const char *end, uint16_t *port_out)
{
    unsigned value = 0;
    if (begin == end) return -1;
    for (const char *p = begin; p < end; ++p) {
        if (*p < '0' || *p > '9') return -1;
        {
            unsigned digit = (unsigned)(*p - '0');
            if (value > (65535u - digit) / 10u) return -1;
            value = value * 10u + digit;
        }
    }
    if (value == 0) return -1;
    *port_out = (uint16_t)value;
    return 0;
}

static int valid_domain(const char *host)
{
    size_t label_length = 0, total = strlen(host);
    if (total == 0 || total > 253) return 0;
    for (size_t i = 0; i < total; ++i) {
        unsigned char c = (unsigned char)host[i];
        if (c == '.') {
            if (label_length == 0 || label_length > 63 || host[i - 1] == '-') return 0;
            label_length = 0;
        } else {
            if (!(isalnum(c) || c == '-')) return 0;
            if (label_length == 0 && c == '-') return 0;
            ++label_length;
        }
    }
    if (label_length == 0) return host[total - 1] == '.';
    return label_length <= 63 && host[total - 1] != '-';
}

int xw_url_parse(const char *input, XwUrl *out, char *error, size_t error_size)
{
    char normalized[XW_URL_INPUT_MAX + 8];
    const char *cursor;
    const char *authority_end;
    const char *host_begin;
    const char *host_end;
    const char *path_begin;
    size_t input_length;
    size_t scheme_length;
    uint16_t parsed_port;

    if (out == NULL || input == NULL) return fail(error, error_size, "argumento nulo");
    memset(out, 0, sizeof(*out));
    input_length = strlen(input);
    if (input_length == 0 || input_length > XW_URL_INPUT_MAX)
        return fail(error, error_size, "URL vazia ou longa demais");
    for (size_t i = 0; i < input_length; ++i) {
        unsigned char ch = (unsigned char)input[i];
        if (isspace(ch) || ch < 0x20 || ch == 0x7f)
            return fail(error, error_size, "URL contém espaço ou caractere de controle");
    }

    if (strstr(input, "://") == NULL) {
        if (snprintf(normalized, sizeof(normalized), "https://%s", input) >= (int)sizeof(normalized))
            return fail(error, error_size, "URL longa demais");
    } else {
        if (copy_range(normalized, sizeof(normalized), input, input_length) != 0)
            return fail(error, error_size, "URL longa demais");
    }

    cursor = strstr(normalized, "://");
    if (cursor == NULL) return fail(error, error_size, "esquema inválido");
    scheme_length = (size_t)(cursor - normalized);
    if (scheme_length == 4 && equal_ci(normalized, scheme_length, "http")) {
        memcpy(out->scheme, "http", 5);
        out->port = 80;
        out->tls = 0;
    } else if (scheme_length == 5 && equal_ci(normalized, scheme_length, "https")) {
        memcpy(out->scheme, "https", 6);
        out->port = 443;
        out->tls = 1;
    } else {
        return fail(error, error_size, "somente http e https são reconhecidos");
    }

    host_begin = cursor + 3;
    authority_end = host_begin + strcspn(host_begin, "/?#");
    if (authority_end == host_begin) return fail(error, error_size, "host ausente");
    if (memchr(host_begin, '@', (size_t)(authority_end - host_begin)) != NULL)
        return fail(error, error_size, "credenciais embutidas na URL não são aceitas");

    if (*host_begin == '[') {
        const char *closing = memchr(host_begin, ']', (size_t)(authority_end - host_begin));
        if (closing == NULL) return fail(error, error_size, "IPv6 sem colchete final");
        host_end = closing + 1;
        if (closing == host_begin + 1) return fail(error, error_size, "IPv6 vazio");
        for (const char *p = host_begin + 1; p < closing; ++p) {
            if (!(isxdigit((unsigned char)*p) || *p == ':' || *p == '.'))
                return fail(error, error_size, "endereco IPv6 invalido");
        }
        if (copy_range(out->host, sizeof(out->host), host_begin, (size_t)(host_end - host_begin)) != 0)
            return fail(error, error_size, "host longo demais");
        for (size_t i = 0; out->host[i] != '\0'; ++i)
            out->host[i] = (char)tolower((unsigned char)out->host[i]);
        if (host_end < authority_end) {
            if (*host_end != ':' || parse_port(host_end + 1, authority_end, &parsed_port) != 0)
                return fail(error, error_size, "porta fora do intervalo");
            out->port = parsed_port;
        }
    } else {
        const char *colon = memchr(host_begin, ':', (size_t)(authority_end - host_begin));
        host_end = colon != NULL ? colon : authority_end;
        if (copy_range(out->host, sizeof(out->host), host_begin, (size_t)(host_end - host_begin)) != 0)
            return fail(error, error_size, "host longo demais");
        for (size_t i = 0; out->host[i] != '\0'; ++i)
            out->host[i] = (char)tolower((unsigned char)out->host[i]);
        if (!valid_domain(out->host)) return fail(error, error_size, "host invalido");
        if (colon != NULL) {
            if (parse_port(colon + 1, authority_end, &parsed_port) != 0)
                return fail(error, error_size, "porta fora do intervalo");
            out->port = parsed_port;
        }
    }

    if (out->host[0] == '\0') return fail(error, error_size, "host ausente");
    path_begin = authority_end;
    if (*path_begin == '\0' || *path_begin == '#' || *path_begin == '?') {
        if (*path_begin == '?') {
            if (snprintf(out->path, sizeof(out->path), "/%s", path_begin) >= (int)sizeof(out->path))
                return fail(error, error_size, "caminho longo demais");
        } else {
            memcpy(out->path, "/", 2);
        }
    } else {
        const char *fragment = strchr(path_begin, '#');
        size_t path_length = fragment != NULL ? (size_t)(fragment - path_begin) : strlen(path_begin);
        if (copy_range(out->path, sizeof(out->path), path_begin, path_length) != 0)
            return fail(error, error_size, "caminho longo demais");
    }

    if (error != NULL && error_size > 0) error[0] = '\0';
    return 0;
}
