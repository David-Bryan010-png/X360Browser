#include "xw_http_client.h"

#include "xw_http_protocol.h"
#include "xw_url.h"

#include <stdint.h>
#include <stdio.h>
#include <string.h>

#include <lwip/dns.h>
#include <lwip/err.h>
#include <lwip/ip_addr.h>
#include <lwip/pbuf.h>
#include <lwip/tcp.h>

#define XW_HTTP_MAX_RAW (XW_HTTP_BODY_BYTES + XW_HTTP_HEADER_BYTES)

static unsigned char raw_response[XW_HTTP_MAX_RAW];
static unsigned char decoded_body[XW_HTTP_BODY_BYTES];
static size_t raw_length;
static size_t decoded_length;
static struct tcp_pcb *connection;
static XwHttpState state = XW_HTTP_IDLE;
static XwHttpHeaders response_headers;
static char last_error[160];
static XwUrl active_url;
static char request[2048];
static int result_ready;
static uintptr_t request_generation;

static void fail(const char *message)
{
    (void)snprintf(last_error, sizeof(last_error), "%s", message ? message : "erro de rede");
    state = XW_HTTP_FAILED;
    result_ready = 0;
}

static void on_tcp_error(void *arg, err_t error)
{
    if ((uintptr_t)arg != request_generation) return;
    connection = NULL; /* lwIP has already freed the PCB before this callback. */
    (void)snprintf(last_error, sizeof(last_error), "TCP falhou (lwIP %d)", (int)error);
    state = XW_HTTP_FAILED;
    result_ready = 0;
}

static err_t on_receive(void *arg, struct tcp_pcb *pcb, struct pbuf *packet, err_t error)
{
    if ((uintptr_t)arg != request_generation) { tcp_abort(pcb); return ERR_ABRT; }
    if (error != ERR_OK) {
        if (packet) pbuf_free(packet);
        tcp_abort(pcb);
        connection = NULL;
        fail("erro ao receber dados TCP");
        return ERR_ABRT;
    }
    if (packet == NULL) {
        err_t close_error = tcp_close(pcb);
        connection = NULL;
        if (close_error != ERR_OK) {
            tcp_abort(pcb);
            fail("nao foi possivel fechar conexao TCP");
            return ERR_ABRT;
        }
        state = XW_HTTP_DONE;
        result_ready = 1;
        return ERR_OK;
    }
    if ((size_t)packet->tot_len > XW_HTTP_MAX_RAW - raw_length) {
        tcp_abort(pcb);
        connection = NULL;
        fail("resposta excedeu 264 KiB");
        return ERR_ABRT;
    }
    if (pbuf_copy_partial(packet, raw_response + raw_length, packet->tot_len, 0) != packet->tot_len) {
        tcp_abort(pcb);
        connection = NULL;
        fail("falha ao copiar pacote TCP");
        return ERR_ABRT;
    }
    raw_length += packet->tot_len;
    tcp_recved(pcb, packet->tot_len);
    pbuf_free(packet);
    return ERR_OK;
}

static err_t on_connected(void *arg, struct tcp_pcb *pcb, err_t error)
{
    size_t request_length;
    if ((uintptr_t)arg != request_generation) { tcp_abort(pcb); return ERR_ABRT; }
    if (error != ERR_OK) {
        tcp_abort(pcb);
        connection = NULL;
        fail("conexao TCP recusada");
        return ERR_ABRT;
    }
    state = XW_HTTP_RECEIVING;
    request_length = strlen(request);
    if (request_length > 2048 || tcp_write(pcb, request, (u16_t)request_length, TCP_WRITE_FLAG_COPY) != ERR_OK || tcp_output(pcb) != ERR_OK) {
        tcp_abort(pcb);
        connection = NULL;
        fail("nao foi possivel enviar requisicao HTTP");
        return ERR_ABRT;
    }
    return ERR_OK;
}

static void begin_connection(ip_addr_t *address)
{
    err_t error;
    connection = tcp_new();
    if (!connection) { fail("sem memoria para conexao TCP"); return; }
    tcp_arg(connection, (void *)(uintptr_t)request_generation);
    tcp_recv(connection, on_receive);
    tcp_err(connection, on_tcp_error);
    state = XW_HTTP_CONNECTING;
    error = tcp_connect(connection, address, active_url.port, on_connected);
    if (error != ERR_OK) {
        tcp_abort(connection);
        connection = NULL;
        fail("nao foi possivel iniciar TCP");
    }
}

static void on_dns(const char *name, ip_addr_t *address, void *arg)
{
    (void)name;
    if ((uintptr_t)arg != request_generation || state != XW_HTTP_RESOLVING) return;
    if (address == NULL) { fail("DNS nao encontrou o host"); return; }
    begin_connection(address);
}

int xw_http_start(const char *url)
{
    ip_addr_t address;
    err_t dns_error;
    char error_text[128];
    if (state == XW_HTTP_RESOLVING || state == XW_HTTP_CONNECTING || state == XW_HTTP_RECEIVING)
        return -1;
    xw_http_cancel();
    if (xw_url_parse(url, &active_url, error_text, sizeof(error_text)) != 0) {
        fail(error_text);
        return -1;
    }
    if (active_url.tls) { fail("HTTPS ainda aguarda integracao TLS"); return -2; }
    if (strchr(active_url.host, ':') != NULL) { fail("IPv6 ainda nao esta habilitado nesta camada"); return -3; }
    {
        char host_header[sizeof(active_url.host) + 8];
        if (active_url.port == 80)
            (void)snprintf(host_header, sizeof(host_header), "%s", active_url.host);
        else
            (void)snprintf(host_header, sizeof(host_header), "%s:%u", active_url.host, (unsigned)active_url.port);
        if (snprintf(request, sizeof(request),
                     "GET %s HTTP/1.0\r\nHost: %s\r\nUser-Agent: X360WebTotal/0.1\r\n"
                     "Accept: text/html,application/xhtml+xml,text/plain,*/*;q=0.5\r\n"
                     "Accept-Encoding: identity\r\nConnection: close\r\n\r\n",
                     active_url.path, host_header) >= (int)sizeof(request)) {
            fail("requisicao HTTP grande demais");
            return -1;
        }
    }
    /* request is now ready for DNS/TCP. */
    if (request[0] == '\0') {
        fail("requisicao HTTP vazia");
        return -1;
    }
    raw_length = 0;
    decoded_length = 0;
    result_ready = 0;
    last_error[0] = '\0';
    state = XW_HTTP_RESOLVING;
    dns_error = dns_gethostbyname(active_url.host, &address, on_dns, (void *)(uintptr_t)request_generation);
    if (dns_error == ERR_OK) begin_connection(&address);
    else if (dns_error != ERR_INPROGRESS) { fail("consulta DNS nao pode ser iniciada"); return -1; }
    return 0;
}

void xw_http_cancel(void)
{
    ++request_generation;
    if (request_generation == 0) ++request_generation;
    if (connection != NULL) {
        tcp_abort(connection);
        connection = NULL;
    }
    state = XW_HTTP_IDLE;
    raw_length = decoded_length = 0;
    result_ready = 0;
    last_error[0] = '\0';
}

XwHttpState xw_http_state(void) { return state; }
const char *xw_http_error(void) { return last_error; }

int xw_http_result(const unsigned char **body, size_t *length, int *status_code)
{
    char decode_error[128];
    if (state != XW_HTTP_DONE || !result_ready || body == NULL || length == NULL) return -1;
    if (xw_http_decode_response(raw_response, raw_length, &response_headers,
                                decoded_body, sizeof(decoded_body), &decoded_length,
                                decode_error, sizeof(decode_error)) != 0) {
        fail(decode_error);
        return -1;
    }
    *body = decoded_body;
    *length = decoded_length;
    if (status_code) *status_code = response_headers.status_code;
    return 0;
}
