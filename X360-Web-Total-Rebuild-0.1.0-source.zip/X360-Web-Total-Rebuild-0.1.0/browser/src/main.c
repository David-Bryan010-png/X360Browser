/*
 * X360 Web Total - first LibXenon browser-shell milestone.
 * The code deliberately exposes HTTP-only status in this alpha. TLS, CSS and
 * JavaScript are not silently emulated or claimed to work.
 */
#include <stdio.h>
#include <string.h>

#include <console/console.h>
#include <diskio/ata.h>
#include <input/input.h>
#include <lwip/dns.h>
#include <libfat/fat.h>
#include <network/network.h>
#include <time/time.h>
#include <usb/usbmain.h>
#include <xenon_soc/xenon_power.h>
#include <xenos/xenos.h>

#include "xw_html.h"
#include "xw_http_client.h"
#include "xw_layout.h"

#define ADDRESS_CAP 256
#define KEY_ROWS 6
#define KEY_COLS 8

static const char keyboard[KEY_ROWS][KEY_COLS + 1] = {
    "abcdefgh", "ijklmnop", "qrstuvwx", "yz012345", "6789.-_/", ":?&=%+# "
};

static char address[ADDRESS_CAP] = "http://neverssl.com/";
static unsigned key_row;
static unsigned key_col;
static int network_ready;
static XwHtmlDocument current_document;
static XwLayout current_layout;
static int current_http_status;
static char ui_message[160];
static unsigned loading_frames;

typedef enum { SCREEN_HOME = 0, SCREEN_LOADING, SCREEN_PAGE, SCREEN_ERROR } Screen;
static Screen screen = SCREEN_HOME;

static void draw_home(void)
{
    unsigned width = 64, height = 32;
    console_get_dimensions(&width, &height);
    if (width < 32 || width > 110) width = 64;
    console_set_colors(CONSOLE_COLOR_BLACK, CONSOLE_COLOR_WHITE);
    console_clrscr();
    printf("X360 WEB TOTAL  |  REBUILD ALPHA 0.1.0\n");
    printf("================================================================\n");
    printf("Endereco: %s\n", address);
    printf("D-pad: escolher tecla | A: inserir | X: apagar | START: navegar\n");
    printf("----------------------------------------------------------------\n");
    for (unsigned r = 0; r < KEY_ROWS; ++r) {
        for (unsigned c = 0; c < KEY_COLS; ++c) {
            if (r == key_row && c == key_col) {
                console_set_colors(CONSOLE_COLOR_BLUE, CONSOLE_COLOR_WHITE);
                printf("[%c]", keyboard[r][c] == ' ' ? '_' : keyboard[r][c]);
                console_set_colors(CONSOLE_COLOR_BLACK, CONSOLE_COLOR_WHITE);
            } else {
                printf(" %c ", keyboard[r][c] == ' ' ? '_' : keyboard[r][c]);
            }
        }
        putchar('\n');
    }
    printf("----------------------------------------------------------------\n");
    printf("Rede: %s\n", network_ready ? "inicializada" : "indisponivel (verifique cabo/roteador)");
    printf("HTTP: disponivel nesta alpha | HTTPS/TLS: em desenvolvimento\n");
    printf("HTML: leitura estrutural | CSS/JS/imagens reais: em desenvolvimento\n");
    if (ui_message[0]) printf("\n%s\n", ui_message);
    (void)height;
}

static void draw_loading(void)
{
    console_set_colors(CONSOLE_COLOR_BLACK, CONSOLE_COLOR_WHITE);
    console_clrscr();
    printf("X360 WEB TOTAL\n");
    printf("Conectando a: %s\n\n", address);
    switch (xw_http_state()) {
        case XW_HTTP_RESOLVING: printf("Resolvendo DNS...\n"); break;
        case XW_HTTP_CONNECTING: printf("Abrindo conexao TCP...\n"); break;
        case XW_HTTP_RECEIVING: printf("Recebendo resposta HTTP...\n"); break;
        default: printf("Preparando requisicao...\n"); break;
    }
    printf("B: cancelar e voltar\n");
}

static void draw_document(void)
{
    unsigned width = 64, height = 32;
    console_get_dimensions(&width, &height);
    if (width < 32 || width > 110) width = 64;
    console_set_colors(CONSOLE_COLOR_BLACK, CONSOLE_COLOR_WHITE);
    console_clrscr();
    printf("X360 WEB TOTAL  |  HTTP %d\n", current_http_status);
    printf("URL: %.180s\n", address);
    printf("================================================================\n");
    if (current_document.title[0]) printf("Pagina: %.150s\n", current_document.title);
    for (size_t i = 0; i < current_layout.line_count && i < (height > 7 ? height - 7 : 1); ++i) {
        if (current_layout.lines[i].is_link) console_set_colors(CONSOLE_COLOR_BLACK, CONSOLE_COLOR_GREEN);
        for (unsigned s = 0; s < current_layout.lines[i].indent; ++s) putchar(' ');
        puts(current_layout.lines[i].text);
        console_set_colors(CONSOLE_COLOR_BLACK, CONSOLE_COLOR_WHITE);
    }
    if (current_document.truncated) printf("[Aviso: documento excedeu os limites desta alpha]\n");
    printf("\n----------------------------------------------------------------\n");
    printf("B: voltar ao inicio | BACK: sair\n");
    printf("Nota: links aparecem como texto; clique/DOM ainda nao foi implementado.\n");
}

static void draw_error(const char *message)
{
    console_set_colors(CONSOLE_COLOR_BLACK, CONSOLE_COLOR_ORANGE);
    console_clrscr();
    printf("X360 WEB TOTAL - FALHA DE NAVEGACAO\n\n");
    printf("URL: %s\n", address);
    printf("Erro: %s\n\n", message ? message : "erro desconhecido");
    printf("B: voltar ao inicio | BACK: sair\n");
    console_set_colors(CONSOLE_COLOR_BLACK, CONSOLE_COLOR_WHITE);
}

static void start_navigation(void)
{
    int result = xw_http_start(address);
    if (result != 0) {
        (void)snprintf(ui_message, sizeof(ui_message), "%s", xw_http_error());
        screen = SCREEN_ERROR;
        draw_error(ui_message);
        return;
    }
    screen = SCREEN_LOADING;
    loading_frames = 0;
    draw_loading();
}

static void finish_navigation(void)
{
    const unsigned char *body = NULL;
    size_t body_length = 0;
    if (xw_http_result(&body, &body_length, &current_http_status) != 0) {
        screen = SCREEN_ERROR;
        (void)snprintf(ui_message, sizeof(ui_message), "%s", xw_http_error());
        draw_error(ui_message);
        return;
    }
    if (current_http_status < 200 || current_http_status >= 300) {
        screen = SCREEN_ERROR;
        if (current_http_status >= 300 && current_http_status < 400)
            (void)snprintf(ui_message, sizeof(ui_message), "redirecionamento HTTP %d ainda nao e seguido automaticamente", current_http_status);
        else
            (void)snprintf(ui_message, sizeof(ui_message), "servidor respondeu HTTP %d", current_http_status);
        draw_error(ui_message);
        return;
    }
    if (xw_html_parse((const char *)body, body_length, &current_document) != 0 ||
        xw_layout_build(&current_document, 68, &current_layout) != 0) {
        screen = SCREEN_ERROR;
        draw_error("nao foi possivel interpretar a pagina");
        return;
    }
    screen = SCREEN_PAGE;
    draw_document();
}

static void append_key(char c)
{
    size_t n = strlen(address);
    if (n + 1 < sizeof(address) && c != ' ') {
        address[n] = c;
        address[n + 1] = '\0';
    }
}

int main(void)
{
    struct controller_data_s pad, previous;
    int net_result;
    unsigned dns_timer_frames = 0;

    memset(&pad, 0, sizeof(pad));
    memset(&previous, 0, sizeof(previous));
    xenos_init(VIDEO_MODE_AUTO);
    console_set_colors(CONSOLE_COLOR_BLACK, CONSOLE_COLOR_WHITE);
    console_init();
    console_clrscr();
    printf("X360 Web Total: preparando ambiente independente...\n");
    xenon_make_it_faster(XENON_SPEED_FULL);

    printf("Inicializando USB...\n");
    (void)usb_init();
    for (int i = 0; i < 20; ++i) { usb_do_poll(); mdelay(50); }
    printf("Inicializando armazenamento...\n");
    (void)xenon_ata_init();
    if (!fatInitDefault()) printf("Aviso: FAT nao foi montado pelo libfat.\n");

    printf("Inicializando rede (DHCP)...\n");
    net_result = network_init();
    network_ready = (net_result == NETWORK_INIT_SUCCESS) ||
                    (net_result == NETWORK_INIT_DHCP_FAILURE && network_link_up());
    if (net_result == NETWORK_INIT_SUCCESS) network_print_config();
    else if (net_result == NETWORK_INIT_DHCP_FAILURE) {
        printf("DHCP falhou; LibXenon configurou IP alternativo.\n");
        if (network_ready) network_print_config();
        else printf("Sem link Ethernet; verifique cabo e roteador.\n");
    } else printf("Interface de rede indisponivel.\n");
    mdelay(1000);

    screen = SCREEN_HOME;
    draw_home();
    for (;;) {
        int got_pad;
        network_poll();
        if (++dns_timer_frames >= 60) {
            dns_tmr(); /* LibXenon's NO_SYS build requires this timer to be pumped manually. */
            dns_timer_frames = 0;
        }
        got_pad = get_controller_data(&pad, 0);
        if (got_pad >= 0) {
            int pressed_a = pad.a && !previous.a;
            int pressed_b = pad.b && !previous.b;
            int pressed_x = pad.x && !previous.x;
            int pressed_start = pad.start && !previous.start;
            int pressed_back = pad.back && !previous.back;
            int pressed_up = pad.up && !previous.up;
            int pressed_down = pad.down && !previous.down;
            int pressed_left = pad.left && !previous.left;
            int pressed_right = pad.right && !previous.right;

            if (pressed_back) {
                xw_http_cancel();
                break;
            }
            if (screen == SCREEN_HOME) {
                if (pressed_up) key_row = (key_row + KEY_ROWS - 1) % KEY_ROWS;
                if (pressed_down) key_row = (key_row + 1) % KEY_ROWS;
                if (pressed_left) key_col = (key_col + KEY_COLS - 1) % KEY_COLS;
                if (pressed_right) key_col = (key_col + 1) % KEY_COLS;
                if (pressed_a) append_key(keyboard[key_row][key_col]);
                if (pressed_x) { size_t n = strlen(address); if (n) address[n - 1] = '\0'; }
                if (pressed_start) start_navigation();
                if (pressed_a || pressed_x || pressed_up || pressed_down || pressed_left || pressed_right) draw_home();
            } else if (screen == SCREEN_LOADING) {
                if (pressed_b) { xw_http_cancel(); screen = SCREEN_HOME; draw_home(); }
            } else if (screen == SCREEN_PAGE || screen == SCREEN_ERROR) {
                if (pressed_b) { xw_http_cancel(); screen = SCREEN_HOME; draw_home(); }
            }
            previous = pad;
        } else {
            memset(&previous, 0, sizeof(previous));
        }
        if (screen == SCREEN_LOADING) {
            if (xw_http_state() == XW_HTTP_DONE) finish_navigation();
            else if (xw_http_state() == XW_HTTP_FAILED) {
                screen = SCREEN_ERROR;
                (void)snprintf(ui_message, sizeof(ui_message), "%s", xw_http_error());
                draw_error(ui_message);
            } else {
                ++loading_frames;
                if (loading_frames > 1800) {
                    xw_http_cancel();
                    screen = SCREEN_ERROR;
                    (void)snprintf(ui_message, sizeof(ui_message), "tempo limite: DNS/TCP nao respondeu em 30 segundos");
                    draw_error(ui_message);
                } else if ((loading_frames % 60) == 0) draw_loading();
            }
        }
        mdelay(16);
    }

    console_set_colors(CONSOLE_COLOR_BLACK, CONSOLE_COLOR_WHITE);
    console_clrscr();
    printf("X360 Web Total encerrado.\n");
    return 0;
}
