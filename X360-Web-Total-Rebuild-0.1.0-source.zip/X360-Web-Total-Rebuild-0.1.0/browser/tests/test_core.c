#include "xw_html.h"
#include "xw_layout.h"
#include "xw_http_protocol.h"
#include "xw_url.h"

#include <stdio.h>
#include <string.h>

static int failures;
#define CHECK(expr) do { if (!(expr)) { fprintf(stderr, "FAIL %s:%d: %s\n", __FILE__, __LINE__, #expr); ++failures; } } while (0)

static void test_url(void)
{
    XwUrl url;
    char error[128];
    CHECK(xw_url_parse("example.com/path?q=1#top", &url, error, sizeof(error)) == 0);
    CHECK(strcmp(url.scheme, "https") == 0);
    CHECK(strcmp(url.host, "example.com") == 0);
    CHECK(strcmp(url.path, "/path?q=1") == 0);
    CHECK(url.port == 443 && url.tls == 1);
    CHECK(xw_url_parse("http://EXAMPLE.com:8080", &url, error, sizeof(error)) == 0);
    CHECK(strcmp(url.host, "example.com") == 0 && strcmp(url.path, "/") == 0 && url.port == 8080);
    CHECK(xw_url_parse("file:///etc/passwd", &url, error, sizeof(error)) != 0);
    CHECK(xw_url_parse("http://user:pass@example.com", &url, error, sizeof(error)) != 0);
    CHECK(xw_url_parse("http://example.com:99999", &url, error, sizeof(error)) != 0);
    CHECK(xw_url_parse("http://example.com:+80", &url, error, sizeof(error)) != 0);
    CHECK(xw_url_parse("http://exa_mple.com", &url, error, sizeof(error)) != 0);
    CHECK(xw_url_parse("HTTPS://Example.COM", &url, error, sizeof(error)) == 0);
    CHECK(strcmp(url.scheme, "https") == 0 && strcmp(url.host, "example.com") == 0);
    CHECK(xw_url_parse("http://[2001:DB8::1]:8080/", &url, error, sizeof(error)) == 0);
    CHECK(strcmp(url.host, "[2001:db8::1]") == 0 && url.port == 8080);
}

static void test_html(void)
{
    static const char html[] = "<!doctype html><html><head><title>Demo &amp; Test</title><script>bad()</script></head>"
        "<body><h1>Olá &lt;Xbox&gt;</h1><p>Um texto <strong>com ênfase</strong> e fim.</p>"
        "<a href=\"https://example.org/\">Abrir site</a><ul><li>Item um</li><li>Item dois</li></ul>"
        "<img src=\"cover.png\" alt=\"Capa\"><style>.x{}</style></body></html>";
    XwHtmlDocument doc;
    CHECK(xw_html_parse(html, strlen(html), &doc) == 0);
    CHECK(strcmp(doc.title, "Demo & Test") == 0);
    CHECK(doc.block_count >= 6);
    CHECK(strcmp(doc.blocks[0].text, "Olá <Xbox>") == 0);
    CHECK(strcmp(doc.blocks[1].text, "Um texto com ênfase e fim.") == 0);
    CHECK(doc.blocks[2].type == XW_BLOCK_LINK);
    CHECK(strcmp(doc.blocks[2].href, "https://example.org/") == 0);
    CHECK(strcmp(doc.blocks[2].text, "Abrir site") == 0);
    CHECK(doc.blocks[doc.block_count - 1].type == XW_BLOCK_IMAGE);
    CHECK(strcmp(doc.blocks[doc.block_count - 1].text, "Capa") == 0);
}

static void test_http_protocol(void)
{
    static const unsigned char plain[] =
        "HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: 5\r\n\r\nhello";
    static const unsigned char chunked[] =
        "HTTP/1.1 200 OK\r\nTransfer-Encoding: chunked\r\n\r\n"
        "5\r\nhello\r\n6\r\n world\r\n0\r\nX-Test: yes\r\n\r\n";
    unsigned char body[128];
    size_t body_len = 0;
    int status = 0;
    char error[128];
    XwHttpHeaders headers;
    CHECK(xw_http_decode_response(plain, sizeof(plain) - 1, &headers, body, sizeof(body), &body_len, error, sizeof(error)) == 0);
    CHECK(headers.status_code == 200 && body_len == 5 && memcmp(body, "hello", 5) == 0);
    CHECK(strcmp(headers.content_type, "text/html; charset=utf-8") == 0);
    status = headers.status_code;
    CHECK(status == 200);
    CHECK(xw_http_decode_response(chunked, sizeof(chunked) - 1, &headers, body, sizeof(body), &body_len, error, sizeof(error)) == 0);
    CHECK(headers.chunked == 1 && body_len == 11 && memcmp(body, "hello world", 11) == 0);
    CHECK(xw_http_decode_response(plain, sizeof(plain) - 3, &headers, body, sizeof(body), &body_len, error, sizeof(error)) != 0);
    CHECK(xw_http_decode_response(chunked, sizeof(chunked) - 8, &headers, body, sizeof(body), &body_len, error, sizeof(error)) != 0);
}

static void test_layout(void)
{
    XwHtmlDocument doc;
    XwLayout layout;
    memset(&doc, 0, sizeof(doc));
    doc.block_count = 1;
    doc.blocks[0].type = XW_BLOCK_PARAGRAPH;
    strcpy(doc.blocks[0].text, "Este é um parágrafo de teste que deve ocupar mais de uma linha na visualização.");
    CHECK(xw_layout_build(&doc, 30, &layout) == 0);
    CHECK(layout.line_count >= 3);
}

int main(void)
{
    test_url(); test_html(); test_http_protocol(); test_layout();
    if (failures) { fprintf(stderr, "%d test(s) failed\n", failures); return 1; }
    puts("All X360 Web Total host tests passed.");
    return 0;
}
