# Estado do motor web

## Marco 0.1.0-alpha.1 — base de execução

### Implementado no código desta alpha

- parsing de URL `http` e `https`, com host, porta, caminho e rejeição de credenciais embutidas;
- cliente HTTP experimental sobre DNS + TCP bruto do lwIP/LibXenon;
- pedido HTTP/1.0 com `Host`, `Connection: close` e `Accept-Encoding: identity`;
- leitura limitada a 264 KiB de resposta bruta;
- análise do status e de cabeçalhos básicos, `Content-Length` e `Transfer-Encoding: chunked`;
- parser HTML próprio e restrito, sem execução de script;
- layout de texto com quebra por palavras e limite de blocos/linhas;
- interface LibXenon com endereço editável pelo controle;
- inicialização de vídeo, USB, FAT, ATA, rede e controle.

Os testes de host validam o parser de URL, HTML, layout e protocolo HTTP. O cliente lwIP, o build cruzado e a execução no Xbox ainda precisam de validação real.

## Não implementado

- HTTPS/TLS, cadeia de certificados e relógio confiável;
- HTTP/1.1 persistente, redirecionamentos automáticos, links relativos, cookies e cache;
- DOM completo, eventos, formulários e navegação por links;
- CSS (cascata, seletores, box model, flex/grid e fontes);
- JavaScript (runtime, DOM API, timers e eventos);
- decodificação PNG/JPEG/GIF/WebP;
- áudio, vídeo, codecs, streaming adaptativo e DRM;
- histórico, favoritos persistentes, abas, downloads e armazenamento local.

## Sequência técnica recomendada

1. **Confiabilidade de rede:** timeout, cancelamento, redirecionamentos, DNS resiliente e respostas grandes.
2. **HTTPS:** portar TLS para LibXenon, validar certificados usando um bundle de CAs e testar SNI, versões TLS e cifras.
3. **DOM e navegação:** árvore de nós, atributos, resolução de URLs relativas, seleção/foco e eventos básicos.
4. **Renderizador visual:** superfícies Xenos, fontes, clipping, rolagem, caixas CSS e imagens.
5. **JavaScript restrito:** runtime embutido pequeno, com orçamento estrito de memória/instruções e API web parcial.
6. **Mídia:** formatos e codecs que caibam no hardware, primeiro imagens; áudio/vídeo depois.

A designação “navegador moderno” só será justificável quando as camadas de HTTPS, HTML/CSS, interação e renderização visual estiverem funcionando em testes reais. A meta é uma implementação própria, progressiva e otimizada para o Xbox 360 — não uma promessa de compatibilidade Chromium.
