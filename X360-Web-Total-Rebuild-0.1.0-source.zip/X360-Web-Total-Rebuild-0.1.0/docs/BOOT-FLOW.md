# Fluxo de inicialização

## Raiz esperada do pendrive FAT32

```text
USB:/
├── XellLaunch2.xex
├── xenon.elf
├── LEIA-ME.txt
├── FLUXO-DE-INICIALIZACAO.txt
├── SHA256SUMS.txt
└── X360WebTotal/
    ├── config/browser.ini
    ├── data/
    ├── cache/
    └── logs/
```

1. Extraia o pacote USB inteiro na raiz do pendrive FAT32.
2. No dashboard/homebrew, execute `XellLaunch2.xex`.
3. O XellLaunch2 inicia uma build XeLL compatível (ou usa o XeLL embutido conforme as condições documentadas no projeto).
4. XeLL Reloaded procura e carrega `xenon.elf` pelo USB FAT.
5. O ELF inicia o ambiente LibXenon do navegador.

## Importante sobre o ambiente

- Não há desligamento físico do console neste fluxo. O XEX solicita a transição suportada para XeLL; a execução anterior termina quando o controle é transferido.
- Um aplicativo XEX não pode descarregar o kernel completo do Xbox nem executar um ELF LibXenon como se fosse um aplicativo comum.
- A versão 2.2.0 do XellLaunch2 documenta uma correção para um bloqueio em tela preta em determinadas variantes de XeLL. A própria nota condiciona o caso `xell-gggggg` a uma NAND construída com J-Runner 3.4.0+ ou XeLL upstream compatível.
- Mantenha `xenon.elf` exatamente na raiz do pendrive e com esse nome.
- A configuração do console é individual: RGH/JTAG, NAND e XeLL devem ser verificados antes de considerar a inicialização garantida.
- Não há teste físico de boot nesta entrega.

## Recuperação

Se a tela ficar preta ou o XeLL não aparecer, não repita tentativas indefinidamente. Desligue pelo procedimento normal e use o caminho de recuperação conhecido do seu RGH/JTAG para voltar ao dashboard. Não grave NAND nem atualize XeLL automaticamente pelo navegador.
