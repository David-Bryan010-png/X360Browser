X360 WEB TOTAL 0.6.0 - REVISION EXPANDED 1

1. Extraia todo o conteudo do pacote para a raiz de um pendrive FAT32.
2. Mantenha xenon.elf na raiz e a pasta X360WebTotal completa.
3. Inicie XellLaunch2.xex pela dashboard homebrew configurada para carregar XeLL Reloaded.
4. O XeLL deve localizar e carregar xenon.elf no pendrive.
5. A configuracao e os dados do navegador ficam dentro de X360WebTotal/.
6. Favoritos e historico sao gravados automaticamente no USB. Nunca retire o pendrive durante uma gravacao.

CONTROLES PRINCIPAIS
- HOME: D-pad escolhe caracteres; A insere; X apaga; START abre; Y abre configuracoes; B abre historico.
- PAGINA: D-pad rola; esquerda/direita escolhe link; A abre; X volta; B retorna a Home; Y abre configuracoes.
- CONFIGURACOES: D-pad escolhe; A altera/executa; B volta.
- FAVORITOS/HISTORICO: D-pad escolhe; A abre; X remove; B volta.
- BACK encerra o aplicativo.

LIMITES IMPORTANTES
- XellLaunch2.xex e somente o launcher. O navegador e xenon.elf.
- HTTP/1.x e HTML limitado estao implementados; CSS completo e JavaScript nao.
- HTTPS/TLS permanece desabilitado nesta revisao. Enderecos HTTPS sao recusados com seguranca.
- Imagens rasterizadas, audio, video e reproducao de YouTube ainda nao estao implementados.
- A home.html e uma pre-visualizacao/configurador externo; a UI do console e desenhada em C.
- O app NAO le, grava, verifica, repara, faz backup ou restaura a NAND.
- Diagnostico mostra explicitamente NAND NAO VERIFICADA. Inicializacao do app nao prova integridade completa da NAND.
- Host tests nao substituem compilacao LibXenon e teste em Xbox 360 RGH/JTAG real.
