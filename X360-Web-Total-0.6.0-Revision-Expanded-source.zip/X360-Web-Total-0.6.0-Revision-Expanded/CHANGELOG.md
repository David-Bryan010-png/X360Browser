# Changelog — X360 Web Total

## 0.6.0 — Revision Expanded 1
- Histórico de navegação persistente no USB, limitado pela configuração 8/16/24.
- Favoritos persistentes no USB, com tela para abrir/remover e limite de 12 URLs.
- Novo formato de listas versionado com CRC32, validação estrita de URL e arquivo backup `.bak`.
- Novo menu nativo com Favoritos e Diagnóstico, mantendo acesso às opções de rede/controle.
- Histórico acessível diretamente pela tecla B na Home, com abertura e remoção de entradas.
- Política HTTPS consolidada em módulo próprio e fail-closed; não há downgrade para HTTP.
- Testes adicionais de persistência, recuperação e política de segurança.
- Documentação atualizada sobre limites do motor e pré-requisitos reais de TLS.

## 0.6.0 — Boot Diagnostics & Fast Start
- Inicialização USB mais curta com polling contínuo.
- Diagnóstico explícito: `BOOT OK` não significa NAND verificada.
- Atualização no console permanece bloqueada sem HTTPS e verificação autenticada.

## 0.5.0 — Interface gráfica e recuperação USB
- Primeira interface gráfica nativa em C e framebuffer Xenos.
- Recuperação dos arquivos de configuração no USB com CRC32 e snapshots.
