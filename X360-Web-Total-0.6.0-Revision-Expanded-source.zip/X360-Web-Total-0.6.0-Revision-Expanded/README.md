# X360 Web Total 0.6.0 — Revision Expanded 1

Navegador homebrew independente para Xbox 360 RGH/JTAG, em C/LibXenon. Identificação visual: **DVDBRN**.

## Objetivo desta revisão

Expandir a base 0.6.0 com persistência local, navegação mais utilizável e diagnóstico visível, mantendo limites claros sobre o que ainda não existe no motor web.

## Novidades implementadas nesta revisão

- Favoritos persistentes no USB (`X360WebTotal/data/bookmarks.dat`), com limite de 12 URLs.
- Histórico persistente no USB (`X360WebTotal/data/history.dat`), com limite configurável de 8, 16 ou 24 entradas.
- Arquivos de favoritos/histórico usam formato versionado, CRC32, validação de URL e rotação para cópia `.bak` antes da substituição.
- Arquivo principal inválido pode ser recuperado da cópia `.bak`; arquivos ausentes iniciam listas vazias.
- Novo menu nativo: salvar página nos favoritos, abrir favoritos, diagnóstico e voltar à tela anterior.
- Tela de favoritos: navegar, abrir e remover entradas com o controle.
- Tela de histórico: atalho **B** na home para abrir, selecionar, visitar e remover páginas recentes; a seleção preserva a posição para navegação Voltar.
- Tela de diagnóstico: estado USB/rede/IP, contagem de histórico/favoritos, status TLS e política NAND.
- Política HTTPS centralizada e *fail-closed*: o app recusa HTTPS enquanto não existir transporte TLS validado.
- Testes host adicionais para persistência, CRC/recuperação, favoritos e política de segurança.

## O que continua verdadeiro

- Inicialização: `XellLaunch2.xex → XeLL Reloaded → xenon.elf`.
- O `.xex` é o launcher. O navegador é o ELF LibXenon.
- Home, menus, favoritos, diagnóstico e páginas são desenhados pelo código C nativo. `home.html` é uma prévia/configurador externo, não o renderer do Xbox.
- O motor web apresenta HTML limitado em linhas e links. Não é um motor CSS moderno.
- HTTP/1.x experimental via lwIP; DNS A/IN via UDP e polling.
- JavaScript, CSS completo, imagens rasterizadas, áudio e vídeo ainda não são suportados.
- HTTPS/TLS permanece desabilitado. URLs `https://` são recusadas; não há downgrade silencioso para HTTP.
- A atualização automática do executável no console permanece desabilitada.
- O projeto não lê, grava, testa, repara, faz backup nem restaura NAND.

## HTTPS: decisão técnica desta revisão

A próxima integração deve usar uma versão mantida do Mbed TLS, adaptada ao transporte TCP de LibXenon. A série 4.1 é LTS e o projeto oficial informa manutenção até março de 2029; isso faz dela uma candidata melhor para o próximo ciclo que iniciar uma implementação criptográfica própria. Ainda assim, a biblioteca não foi ligada ao ELF nesta revisão.

Para habilitar HTTPS com segurança ainda faltam: integração TLS sobre o TCP assíncrono, fonte CSPRNG comprovada e exposta ao app por uma interface suportada, relógio confiável para validar `notBefore`/`notAfter`, conjunto atualizável de CAs, SNI, validação de hostname/cadeia e testes de interoperabilidade. A CPU Xenon possui unidade RNG descrita em análises arquiteturais, mas esta revisão não usa endereços de hardware não documentados nem presume que a API esteja disponível no LibXenon instalado.

Consulte `docs/TLS-HTTPS-ROADMAP.md`.

## Controles principais

- Home: D-pad/A/X editam o endereço; START navega; Y abre configurações; B abre histórico; BACK encerra.
- Página: D-pad rola/seleciona links; A abre; X volta no histórico; B retorna à home; Y configurações.
- Favoritos/histórico: D-pad seleciona; A abre; X remove; B retorna.

## Estrutura de armazenamento

```text
USB:/
├── xenon.elf
├── XellLaunch2.xex
└── X360WebTotal/
    ├── config/browser.ini
    ├── data/
    │   ├── browser.factory
    │   ├── browser.recovery.0
    │   ├── browser.recovery.1
    │   ├── history.dat
    │   └── bookmarks.dat
    ├── cache/
    ├── logs/
    └── ui/home.html
```

Os arquivos `.dat` são criados quando o usuário navega/salva favoritos. As cópias `.bak` aparecem após o segundo salvamento. Esses dados são somente do navegador.

## Testes locais executados nesta revisão

```sh
cmake -S browser -B build-host -DCMAKE_BUILD_TYPE=Release -DCMAKE_C_FLAGS='-Wall -Wextra -Wpedantic -Werror'
cmake --build build-host --parallel 2
ctest --test-dir build-host --output-on-failure
python3 scripts/test_package_usb.py
python3 scripts/test_nand_boundary.py
```

Resultado no ambiente host desta revisão: compilação da biblioteca de componentes e testes C aprovados; testes de empacotamento e fronteira NAND executados separadamente. O `main.c` depende de headers/SDK LibXenon e não é compilado pela suíte host.

**Ainda não confirmado:** cross-compile PowerPC/LibXenon, ELF gerado por este código, boot pelo XeLL, renderização Xenos no console e teste físico de controle/rede/USB. A etapa de release do GitHub deve executar a compilação cruzada e validar o ELF antes de montar o pacote para console.

## Build Xbox 360

```sh
cd browser
make clean all DEVKITXENON=/caminho/para/devkitxenon
```

Saída esperada: `browser/xenon.elf`. Só um build bem-sucedido no toolchain LibXenon e teste no console podem confirmar a execução real.
