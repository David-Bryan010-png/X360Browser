#include "xw_ui.h"

#include <stdio.h>
#include <string.h>

#define C_BG       0xFF08110Du
#define C_PANEL    0xFF13251Cu
#define C_PANEL2   0xFF1A3025u
#define C_GREEN    0xFF32D477u
#define C_GREEN2   0xFF1B9E59u
#define C_WHITE    0xFFF1F7F3u
#define C_MUTED    0xFF9AB3A4u
#define C_DARK     0xFF0D1912u
#define C_BORDER   0xFF294A36u
#define C_YELLOW   0xFFFFD166u
#define C_RED      0xFFFF6868u

static int sx(const XwGraphics *g, int x) { return (int)((long)x * (long)g->width / 1280L); }
static int sy(const XwGraphics *g, int y) { return (int)((long)y * (long)g->height / 720L); }
static int sw(const XwGraphics *g, int w) { return sx(g, w); }
static int sh(const XwGraphics *g, int h) { return sy(g, h); }
static unsigned text_scale(const XwGraphics *g) { return g->width >= 1000u ? 2u : 1u; }

static void rect(XwGraphics *g, int x, int y, int w, int h, uint32_t color)
{ xw_gfx_rect(g, sx(g,x), sy(g,y), sw(g,w), sh(g,h), color); }
static void border(XwGraphics *g, int x, int y, int w, int h, int t, uint32_t color)
{ xw_gfx_border(g, sx(g,x), sy(g,y), sw(g,w), sh(g,h), sx(g,t) > 0 ? sx(g,t) : 1, color); }
static void text(XwGraphics *g, int x, int y, const char *s, uint32_t color)
{ xw_gfx_text(g, sx(g,x), sy(g,y), s, text_scale(g), color); }

static void shell(XwGraphics *g, const char *section)
{
    char caption[96];
    xw_gfx_clear(g, C_BG);
    rect(g, 0, 0, 1280, 68, C_DARK);
    rect(g, 0, 66, 1280, 2, C_GREEN);
    rect(g, 34, 18, 34, 34, C_GREEN);
    text(g, 43, 29, "W", C_DARK);
    text(g, 84, 18, "X360 WEB TOTAL", C_WHITE);
    (void)snprintf(caption, sizeof(caption), "DVDBRN  /  %s", section ? section : "BROWSER");
    text(g, 84, 43, caption, C_MUTED);
    text(g, 1110, 28, "XBOX 360", C_GREEN);
}

void xw_ui_home(XwGraphics *g, const char *url, unsigned key_row, unsigned key_col,
                const char *network, const char *ip, const char *message)
{
    static const char keyboard[6][9] = {"ABCDEFGH", "IJKLMNOP", "QRSTUVWX", "YZ012345", "6789.-_/ ", ":?&=%+# "};
    char line[190];
    if (!g || !g->pixels) return;
    shell(g, "INICIO");
    text(g, 42, 91, "NAVEGADOR", C_WHITE);
    text(g, 42, 119, "Digite um endereco e pressione START para navegar", C_MUTED);
    rect(g, 38, 150, 1204, 64, C_PANEL);
    border(g, 38, 150, 1204, 64, 2, C_BORDER);
    rect(g, 54, 166, 34, 32, C_GREEN2);
    text(g, 64, 176, "G", C_WHITE);
    (void)snprintf(line, sizeof(line), "%.170s", url ? url : "http://");
    text(g, 108, 174, line, C_WHITE);

    rect(g, 38, 236, 570, 116, C_PANEL);
    rect(g, 38, 236, 7, 116, C_GREEN);
    text(g, 62, 258, "REDE", C_GREEN);
    (void)snprintf(line, sizeof(line), "Status: %.72s", network ? network : "NAO INICIALIZADA");
    text(g, 62, 285, line, C_WHITE);
    (void)snprintf(line, sizeof(line), "IP: %.75s", ip ? ip : "0.0.0.0");
    text(g, 62, 313, line, C_MUTED);

    rect(g, 628, 236, 614, 116, C_PANEL);
    rect(g, 628, 236, 7, 116, C_GREEN2);
    text(g, 652, 258, "ATALHOS", C_GREEN);
    text(g, 652, 286, "Y  CONFIGURACOES", C_WHITE);
    text(g, 652, 314, "B HISTORICO  |  BACK SAIR", C_MUTED);

    rect(g, 38, 372, 1204, 300, C_PANEL);
    text(g, 58, 392, "TECLADO VIRTUAL  |  D-PAD ESCOLHER  |  A INSERIR  |  X APAGAR  |  B HISTORICO", C_MUTED);
    for (unsigned r = 0; r < 6u; ++r) {
        for (unsigned c = 0; c < 8u; ++c) {
            int x = 58 + (int)c * 145;
            int y = 432 + (int)r * 36;
            uint32_t fill = (r == key_row && c == key_col) ? C_GREEN2 : C_PANEL2;
            rect(g, x, y, 128, 29, fill);
            if (r == key_row && c == key_col) border(g, x, y, 128, 29, 2, C_GREEN);
            line[0] = keyboard[r][c] == ' ' ? '_' : keyboard[r][c]; line[1] = '\0';
            text(g, x + 58, y + 9, line, (r == key_row && c == key_col) ? C_WHITE : C_MUTED);
        }
    }
    if (message && message[0]) {
        rect(g, 38, 680, 1204, 28, C_DARK);
        text(g, 48, 690, message, C_YELLOW);
    }
    xw_gfx_present(g);
}

void xw_ui_loading(XwGraphics *g, const char *url, const char *phase)
{
    if (!g || !g->pixels) return;
    shell(g, "CARREGANDO");
    rect(g, 180, 210, 920, 280, C_PANEL);
    border(g, 180, 210, 920, 280, 2, C_BORDER);
    text(g, 230, 258, "CONECTANDO AO SITE", C_GREEN);
    text(g, 230, 310, phase ? phase : "AGUARDE...", C_WHITE);
    text(g, 230, 364, url ? url : "", C_MUTED);
    rect(g, 230, 422, 820, 8, C_PANEL2);
    rect(g, 230, 422, 190, 8, C_GREEN);
    text(g, 230, 458, "B  CANCELAR     BACK  SAIR", C_MUTED);
    xw_gfx_present(g);
}

void xw_ui_page(XwGraphics *g, const char *url, const char *title, int status,
                const XwLayout *layout, size_t scroll, unsigned selected_link)
{
    size_t visible, end;
    unsigned selected_block = 0, links = 0;
    int found = 0;
    char status_text[48];
    if (!g || !g->pixels) return;
    shell(g, "PAGINA WEB");
    rect(g, 36, 82, 1208, 48, C_PANEL);
    text(g, 52, 101, url ? url : "", C_WHITE);
    rect(g, 36, 144, 1208, 56, C_PANEL2);
    (void)snprintf(status_text, sizeof(status_text), "HTTP %d", status);
    text(g, 54, 164, status_text, C_GREEN);
    text(g, 170, 164, title && title[0] ? title : "PAGINA SEM TITULO", C_WHITE);
    rect(g, 36, 214, 1208, 444, 0xFFFFFFFFu);
    rect(g, 36, 214, 1208, 444, 0xFFFCFDFCu);
    if (layout) {
        for (size_t i = 0; i < layout->line_count; ++i) {
            if (layout->lines[i].is_link) {
                if (links == selected_link) { selected_block = layout->lines[i].source_block; found = 1; break; }
                ++links;
            }
        }
        visible = g->height > 600u ? 24u : 14u;
        if (scroll > layout->line_count) scroll = layout->line_count;
        end = scroll + visible;
        if (end > layout->line_count) end = layout->line_count;
        for (size_t i = scroll; i < end; ++i) {
            const XwVisualLine *l = &layout->lines[i];
            int y = 236 + (int)(i - scroll) * (g->height > 600u ? 17 : 20);
            uint32_t color = (found && l->is_link && l->source_block == selected_block) ? 0xFF008A42u :
                             (l->is_link ? 0xFF136AABu : 0xFF1A211Du);
            if (found && l->is_link && l->source_block == selected_block) rect(g, 48, y - 2, 1178, 17, 0xFFDDF4E5u);
            xw_gfx_text(g, sx(g, 54 + (int)l->indent * 8), sy(g, y), l->text, 1u, color);
        }
    }
    rect(g, 36, 666, 1208, 34, C_DARK);
    text(g, 52, 677, "UP/DOWN ROLAR   LEFT/RIGHT LINK   A ABRIR   X VOLTAR   B INICIO", C_WHITE);
    xw_gfx_present(g);
}

void xw_ui_error(XwGraphics *g, const char *url, const char *message)
{
    if (!g || !g->pixels) return;
    shell(g, "ERRO");
    rect(g, 150, 200, 980, 300, C_PANEL);
    border(g, 150, 200, 980, 300, 2, C_RED);
    text(g, 202, 244, "NAO FOI POSSIVEL ABRIR A PAGINA", C_RED);
    text(g, 202, 300, url ? url : "", C_WHITE);
    text(g, 202, 350, message ? message : "ERRO DESCONHECIDO", C_MUTED);
    text(g, 202, 436, "B  VOLTAR AO INICIO     BACK  SAIR", C_WHITE);
    xw_gfx_present(g);
}

void xw_ui_settings(XwGraphics *g, unsigned selected, const char *const names[13],
                    const char *const values[8], const char *message)
{
    char line[220];
    if (!g || !g->pixels) return;
    shell(g, "CONFIGURACOES");
    text(g, 42, 92, "REDE, CONTROLE E NAVEGACAO", C_GREEN);
    for (unsigned i = 0; i < 13u; ++i) {
        int y = 118 + (int)i * 40;
        uint32_t fill = (i == selected) ? C_GREEN2 : C_PANEL;
        rect(g, 40, y, 1200, 40, fill);
        if (i == selected) border(g, 40, y, 1200, 40, 2, C_GREEN);
        (void)snprintf(line, sizeof(line), "%s", names && names[i] ? names[i] : "");
        text(g, 60, y + 13, line, C_WHITE);
        if (i < 8u && values && values[i]) text(g, 620, y + 13, values[i], C_MUTED);
    }
    text(g, 44, 646, "D-PAD SELECIONAR   A EXECUTAR   B VOLTAR", C_WHITE);
    if (message && message[0]) text(g, 44, 678, message, C_YELLOW);
    xw_gfx_present(g);
}

void xw_ui_editor(XwGraphics *g, const char *field, const char *value,
                  unsigned key_row, unsigned key_col, int numeric)
{
    static const char keyboard[6][9] = {"ABCDEFGH", "IJKLMNOP", "QRSTUVWX", "YZ012345", "6789.-_/ ", ":?&=%+# "};
    char line[180];
    (void)numeric;
    if (!g || !g->pixels) return;
    shell(g, "EDITAR CONFIGURACAO");
    (void)snprintf(line, sizeof(line), "CAMPO: %.120s", field ? field : "");
    text(g, 44, 100, line, C_GREEN);
    rect(g, 40, 142, 1200, 68, C_PANEL);
    border(g, 40, 142, 1200, 68, 2, C_BORDER);
    text(g, 60, 172, value ? value : "", C_WHITE);
    for (unsigned r = 0; r < 6u; ++r) {
        for (unsigned c = 0; c < 8u; ++c) {
            int x = 58 + (int)c * 145;
            int y = 244 + (int)r * 54;
            uint32_t fill = (r == key_row && c == key_col) ? C_GREEN2 : C_PANEL;
            rect(g, x, y, 128, 42, fill);
            if (r == key_row && c == key_col) border(g, x, y, 128, 42, 2, C_GREEN);
            line[0] = keyboard[r][c] == ' ' ? '_' : keyboard[r][c]; line[1] = '\0';
            text(g, x + 58, y + 17, line, C_WHITE);
        }
    }
    text(g, 44, 602, "D-PAD ESCOLHER   A INSERIR   X APAGAR   START CONFIRMAR   B CANCELAR", C_WHITE);
    xw_gfx_present(g);
}


void xw_ui_bookmarks(XwGraphics *g, const XwStoreList *bookmarks, unsigned selected,
                     const char *message)
{
    char line[190];
    if (!g || !g->pixels) return;
    shell(g, "FAVORITOS");
    text(g, 42, 94, "PAGINAS SALVAS NO USB", C_GREEN);
    if (!bookmarks || bookmarks->count == 0u) {
        text(g, 70, 170, "NENHUM FAVORITO SALVO", C_MUTED);
        text(g, 70, 210, "Abra uma pagina e salve em CONFIGURACOES", C_WHITE);
    } else {
        for (unsigned i = 0; i < bookmarks->count; ++i) {
            int y = 142 + (int)i * 42;
            uint32_t fill = (i == selected) ? C_GREEN2 : C_PANEL;
            rect(g, 40, y, 1200, 34, fill);
            if (i == selected) border(g, 40, y, 1200, 34, 2, C_GREEN);
            (void)snprintf(line, sizeof(line), "%u. %.168s", i + 1u, bookmarks->items[i]);
            text(g, 58, y + 11, line, C_WHITE);
        }
    }
    text(g, 44, 646, "UP/DOWN SELECIONAR   A ABRIR   X REMOVER   B VOLTAR", C_WHITE);
    if (message && message[0]) text(g, 44, 678, message, C_YELLOW);
    xw_gfx_present(g);
}

void xw_ui_history(XwGraphics *g, const XwStoreList *history, unsigned selected,
                   const char *message)
{
    char line[190];
    if (!g || !g->pixels) return;
    shell(g, "HISTORICO");
    text(g, 42, 94, "NAVEGACOES RECENTES SALVAS NO USB", C_GREEN);
    if (!history || history->count == 0u) {
        text(g, 70, 170, "NENHUM HISTORICO DISPONIVEL", C_MUTED);
        text(g, 70, 210, "Visite uma pagina HTTP para criar entradas", C_WHITE);
    } else {
        unsigned first = selected >= 12u ? selected - 11u : 0u;
        unsigned last = first + 12u;
        if (last > history->count) last = history->count;
        for (unsigned i = first; i < last; ++i) {
            int y = 142 + (int)(i - first) * 42;
            uint32_t fill = (i == selected) ? C_GREEN2 : C_PANEL;
            rect(g, 40, y, 1200, 34, fill);
            if (i == selected) border(g, 40, y, 1200, 34, 2, C_GREEN);
            (void)snprintf(line, sizeof(line), "%u. %.168s", i + 1u, history->items[i]);
            text(g, 58, y + 11, line, C_WHITE);
        }
    }
    text(g, 44, 646, "UP/DOWN SELECIONAR   A ABRIR   X REMOVER   B VOLTAR", C_WHITE);
    if (message && message[0]) text(g, 44, 678, message, C_YELLOW);
    xw_gfx_present(g);
}

void xw_ui_diagnostics(XwGraphics *g, const char *const lines[8])
{
    if (!g || !g->pixels) return;
    shell(g, "DIAGNOSTICO");
    text(g, 42, 94, "ESTADO DO NAVEGADOR E DO AMBIENTE", C_GREEN);
    for (unsigned i = 0; i < 8u; ++i) {
        int y = 144 + (int)i * 54;
        rect(g, 40, y, 1200, 42, C_PANEL);
        text(g, 60, y + 14, lines && lines[i] ? lines[i] : "", C_WHITE);
    }
    text(g, 44, 650, "B VOLTAR  |  BACK ENCERRAR", C_MUTED);
    xw_gfx_present(g);
}
