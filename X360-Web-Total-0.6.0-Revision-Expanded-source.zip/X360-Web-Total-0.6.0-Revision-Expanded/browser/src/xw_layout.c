#include "xw_layout.h"

#include <stdio.h>
#include <string.h>

static void push_line(XwLayout *layout, const char *text, unsigned indent,
                      unsigned block, int link)
{
    XwVisualLine *line;
    if (layout->line_count >= sizeof(layout->lines) / sizeof(layout->lines[0])) {
        ++layout->dropped_lines;
        return;
    }
    line = &layout->lines[layout->line_count++];
    memset(line, 0, sizeof(*line));
    (void)snprintf(line->text, sizeof(line->text), "%s", text);
    line->indent = indent;
    line->source_block = block;
    line->is_link = link;
}

static unsigned spaces_before(XwBlockType type, unsigned level)
{
    if (type == XW_BLOCK_HEADING) return level > 1 ? 1u : 0u;
    if (type == XW_BLOCK_LIST_ITEM) return 2u;
    if (type == XW_BLOCK_LINK) return 1u;
    return 0u;
}

static void emit_wrapped_text(XwLayout *layout, const char *src, unsigned limit,
                              unsigned indent, unsigned block, int is_link,
                              const char *prefix)
{
    char line[128];
    size_t used = 0, pos = 0, length = strlen(src);
    const size_t line_capacity = sizeof(line) - 1;
    if (prefix != NULL) {
        size_t prefix_len = strlen(prefix);
        if (prefix_len > line_capacity) prefix_len = line_capacity;
        memcpy(line, prefix, prefix_len);
        used = prefix_len;
    }
    while (pos < length) {
        size_t word_start, word_length;
        while (pos < length && src[pos] == ' ') ++pos;
        word_start = pos;
        while (pos < length && src[pos] != ' ') ++pos;
        word_length = pos - word_start;
        if (word_length == 0) continue;
        if (used != 0 && used < limit && used + 1 + word_length <= limit && used + 1 + word_length <= line_capacity) {
            line[used++] = ' ';
        } else if (used != 0 && (used >= limit || used + 1 + word_length > limit)) {
            line[used] = '\0';
            push_line(layout, line, indent, block, is_link);
            used = 0;
        }
        while (word_length != 0) {
            size_t room = limit > used ? (size_t)(limit - used) : 1u;
            size_t take;
            if (room > line_capacity - used) room = line_capacity - used;
            if (room == 0) {
                line[used] = '\0';
                push_line(layout, line, indent, block, is_link);
                used = 0;
                room = limit < line_capacity ? limit : line_capacity;
                if (room == 0) room = 1;
            }
            take = word_length < room ? word_length : room;
            memcpy(line + used, src + word_start, take);
            used += take;
            word_start += take;
            word_length -= take;
            if (word_length != 0) {
                line[used] = '\0';
                push_line(layout, line, indent, block, is_link);
                used = 0;
            }
        }
    }
    if (used != 0 || length == 0) {
        line[used] = '\0';
        push_line(layout, line, indent, block, is_link);
    }
}

int xw_layout_build(const XwHtmlDocument *document, unsigned columns, XwLayout *layout)
{
    if (document == NULL || layout == NULL || columns < 12u || columns > 120u) return -1;
    memset(layout, 0, sizeof(*layout));
    for (size_t i = 0; i < document->block_count; ++i) {
        const XwHtmlBlock *block = &document->blocks[i];
        unsigned indent = spaces_before(block->type, block->level);
        unsigned limit = columns > indent ? columns - indent : columns;
        const char *prefix = NULL;
        char href_line[128];
        int link = block->type == XW_BLOCK_LINK;
        if (block->type == XW_BLOCK_RULE) {
            push_line(layout, "----------------------------------------------------------------------------", 0, (unsigned)i, 0);
            continue;
        }
        if (block->type == XW_BLOCK_HEADING) prefix = "# ";
        else if (block->type == XW_BLOCK_LIST_ITEM) prefix = "* ";
        else if (block->type == XW_BLOCK_LINK) prefix = "[LINK] ";
        else if (block->type == XW_BLOCK_IMAGE) prefix = "[IMG] ";
        if (block->type == XW_BLOCK_HEADING || block->type == XW_BLOCK_PARAGRAPH ||
            block->type == XW_BLOCK_LIST_ITEM || block->type == XW_BLOCK_IMAGE ||
            block->type == XW_BLOCK_PREFORMATTED || block->type == XW_BLOCK_LINK)
            push_line(layout, "", 0, (unsigned)i, 0);
        if (prefix != NULL) {
            size_t n = strlen(prefix);
            limit = columns > n ? columns - (unsigned)n : columns;
        }
        emit_wrapped_text(layout, block->text, limit, indent, (unsigned)i, link, prefix);
        if (block->type == XW_BLOCK_LINK && block->href[0]) {
            (void)snprintf(href_line, sizeof(href_line), "  -> %.118s", block->href);
            push_line(layout, href_line, indent, (unsigned)i, 1);
        } else if (block->type == XW_BLOCK_IMAGE && block->href[0]) {
            (void)snprintf(href_line, sizeof(href_line), "  src: %.117s", block->href);
            push_line(layout, href_line, indent, (unsigned)i, 0);
        }
    }
    return 0;
}
