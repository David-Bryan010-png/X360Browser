#ifndef XW_HTML_H
#define XW_HTML_H

#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

#define XW_HTML_MAX_BLOCKS 192
#define XW_HTML_TEXT_BYTES 768
#define XW_HTML_HREF_BYTES 384
#define XW_HTML_TITLE_BYTES 160

typedef enum {
    XW_BLOCK_TEXT = 0,
    XW_BLOCK_HEADING,
    XW_BLOCK_PARAGRAPH,
    XW_BLOCK_LIST_ITEM,
    XW_BLOCK_LINK,
    XW_BLOCK_IMAGE,
    XW_BLOCK_RULE,
    XW_BLOCK_PREFORMATTED
} XwBlockType;

typedef struct {
    XwBlockType type;
    unsigned level;
    char text[XW_HTML_TEXT_BYTES];
    char href[XW_HTML_HREF_BYTES];
} XwHtmlBlock;

typedef struct {
    char title[XW_HTML_TITLE_BYTES];
    XwHtmlBlock blocks[XW_HTML_MAX_BLOCKS];
    size_t block_count;
    size_t source_bytes;
    size_t dropped_blocks;
    int truncated;
} XwHtmlDocument;

/* Bounded, deliberately conservative HTML reader. It does not execute scripts. */
int xw_html_parse(const char *html, size_t length, XwHtmlDocument *document);

#ifdef __cplusplus
}
#endif
#endif
