#ifndef XW_UI_H
#define XW_UI_H

#include "xw_config.h"
#include "xw_graphics.h"
#include "xw_layout.h"
#include "xw_store.h"

void xw_ui_home(XwGraphics *gfx, const char *url, unsigned key_row, unsigned key_col,
                const char *network, const char *ip, const char *message);
void xw_ui_loading(XwGraphics *gfx, const char *url, const char *phase);
void xw_ui_page(XwGraphics *gfx, const char *url, const char *title, int status,
                const XwLayout *layout, size_t scroll, unsigned selected_link);
void xw_ui_error(XwGraphics *gfx, const char *url, const char *message);
void xw_ui_settings(XwGraphics *gfx, unsigned selected, const char *const names[13],
                    const char *const values[8], const char *message);
void xw_ui_bookmarks(XwGraphics *gfx, const XwStoreList *bookmarks, unsigned selected,
                     const char *message);
void xw_ui_history(XwGraphics *gfx, const XwStoreList *history, unsigned selected,
                   const char *message);
void xw_ui_diagnostics(XwGraphics *gfx, const char *const lines[8]);
void xw_ui_editor(XwGraphics *gfx, const char *field, const char *value,
                  unsigned key_row, unsigned key_col, int numeric);

#endif
