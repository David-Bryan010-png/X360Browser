#ifndef XW_HTTP_PROTOCOL_H
#define XW_HTTP_PROTOCOL_H

#include <stddef.h>

#define XW_HTTP_HEADER_BYTES 8192
#define XW_HTTP_BODY_BYTES (256u * 1024u)

typedef struct {
    int status_code;
    int chunked;
    size_t content_length;
    int has_content_length;
    char content_type[96];
    char content_encoding[32];
    char location[384];
} XwHttpHeaders;

/* Parses an HTTP/1.x response and copies the decoded entity body to output. */
int xw_http_decode_response(const unsigned char *raw, size_t raw_length,
                            XwHttpHeaders *headers,
                            unsigned char *output, size_t output_capacity,
                            size_t *output_length,
                            char *error, size_t error_capacity);

#endif
