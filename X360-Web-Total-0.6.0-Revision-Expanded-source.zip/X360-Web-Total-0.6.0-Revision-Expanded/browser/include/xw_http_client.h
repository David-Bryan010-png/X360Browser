#ifndef XW_HTTP_CLIENT_H
#define XW_HTTP_CLIENT_H

#include <stddef.h>

typedef enum {
    XW_HTTP_IDLE = 0,
    XW_HTTP_RESOLVING,
    XW_HTTP_CONNECTING,
    XW_HTTP_RECEIVING,
    XW_HTTP_DONE,
    XW_HTTP_FAILED
} XwHttpState;

/* LibXenon lwIP raw-TCP HTTP/1.0 client. HTTPS is rejected until TLS is added. */
int xw_http_start(const char *url);
void xw_http_cancel(void);
void xw_http_poll(void);
const char *xw_http_location(void);
XwHttpState xw_http_state(void);
const char *xw_http_error(void);
int xw_http_result(const unsigned char **body, size_t *length, int *status_code);

#endif
