#include "xw_html.h"
#include "xw_layout.h"
#include "xw_http_protocol.h"
#include "xw_url.h"
#include "xw_dns_wire.h"
#include "xw_config.h"
#include "xw_graphics.h"
#include "xw_recovery.h"
#include "xw_ui.h"
#include "xw_store.h"
#include "xw_security.h"

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

static int failures;
#define CHECK(expr) do { if (!(expr)) { fprintf(stderr, "FAIL %s:%d: %s\n", __FILE__, __LINE__, #expr); ++failures; } } while (0)

static void test_url(void)
{
    XwUrl url;
    char error[128];
    CHECK(xw_url_parse("example.com/path?q=1#top", &url, error, sizeof(error)) == 0);
    CHECK(strcmp(url.scheme, "http") == 0);
    CHECK(strcmp(url.host, "example.com") == 0);
    CHECK(strcmp(url.path, "/path?q=1") == 0);
    CHECK(url.port == 80 && url.tls == 0);
    CHECK(xw_url_parse("http://EXAMPLE.com:8080", &url, error, sizeof(error)) == 0);
    CHECK(strcmp(url.host, "example.com") == 0 && strcmp(url.path, "/") == 0 && url.port == 8080);
    CHECK(xw_url_parse("file:///etc/passwd", &url, error, sizeof(error)) != 0);
    CHECK(xw_url_parse("http://user:pass@example.com", &url, error, sizeof(error)) != 0);
    CHECK(xw_url_parse("http://example.com:99999", &url, error, sizeof(error)) != 0);
    CHECK(xw_url_parse("http://example.com:+80", &url, error, sizeof(error)) != 0);
    CHECK(xw_url_parse("http://exa_mple.com", &url, error, sizeof(error)) != 0);
    CHECK(xw_url_parse("HTTPS://Example.COM", &url, error, sizeof(error)) == 0);
    CHECK(strcmp(url.scheme, "https") == 0 && strcmp(url.host, "example.com") == 0);
    {
        XwUrl base;
        char resolved[1024];
        CHECK(xw_url_parse("http://example.com/docs/page.html?old=1", &base, error, sizeof(error)) == 0);
        CHECK(xw_url_resolve(&base, "../images/cover.png", resolved, sizeof(resolved)) == 0);
        CHECK(strcmp(resolved, "http://example.com/images/cover.png") == 0);
        CHECK(xw_url_resolve(&base, "/next?q=2#frag", resolved, sizeof(resolved)) == 0);
        CHECK(strcmp(resolved, "http://example.com/next?q=2") == 0);
        CHECK(xw_url_resolve(&base, "https://other.test/a", resolved, sizeof(resolved)) == 0);
        CHECK(strcmp(resolved, "https://other.test/a") == 0);
        CHECK(xw_url_resolve(&base, "//cdn.example.net/file", resolved, sizeof(resolved)) == 0);
        CHECK(strcmp(resolved, "http://cdn.example.net/file") == 0);
        CHECK(xw_url_resolve(&base, "javascript:alert(1)", resolved, sizeof(resolved)) != 0);
        CHECK(xw_url_resolve(&base, "?new=2", resolved, sizeof(resolved)) == 0);
        CHECK(strcmp(resolved, "http://example.com/docs/page.html?new=2") == 0);
        CHECK(xw_url_resolve(&base, "#section", resolved, sizeof(resolved)) == 0);
        CHECK(strcmp(resolved, "http://example.com/docs/page.html?old=1") == 0);
        CHECK(xw_url_resolve(&base, "../../../../outside", resolved, sizeof(resolved)) == 0);
        CHECK(strcmp(resolved, "http://example.com/outside") == 0);
    }
    CHECK(xw_url_parse("http://[2001:DB8::1]:8080/", &url, error, sizeof(error)) == 0);
    CHECK(strcmp(url.host, "[2001:db8::1]") == 0 && url.port == 8080);
}

static void test_html(void)
{
    static const char html[] = "<!doctype html><html><head><title>Demo &amp; Test</title><script>bad()</script></head>"
        "<body>Texto direto <h1>Olá &lt;Xbox&gt;</h1><p>Um texto <strong>com ênfase</strong> e fim.</p>"
        "<a href=\"https://example.org/\">Abrir site</a><ul><li>Item um</li><li>Item dois</li></ul>"
        "<div data-check=\"1 > 0\">Conteúdo</div><img src=\"cover.png\" alt=\"Capa > frontal\"><style>.x{}</style></body></html>";
    XwHtmlDocument doc;
    CHECK(xw_html_parse(html, strlen(html), &doc) == 0);
    CHECK(strcmp(doc.title, "Demo & Test") == 0);
    CHECK(doc.block_count >= 6);
    CHECK(doc.blocks[0].type == XW_BLOCK_TEXT);
    CHECK(strcmp(doc.blocks[0].text, "Texto direto") == 0);
    CHECK(strcmp(doc.blocks[1].text, "Olá <Xbox>") == 0);
    CHECK(strcmp(doc.blocks[2].text, "Um texto com ênfase e fim.") == 0);
    CHECK(doc.blocks[3].type == XW_BLOCK_LINK);
    CHECK(strcmp(doc.blocks[3].href, "https://example.org/") == 0);
    CHECK(strcmp(doc.blocks[3].text, "Abrir site") == 0);
    CHECK(doc.blocks[doc.block_count - 1].type == XW_BLOCK_IMAGE);
    CHECK(strcmp(doc.blocks[doc.block_count - 1].text, "Capa > frontal") == 0);
    {
        static const char invalid_reference[] = "<p>A&#0;B</p>";
        CHECK(xw_html_parse(invalid_reference, sizeof(invalid_reference) - 1, &doc) == 0);
        CHECK(doc.block_count == 1);
        CHECK(strchr(doc.blocks[0].text, '\0') == doc.blocks[0].text + strlen(doc.blocks[0].text));
        CHECK(strcmp(doc.blocks[0].text, "A&#0;B") == 0);
    }
}

static void test_http_protocol(void)
{
    static const unsigned char plain[] =
        "HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: 5\r\n\r\nhello";
    static const unsigned char chunked[] =
        "HTTP/1.1 200 OK\r\nTransfer-Encoding: chunked\r\n\r\n"
        "5;foo=bar\r\nhello\r\n6\r\n world\r\n0\r\nX-Test: yes\r\n\r\n";
    static const unsigned char close_delimited[] = "HTTP/1.0 200 OK\r\nContent-Type: text/plain\r\n\r\nhello";
    static const unsigned char redirect[] = "HTTP/1.1 302 Found\r\nLocation: ../next\r\nContent-Length: 0\r\n\r\n";
    static const unsigned char invalid_status[] = "HTTP/9.9 200 OK\r\nContent-Length: 0\r\n\r\n";
    static const unsigned char conflicting_length[] =
        "HTTP/1.1 200 OK\r\nContent-Length: 5\r\nContent-Length: 6\r\n\r\nhello!";
    static const unsigned char overflow_length[] =
        "HTTP/1.1 200 OK\r\nContent-Length: 999999999999999999999999999999999\r\n\r\nx";
    static const unsigned char ambiguous[] =
        "HTTP/1.1 200 OK\r\nTransfer-Encoding: chunked\r\nContent-Length: 5\r\n\r\n0\r\n\r\n";
    static const unsigned char compressed[] =
        "HTTP/1.1 200 OK\r\nContent-Encoding: gzip\r\nContent-Length: 5\r\n\r\nhello";
    static const unsigned char excess_body[] =
        "HTTP/1.1 200 OK\r\nContent-Length: 5\r\n\r\nhelloX";
    static const unsigned char excess_chunk_trailer[] =
        "HTTP/1.1 200 OK\r\nTransfer-Encoding: chunked\r\n\r\n"
        "5\r\nhello\r\n0\r\n\r\nX";
    static const unsigned char bad_chunk[] = "HTTP/1.1 200 OK\r\nTransfer-Encoding: chunked\r\n\r\nFFFFFFFFFFFFFFFFFFFFFFFF\r\n";
    unsigned char body[128];
    size_t body_len = 0;
    int status = 0;
    char error[128];
    XwHttpHeaders headers;
    CHECK(xw_http_decode_response(plain, sizeof(plain) - 1, &headers, body, sizeof(body), &body_len, error, sizeof(error)) == 0);
    CHECK(headers.status_code == 200 && body_len == 5 && memcmp(body, "hello", 5) == 0);
    CHECK(strcmp(headers.content_type, "text/html; charset=utf-8") == 0);
    status = headers.status_code;
    CHECK(status == 200);
    CHECK(xw_http_decode_response(chunked, sizeof(chunked) - 1, &headers, body, sizeof(body), &body_len, error, sizeof(error)) == 0);
    CHECK(headers.chunked == 1 && body_len == 11 && memcmp(body, "hello world", 11) == 0);
    CHECK(xw_http_decode_response(close_delimited, sizeof(close_delimited) - 1, &headers, body, sizeof(body), &body_len, error, sizeof(error)) == 0);
    CHECK(body_len == 5 && memcmp(body, "hello", 5) == 0);
    CHECK(xw_http_decode_response(redirect, sizeof(redirect) - 1, &headers, body, sizeof(body), &body_len, error, sizeof(error)) == 0);
    CHECK(headers.status_code == 302 && strcmp(headers.location, "../next") == 0);
    CHECK(xw_http_decode_response(plain, sizeof(plain) - 3, &headers, body, sizeof(body), &body_len, error, sizeof(error)) != 0);
    CHECK(xw_http_decode_response(chunked, sizeof(chunked) - 8, &headers, body, sizeof(body), &body_len, error, sizeof(error)) != 0);
    CHECK(xw_http_decode_response(invalid_status, sizeof(invalid_status) - 1, &headers, body, sizeof(body), &body_len, error, sizeof(error)) != 0);
    CHECK(xw_http_decode_response(conflicting_length, sizeof(conflicting_length) - 1, &headers, body, sizeof(body), &body_len, error, sizeof(error)) != 0);
    CHECK(xw_http_decode_response(overflow_length, sizeof(overflow_length) - 1, &headers, body, sizeof(body), &body_len, error, sizeof(error)) != 0);
    CHECK(xw_http_decode_response(ambiguous, sizeof(ambiguous) - 1, &headers, body, sizeof(body), &body_len, error, sizeof(error)) != 0);
    CHECK(xw_http_decode_response(compressed, sizeof(compressed) - 1, &headers, body, sizeof(body), &body_len, error, sizeof(error)) != 0);
    CHECK(xw_http_decode_response(bad_chunk, sizeof(bad_chunk) - 1, &headers, body, sizeof(body), &body_len, error, sizeof(error)) != 0);
    CHECK(xw_http_decode_response(excess_body, sizeof(excess_body) - 1, &headers, body, sizeof(body), &body_len, error, sizeof(error)) != 0);
    CHECK(xw_http_decode_response(excess_chunk_trailer, sizeof(excess_chunk_trailer) - 1, &headers, body, sizeof(body), &body_len, error, sizeof(error)) != 0);
}

static void test_dns_wire(void)
{
    unsigned char query[XW_DNS_PACKET_MAX];
    unsigned char response[XW_DNS_PACKET_MAX];
    unsigned char address[4] = {0, 0, 0, 0};
    size_t query_length = 0, response_length;
    CHECK(xw_dns_build_query("Example.COM", 0x1234u, query, sizeof(query), &query_length) == 0);
    CHECK(query_length == 29u);
    CHECK(query[0] == 0x12 && query[1] == 0x34);
    CHECK(query[2] == 0x01 && query[3] == 0x00);
    CHECK(xw_dns_build_query("bad..name", 1u, query, sizeof(query), &query_length) != 0);
    CHECK(xw_dns_build_query("example.com.", 0x1234u, query, sizeof(query), &query_length) == 0);
    CHECK(xw_dns_build_query("-bad.example", 1u, query, sizeof(query), &query_length) != 0);
    CHECK(xw_dns_build_query("example.com", 0x1234u, query, sizeof(query), &query_length) == 0);
    memcpy(response, query, query_length);
    response[2] = 0x81; response[3] = 0x80;
    response[6] = 0; response[7] = 1;
    response_length = query_length;
    response[response_length++] = 0xc0; response[response_length++] = 0x0c;
    response[response_length++] = 0; response[response_length++] = 1;
    response[response_length++] = 0; response[response_length++] = 1;
    response[response_length++] = 0; response[response_length++] = 0;
    response[response_length++] = 0; response[response_length++] = 60;
    response[response_length++] = 0; response[response_length++] = 4;
    response[response_length++] = 93; response[response_length++] = 184;
    response[response_length++] = 216; response[response_length++] = 34;
    CHECK(xw_dns_parse_a_response(response, response_length, 0x1234u, "example.com", address) == 1);
    CHECK(address[0] == 93 && address[1] == 184 && address[2] == 216 && address[3] == 34);
    CHECK(xw_dns_parse_a_response(response, response_length, 0x1234u, "other.example", address) == -1);
    CHECK(xw_dns_parse_a_response(response, response_length, 0x1235u, "example.com", address) == -1);
    CHECK(xw_dns_parse_a_response(response, response_length - 2, 0x1234u, "example.com", address) == -1);

    /* CNAME answer followed by its A record (common CDN/DNS response shape). */
    CHECK(xw_dns_build_query("example.com", 0x1234u, query, sizeof(query), &query_length) == 0);
    memcpy(response, query, query_length);
    response[2] = 0x81; response[3] = 0x80;
    response[6] = 0; response[7] = 2;
    response_length = query_length;
    response[response_length++] = 0xc0; response[response_length++] = 0x0c; /* owner: example.com */
    response[response_length++] = 0; response[response_length++] = 5; /* CNAME */
    response[response_length++] = 0; response[response_length++] = 1; /* IN */
    response[response_length++] = 0; response[response_length++] = 0;
    response[response_length++] = 0; response[response_length++] = 60;
    response[response_length++] = 0; response[response_length++] = 17;
    {
        size_t cname_offset = response_length;
        response[response_length++] = 3; memcpy(response + response_length, "www", 3); response_length += 3;
        response[response_length++] = 7; memcpy(response + response_length, "example", 7); response_length += 7;
        response[response_length++] = 3; memcpy(response + response_length, "net", 3); response_length += 3;
        response[response_length++] = 0;
        response[response_length++] = (unsigned char)(0xc0u | ((cname_offset >> 8) & 0x3fu));
        response[response_length++] = (unsigned char)(cname_offset & 0xffu); /* owner: www.example.net */
    }
    response[response_length++] = 0; response[response_length++] = 1; /* A */
    response[response_length++] = 0; response[response_length++] = 1; /* IN */
    response[response_length++] = 0; response[response_length++] = 0;
    response[response_length++] = 0; response[response_length++] = 60;
    response[response_length++] = 0; response[response_length++] = 4;
    response[response_length++] = 203; response[response_length++] = 0;
    response[response_length++] = 113; response[response_length++] = 9;
    CHECK(xw_dns_parse_a_response(response, response_length, 0x1234u, "example.com", address) == 1);
    CHECK(address[0] == 203 && address[1] == 0 && address[2] == 113 && address[3] == 9);
}


static void test_config(void)
{
    static const char valid[] =
        "# X360 Web Total\nversion=0.6.0\nhomepage = http://example.org/start\n"
        "network_mode=static\nstatic_ip=192.168.1.50\nnetmask=255.255.255.0\n"
        "gateway=192.168.1.1\ndns_primary=9.9.9.9\ndns_secondary=1.1.1.1\ncontroller_port=2\nhistory_entries=24\nunknown=value\n";
    static const char duplicate[] = "homepage=http://a.test/\nhomepage=http://b.test/\n";
    static const char unsafe[] = "homepage=javascript:alert(1)\n";
    static const char bad_ip[] = "static_ip=999.1.1.1\n";
    static const char bad_mode[] = "network_mode=automatic\n";
    XwConfig config;
    char error[128];
    char formatted[XW_CONFIG_MAX_BYTES];
    xw_config_defaults(&config);
    CHECK(strcmp(config.homepage, "http://neverssl.com/") == 0);
    CHECK(strcmp(config.network_mode, "dhcp") == 0);
    CHECK(config.controller_port == 0u);
    CHECK(xw_config_parse(valid, sizeof(valid) - 1u, &config, error, sizeof(error)) == 0);
    CHECK(strcmp(config.homepage, "http://example.org/start") == 0);
    CHECK(strcmp(config.network_mode, "static") == 0);
    CHECK(strcmp(config.static_ip, "192.168.1.50") == 0);
    CHECK(strcmp(config.dns_primary, "9.9.9.9") == 0);
    CHECK(config.controller_port == 2u);
    CHECK(config.history_entries == 24u);
    CHECK(xw_config_format(&config, formatted, sizeof(formatted)) > 0);
    {
        XwConfig reparsed;
        xw_config_defaults(&reparsed);
        CHECK(xw_config_parse(formatted, strlen(formatted), &reparsed, error, sizeof(error)) == 0);
        CHECK(strcmp(reparsed.static_ip, "192.168.1.50") == 0);
        CHECK(reparsed.controller_port == 2u);
        CHECK(reparsed.history_entries == 24u);
    }
    CHECK(xw_config_parse(duplicate, sizeof(duplicate) - 1u, &config, error, sizeof(error)) != 0);
    CHECK(strcmp(config.homepage, "http://example.org/start") == 0); /* failed parse is atomic */
    CHECK(xw_config_parse(unsafe, sizeof(unsafe) - 1u, &config, error, sizeof(error)) != 0);
    CHECK(xw_config_parse(bad_ip, sizeof(bad_ip) - 1u, &config, error, sizeof(error)) != 0);
    CHECK(xw_config_parse(bad_mode, sizeof(bad_mode) - 1u, &config, error, sizeof(error)) != 0);
    CHECK(xw_config_valid_ipv4("10.0.0.1"));
    CHECK(!xw_config_valid_ipv4("10.0.0.256"));
    CHECK(!xw_config_valid_ipv4("10.0..1"));
    CHECK(xw_config_parse(valid, XW_CONFIG_MAX_BYTES + 1u, &config, error, sizeof(error)) != 0);
}

static void test_layout(void)
{
    XwHtmlDocument doc;
    XwLayout layout;
    memset(&doc, 0, sizeof(doc));
    doc.block_count = 1;
    doc.blocks[0].type = XW_BLOCK_PARAGRAPH;
    strcpy(doc.blocks[0].text, "Este é um parágrafo de teste que deve ocupar mais de uma linha na visualização.");
    CHECK(xw_layout_build(&doc, 30, &layout) == 0);
    CHECK(layout.line_count >= 3);
    memset(&doc, 0, sizeof(doc));
    doc.block_count = 1;
    doc.blocks[0].type = XW_BLOCK_PARAGRAPH;
    strcpy(doc.blocks[0].text, "ABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZ");
    CHECK(xw_layout_build(&doc, 20, &layout) == 0);
    {
        char combined[128] = {0};
        for (size_t i = 0; i < layout.line_count; ++i) strcat(combined, layout.lines[i].text);
        CHECK(strstr(combined, "ABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZ") != NULL);
    }
}

static void remove_recovery_files(void)
{
    (void)remove("test_browser.ini");
    (void)remove("test_browser.ini.tmp");
    (void)remove("test_browser.a");
    (void)remove("test_browser.a.tmp");
    (void)remove("test_browser.b");
    (void)remove("test_browser.b.tmp");
    (void)remove("test_browser.factory");
    (void)remove("test_browser.factory.tmp");
}

static void test_recovery(void)
{
    XwConfig config;
    char message[160];
    FILE *f;
    remove_recovery_files();
    xw_config_defaults(&config);
    CHECK(xw_recovery_save("test_browser.ini", "test_browser.a", "test_browser.b",
                           "test_browser.factory", &config, message, sizeof(message)) == 0);
    strcpy(config.static_ip, "192.168.1.77");
    CHECK(xw_recovery_save("test_browser.ini", "test_browser.a", "test_browser.b",
                           "test_browser.factory", &config, message, sizeof(message)) == 0);
    /* A valid primary configuration must not be rolled back because one backup is damaged. */
    f = fopen("test_browser.b", "wb");
    CHECK(f != NULL);
    if (f) { fputs("damaged snapshot", f); fclose(f); }
    xw_config_defaults(&config);
    CHECK(xw_recovery_load("test_browser.ini", "test_browser.a", "test_browser.b",
                           "test_browser.factory", &config, message, sizeof(message)) == 0);
    CHECK(strcmp(config.static_ip, "192.168.1.77") == 0);
    CHECK(strstr(message, "backup divergente") != NULL);
    /* Now corrupt the primary: the rebuilt, verified snapshot restores the latest value. */
    f = fopen("test_browser.ini", "wb");
    CHECK(f != NULL);
    if (f) { fputs("broken partial config", f); fclose(f); }
    xw_config_defaults(&config);
    CHECK(xw_recovery_load("test_browser.ini", "test_browser.a", "test_browser.b",
                           "test_browser.factory", &config, message, sizeof(message)) == 1);
    CHECK(strcmp(config.static_ip, "192.168.1.77") == 0);
    CHECK(strstr(message, "restaurada") != NULL);
    /* If the newest snapshot is damaged too, the previous verified copy remains usable. */
    f = fopen("test_browser.b", "wb");
    CHECK(f != NULL);
    if (f) { fputs("damaged", f); fclose(f); }
    f = fopen("test_browser.ini", "wb");
    CHECK(f != NULL);
    if (f) { fputs("also damaged", f); fclose(f); }
    xw_config_defaults(&config);
    CHECK(xw_recovery_load("test_browser.ini", "test_browser.a", "test_browser.b",
                           "test_browser.factory", &config, message, sizeof(message)) == 1);
    CHECK(strcmp(config.static_ip, "192.168.1.99") == 0 || strcmp(config.static_ip, "192.168.1.77") == 0);
    /* If both rotating snapshots and the primary are lost, restore the factory USB baseline. */
    f = fopen("test_browser.a", "wb");
    CHECK(f != NULL);
    if (f) { fputs("bad slot A", f); fclose(f); }
    f = fopen("test_browser.b", "wb");
    CHECK(f != NULL);
    if (f) { fputs("bad slot B", f); fclose(f); }
    f = fopen("test_browser.ini", "wb");
    CHECK(f != NULL);
    if (f) { fputs("bad primary", f); fclose(f); }
    xw_config_defaults(&config);
    CHECK(xw_recovery_load("test_browser.ini", "test_browser.a", "test_browser.b",
                           "test_browser.factory", &config, message, sizeof(message)) == 1);
    CHECK(strcmp(config.static_ip, "192.168.1.99") == 0);
    CHECK(strstr(message, "fabrica") != NULL);
    remove_recovery_files();
}

static void test_graphics(void)
{
    XwGraphics gfx;
    CHECK(xw_gfx_init_memory(&gfx, 320u, 240u) == 0);
    if (!gfx.pixels) return;
    xw_gfx_clear(&gfx, 0xFF010203u);
    xw_gfx_rect(&gfx, 10, 10, 40, 20, 0xFF112233u);
    xw_gfx_rect(&gfx, -5, -5, 10, 10, 0xFF445566u);
    xw_gfx_line(&gfx, 0, 0, 20, 20, 0xFF778899u);
    xw_gfx_text(&gfx, 5, 40, "X360 WEB TOTAL 0.6", 1u, 0xFFFFFFFFu);
    CHECK(gfx.pixels[10u * 320u + 11u] == 0xFF112233u);
    CHECK(gfx.pixels[0] == 0xFF778899u);
    CHECK(gfx.pixels[15u * 320u + 15u] == 0xFF778899u);
    CHECK(gfx.pixels[100u * 320u + 100u] == 0xFF010203u);
    gfx.scanout = (uint32_t *)calloc(320u * 256u, sizeof(uint32_t));
    CHECK(gfx.scanout != NULL);
    if (gfx.scanout) {
        gfx.pixels[0] = 0xFFAABBCCu;
        xw_gfx_present(&gfx);
        CHECK(gfx.scanout[xw_gfx_tiled_offset(320u, 0u, 0u)] == 0xFFAABBCCu);
        CHECK(xw_gfx_tiled_offset(320u, 319u, 239u) < 320u * 256u);
        free(gfx.scanout);
        gfx.scanout = NULL;
    }
    xw_gfx_shutdown(&gfx);
    CHECK(gfx.pixels == NULL);
}

static void test_security_policy(void)
{
    CHECK(xw_security_https_supported() == 0);
    CHECK(strstr(xw_security_https_status(), "HTTPS bloqueado") != NULL);
}

static void test_store(void)
{
    XwStoreList list, loaded;
    FILE *file;
    const char *path = "test_xw_store.dat";
    xw_store_list_clear(&list);
    remove(path); remove("test_xw_store.dat.bak");
    CHECK(xw_store_load(path, "bookmarks", &loaded) == 0 && loaded.count == 0u);
    CHECK(xw_store_list_add(&list, "http://example.org/", XW_STORE_MAX_BOOKMARKS) == 1);
    CHECK(xw_store_list_add(&list, "http://example.org/", XW_STORE_MAX_BOOKMARKS) == 0);
    CHECK(xw_store_list_add(&list, "https://example.net/page", XW_STORE_MAX_BOOKMARKS) == 1);
    CHECK(xw_store_list_add(&list, "javascript:alert(1)", XW_STORE_MAX_BOOKMARKS) < 0);
    CHECK(xw_store_save(path, "bookmarks", &list) == 0);
    xw_store_list_clear(&loaded);
    CHECK(xw_store_load(path, "bookmarks", &loaded) == 0);
    CHECK(loaded.count == 2u && strcmp(loaded.items[1], "https://example.net/page") == 0);
    CHECK(xw_store_list_add(&list, "http://third.example/", XW_STORE_MAX_BOOKMARKS) == 1);
    CHECK(xw_store_save(path, "bookmarks", &list) == 0);
    file = fopen(path, "wb");
    CHECK(file != NULL);
    if (file) { fputs("corrupted", file); fclose(file); }
    xw_store_list_clear(&loaded);
    CHECK(xw_store_load(path, "bookmarks", &loaded) == 1);
    CHECK(loaded.count == 2u && strcmp(loaded.items[1], "https://example.net/page") == 0);
    CHECK(xw_store_list_remove(&loaded, 0u) == 0 && loaded.count == 1u);
    CHECK(xw_store_list_remove(&loaded, 99u) != 0);
    {
        XwStoreList oversized;
        char url[64];
        xw_store_list_clear(&oversized);
        for (unsigned i = 0; i < XW_STORE_MAX_BOOKMARKS + 1u; ++i) {
            (void)snprintf(url, sizeof(url), "http://bookmark-%u.example/", i);
            CHECK(xw_store_list_add(&oversized, url, XW_STORE_MAX_HISTORY) == 1);
        }
        CHECK(xw_store_save(path, "bookmarks", &oversized) != 0);
    }
    remove(path); remove("test_xw_store.dat.bak"); remove("test_xw_store.dat.tmp"); remove("test_xw_store.dat.restore");
}

static void test_ui_rendering(void)
{
    XwGraphics gfx;
    const char *names[13] = {"Modo de rede", "IP", "Mascara", "Gateway", "DNS 1", "DNS 2", "Homepage", "Controle", "Salvar", "Favorito", "Abrir favoritos", "Diagnostico", "Voltar"};
    const char *values[8] = {"dhcp", "192.168.1.99", "255.255.255.0", "192.168.1.1", "1.1.1.1", "8.8.8.8", "http://example.org/", "1"};
    CHECK(xw_gfx_init_memory(&gfx, 320u, 240u) == 0);
    if (!gfx.pixels) return;
    xw_ui_home(&gfx, "http://example.org/", 0u, 0u, "OFFLINE", "0.0.0.0", "host UI test");
    xw_ui_settings(&gfx, 2u, names, values, "test settings");
    xw_ui_editor(&gfx, "DNS primary", "1.1.1.1", 0u, 0u, 1);
    xw_ui_loading(&gfx, "http://example.org/", "RESOLVENDO DNS");
    xw_ui_error(&gfx, "http://example.org/", "connection refused");
    {
        XwStoreList bookmarks;
        const char *diagnostics[8] = {"USB: OK", "NETWORK: OK", "IP: 192.168.1.2", "HISTORY: 2", "BOOKMARKS: 1", "TLS: disabled", "NAND: untouched", "HTML: limited"};
        xw_store_list_clear(&bookmarks);
        (void)xw_store_list_add(&bookmarks, "http://example.org/", XW_STORE_MAX_BOOKMARKS);
        xw_ui_bookmarks(&gfx, &bookmarks, 0u, "host bookmarks test");
        xw_ui_history(&gfx, &bookmarks, 0u, "host history test");
        xw_ui_diagnostics(&gfx, diagnostics);
    }
    xw_gfx_shutdown(&gfx);
}

int main(void)
{
    test_url(); test_html(); test_http_protocol(); test_dns_wire(); test_config(); test_layout(); test_recovery(); test_store(); test_security_policy(); test_graphics(); test_ui_rendering();
    if (failures) { fprintf(stderr, "%d test(s) failed\n", failures); return 1; }
    puts("All X360 Web Total host tests passed.");
    return 0;
}
