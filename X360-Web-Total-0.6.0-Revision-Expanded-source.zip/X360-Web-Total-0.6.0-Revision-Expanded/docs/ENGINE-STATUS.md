# X360 Web Total 0.6.0 — Revision Expanded 1: estado técnico

## UI gráfica e navegação

- Renderer 2D software em C, com backbuffer ARGB, fonte bitmap 5x7 e primitivas de desenho.
- A apresentação converte a imagem linear para tiles Xenos 32x32 e limpa o cache da CPU. O funcionamento físico precisa ser confirmado nos modos de vídeo reais.
- Home, configurações, editor, carregamento, erro, documento, favoritos, histórico e diagnóstico usam a UI nativa se o renderer iniciar; há fallback de console.
- Página web ainda é convertida para linhas e links. Não existe layout CSS por caixas/estilos.

## Dados locais

- `browser.ini`: dois snapshots com CRC32 e baseline de fábrica, como na 0.6.0 original.
- `history.dat`: histórico persistente limitado a 8/16/24 entradas conforme configuração; atalho B na Home abre uma lista com janela de 12 itens.
- `bookmarks.dat`: favoritos persistentes limitados a 12 entradas.
- Listas de URL têm CRC32, limite de tamanho, validação pelo parser e backup `.bak`.
- Todas as gravações ficam no USB; não há API de NAND/flash.

## Rede e segurança

- HTTP/1.x experimental com TCP raw lwIP, DNS A/IN via UDP e polling.
- Redirecionamentos HTTP limitados a cinco saltos.
- HTTPS/TLS deliberadamente desabilitado e rejeitado sem downgrade.
- CSS completo, JavaScript, imagens, áudio e vídeo não estão implementados.
- Atualização automática no console ainda desativada; hash SHA-256 sozinho não autentica uma origem.

## NAND

- A aplicação não lê nem grava NAND, KV, SMC, flash, bootloader ou imagem de firmware.
- A tela de diagnóstico deve exibir `NAND NÃO VERIFICADA`; boot bem-sucedido só confirma que o fluxo chegou ao aplicativo.

## Verificação

- Host: testes para URL, HTML, HTTP framing, DNS, configuração, layout, recuperação de browser.ini, storage, política HTTPS e primitivas/UI gráficas em memória.
- A suíte host não compila o `main.c` com SDK LibXenon e não valida os registradores/framebuffer no Xbox.
- Build PowerPC, validação ELF, boot XeLL e teste físico em console real continuam pendentes até a execução do workflow e do hardware.
