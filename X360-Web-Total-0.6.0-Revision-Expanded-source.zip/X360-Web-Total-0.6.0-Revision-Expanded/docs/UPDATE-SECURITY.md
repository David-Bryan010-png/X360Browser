# Atualização segura pelo GitHub

O workflow `publish-x360-web-total-0.6.0-revision-expanded.yml` publica o pacote USB, o código-fonte e `latest.json` no Release `v0.6.0-revision-expanded-1`. O manifesto contém URLs fixas de assets e SHA-256 calculado no próprio workflow.

## Estado do atualizador no console

O cliente de rede atual usa HTTP/lwIP e não possui TLS/HTTPS integrado. Portanto, o Xbox não baixa nem instala atualizações automaticamente nesta versão. Isso é intencional: SHA-256 recebido por um canal HTTP não autentica a origem, e um atacante poderia substituir tanto o pacote quanto o hash.

Para habilitar atualização automática de forma aceitável, uma versão futura precisa: (1) TLS com validação de certificado/hostname; (2) buscar `latest.json` exclusivamente por HTTPS; (3) validar formato, versão e tamanho; (4) baixar para `X360WebTotal/update-staging/`; (5) validar SHA-256; (6) preservar o ELF atual e os dados do usuário; (7) trocar o payload somente após reinicialização pelo launcher e manter rollback. Nenhuma etapa pode escrever na NAND.

A versão 0.6.0 prepara a publicação no GitHub, mas não afirma que o atualizador automático já funciona no Xbox.
