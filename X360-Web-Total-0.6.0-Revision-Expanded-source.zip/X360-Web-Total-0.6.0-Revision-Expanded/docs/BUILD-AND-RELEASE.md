# Build e release — 0.6.0 revision-expanded-1

O workflow `build-x360-web-total.yml` executa os testes host e, em job separado, tenta compilar o ELF PowerPC com uma imagem LibXenon fixada por digest. O pacote USB só é gerado após a validação do ELF e do hash fixado do XellLaunch2.

O workflow `publish-x360-web-total-0.6.0-revision-expanded.yml` usa a mesma sequência de gates e publica um pré-lançamento com fonte, pacote USB, `latest.json` e `SHA256SUMS.txt`. A tag esperada é `v0.6.0-revision-expanded-1`.

O manifesto `latest.json` serve para distribuição e identificação de artefatos. Ele não habilita o atualizador no console. SHA-256 detecta alterações, mas não autentica sozinho a origem; uma futura atualização automática precisará de assinatura digital verificada por chave pública incorporada no executável e transporte HTTPS autenticado.

O pipeline não faz qualquer operação de NAND. O build host não prova compatibilidade com LibXenon; a etapa Docker é a autoridade para verificar o cross-build, e apenas teste em hardware confirma boot, vídeo, controle, USB e rede.
