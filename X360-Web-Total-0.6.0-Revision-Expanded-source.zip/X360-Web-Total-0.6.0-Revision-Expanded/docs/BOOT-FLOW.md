# Fluxo de inicialização — X360 Web Total 0.6.0

Dashboard homebrew (por exemplo Aurora)
  → XellLaunch2.xex
  → XeLL Reloaded
  → busca e carrega xenon.elf do USB FAT32
  → inicializa Xenos/LibXenon, USB, armazenamento e lwIP
  → abre interface gráfica nativa e browser

`XellLaunch2.xex` é somente o launcher. `xenon.elf` é o executável do X360 Web Total.

O app salva `browser.ini` e pontos de recuperação em `X360WebTotal/` no USB. Não acessa nem grava a NAND.
