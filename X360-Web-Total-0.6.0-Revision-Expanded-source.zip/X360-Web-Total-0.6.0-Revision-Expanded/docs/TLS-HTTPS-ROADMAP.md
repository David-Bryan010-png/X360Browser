# HTTPS/TLS roadmap — Revision Expanded 1

## Current behavior

HTTPS is intentionally disabled. `xw_http_start()` parses `https://`, then asks `xw_security_https_supported()`. This build returns false and the request fails with a clear error. It never retries the same URL as plain HTTP.

## Candidate TLS library

Mbed TLS 4.1 is the preferred candidate for the next integration. The upstream project lists 4.1 as a maintained LTS branch with security/bug-fix support through at least March 2029. Do not vendor a random mirror or track an unpinned moving branch in a release build. Pin a reviewed release/tag/commit and record the archive SHA-256.

Upstream references:
- https://github.com/Mbed-TLS/mbedtls/releases
- https://github.com/Mbed-TLS/mbedtls/blob/development/BRANCHES.md

## Mandatory prerequisites before enabling the feature flag

1. A TLS engine linked into the PowerPC ELF and cross-build reproduced in CI.
2. A non-blocking TLS BIO adapter integrated with the existing lwIP raw-TCP polling model. It must handle WANT_READ/WANT_WRITE, partial writes, close-notify and abort/cancel paths.
3. A cryptographically secure random source. Xenon architecture research describes an on-die random unit, but this source tree does not expose a verified LibXenon API for it. Do not invent register addresses or seed TLS from timers, MAC addresses, controller input, or ordinary `rand()`.
4. A reliable UTC clock for certificate validity. If a trustworthy clock cannot be established, certificate date checks must fail closed.
5. A CA trust bundle with a documented update path on USB, plus hostname/SNI and full chain verification.
6. TLS 1.2 minimum; TLS 1.3 can be enabled only after compatibility and memory tests.
7. Test matrix for valid/expired/wrong-host/untrusted certificates, redirects, fragmented records, disconnects, cancellation, memory pressure, and at least several real HTTPS hosts.

## Why this is not enabled yet

The current HTTP client directly uses lwIP raw TCP callbacks. Mbed TLS cannot safely be dropped in as a compile-time link alone; it needs a stateful non-blocking transport bridge. The RNG/time/CA requirements are also protocol security requirements, not optional polish. A green host test cannot prove that the target hardware has a suitable entropy source or clock.

## Future auto-update safety

The release manifest's SHA-256 checks accidental corruption but is not an authenticity signature by itself. Do not let the console automatically replace its ELF based only on a manifest fetched over HTTP. Before auto-update, add HTTPS with peer verification, a signed manifest verified against a public key embedded read-only in the app, staged installation on USB, and rollback. NAND must remain untouched.
