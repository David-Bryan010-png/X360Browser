#!/usr/bin/env python3
"""Unit tests for the ELF and FAT32 package validators."""
import hashlib
import io
import struct
import tempfile
import unittest
import warnings
from pathlib import Path
from unittest import mock

import package_usb


def make_powerpc_elf() -> bytes:
    header = bytearray(84)
    header[:7] = b"\x7fELF\x01\x02\x01"
    struct.pack_into(">HHI", header, 16, 2, 20, 1)
    struct.pack_into(">I", header, 24, 0x80000000)
    struct.pack_into(">II", header, 28, 52, 0)
    struct.pack_into(">HHHHHH", header, 40, 52, 32, 1, 0, 0, 0)
    struct.pack_into(">IIIIIIII", header, 52, 1, 0, 0x80000000, 0x80000000, 32, 32, 5, 4)
    return bytes(header)


class PackageValidatorTests(unittest.TestCase):
    def test_valid_powerpc_elf(self):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "xenon.elf"
            path.write_bytes(make_powerpc_elf())
            package_usb.validate_elf(path)
            package_usb.validate_elf_bytes(path.read_bytes())

    def test_rejects_wrong_machine(self):
        data = bytearray(make_powerpc_elf())
        struct.pack_into(">H", data, 18, 3)
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "bad.elf"
            path.write_bytes(data)
            with self.assertRaises(ValueError):
                package_usb.validate_elf(path)

    def test_rejects_truncated_elf(self):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "short.elf"
            path.write_bytes(b"\x7fELF")
            with self.assertRaises(ValueError):
                package_usb.validate_elf(path)

    def test_rejects_unsafe_package_paths(self):
        for value in (
            "../xenon.elf", "/root/xenon.elf", "C:/xenon.elf",
            r"..\xenon.elf", r"C:\xenon.elf", "a//b", "a/./b", "",
            "a/../b", "trailing./file", "bad:name", "a\x00b",
        ):
            with self.subTest(value=value), self.assertRaises(ValueError):
                package_usb.safe_zip_name(value)

    def test_rejects_duplicate_zip_entries(self):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "duplicate.zip"
            with warnings.catch_warnings():
                warnings.simplefilter("ignore", UserWarning)
                with package_usb.zipfile.ZipFile(path, "w") as archive:
                    archive.writestr("xenon.elf", make_powerpc_elf())
                    archive.writestr("xenon.elf", make_powerpc_elf())
            with self.assertRaisesRegex(ValueError, "duplicate"):
                package_usb.verify_package(path)

    def test_rejects_case_collisions(self):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "case-collision.zip"
            with package_usb.zipfile.ZipFile(path, "w") as archive:
                archive.writestr("Xenon.elf", b"one")
                archive.writestr("xenon.elf", b"two")
            with self.assertRaisesRegex(ValueError, "duplicate or case-colliding"):
                package_usb.verify_package(path)

    def test_rejects_invalid_elf_section_table(self):
        data = bytearray(make_powerpc_elf())
        struct.pack_into(">I", data, 32, 0xFFFFFFF0)
        struct.pack_into(">HH", data, 46, 40, 1)
        with self.assertRaisesRegex(ValueError, "section"):
            package_usb.validate_elf_bytes(bytes(data))

    def test_rejects_elf_without_executable_entry_segment(self):
        data = bytearray(make_powerpc_elf())
        struct.pack_into(">I", data, 52 + 24, 4)  # PT_LOAD without PF_X
        with self.assertRaisesRegex(ValueError, "entry point"):
            package_usb.validate_elf_bytes(bytes(data))

    def test_rejects_elf_segment_outside_file(self):
        data = bytearray(make_powerpc_elf())
        struct.pack_into(">I", data, 52 + 16, 0x1000)  # p_filesz
        with self.assertRaisesRegex(ValueError, "PT_LOAD"):
            package_usb.validate_elf_bytes(bytes(data))

    def test_builds_and_verifies_complete_usb_package(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            project = root / "project"
            (project / "docs").mkdir(parents=True)
            (project / "usb/X360WebTotal/config").mkdir(parents=True)
            (project / "README-INSTALL-PT-BR.txt").write_text("install", encoding="utf-8")
            (project / "REVISION.txt").write_text(package_usb.REVISION + "\n", encoding="ascii")
            (project / "docs/BOOT-FLOW.md").write_text("boot", encoding="utf-8")
            (project / "usb/X360WebTotal/data").mkdir(parents=True)
            (project / "usb/X360WebTotal/ui").mkdir(parents=True)
            (project / "usb/X360WebTotal/ui/home.html").write_text("<!doctype html>" + (" " * 6000), encoding="utf-8")
            (project / "usb/X360WebTotal/config/browser.ini").write_text(
                "homepage=http://neverssl.com/\n", encoding="utf-8"
            )
            elf = root / "xenon.elf"
            elf.write_bytes(make_powerpc_elf())
            xell = root / "XellLaunch2.xex"
            xell.write_bytes(b"X" * 2048)
            output = root / "X360-Web-Total-USB.zip"
            digest = hashlib.sha256(xell.read_bytes()).hexdigest()
            argv = [
                "package_usb.py", "--elf", str(elf), "--xell", str(xell),
                "--project", str(project), "--output", str(output),
            ]
            with mock.patch.object(package_usb, "XELLLAUNCH2_SHA256", digest), \
                 mock.patch("sys.argv", argv), mock.patch("sys.stdout", new=io.StringIO()):
                self.assertEqual(package_usb.main(), 0)
                package_usb.verify_package(output)
            with package_usb.zipfile.ZipFile(output) as archive:
                self.assertEqual(set(package_usb.REQUIRED_FILES) - set(archive.namelist()), set())
                self.assertIn("xenon.elf", archive.namelist())
                self.assertIn("XellLaunch2.xex", archive.namelist())


if __name__ == "__main__":
    unittest.main(verbosity=2)
