#!/usr/bin/env python3
"""Create and verify the X360 Web Total 0.6.0 FAT32 boot package."""
from __future__ import annotations

import argparse
import hashlib
import shutil
import struct
import tempfile
import zipfile
from pathlib import Path, PurePosixPath

VERSION = "0.6.0"
REVISION = "revision-expanded-1"
XELLLAUNCH2_VERSION = "2.2.0"
XELLLAUNCH2_SHA256 = "49dd8666b83a7c7b37597affc46513fe2cb9ab5cb2fe1fb71da1b13175276bb0"
REQUIRED_FILES = (
    "xenon.elf",
    "XellLaunch2.xex",
    "LEIA-ME.txt",
    "FLUXO-DE-INICIALIZACAO.txt",
    "VERSION.txt",
    "REVISION.txt",
    "PACKAGE-MANIFEST.txt",
    "SHA256SUMS.txt",
    "X360WebTotal/config/browser.ini",
    "X360WebTotal/data/.keep",
    "X360WebTotal/ui/home.html",
    "X360WebTotal/cache/.keep",
    "X360WebTotal/logs/.keep",
)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def validate_elf(path: Path) -> None:
    size = path.stat().st_size
    if size < 52 or size > 64 * 1024 * 1024:
        raise ValueError(f"ELF size is outside the accepted range: {size} bytes")
    validate_elf_bytes(path.read_bytes())


def validate_xell(path: Path) -> None:
    if path.stat().st_size < 1024:
        raise ValueError("XellLaunch2.xex is unexpectedly small")
    actual = sha256(path)
    if actual != XELLLAUNCH2_SHA256:
        raise ValueError(f"XellLaunch2 {XELLLAUNCH2_VERSION} SHA-256 mismatch: {actual}")


def safe_zip_name(name: str) -> PurePosixPath:
    if not name or "\x00" in name or "\\" in name or name.startswith("/"):
        raise ValueError(f"unsafe path in package: {name!r}")
    raw_parts = name.split("/")
    if any(part in ("", ".", "..") for part in raw_parts):
        raise ValueError(f"unsafe path component in package: {name!r}")
    if any(any(char in part for char in '<>:"|?*') for part in raw_parts):
        raise ValueError(f"non-portable path in package: {name!r}")
    if any(part.endswith((".", " ")) for part in raw_parts):
        raise ValueError(f"non-portable path ending in package: {name!r}")
    if len(name) > 240:
        raise ValueError(f"package path exceeds portability limit: {name}")
    return PurePosixPath(name)


def verify_package(path: Path) -> None:
    if path.stat().st_size > 64 * 1024 * 1024:
        raise ValueError("USB package exceeds the 64 MiB safety limit")
    with zipfile.ZipFile(path) as archive:
        entries = archive.infolist()
        names_in_order = [entry.filename for entry in entries]
        folded_names = set()
        for entry in entries:
            safe_zip_name(entry.filename)
            folded = entry.filename.casefold()
            if folded in folded_names:
                raise ValueError(f"duplicate or case-colliding package path: {entry.filename}")
            folded_names.add(folded)
            mode = (entry.external_attr >> 16) & 0o170000
            if mode == 0o120000:
                raise ValueError(f"symbolic link is not allowed in USB package: {entry.filename}")
            if entry.is_dir():
                raise ValueError(f"unexpected directory entry in USB package: {entry.filename}")
            if entry.file_size > 16 * 1024 * 1024:
                raise ValueError(f"package file exceeds the 16 MiB safety limit: {entry.filename}")
        bad = archive.testzip()
        if bad is not None:
            raise ValueError(f"ZIP CRC check failed at {bad}")
        names = set(names_in_order)
        missing = sorted(set(REQUIRED_FILES) - names)
        if missing:
            raise ValueError("USB package is missing: " + ", ".join(missing))
        sums = archive.read("SHA256SUMS.txt").decode("ascii").splitlines()
        checked = set()
        for line in sums:
            digest, filename = line.split("  ", 1)
            safe_zip_name(filename)
            if filename not in names or filename in checked:
                raise ValueError(f"invalid SHA256SUMS entry: {filename}")
            actual = hashlib.sha256(archive.read(filename)).hexdigest()
            if actual.lower() != digest.lower():
                raise ValueError(f"package SHA-256 mismatch: {filename}")
            checked.add(filename)
        if names - {"SHA256SUMS.txt"} != checked:
            raise ValueError("SHA256SUMS.txt does not cover every package file")
        validate_elf_bytes(archive.read("xenon.elf"))
        home_html = archive.read("X360WebTotal/ui/home.html")
        if b"<!doctype html>" not in home_html.lower() or len(home_html) < 5000:
            raise ValueError("X360WebTotal/ui/home.html is missing or too small")
        xell_digest = hashlib.sha256(archive.read("XellLaunch2.xex")).hexdigest()
        if xell_digest != XELLLAUNCH2_SHA256:
            raise ValueError("packaged XellLaunch2 hash does not match the official pinned binary")


def validate_elf_bytes(data: bytes) -> None:
    if len(data) < 52 or len(data) > 64 * 1024 * 1024 or data[:7] != b"\x7fELF\x01\x02\x01":
        raise ValueError("packaged xenon.elf header or size is invalid")
    elf_type, machine = struct.unpack(">HH", data[16:20])
    version = struct.unpack(">I", data[20:24])[0]
    entry = struct.unpack(">I", data[24:28])[0]
    phoff, shoff = struct.unpack(">II", data[28:36])
    ehsize, phentsize, phnum, shentsize, shnum, _ = struct.unpack(">HHHHHH", data[40:52])
    if elf_type not in (2, 3) or machine != 20 or version != 1 or entry == 0:
        raise ValueError("packaged ELF is not an executable PowerPC ELF32 image")
    if ehsize != 52 or phnum == 0 or phentsize < 32 or phoff < ehsize or phoff + phentsize * phnum > len(data):
        raise ValueError("packaged ELF program headers are missing or truncated")
    if shoff != 0 and (shentsize < 40 or shnum == 0 or shoff + shentsize * shnum > len(data)):
        raise ValueError("packaged ELF section headers are missing or truncated")

    has_loadable_segment = False
    entry_is_executable = False
    for index in range(phnum):
        offset = phoff + index * phentsize
        p_type, p_offset, p_vaddr, _p_paddr, p_filesz, p_memsz, p_flags, _p_align = struct.unpack(
            ">IIIIIIII", data[offset:offset + 32]
        )
        if p_type != 1:  # PT_LOAD
            continue
        has_loadable_segment = True
        if p_filesz > p_memsz or p_offset + p_filesz > len(data) or p_memsz == 0:
            raise ValueError("ELF PT_LOAD segment has invalid file or memory bounds")
        if p_vaddr + p_memsz > 0x100000000:
            raise ValueError("ELF PT_LOAD segment address overflows 32-bit address space")
        if (p_flags & 1) and p_vaddr <= entry < p_vaddr + p_memsz:
            entry_is_executable = True
    if not has_loadable_segment or not entry_is_executable:
        raise ValueError("ELF has no loadable segment containing its executable entry point")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--elf", type=Path, required=True, help="compiled LibXenon xenon.elf")
    parser.add_argument("--xell", type=Path, required=True, help=f"official XellLaunch2 {XELLLAUNCH2_VERSION} XEX")
    parser.add_argument("--project", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--output", type=Path, default=Path("X360-Web-Total-USB.zip"))
    args = parser.parse_args()

    if not args.elf.is_file() or not args.xell.is_file():
        raise FileNotFoundError("both --elf and --xell must point to existing files")
    validate_elf(args.elf)
    validate_xell(args.xell)
    project = args.project.resolve()
    for relative in ("README-INSTALL-PT-BR.txt", "docs/BOOT-FLOW.md", "usb/X360WebTotal/config/browser.ini", "usb/X360WebTotal/ui/home.html"):
        if not (project / relative).is_file():
            raise FileNotFoundError(project / relative)

    output = args.output.resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="x360-web-total-") as temp_dir:
        stage = Path(temp_dir) / "usb-root"
        data_dir = stage / "X360WebTotal"
        for name in ("config", "data", "cache", "logs"):
            (data_dir / name).mkdir(parents=True, exist_ok=True)
        shutil.copy2(args.elf, stage / "xenon.elf")
        shutil.copy2(args.xell, stage / "XellLaunch2.xex")
        shutil.copy2(project / "usb/X360WebTotal/config/browser.ini", data_dir / "config/browser.ini")
        (data_dir / "ui").mkdir(parents=True, exist_ok=True)
        shutil.copy2(project / "usb/X360WebTotal/ui/home.html", data_dir / "ui/home.html")
        shutil.copy2(project / "README-INSTALL-PT-BR.txt", stage / "LEIA-ME.txt")
        shutil.copy2(project / "docs/BOOT-FLOW.md", stage / "FLUXO-DE-INICIALIZACAO.txt")
        for folder in ("data", "cache", "logs"):
            (data_dir / folder / ".keep").write_text("reserved\n", encoding="ascii")
        (stage / "VERSION.txt").write_text(VERSION + "\n", encoding="ascii")
        (stage / "REVISION.txt").write_text(REVISION + "\n", encoding="ascii")
        (stage / "PACKAGE-MANIFEST.txt").write_text(
            "X360 WEB TOTAL - FAT32 BOOT PACKAGE\n"
            f"Version: {VERSION}\n"
            f"Revision: {REVISION}\n"
            "Boot payload: xenon.elf (ELF32, big-endian PowerPC / LibXenon)\n"
            f"Launcher: XellLaunch2.xex (version {XELLLAUNCH2_VERSION}, pinned SHA-256)\n"
            "Launch path: XellLaunch2 XEX -> XeLL Reloaded -> USB FAT -> xenon.elf\n"
            "This is a XeLL-loadable ELF system payload, not a dashboard-native browser XEX.\n"
            "The browser UI is drawn by native C graphics code through the LibXenon/Xenos framebuffer.\n"
            "USB recovery snapshots protect browser.ini; history/bookmarks use CRC32 and .bak rotation.\n"
            "HTTPS/TLS is disabled and fails closed; there is no automatic HTTP downgrade.\n"
            "The application never reads or writes NAND and does not perform NAND diagnostics.\n",
            encoding="utf-8",
        )
        sums = []
        for file in sorted(p for p in stage.rglob("*") if p.is_file()):
            rel = file.relative_to(stage).as_posix()
            safe_zip_name(rel)
            sums.append(f"{sha256(file)}  {rel}")
        (stage / "SHA256SUMS.txt").write_text("\n".join(sums) + "\n", encoding="ascii")
        with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
            for file in sorted(p for p in stage.rglob("*") if p.is_file()):
                relative = file.relative_to(stage).as_posix()
                info = zipfile.ZipInfo(relative, date_time=(2026, 1, 1, 0, 0, 0))
                info.compress_type = zipfile.ZIP_DEFLATED
                info.external_attr = 0o100644 << 16
                archive.writestr(info, file.read_bytes(), compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
    verify_package(output)
    print(f"Created and verified {output} ({output.stat().st_size} bytes)")
    print(f"XellLaunch2 {XELLLAUNCH2_VERSION} SHA-256 verified: {sha256(args.xell)}")
    print(f"ELF SHA-256: {sha256(args.elf)}")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (FileNotFoundError, ValueError, OSError, zipfile.BadZipFile, UnicodeError) as exc:
        raise SystemExit(f"package error: {exc}")
