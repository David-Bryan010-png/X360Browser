#pragma once

#include <cstdint>
#include <functional>
#include <string>

namespace x360browser {

enum class PageLoadStatus {
    Queued,
    Loading,
    Complete,
    Failed,
    Cancelled
};

struct PageProgress {
    PageLoadStatus status = PageLoadStatus::Queued;
    unsigned int percent = 0; // 0..100 when known; 0 means unknown for streaming loads.
    std::string message;
};

struct PageResult {
    PageLoadStatus status = PageLoadStatus::Failed;
    std::string requested_url;
    std::string final_url;
    std::string title;
    std::string error;
};

struct RenderedSurface {
    const std::uint32_t* pixels = nullptr; // RGBA8888; owned by the engine.
    unsigned int width = 0;
    unsigned int height = 0;
    unsigned int stride_bytes = 0;
};

struct EngineCapabilities {
    bool html = false;
    bool css = false;
    bool javascript = false;
    bool images = false;
    bool https = false;
    bool downloads = false;
};

// Integration boundary between the portable browser UI and a page-rendering engine.
// A concrete adapter is intentionally not provided in 0.3.0: NetSurf/TLS must be
// ported and tested before this interface can be reported as working.
class PageEngine {
public:
    using ProgressHandler = std::function<void(const PageProgress&)>;
    using CompletionHandler = std::function<void(const PageResult&)>;

    virtual ~PageEngine() = default;
    virtual bool initialize(std::string* error = nullptr) = 0;
    virtual const char* name() const noexcept = 0;
    virtual EngineCapabilities capabilities() const noexcept = 0;
    virtual bool open(const std::string& url, ProgressHandler progress, CompletionHandler complete) = 0;
    virtual void update() = 0; // Pump engine work from the application's main loop.
    virtual void cancel() = 0;
    virtual void scroll(int delta_y) = 0;
    virtual void pointer_move(int x, int y) = 0;
    virtual void pointer_activate(int x, int y) = 0;
    virtual RenderedSurface surface() const noexcept = 0;
    virtual void shutdown() noexcept = 0;
};

} // namespace x360browser
