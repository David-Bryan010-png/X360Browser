# X360 Browser 0.3.0

**Objetivo:** construir um navegador para Xbox 360 com interface nativa e motor web real. Esta versão avança o projeto ao incluir uma primeira camada de shell Xbox compilável com o xSDK e um fluxo automatizado de build. Ela **ainda não carrega sites**: HTML/CSS/JavaScript, rede HTTP/HTTPS, TLS/certificados e integração do NetSurf continuam pendentes.

## Downloads e estado

- Código-fonte: este pacote.
- `X360Browser.xex`: será produzido pelo build do shell Xbox. Não é fornecido pronto neste ZIP porque o xSDK/toolchain não está instalado neste ambiente e o binário não foi testado no console.
- Core de navegação: compilável no computador/Termux com CMake e C++17.
- Shell Xbox: compilável com o xSDK conforme `docs/XBOX_BUILD.md` e `.github/workflows/build-xbox-shell.yml`.

## O que há nesta versão

- Núcleo C++ com normalização e validação de URLs HTTP/HTTPS, pesquisa Google com UTF-8, histórico, voltar/avançar, favoritos, temas, página inicial e persistência versionada.
- Testes automatizados para o núcleo portátil.
- Shell nativo experimental para Xbox: saída 720p, texto, leitura de D-pad/A/Back, registro de diagnósticos e avisos honestos quando uma ação web ainda não pode ser executada.
- Build em nuvem com GitHub Actions para gerar um `.xex` do shell sem depender de compilar todo o toolchain no celular.
- Instruções para Termux com Debian via `proot-distro`.

## Testar o núcleo no Termux

No Termux:

```bash
pkg update
pkg install clang cmake make git
```

Extraia o ZIP e, dentro da pasta `X360Browser`, execute:

```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build -j2
ctest --test-dir build --output-on-failure
./build/x360browser_demo
```

Isso testa o núcleo e a demonstração de terminal, **não** o navegador no Xbox.

## Gerar o shell `.xex`

Leia [`docs/XBOX_BUILD.md`](docs/XBOX_BUILD.md). A opção mais amigável para quem só tem celular é subir este projeto para um repositório GitHub e executar o workflow `Build Xbox shell`; o artefato final aparece na aba **Actions**. O workflow foi incluído, mas não foi executado por este ambiente.

O shell exige xSDK. O projeto de referência diz explicitamente que seus `.xex` são destinados a um ambiente Xbox que execute homebrew não assinado, normalmente RGH/JTAG; compatibilidade com um exploit USB depende do método e do loader instalados. Consulte também [`docs/TERMUX_BUILD.md`](docs/TERMUX_BUILD.md).

## Estrutura

```text
X360Browser/
├── include/x360browser/          # núcleo e contrato do motor web
├── src/                          # URLs, sessão, histórico, favoritos e perfil
├── tests/                        # testes do núcleo
├── platform/xbox360/xsdk/        # shell nativo C para gerar X360Browser.xex
├── engine/netsurf/               # plano para integrar motor web
├── tools/build_xbox_shell.sh     # build xSDK em host Debian
├── .github/workflows/            # build em nuvem
└── docs/                         # estado, arquitetura e instruções
```

## Critério para a versão de navegador de verdade

A versão só será um navegador quando o `.xex` abrir no console e carregar/renderizar uma página real via HTTPS, com HTML/CSS/imagens, navegação por links, tratamento de erros e limites de memória testados no hardware. A versão 0.3.0 é um marco de portabilidade, não esse marco final.
