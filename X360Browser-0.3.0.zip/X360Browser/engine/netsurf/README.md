# Integração do motor web — pendente na 0.3.0

O contrato `PageEngine` existe, mas nenhum adaptador NetSurf está compilado. O shell Xbox é uma prova do ciclo de vida nativo e não envia requisições web.

Próximos trabalhos:

1. Fixar uma versão de NetSurf e todas as dependências/licenças.
2. Portar o backend de fetch/rede para o ambiente Xbox e verificar suporte a DNS/TCP.
3. Selecionar e portar uma implementação TLS atual, cadeia de certificados e validação de hostname.
4. Integrar HTML, CSS, imagens e Duktape/DOM ao loop gráfico.
5. Expor a superfície rasterizada ao shell e adicionar rolagem, seleção de links e teclado virtual.
6. Testar HTTP e HTTPS reais no hardware, páginas simples e falhas de certificado/timeout.

O uso de um motor leve não garante compatibilidade com sites modernos ou aplicações complexas.
