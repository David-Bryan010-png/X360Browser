#!/usr/bin/env bash
set -euo pipefail

# Build X360Browser's native platform-test shell with xSDK on a Debian-like host.
# This produces a shell XEX only; it does NOT integrate the HTML/web engine.
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
XSDK_DIR="${XSDK_DIR:-$HOME/xsdk}"
GLSLANG_DIR="${GLSLANG_DIR:-$HOME/glslang-xenon}"
PREFIX="${PREFIX:-$HOME/xsdk-gcc}"
WORK="${WORK:-$HOME/xsdk-gcc-work}"
JOBS="${JOBS:-2}"

for cmd in git cmake ninja make python3; do
  command -v "$cmd" >/dev/null 2>&1 || { echo "Falta o comando: $cmd" >&2; exit 2; }
done

if [[ ! -d "$XSDK_DIR/.git" ]]; then
  git clone https://github.com/xenosworks/xsdk.git "$XSDK_DIR"
fi
if [[ ! -d "$GLSLANG_DIR/.git" ]]; then
  git clone --depth 1 --branch xenon https://github.com/xenosworks/glslang-xenon.git "$GLSLANG_DIR"
fi

if [[ ! -x "$PREFIX/bin/powerpc-xsdk-elf-gcc" ]]; then
  echo "== Building xSDK PowerPC toolchain (can take a long time) =="
  (cd "$XSDK_DIR" && PREFIX="$PREFIX" WORK="$WORK" JOBS="$JOBS" tools/toolchain/build.sh)
fi

if [[ ! -x "$GLSLANG_DIR/build/StandAlone/glslang" ]]; then
  echo "== Fetching/building glslang-xenon =="
  (cd "$GLSLANG_DIR" && python3 update_glslang_sources.py)
  cmake -S "$GLSLANG_DIR" -B "$GLSLANG_DIR/build" -G Ninja \
    -DCMAKE_BUILD_TYPE=Release -DENABLE_OPT=ON -DSPIRV_SKIP_EXECUTABLES=ON -DGLSLANG_TESTS=OFF
  cmake --build "$GLSLANG_DIR/build" --parallel "$JOBS"
fi
cp "$GLSLANG_DIR/build/StandAlone/glslang" "$PREFIX/bin/glslang"

if [[ ! -f "$XSDK_DIR/build/libxsdk.a" ]]; then
  echo "== Building xSDK libraries =="
  make -C "$XSDK_DIR" -j"$JOBS" TOOLCHAIN="$PREFIX/bin/powerpc-xsdk-elf-"
fi

echo "== Building X360 Browser Xbox shell =="
cmake -S "$ROOT_DIR/platform/xbox360/xsdk" -B "$ROOT_DIR/build-xbox360" -G Ninja \
  -DCMAKE_TOOLCHAIN_FILE="$XSDK_DIR/cmake/xsdk.cmake" \
  -DXSDK_TOOLCHAIN="$PREFIX" \
  -DCMAKE_BUILD_TYPE=Release
cmake --build "$ROOT_DIR/build-xbox360" --parallel "$JOBS"

XEX="$ROOT_DIR/build-xbox360/X360Browser.xex"
if [[ ! -s "$XEX" ]]; then
  echo "Build terminou, mas o XEX não foi encontrado em: $XEX" >&2
  exit 3
fi

echo "Build concluído: $XEX"
echo "ATENÇÃO: shell nativo apenas; não carrega sites. Teste real requer console e método homebrew compatível."
