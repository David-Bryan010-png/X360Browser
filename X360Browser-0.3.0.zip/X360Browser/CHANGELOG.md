# Changelog

## 0.3.0 — Primeira camada nativa para Xbox

- Adicionado um shell nativo experimental para Xbox 360 baseado no xSDK: tela 720p, texto, leitura do controle e saída pelo botão Back.
- Adicionado alvo CMake separado para gerar `X360Browser.xex` com o xSDK.
- Adicionado fluxo GitHub Actions para compilar o shell em nuvem a partir de um celular.
- Adicionado script de compilação para ambientes Debian/Termux e guia específico para Android.
- Criada uma separação explícita entre o shell compilável e o motor web ainda não integrado.
- Mantidos os testes do núcleo portátil, com testes novos para entrada HTTP e codificação de pesquisa.

**Limitação:** o shell Xbox não é ainda um navegador web. Ele permite testar execução nativa, gráficos básicos e controle; não carrega sites nesta versão. Nenhum `.xex` foi validado em hardware real neste ambiente.

## 0.2.0 — Núcleo ampliado

- Reforçada a normalização de URLs e validação de host/porta.
- Adicionados favoritos, configurações, histórico e perfis persistentes.
- Adicionadas APIs `BrowserSession` e `PageEngine` para separar lógica e motor web.
- Incluída demonstração de terminal e testes automatizados do núcleo.

## 0.1.0 — Núcleo inicial

- Pesquisa Google, normalização básica de URL e histórico em memória.
