# Adaptador Xbox 360 — pendente

O adaptador específico do console deverá implementar:

- entrada e encerramento do título `.xex`;
- vídeo/2D e apresentação da superfície RGBA do motor web;
- leitura do gamepad, foco de controles e teclado virtual;
- armazenamento em USB/HD;
- DNS, sockets, timeouts e integração de TLS/certificados;
- integração do loop principal com `PageEngine::update()`.

Nenhuma chamada do SDK de Xbox 360 está implementada nesta pasta. A escolha da toolchain e do método de execução precisa ser verificada antes de declarar compatibilidade.
