#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>

#include "xsdk/gpu.h"
#include "xsdk/kernel.h"
#include "xsdk/log.h"
#include "xsdk/present.h"
#include "xsdk/splash.h"
#include "xsdk/text.h"

enum {
    SPLASH_MS = 1200,
    BUFFERS = 2,
    SWAP_INTERVAL = 1,
    BEGIN_TIMEOUT_MS = 5000,
    CLEAR_ARGB = 0xFF101827,
    COLOR_WHITE = 0xFFFFFFFF,
    COLOR_BLUE = 0xFF70B7FF,
    COLOR_GOLD = 0xFFFFD166
};

static const char *const MENU_ITEMS[] = {
    "HOME / GOOGLE",
    "SEARCH THE WEB",
    "BOOKMARKS",
    "DIAGNOSTICS"
};
enum { MENU_COUNT = sizeof MENU_ITEMS / sizeof MENU_ITEMS[0] };

static const char *status_text = "Shell started. Web engine is NOT connected.";

static void draw_screen(uint32_t address, uint32_t width, uint32_t height, unsigned selected)
{
    (void)height;
    xsdk_gpu_set_target(width, height);
    xsdk_text_draw(60, 42, 3, COLOR_WHITE, "X360 BROWSER");
    xsdk_text_draw(64, 112, 1, COLOR_BLUE, "VERSION 0.3.0  |  XBOX NATIVE SHELL TEST");
    xsdk_text_draw(64, 165, 2, COLOR_WHITE, "Address: https://www.google.com");
    xsdk_text_draw(64, 205, 1, COLOR_GOLD, "STATUS: NO WEB PAGE IS LOADED IN THIS BUILD");

    for (unsigned i = 0; i < MENU_COUNT; ++i) {
        char line[64];
        const char *prefix = (i == selected) ? "> " : "  ";
        (void)snprintf(line, sizeof line, "%s%u. %s", prefix, i + 1U, MENU_ITEMS[i]);
        xsdk_text_draw(92, 285 + (int32_t)(i * 44U), 2,
                       i == selected ? COLOR_GOLD : COLOR_WHITE, line);
    }

    xsdk_text_draw(64, 500, 1, COLOR_BLUE, status_text);
    xsdk_text_draw(64, 552, 1, COLOR_WHITE, "D-PAD: SELECT     A: CONFIRM     BACK: EXIT");
    xsdk_text_draw(64, 592, 1, COLOR_WHITE, "HTML/CSS/JS/HTTPS ENGINE: PENDING");
    xsdk_text_draw(64, 632, 1, COLOR_WHITE, "This is a platform test, not a working browser yet.");
    xsdk_gpu_resolve(address, width, height, CLEAR_ARGB);
}

static void select_item(unsigned selected)
{
    switch (selected) {
    case 0:
        status_text = "Google selected, but no request was sent: engine pending.";
        xsdk_log_write("X360Browser: Google selected; web engine not connected; no request sent.");
        break;
    case 1:
        status_text = "Search selected, but the console keyboard/engine is pending.";
        xsdk_log_write("X360Browser: Search selected; keyboard and engine not connected.");
        break;
    case 2:
        status_text = "Bookmarks UI is pending in the native Xbox shell.";
        xsdk_log_write("X360Browser: Bookmarks selected; shell placeholder only.");
        break;
    default:
        status_text = "Video and controller loop are active. Press Back to exit.";
        xsdk_log_write("X360Browser: diagnostics selected.");
        break;
    }
}

static void run_loop(uint32_t width, uint32_t height)
{
    unsigned selected = 0;
    uint16_t previous_buttons = 0;

    for (;;) {
        INPUT_STATE input = { 0 };
        const uint32_t input_result = XamInputGetState(0, 0, &input);
        if (input_result != ERROR_SUCCESS)
            input = (INPUT_STATE){ 0 };
        const uint16_t buttons = input.gamepad.buttons;

        if ((buttons & INPUT_GAMEPAD_BACK) != 0) {
            xsdk_log_write("X360Browser: Back pressed; exiting shell.");
            break;
        }
        if ((buttons & INPUT_GAMEPAD_DPAD_UP) != 0 &&
            (previous_buttons & INPUT_GAMEPAD_DPAD_UP) == 0)
            selected = (selected + MENU_COUNT - 1U) % MENU_COUNT;
        if (((buttons & INPUT_GAMEPAD_DPAD_DOWN) != 0 &&
             (previous_buttons & INPUT_GAMEPAD_DPAD_DOWN) == 0) ||
            ((buttons & INPUT_GAMEPAD_DPAD_RIGHT) != 0 &&
             (previous_buttons & INPUT_GAMEPAD_DPAD_RIGHT) == 0))
            selected = (selected + 1U) % MENU_COUNT;
        if ((buttons & INPUT_GAMEPAD_DPAD_LEFT) != 0 &&
            (previous_buttons & INPUT_GAMEPAD_DPAD_LEFT) == 0)
            selected = (selected + MENU_COUNT - 1U) % MENU_COUNT;
        if ((buttons & INPUT_GAMEPAD_A) != 0 &&
            (previous_buttons & INPUT_GAMEPAD_A) == 0)
            select_item(selected);

        previous_buttons = buttons;

        uint32_t address = 0;
        const NTSTATUS present_status = xsdk_present_begin(&address, BEGIN_TIMEOUT_MS);
        if (!NT_SUCCESS(present_status)) {
            xsdk_log_write("X360Browser: xsdk_present_begin failed: 0x%08X", (unsigned)present_status);
            break;
        }
        draw_screen(address, width, height, selected);
        xsdk_present_end();
    }
}

int main(void)
{
    xsdk_log_write("X360Browser 0.3.0: native shell test starting.");
    const NTSTATUS splash_status = xsdk_splash_show(SPLASH_MS);
    if (!NT_SUCCESS(splash_status))
        xsdk_log_write("X360Browser: splash failed: 0x%08X", (unsigned)splash_status);

    NTSTATUS status = xsdk_gpu_open();
    if (!NT_SUCCESS(status)) {
        xsdk_log_write("X360Browser: xsdk_gpu_open failed: 0x%08X", (unsigned)status);
        return 1;
    }

    uint32_t width = 0;
    uint32_t height = 0;
    status = xsdk_present_open(XSDK_DISPLAY_720P, BUFFERS, SWAP_INTERVAL, &width, &height);
    if (!NT_SUCCESS(status)) {
        xsdk_log_write("X360Browser: xsdk_present_open failed: 0x%08X", (unsigned)status);
        (void)xsdk_gpu_close();
        return 1;
    }

    status = xsdk_text_open();
    if (!NT_SUCCESS(status)) {
        xsdk_log_write("X360Browser: xsdk_text_open failed: 0x%08X", (unsigned)status);
        xsdk_present_close();
        (void)xsdk_gpu_close();
        return 1;
    }

    xsdk_log_write("X360Browser: display is %ux%u", (unsigned)width, (unsigned)height);
    run_loop(width, height);

    xsdk_text_close();
    xsdk_present_close();
    status = xsdk_gpu_close();
    if (!NT_SUCCESS(status))
        xsdk_log_write("X360Browser: xsdk_gpu_close failed: 0x%08X", (unsigned)status);
    xsdk_log_write("X360Browser: shell exited. Web renderer remains pending.");
    return 0;
}
