X360 Browser 0.3.0 — Xbox shell de teste

Esta aplicação valida a inicialização gráfica 720p, saída de texto e leitura do controle pelo xSDK.

Controles:
  D-pad para cima/baixo ou esquerda/direita: mudar item
  A: selecionar o item (mostra aviso de que o motor web não está conectado)
  Back: sair para o dashboard

IMPORTANTE: não é um navegador funcional. Não carrega Google, HTML, HTTPS, vídeos nem outros sites.
