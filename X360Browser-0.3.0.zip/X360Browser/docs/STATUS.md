# Estado do projeto — 0.3.0

## Implementado

- [x] Núcleo C++17 e demonstração portátil.
- [x] Normalização HTTP/HTTPS, pesquisa Google, histórico, favoritos, configurações e perfil.
- [x] Suíte do núcleo verificada no ambiente host.
- [x] Shell C nativo separado para xSDK: inicialização gráfica 720p, texto e leitura do controle.
- [x] Alvo CMake e workflow para tentar gerar `X360Browser.xex`.
- [x] Guia específico para Termux e build em nuvem.

## Ainda não implementado

- [ ] Motor de renderização HTML/CSS/imagens real.
- [ ] JavaScript e DOM.
- [ ] Fetch HTTP/HTTPS integrado no shell Xbox.
- [ ] TLS e pacote de certificados raiz atualizável.
- [ ] Teclado virtual do console ligado à barra de endereço.
- [ ] Surfing em sites reais, cookies, downloads, cache e rolagem da página.
- [ ] Compilação do workflow executada com sucesso nesta sessão.
- [ ] Teste do `.xex` em console físico.

## O que a versão Xbox faz

O shell usa APIs do xSDK para abrir a saída de vídeo, desenhar texto e ler o controle. Ele mostra que a camada nativa pode ser iniciada, mas é explicitamente uma **prova de integração da plataforma**, não uma página web. Selecionar Google ou pesquisa mostra que o motor está pendente; não afirma que carregou o site.

## Critério de conclusão

Não marcar como navegador funcional até abrir um `.xex` no método homebrew real do usuário, carregar uma URL via HTTPS, renderizar uma página de verdade e testar voltar/avançar no hardware.
