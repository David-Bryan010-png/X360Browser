# Termux e Pydroid: o que usar

## Recomendação

Use **Termux**, não Pydroid, para este projeto. Pydroid é útil para executar Python, mas não substitui os compiladores cruzados, CMake/Ninja e etapas do toolchain PowerPC exigidas para gerar `.xex`.

O caminho mais leve para quem só tem Android é o workflow GitHub Actions descrito em `XBOX_BUILD.md`. O build local em Termux é experimental, pois a documentação upstream do xSDK prepara um ambiente Debian x86-64 por WSL e este fluxo tenta usar Debian ARM64 em `proot-distro`.

## 1. Preparar Termux

Instale o Termux de uma fonte confiável e, no aplicativo, execute:

```bash
pkg update && pkg upgrade -y
pkg install -y proot-distro git unzip nano
termux-setup-storage
proot-distro install debian
```

Extraia `X360Browser-0.3.0.zip` para a pasta Downloads do Android.

## 2. Abrir Debian com acesso à pasta Downloads

No Termux:

```bash
proot-distro login debian --bind "$HOME/storage/downloads:/mnt/shared"
```

Dentro do Debian:

```bash
apt update
apt install -y build-essential bison flex texinfo libgmp-dev libmpfr-dev libmpc-dev \
  curl xz-utils patch python3 cmake ninja-build git unzip ca-certificates
mkdir -p ~/work
unzip /mnt/shared/X360Browser-0.3.0.zip -d ~/work
cd ~/work/X360Browser
```

Se o nome do ZIP estiver diferente, liste os arquivos com `ls /mnt/shared` e ajuste o comando.

## 3. Compilar/testar apenas o núcleo portátil

```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build -j2
ctest --test-dir build --output-on-failure
```

Esse teste é rápido e não exige o toolchain Xbox.

## 4. Tentar gerar o shell `.xex`

```bash
JOBS=2 ./tools/build_xbox_shell.sh
```

O script clona o xSDK e o glslang-xenon, constrói o toolchain PowerPC e as dependências, depois compila `platform/xbox360/xsdk`. Pode levar bastante tempo e usar muitos gigabytes. Se falhar em uma dependência, pouca memória, falta de espaço ou incompatibilidade de arquitetura, copie o erro final; não há garantia de sucesso em Android.

Quando der certo, procure:

```text
build-xbox360/X360Browser.xex
```

## 5. Limite importante

Mesmo quando o `.xex` for gerado, esta versão é apenas o **shell nativo de teste**. O motor HTML/CSS/JavaScript, as requisições HTTP/HTTPS e a validação de certificados ainda precisam ser integrados antes de navegar em sites. Não copie um binário obtido de uma build que falhou.
