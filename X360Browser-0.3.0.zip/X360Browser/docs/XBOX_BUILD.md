# Gerar o shell Xbox 360 (`X360Browser.xex`)

## Estado honesto

A versão 0.3.0 contém código Xbox nativo para o shell, mas **não inclui um `.xex` pré-compilado nem o motor web**. O alvo requer o xSDK e seu toolchain PowerPC. Depois de construído, o shell valida tela e controle; ainda não navega em sites.

## Opção A — apenas com celular: GitHub Actions (recomendado)

1. Baixe `X360Browser-0.3.0.zip` e extraia os arquivos.
2. No navegador do celular, crie um repositório no GitHub e envie **todo o conteúdo** do projeto, incluindo a pasta oculta `.github/workflows/`. Se o envio pelo navegador não mostrar arquivos ocultos, use o Termux para iniciar o envio, ou use a opção B para compilar localmente.
3. Abra a aba **Actions** do repositório.
4. Execute o workflow **Build Xbox shell** (ou faça um commit/push, que também o dispara).
5. Quando terminar, abra a execução e baixe o artefato `X360Browser-0.3.0-xbox-shell`.
6. Dentro do ZIP haverá `X360Browser.xex` e um README para o teste.

O workflow compila dependências de terceiros a partir dos repositórios públicos upstream. O workflow está incluído, mas não foi executado neste ambiente; se falhar, abra o log da etapa que falhou.

## Opção B — Termux + Debian (experimental)

Requer celular Android ARM64, espaço livre amplo (planeje pelo menos 10 GB), boa memória e bateria/carga. O toolchain do xSDK foi documentado para PC Windows/WSL Debian; compilá-lo em Android ARM64 por `proot-distro` é experimental e pode falhar ou consumir muita memória.

Veja [`TERMUX_BUILD.md`](TERMUX_BUILD.md) para os comandos completos.

## Enviar ao Xbox

1. Confirme que seu ambiente de homebrew está ativo e consegue executar um `.xex` não assinado. Um pendrive com arquivos de exploit não significa, por si só, que qualquer `.xex` será executável.
2. Copie o `X360Browser.xex` para uma pasta no USB formatado em FAT32, por exemplo `Applications/X360Browser/`.
3. No dashboard/loader que você já usa para homebrew, navegue até o arquivo e tente executá-lo.
4. Se ele abrir, use D-pad para mudar a opção, A para selecionar e Back para sair.
5. A tela de shell **não carrega páginas na v0.3.0**. Esse teste apenas valida o ciclo de vida da aplicação e entrada do controle.

Se o método for BadUpdate/FreeMyXe ou outro exploit temporário, verifique as instruções específicas do exploit e do launcher. Alguns métodos perdem o estado de execução de código não assinado após reiniciar; não suponha que seja um RGH físico.
