# Testes da versão 0.3.0

## Núcleo portátil

```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build --config Release -j2
ctest --test-dir build --output-on-failure
```

A suíte cobre normalização HTTP/HTTPS, pesquisa UTF-8, esquemas bloqueados, histórico, favoritos, configurações e persistência. O resultado reportado no pacote corresponde ao compilador host usado nesta sessão.

## Shell Xbox

O shell só pode ser validado após compilar com o xSDK. Depois disso, executar o `.xex` num emulador pode ajudar em testes iniciais, mas o hardware real é a verificação final para gráficos, entrada e compatibilidade com o método de homebrew. A execução do workflow e o teste num console não foram realizados nesta sessão.

## Cobertura ainda ausente

Não há testes reais de HTTP/HTTPS, TLS, certificados, DNS no console, cookies, HTML/CSS/JavaScript, downloads nem reprodução de vídeo. A UI da versão 0.3.0 não faz pedidos web.
