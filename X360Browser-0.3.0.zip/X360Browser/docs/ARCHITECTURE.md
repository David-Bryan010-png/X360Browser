# Arquitetura do X360 Browser 0.3.0

## Camadas

- `src/url`: entrada do usuário convertida em URL HTTP/HTTPS ou pesquisa Google.
- `BrowserState`, `BookmarkStore`, `BrowserSettings`, `ProfileStore`, `BrowserSession`: estado e preferências independentes da plataforma.
- `PageEngine`: contrato abstrato para carga, progresso, cancelamento, rolagem e superfície renderizada; ainda não há adaptador real.
- `platform/xbox360/xsdk`: shell nativo C para xSDK, com saída 720p, texto e entradas do controle. É um projeto C separado de propósito, para primeiro validar o ciclo de vida de um `.xex`.
- `engine/netsurf`: plano de integração do NetSurf e de sua camada JavaScript.

## Fluxo desejado

1. A UI aceita uma URL/pesquisa por teclado virtual ou teclado USB.
2. `BrowserSession` normaliza e registra a navegação.
3. O adaptador `PageEngine` resolve DNS, faz a requisição, valida TLS e renderiza a página.
4. A UI exibe a superfície renderizada e o estado do carregamento.
5. O perfil grava configurações, favoritos e histórico.

A etapa 3 não está implementada. O shell Xbox da versão 0.3.0 não envia requisições web.

## Segurança

A camada de URL bloqueia esquemas não HTTP(S) e credenciais embutidas. Isso é validação sintática, não validação de certificado nem garantia de que um URL seja seguro. O futuro motor deve impor timeout, limite de memória, redirects limitados, verificação de certificados e tratamento de conteúdo não confiável.
