# Changelog

## 5.2.0 — 2026-10-28

- Expanded the page renderer to a 1280×544 full-width visual viewport for 720p output.
- Added CSS `background-image` extraction and raster-image lookup for HTML and external CSS resources.
- CSS background images stretch to their element box while normal images keep aspect-ratio contain behavior.
- Preserved border outlines after raster image composition and prioritized content images before CSS decoration.
- Replaced the configurable Vercel update endpoint with a direct GitHub Releases API client.
- Added release asset allowlisting, GitHub digest/checksum fallback, strict HTTPS/TLS checks, 64 MiB download limit, SHA-256 verification and rollback attempt.
- Removed runtime dependency on `X360Browser-update-config.txt`.
- Added host tests for the GitHub update-manifest parser and visual CSS background layers.
- Console operation, automatic in-place replacement and modern website compatibility still require hardware validation; this is not Chromium/WebKit.

## 5.1.0 — cursor, viewport expandido e atualização remota verificada
- Aumenta a altura da área de renderização web para 500 px e move o conteúdo para mais perto da barra superior.
- Reorganiza a interface para uma barra de endereço/título mais compacta e neutraliza o fundo externo azul.
- Adiciona cursor controlado pelo D-pad na vista visual, ativável/desativável com RS, com hit-testing de links e controles HTML visíveis. A tecla A abre o link sob cursor, executa handlers `onclick` suportados ou abre a entrada de endereço.
- Adiciona cliente de atualização HTTPS: lê endpoint de configuração, exige versão semântica, limita manifesto e XEX, valida SHA-256 via Mbed TLS e tenta troca com rollback. Se a troca falhar, preserva o XEX validado e informa o procedimento.
- Adiciona endpoint Vercel para consultar a última GitHub Release e manifesto JSON; workflow publica `.xex` e checksum junto ao ZIP nas tags de release.
- Adiciona edição de `input`/`textarea` via teclado virtual do Xbox e regressões para hit-test, valores DOM e dispatch de `onclick` em botão; atualiza documentação e workflow.
- Limites: ainda depende de validação no Xbox para confirmar renomeação do executável ativo; JavaScript e mídia continuam parciais, e YouTube não é garantido.


## 5.0.0 — XenonWeb Next / performance, controls and media handoff
- Cachear a estrutura WebVisualFrame fora da pilha de draw e evitar recalcular hashes do HTML em todo quadro; reconstruir apenas após navegação, ação DOM ou rolagem.
- Evitar a chamada duplicada à rota de layout quando a pipeline DOM/CSS falha; fallback direto para o renderizador legado.
- Adicionar invalidação explícita do cache visual na navegação e em dispatches DOM.
- Corrigir o caminho de `stream-url` do YouTube: resolução MP4 ocorre em worker de rede antes do handoff, em vez de entregar a URL watch ao player.
- Auto-detectar FFPlay.xex em locais comuns, permitir caminho explicitamente configurado e mostrar diagnóstico de configuração ausente/desativada.
- Acrescentar busca multi-provedor com `!g`, `!b` e `!d`; DuckDuckGo continua sendo o padrão.
- Ampliar XenonScript com propriedades e métodos comuns de string (`length`, `trim`, maiúsculas/minúsculas, busca, prefixo/sufixo e recorte), com testes de regressão.
- Reduzir consultas de arquivos de imagem ao preparar os índices de placeholders uma vez por layout, em vez de procurar novamente cada imagem para cada linha de texto em todo quadro.
- Atualizar identidade da aplicação, fluxo de build e documentação de compatibilidade.
- Limites mantidos explicitamente: runtime JavaScript parcial, sem pipeline HTML5 moderno de vídeo, WebGL/WASM ou compatibilidade universal com jogos atuais.

# Changelog — X360Browser

## 4.3.0 — confiabilidade do build e correções de interface

- Corrige a causa da falha `Extract validated source`: o ZIP era extraído de um caminho fixo que não correspondia à estrutura do artefato quando o log alterava o diretório comum do upload.
- Separa o artefato de fonte (ZIP + SHA-256) do artefato de log de validação.
- Pesquisa o ZIP recursivamente, exige exatamente um resultado, verifica o SHA-256, valida caminhos do ZIP e verifica `VERSION` antes de iniciar o compilador.
- Cria log da etapa de extração antes da primeira validação para preservar diagnóstico se a etapa falhar.
- Adiciona teste de regressão de estrutura do artefato e corrige o título de UI que ainda informava versão 3.3.
- Inicializa explicitamente o buffer de entrada do teclado de endereços e calcula seu comprimento uma vez, removendo um alerta de leitura potencial de bytes não inicializados.
- Deixa de reter ponteiros temporários de `stats`/código-fonte no interpretador global após retornar, preservando a identidade do documento e as variáveis entre eventos da mesma página; adiciona fallback defensivo para valores CSS nulos.
- Mantém a correção do shader 4.2.0; não declara que um XEX foi produzido até a execução real do workflow.



## 4.3.0 — correção crítica do renderizador Xbox

- Corrige a localização de entrada do shader de textura: em xSDK, GLSL `location=1` corresponde a `COLOR`, e `location=2` a `TEXCOORD0`. A localização errada causava a mensagem `vertex layout lacks an input the shader fetches` e desligava o renderizador visual.
- Adiciona teste de regressão para o contrato GLSL ↔ `XsdkVertexElement`, incluindo formato, índice de uso, offsets e stride.
- Separa mensagens de falha para carregamento de shader, layout de vértices e alocação de textura.
- Cria arquivos padrão de configuração de mídia e favoritos no diretório de build, reduzindo falhas de abertura esperadas na primeira execução; o player externo continua desativado.
- Remove a exclusão redundante de um arquivo de cache antes de abri-lo em modo de escrita e substitui a cópia `snprintf` por cópia limitada explícita.
- Atualiza o User-Agent e a documentação para 4.3.0.
- Não declara compatibilidade total com Chromium, WebGL, WebAssembly ou vídeo HTML5 nativo.

## 4.1.0 — URL hardening e manutenção do motor

- Corrige a validação de portas para rejeitar valores enormes antes de ocorrer overflow inteiro.
- Rejeita sequências percent-encoded incompletas ou com dígitos não hexadecimais em URLs HTTP/HTTPS.
- Adiciona testes de regressão para portas excessivas e escapes `%` inválidos, preservando escapes válidos.
- Mantém as melhorias de renderização, scripts, imagens e resolução experimental de mídia da 4.0.0.
- Não declara suporte novo a codecs de vídeo, JavaScript moderno, WebGL ou WebAssembly sem implementação e testes próprios.

## 4.0.0 — engine refresh

- Maior capacidade delimitada no DOM, CSS, layout e execução XenonScript.
- Negociação de compressão HTTP para documento, estilos e scripts quando disponível na build do libcurl.
- Suporte ampliado a scripts externos pequenos, com limites máximos, verificação de tipo MIME, TLS validado e timeouts mantidos.
- Fallback de textura tiled para linear e invalidação da cache raster quando o arquivo muda.
- Resolução experimental de links de vídeo do YouTube via Invidious para MP4 muxado até 480p, com restrição a host Google Video, TLS e limite de download. Exige player externo configurado e uma instância pública funcional.
- Atualização de metadados, título da aplicação e User-Agent para 4.0.0.
- Documentação explícita das lacunas de compatibilidade.

- Strict YouTube URL authority parsing now rejects empty, non-numeric, overflowing and malformed ports; watch links with fragments retain correct video-ID parsing.
- Resolved media URLs now accept only HTTPS Google Video hosts on the default TLS port, and downloaded YouTube payloads must pass an MP4 `ftyp` signature/box-length check before external-player handoff.
- The stream JSON parser now rejects truncated/incomplete top-level objects and unclosed format arrays instead of accepting a partially parsed result.
- Image URL discovery now recognizes additional lazy-loading attributes (`data-lazy-src`, `data-original-src`, `data-src-large`, and `data-lazy-srcset`) without overriding a normal `src`.

## 3.6.0

- Preview de compatibilidade web com engine XenonWeb DOM/CSS/XenonScript, XenonMedia e rede TLS via libcurl/Mbed TLS.
