#!/usr/bin/env python3
"""Static regression checks for the direct-to-GitHub self-updater."""
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
updater = (ROOT / "platform/xbox360/xsdk/update_manager.c").read_text(encoding="utf-8")
manifest = (ROOT / "platform/xbox360/xsdk/update_manifest.c").read_text(encoding="utf-8")
header = (ROOT / "platform/xbox360/xsdk/update_manifest.h").read_text(encoding="utf-8")
main = (ROOT / "platform/xbox360/xsdk/main.c").read_text(encoding="utf-8")
workflow = (ROOT / ".github/workflows/build-xex-from-zip.yml").read_text(encoding="utf-8")
cmake = (ROOT / "platform/xbox360/xsdk/CMakeLists.txt").read_text(encoding="utf-8")
checks = {
    "client requests the public latest-release GitHub API": "api.github.com/repos/David-Bryan010-png/X360Browser/releases/latest" in updater,
    "client enforces HTTPS and certificate verification": 'strncasecmp(url, "https://", 8U)' in updater and "CURLOPT_SSL_VERIFYPEER, 1L" in updater and "CURLOPT_SSL_VERIFYHOST, 2L" in updater,
    "client caps downloaded executable size": "UPDATE_XEX_MAX_BYTES (64U * 1024U * 1024U)" in updater,
    "client computes executable SHA-256 with Mbed TLS": "mbedtls_md_info_from_type(MBEDTLS_MD_SHA256)" in updater and "mbedtls_md_finish" in updater,
    "release parser permits only this repository's release assets": "X360Browser/releases/download/" in manifest and "x360_update_parse_github_release" in header,
    "release parser accepts GitHub asset digest and checksum fallback": '"digest"' in manifest and "X360Browser.xex.sha256" in manifest and "x360_update_parse_checksum" in manifest,
    "release parser rejects unknown asset hosts": "strncasecmp(url, X360_RELEASE_PREFIX" in manifest,
    "client attempts rollback after failed rename": "rename(UPDATE_XEX_BACKUP, UPDATE_XEX_CURRENT)" in updater,
    "application starts updater in background without reading config file": "start_update_check();" in main and "pthread_create(&g_update_thread" in main and "load_update_config" not in main and "g_update_endpoint" not in main,
    "updater is part of Xbox build": "update_manifest.c" in cmake,
    "GitHub workflow publishes XEX and checksum": "softprops/action-gh-release@v2" in workflow and 'tags: ["v*"]' in workflow and "X360Browser.xex.sha256" in workflow,
    "no Vercel dependency remains in build workflow": "vercel/api/update.js" not in workflow and "X360Browser-update-config.txt" not in workflow,
}
failed = [name for name, ok in checks.items() if not ok]
for name, ok in checks.items():
    print(("PASS" if ok else "FAIL") + ": " + name)
if failed:
    raise SystemExit(f"FAIL: {len(failed)} update contract checks failed")
print(f"PASS: all {len(checks)} update contract checks")
