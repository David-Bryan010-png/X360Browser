#!/usr/bin/env python3
"""Regression tests for the Actions source-artifact download/extraction path."""
from pathlib import Path
from tempfile import TemporaryDirectory
import re

ROOT = Path(__file__).resolve().parents[1]
workflow = (ROOT / ".github/workflows/build-xex-from-zip.yml").read_text(encoding="utf-8")
version = (ROOT / "VERSION").read_text(encoding="utf-8").strip()

checks = {
    "source archive is uploaded as a separate artifact": "name: X360Browser-${{ steps.source.outputs.version }}-validated-source" in workflow,
    "validation log is not mixed into the source artifact": "name: X360Browser-${{ steps.source.outputs.version }}-validation-log" in workflow,
    "extract step searches downloaded artifact recursively": 'find "$DOWNLOAD_DIR" -type f' in workflow and 'X360Browser-${EXPECTED_SOURCE_VERSION}-source.zip' in workflow,
    "archive checksum is required and verified": 'sha256sum -c' in workflow and 'X360Browser-${EXPECTED_SOURCE_VERSION}-source.zip.sha256' in workflow,
    "release packages XEX and matching checksum": 'X360Browser.xex.sha256' in workflow and 'softprops/action-gh-release@v2' in workflow,
    "runtime package no longer requires URL config file": 'X360Browser-update-config.txt' not in workflow,
    "GitHub manifest parser is included in source validation": "platform/xbox360/xsdk/update_manifest.c" in workflow,
    "extract step validates version after extraction": 'FOUND_VERSION" != "$EXPECTED_SOURCE_VERSION"' in workflow,
    "semantic version comes from VERSION and is published as a job output": 'echo "version=$PROJECT_VERSION" >> "$GITHUB_OUTPUT"' in workflow and 'outputs:' in workflow,
    "tag version must match source VERSION": 'Tag $GITHUB_REF_NAME does not match VERSION $PROJECT_VERSION' in workflow,
    "legacy brittle path was removed": 'ARCHIVE="$RUNNER_TEMP/validated/X360Browser-5.1.0-source.zip"' not in workflow,
    "newer source ZIP wins over an older checked-out tree": "NEWEST_ARCHIVE" in workflow and "sort -V" in workflow and "X360Browser-(\\d+)\\.(\\d+)\\.(\\d+)-source" in workflow,
}
for label, ok in checks.items():
    print(("PASS" if ok else "FAIL") + ": " + label)
if not all(checks.values()):
    raise SystemExit(1)

# Simulate both a flat artifact and the previous nested-common-ancestor structure.
with TemporaryDirectory() as tmp:
    base = Path(tmp)
    flat = base / "flat"
    nested = base / "nested" / "x360browser-dist"
    flat.mkdir(parents=True)
    nested.mkdir(parents=True)
    archive_name = f"X360Browser-{version}-source.zip"
    (flat / archive_name).write_bytes(b"zip fixture")
    (nested / archive_name).write_bytes(b"nested zip fixture")
    for root in (flat, base / "nested"):
        found = sorted(root.rglob(archive_name))
        if len(found) != 1:
            raise SystemExit(f"FAIL: recursive archive discovery found {len(found)} files in {root}")
    print("PASS: archive discovery handles flat and nested artifact layouts")

print(f"PASS: all {len(checks) + 1} workflow artifact-path checks")
