# X360Browser 5.2.0 — build Xbox 360

O workflow `.github/workflows/build-xex-from-zip.yml` valida a versão definida em `VERSION`, executa os testes e tenta compilar/empacotar o XEX PowerPC/xSDK. A existência de fonte ou testes host verdes não prova que o XEX tenha sido compilado nem que inicie no console. Confirme uma execução verde do GitHub Actions e baixe o artefato publicado.

O pacote esperado contém `X360Browser.xex`, `cacert.pem`, `X360Browser-video-config.txt`, `X360Browser-bookmarks.txt`, `SHA256SUMS.txt` e eventuais licenças. Não existe mais requisito de `X360Browser-update-config.txt`.

O cliente de atualização consulta `https://api.github.com/repos/David-Bryan010-png/X360Browser/releases/latest`, aceita apenas download assets da release oficial, valida SHA-256 e tenta troca/rollback. A primeira instalação da versão com atualizador continua manual. Como o Xbox pode não permitir renomear o XEX em execução, valide o comportamento no RGH/JTAG e mantenha backup.
