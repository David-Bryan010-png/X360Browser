# X360Browser 5.2.0 — estado da fonte

## Alterações desta versão

- Viewport gráfico ampliado para 1280×544 e alinhado à largura integral da tela.
- XenonWeb reconhece imagens CSS `background-image`; URLs de CSS externo também entram no pré-carregamento raster.
- Imagens de conteúdo têm prioridade sobre fundos decorativos.
- Atualizador consulta diretamente a API pública de GitHub Releases; não exige Vercel nem `X360Browser-update-config.txt`.
- Parser do manifesto, política de URLs permitidas, digest/checksum e integração no build estão cobertos por testes.

## Validação

Executar `python3 tests/validate_project_integrity.py`, `python3 tests/test_xbox_shader_contract.py`, `python3 tests/test_workflow_artifact_paths.py`, `python3 tests/test_auto_update_contract.py`, `python3 tests/run_host_tests.py` e CMake/CTest de host. Os resultados devem ser regenerados após cada alteração; não reutilizar resultados antigos.

## Status que ainda exige validação externa

- O workflow GitHub Actions precisa produzir o XEX usando o toolchain PowerPC/xSDK.
- O `.xex` precisa ser executado em Xbox 360 RGH/JTAG real.
- HTTPS/TLS, consulta da release, SHA-256, staging/rollback e reabertura precisam ser verificados no hardware.
- YouTube e sites modernos continuam limitados pelo subconjunto do motor.
