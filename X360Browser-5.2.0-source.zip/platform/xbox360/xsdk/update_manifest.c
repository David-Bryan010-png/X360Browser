#include "update_manifest.h"

#include <ctype.h>
#include <stdio.h>
#include <string.h>
#include <strings.h>

#define X360_RELEASE_PREFIX "https://github.com/David-Bryan010-png/X360Browser/releases/download/"

static int json_string(const char *begin, const char *end, const char *key, char *out, size_t cap)
{
    char needle[64];
    const char *p, *finish;
    size_t n, needle_len;
    if (begin == NULL || end == NULL || key == NULL || out == NULL || cap == 0U || end < begin) return 0;
    if (snprintf(needle, sizeof(needle), "\"%s\"", key) < 0) return 0;
    needle_len = strlen(needle);
    p = begin;
    while (p <= end && (size_t)(end - p) >= needle_len) {
        const char *match = NULL;
        for (; p <= end && (size_t)(end - p) >= needle_len; ++p) {
            if (memcmp(p, needle, needle_len) == 0) { match = p; break; }
        }
        if (match == NULL) return 0;
        p = match + needle_len;
        while (p < end && isspace((unsigned char)*p)) ++p;
        if (p >= end || *p++ != ':') continue;
        while (p < end && isspace((unsigned char)*p)) ++p;
        if (p >= end || *p++ != '"') continue;
        finish = p;
        while (finish < end && *finish != '"') {
            if (*finish == '\\') return 0; /* These fields must not depend on JSON escape decoding. */
            ++finish;
        }
        if (finish >= end || *finish != '"') return 0;
        n = (size_t)(finish - p);
        if (n == 0U || n >= cap) return 0;
        memcpy(out, p, n);
        out[n] = '\0';
        return 1;
    }
    return 0;
}

static int valid_version(char *version)
{
    unsigned int major, minor, patch;
    char tail;
    if (version[0] == 'v' || version[0] == 'V') {
        memmove(version, version + 1, strlen(version));
    }
    if (sscanf(version, "%u.%u.%u%c", &major, &minor, &patch, &tail) != 3) return 0;
    if (strchr(version, '-') != NULL || strchr(version, '+') != NULL) return 0;
    return 1;
}

static int copy_asset_object(const char *start, const char *end, X360UpdateManifest *manifest)
{
    char name[128] = {0};
    char url[1024] = {0};
    char digest[96] = {0};
    if (!json_string(start, end, "name", name, sizeof(name)) ||
        !json_string(start, end, "browser_download_url", url, sizeof(url))) return 0;
    if (strncasecmp(url, X360_RELEASE_PREFIX, sizeof(X360_RELEASE_PREFIX) - 1U) != 0) return 0;
    if (strcmp(name, "X360Browser.xex") == 0) {
        (void)snprintf(manifest->xex_url, sizeof(manifest->xex_url), "%s", url);
        if (json_string(start, end, "digest", digest, sizeof(digest)) && strncasecmp(digest, "sha256:", 7U) == 0 && strlen(digest + 7U) == 64U) {
            size_t i;
            for (i = 0U; i < 64U; ++i) {
                if (!isxdigit((unsigned char)digest[i + 7U])) return 0;
                manifest->sha256[i] = (char)tolower((unsigned char)digest[i + 7U]);
            }
            manifest->sha256[64] = '\0';
        }
    } else if (strcmp(name, "X360Browser.xex.sha256") == 0) {
        (void)snprintf(manifest->checksum_url, sizeof(manifest->checksum_url), "%s", url);
    }
    return 1;
}

int x360_update_parse_github_release(const char *json, X360UpdateManifest *manifest)
{
    const char *end, *tag, *assets, *p;
    if (json == NULL || manifest == NULL) return 0;
    memset(manifest, 0, sizeof(*manifest));
    end = json + strlen(json);
    if (!json_string(json, end, "tag_name", manifest->version, sizeof(manifest->version)) || !valid_version(manifest->version)) return 0;
    tag = strstr(json, "\"assets\"");
    if (tag == NULL) return 0;
    assets = strchr(tag, '[');
    if (assets == NULL) return 0;
    p = assets + 1;
    while (p < end && *p != ']') {
        const char *object_start, *object_end;
        unsigned depth = 0U;
        int in_string = 0, escaped = 0;
        while (p < end && *p != '{' && *p != ']') ++p;
        if (p >= end || *p == ']') break;
        object_start = p++;
        depth = 1U;
        in_string = 0;
        while (p < end && depth > 0U) {
            char c = *p++;
            if (in_string) {
                if (escaped) escaped = 0;
                else if (c == '\\') escaped = 1;
                else if (c == '"') in_string = 0;
            } else {
                if (c == '"') in_string = 1;
                else if (c == '{') ++depth;
                else if (c == '}') --depth;
            }
        }
        if (depth != 0U) return 0;
        object_end = p;
        if (!copy_asset_object(object_start, object_end, manifest)) return 0;
    }
    if (manifest->xex_url[0] == '\0') return 0;
    if (manifest->sha256[0] == '\0' && manifest->checksum_url[0] == '\0') return 0;
    return 1;
}

int x360_update_parse_checksum(const char *text, char output[65])
{
    size_t i;
    if (text == NULL || output == NULL) return 0;
    for (i = 0U; text[i] != '\0'; ++i) {
        size_t j;
        if (!isxdigit((unsigned char)text[i])) continue;
        for (j = 0U; j < 64U && text[i + j] != '\0' && isxdigit((unsigned char)text[i + j]); ++j) { }
        if (j == 64U) {
            size_t k;
            for (k = 0U; k < 64U; ++k) output[k] = (char)tolower((unsigned char)text[i + k]);
            output[64] = '\0';
            return 1;
        }
        i += j > 0U ? j - 1U : 0U;
    }
    return 0;
}
