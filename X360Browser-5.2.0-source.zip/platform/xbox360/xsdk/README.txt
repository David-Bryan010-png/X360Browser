X360Browser 5.2.0 — Xbox 360 xSDK target

The application owns XenonWeb (HTML/CSS layout and visual page composition), XenonScript (bounded JavaScript-like runtime), and XenonMedia (first-party raster/elementary-media decoders). The 1280x544 graphical viewport, CSS background-image layers, external stylesheet image discovery, gamepad pointer and bounded DOM event support are described in docs/GRAPHICAL-ENGINE-5.2.0-pt-BR.md.

The runtime package contains X360Browser.xex, cacert.pem, X360Browser-video-config.txt, X360Browser-bookmarks.txt, README.txt and relevant licenses. There is no X360Browser-update-config.txt. The updater requests https://api.github.com/repos/David-Bryan010-png/X360Browser/releases/latest over certificate-verified HTTPS, accepts only release assets hosted under this project's GitHub Releases path, validates SHA-256 and attempts a rollback-capable swap. It may leave X360Browser.update.xex staged if the active executable cannot be replaced. Initial installation of the new updater version must be manual.

YouTube is still experimental and may require compatible FFPlay.xex external playback. This is not Chromium/WebKit, and XenonScript is not full ECMAScript. Current CSS, HTML, media codecs and Web APIs are a bounded subset.

Host tests do not prove successful PowerPC compilation or Xbox hardware operation. Run GitHub Actions and test on a real RGH/JTAG console. Refer to docs/XBOX_BUILD.md and docs/GRAPHICAL-ENGINE-5.2.0-pt-BR.md.
