# Xbox 360 target — X360Browser 5.2.0

The xSDK target uses shader location 0 = POSITION, location 1 = COLOR, location 2 = TEXCOORD0. The current version expands the graphical viewport to 1280×544, supports CSS background-image layers and background URL discovery from external stylesheets, uses a gamepad-controlled pointer, and checks GitHub Releases directly for verified updates.

Build with `tools/build_xbox_shell.sh` using the supported xSDK PowerPC toolchain. The runtime package contains `X360Browser.xex`, `cacert.pem`, `X360Browser-video-config.txt`, `X360Browser-bookmarks.txt`, `README.txt`, `SHA256SUMS.txt`, and relevant licenses. There is no requirement for a Vercel service or update URL text file.

A successful host build/test is not a substitute for an Xbox PowerPC XEX build and a smoke test on Xbox 360 RGH/JTAG hardware. The update installer must also be tested on the actual location where the XEX is launched, because the running executable might not be replaceable in-place.
