# X360Browser 5.2.0 — XenonWeb Graphical Preview

Navegador homebrew para Xbox 360 RGH/JTAG, escrito em C/C++. Esta versão concentra-se na apresentação gráfica de páginas: viewport de 1280×544, renderizador próprio XenonWeb, CSS `background-image`, descoberta de imagens referenciadas por folhas de estilo externas, interação por gamepad e atualização consultando diretamente o GitHub Releases. Não é um port do Chromium/WebKit e não deve ser descrito como navegador moderno completo.

## O que mudou na 5.2.0

- Área visual ampliada para 1280×544 e posicionada para usar toda a largura da tela 720p; leitor textual fica como fallback quando a camada gráfica não inicia.
- Suporte no renderizador a fundos CSS `background-image`, respeitando camada de fundo atrás do conteúdo. Imagens `<img>` continuam preservando proporção; fundos CSS podem preencher o elemento.
- Pré-carregamento de imagens de conteúdo priorizado antes de fundos decorativos, incluindo URLs encontradas em CSS externo.
- Cursor por gamepad, seleção de links/controles, campos de entrada com teclado virtual e execução limitada de `onclick`.
- Atualizador sem serviço pago ou URL de configuração: consulta `https://api.github.com/repos/David-Bryan010-png/X360Browser/releases/latest`, limita downloads, aceita somente assets da release oficial e valida SHA-256 vindo do `digest` do GitHub ou do asset de checksum. O programa tenta troca transacional e rollback; se o sistema de arquivos não permitir trocar o executável em uso, pode deixar o arquivo verificado como `X360Browser.update.xex` para instalação na próxima abertura.
- Testes automatizados para manifesto de release, checksum, renderização de fundo CSS, layout, DOM, scripts limitados, mídia e workflow.

## Publicar uma release e usar auto-update

1. Envie a árvore de fonte e `.github/workflows/build-xex-from-zip.yml` para o GitHub.
2. Confira o workflow **Actions** e espere todos os passos concluírem. Ele precisa compilar o XEX usando o toolchain Xbox apropriado e publicar os artefatos de release.
3. Publique uma tag `v5.2.0` que corresponda ao arquivo `VERSION` (ou use `workflow_dispatch` para testar o build). A API `/releases/latest` ignora drafts e pré-releases.
4. A release estável precisa conter `X360Browser.xex`; quando o GitHub disponibiliza seu digest SHA-256, o cliente usa esse digest. Caso contrário, tenta `X360Browser.xex.sha256`.
5. Copie o primeiro XEX atualizado manualmente para o USB e mantenha backup do anterior. Depois de iniciar a versão com o atualizador, ela pode verificar releases posteriores no início. Não é necessário `X360Browser-update-config.txt` nem Vercel.

## Limites de compatibilidade

XenonWeb é um renderizador gráfico de subconjunto HTML/CSS, não um motor equivalente ao Chromium ou WebKit. XenonScript executa um subconjunto limitado de JavaScript. Canvas/WebGL/WebAssembly, módulos modernos, promises completas, layouts CSS complexos, iframes executáveis, DRM e sites/jogos modernos não têm suporte garantido. A reprodução de YouTube é experimental e pode depender de um resolvedor MP4 e de `FFPlay.xex`; não é reprodução HTML5 completa integrada.

O teste host valida código portável e contratos; **não demonstra funcionamento no Xbox físico**. Para certificar uma release, execute o workflow de build e teste o XEX em console RGH/JTAG real.

## Testes locais

```sh
python3 tests/validate_project_integrity.py
python3 tests/test_xbox_shader_contract.py
python3 tests/test_workflow_artifact_paths.py
python3 tests/test_auto_update_contract.py
python3 tests/run_host_tests.py
cmake -S . -B build-host -DX360BROWSER_BUILD_TESTS=ON
cmake --build build-host
ctest --test-dir build-host --output-on-failure
```
