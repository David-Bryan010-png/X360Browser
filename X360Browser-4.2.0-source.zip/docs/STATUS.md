# X360Browser 4.2.0 — estado atual

- Correção aplicada para o erro fatal de inicialização do renderizador: coordenadas UV movidas para a localização GLSL 2, mapeada pelo xSDK para TEXCOORD0.
- Adicionado teste de contrato de shader/vertex fetch e diagnóstico separado para falha de shader, layout ou textura.
- Build cria por padrão os arquivos de configuração de vídeo (player externo desativado) e banco de favoritos vazio junto do XEX.
- Removida a exclusão redundante do arquivo de cache antes de abrir para escrita; melhorada cópia de strings limitada para remover aviso do compilador.
- Testes de host XenonWeb/XenonScript/XenonMedia passaram; CMake/CTest passou com 2/2; sintaxe C estrita e shell passaram.
- **Pendente:** rodar o XEX 4.2.0 em um Xbox 360 RGH/JTAG e conferir que o log deixa de mostrar `visual renderer unavailable` e passa a mostrar `XenonWeb DOM/CSS/XenonScript renderer initialized`.

Ainda não é Chromium e não oferece reprodução nativa universal de vídeo nem compatibilidade garantida com jogos modernos que exigem WebGL/WebAssembly.
