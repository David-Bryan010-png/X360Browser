# Changelog — X360Browser


## 4.2.0 — correção crítica do renderizador Xbox

- Corrige a localização de entrada do shader de textura: em xSDK, GLSL `location=1` corresponde a `COLOR`, e `location=2` a `TEXCOORD0`. A localização errada causava a mensagem `vertex layout lacks an input the shader fetches` e desligava o renderizador visual.
- Adiciona teste de regressão para o contrato GLSL ↔ `XsdkVertexElement`, incluindo formato, índice de uso, offsets e stride.
- Separa mensagens de falha para carregamento de shader, layout de vértices e alocação de textura.
- Cria arquivos padrão de configuração de mídia e favoritos no diretório de build, reduzindo falhas de abertura esperadas na primeira execução; o player externo continua desativado.
- Remove a exclusão redundante de um arquivo de cache antes de abri-lo em modo de escrita e substitui a cópia `snprintf` por cópia limitada explícita.
- Atualiza o User-Agent e a documentação para 4.2.0.
- Não declara compatibilidade total com Chromium, WebGL, WebAssembly ou vídeo HTML5 nativo.

## 4.1.0 — URL hardening e manutenção do motor

- Corrige a validação de portas para rejeitar valores enormes antes de ocorrer overflow inteiro.
- Rejeita sequências percent-encoded incompletas ou com dígitos não hexadecimais em URLs HTTP/HTTPS.
- Adiciona testes de regressão para portas excessivas e escapes `%` inválidos, preservando escapes válidos.
- Mantém as melhorias de renderização, scripts, imagens e resolução experimental de mídia da 4.0.0.
- Não declara suporte novo a codecs de vídeo, JavaScript moderno, WebGL ou WebAssembly sem implementação e testes próprios.

## 4.0.0 — engine refresh

- Maior capacidade delimitada no DOM, CSS, layout e execução XenonScript.
- Negociação de compressão HTTP para documento, estilos e scripts quando disponível na build do libcurl.
- Suporte ampliado a scripts externos pequenos, com limites máximos, verificação de tipo MIME, TLS validado e timeouts mantidos.
- Fallback de textura tiled para linear e invalidação da cache raster quando o arquivo muda.
- Resolução experimental de links de vídeo do YouTube via Invidious para MP4 muxado até 480p, com restrição a host Google Video, TLS e limite de download. Exige player externo configurado e uma instância pública funcional.
- Atualização de metadados, título da aplicação e User-Agent para 4.0.0.
- Documentação explícita das lacunas de compatibilidade.

- Strict YouTube URL authority parsing now rejects empty, non-numeric, overflowing and malformed ports; watch links with fragments retain correct video-ID parsing.
- Resolved media URLs now accept only HTTPS Google Video hosts on the default TLS port, and downloaded YouTube payloads must pass an MP4 `ftyp` signature/box-length check before external-player handoff.
- The stream JSON parser now rejects truncated/incomplete top-level objects and unclosed format arrays instead of accepting a partially parsed result.
- Image URL discovery now recognizes additional lazy-loading attributes (`data-lazy-src`, `data-original-src`, `data-src-large`, and `data-lazy-srcset`) without overriding a normal `src`.

## 3.6.0

- Preview de compatibilidade web com engine XenonWeb DOM/CSS/XenonScript, XenonMedia e rede TLS via libcurl/Mbed TLS.
