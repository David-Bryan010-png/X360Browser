# X360Browser 4.2.0

Navegador homebrew experimental para Xbox 360 RGH/JTAG. O código combina transporte HTTPS via libcurl/Mbed TLS com o motor próprio XenonWeb (DOM/CSS/layout), XenonScript (subconjunto JavaScript) e XenonMedia.

## Versão 4.2.0

A 4.2.0 corrige o motivo principal da tela de texto no Xbox: o shader usava a localização GLSL errada para coordenadas de textura, fazendo o xSDK rejeitar o layout de vértices e desativar o renderizador. Também melhora o diagnóstico de inicialização gráfica, evita um aviso de cache ausente e inclui arquivos padrão de favoritos/configuração junto do XEX. A 4.1.0 reforçou a validação de URLs, corrigiu a verificação de portas muito longas para evitar overflow inteiro e rejeitou escapes percentuais incompletos ou não hexadecimais. Também preserva as melhorias da 4.0.0: amplia limites delimitados de DOM/CSS/layout/script, negocia compressão HTTP quando o libcurl oferece suporte, melhora o fallback gráfico e invalida caches de imagens modificadas. A fonte também corrige a classificação de URLs do YouTube, recusa portas malformadas, rejeita respostas JSON truncadas, valida o cabeçalho MP4 antes de entregar streams resolvidos ao player e reconhece atributos comuns de lazy loading de imagens. Inclui um caminho experimental para resolver certos links do YouTube em MP4 muxado até 480p por APIs públicas de terceiros; exige um player externo compatível e não é reprodução nativa.

**Isto ainda não é Chromium nem um navegador moderno completo.** Muitos sites atuais podem falhar. Jogos do Poki que exigem ECMAScript moderno, Canvas/WebGL, WebAssembly, timers e APIs avançadas continuam fora da compatibilidade garantida. Ver [`docs/COMPATIBILITY-4.2.0.md`](docs/COMPATIBILITY-4.2.0.md).

## Build

Use `.github/workflows/build-xex-from-zip.yml` ou `platform/xbox360/xsdk/CMakeLists.txt` com a toolchain Xbox 360/XSDK e as dependências Mbed TLS/libcurl compatíveis. A verificação host via CMake não substitui compilação PowerPC nem teste real no console.
