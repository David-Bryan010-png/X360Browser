# XenonWeb — arquitetura e estado

## Objetivo

XenonWeb é o motor de página próprio do X360Browser, escrito em C para o orçamento de CPU/memória do Xbox 360. Combina um parser/árvore DOM limitada, parser e cálculo de um subconjunto CSS e geração de layout para `WebVisualFrame`. XenonScript é a camada inline associada para uma parte controlada de script. O projeto não depende de NetSurf/libcss/libdom como motor principal; `netsurf_backend_stub.c` é apenas um stub.

## Limites atuais

| Módulo | Implementado | Limite conhecido |
|---|---|---|
| DOM | Nós, atributos, texto, entidades HTML comuns, tags void, lookup por ID e mutações de texto/atributos | Sem parsing/recuperação completa do HTML5; capacidade e profundidade limitadas |
| CSS | `<style>` embutido, estilo inline, tag/classe/ID, descendente/filho, seletores de atributo e algumas pseudoclasses | Parser/cascade não completo; sem toda especificidade/herança CSS, `@media`, stylesheet externo, flex/grid reais |
| Layout | Texto, quebras de bloco, estilos básicos, links focáveis, placeholders e caixas de controles | Métricas tipográficas aproximadas, inline layout sofisticado, stacking context e posicionamento avançado ausentes |
| XenonScript | Script inline limitado, variáveis/expressões simples, `if/else`, mutações DOM selecionadas, `onclick` em âncoras | Não é ECMAScript; sem loop completo, funções, event loop, APIs web ou frameworks |
| Integração | Quadro visual conectado ao renderer Xbox, fallback VisualLite | PowerPC/xSDK e console ainda não validados nesta entrega |

Os limites do DOM são deliberados: `XW_DOM_MAX_NODES=1024`, `XW_DOM_MAX_ATTRIBUTES=4096`, pool de strings de 128 KiB e profundidade de 64. O parser registra truncamento em vez de alegar memória ilimitada.

## Fluxo de renderização

O UI entrega uma `WebEnginePage` ao caminho visual. XenonWeb constrói e mantém a árvore DOM para a identidade da página; XenonScript executa uma vez os scripts inline permitidos; XenonWeb coleta CSS, calcula estilos e constrói o quadro; o renderer Xbox desenha texto, caixas e foco de links. Ao ativar uma âncora com `onclick`, o dispatch executa o trecho suportado e invalida o quadro para que mutações de DOM sejam renderizadas novamente. Se não for possível montar o quadro XenonWeb, usa-se o layout antigo como fallback.

O parser de links de rede mantém âncoras com `#fragment` para permitir foco e dispatch local. Essa seleção não significa que navegação por fragmentos tenha implementação completa de scroll-to-element.

## Segurança e robustez

- DOM, CSS, scripts e quadro visual têm limites fixos.
- XenonScript tem orçamento de instruções e rejeita sintaxe não suportada; não deve executar código arbitrário com loop ilimitado.
- A implementação é síncrona e single-page; não oferece sandbox web de navegador moderno nem isolamento por origem.
- Ainda é necessário fuzzing/adversarial tests e validação no hardware real.

## Próximas etapas

1. Cross-build xSDK/PowerPC e teste do arranque/controles no Xbox.
2. Medição da memória/stack/CPU e correção dos problemas específicos de console.
3. Ampliar testes DOM/CSS/XenonScript e cobertura de mutações/events/forms.
4. Expandir regras CSS e layout em pequenas partes mensuráveis.
5. Planejar codecs/mídia apenas após validar o motor básico no hardware.

O teste host confirma só os cenários automatizados, não a compatibilidade com a web moderna.
