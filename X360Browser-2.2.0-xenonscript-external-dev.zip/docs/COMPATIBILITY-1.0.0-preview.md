# Compatibility matrix — X360Browser 1.0.0-preview

| Capability | Status | Notes |
|---|---|---|
| HTTP/HTTPS GET | Partial | libcurl; TLS peer/host verification enabled; bounded response |
| HTML title/text/links | Partial | custom lightweight parser; malformed/modern pages may be incomplete |
| Static CSS | Partial | small subset for a static flow, not full CSS layout |
| Link focus with controller | Supported in VisualLite | focus/activation and scroll tested on host; console still needs validation |
| Raster pixels | Partial | PNG/JPEG/GIF first frame/BMP/TGA/PSD/HDR/PNM via pinned stb_image when supplied by build script |
| WebP/SVG/AVIF/TIFF/JXL | Unsupported | extracted as resource metadata or placeholders only |
| Direct video file | Partial | bounded download up to 512 MiB and optional external player handoff |
| HLS VOD | Experimental/partial | unencrypted VOD, up to 256 segments and a 128 KiB manifest; downloads full file then hands off |
| HLS live / AES encryption / byte ranges | Unsupported | rejected with clear errors |
| MPEG-DASH | Unsupported | no DASH segment scheduler/merger |
| YouTube watch/embed playback | Unsupported | modern JS, adaptive stream logic, supported codecs and player APIs are absent |
| JavaScript / dynamic DOM | Unsupported | scripts are discovered but not run |
| HTML5 games / Canvas / WebGL / WebAssembly | Unsupported | no script runtime/game frame scheduler/graphics APIs |
| NetSurf engine | Not integrated | adapter remains a stub; NativePlus/VisualLite is active |
| PowerPC XEX build | Not yet verified here | GitHub Actions must complete successfully |
| Physical Xbox 360 | Not yet verified here | must be tested on RGH/JTAG hardware |

This preview must not be advertised as a fully compatible modern browser. “Stable 1.0.0” requires the target XEX to build, run on the console, and pass the chosen smoke-test matrix. Full games and YouTube require a real engine and media pipeline, not merely more HTML extraction.
