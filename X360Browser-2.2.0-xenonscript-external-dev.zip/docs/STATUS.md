# X360Browser 2.2.0-xenonscript-external-dev — status

## Implementado neste marco

- Motor próprio XenonWeb em C: parser DOM limitado, atributos/entidades HTML comuns e árvore de nós com limites explícitos.
- Parser CSS experimental ampliado: seletores de tag/classe/ID, descendente, filho direto, atributos e pseudoclasses selecionadas.
- Layout XenonWeb ligado ao renderer visual do Xbox, preservando VisualLite como fallback.
- XenonScript: interpretador limitado de scripts inline e até dois scripts externos síncronos pequenos (4 KiB cada), com variáveis simples, expressões básicas, `if/else`, leituras/mutações DOM selecionadas e orçamento de instruções.
- Dispatch de `onclick` para âncoras no quadro visual; âncoras `#fragment` passam a ser identificáveis e selecionáveis.
- Cache do documento para que handlers possam mutar DOM e invalidar a superfície sem reparse/reexecução de todo script.
- Scripts externos têm MIME reconhecido, TLS verificado, limite de tamanho/tempo, bloqueio de downgrade HTTPS→HTTP e proteção contra `</script` no conteúdo; `async`, `defer`, `module`, `nomodule` e SRI são ignorados.
- Testes host com compilação C17 e avisos estritos, incluindo fetch e execução de script externo no DOM, além de CSS, links, transporte, recursos raster e fallback.

## Componentes de suporte

- NativePlus/libcurl: transporte HTTP/HTTPS, validação TLS e descoberta de links/recursos.
- VisualLite: layout/renderização legado usado apenas como fallback.
- `netsurf_backend_stub.c`: stub; não é um motor completo integrado.
- Bibliotecas de terceiros são usadas em funções específicas (rede, criptografia, decodificação); não substituem XenonWeb/XenonScript como o motor de páginas.

## Não implementado / não compatível

- ECMAScript/JavaScript completo, event loop, funções/loops gerais, módulos, scripts async/defer, APIs de rede e eventos DOM completos.
- HTML/CSS completo, flexbox/grid reais e formulários completos; folhas CSS externas são buscadas sob limites e agregadas para o subconjunto CSS atual, não como um sistema de cascata completo.
- Canvas/WebGL/WebAssembly/WebSockets/service workers, apps SPA modernas e jogos web atuais.
- Reprodução inline de vídeo/YouTube e suporte de mídia completo.
- Cross-build PowerPC/xSDK, XEX validado e ensaio num Xbox 360 físico nesta entrega.

## Validação

`python3 tests/run_host_tests.py` e o build portátil CMake/CTest passaram no ambiente da entrega. Nenhum teste host substitui a compilação PowerPC, arranque no console, validação de controles, medição de memória/CPU ou ensaios com páginas reais.
