# Building X360Browser 2.2.0-xenonscript-external-dev for Xbox 360

The source workflow is `.github/workflows/build-xbox-engine.yml`. It runs host tests and strict checks, then attempts a PowerPC/xSDK cross-build and packages `X360Browser.xex` only if the expected output and runtime files exist. The source archive is named `X360Browser-2.2.0-xenonscript-external-dev.zip`; the console package, produced only after a successful cross-build, is `X360Browser-2.2.0-xenonscript-external-dev-xbox.zip`.

## Run the build from GitHub

1. Put the contents of this source archive at the root of the repository and commit/push them to the `main` branch.
2. Open the repository's **Actions** tab and select **Build X360Browser 2.2.0 XenonScript External dev**.
3. Select **Run workflow**. The host-test job runs first; only if it passes does the PowerPC/xSDK job start.
4. When the run finishes, open its **Artifacts** section. Download `X360Browser-2.2.0-xenonscript-external-dev-xbox` only if the build job succeeded. The source and build-log artifacts are uploaded even on a failed cross-build where GitHub Actions permits artifact upload.
5. If the cross-build fails, download the build-log artifact and fix the first real compiler/configuration error. A ZIP containing source or a failed log is not an XEX.

## Local build requirements

A compatible Xbox 360 xSDK/Xenon PowerPC toolchain plus the dependencies described by `tools/build_xbox_shell.sh` are required. Host tests can be run independently with:

```sh
python3 tests/run_host_tests.py
cmake -S . -B build -DX360BROWSER_BUILD_TESTS=ON -DCMAKE_BUILD_TYPE=Release
cmake --build build --parallel 2
ctest --test-dir build --output-on-failure
```

## Release gate

A successful cross-build proves only that an XEX was produced. Before calling the app usable, test a physical RGH/JTAG console: cold launch, controller navigation, HTTP/HTTPS with a current CA bundle, simple HTML/CSS pages, images, script/anchor handling, focus/scroll, malformed/oversized HTML and memory use. Host tests do not establish these results. This build does not provide full ECMAScript, Canvas/WebGL/WebAssembly, inline video or modern-game compatibility.
