# X360Browser 2.2.0-xenonscript-external-dev — architecture

## Main parts

- `engine/xenonweb/xw_dom.c`: in-project bounded HTML DOM parser/tree and controlled text/attribute mutation.
- `engine/xenonweb/xw_css.c`: in-project limited CSS parser and computed styles.
- `engine/xenonweb/xw_script.c`: XenonScript, a bounded interpreter for a narrow inline-script subset.
- `engine/xenonweb/xw_layout.c`: converts the DOM/style subset into `WebVisualFrame` arrays and dispatches supported inline anchor handlers.
- `platform/xbox360/xsdk/visual_renderer.c`: paints the visual frame and controller-focus rectangles.
- `platform/xbox360/xsdk/web_engine.c`: network transport, bounded external stylesheet/script fetching, HTML metadata/link/resource inventory and legacy media handoff; it is not the primary layout/script engine.
- `platform/xbox360/xsdk/visual_layout.c`: legacy layout fallback.
- `platform/xbox360/xsdk/netsurf_backend_stub.c`: capability stub only; no real NetSurf engine is linked.

## Render path

The UI passes a fetched `WebEnginePage` to XenonWeb. On a new page, the bounded parser builds the DOM and XenonScript executes permitted inline script text once. XenonWeb then collects style blocks, computes the supported CSS subset and creates the visual frame. A supported `onclick` handler can mutate the retained DOM; the frame cache is invalidated so the next draw reflects the mutation. If XenonWeb cannot build the frame, the legacy visual layout is retained as a fallback.

## Design boundary

This is a first-party browser engine under active development, not a standards-complete engine. XenonScript is not ECMAScript; the engine lacks complete HTML5/CSS, event loop, full form behavior, Canvas/WebGL/WebAssembly, in-page video decode and modern web-app APIs. Libraries for HTTP/TLS or raster decoding handle supporting tasks rather than substituting a third-party browser engine.
