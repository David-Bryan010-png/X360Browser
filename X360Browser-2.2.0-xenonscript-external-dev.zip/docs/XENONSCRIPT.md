# XenonScript — interpretador de script próprio (experimental)

XenonScript é uma camada escrita para este projeto e conectada à árvore DOM XenonWeb. Seu objetivo imediato é habilitar alterações simples de página sem portar um runtime enorme para o orçamento de memória do Xbox 360. **Não é uma implementação de JavaScript/ECMAScript e não deve ser usada para anunciar compatibilidade com sites modernos.**

## Recursos atualmente implementados

- Script inline no documento e execução na ordem do documento. O transporte pode materializar, em sua posição original, até dois scripts externos síncronos pequenos (4 KiB por arquivo; 8 KiB somados) com MIME JavaScript reconhecido. O conteúdo ainda é executado somente pelo subset XenonScript; respostas com MIME que não indique JavaScript e arquivos acima do limite são rejeitados. A execução ocorre depois da criação da árvore DOM e não implementa a semântica de bloqueio do parser de um navegador completo.
- Declarações `var`, `let` e `const` sobre um conjunto limitado de valores/variáveis.
- Literais de texto, números e booleanos; operações aritméticas e comparações básicas.
- Declarações `if/else` simples.
- `document.getElementById(...)` e `document.querySelector(...)` no subconjunto de seletores suportado.
- Leitura/alteração limitada de `textContent` e `innerText`; propriedades `id`, `className`, `value`, `href`, `src`; `setAttribute(...)`.
- `document.title`, `console.log(...)` para telemetria de teste e `alert(...)` como saída diagnóstica limitada.
- `onclick` inline em âncoras selecionadas pelo renderer; o interpretador é chamado com orçamento de instruções limitado.

## Limites deliberados

A implementação rejeita sintaxe que não suporta. Entre os recursos ausentes estão funções, `while`/`for` gerais, callbacks, objetos/arrays gerais, protótipos, classes, módulos, `try/catch`, promises, async/await, timers, event loop, `addEventListener`, propagação/cancelamento de eventos, fetch/XHR, cookies, storage, APIs de rede, WebSockets, Canvas, WebGL e WebAssembly.

A execução é síncrona e limitada; `async`, `defer`, `type=module`, `nomodule` e scripts com `integrity` são ignorados porque os respectivos modelos de execução/verificação não existem aqui. Redirect HTTPS→HTTP, MIME não reconhecido, corpo binário, script excessivo e conteúdo contendo `</script` são rejeitados. Não há heap JavaScript geral nem coleta de lixo ECMAScript. Falhar ao interpretar uma linha não significa que o site tenha sido executado parcialmente de modo compatível com navegadores. Um script pode depender de APIs ausentes e não funcionar.

## Guardas e testes

O parser usa limites finitos de comprimento de script, tokens, profundidade e instruções. Os testes incluem mutação de DOM, variáveis compartilhadas entre scripts, `if/else`, atributo de DOM e rejeição controlada de `while(true)`. Execute:

```sh
python3 tests/run_host_tests.py
```

Os testes são executados no host. Ainda falta cross-compilar o alvo PowerPC, medir custo real de CPU/stack/memória e testar no Xbox 360 físico. Os limites e a sintaxe do interpretador podem mudar durante o desenvolvimento.
