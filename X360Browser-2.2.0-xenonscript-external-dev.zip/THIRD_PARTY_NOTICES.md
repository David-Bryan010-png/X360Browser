# Third-party component notices

The Xbox web-engine build downloads and statically links third-party components. Their upstream notices remain authoritative:

- **xSDK** — MIT: https://github.com/xenosworks/xsdk/blob/main/LICENSE
- **curl / libcurl (curl-xenon)** — curl license: https://github.com/xenosworks/curl-xenon/blob/xenon/COPYING
- **Mbed TLS (mbedtls-xenon)** — Apache-2.0 OR GPL-2.0-or-later, as stated upstream: https://github.com/xenosworks/mbedtls-xenon/blob/xenon/LICENSE
- **stb_image** — image decoder from `nothings/stb`, pinned revision `003501f6d7a8668ce8b6d875e34dd97ad0d5d5b5`; license included as `LICENSE-stb_image.txt` in the XEX package: https://github.com/nothings/stb
- **Mozilla CA certificate bundle** — supplied by the Mbed TLS port. It is runtime data and must remain beside `X360Browser.xex` for HTTPS verification.

The source archive contains the thin stb_image implementation wrapper; the build script fetches the exact upstream header and license before CMake configures the XEX target.
