#include "visual_layout.h"

#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

static int text_contains(const WebVisualFrame *frame, const char *needle)
{
    size_t i;
    for (i = 0U; i < frame->text_count; ++i)
        if (strstr(frame->texts[i].text, needle) != NULL) return 1;
    return 0;
}

int main(void)
{
    static const char html[] =
        "<html><head><title>Not shown in page flow</title>"
        "<style>body { background-color: #eeeeee; }"
        "h1 { color: #ff0000; font-size: 30px; }"
        ".card { background-color: #ddeeff; padding: 8px; border: 1px solid #aabbcc; }"
        "a { color: #0000ff; }.hidden { display: none; }</style></head>"
        "<body style='background-color:#fafafa'><div class='card'>"
        "<h1 id='hero'>Visual test heading</h1>"
        "<p style='color:#008000'>Green paragraph text for layout</p>"
        "<a href='/go'>Visit test link</a>"
        "<a href='next.html'>Relative next link</a>"
        "<p class='hidden'>SHOULD NOT SHOW</p>"
        "<p style='text-align:right'>Right aligned marker</p>"
        "<img src='/tiny.png' alt='Image placeholder' width='120' height='50'>"
        "<input placeholder='Search field'><video></video>"
        "</div></body></html>";
    WebEnginePage page;
    WebVisualFrame frame;
    size_t i;
    int saw_heading_color = 0;
    int saw_body_background = 0;
    int saw_link_color = 0;
    int saw_right_alignment = 0;
    int link_text_y = -1;
    int link_rect_y = -1;
    size_t unscrolled_content_height;
    memset(&page, 0, sizeof(page));
    (void)snprintf(page.page_url, sizeof(page.page_url), "https://example.test/page.html");
    page.link_count = 2U;
    (void)snprintf(page.links[0].url, sizeof(page.links[0].url), "https://example.test/go");
    (void)snprintf(page.links[0].label, sizeof(page.links[0].label), "Visit test link");
    (void)snprintf(page.links[1].url, sizeof(page.links[1].url), "https://example.test/next.html");
    (void)snprintf(page.links[1].label, sizeof(page.links[1].label), "Relative next link");
    memcpy(page.source_html, html, sizeof(html));
    page.source_html_length = sizeof(html) - 1U;
    page.image_count = 1U;
    (void)snprintf(page.images[0].url, sizeof(page.images[0].url), "https://example.test/tiny.png");
    (void)snprintf(page.images[0].alt, sizeof(page.images[0].alt), "Image placeholder");
    (void)snprintf(page.images[0].cache_path, sizeof(page.images[0].cache_path), "X360Browser-cache-test.png");
    web_visual_layout_legacy(&page, 0U, &frame);
    assert(frame.text_count >= 5U);
    assert(frame.rect_count >= 4U);
    assert(frame.background == 0xFFFAFAFAU);
    assert(text_contains(&frame, "Visual test heading"));
    assert(text_contains(&frame, "Green paragraph text"));
    assert(text_contains(&frame, "Visit test link"));
    assert(text_contains(&frame, "Image placeholder"));
    assert(frame.image_count == 1U);
    assert(frame.images[0].width == 120 && frame.images[0].height == 50);
    assert(frame.images[0].placeholder_text_index < frame.text_count);
    assert(text_contains(&frame, "Search field"));
    assert(frame.link_count == 2U);
    assert(frame.links[0].page_link_index == 0U);
    assert(frame.links[1].page_link_index == 1U);
    assert(frame.links[0].width > 0 && frame.links[1].width > 0);
    assert(!text_contains(&frame, "Not shown in page flow"));
    assert(!text_contains(&frame, "SHOULD NOT SHOW"));
    for (i = 0U; i < frame.text_count; ++i) {
        if (strstr(frame.texts[i].text, "Visual test heading") != NULL && frame.texts[i].color == 0xFFFF0000U)
            saw_heading_color = 1;
        if (strstr(frame.texts[i].text, "Visit test link") != NULL && frame.texts[i].color == 0xFF0000FFU) {
            saw_link_color = 1;
            link_text_y = frame.texts[i].y;
        }
        if (strstr(frame.texts[i].text, "Right aligned marker") != NULL && frame.texts[i].x > 700)
            saw_right_alignment = 1;
    }
    link_rect_y = frame.links[0].y;
    unscrolled_content_height = frame.content_height;
    for (i = 0U; i < frame.rect_count; ++i)
        if (frame.rects[i].color == 0xFFDDEEFFU) saw_body_background = 1;
    assert(saw_heading_color);
    assert(saw_link_color);
    assert(saw_right_alignment);
    assert(saw_body_background);
    assert(frame.content_height > 100U);

    web_visual_layout_legacy(&page, 60U, &frame);
    assert(frame.content_height == unscrolled_content_height);
    assert(frame.link_count == 2U);
    assert(frame.links[0].y == link_rect_y - 60);
    for (i = 0U; i < frame.text_count; ++i) {
        if (strstr(frame.texts[i].text, "Visit test link") != NULL)
            assert(frame.texts[i].y == link_text_y - 60);
    }
    {
        WebEnginePage text_page;
        char *cursor;
        size_t line;
        memset(&text_page, 0, sizeof(text_page));
        cursor = text_page.text;
        for (line = 0U; line < 30U; ++line) {
            int written = snprintf(cursor, sizeof(text_page.text) - (size_t)(cursor - text_page.text),
                                   "line %02lu\n", (unsigned long)line);
            assert(written > 0);
            cursor += written;
        }
        text_page.text_length = (size_t)(cursor - text_page.text);
        web_visual_layout_legacy(&text_page, 200U, &frame);
        assert(frame.content_height >= 600U);
        assert(frame.text_count > 0U);
        assert(frame.texts[0].y >= -16 && frame.texts[0].y < WEB_VISUAL_HEIGHT - 12);
        assert(strstr(frame.texts[0].text, "line 09") != NULL);
    }
    puts("PASS: VisualLite HTML/CSS, right alignment, link geometry, stable content height and one-time scrolling");
    return 0;
}
