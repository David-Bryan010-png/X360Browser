#include "../engine/xenonweb/xw_dom.h"
#include "../engine/xenonweb/xw_css.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static int failures;
static void check(int condition, const char *name)
{
    if (condition) printf("PASS: %s\n", name);
    else { printf("FAIL: %s\n", name); ++failures; }
}

int main(void)
{
    static const char html[] =
        "<!doctype html><html><head><title>Demo &amp; test</title>"
        "<style>body { color: #222222; } .card { background: #abc; padding: 12px; }"
        "#headline { color: red; font-size: 24px; } main .card a { font-weight: bold; }"
        "#selector-probe > p:first-child { color: orange; }"
        "#selector-probe > p.keep:last-child { background: #abc; }"
        "input[type=\"submit\"] { font-weight: bold; }"
        "p:not(.keep) { margin-bottom: 13px; }</style>"
        "<script>if (a < b) { x = '<tag>'; }</script></head>"
        "<body><main><div id='hero' class='card active' style='text-align:center;color:blue'>"
        "<h1 id='headline'>A &lt; B</h1><p class='copy'>First &nbsp; paragraph</p>"
        "<a href='/play'>Start game</a><img src='hero.png' alt='Hero'></div>"
        "<section id='selector-probe'><p id='first-child'>First</p><p id='last-child' class='keep'>Last</p></section>"
        "<input id='submit' type='submit' value='Go'></main></body></html>";
    XwDocument *doc = (XwDocument *)calloc(1U, sizeof(*doc));
    XwStylesheet *sheet = (XwStylesheet *)calloc(1U, sizeof(*sheet));
    XwComputedStyle body_style, hero_style, heading_style, link_style;
    XwComputedStyle first_style, last_style, submit_style;
    uint16_t body, hero, heading, link, script, first_child, last_child, submit;
    int ok;
    if (doc == NULL || sheet == NULL) return 2;
    ok = xw_dom_parse(doc, html, sizeof(html) - 1U);
    check(ok, "DOM parses nested HTML within fixed memory budget");
    check(xw_dom_find_by_id(doc, "hero") != XW_DOM_NONE, "DOM id lookup finds elements");
    hero = xw_dom_find_by_id(doc, "hero");
    check(xw_dom_has_class(doc, hero, "card") && xw_dom_has_class(doc, hero, "active"),
          "DOM class lookup supports multiple class tokens");
    check(strcmp(xw_dom_attribute(doc, hero, "style"), "text-align:center;color:blue") == 0,
          "DOM preserves inline attributes and case-insensitive attribute access");
    heading = xw_dom_find_by_id(doc, "headline");
    check(heading != XW_DOM_NONE && strcmp(xw_dom_attribute(doc, heading, "id"), "headline") == 0,
          "DOM stores common attributes");
    check(strcmp(xw_dom_string(doc, doc->nodes[doc->nodes[heading].first_child].value_offset), "A < B") == 0,
          "HTML named entities are decoded in text nodes");
    script = XW_DOM_NONE;
    for (size_t i = 0U; i < doc->node_count; ++i) {
        if (doc->nodes[i].type == XW_NODE_ELEMENT &&
            strcmp(xw_dom_string(doc, doc->nodes[i].name_offset), "script") == 0) script = (uint16_t)i;
    }
    check(script != XW_DOM_NONE && doc->nodes[script].first_child != XW_DOM_NONE &&
          strstr(xw_dom_string(doc, doc->nodes[doc->nodes[script].first_child].value_offset), "<tag>") != NULL,
          "script raw text does not get tokenized as HTML markup");
    xw_css_init(sheet);
    xw_css_collect_document_styles(sheet, doc);
    check(sheet->rule_count >= 4U, "CSS parser discovers embedded stylesheet rules");
    body = XW_DOM_NONE;
    link = XW_DOM_NONE;
    for (size_t i = 0U; i < doc->node_count; ++i) {
        const char *tag = xw_dom_string(doc, doc->nodes[i].name_offset);
        if (doc->nodes[i].type == XW_NODE_ELEMENT && strcmp(tag, "body") == 0) body = (uint16_t)i;
        if (doc->nodes[i].type == XW_NODE_ELEMENT && strcmp(tag, "a") == 0) link = (uint16_t)i;
    }
    xw_css_compute(sheet, doc, body, NULL, &body_style);
    xw_css_compute(sheet, doc, hero, &body_style, &hero_style);
    xw_css_compute(sheet, doc, heading, &hero_style, &heading_style);
    xw_css_compute(sheet, doc, link, &hero_style, &link_style);
    check(body_style.color == 0xFF222222U, "CSS type selector applies color");
    check(hero_style.background_color == 0xFFAABBCCU && hero_style.padding == 12,
          "CSS class selector applies background and padding");
    check(hero_style.align == XW_ALIGN_CENTER && hero_style.color == 0xFF0000FFU,
          "inline CSS overrides stylesheet values at higher specificity");
    check(heading_style.color == 0xFFFF0000U && heading_style.font_size_px == 24,
          "CSS id selector overrides inherited text style");
    check(link_style.bold == 1, "CSS descendant selector matches nested links");
    first_child = xw_dom_find_by_id(doc, "first-child");
    last_child = xw_dom_find_by_id(doc, "last-child");
    submit = xw_dom_find_by_id(doc, "submit");
    xw_css_compute(sheet, doc, first_child, &body_style, &first_style);
    xw_css_compute(sheet, doc, last_child, &body_style, &last_style);
    xw_css_compute(sheet, doc, submit, &body_style, &submit_style);
    check(first_child != XW_DOM_NONE && first_style.color == 0xFFFFA500U,
          "CSS direct-child combinator and first-child pseudo-class match");
    check(last_child != XW_DOM_NONE && last_style.background_color == 0xFFAABBCCU,
          "CSS last-child pseudo-class and class compound selector match");
    check(submit != XW_DOM_NONE && submit_style.bold == 1,
          "CSS attribute selector matches input type");
    {
        XwStylesheet malformed;
        static const char unterminated_comment[] = {'/', '*', 'n', 'o', ' ', 't', 'e', 'r', 'm'};
        xw_css_init(&malformed);
        (void)xw_css_parse(&malformed, unterminated_comment, sizeof(unterminated_comment));
        check(malformed.truncated == 1, "CSS comment scanner stays within a non-NUL-terminated input buffer");
    }
    {
        XwDomStats stats;
        xw_dom_get_stats(doc, sizeof(html) - 1U, &stats);
        check(stats.node_count == doc->node_count && stats.string_bytes <= XW_DOM_STRING_POOL_SIZE,
              "DOM telemetry reports bounded allocations");
    }
    free(sheet); free(doc);
    if (failures) { printf("%d XENONWEB test(s) failed\n", failures); return 1; }
    printf("All XenonWeb DOM/CSS host tests passed\n");
    return 0;
}
