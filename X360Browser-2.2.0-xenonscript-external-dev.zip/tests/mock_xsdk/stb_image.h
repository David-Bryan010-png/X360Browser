#ifndef TEST_STB_IMAGE_H
#define TEST_STB_IMAGE_H
#ifdef __cplusplus
extern "C" {
#endif
unsigned char *stbi_load(const char *filename, int *x, int *y, int *channels_in_file, int desired_channels);
int stbi_info(const char *filename, int *x, int *y, int *channels_in_file);
void stbi_image_free(void *retval_from_stbi_load);
#ifdef __cplusplus
}
#endif
#endif
