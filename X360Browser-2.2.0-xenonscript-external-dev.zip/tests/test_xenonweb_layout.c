#include "../platform/xbox360/xsdk/visual_layout.h"
#include <stdio.h>
#include <string.h>

static int failures;
static void check(int condition, const char *name)
{
    if (condition) printf("PASS: %s\n", name);
    else { printf("FAIL: %s\n", name); ++failures; }
}

int main(void)
{
    static const char html[] =
        "<!doctype html><html><head><title>hidden title</title>"
        "<style>body{background:#f0f0f0;color:#222} .card{background:#abc;padding:8px}"
        "#special{color:red;font-size:24px} .hide{display:none} main .card a{font-weight:bold}</style>"
        "<script>document.getElementById('runtime').textContent = 'XenonScript is active';</script></head>"
        "<body><main><div class='card'><h1 id='special'>XenonWeb Engine</h1>"
        "<p id='runtime'>static fallback text</p>"
        "<p>DOM and CSS are active.</p><a href='/play'>Open game page</a>"
        "<a href='#run' onclick=\"document.getElementById('runtime').textContent = 'Clicked by script';\">Run action</a>"
        "<p class='hide'>THIS SHOULD NOT RENDER</p><img src='/hero.png' alt='Hero artwork' width='180' height='60'>"
        "</div></main></body></html>";
    WebEnginePage page;
    WebVisualFrame frame;
    size_t i;
    int found_title = 0, found_hidden = 0, found_anchor = 0, found_image = 0, found_styled_box = 0;
    int found_script_text = 0;
    memset(&page, 0, sizeof(page));
    (void)snprintf(page.page_url, sizeof(page.page_url), "%s", "https://example.com/index.html");
    memcpy(page.source_html, html, sizeof(html));
    page.source_html_length = sizeof(html) - 1U;
    page.link_count = 2U;
    (void)snprintf(page.links[0].url, sizeof(page.links[0].url), "%s", "https://example.com/play");
    (void)snprintf(page.links[0].label, sizeof(page.links[0].label), "%s", "Open game page");
    (void)snprintf(page.links[1].url, sizeof(page.links[1].url), "%s", "https://example.com/index.html#run");
    (void)snprintf(page.links[1].label, sizeof(page.links[1].label), "%s", "Run action");

    web_visual_layout(&page, 0U, &frame);
    check(frame.text_count > 0U, "new XenonWeb path emits visible text runs");
    check(frame.background == 0xFFF0F0F0U, "body background CSS is applied to page surface");
    for (i = 0U; i < frame.text_count; ++i) {
        if (strstr(frame.texts[i].text, "XenonScript is active") != NULL) found_script_text = 1;
        if (strstr(frame.texts[i].text, "XenonWeb Engine") != NULL) {
            found_title = 1;
            check(frame.texts[i].color == 0xFFFF0000U && frame.texts[i].scale >= 2U,
                  "ID CSS selector affects visible heading style");
        }
        if (strstr(frame.texts[i].text, "THIS SHOULD NOT RENDER") != NULL) found_hidden = 1;
        if (strstr(frame.texts[i].text, "[Image: Hero artwork]") != NULL) found_image = 1;
    }
    for (i = 0U; i < frame.link_count; ++i)
        if (frame.links[i].page_link_index == 0U && frame.links[i].width > 0) found_anchor = 1;
    for (i = 0U; i < frame.rect_count; ++i)
        if (frame.rects[i].color == 0xFFAABBCCU) found_styled_box = 1;
    check(found_title, "styled heading is present");
    check(found_script_text, "first-party script runtime mutates the DOM before visual rendering");
    check(!found_hidden, "display:none subtree is not rendered");
    check(found_anchor, "relative anchor maps to browser's canonical link index");
    check(found_image, "image element creates an accessible placeholder");
    check(found_styled_box, "CSS background is represented by GPU rectangle");
    {
        int navigation_consumed = 0;
        WebVisualFrame changed;
        int dispatched = web_visual_dispatch_link(&page, 1U, &navigation_consumed);
        web_visual_layout(&page, 0U, &changed);
        check(dispatched && navigation_consumed,
              "focused fragment anchor dispatches its inline onclick handler without navigation");
        found_script_text = 0;
        for (i = 0U; i < changed.text_count; ++i)
            if (strstr(changed.texts[i].text, "Clicked by script") != NULL) found_script_text = 1;
        check(found_script_text, "event-handler DOM mutations invalidate and rebuild the visual frame");
    }
    {
        WebVisualFrame scrolled;
        size_t original_height = frame.content_height;
        web_visual_layout(&page, 35U, &scrolled);
        check(scrolled.content_height == original_height, "scrolling preserves document content height");
        check(scrolled.text_count > 0U && scrolled.texts[0].y == frame.texts[0].y - 35,
              "viewport scroll is applied exactly once to generated text");
    }
    if (failures) { printf("%d XenonWeb layout test(s) failed\n", failures); return 1; }
    printf("All XenonWeb layout tests passed\n");
    return 0;
}
