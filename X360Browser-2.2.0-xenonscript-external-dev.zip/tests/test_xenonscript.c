#include "xw_dom.h"
#include "xw_script.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static int failures;
static void check(int condition, const char *name)
{
    if (condition) printf("PASS: %s\n", name);
    else { printf("FAIL: %s\n", name); ++failures; }
}

int main(void)
{
    static const char html[] =
        "<html><head><title>Before</title>"
        "<script>var n = 5; if (n > 3) { document.getElementById('message').textContent = 'Changed ' + n; } else { document.getElementById('message').textContent = 'Wrong'; }</script>"
        "<script>var target = document.querySelector('#message'); target.setAttribute('style', 'color:red'); console.log('ready');</script>"
        "</head><body><p id='message'>Initial</p><p id='other'>Keep</p></body></html>";
    XwDocument *document = (XwDocument *)calloc(1U, sizeof(*document));
    XwScriptStats stats;
    uint16_t message;
    char text[128];
    int ok;
    if (document == NULL) return 2;
    check(xw_dom_parse(document, html, sizeof(html) - 1U), "DOM parsed before script execution");
    ok = xw_script_run_document(document, 1000U, &stats);
    check(ok, "bounded XenonScript executes supported inline scripts");
    message = xw_dom_find_by_id(document, "message");
    (void)xw_dom_text_content(document, message, text, sizeof(text));
    check(strcmp(text, "Changed 5") == 0, "if/else, variables, addition and textContent mutation work");
    check(strcmp(xw_dom_attribute(document, message, "style"), "color:red") == 0,
          "setAttribute writes a DOM attribute used by style recalculation");
    check(stats.script_elements == 2U && stats.executed_scripts == 2U,
          "multiple inline scripts execute in document order with shared globals");
    check(stats.dom_mutations >= 2U && stats.console_calls == 1U && stats.errors == 0U,
          "script telemetry records mutations and console calls");
    {
        static const char unsafe_html[] =
            "<html><script>while (true) { }</script><body><p>Safe fallback</p></body></html>";
        XwScriptStats unsafe_stats;
        check(xw_dom_parse(document, unsafe_html, sizeof(unsafe_html) - 1U), "second document resets bounded DOM");
        check(!xw_script_run_document(document, 100U, &unsafe_stats) && unsafe_stats.errors == 1U,
              "unsupported unbounded loops fail closed instead of hanging the console");
    }
    free(document);
    if (failures) { printf("%d XenonScript test(s) failed\n", failures); return 1; }
    printf("All XenonScript tests passed\n");
    return 0;
}
