#include "../platform/xbox360/xsdk/web_engine.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(void)
{
    WebEnginePage *page = (WebEnginePage *)calloc(1U, sizeof(*page));
    char error[192] = {0};
    int ok;
    if (page == NULL) {
        fputs("FAIL: page allocation\n", stderr);
        return 1;
    }
    if (!web_engine_init()) {
        fputs("FAIL: dispatcher initialization\n", stderr);
        free(page);
        return 1;
    }
    ok = web_engine_fetch("http://127.0.0.1:18765/page.html", page, error, sizeof(error));
    if (!ok) {
        fprintf(stderr, "FAIL: dispatcher fetch: %s\n", error);
        web_engine_shutdown();
        free(page);
        return 1;
    }
    if (page->backend_used != WEB_ENGINE_BACKEND_NATIVE_PLUS) {
        fputs("FAIL: NativePlus was not selected when NetSurf is unavailable\n", stderr);
        web_engine_shutdown();
        free(page);
        return 1;
    }
    if (page->used_fallback != 0) {
        fputs("FAIL: startup selection must not be reported as page-level fallback\n", stderr);
        web_engine_shutdown();
        free(page);
        return 1;
    }
    if (strstr(page->fallback_reason, "not linked") == NULL) {
        fputs("FAIL: missing honest NetSurf capability status\n", stderr);
        web_engine_shutdown();
        free(page);
        return 1;
    }
    if (strcmp(web_engine_backend_label(), "AUTO: NativePlus active (NetSurf not linked)") != 0) {
        fputs("FAIL: backend label does not describe this build\n", stderr);
        web_engine_shutdown();
        free(page);
        return 1;
    }
    web_engine_shutdown();
    free(page);
    puts("PASS: dispatcher selects NativePlus when the real NetSurf backend is unavailable");
    return 0;
}
