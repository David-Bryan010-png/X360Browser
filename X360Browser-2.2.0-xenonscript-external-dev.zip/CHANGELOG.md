## 2.2.0-xenonscript-external-dev — scripts externos limitados e integração reforçada

- Adicionado carregamento seguro e limitado de scripts externos síncronos com MIME JavaScript reconhecido; cada recurso possui limite de 4 KiB e são permitidos no máximo dois por página.
- Scripts externos elegíveis são materializados no HTML em sua posição original; o XenonScript restrito os executa em ordem documental depois de construir o DOM (sem semântica completa de bloqueio do parser).
- Scripts `async`, `defer`, `module`, `nomodule` e com `integrity` permanecem sem execução; redirects HTTPS para HTTP, MIME inesperado, scripts grandes e fechamento HTML perigoso são rejeitados.
- Teste de integração host busca um script local pelo HTTP fixture, injeta-o na página e verifica a mutação DOM; scripts acima do limite e payloads com MIME incorreto são rejeitados.
- Corrigidos nomes/metadados atuais do build e documentação sobre limites reais.
- Não inclui runtime ECMAScript completo, Canvas/WebGL/WebAssembly, vídeo inline ou validação física do XEX.

## 2.1.0-xenonscript-dev — XenonWeb + XenonScript (desenvolvimento)

- Ampliado o motor próprio de CSS com combinador filho direto, seletores de atributo e pseudoclasses selecionadas.
- Adicionado XenonScript, um interpretador controlado de scripts inline: variáveis, expressões simples, `if/else` e mutações DOM selecionadas.
- Conectadas mutações de DOM ao layout visual; `onclick` inline de âncoras recebe dispatch limitado no controle A.
- Âncoras `#fragment` permanecem na lista de links e podem disparar handlers locais.
- Adicionados testes para script, CSS, links fragmentários e invalidação/reconstrução de quadro.
- Atualizados versionamento, workflow e documentação para explicitar que XenonScript não é JavaScript completo.
- Sem XEX validado nesta entrega: build PowerPC/xSDK e teste físico ainda são gates pendentes.

## 2.0.0-engine-dev — novo núcleo XenonWeb (desenvolvimento)

- Adicionado um parser DOM próprio, limitado por memória, em `engine/xenonweb/xw_dom.c`.
- Adicionado parser/cascade CSS experimental para um subconjunto de seletores e propriedades.
- Ligado o layout XenonWeb às estruturas `WebVisualFrame`, preservando o layout legado como fallback.
- Adicionados testes de host DOM/CSS/layout e cache simples de layout por identidade da página.
- Corrigido o tratamento de comentários CSS para obedecer ao tamanho declarado do buffer.
- Limitações explícitas: sem JavaScript, APIs web dinâmicas, Canvas/WebGL/WebAssembly, vídeo embutido ou integração real de NetSurf; XEX e console ainda não validados.

# Changelog

## 1.0.0-preview — base de multimídia limitada e imagens raster

- Substituído o decodificador PNG-only por `stb_image`, com suporte raster comum e limites de dimensões/memória.
- Download de imagens aceita MIME raster permitido, valida assinatura e limita cada arquivo a 1 MiB.
- Adicionado downloader de HLS VOD com seleção da variante de menor largura de banda, resolução de URLs relativos e até 256 segmentos.
- HLS live, criptografia, byte-ranges e MPEG-DASH são rejeitados explicitamente; não tentamos ignorar DRM.
- Links de HLS VOD extraídos de `<video>/<source>` ficam selecionáveis e usam o fluxo de download/handoff de player externo.
- Corrigidos nomes de versão, labels do XEX, documentação, licença do decodificador e workflow por ZIP.
- Ampliados os testes de imagem e listas HLS; ver `TEST-RESULTS.txt`.
- **Ainda bloqueado:** motor de HTML/DOM/CSS completo, JavaScript, Canvas/WebGL/WebAssembly, jogos web modernos, YouTube watch pages e reprodução embutida.

## 0.9.0 — navegação visual

- Links visuais acionáveis pelo controle, correção da rolagem duplicada e alinhamento à direita.
- Melhor relação entre URLs base/redirecionadas e geometria dos links.

## 0.8.0 — VisualLite estático

- Renderizador HTML/CSS estático, extração de metadados e links, descoberta de recursos e cache limitado de imagens PNG.
