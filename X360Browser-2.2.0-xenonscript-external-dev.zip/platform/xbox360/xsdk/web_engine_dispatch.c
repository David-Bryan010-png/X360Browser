#include "web_engine.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static int g_native_ready;
static int g_netsurf_ready;
static char g_last_fallback[WEB_ENGINE_FALLBACK_REASON_CAP];

int web_engine_init(void)
{
    g_netsurf_ready = netsurf_backend_init();
    g_native_ready = web_engine_native_init();
    if (!g_netsurf_ready) {
        (void)snprintf(g_last_fallback, sizeof(g_last_fallback), "%s",
                       netsurf_backend_status());
    } else {
        g_last_fallback[0] = '\0';
    }
    return g_native_ready || g_netsurf_ready;
}

void web_engine_shutdown(void)
{
    if (g_netsurf_ready)
        netsurf_backend_shutdown();
    if (g_native_ready)
        web_engine_native_shutdown();
    g_netsurf_ready = 0;
    g_native_ready = 0;
}

int web_engine_fetch(const char *url, WebEnginePage *page,
                     char *error, size_t error_capacity)
{
    int result;
    if (page == NULL) {
        if (error != NULL && error_capacity > 0U)
            (void)snprintf(error, error_capacity, "No page buffer provided");
        return 0;
    }

    /* Engine 1: NetSurf, when its real Xbox renderer has been linked. */
    if (g_netsurf_ready) {
        WebEnginePage *netsurf_page = (WebEnginePage *)calloc(1U, sizeof(*netsurf_page));
        if (netsurf_page != NULL) {
            result = netsurf_backend_fetch(url, netsurf_page, error, error_capacity);
            if (result != 0) {
                *page = *netsurf_page;
                if (page->page_url[0] == '\0')
                    (void)snprintf(page->page_url, sizeof(page->page_url), "%s", url);
                page->backend_used = WEB_ENGINE_BACKEND_NETSURF;
                page->used_fallback = 0;
                page->fallback_reason[0] = '\0';
                free(netsurf_page);
                return 1;
            }
            free(netsurf_page);
            (void)snprintf(g_last_fallback, sizeof(g_last_fallback), "%s",
                           error != NULL && error[0] != '\0' ? error :
                           "NetSurf declined this page; NativePlus took over");
        }
    }

    /* Engine 2: small native parser/network path, intentionally safe on failure. */
    if (!g_native_ready) {
        if (error != NULL && error_capacity > 0U)
            (void)snprintf(error, error_capacity, "No usable web engine is initialized");
        return 0;
    }
    result = web_engine_native_fetch(url, page, error, error_capacity);
    if (result != 0) {
        if (page->page_url[0] == '\0')
            (void)snprintf(page->page_url, sizeof(page->page_url), "%s", url);
        page->backend_used = WEB_ENGINE_BACKEND_NATIVE_PLUS;
        /* The stub means NativePlus is selected at startup, not after a page-level fallback. */
        page->used_fallback = g_netsurf_ready ? 1 : 0;
        if (g_netsurf_ready) {
            (void)snprintf(page->fallback_reason, sizeof(page->fallback_reason), "%s",
                           g_last_fallback[0] != '\0' ? g_last_fallback :
                           "NetSurf could not load this page; NativePlus fallback used");
        } else {
            (void)snprintf(page->fallback_reason, sizeof(page->fallback_reason), "%s",
                           "NetSurf is not linked in this build; NativePlus selected automatically");
        }
    }
    return result;
}

const char *web_engine_backend_label(void)
{
    if (g_netsurf_ready)
        return "AUTO: NetSurf -> NativePlus fallback";
    return "AUTO: NativePlus active (NetSurf not linked)";
}
