#include "web_engine.h"

#include <stdio.h>

/*
 * Deliberately honest capability stub.
 *
 * NetSurf is the preferred future renderer, but it is not yet a linked engine
 * in X360Browser.  The real port must provide NetSurf's core libraries and a
 * framebuffer/plotter bridge to xSDK before this backend can report ready.
 * Keeping this adapter separate lets the dispatcher try NetSurf first when
 * that integration exists without risking the working NativePlus fallback.
 */

int netsurf_backend_init(void)
{
    return 0;
}

void netsurf_backend_shutdown(void)
{
}

int netsurf_backend_fetch(const char *url, WebEnginePage *page,
                          char *error, size_t error_capacity)
{
    (void)url;
    (void)page;
    if (error != NULL && error_capacity > 0U) {
        (void)snprintf(error, error_capacity,
                       "NetSurf renderer is not linked into this XEX");
    }
    return 0;
}

const char *netsurf_backend_status(void)
{
    return "NetSurf adapter present; rendering libraries not linked";
}
