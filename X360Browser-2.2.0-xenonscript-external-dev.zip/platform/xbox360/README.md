# Xbox 360 target — X360Browser 2.2.0-xenonscript-external-dev

The xSDK target connects the project-owned XenonWeb DOM/CSS/layout engine and the bounded XenonScript interpreter to the visual renderer. XenonScript is a deliberately small first-party inline-script subset, not full ECMAScript. NativePlus supplies HTTP/HTTPS transport and VisualLite remains a rendering fallback; neither decides the primary HTML/CSS layout. `netsurf_backend_stub.c` is not a real engine integration.

See `../../docs/XENONWEB-ENGINE.md`, `../../docs/XENONSCRIPT.md` and `../../docs/STATUS.md` for the exact support boundary. The PowerPC/xSDK build and physical Xbox validation remain release gates.
