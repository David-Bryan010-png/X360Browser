#ifndef XW_CSS_H
#define XW_CSS_H

#include "xw_dom.h"
#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#define XW_CSS_MAX_RULES 128U
#define XW_CSS_SELECTOR_CAP 96U

typedef enum {
    XW_ALIGN_LEFT = 0,
    XW_ALIGN_CENTER = 1,
    XW_ALIGN_RIGHT = 2
} XwTextAlign;

typedef struct {
    uint32_t color;
    uint32_t background_color;
    int has_background;
    int display_none;
    int display_inline;
    int font_size_px;
    int bold;
    int align;
    int margin_top;
    int margin_bottom;
    int padding;
    int border_width;
    int width_px;
} XwComputedStyle;

typedef struct {
    char selector[XW_CSS_SELECTOR_CAP];
    XwComputedStyle values;
    uint32_t declarations;
    unsigned int specificity;
    unsigned int source_order;
} XwCssRule;

typedef struct {
    XwCssRule rules[XW_CSS_MAX_RULES];
    size_t rule_count;
    unsigned int next_source_order;
    int truncated;
} XwStylesheet;

void xw_css_init(XwStylesheet *sheet);
int xw_css_parse(XwStylesheet *sheet, const char *css, size_t length);
void xw_css_collect_document_styles(XwStylesheet *sheet, const XwDocument *document);
void xw_css_compute(const XwStylesheet *sheet, const XwDocument *document,
                    uint16_t node_index, const XwComputedStyle *parent,
                    XwComputedStyle *computed);

#ifdef __cplusplus
}
#endif
#endif
