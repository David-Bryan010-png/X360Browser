#include "xw_script.h"

#include <ctype.h>
#include <math.h>
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>

#define XW_JS_TEXT_CAP 256U
#define XW_JS_NAME_CAP 48U
#define XW_JS_MAX_DEPTH 32U
#define XW_JS_MAX_TOKENS 20000U

typedef enum {
    TOK_END = 0, TOK_ID, TOK_NUMBER, TOK_STRING, TOK_PUNCT, TOK_OPERATOR, TOK_BAD
} XwTokenKind;

typedef struct {
    XwTokenKind kind;
    char text[XW_JS_TEXT_CAP];
    double number;
} XwToken;

typedef enum {
    VAL_UNDEFINED = 0, VAL_NUMBER, VAL_STRING, VAL_BOOL, VAL_NODE,
    VAL_DOCUMENT, VAL_CONSOLE, VAL_ALERT
} XwValueType;

typedef enum {
    REF_NONE = 0, REF_VARIABLE, REF_NODE_TEXT, REF_NODE_ATTRIBUTE, REF_DOCUMENT_TITLE
} XwRefKind;

typedef struct {
    XwValueType type;
    XwRefKind ref_kind;
    unsigned int ref_index;
    uint16_t node_index;
    double number;
    int boolean;
    char string[XW_JS_TEXT_CAP];
    char ref_name[32];
} XwValue;

typedef struct {
    char name[XW_JS_NAME_CAP];
    XwValue value;
} XwVariable;

typedef struct {
    XwDocument *document;
    const char *source;
    size_t source_length;
    size_t position;
    size_t tokens;
    size_t remaining;
    unsigned int depth;
    int execute;
    int failed;
    XwToken token;
    XwVariable variables[XW_SCRIPT_MAX_VARIABLES];
    size_t variable_count;
    XwScriptStats *stats;
} XwParser;

static XwParser g_parser;

static XwValue value_undefined(void)
{
    XwValue value;
    memset(&value, 0, sizeof(value));
    value.type = VAL_UNDEFINED;
    value.node_index = XW_DOM_NONE;
    return value;
}

static XwValue value_string(const char *text)
{
    XwValue value = value_undefined();
    value.type = VAL_STRING;
    if (text != NULL) (void)snprintf(value.string, sizeof(value.string), "%s", text);
    return value;
}

static XwValue value_number(double number)
{
    XwValue value = value_undefined();
    value.type = VAL_NUMBER;
    value.number = number;
    return value;
}

static XwValue value_bool(int boolean)
{
    XwValue value = value_undefined();
    value.type = VAL_BOOL;
    value.boolean = boolean != 0;
    return value;
}

static void clear_reference(XwValue *value)
{
    value->ref_kind = REF_NONE;
    value->ref_index = 0U;
    value->ref_name[0] = '\0';
}

static void skip_ignored(XwParser *parser)
{
    while (parser->position < parser->source_length) {
        char c = parser->source[parser->position];
        if (isspace((unsigned char)c)) {
            ++parser->position;
            continue;
        }
        if (c == '/' && parser->position + 1U < parser->source_length &&
            parser->source[parser->position + 1U] == '/') {
            parser->position += 2U;
            while (parser->position < parser->source_length && parser->source[parser->position] != '\n')
                ++parser->position;
            continue;
        }
        if (c == '/' && parser->position + 1U < parser->source_length &&
            parser->source[parser->position + 1U] == '*') {
            parser->position += 2U;
            while (parser->position + 1U < parser->source_length &&
                   !(parser->source[parser->position] == '*' && parser->source[parser->position + 1U] == '/'))
                ++parser->position;
            if (parser->position + 1U >= parser->source_length) {
                parser->failed = 1;
                return;
            }
            parser->position += 2U;
            continue;
        }
        break;
    }
}

static void next_token(XwParser *parser)
{
    size_t start;
    size_t length;
    char c;
    memset(&parser->token, 0, sizeof(parser->token));
    skip_ignored(parser);
    if (parser->failed || parser->position >= parser->source_length) {
        parser->token.kind = TOK_END;
        return;
    }
    if (++parser->tokens > XW_JS_MAX_TOKENS) {
        parser->failed = 1;
        parser->token.kind = TOK_BAD;
        return;
    }
    c = parser->source[parser->position];
    if (isalpha((unsigned char)c) || c == '_' || c == '$') {
        start = parser->position++;
        while (parser->position < parser->source_length) {
            c = parser->source[parser->position];
            if (!(isalnum((unsigned char)c) || c == '_' || c == '$')) break;
            ++parser->position;
        }
        length = parser->position - start;
        if (length >= sizeof(parser->token.text)) { parser->failed = 1; parser->token.kind = TOK_BAD; return; }
        memcpy(parser->token.text, parser->source + start, length);
        parser->token.kind = TOK_ID;
        return;
    }
    if (isdigit((unsigned char)c) || (c == '.' && parser->position + 1U < parser->source_length &&
                                       isdigit((unsigned char)parser->source[parser->position + 1U]))) {
        char number[64];
        char *end = NULL;
        start = parser->position++;
        while (parser->position < parser->source_length) {
            c = parser->source[parser->position];
            if (!(isalnum((unsigned char)c) || c == '.' || c == '+' || c == '-')) break;
            if ((c == '+' || c == '-') && parser->position > start &&
                parser->source[parser->position - 1U] != 'e' && parser->source[parser->position - 1U] != 'E') break;
            ++parser->position;
        }
        length = parser->position - start;
        if (length >= sizeof(number)) { parser->failed = 1; parser->token.kind = TOK_BAD; return; }
        memcpy(number, parser->source + start, length);
        number[length] = '\0';
        parser->token.number = strtod(number, &end);
        if (end == number || *end != '\0' || !isfinite(parser->token.number)) {
            parser->failed = 1; parser->token.kind = TOK_BAD; return;
        }
        parser->token.kind = TOK_NUMBER;
        (void)snprintf(parser->token.text, sizeof(parser->token.text), "%s", number);
        return;
    }
    if (c == '\'' || c == '"') {
        char quote = c;
        size_t out = 0U;
        ++parser->position;
        while (parser->position < parser->source_length && parser->source[parser->position] != quote) {
            c = parser->source[parser->position++];
            if (c == '\\') {
                if (parser->position >= parser->source_length) { parser->failed = 1; break; }
                c = parser->source[parser->position++];
                if (c == 'n') c = '\n';
                else if (c == 'r') c = '\r';
                else if (c == 't') c = '\t';
                else if (c != '\\' && c != '\'' && c != '"') { parser->failed = 1; break; }
            }
            if (out + 1U >= sizeof(parser->token.text)) { parser->failed = 1; break; }
            parser->token.text[out++] = c;
        }
        if (parser->position >= parser->source_length || parser->source[parser->position] != quote)
            parser->failed = 1;
        else ++parser->position;
        parser->token.kind = parser->failed ? TOK_BAD : TOK_STRING;
        return;
    }
    {
        static const char *const multi_ops[] = { "===", "!==", "==", "!=", "<=", ">=", "&&", "||" };
        size_t i;
        for (i = 0U; i < sizeof(multi_ops) / sizeof(multi_ops[0]); ++i) {
            size_t n = strlen(multi_ops[i]);
            if (parser->position + n <= parser->source_length &&
                memcmp(parser->source + parser->position, multi_ops[i], n) == 0) {
                memcpy(parser->token.text, multi_ops[i], n + 1U);
                parser->token.kind = TOK_OPERATOR;
                parser->position += n;
                return;
            }
        }
    }
    parser->token.text[0] = c;
    parser->token.text[1] = '\0';
    parser->token.kind = strchr("(){};,.", c) != NULL ? TOK_PUNCT :
                         strchr("+-*/!<>=", c) != NULL ? TOK_OPERATOR : TOK_BAD;
    if (parser->token.kind == TOK_BAD) parser->failed = 1;
    ++parser->position;
}

static int token_is(const XwParser *parser, const char *text)
{
    return strcmp(parser->token.text, text) == 0;
}

static int accept(XwParser *parser, const char *text)
{
    if (!token_is(parser, text)) return 0;
    next_token(parser);
    return 1;
}

static int expect(XwParser *parser, const char *text)
{
    if (!accept(parser, text)) { parser->failed = 1; return 0; }
    return 1;
}

static int value_truthy(const XwValue *value)
{
    if (value->type == VAL_UNDEFINED) return 0;
    if (value->type == VAL_BOOL) return value->boolean;
    if (value->type == VAL_NUMBER) return value->number != 0.0 && !isnan(value->number);
    if (value->type == VAL_STRING) return value->string[0] != '\0';
    return 1;
}

static void value_to_string(const XwValue *value, char *output, size_t capacity)
{
    if (capacity == 0U) return;
    output[0] = '\0';
    switch (value->type) {
    case VAL_STRING: (void)snprintf(output, capacity, "%s", value->string); break;
    case VAL_NUMBER: (void)snprintf(output, capacity, "%.15g", value->number); break;
    case VAL_BOOL: (void)snprintf(output, capacity, "%s", value->boolean ? "true" : "false"); break;
    case VAL_NODE: (void)snprintf(output, capacity, "[object Element]"); break;
    case VAL_DOCUMENT: (void)snprintf(output, capacity, "[object Document]"); break;
    case VAL_CONSOLE: (void)snprintf(output, capacity, "[object Console]"); break;
    case VAL_ALERT: (void)snprintf(output, capacity, "[function alert]"); break;
    default: (void)snprintf(output, capacity, "undefined"); break;
    }
}

static XwValue *find_variable(XwParser *parser, const char *name, int create)
{
    size_t i;
    for (i = 0U; i < parser->variable_count; ++i)
        if (strcmp(parser->variables[i].name, name) == 0) return &parser->variables[i].value;
    if (!create || parser->variable_count >= XW_SCRIPT_MAX_VARIABLES || strlen(name) >= XW_JS_NAME_CAP)
        return NULL;
    (void)snprintf(parser->variables[parser->variable_count].name,
                   sizeof(parser->variables[parser->variable_count].name), "%s", name);
    parser->variables[parser->variable_count].value = value_undefined();
    return &parser->variables[parser->variable_count++].value;
}

static uint16_t find_selector(XwDocument *document, const char *selector)
{
    size_t i;
    if (selector[0] == '#') return xw_dom_find_by_id(document, selector + 1);
    if (selector[0] == '.') {
        for (i = 0U; i < document->node_count; ++i)
            if (document->nodes[i].type == XW_NODE_ELEMENT &&
                xw_dom_has_class(document, (uint16_t)i, selector + 1)) return (uint16_t)i;
        return XW_DOM_NONE;
    }
    for (i = 0U; i < document->node_count; ++i) {
        if (document->nodes[i].type == XW_NODE_ELEMENT &&
            strcasecmp(xw_dom_string(document, document->nodes[i].name_offset), selector) == 0)
            return (uint16_t)i;
    }
    return XW_DOM_NONE;
}

static XwValue parse_expression(XwParser *parser, int min_precedence);
static void parse_statement(XwParser *parser);

static int operator_precedence(const char *op)
{
    if (strcmp(op, "||") == 0) return 1;
    if (strcmp(op, "&&") == 0) return 2;
    if (strcmp(op, "==") == 0 || strcmp(op, "===") == 0 || strcmp(op, "!=") == 0 || strcmp(op, "!==") == 0) return 3;
    if (strcmp(op, "<") == 0 || strcmp(op, ">") == 0 || strcmp(op, "<=") == 0 || strcmp(op, ">=") == 0) return 4;
    if (strcmp(op, "+") == 0 || strcmp(op, "-") == 0) return 5;
    if (strcmp(op, "*") == 0 || strcmp(op, "/") == 0) return 6;
    return 0;
}

static double value_to_number(const XwValue *value)
{
    char *end = NULL;
    if (value->type == VAL_NUMBER) return value->number;
    if (value->type == VAL_BOOL) return value->boolean ? 1.0 : 0.0;
    if (value->type == VAL_STRING) {
        double number = strtod(value->string, &end);
        return end != value->string && *end == '\0' ? number : 0.0;
    }
    return 0.0;
}

static XwValue apply_operator(const char *op, XwValue left, XwValue right)
{
    char a[XW_JS_TEXT_CAP], b[XW_JS_TEXT_CAP], joined[XW_JS_TEXT_CAP];
    int result = 0;
    clear_reference(&left);
    clear_reference(&right);
    if (strcmp(op, "+") == 0 && (left.type == VAL_STRING || right.type == VAL_STRING)) {
        value_to_string(&left, a, sizeof(a)); value_to_string(&right, b, sizeof(b));
        {
            size_t a_len = strlen(a);
            size_t b_len = strlen(b);
            if (a_len >= sizeof(joined)) a_len = sizeof(joined) - 1U;
            if (b_len > sizeof(joined) - a_len - 1U) b_len = sizeof(joined) - a_len - 1U;
            memcpy(joined, a, a_len);
            memcpy(joined + a_len, b, b_len);
            joined[a_len + b_len] = '\0';
        }
        return value_string(joined);
    }
    if (strcmp(op, "||") == 0) return value_bool(value_truthy(&left) || value_truthy(&right));
    if (strcmp(op, "&&") == 0) return value_bool(value_truthy(&left) && value_truthy(&right));
    if (strcmp(op, "==") == 0 || strcmp(op, "===") == 0 ||
        strcmp(op, "!=") == 0 || strcmp(op, "!==") == 0) {
        if (left.type == right.type && left.type == VAL_STRING) result = strcmp(left.string, right.string) == 0;
        else if (left.type == VAL_BOOL && right.type == VAL_BOOL) result = left.boolean == right.boolean;
        else result = value_to_number(&left) == value_to_number(&right);
        if (strcmp(op, "!=") == 0 || strcmp(op, "!==") == 0) result = !result;
        return value_bool(result);
    }
    if (left.type == VAL_STRING && right.type == VAL_STRING &&
        (strcmp(op, "<") == 0 || strcmp(op, ">") == 0 || strcmp(op, "<=") == 0 || strcmp(op, ">=") == 0)) {
        int cmp = strcmp(left.string, right.string);
        if (strcmp(op, "<") == 0) result = cmp < 0;
        else if (strcmp(op, ">") == 0) result = cmp > 0;
        else if (strcmp(op, "<=") == 0) result = cmp <= 0;
        else result = cmp >= 0;
        return value_bool(result);
    }
    {
        double x = value_to_number(&left), y = value_to_number(&right);
        if (strcmp(op, "+") == 0) return value_number(x + y);
        if (strcmp(op, "-") == 0) return value_number(x - y);
        if (strcmp(op, "*") == 0) return value_number(x * y);
        if (strcmp(op, "/") == 0) return y == 0.0 ? value_undefined() : value_number(x / y);
        if (strcmp(op, "<") == 0) result = x < y;
        else if (strcmp(op, ">") == 0) result = x > y;
        else if (strcmp(op, "<=") == 0) result = x <= y;
        else if (strcmp(op, ">=") == 0) result = x >= y;
        else return value_undefined();
        return value_bool(result);
    }
}

static XwValue read_node_property(XwParser *parser, XwValue value, const char *property)
{
    const char *attribute_name = NULL;
    char text[XW_JS_TEXT_CAP];
    if (value.type == VAL_DOCUMENT) {
        if (strcmp(property, "title") == 0) {
            size_t i;
            for (i = 0U; i < parser->document->node_count; ++i) {
                if (parser->document->nodes[i].type == XW_NODE_ELEMENT &&
                    strcasecmp(xw_dom_string(parser->document, parser->document->nodes[i].name_offset), "title") == 0) {
                    xw_dom_text_content(parser->document, (uint16_t)i, text, sizeof(text));
                    value = value_string(text);
                    value.ref_kind = REF_DOCUMENT_TITLE;
                    return value;
                }
            }
            value = value_string(""); value.ref_kind = REF_DOCUMENT_TITLE; return value;
        }
        if (strcmp(property, "body") == 0) {
            size_t i;
            for (i = 0U; i < parser->document->node_count; ++i)
                if (parser->document->nodes[i].type == XW_NODE_ELEMENT &&
                    strcasecmp(xw_dom_string(parser->document, parser->document->nodes[i].name_offset), "body") == 0) {
                    XwValue node = value_undefined(); node.type = VAL_NODE; node.node_index = (uint16_t)i; return node;
                }
        }
        return value_undefined();
    }
    if (value.type != VAL_NODE || value.node_index >= parser->document->node_count) return value_undefined();
    if (strcmp(property, "textContent") == 0 || strcmp(property, "innerText") == 0) {
        {
            uint16_t node_index = value.node_index;
            xw_dom_text_content(parser->document, node_index, text, sizeof(text));
            value = value_string(text);
            value.ref_kind = REF_NODE_TEXT;
            value.ref_index = node_index;
            return value;
        }
    }
    if (strcmp(property, "id") == 0) attribute_name = "id";
    else if (strcmp(property, "className") == 0) attribute_name = "class";
    else if (strcmp(property, "value") == 0) attribute_name = "value";
    else if (strcmp(property, "href") == 0) attribute_name = "href";
    else if (strcmp(property, "src") == 0) attribute_name = "src";
    if (attribute_name != NULL) {
        {
            uint16_t node_index = value.node_index;
            const char *current = xw_dom_attribute(parser->document, node_index, attribute_name);
            value = value_string(current != NULL ? current : "");
            value.ref_kind = REF_NODE_ATTRIBUTE;
            value.ref_index = node_index;
            (void)snprintf(value.ref_name, sizeof(value.ref_name), "%s", attribute_name);
            return value;
        }
    }
    return value_undefined();
}

static XwValue parse_primary(XwParser *parser)
{
    XwValue value = value_undefined();
    if (++parser->depth > XW_JS_MAX_DEPTH) { parser->failed = 1; --parser->depth; return value; }
    if (parser->token.kind == TOK_NUMBER) {
        value = value_number(parser->token.number);
        next_token(parser);
    } else if (parser->token.kind == TOK_STRING) {
        value = value_string(parser->token.text);
        next_token(parser);
    } else if (accept(parser, "(")) {
        value = parse_expression(parser, 1);
        (void)expect(parser, ")");
        clear_reference(&value);
    } else if (accept(parser, "!")) {
        XwValue inner = parse_primary(parser);
        value = value_bool(!value_truthy(&inner));
    } else if (accept(parser, "-")) {
        XwValue inner = parse_primary(parser);
        value = value_number(-value_to_number(&inner));
    } else if (parser->token.kind == TOK_ID) {
        char identifier[XW_JS_TEXT_CAP];
        (void)snprintf(identifier, sizeof(identifier), "%s", parser->token.text);
        next_token(parser);
        if (strcmp(identifier, "true") == 0) value = value_bool(1);
        else if (strcmp(identifier, "false") == 0 || strcmp(identifier, "null") == 0 || strcmp(identifier, "undefined") == 0)
            value = strcmp(identifier, "false") == 0 ? value_bool(0) : value_undefined();
        else if (strcmp(identifier, "document") == 0) value.type = VAL_DOCUMENT;
        else if (strcmp(identifier, "console") == 0) value.type = VAL_CONSOLE;
        else if (strcmp(identifier, "alert") == 0) value.type = VAL_ALERT;
        else {
            XwValue *stored = find_variable(parser, identifier, 0);
            if (stored != NULL) value = *stored;
            value.ref_kind = REF_VARIABLE;
            /* Indexes are based on variable records, not the nested value subobjects. */
            {
                size_t i;
                value.ref_index = UINT_MAX;
                for (i = 0U; i < parser->variable_count; ++i)
                    if (strcmp(parser->variables[i].name, identifier) == 0) { value.ref_index = (unsigned int)i; break; }
                if (value.ref_index == UINT_MAX) value.ref_kind = REF_NONE;
            }
        }
    } else {
        parser->failed = 1;
    }

    while (!parser->failed) {
        if (accept(parser, ".")) {
            char property[XW_JS_TEXT_CAP];
            if (parser->token.kind != TOK_ID) { parser->failed = 1; break; }
            (void)snprintf(property, sizeof(property), "%s", parser->token.text);
            next_token(parser);
            if (value.type == VAL_CONSOLE && strcmp(property, "log") == 0) {
                value.type = VAL_CONSOLE;
            } else if (value.type == VAL_DOCUMENT &&
                (strcmp(property, "getElementById") == 0 || strcmp(property, "querySelector") == 0) &&
                accept(parser, "(")) {
                XwValue argument = parse_expression(parser, 1);
                char selector[XW_JS_TEXT_CAP];
                uint16_t node_index;
                (void)expect(parser, ")");
                value_to_string(&argument, selector, sizeof(selector));
                node_index = strcmp(property, "getElementById") == 0 ?
                    xw_dom_find_by_id(parser->document, selector) : find_selector(parser->document, selector);
                value = value_undefined();
                if (node_index != XW_DOM_NONE) { value.type = VAL_NODE; value.node_index = node_index; }
            } else if (value.type == VAL_NODE && strcmp(property, "setAttribute") == 0 && accept(parser, "(")) {
                XwValue name = parse_expression(parser, 1), attr_value;
                char name_text[64], value_text[XW_JS_TEXT_CAP];
                (void)expect(parser, ",");
                attr_value = parse_expression(parser, 1);
                (void)expect(parser, ")");
                value_to_string(&name, name_text, sizeof(name_text));
                value_to_string(&attr_value, value_text, sizeof(value_text));
                if (parser->execute && xw_dom_set_attribute(parser->document, value.node_index, name_text, value_text))
                    ++parser->stats->dom_mutations;
                value = value_undefined();
            } else {
                value = read_node_property(parser, value, property);
            }
        } else if (accept(parser, "(")) {
            if (value.type == VAL_CONSOLE || value.type == VAL_ALERT) {
                int is_alert = value.type == VAL_ALERT;
                if (!token_is(parser, ")")) {
                    (void)parse_expression(parser, 1);
                    while (accept(parser, ",")) (void)parse_expression(parser, 1);
                }
                (void)expect(parser, ")");
                if (parser->execute) {
                    if (is_alert) ++parser->stats->alert_calls;
                    else ++parser->stats->console_calls;
                }
                value = value_undefined();
            } else {
                parser->failed = 1;
                break;
            }
        } else break;
    }
    --parser->depth;
    return value;
}

static XwValue parse_expression(XwParser *parser, int min_precedence)
{
    XwValue left = parse_primary(parser);
    while (!parser->failed && parser->token.kind == TOK_OPERATOR) {
        char op[XW_JS_TEXT_CAP];
        int precedence = operator_precedence(parser->token.text);
        XwValue right;
        if (precedence < min_precedence || precedence == 0) break;
        (void)snprintf(op, sizeof(op), "%s", parser->token.text);
        next_token(parser);
        right = parse_expression(parser, precedence + 1);
        left = apply_operator(op, left, right);
    }
    return left;
}

static int assign_value(XwParser *parser, const XwValue *left, XwValue right)
{
    char text[XW_JS_TEXT_CAP];
    value_to_string(&right, text, sizeof(text));
    if (!parser->execute) return 1;
    switch (left->ref_kind) {
    case REF_VARIABLE:
        if (left->ref_index < parser->variable_count) {
            parser->variables[left->ref_index].value = right;
            clear_reference(&parser->variables[left->ref_index].value);
            return 1;
        }
        return 0;
    case REF_NODE_TEXT:
        if (xw_dom_set_text_content(parser->document, (uint16_t)left->ref_index, text)) {
            ++parser->stats->dom_mutations; return 1;
        }
        return 0;
    case REF_NODE_ATTRIBUTE:
        if (xw_dom_set_attribute(parser->document, (uint16_t)left->ref_index, left->ref_name, text)) {
            ++parser->stats->dom_mutations; return 1;
        }
        return 0;
    case REF_DOCUMENT_TITLE: {
        size_t i;
        for (i = 0U; i < parser->document->node_count; ++i) {
            if (parser->document->nodes[i].type == XW_NODE_ELEMENT &&
                strcasecmp(xw_dom_string(parser->document, parser->document->nodes[i].name_offset), "title") == 0) {
                if (xw_dom_set_text_content(parser->document, (uint16_t)i, text)) {
                    ++parser->stats->dom_mutations; return 1;
                }
                return 0;
            }
        }
        return 0;
    }
    default: return 0;
    }
}

static void parse_block(XwParser *parser)
{
    if (!expect(parser, "{")) return;
    while (!parser->failed && parser->token.kind != TOK_END && !token_is(parser, "}")) {
        size_t before = parser->position;
        parse_statement(parser);
        if (parser->position == before && !parser->failed) { parser->failed = 1; break; }
    }
    (void)expect(parser, "}");
}

static void parse_statement(XwParser *parser)
{
    int is_declaration = 0;
    char variable_name[XW_JS_NAME_CAP];
    XwValue left;
    if (parser->failed || parser->token.kind == TOK_END) return;
    if (parser->stats->statements >= XW_SCRIPT_MAX_STATEMENTS || parser->remaining == 0U) {
        parser->stats->budget_exhausted = 1;
        parser->failed = 1;
        return;
    }
    ++parser->stats->statements;
    --parser->remaining;
    if (accept(parser, ";")) return;
    if (accept(parser, "{")) {
        while (!parser->failed && parser->token.kind != TOK_END && !token_is(parser, "}"))
            parse_statement(parser);
        (void)expect(parser, "}");
        return;
    }
    if (parser->token.kind == TOK_ID &&
        (token_is(parser, "var") || token_is(parser, "let") || token_is(parser, "const"))) {
        next_token(parser);
        if (parser->token.kind != TOK_ID || strlen(parser->token.text) >= sizeof(variable_name)) {
            parser->failed = 1; return;
        }
        (void)snprintf(variable_name, sizeof(variable_name), "%s", parser->token.text);
        next_token(parser);
        is_declaration = 1;
        if (accept(parser, "=")) {
            XwValue value = parse_expression(parser, 1);
            if (parser->execute) {
                XwValue *stored = find_variable(parser, variable_name, 1);
                if (stored == NULL) parser->failed = 1;
                else { *stored = value; clear_reference(stored); }
            }
        } else if (parser->execute) {
            XwValue *stored = find_variable(parser, variable_name, 1);
            if (stored == NULL) parser->failed = 1;
        }
        (void)accept(parser, ";");
        return;
    }
    if (accept(parser, "if")) {
        XwValue condition;
        int parent_execute = parser->execute;
        (void)expect(parser, "(");
        condition = parse_expression(parser, 1);
        (void)expect(parser, ")");
        parser->execute = parent_execute && value_truthy(&condition);
        if (token_is(parser, "{")) parse_block(parser); else parse_statement(parser);
        parser->execute = parent_execute && !value_truthy(&condition);
        if (accept(parser, "else")) {
            if (token_is(parser, "{")) parse_block(parser); else parse_statement(parser);
        }
        parser->execute = parent_execute;
        (void)accept(parser, ";");
        return;
    }
    if (token_is(parser, "while") || token_is(parser, "for") || token_is(parser, "function") ||
        token_is(parser, "return") || token_is(parser, "import") || token_is(parser, "export")) {
        parser->failed = 1;
        return;
    }
    left = parse_expression(parser, 1);
    if (accept(parser, "=")) {
        XwValue right = parse_expression(parser, 1);
        if (left.ref_kind != REF_NONE && !assign_value(parser, &left, right)) parser->failed = 1;
    }
    (void)is_declaration;
    (void)accept(parser, ";");
}

static int script_type_allowed(const char *type)
{
    return type == NULL || type[0] == '\0' || strcasecmp(type, "text/javascript") == 0 ||
           strcasecmp(type, "application/javascript") == 0 || strcasecmp(type, "text/ecmascript") == 0 ||
           strcasecmp(type, "application/ecmascript") == 0;
}

int xw_script_run_document(XwDocument *document, size_t instruction_budget,
                           XwScriptStats *stats)
{
    /* Renderer is synchronous and single-page: keep the interpreter arena off the small console stack. */
    XwParser *parser = &g_parser;
    size_t i;
    int all_ok = 1;
    XwScriptStats local_stats;
    if (document == NULL) return 0;
    if (stats == NULL) stats = &local_stats;
    memset(stats, 0, sizeof(*stats));
    memset(parser, 0, sizeof(*parser));
    parser->document = document;
    parser->remaining = instruction_budget > 0U ? instruction_budget : 1U;
    parser->execute = 1;
    parser->stats = stats;
    for (i = 0U; i < document->node_count; ++i) {
        const char *tag;
        const char *type;
        const char *src;
        uint16_t child;
        size_t code_length;
        if (document->nodes[i].type != XW_NODE_ELEMENT) continue;
        tag = xw_dom_string(document, document->nodes[i].name_offset);
        if (strcasecmp(tag, "script") != 0) continue;
        ++stats->script_elements;
        type = xw_dom_attribute(document, (uint16_t)i, "type");
        src = xw_dom_attribute(document, (uint16_t)i, "src");
        if ((src != NULL && src[0] != '\0') || !script_type_allowed(type)) continue;
        child = document->nodes[i].first_child;
        while (child != XW_DOM_NONE && document->nodes[child].type != XW_NODE_TEXT)
            child = document->nodes[child].next_sibling;
        if (child == XW_DOM_NONE) { ++stats->executed_scripts; continue; }
        /* A previous malformed conditional must not suppress a later script. */
        parser->execute = 1;
        parser->source = xw_dom_string(document, document->nodes[child].value_offset);
        code_length = strlen(parser->source);
        if (code_length > XW_SCRIPT_MAX_SOURCE) {
            ++stats->errors; stats->truncated = 1; all_ok = 0; continue;
        }
        parser->source_length = code_length;
        parser->position = 0U;
        parser->tokens = 0U;
        parser->failed = 0;
        parser->depth = 0U;
        next_token(parser);
        while (!parser->failed && parser->token.kind != TOK_END) {
            size_t old_pos = parser->position;
            parse_statement(parser);
            if (parser->position == old_pos && !parser->failed) parser->failed = 1;
        }
        ++stats->executed_scripts;
        if (parser->failed) {
            ++stats->errors;
            all_ok = 0;
            if (stats->budget_exhausted) break;
        }
    }
    return all_ok;
}


int xw_script_execute_code(XwDocument *document, const char *code, size_t code_length,
                           size_t instruction_budget, XwScriptStats *stats)
{
    XwScriptStats local_stats;
    XwParser *parser = &g_parser;
    int all_ok = 1;
    if (stats == NULL) stats = &local_stats;
    memset(stats, 0, sizeof(*stats));
    if (document == NULL || code == NULL) { ++stats->errors; return 0; }
    if (code_length > XW_SCRIPT_MAX_SOURCE) {
        stats->truncated = 1;
        ++stats->errors;
        return 0;
    }
    if (parser->document != document) {
        memset(parser, 0, sizeof(*parser));
        parser->document = document;
    }
    parser->source = code;
    parser->source_length = code_length;
    parser->position = 0U;
    parser->tokens = 0U;
    parser->remaining = instruction_budget > 0U ? instruction_budget : 1U;
    parser->depth = 0U;
    parser->execute = 1;
    parser->failed = 0;
    parser->stats = stats;
    next_token(parser);
    while (!parser->failed && parser->token.kind != TOK_END) {
        size_t old_position = parser->position;
        parse_statement(parser);
        if (parser->position == old_position && !parser->failed) parser->failed = 1;
    }
    if (parser->failed) {
        ++stats->errors;
        if (stats->budget_exhausted) all_ok = 0;
        else all_ok = 0;
    }
    return all_ok;
}
