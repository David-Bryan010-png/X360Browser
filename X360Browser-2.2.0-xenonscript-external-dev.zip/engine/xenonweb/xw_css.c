#include "xw_css.h"

#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>

#define PROP_COLOR       (1UL << 0U)
#define PROP_BACKGROUND  (1UL << 1U)
#define PROP_DISPLAY     (1UL << 2U)
#define PROP_FONT_SIZE   (1UL << 3U)
#define PROP_WEIGHT      (1UL << 4U)
#define PROP_ALIGN       (1UL << 5U)
#define PROP_MARGIN_TOP  (1UL << 6U)
#define PROP_MARGIN_BOT  (1UL << 7U)
#define PROP_PADDING     (1UL << 8U)
#define PROP_BORDER      (1UL << 9U)
#define PROP_WIDTH       (1UL << 10U)
#define PROP_MARGIN      (PROP_MARGIN_TOP | PROP_MARGIN_BOT)
#define PROP_ALL         (PROP_COLOR | PROP_BACKGROUND | PROP_DISPLAY | PROP_FONT_SIZE | PROP_WEIGHT | PROP_ALIGN | PROP_MARGIN | PROP_PADDING | PROP_BORDER | PROP_WIDTH)

static void trim(char *text)
{
    size_t n;
    size_t start = 0U;
    while (text[start] != '\0' && isspace((unsigned char)text[start])) ++start;
    if (start > 0U) memmove(text, text + start, strlen(text + start) + 1U);
    n = strlen(text);
    while (n > 0U && isspace((unsigned char)text[n - 1U])) text[--n] = '\0';
}

static int parse_number_px(const char *value, int fallback)
{
    char *end = NULL;
    long number;
    while (isspace((unsigned char)*value)) ++value;
    number = strtol(value, &end, 10);
    if (end == value) return fallback;
    if (number < 0L) number = 0L;
    if (number > 512L) number = 512L;
    return (int)number;
}

static uint32_t parse_color(const char *value, uint32_t fallback)
{
    char token[64];
    size_t n = 0U;
    unsigned long parsed;
    while (*value != '\0' && *value != ';' && !isspace((unsigned char)*value) && n + 1U < sizeof(token))
        token[n++] = *value++;
    token[n] = '\0';
    if (token[0] == '#') {
        if (n == 4U) {
            unsigned long r = strtoul((char[]){token[1], '\0'}, NULL, 16) & 15UL;
            unsigned long g = strtoul((char[]){token[2], '\0'}, NULL, 16) & 15UL;
            unsigned long b = strtoul((char[]){token[3], '\0'}, NULL, 16) & 15UL;
            return 0xFF000000UL | ((uint32_t)(r * 17UL) << 16U) |
                   ((uint32_t)(g * 17UL) << 8U) | (uint32_t)(b * 17UL);
        }
        if (n == 7U && sscanf(token + 1U, "%lx", &parsed) == 1)
            return 0xFF000000U | ((uint32_t)parsed & 0x00FFFFFFU);
    }
    if (strcasecmp(token, "black") == 0) return 0xFF000000U;
    if (strcasecmp(token, "white") == 0) return 0xFFFFFFFFU;
    if (strcasecmp(token, "red") == 0) return 0xFFFF0000U;
    if (strcasecmp(token, "green") == 0) return 0xFF008000U;
    if (strcasecmp(token, "blue") == 0) return 0xFF0000FFU;
    if (strcasecmp(token, "navy") == 0) return 0xFF000080U;
    if (strcasecmp(token, "gray") == 0 || strcasecmp(token, "grey") == 0) return 0xFF808080U;
    if (strcasecmp(token, "yellow") == 0) return 0xFFFFFF00U;
    if (strcasecmp(token, "orange") == 0) return 0xFFFFA500U;
    if (strcasecmp(token, "purple") == 0) return 0xFF800080U;
    if (strcasecmp(token, "teal") == 0) return 0xFF008080U;
    if (strcasecmp(token, "pink") == 0) return 0xFFFFC0CBU;
    if (strcasecmp(token, "transparent") == 0) return 0x00000000U;
    return fallback;
}

static unsigned int selector_specificity(const char *selector)
{
    unsigned int specificity = 0U;
    const char *p = selector;
    while (*p != '\0') {
        if (*p == '#') specificity += 100U;
        else if (*p == '.') specificity += 10U;
        else if (isalpha((unsigned char)*p) && (p == selector ||
                 !(isalnum((unsigned char)p[-1]) || p[-1] == '-' || p[-1] == '_' || p[-1] == '.')))
            specificity += 1U;
        ++p;
    }
    return specificity;
}

static int parse_declarations(const char *source, size_t length,
                              XwComputedStyle *values, uint32_t *mask)
{
    size_t p = 0U;
    *mask = 0U;
    while (p < length) {
        size_t name_start, name_end, value_start, value_end;
        char name[32];
        char value[96];
        size_t copy;
        while (p < length && (isspace((unsigned char)source[p]) || source[p] == ';')) ++p;
        if (p >= length) break;
        name_start = p;
        while (p < length && source[p] != ':' && source[p] != ';') ++p;
        if (p >= length || source[p] != ':') {
            while (p < length && source[p] != ';') ++p;
            continue;
        }
        name_end = p++;
        while (name_start < name_end && isspace((unsigned char)source[name_start])) ++name_start;
        while (name_end > name_start && isspace((unsigned char)source[name_end - 1U])) --name_end;
        value_start = p;
        while (p < length && source[p] != ';') ++p;
        value_end = p;
        while (value_start < value_end && isspace((unsigned char)source[value_start])) ++value_start;
        while (value_end > value_start && isspace((unsigned char)source[value_end - 1U])) --value_end;
        copy = name_end - name_start;
        if (copy == 0U || copy >= sizeof(name)) continue;
        memcpy(name, source + name_start, copy); name[copy] = '\0';
        copy = value_end - value_start;
        if (copy >= sizeof(value)) copy = sizeof(value) - 1U;
        memcpy(value, source + value_start, copy); value[copy] = '\0';
        if (strcasecmp(name, "color") == 0) {
            values->color = parse_color(value, values->color); *mask |= PROP_COLOR;
        } else if (strcasecmp(name, "background") == 0 || strcasecmp(name, "background-color") == 0) {
            values->background_color = parse_color(value, values->background_color);
            values->has_background = 1; *mask |= PROP_BACKGROUND;
        } else if (strcasecmp(name, "display") == 0) {
            values->display_none = strcasecmp(value, "none") == 0;
            values->display_inline = strcasecmp(value, "inline") == 0 || strcasecmp(value, "inline-block") == 0;
            *mask |= PROP_DISPLAY;
        } else if (strcasecmp(name, "font-size") == 0) {
            values->font_size_px = parse_number_px(value, values->font_size_px); *mask |= PROP_FONT_SIZE;
        } else if (strcasecmp(name, "font-weight") == 0) {
            values->bold = strcasecmp(value, "bold") == 0 || strcasecmp(value, "bolder") == 0 || atoi(value) >= 600;
            *mask |= PROP_WEIGHT;
        } else if (strcasecmp(name, "text-align") == 0) {
            if (strcasecmp(value, "center") == 0) values->align = XW_ALIGN_CENTER;
            else if (strcasecmp(value, "right") == 0 || strcasecmp(value, "end") == 0) values->align = XW_ALIGN_RIGHT;
            else values->align = XW_ALIGN_LEFT;
            *mask |= PROP_ALIGN;
        } else if (strcasecmp(name, "margin-top") == 0) {
            values->margin_top = parse_number_px(value, values->margin_top); *mask |= PROP_MARGIN_TOP;
        } else if (strcasecmp(name, "margin-bottom") == 0) {
            values->margin_bottom = parse_number_px(value, values->margin_bottom); *mask |= PROP_MARGIN_BOT;
        } else if (strcasecmp(name, "margin") == 0) {
            int v = parse_number_px(value, 0);
            values->margin_top = v; values->margin_bottom = v; *mask |= PROP_MARGIN;
        } else if (strcasecmp(name, "padding") == 0) {
            values->padding = parse_number_px(value, values->padding); *mask |= PROP_PADDING;
        } else if (strcasecmp(name, "border-width") == 0) {
            values->border_width = parse_number_px(value, values->border_width); *mask |= PROP_BORDER;
        } else if (strcasecmp(name, "width") == 0) {
            values->width_px = parse_number_px(value, values->width_px); *mask |= PROP_WIDTH;
        }
    }
    return *mask != 0U;
}

void xw_css_init(XwStylesheet *sheet)
{
    if (sheet == NULL) return;
    memset(sheet, 0, sizeof(*sheet));
}

int xw_css_parse(XwStylesheet *sheet, const char *css, size_t length)
{
    size_t p = 0U;
    int parsed_any = 0;
    if (sheet == NULL || css == NULL) return 0;
    while (p < length && sheet->rule_count < XW_CSS_MAX_RULES) {
        size_t selector_start, selector_end, body_start, body_end, copy;
        char selector[XW_CSS_SELECTOR_CAP];
        const char *open;
        const char *close;
        XwCssRule rule;
        while (p < length && isspace((unsigned char)css[p])) ++p;
        if (p + 1U < length && css[p] == '/' && css[p + 1U] == '*') {
            size_t end = p + 2U;
            while (end + 1U < length && !(css[end] == '*' && css[end + 1U] == '/')) ++end;
            if (end + 1U >= length) { sheet->truncated = 1; break; }
            p = end + 2U;
            continue;
        }
        open = memchr(css + p, '{', length - p);
        if (open == NULL) break;
        selector_start = p;
        selector_end = (size_t)(open - css);
        close = memchr(open + 1U, '}', length - ((size_t)(open + 1U - css)));
        if (close == NULL) { sheet->truncated = 1; break; }
        body_start = (size_t)(open + 1U - css);
        body_end = (size_t)(close - css);
        p = body_end + 1U;
        while (selector_start < selector_end && isspace((unsigned char)css[selector_start])) ++selector_start;
        while (selector_end > selector_start && isspace((unsigned char)css[selector_end - 1U])) --selector_end;
        copy = selector_end - selector_start;
        if (copy == 0U || copy >= sizeof(selector)) continue;
        memcpy(selector, css + selector_start, copy); selector[copy] = '\0';
        /* Comma-separated selector groups become independent cascade rules. */
        {
            char *comma = selector;
            do {
                char one[XW_CSS_SELECTOR_CAP];
                char *next = strchr(comma, ',');
                size_t n = next != NULL ? (size_t)(next - comma) : strlen(comma);
                memset(&rule, 0, sizeof(rule));
                if (n >= sizeof(one)) n = sizeof(one) - 1U;
                memcpy(one, comma, n); one[n] = '\0'; trim(one);
                if (one[0] != '\0' && sheet->rule_count < XW_CSS_MAX_RULES) {
                    snprintf(rule.selector, sizeof(rule.selector), "%s", one);
                    rule.specificity = selector_specificity(one);
                    rule.source_order = sheet->next_source_order++;
                    (void)parse_declarations(css + body_start, body_end - body_start,
                                             &rule.values, &rule.declarations);
                    if (rule.declarations != 0U) {
                        sheet->rules[sheet->rule_count++] = rule;
                        parsed_any = 1;
                    }
                }
                if (next == NULL) break;
                comma = next + 1;
            } while (1);
        }
    }
    if (p < length && sheet->rule_count >= XW_CSS_MAX_RULES) sheet->truncated = 1;
    return parsed_any;
}

static int is_element_child_of(const XwDocument *document, uint16_t node_index,
                               int require_first, int require_last, long nth_child)
{
    const XwDomNode *node;
    uint16_t parent;
    uint16_t cursor;
    long element_position = 0L;
    int found = 0;
    if (node_index >= document->node_count) return 0;
    node = &document->nodes[node_index];
    parent = node->parent;
    if (parent == XW_DOM_NONE || parent >= document->node_count) return 0;
    cursor = document->nodes[parent].first_child;
    while (cursor != XW_DOM_NONE) {
        if (document->nodes[cursor].type == XW_NODE_ELEMENT) {
            ++element_position;
            if (cursor == node_index) {
                found = 1;
                if (require_first && element_position != 1L) return 0;
                if (nth_child > 0L && element_position != nth_child) return 0;
            } else if (found && require_last) {
                return 0;
            }
        }
        cursor = document->nodes[cursor].next_sibling;
    }
    if (!found) return 0;
    if (require_last) {
        cursor = node->next_sibling;
        while (cursor != XW_DOM_NONE) {
            if (document->nodes[cursor].type == XW_NODE_ELEMENT) return 0;
            cursor = document->nodes[cursor].next_sibling;
        }
    }
    return 1;
}

static int attribute_selector_match(const XwDocument *document, uint16_t node_index,
                                    const char *source, size_t length)
{
    char expression[XW_CSS_SELECTOR_CAP];
    char name[64];
    char wanted[64];
    const char *actual;
    size_t eq = SIZE_MAX;
    size_t i;
    size_t name_length;
    size_t wanted_length;
    char operation = '=';
    if (length == 0U || length >= sizeof(expression)) return 0;
    memcpy(expression, source, length);
    expression[length] = '\0';
    trim(expression);
    for (i = 0U; expression[i] != '\0'; ++i) {
        if (expression[i] == '=' || ((expression[i] == '^' || expression[i] == '$' ||
            expression[i] == '*' || expression[i] == '~' || expression[i] == '|') && expression[i + 1U] == '=')) {
            eq = i;
            if (expression[i] != '=') operation = expression[i];
            break;
        }
    }
    if (eq == SIZE_MAX) {
        if (strlen(expression) >= sizeof(name)) return 0;
        memcpy(name, expression, strlen(expression) + 1U);
        actual = xw_dom_attribute(document, node_index, name);
        return actual != NULL;
    }
    name_length = eq;
    if (operation != '=') ++eq;
    while (name_length > 0U && isspace((unsigned char)expression[name_length - 1U])) --name_length;
    if (name_length == 0U || name_length >= sizeof(name)) return 0;
    memcpy(name, expression, name_length); name[name_length] = '\0';
    ++eq; /* skip '=' */
    while (expression[eq] != '\0' && isspace((unsigned char)expression[eq])) ++eq;
    wanted_length = strlen(expression + eq);
    if (wanted_length >= sizeof(wanted)) wanted_length = sizeof(wanted) - 1U;
    if (wanted_length >= 2U && ((expression[eq] == '\'' && expression[eq + wanted_length - 1U] == '\'') ||
                                (expression[eq] == '"' && expression[eq + wanted_length - 1U] == '"'))) {
        ++eq; wanted_length -= 2U;
    }
    memcpy(wanted, expression + eq, wanted_length); wanted[wanted_length] = '\0';
    actual = xw_dom_attribute(document, node_index, name);
    if (actual == NULL) return 0;
    if (operation == '=') return strcmp(actual, wanted) == 0;
    if (operation == '^') return strncmp(actual, wanted, wanted_length) == 0;
    if (operation == '$') {
        size_t actual_length = strlen(actual);
        return actual_length >= wanted_length && strcmp(actual + actual_length - wanted_length, wanted) == 0;
    }
    if (operation == '*') return strstr(actual, wanted) != NULL;
    if (operation == '~') {
        const char *cursor = actual;
        while (*cursor != '\0') {
            const char *start;
            while (isspace((unsigned char)*cursor)) ++cursor;
            start = cursor;
            while (*cursor != '\0' && !isspace((unsigned char)*cursor)) ++cursor;
            if ((size_t)(cursor - start) == wanted_length && strncmp(start, wanted, wanted_length) == 0) return 1;
        }
        return 0;
    }
    if (operation == '|')
        return strncmp(actual, wanted, wanted_length) == 0 &&
               (actual[wanted_length] == '\0' || actual[wanted_length] == '-');
    return 0;
}

static int simple_selector_match_depth(const XwDocument *document, uint16_t node_index,
                                       const char *token, size_t length, unsigned depth)
{
    size_t i = 0U;
    size_t type_start = 0U;
    int type_seen = 0;
    if (node_index >= document->node_count || length == 0U || depth > 8U ||
        document->nodes[node_index].type != XW_NODE_ELEMENT) return 0;
    if (length == 1U && token[0] == '*') return 1;
    while (i < length && token[i] != '.' && token[i] != '#' && token[i] != '[' && token[i] != ':') ++i;
    if (i > type_start) {
        char type_name[XW_CSS_SELECTOR_CAP];
        if (i >= sizeof(type_name)) return 0;
        memcpy(type_name, token, i); type_name[i] = '\0';
        if (strcmp(type_name, "*") != 0 &&
            strcasecmp(xw_dom_string(document, document->nodes[node_index].name_offset), type_name) != 0) return 0;
        type_seen = 1;
    }
    while (i < length) {
        char marker = token[i++];
        size_t start = i;
        size_t n;
        char name[XW_CSS_SELECTOR_CAP];
        if (marker == '.' || marker == '#') {
            while (i < length && token[i] != '.' && token[i] != '#' && token[i] != '[' && token[i] != ':') ++i;
            n = i - start;
            if (n == 0U || n >= sizeof(name)) return 0;
            memcpy(name, token + start, n); name[n] = '\0';
            if (marker == '#') {
                const char *id = xw_dom_attribute(document, node_index, "id");
                if (id == NULL || strcmp(id, name) != 0) return 0;
            } else if (!xw_dom_has_class(document, node_index, name)) return 0;
        } else if (marker == '[') {
            size_t close = i;
            char quote = '\0';
            while (close < length) {
                if (quote != '\0') { if (token[close] == quote) quote = '\0'; }
                else if (token[close] == '\'' || token[close] == '"') quote = token[close];
                else if (token[close] == ']') break;
                ++close;
            }
            if (close >= length || !attribute_selector_match(document, node_index, token + start, close - start)) return 0;
            i = close + 1U;
        } else if (marker == ':') {
            char pseudo[32];
            size_t pseudo_start = i;
            size_t pseudo_length;
            size_t arg_start = SIZE_MAX;
            size_t arg_length = 0U;
            while (i < length && token[i] != ':' && token[i] != '.' && token[i] != '#' && token[i] != '[' && token[i] != '(') ++i;
            pseudo_length = i - pseudo_start;
            if (pseudo_length == 0U || pseudo_length >= sizeof(pseudo)) return 0;
            memcpy(pseudo, token + pseudo_start, pseudo_length); pseudo[pseudo_length] = '\0';
            if (i < length && token[i] == '(') {
                arg_start = ++i;
                while (i < length && token[i] != ')') ++i;
                if (i >= length) return 0;
                arg_length = i - arg_start;
                ++i;
            }
            if (strcasecmp(pseudo, "first-child") == 0) {
                if (!is_element_child_of(document, node_index, 1, 0, 0L)) return 0;
            } else if (strcasecmp(pseudo, "last-child") == 0) {
                if (!is_element_child_of(document, node_index, 0, 1, 0L)) return 0;
            } else if (strcasecmp(pseudo, "nth-child") == 0) {
                char number[16]; char *end = NULL; long nth_value;
                if (arg_start == SIZE_MAX || arg_length == 0U || arg_length >= sizeof(number)) return 0;
                memcpy(number, token + arg_start, arg_length); number[arg_length] = '\0';
                nth_value = strtol(number, &end, 10);
                if (end == number || *end != '\0' || nth_value <= 0L ||
                    !is_element_child_of(document, node_index, 0, 0, nth_value)) return 0;
            } else if (strcasecmp(pseudo, "checked") == 0 || strcasecmp(pseudo, "disabled") == 0 ||
                       strcasecmp(pseudo, "required") == 0 || strcasecmp(pseudo, "selected") == 0) {
                const char *attribute = strcasecmp(pseudo, "checked") == 0 ? "checked" :
                    strcasecmp(pseudo, "disabled") == 0 ? "disabled" :
                    strcasecmp(pseudo, "required") == 0 ? "required" : "selected";
                if (xw_dom_attribute(document, node_index, attribute) == NULL) return 0;
            } else if (strcasecmp(pseudo, "not") == 0) {
                if (arg_start == SIZE_MAX || arg_length == 0U ||
                    simple_selector_match_depth(document, node_index, token + arg_start, arg_length, depth + 1U)) return 0;
            } else if (strcasecmp(pseudo, "link") == 0) {
                if (strcasecmp(xw_dom_string(document, document->nodes[node_index].name_offset), "a") != 0 ||
                    xw_dom_attribute(document, node_index, "href") == NULL) return 0;
            } else return 0;
        } else return 0;
    }
    return type_seen || token[0] == '.' || token[0] == '#' || token[0] == '[' || token[0] == ':';
}

static int simple_selector_match(const XwDocument *document, uint16_t node_index,
                                 const char *token, size_t length)
{
    return simple_selector_match_depth(document, node_index, token, length, 0U);
}

static int selector_match(const XwDocument *document, uint16_t node_index, const char *selector)
{
    size_t starts[16];
    size_t ends[16];
    unsigned char child_combinator[16];
    size_t count = 0U;
    size_t p = 0U;
    size_t length;
    uint16_t current;
    int next_is_child = 0;
    if (selector == NULL) return 0;
    length = strlen(selector);
    memset(child_combinator, 0, sizeof(child_combinator));
    while (p < length) {
        while (p < length && isspace((unsigned char)selector[p])) ++p;
        if (p >= length) break;
        if (selector[p] == '>') {
            if (count == 0U || next_is_child) return 0;
            next_is_child = 1;
            ++p;
            continue;
        }
        {
            size_t start = p;
            char quote = '\0';
            while (p < length) {
                char c = selector[p];
                if (quote != '\0') { if (c == quote) quote = '\0'; }
                else if (c == '\'' || c == '"') quote = c;
                else if (c == '>' || isspace((unsigned char)c)) break;
                ++p;
            }
            if (p == start || count >= sizeof(starts) / sizeof(starts[0])) return 0;
            starts[count] = start;
            ends[count] = p;
            child_combinator[count] = (unsigned char)(count > 0U && next_is_child ? 1U : 0U);
            ++count;
            next_is_child = 0;
        }
    }
    if (count == 0U || next_is_child) return 0;
    if (!simple_selector_match(document, node_index, selector + starts[count - 1U], ends[count - 1U] - starts[count - 1U])) return 0;
    current = document->nodes[node_index].parent;
    if (count == 1U) return 1;
    {
        size_t token = count - 1U;
        while (token > 0U) {
            --token;
            if (child_combinator[token + 1U]) {
                if (current == XW_DOM_NONE ||
                    !simple_selector_match(document, current, selector + starts[token], ends[token] - starts[token])) return 0;
                current = document->nodes[current].parent;
            } else {
                while (current != XW_DOM_NONE &&
                       !simple_selector_match(document, current, selector + starts[token], ends[token] - starts[token]))
                    current = document->nodes[current].parent;
                if (current == XW_DOM_NONE) return 0;
                current = document->nodes[current].parent;
            }
        }
    }
    return 1;
}

static int is_block_tag(const char *tag)
{
    static const char *const block[] = {
        "address", "article", "aside", "blockquote", "body", "div", "dl", "dt", "dd",
        "fieldset", "figcaption", "figure", "footer", "form", "h1", "h2", "h3", "h4",
        "h5", "h6", "header", "hr", "li", "main", "nav", "ol", "p", "pre",
        "section", "table", "tr", "ul"
    };
    size_t i;
    for (i = 0U; i < sizeof(block) / sizeof(block[0]); ++i) if (strcasecmp(tag, block[i]) == 0) return 1;
    return 0;
}

static void apply_values(XwComputedStyle *target, const XwComputedStyle *value, uint32_t mask)
{
    if (mask & PROP_COLOR) target->color = value->color;
    if (mask & PROP_BACKGROUND) { target->background_color = value->background_color; target->has_background = value->has_background; }
    if (mask & PROP_DISPLAY) { target->display_none = value->display_none; target->display_inline = value->display_inline; }
    if (mask & PROP_FONT_SIZE) target->font_size_px = value->font_size_px;
    if (mask & PROP_WEIGHT) target->bold = value->bold;
    if (mask & PROP_ALIGN) target->align = value->align;
    if (mask & PROP_MARGIN_TOP) target->margin_top = value->margin_top;
    if (mask & PROP_MARGIN_BOT) target->margin_bottom = value->margin_bottom;
    if (mask & PROP_PADDING) target->padding = value->padding;
    if (mask & PROP_BORDER) target->border_width = value->border_width;
    if (mask & PROP_WIDTH) target->width_px = value->width_px;
}

void xw_css_collect_document_styles(XwStylesheet *sheet, const XwDocument *document)
{
    size_t i;
    if (sheet == NULL || document == NULL) return;
    for (i = 0U; i < document->node_count; ++i) {
        const XwDomNode *node = &document->nodes[i];
        if (node->type == XW_NODE_ELEMENT && strcasecmp(xw_dom_string(document, node->name_offset), "style") == 0) {
            uint16_t child = node->first_child;
            while (child != XW_DOM_NONE) {
                if (document->nodes[child].type == XW_NODE_TEXT) {
                    const char *text = xw_dom_string(document, document->nodes[child].value_offset);
                    (void)xw_css_parse(sheet, text, strlen(text));
                }
                child = document->nodes[child].next_sibling;
            }
        }
    }
}

void xw_css_compute(const XwStylesheet *sheet, const XwDocument *document,
                    uint16_t node_index, const XwComputedStyle *parent,
                    XwComputedStyle *computed)
{
    const char *tag;
    unsigned int property_specificity[11] = {0U};
    unsigned int property_order[11] = {0U};
    size_t i;
    if (document == NULL || computed == NULL || node_index >= document->node_count) return;
    memset(computed, 0, sizeof(*computed));
    computed->color = parent != NULL ? parent->color : 0xFF202124U;
    computed->background_color = 0x00000000U;
    computed->font_size_px = parent != NULL ? parent->font_size_px : 16;
    computed->align = parent != NULL ? parent->align : XW_ALIGN_LEFT;
    computed->width_px = -1;
    tag = xw_dom_string(document, document->nodes[node_index].name_offset);
    if (document->nodes[node_index].type == XW_NODE_ELEMENT) {
        computed->display_inline = !is_block_tag(tag);
        if (strcasecmp(tag, "script") == 0 || strcasecmp(tag, "style") == 0 ||
            strcasecmp(tag, "head") == 0 || strcasecmp(tag, "meta") == 0 ||
            strcasecmp(tag, "link") == 0 || strcasecmp(tag, "title") == 0) computed->display_none = 1;
        if (tag[0] == 'h' && tag[1] >= '1' && tag[1] <= '6' && tag[2] == '\0') {
            computed->bold = 1;
            computed->font_size_px = 32 - (tag[1] - '1') * 3;
        } else if (strcasecmp(tag, "strong") == 0 || strcasecmp(tag, "b") == 0) computed->bold = 1;
        if (strcasecmp(tag, "a") == 0) computed->color = 0xFF1A73E8U;
        if (strcasecmp(tag, "p") == 0 || tag[0] == 'h') { computed->margin_top = 8; computed->margin_bottom = 8; }
        if (strcasecmp(tag, "br") == 0) computed->display_inline = 1;
    }

    if (sheet != NULL) {
        for (i = 0U; i < sheet->rule_count; ++i) {
            const XwCssRule *rule = &sheet->rules[i];
            unsigned int prop;
            if (!selector_match(document, node_index, rule->selector)) continue;
            for (prop = 0U; prop < 11U; ++prop) {
                uint32_t bit = (uint32_t)(1UL << prop);
                if ((rule->declarations & bit) != 0U &&
                    (rule->specificity > property_specificity[prop] ||
                     (rule->specificity == property_specificity[prop] && rule->source_order >= property_order[prop]))) {
                    property_specificity[prop] = rule->specificity;
                    property_order[prop] = rule->source_order;
                    apply_values(computed, &rule->values, bit);
                }
            }
        }
    }
    {
        const char *inline_style = xw_dom_attribute(document, node_index, "style");
        if (inline_style != NULL) {
            XwComputedStyle inline_values;
            uint32_t mask = 0U;
            memset(&inline_values, 0, sizeof(inline_values));
            inline_values.color = computed->color;
            inline_values.background_color = computed->background_color;
            inline_values.font_size_px = computed->font_size_px;
            inline_values.width_px = computed->width_px;
            (void)parse_declarations(inline_style, strlen(inline_style), &inline_values, &mask);
            apply_values(computed, &inline_values, mask);
        }
    }
    if (computed->font_size_px < 8) computed->font_size_px = 8;
    if (computed->font_size_px > 48) computed->font_size_px = 48;
    if (computed->padding > 64) computed->padding = 64;
}
