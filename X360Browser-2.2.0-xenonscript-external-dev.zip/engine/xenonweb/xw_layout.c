#include "xw_layout.h"
#include "xw_dom.h"
#include "xw_css.h"
#include "xw_script.h"

#include <ctype.h>
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>

#define XW_LAYOUT_LEFT 16
#define XW_LAYOUT_RIGHT (WEB_VISUAL_WIDTH - 16)
#define XW_LAYOUT_TOP 18
#define XW_LAYOUT_MAX_DEPTH 64U
#define XW_DEFAULT_COLOR 0xFF202124U
#define XW_LINK_COLOR 0xFF1A73E8U
#define XW_FRAME_BACKGROUND 0xFFFFFFFFU

/* Reused rather than placed on the Xbox stack. Rendering is synchronous and
 * single-page; the DOM storage remains bounded to about 200 KiB. */
static XwDocument g_document;
static XwStylesheet g_stylesheet;
static WebVisualFrame g_cached_frame;
static uint64_t g_cached_page_hash;
static uint64_t g_document_page_hash;
static int g_cache_valid;
static int g_document_valid;

static uint64_t xw_hash_bytes(uint64_t hash, const char *data, size_t length)
{
    size_t i;
    for (i = 0U; i < length; ++i) {
        hash ^= (unsigned char)data[i];
        hash *= UINT64_C(1099511628211);
    }
    return hash;
}

static uint64_t xw_page_identity(const WebEnginePage *page)
{
    uint64_t hash = UINT64_C(1469598103934665603);
    size_t i;
    hash = xw_hash_bytes(hash, page->page_url, strlen(page->page_url));
    hash = xw_hash_bytes(hash, page->source_html, page->source_html_length);
    for (i = 0U; i < page->link_count; ++i)
        hash = xw_hash_bytes(hash, page->links[i].url, strlen(page->links[i].url));
    for (i = 0U; i < page->image_count; ++i) {
        hash = xw_hash_bytes(hash, page->images[i].url, strlen(page->images[i].url));
        hash = xw_hash_bytes(hash, page->images[i].cache_path, strlen(page->images[i].cache_path));
        hash = xw_hash_bytes(hash, page->images[i].alt, strlen(page->images[i].alt));
    }
    return hash;
}

static void xw_apply_scroll(WebVisualFrame *frame, size_t scroll_pixels)
{
    size_t i;
    int offset = scroll_pixels > (size_t)INT_MAX ? INT_MAX : (int)scroll_pixels;
    for (i = 0U; i < frame->rect_count; ++i) frame->rects[i].y -= offset;
    for (i = 0U; i < frame->text_count; ++i) frame->texts[i].y -= offset;
    for (i = 0U; i < frame->image_count; ++i) frame->images[i].y -= offset;
    for (i = 0U; i < frame->link_count; ++i) frame->links[i].y -= offset;
}

typedef struct {
    const WebEnginePage *page;
    WebVisualFrame *frame;
    int x;
    int y;
    int left;
    int right;
    int line_height;
    int line_y;
    int line_align;
    size_t line_text_start;
    size_t line_link_start;
    char run[WEB_VISUAL_TEXT_CAP];
    size_t run_length;
    uint32_t run_color;
    uint32_t run_scale;
    size_t run_link;
    int run_align;
    int pending_space;
    int preformatted;
    int truncation;
} XwLayoutContext;

static int xw_is_block(const char *tag, const XwComputedStyle *style)
{
    (void)tag;
    return !style->display_inline;
}

static uint32_t xw_text_scale(int px)
{
    if (px >= 30) return 3U;
    if (px >= 22) return 2U;
    return 1U;
}

static int xw_line_height(int px)
{
    int value = px + 6;
    if (value < 22) value = 22;
    if (value > 54) value = 54;
    return value;
}

static int xw_estimated_width(size_t bytes, uint32_t scale)
{
    uint64_t width = (uint64_t)bytes * 8U * (uint64_t)scale;
    return width > (uint64_t)INT_MAX ? INT_MAX : (int)width;
}

static void xw_mark_truncated(XwLayoutContext *ctx)
{
    if (ctx != NULL && ctx->frame != NULL) ctx->frame->truncated = 1;
}

static void xw_add_rect(XwLayoutContext *ctx, int x, int y, int width, int height,
                        uint32_t color, uint32_t border_color, int border_width)
{
    WebVisualRect *rect;
    if (ctx->frame->rect_count >= WEB_VISUAL_MAX_RECTS) {
        xw_mark_truncated(ctx);
        return;
    }
    if (width < 0) width = 0;
    if (height < 0) height = 0;
    rect = &ctx->frame->rects[ctx->frame->rect_count++];
    rect->x = x; rect->y = y; rect->width = width; rect->height = height;
    rect->color = color; rect->border_color = border_color; rect->border_width = border_width;
}

static void xw_align_line(XwLayoutContext *ctx, int line_width)
{
    int delta = 0;
    size_t i;
    if (ctx->line_align == XW_ALIGN_CENTER)
        delta = ((ctx->right - ctx->left) - line_width) / 2;
    else if (ctx->line_align == XW_ALIGN_RIGHT)
        delta = (ctx->right - ctx->left) - line_width;
    if (delta == 0) return;
    for (i = ctx->line_text_start; i < ctx->frame->text_count; ++i)
        if (ctx->frame->texts[i].y == ctx->line_y) ctx->frame->texts[i].x += delta;
    for (i = ctx->line_link_start; i < ctx->frame->link_count; ++i)
        if (ctx->frame->links[i].y == ctx->line_y) ctx->frame->links[i].x += delta;
}

static void xw_flush_run(XwLayoutContext *ctx)
{
    WebVisualText *text;
    int width;
    if (ctx->run_length == 0U) return;
    if (ctx->frame->text_count >= WEB_VISUAL_MAX_TEXTS) {
        xw_mark_truncated(ctx);
        ctx->run_length = 0U;
        ctx->run[0] = '\0';
        return;
    }
    text = &ctx->frame->texts[ctx->frame->text_count++];
    memset(text, 0, sizeof(*text));
    text->x = ctx->x;
    text->y = ctx->y;
    text->color = ctx->run_color;
    text->scale = ctx->run_scale;
    text->page_link_index = ctx->run_link;
    memcpy(text->text, ctx->run, ctx->run_length);
    text->text[ctx->run_length] = '\0';
    width = xw_estimated_width(ctx->run_length, ctx->run_scale);
    if (ctx->run_link != SIZE_MAX) {
        if (ctx->frame->link_count < WEB_VISUAL_MAX_LINK_RECTS) {
            WebVisualLink *link = &ctx->frame->links[ctx->frame->link_count++];
            link->x = ctx->x; link->y = ctx->y;
            link->width = width > 0 ? width : 8;
            link->height = ctx->line_height;
            link->page_link_index = ctx->run_link;
        } else xw_mark_truncated(ctx);
    }
    if (ctx->run_align != ctx->line_align && ctx->x == ctx->left) ctx->line_align = ctx->run_align;
    ctx->x += width;
    if (ctx->line_height < (int)(16U * ctx->run_scale + 6U))
        ctx->line_height = (int)(16U * ctx->run_scale + 6U);
    if ((size_t)(ctx->y + ctx->line_height) > ctx->frame->content_height)
        ctx->frame->content_height = (size_t)(ctx->y + ctx->line_height);
    ctx->run_length = 0U;
    ctx->run[0] = '\0';
}

static void xw_finish_line(XwLayoutContext *ctx, int advance)
{
    int width;
    xw_flush_run(ctx);
    width = ctx->x - ctx->left;
    xw_align_line(ctx, width);
    if (advance && (width > 0 || ctx->pending_space)) {
        ctx->y += ctx->line_height;
        ctx->x = ctx->left;
        ctx->line_height = 22;
        ctx->line_y = ctx->y;
        ctx->line_text_start = ctx->frame->text_count;
        ctx->line_link_start = ctx->frame->link_count;
        ctx->line_align = XW_ALIGN_LEFT;
        ctx->pending_space = 0;
    }
    if ((size_t)(ctx->y + ctx->line_height) > ctx->frame->content_height)
        ctx->frame->content_height = (size_t)(ctx->y + ctx->line_height);
}

static void xw_prepare_run(XwLayoutContext *ctx, const XwComputedStyle *style, size_t link_index)
{
    uint32_t color = style->color;
    uint32_t scale = xw_text_scale(style->font_size_px);
    int align = style->align;
    if (ctx->run_length > 0U && (ctx->run_color != color || ctx->run_scale != scale ||
                                 ctx->run_link != link_index || ctx->run_align != align))
        xw_flush_run(ctx);
    if (ctx->run_length == 0U) {
        ctx->run_color = color;
        ctx->run_scale = scale;
        ctx->run_link = link_index;
        ctx->run_align = align;
        if (ctx->x == ctx->left && ctx->frame->text_count == ctx->line_text_start)
            ctx->line_align = align;
    }
    if (ctx->line_height < xw_line_height(style->font_size_px))
        ctx->line_height = xw_line_height(style->font_size_px);
}

static void xw_append_fragment(XwLayoutContext *ctx, const char *text, size_t length,
                               const XwComputedStyle *style, size_t link_index)
{
    size_t start = 0U;
    while (start < length) {
        size_t available;
        size_t chunk;
        int space_width = 0;
        int word_width;
        xw_prepare_run(ctx, style, link_index);
        if (ctx->pending_space && (ctx->x > ctx->left || ctx->run_length > 0U)) space_width = (int)(8U * ctx->run_scale);
        word_width = xw_estimated_width(length - start, ctx->run_scale);
        if (ctx->x + (int)ctx->run_length * (int)(8U * ctx->run_scale) + space_width + word_width > ctx->right &&
            (ctx->x > ctx->left || ctx->run_length > 0U)) {
            xw_finish_line(ctx, 1);
            xw_prepare_run(ctx, style, link_index);
            space_width = 0;
        }
        if (space_width > 0 && ctx->run_length + 1U < sizeof(ctx->run)) {
            ctx->run[ctx->run_length++] = ' ';
            ctx->run[ctx->run_length] = '\0';
        }
        ctx->pending_space = 0;
        available = sizeof(ctx->run) - ctx->run_length - 1U;
        if (available == 0U) {
            xw_flush_run(ctx);
            available = sizeof(ctx->run) - 1U;
        }
        chunk = length - start < available ? length - start : available;
        if (chunk == 0U) { xw_mark_truncated(ctx); break; }
        memcpy(ctx->run + ctx->run_length, text + start, chunk);
        ctx->run_length += chunk;
        ctx->run[ctx->run_length] = '\0';
        start += chunk;
        if (start < length) xw_flush_run(ctx);
    }
}

static void xw_append_text_node(XwLayoutContext *ctx, const char *text,
                                const XwComputedStyle *style, size_t link_index,
                                int preformatted)
{
    size_t p = 0U;
    size_t length = strlen(text);
    if (preformatted) {
        while (p < length) {
            if (text[p] == '\n' || text[p] == '\r') {
                xw_finish_line(ctx, 1);
                if (text[p] == '\r' && p + 1U < length && text[p + 1U] == '\n') ++p;
                ++p;
            } else {
                size_t end = p;
                while (end < length && text[end] != '\n' && text[end] != '\r') ++end;
                if (end > p) xw_append_fragment(ctx, text + p, end - p, style, link_index);
                p = end;
            }
        }
        return;
    }
    while (p < length) {
        if (isspace((unsigned char)text[p])) {
            if (ctx->x > ctx->left || ctx->run_length > 0U) ctx->pending_space = 1;
            ++p;
            continue;
        }
        {
            size_t end = p;
            while (end < length && !isspace((unsigned char)text[end])) ++end;
            xw_append_fragment(ctx, text + p, end - p, style, link_index);
            p = end;
        }
    }
}

static int xw_parse_dimension(const char *value, int fallback, int minimum, int maximum)
{
    char *end = NULL;
    long n;
    if (value == NULL || value[0] == '\0') return fallback;
    n = strtol(value, &end, 10);
    if (end == value) return fallback;
    if (n < minimum) n = minimum;
    if (n > maximum) n = maximum;
    return (int)n;
}

static void xw_resolve_href(const char *base, const char *href, char *out, size_t capacity)
{
    const char *scheme_end;
    const char *host_end;
    const char *last_slash;
    size_t origin_len;
    size_t dir_len;
    if (capacity == 0U) return;
    out[0] = '\0';
    if (base == NULL || href == NULL || href[0] == '\0') return;
    if (href[0] == '#') {
        const char *fragment = strchr(base, '#');
        size_t base_length = fragment != NULL ? (size_t)(fragment - base) : strlen(base);
        (void)snprintf(out, capacity, "%.*s%s", (int)base_length, base, href);
        return;
    }
    if (strncasecmp(href, "http://", 7U) == 0 || strncasecmp(href, "https://", 8U) == 0) {
        (void)snprintf(out, capacity, "%s", href); return;
    }
    if (strncasecmp(href, "javascript:", 11U) == 0 || strncasecmp(href, "data:", 5U) == 0 ||
        strncasecmp(href, "mailto:", 7U) == 0) return;
    scheme_end = strstr(base, "://");
    if (scheme_end == NULL) { (void)snprintf(out, capacity, "%s", href); return; }
    if (href[0] == '/' && href[1] == '/') {
        (void)snprintf(out, capacity, "%.*s:%s", (int)(scheme_end - base), base, href); return;
    }
    host_end = strchr(scheme_end + 3, '/');
    origin_len = host_end == NULL ? strlen(base) : (size_t)(host_end - base);
    if (href[0] == '/') { (void)snprintf(out, capacity, "%.*s%s", (int)origin_len, base, href); return; }
    last_slash = strrchr(base, '/');
    if (last_slash == NULL || last_slash < scheme_end + 3) dir_len = strlen(base);
    else dir_len = (size_t)(last_slash - base + 1);
    (void)snprintf(out, capacity, "%.*s%s", (int)dir_len, base, href);
}

static size_t xw_link_index(const WebEnginePage *page, const char *href)
{
    char resolved[WEB_ENGINE_LINK_URL_CAP];
    size_t i;
    if (page == NULL || href == NULL) return SIZE_MAX;
    xw_resolve_href(page->page_url, href, resolved, sizeof(resolved));
    if (resolved[0] == '\0') return SIZE_MAX;
    for (i = 0U; i < page->link_count; ++i)
        if (strcmp(page->links[i].url, resolved) == 0) return i;
    return SIZE_MAX;
}

static const WebEngineImage *xw_find_image(const WebEnginePage *page, const char *src, const char *alt)
{
    size_t i;
    if (page == NULL || src == NULL) return NULL;
    for (i = 0U; i < page->image_count; ++i) {
        const WebEngineImage *image = &page->images[i];
        const char *image_name = strrchr(image->url, '/');
        const char *src_name = strrchr(src, '/');
        if (image_name == NULL) image_name = image->url; else ++image_name;
        if (src_name == NULL) src_name = src; else ++src_name;
        if (strcmp(image->url, src) == 0 || (src_name[0] != '\0' && strcmp(image_name, src_name) == 0) ||
            (alt != NULL && alt[0] != '\0' && strcmp(image->alt, alt) == 0)) return image;
    }
    return NULL;
}

static void xw_render_node(XwLayoutContext *ctx, uint16_t node_index,
                           const XwComputedStyle *parent_style, size_t active_link,
                           int preformatted, unsigned depth);

static void xw_render_children(XwLayoutContext *ctx, uint16_t parent_index,
                              const XwComputedStyle *parent_style, size_t active_link,
                              int preformatted, unsigned depth)
{
    uint16_t child;
    if (depth >= XW_LAYOUT_MAX_DEPTH) { xw_mark_truncated(ctx); return; }
    child = ctx->frame != NULL ? g_document.nodes[parent_index].first_child : XW_DOM_NONE;
    while (child != XW_DOM_NONE) {
        uint16_t next = g_document.nodes[child].next_sibling;
        xw_render_node(ctx, child, parent_style, active_link, preformatted, depth + 1U);
        child = next;
        if (ctx->frame->truncated && (ctx->frame->text_count >= WEB_VISUAL_MAX_TEXTS ||
                                     ctx->frame->rect_count >= WEB_VISUAL_MAX_RECTS)) break;
    }
}

static void xw_render_image(XwLayoutContext *ctx, uint16_t node_index,
                            const XwComputedStyle *style)
{
    const char *src = xw_dom_attribute(&g_document, node_index, "src");
    const char *alt = xw_dom_attribute(&g_document, node_index, "alt");
    const char *width_attr = xw_dom_attribute(&g_document, node_index, "width");
    const char *height_attr = xw_dom_attribute(&g_document, node_index, "height");
    const WebEngineImage *cached;
    int width = xw_parse_dimension(width_attr, 300, 40, WEB_VISUAL_WIDTH - 32);
    int height = xw_parse_dimension(height_attr, 96, 24, WEB_VISUAL_HEIGHT - 28);
    int x;
    size_t placeholder = SIZE_MAX;
    WebVisualText *text;
    xw_flush_run(ctx);
    if (ctx->x + width > ctx->right && ctx->x > ctx->left) xw_finish_line(ctx, 1);
    if (ctx->frame->image_count >= WEB_VISUAL_MAX_IMAGES) {
        xw_mark_truncated(ctx);
        return;
    }
    if (alt == NULL || alt[0] == '\0') alt = "Image";
    cached = xw_find_image(ctx->page, src, alt);
    x = ctx->x;
    if (x + width > ctx->right) x = ctx->left;
    xw_add_rect(ctx, x, ctx->y, width, height,
                style->has_background ? style->background_color : 0xFFF4F6F8U,
                0xFFB8C1CCU, 1);
    if (ctx->frame->text_count < WEB_VISUAL_MAX_TEXTS) {
        placeholder = ctx->frame->text_count;
        text = &ctx->frame->texts[ctx->frame->text_count++];
        memset(text, 0, sizeof(*text));
        text->x = x + 8; text->y = ctx->y + 8; text->color = 0xFF4A5568U; text->scale = 1U; text->page_link_index = SIZE_MAX;
        (void)snprintf(text->text, sizeof(text->text), "[Image: %.180s]", alt);
    }
    if (cached != NULL && cached->cache_path[0] != '\0') {
        WebVisualImage *image = &ctx->frame->images[ctx->frame->image_count++];
        memset(image, 0, sizeof(*image));
        image->x = x; image->y = ctx->y; image->width = width; image->height = height;
        image->placeholder_text_index = placeholder;
        (void)snprintf(image->cache_path, sizeof(image->cache_path), "%s", cached->cache_path);
    }
    ctx->x = x + width + 8;
    if (ctx->line_height < height) ctx->line_height = height;
    if ((size_t)(ctx->y + height) > ctx->frame->content_height) ctx->frame->content_height = (size_t)(ctx->y + height);
    ctx->pending_space = 1;
}

static void xw_render_control(XwLayoutContext *ctx, uint16_t node_index,
                              const char *tag, const XwComputedStyle *style)
{
    const char *value = xw_dom_attribute(&g_document, node_index, "value");
    const char *placeholder = xw_dom_attribute(&g_document, node_index, "placeholder");
    const char *type = xw_dom_attribute(&g_document, node_index, "type");
    char label[WEB_VISUAL_TEXT_CAP];
    int width = style->width_px > 0 ? style->width_px : (strcasecmp(tag, "button") == 0 ? 160 : 260);
    int height = strcasecmp(tag, "textarea") == 0 ? 76 : 34;
    WebVisualText *text;
    xw_flush_run(ctx);
    if (ctx->x + width > ctx->right && ctx->x > ctx->left) xw_finish_line(ctx, 1);
    width = width > ctx->right - ctx->left ? ctx->right - ctx->left : width;
    if (strcasecmp(tag, "button") == 0) {
        const char *button_text = value != NULL && value[0] != '\0' ? value : "Button";
        (void)snprintf(label, sizeof(label), "[ %s ]", button_text);
    } else if (strcasecmp(tag, "textarea") == 0) {
        (void)snprintf(label, sizeof(label), "[ Text area: %.150s ]", placeholder != NULL ? placeholder : "");
    } else if (strcasecmp(tag, "select") == 0) {
        (void)snprintf(label, sizeof(label), "[ Select: %.150s ]", value != NULL ? value : "choose");
    } else {
        (void)snprintf(label, sizeof(label), "[ %s: %.150s ]", type != NULL ? type : "input",
                       value != NULL && value[0] != '\0' ? value : (placeholder != NULL ? placeholder : ""));
    }
    xw_add_rect(ctx, ctx->x, ctx->y, width, height,
                style->has_background ? style->background_color : 0xFFF9FAFBU,
                0xFF9CA3AFU, style->border_width > 0 ? style->border_width : 1);
    if (ctx->frame->text_count < WEB_VISUAL_MAX_TEXTS) {
        text = &ctx->frame->texts[ctx->frame->text_count++];
        memset(text, 0, sizeof(*text));
        text->x = ctx->x + 8; text->y = ctx->y + 8; text->color = style->color; text->scale = 1U; text->page_link_index = SIZE_MAX;
        (void)snprintf(text->text, sizeof(text->text), "%s", label);
    }
    ctx->x += width + 8;
    if (ctx->line_height < height) ctx->line_height = height;
    ctx->pending_space = 1;
}

static void xw_render_node(XwLayoutContext *ctx, uint16_t node_index,
                           const XwComputedStyle *parent_style, size_t active_link,
                           int preformatted, unsigned depth)
{
    const XwDomNode *node;
    const char *tag;
    XwComputedStyle style;
    int block;
    int block_start_y;
    int old_left, old_right, old_pre;
    size_t link_index = active_link;
    size_t background_rect = SIZE_MAX;
    if (node_index >= g_document.node_count || depth >= XW_LAYOUT_MAX_DEPTH) {
        xw_mark_truncated(ctx); return;
    }
    node = &g_document.nodes[node_index];
    if (node->type == XW_NODE_TEXT) {
        xw_append_text_node(ctx, xw_dom_string(&g_document, node->value_offset), parent_style,
                            active_link, preformatted);
        return;
    }
    if (node->type != XW_NODE_ELEMENT) {
        xw_render_children(ctx, node_index, parent_style, active_link, preformatted, depth);
        return;
    }
    tag = xw_dom_string(&g_document, node->name_offset);
    xw_css_compute(&g_stylesheet, &g_document, node_index, parent_style, &style);
    if (style.display_none) return;
    if (strcasecmp(tag, "a") == 0) {
        const char *href = xw_dom_attribute(&g_document, node_index, "href");
        xw_flush_run(ctx);
        link_index = xw_link_index(ctx->page, href);
        if (link_index == SIZE_MAX) style.color = XW_LINK_COLOR;
    }
    if (strcasecmp(tag, "br") == 0) { ctx->pending_space = 0; xw_finish_line(ctx, 1); return; }
    if (strcasecmp(tag, "hr") == 0) {
        xw_finish_line(ctx, 1);
        xw_add_rect(ctx, ctx->left, ctx->y, ctx->right - ctx->left, 2, 0xFFDDDDDDU, 0xFFDDDDDDU, 0);
        ctx->y += 12; ctx->x = ctx->left; ctx->line_y = ctx->y;
        return;
    }
    if (strcasecmp(tag, "img") == 0) { xw_render_image(ctx, node_index, &style); return; }
    if (strcasecmp(tag, "input") == 0 || strcasecmp(tag, "button") == 0 ||
        strcasecmp(tag, "textarea") == 0 || strcasecmp(tag, "select") == 0) {
        xw_render_control(ctx, node_index, tag, &style);
        if (strcasecmp(tag, "button") == 0 || strcasecmp(tag, "textarea") == 0 || strcasecmp(tag, "select") == 0)
            xw_render_children(ctx, node_index, &style, link_index, preformatted, depth);
        return;
    }
    if (strcasecmp(tag, "video") == 0 || strcasecmp(tag, "audio") == 0 || strcasecmp(tag, "iframe") == 0 ||
        strcasecmp(tag, "canvas") == 0) {
        char label[WEB_VISUAL_TEXT_CAP];
        xw_finish_line(ctx, 1);
        if (strcasecmp(tag, "iframe") == 0) (void)snprintf(label, sizeof(label), "[Embedded frame: not supported by this engine build]");
        else if (strcasecmp(tag, "canvas") == 0) (void)snprintf(label, sizeof(label), "[Canvas: JavaScript API unavailable]");
        else (void)snprintf(label, sizeof(label), "[%s: inline playback is not implemented; use media/download view]", tag);
        xw_add_rect(ctx, ctx->left, ctx->y, ctx->right - ctx->left, 48, 0xFFF4F6F8U, 0xFFB8C1CCU, 1);
        if (ctx->frame->text_count < WEB_VISUAL_MAX_TEXTS) {
            WebVisualText *text = &ctx->frame->texts[ctx->frame->text_count++];
            memset(text, 0, sizeof(*text)); text->x = ctx->left + 10; text->y = ctx->y + 14;
            text->color = 0xFF4A5568U; text->scale = 1U; text->page_link_index = SIZE_MAX;
            (void)snprintf(text->text, sizeof(text->text), "%s", label);
        }
        ctx->y += 54; ctx->x = ctx->left; ctx->line_y = ctx->y;
        if (strcasecmp(tag, "iframe") == 0 || strcasecmp(tag, "canvas") == 0) return;
        /* Media contents are not rendered as text. */
        return;
    }
    block = xw_is_block(tag, &style);
    old_left = ctx->left; old_right = ctx->right; old_pre = preformatted;
    if (block) {
        xw_finish_line(ctx, 1);
        ctx->y += style.margin_top;
        ctx->x = ctx->left;
        block_start_y = ctx->y;
        if (style.padding > 0) {
            ctx->left += style.padding;
            ctx->right -= style.padding;
            if (ctx->left >= ctx->right) { ctx->left = old_left; ctx->right = old_right; }
        }
        if (style.has_background || style.border_width > 0) {
            background_rect = ctx->frame->rect_count;
            xw_add_rect(ctx, old_left, block_start_y, old_right - old_left, 1,
                        style.background_color, style.color, style.border_width);
        }
    } else {
        block_start_y = ctx->y;
    }
    if (strcasecmp(tag, "pre") == 0 || strcasecmp(tag, "textarea") == 0) preformatted = 1;
    if (strcasecmp(tag, "li") == 0) {
        static const char bullet[] = "-";
        xw_append_text_node(ctx, bullet, &style, link_index, 0);
        ctx->pending_space = 1;
    }
    xw_render_children(ctx, node_index, &style, link_index, preformatted, depth);
    if (block) {
        xw_finish_line(ctx, 1);
        if (background_rect != SIZE_MAX && background_rect < ctx->frame->rect_count) {
            int height = ctx->y - block_start_y;
            if (height < 1) height = 1;
            ctx->frame->rects[background_rect].height = height + style.padding;
        }
        ctx->left = old_left; ctx->right = old_right;
        ctx->x = ctx->left;
        ctx->y += style.margin_bottom;
        ctx->line_y = ctx->y;
        ctx->line_text_start = ctx->frame->text_count;
        ctx->line_link_start = ctx->frame->link_count;
        ctx->line_align = XW_ALIGN_LEFT;
        ctx->line_height = 22;
        ctx->pending_space = 0;
    }
    (void)old_pre;
    if ((size_t)(ctx->y + ctx->line_height) > ctx->frame->content_height)
        ctx->frame->content_height = (size_t)(ctx->y + ctx->line_height);
}

int xw_layout_page(const WebEnginePage *page, size_t scroll_pixels, WebVisualFrame *frame)
{
    XwLayoutContext ctx;
    size_t i;
    uint16_t body = XW_DOM_NONE;
    XwComputedStyle base_style;
    XwScriptStats script_stats;
    uint64_t identity;
    if (page == NULL || frame == NULL || page->source_html_length == 0U || page->source_html[0] == '\0') return 0;
    if (page->source_html_length >= sizeof(page->source_html)) return 0;
    identity = xw_page_identity(page);
    if (g_cache_valid && identity == g_cached_page_hash) {
        *frame = g_cached_frame;
        xw_apply_scroll(frame, scroll_pixels);
        return 1;
    }
    memset(&script_stats, 0, sizeof(script_stats));
    if (!g_document_valid || identity != g_document_page_hash) {
        g_document_valid = 0;
        if (!xw_dom_parse(&g_document, page->source_html, page->source_html_length)) return 0;
        /* Execute bounded first-party inline scripts once per loaded document. */
        (void)xw_script_run_document(&g_document, XW_SCRIPT_MAX_STATEMENTS, &script_stats);
        g_document_page_hash = identity;
        g_document_valid = 1;
    }
    xw_css_init(&g_stylesheet);
    xw_css_collect_document_styles(&g_stylesheet, &g_document);
    memset(frame, 0, sizeof(*frame));
    frame->background = XW_FRAME_BACKGROUND;
    memset(&ctx, 0, sizeof(ctx));
    ctx.page = page; ctx.frame = frame;
    ctx.x = XW_LAYOUT_LEFT; ctx.left = XW_LAYOUT_LEFT; ctx.right = XW_LAYOUT_RIGHT;
    ctx.y = XW_LAYOUT_TOP; ctx.line_y = ctx.y; ctx.line_height = 22;
    ctx.run_link = SIZE_MAX; ctx.line_align = XW_ALIGN_LEFT;
    ctx.line_text_start = 0U; ctx.line_link_start = 0U;

    for (i = 0U; i < g_document.node_count; ++i) {
        if (g_document.nodes[i].type == XW_NODE_ELEMENT &&
            strcasecmp(xw_dom_string(&g_document, g_document.nodes[i].name_offset), "body") == 0) {
            body = (uint16_t)i; break;
        }
    }
    memset(&base_style, 0, sizeof(base_style));
    base_style.color = XW_DEFAULT_COLOR;
    base_style.font_size_px = 16;
    base_style.align = XW_ALIGN_LEFT;
    base_style.width_px = -1;
    if (body != XW_DOM_NONE) {
        XwComputedStyle body_style;
        xw_css_compute(&g_stylesheet, &g_document, body, &base_style, &body_style);
        if (body_style.has_background && (body_style.background_color >> 24U) != 0U)
            frame->background = body_style.background_color;
        xw_render_children(&ctx, body, &body_style, SIZE_MAX, 0, 0U);
    } else {
        xw_render_children(&ctx, g_document.root, &base_style, SIZE_MAX, 0, 0U);
    }
    xw_flush_run(&ctx);
    if (ctx.x > ctx.left) xw_finish_line(&ctx, 0);
    if (frame->content_height < (size_t)(ctx.y + ctx.line_height))
        frame->content_height = (size_t)(ctx.y + ctx.line_height);
    if (g_document.truncated || g_stylesheet.truncated || ctx.truncation || script_stats.truncated) frame->truncated = 1;
    g_cached_frame = *frame; /* Cache absolute document coordinates, never scrolled values. */
    g_cached_page_hash = identity;
    g_cache_valid = 1;
    xw_apply_scroll(frame, scroll_pixels);
    return 1;
}


int xw_layout_dispatch_link(const WebEnginePage *page, size_t page_link_index,
                            int *navigation_consumed)
{
    size_t i;
    uint64_t identity;
    if (navigation_consumed != NULL) *navigation_consumed = 0;
    if (page == NULL || page_link_index >= page->link_count) return 0;
    identity = xw_page_identity(page);
    if (!g_document_valid || identity != g_document_page_hash) {
        WebVisualFrame ignored_frame;
        if (!xw_layout_page(page, 0U, &ignored_frame)) return 0;
    }
    for (i = 0U; i < g_document.node_count; ++i) {
        const char *tag;
        const char *href;
        const char *handler;
        XwScriptStats stats;
        if (g_document.nodes[i].type != XW_NODE_ELEMENT) continue;
        tag = xw_dom_string(&g_document, g_document.nodes[i].name_offset);
        if (strcasecmp(tag, "a") != 0) continue;
        href = xw_dom_attribute(&g_document, (uint16_t)i, "href");
        if (xw_link_index(page, href) != page_link_index) continue;
        handler = xw_dom_attribute(&g_document, (uint16_t)i, "onclick");
        if (handler == NULL || handler[0] == '\0') return 0;
        (void)xw_script_execute_code(&g_document, handler, strlen(handler), 256U, &stats);
        g_cache_valid = 0;
        if (navigation_consumed != NULL && (href[0] == '#' || href[0] == '\0'))
            *navigation_consumed = 1;
        return 1;
    }
    return 0;
}

int web_visual_dispatch_link(const WebEnginePage *page, size_t page_link_index,
                             int *navigation_consumed)
{
    return xw_layout_dispatch_link(page, page_link_index, navigation_consumed);
}

void web_visual_layout(const WebEnginePage *page, size_t scroll_pixels, WebVisualFrame *frame)
{
    if (frame == NULL) return;
    if (!xw_layout_page(page, scroll_pixels, frame))
        web_visual_layout_legacy(page, scroll_pixels, frame);
}
