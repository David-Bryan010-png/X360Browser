#include "xw_dom.h"

#include <ctype.h>
#include <limits.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>

#define XW_NODE_FLAG_VOID 1U

static int is_space_char(char c)
{
    return c == ' ' || c == '\t' || c == '\r' || c == '\n' || c == '\f';
}

static int is_name_char(char c)
{
    return isalnum((unsigned char)c) || c == '-' || c == '_' || c == ':' || c == '.';
}

static int is_void_tag(const char *name)
{
    static const char *const tags[] = {
        "area", "base", "br", "col", "embed", "hr", "img", "input",
        "link", "meta", "param", "source", "track", "wbr"
    };
    size_t i;
    for (i = 0U; i < sizeof(tags) / sizeof(tags[0]); ++i) {
        if (strcasecmp(name, tags[i]) == 0) return 1;
    }
    return 0;
}

static uint32_t pool_put_n(XwDocument *document, const char *src, size_t length)
{
    size_t room;
    size_t copy_len;
    size_t start;
    if (length == 0U) return 0U;
    if (document->strings_used >= XW_DOM_STRING_POOL_SIZE - 1U) {
        document->truncated = 1;
        return 0U;
    }
    room = XW_DOM_STRING_POOL_SIZE - document->strings_used - 1U;
    copy_len = length < room ? length : room;
    if (copy_len == 0U) {
        document->truncated = 1;
        return 0U;
    }
    start = document->strings_used;
    memcpy(document->strings + start, src, copy_len);
    document->strings[start + copy_len] = '\0';
    document->strings_used += copy_len + 1U;
    if (copy_len != length) document->truncated = 1;
    return (uint32_t)start;
}

static size_t encode_utf8(unsigned long codepoint, char encoded[4])
{
    if (codepoint == 0UL || codepoint > 0x10FFFFUL ||
        (codepoint >= 0xD800UL && codepoint <= 0xDFFFUL)) codepoint = 0xFFFDU;
    if (codepoint <= 0x7FUL) {
        encoded[0] = (char)codepoint;
        return 1U;
    }
    if (codepoint <= 0x7FFUL) {
        encoded[0] = (char)(0xC0UL | (codepoint >> 6U));
        encoded[1] = (char)(0x80UL | (codepoint & 0x3FUL));
        return 2U;
    }
    if (codepoint <= 0xFFFFUL) {
        encoded[0] = (char)(0xE0UL | (codepoint >> 12U));
        encoded[1] = (char)(0x80UL | ((codepoint >> 6U) & 0x3FUL));
        encoded[2] = (char)(0x80UL | (codepoint & 0x3FUL));
        return 3U;
    }
    encoded[0] = (char)(0xF0UL | (codepoint >> 18U));
    encoded[1] = (char)(0x80UL | ((codepoint >> 12U) & 0x3FUL));
    encoded[2] = (char)(0x80UL | ((codepoint >> 6U) & 0x3FUL));
    encoded[3] = (char)(0x80UL | (codepoint & 0x3FUL));
    return 4U;
}

static int entity_value(const char *entity, size_t length, unsigned long *codepoint)
{
    struct NamedEntity { const char *name; unsigned long code; };
    static const struct NamedEntity named[] = {
        {"amp", 38UL}, {"apos", 39UL}, {"gt", 62UL}, {"lt", 60UL},
        {"nbsp", 160UL}, {"quot", 34UL}, {"copy", 169UL}, {"reg", 174UL},
        {"ndash", 0x2013UL}, {"mdash", 0x2014UL}, {"hellip", 0x2026UL},
        {"eacute", 0xE9UL}, {"Eacute", 0xC9UL}, {"aacute", 0xE1UL},
        {"Aacute", 0xC1UL}, {"ccedil", 0xE7UL}, {"Ccedil", 0xC7UL},
        {"atilde", 0xE3UL}, {"otilde", 0xF5UL}, {"uuml", 0xFCUL},
        {"ouml", 0xF6UL}, {"rsquo", 0x2019UL}, {"ldquo", 0x201CUL},
        {"rdquo", 0x201DUL}
    };
    size_t i;
    if (length >= 2U && entity[0] == '#') {
        char number[16];
        char *end = NULL;
        int base = 10;
        size_t start = 1U;
        size_t n;
        if (start < length && (entity[start] == 'x' || entity[start] == 'X')) {
            base = 16;
            ++start;
        }
        n = length - start;
        if (n == 0U || n >= sizeof(number)) return 0;
        memcpy(number, entity + start, n);
        number[n] = '\0';
        *codepoint = strtoul(number, &end, base);
        return end != number && *end == '\0';
    }
    for (i = 0U; i < sizeof(named) / sizeof(named[0]); ++i) {
        if (strlen(named[i].name) == length &&
            memcmp(named[i].name, entity, length) == 0) {
            *codepoint = named[i].code;
            return 1;
        }
    }
    return 0;
}

static uint32_t pool_put_decoded(XwDocument *document, const char *src, size_t length)
{
    size_t start;
    size_t out = 0U;
    size_t i = 0U;
    size_t room;
    if (length == 0U) return 0U;
    if (document->strings_used >= XW_DOM_STRING_POOL_SIZE - 1U) {
        document->truncated = 1;
        return 0U;
    }
    start = document->strings_used;
    room = XW_DOM_STRING_POOL_SIZE - start - 1U;
    while (i < length && out < room) {
        if (src[i] == '&') {
            size_t semicolon = i + 1U;
            unsigned long cp = 0UL;
            while (semicolon < length && semicolon - i <= 16U && src[semicolon] != ';' &&
                   !is_space_char(src[semicolon]) && src[semicolon] != '&' && src[semicolon] != '<') ++semicolon;
            if (semicolon < length && src[semicolon] == ';' &&
                entity_value(src + i + 1U, semicolon - i - 1U, &cp)) {
                char encoded[4];
                size_t encoded_length = encode_utf8(cp, encoded);
                if (out + encoded_length > room) break;
                memcpy(document->strings + start + out, encoded, encoded_length);
                out += encoded_length;
                i = semicolon + 1U;
                continue;
            }
        }
        document->strings[start + out++] = src[i++];
    }
    document->strings[start + out] = '\0';
    document->strings_used = start + out + 1U;
    if (i != length) document->truncated = 1;
    return (uint32_t)start;
}

const char *xw_dom_string(const XwDocument *document, uint32_t offset)
{
    if (document == NULL || offset >= document->strings_used) return "";
    return document->strings + offset;
}

static uint16_t add_node(XwDocument *document, XwNodeType type, uint16_t parent,
                         const char *name, size_t name_length,
                         const char *value, size_t value_length)
{
    uint16_t index;
    XwDomNode *node;
    if (document->node_count >= XW_DOM_MAX_NODES) {
        document->truncated = 1;
        return XW_DOM_NONE;
    }
    index = (uint16_t)document->node_count++;
    node = &document->nodes[index];
    memset(node, 0, sizeof(*node));
    node->parent = parent;
    node->first_child = XW_DOM_NONE;
    node->last_child = XW_DOM_NONE;
    node->next_sibling = XW_DOM_NONE;
    node->first_attribute = XW_DOM_NONE;
    node->type = (uint8_t)type;
    node->name_offset = pool_put_n(document, name != NULL ? name : "", name_length);
    node->value_offset = pool_put_decoded(document, value != NULL ? value : "", value_length);
    if (parent != XW_DOM_NONE && parent < document->node_count) {
        XwDomNode *p = &document->nodes[parent];
        if (p->last_child == XW_DOM_NONE) p->first_child = index;
        else document->nodes[p->last_child].next_sibling = index;
        p->last_child = index;
    }
    return index;
}

static void add_attribute(XwDocument *document, uint16_t node_index,
                          const char *name, size_t name_length,
                          const char *value, size_t value_length)
{
    XwDomNode *node;
    XwDomAttribute *attribute;
    uint16_t index;
    uint16_t cursor;
    if (node_index >= document->node_count || document->attribute_count >= XW_DOM_MAX_ATTRIBUTES) {
        document->truncated = 1;
        return;
    }
    node = &document->nodes[node_index];
    cursor = node->first_attribute;
    while (cursor != XW_DOM_NONE) {
        const char *existing = xw_dom_string(document, document->attributes[cursor].name_offset);
        if (strlen(existing) == name_length && strncasecmp(existing, name, name_length) == 0)
            return; /* HTML uses the first duplicate attribute. */
        cursor = document->attributes[cursor].next;
    }
    index = (uint16_t)document->attribute_count++;
    attribute = &document->attributes[index];
    attribute->name_offset = pool_put_n(document, name, name_length);
    attribute->value_offset = pool_put_decoded(document, value != NULL ? value : "", value_length);
    attribute->next = XW_DOM_NONE;
    if (node->first_attribute == XW_DOM_NONE) node->first_attribute = index;
    else {
        cursor = node->first_attribute;
        while (document->attributes[cursor].next != XW_DOM_NONE)
            cursor = document->attributes[cursor].next;
        document->attributes[cursor].next = index;
    }
    ++node->attribute_count;
}

const char *xw_dom_attribute(const XwDocument *document, uint16_t node_index,
                             const char *attribute_name)
{
    uint16_t cursor;
    if (document == NULL || node_index >= document->node_count || attribute_name == NULL) return NULL;
    cursor = document->nodes[node_index].first_attribute;
    while (cursor != XW_DOM_NONE) {
        const char *name = xw_dom_string(document, document->attributes[cursor].name_offset);
        if (strcasecmp(name, attribute_name) == 0)
            return xw_dom_string(document, document->attributes[cursor].value_offset);
        cursor = document->attributes[cursor].next;
    }
    return NULL;
}

int xw_dom_set_attribute(XwDocument *document, uint16_t node_index,
                         const char *attribute_name, const char *value)
{
    uint16_t cursor;
    size_t name_length;
    size_t value_length;
    uint32_t value_offset;
    XwDomAttribute *attribute;
    if (document == NULL || node_index >= document->node_count ||
        attribute_name == NULL || attribute_name[0] == '\0' || value == NULL) return 0;
    name_length = strlen(attribute_name);
    value_length = strlen(value);
    if (name_length >= 64U || value_length >= XW_DOM_STRING_POOL_SIZE) return 0;
    cursor = document->nodes[node_index].first_attribute;
    while (cursor != XW_DOM_NONE) {
        attribute = &document->attributes[cursor];
        if (strcasecmp(xw_dom_string(document, attribute->name_offset), attribute_name) == 0) {
            value_offset = pool_put_n(document, value, value_length);
            if (document->truncated) return 0;
            attribute->value_offset = value_offset;
            return 1;
        }
        cursor = attribute->next;
    }
    if (document->attribute_count >= XW_DOM_MAX_ATTRIBUTES) {
        document->truncated = 1;
        return 0;
    }
    value_offset = pool_put_n(document, value, value_length);
    if (document->truncated) return 0;
    cursor = (uint16_t)document->attribute_count++;
    attribute = &document->attributes[cursor];
    attribute->name_offset = pool_put_n(document, attribute_name, name_length);
    if (document->truncated) return 0;
    attribute->value_offset = value_offset;
    attribute->next = XW_DOM_NONE;
    if (document->nodes[node_index].first_attribute == XW_DOM_NONE) {
        document->nodes[node_index].first_attribute = cursor;
    } else {
        uint16_t tail = document->nodes[node_index].first_attribute;
        while (document->attributes[tail].next != XW_DOM_NONE) tail = document->attributes[tail].next;
        document->attributes[tail].next = cursor;
    }
    ++document->nodes[node_index].attribute_count;
    return 1;
}

int xw_dom_set_text_content(XwDocument *document, uint16_t node_index,
                            const char *value)
{
    XwDomNode *element;
    uint16_t child;
    size_t length;
    uint32_t offset;
    if (document == NULL || node_index >= document->node_count || value == NULL ||
        document->nodes[node_index].type != XW_NODE_ELEMENT) return 0;
    length = strlen(value);
    if (length >= XW_DOM_STRING_POOL_SIZE) return 0;
    if (length == 0U) {
        document->nodes[node_index].first_child = XW_DOM_NONE;
        document->nodes[node_index].last_child = XW_DOM_NONE;
        return 1;
    }
    child = document->nodes[node_index].first_child;
    if (child != XW_DOM_NONE && document->nodes[child].type == XW_NODE_TEXT) {
        offset = pool_put_n(document, value, length);
        if (document->truncated) return 0;
        document->nodes[child].value_offset = offset;
        document->nodes[child].next_sibling = XW_DOM_NONE;
        document->nodes[node_index].first_child = child;
        document->nodes[node_index].last_child = child;
        return 1;
    }
    /* Detach old descendants. Their bounded slots remain allocated but unreachable. */
    document->nodes[node_index].first_child = XW_DOM_NONE;
    document->nodes[node_index].last_child = XW_DOM_NONE;
    if (document->node_count >= XW_DOM_MAX_NODES) {
        document->truncated = 1;
        return 0;
    }
    offset = pool_put_n(document, value, length);
    if (document->truncated) return 0;
    element = &document->nodes[node_index];
    child = (uint16_t)document->node_count++;
    memset(&document->nodes[child], 0, sizeof(document->nodes[child]));
    document->nodes[child].parent = node_index;
    document->nodes[child].first_child = XW_DOM_NONE;
    document->nodes[child].last_child = XW_DOM_NONE;
    document->nodes[child].next_sibling = XW_DOM_NONE;
    document->nodes[child].first_attribute = XW_DOM_NONE;
    document->nodes[child].name_offset = pool_put_n(document, "#text", 5U);
    document->nodes[child].value_offset = offset;
    document->nodes[child].type = XW_NODE_TEXT;
    element->first_child = child;
    element->last_child = child;
    return !document->truncated;
}

size_t xw_dom_text_content(const XwDocument *document, uint16_t node_index,
                           char *output, size_t output_capacity)
{
    size_t written = 0U;
    uint16_t cursor;
    if (output == NULL || output_capacity == 0U) return 0U;
    output[0] = '\0';
    if (document == NULL || node_index >= document->node_count) return 0U;
    cursor = node_index;
    for (;;) {
        const XwDomNode *node = &document->nodes[cursor];
        if (cursor != node_index && node->type == XW_NODE_TEXT) {
            const char *text = xw_dom_string(document, node->value_offset);
            size_t n = strlen(text);
            size_t room = output_capacity - written - 1U;
            if (n > room) n = room;
            if (n > 0U) memcpy(output + written, text, n);
            written += n;
            output[written] = '\0';
            if (written + 1U >= output_capacity) break;
        }
        if (node->first_child != XW_DOM_NONE) {
            cursor = node->first_child;
            continue;
        }
        while (cursor != node_index && document->nodes[cursor].next_sibling == XW_DOM_NONE)
            cursor = document->nodes[cursor].parent;
        if (cursor == node_index) break;
        cursor = document->nodes[cursor].next_sibling;
    }
    return written;
}

uint16_t xw_dom_find_by_id(const XwDocument *document, const char *id)
{
    size_t i;
    if (document == NULL || id == NULL) return XW_DOM_NONE;
    for (i = 0U; i < document->node_count; ++i) {
        const char *node_id = xw_dom_attribute(document, (uint16_t)i, "id");
        if (node_id != NULL && strcmp(node_id, id) == 0) return (uint16_t)i;
    }
    return XW_DOM_NONE;
}

int xw_dom_has_class(const XwDocument *document, uint16_t node_index, const char *class_name)
{
    const char *classes;
    size_t wanted_length;
    const char *p;
    if (class_name == NULL || class_name[0] == '\0') return 0;
    classes = xw_dom_attribute(document, node_index, "class");
    if (classes == NULL) return 0;
    wanted_length = strlen(class_name);
    p = classes;
    while (*p != '\0') {
        const char *start;
        while (is_space_char(*p)) ++p;
        start = p;
        while (*p != '\0' && !is_space_char(*p)) ++p;
        if ((size_t)(p - start) == wanted_length && strncmp(start, class_name, wanted_length) == 0) return 1;
    }
    return 0;
}

static void close_element(uint16_t *stack, size_t *depth, const XwDocument *document,
                          const char *tag, size_t tag_length)
{
    size_t i = *depth;
    while (i > 1U) {
        const uint16_t candidate = stack[--i];
        const char *name = xw_dom_string(document, document->nodes[candidate].name_offset);
        if (strlen(name) == tag_length && strncasecmp(name, tag, tag_length) == 0) {
            *depth = i;
            return;
        }
    }
}

static const char *find_closing_tag(const char *text, size_t length, const char *tag)
{
    size_t tag_length = strlen(tag);
    size_t i;
    for (i = 0U; i + tag_length + 3U <= length; ++i) {
        if (text[i] == '<' && text[i + 1U] == '/' &&
            strncasecmp(text + i + 2U, tag, tag_length) == 0 &&
            (is_space_char(text[i + 2U + tag_length]) || text[i + 2U + tag_length] == '>'))
            return text + i;
    }
    return NULL;
}

int xw_dom_parse(XwDocument *document, const char *html, size_t html_length)
{
    uint16_t stack[XW_DOM_MAX_DEPTH];
    size_t depth = 1U;
    size_t position = 0U;
    if (document == NULL || html == NULL) return 0;
    memset(document, 0, sizeof(*document));
    document->root = 0U;
    document->strings_used = 1U;
    document->strings[0] = '\0';
    document->nodes[0].parent = XW_DOM_NONE;
    document->nodes[0].first_child = XW_DOM_NONE;
    document->nodes[0].last_child = XW_DOM_NONE;
    document->nodes[0].next_sibling = XW_DOM_NONE;
    document->nodes[0].first_attribute = XW_DOM_NONE;
    document->nodes[0].name_offset = 0U;
    document->nodes[0].value_offset = 0U;
    document->nodes[0].type = XW_NODE_DOCUMENT;
    document->node_count = 1U;
    stack[0] = 0U;

    while (position < html_length && !document->truncated) {
        size_t cursor;
        size_t tag_start;
        if (html[position] != '<') {
            size_t end = position;
            while (end < html_length && html[end] != '<') ++end;
            if (end > position && add_node(document, XW_NODE_TEXT, stack[depth - 1U],
                                           "#text", 5U, html + position, end - position) == XW_DOM_NONE) break;
            position = end;
            continue;
        }
        if (position + 4U <= html_length && memcmp(html + position, "<!--", 4U) == 0) {
            size_t end = position + 4U;
            while (end + 3U <= html_length && memcmp(html + end, "-->", 3U) != 0) ++end;
            position = end + 3U <= html_length ? end + 3U : html_length;
            continue;
        }
        if (position + 2U < html_length && (html[position + 1U] == '!' || html[position + 1U] == '?')) {
            const char *gt = memchr(html + position, '>', html_length - position);
            position = gt != NULL ? (size_t)(gt - html) + 1U : html_length;
            continue;
        }
        cursor = position + 1U;
        while (cursor < html_length && is_space_char(html[cursor])) ++cursor;
        if (cursor < html_length && html[cursor] == '/') {
            const char *gt;
            ++cursor;
            while (cursor < html_length && is_space_char(html[cursor])) ++cursor;
            tag_start = cursor;
            while (cursor < html_length && is_name_char(html[cursor])) ++cursor;
            if (cursor == tag_start) { ++position; continue; }
            gt = memchr(html + cursor, '>', html_length - cursor);
            close_element(stack, &depth, document, html + tag_start, cursor - tag_start);
            position = gt != NULL ? (size_t)(gt - html) + 1U : html_length;
            continue;
        }
        tag_start = cursor;
        while (cursor < html_length && is_name_char(html[cursor])) ++cursor;
        if (cursor == tag_start) { ++position; continue; }
        {
            char tag[32];
            size_t tag_length = cursor - tag_start;
            size_t tag_copy = tag_length < sizeof(tag) - 1U ? tag_length : sizeof(tag) - 1U;
            uint16_t node;
            int self_closing = 0;
            memcpy(tag, html + tag_start, tag_copy);
            tag[tag_copy] = '\0';
            if (tag_length >= sizeof(tag)) document->truncated = 1;
            node = add_node(document, XW_NODE_ELEMENT, stack[depth - 1U], tag, tag_copy, "", 0U);
            if (node == XW_DOM_NONE) break;

            while (cursor < html_length) {
                size_t name_start, name_end, value_start, value_end;
                while (cursor < html_length && is_space_char(html[cursor])) ++cursor;
                if (cursor >= html_length) break;
                if (html[cursor] == '>') { ++cursor; break; }
                if (html[cursor] == '/' && cursor + 1U < html_length && html[cursor + 1U] == '>') {
                    self_closing = 1;
                    cursor += 2U;
                    break;
                }
                name_start = cursor;
                while (cursor < html_length && !is_space_char(html[cursor]) &&
                       html[cursor] != '=' && html[cursor] != '>' && html[cursor] != '/') ++cursor;
                name_end = cursor;
                if (name_end == name_start) { ++cursor; continue; }
                while (cursor < html_length && is_space_char(html[cursor])) ++cursor;
                value_start = value_end = cursor;
                if (cursor < html_length && html[cursor] == '=') {
                    ++cursor;
                    while (cursor < html_length && is_space_char(html[cursor])) ++cursor;
                    if (cursor < html_length && (html[cursor] == '\'' || html[cursor] == '"')) {
                        char quote = html[cursor++];
                        value_start = cursor;
                        while (cursor < html_length && html[cursor] != quote) ++cursor;
                        value_end = cursor;
                        if (cursor < html_length) ++cursor;
                        else document->truncated = 1;
                    } else {
                        value_start = cursor;
                        while (cursor < html_length && !is_space_char(html[cursor]) && html[cursor] != '>') ++cursor;
                        value_end = cursor;
                    }
                }
                add_attribute(document, node, html + name_start, name_end - name_start,
                              html + value_start, value_end - value_start);
            }
            position = cursor;
            if (is_void_tag(tag) || self_closing) continue;
            if (depth >= XW_DOM_MAX_DEPTH) {
                document->truncated = 1;
                break;
            }
            stack[depth++] = node;

            /* Script and style are raw-text elements: angle brackets within them
             * must never be mistaken for markup. */
            if (strcasecmp(tag, "script") == 0 || strcasecmp(tag, "style") == 0) {
                const char *close = find_closing_tag(html + position, html_length - position, tag);
                if (close != NULL) {
                    size_t raw_len = (size_t)(close - (html + position));
                    if (raw_len > 0U && add_node(document, XW_NODE_TEXT, node, "#text", 5U,
                                                 html + position, raw_len) == XW_DOM_NONE) break;
                    position = (size_t)(close - html) + 2U + strlen(tag);
                    while (position < html_length && html[position] != '>') ++position;
                    if (position < html_length) ++position;
                    --depth;
                } else {
                    if (position < html_length && add_node(document, XW_NODE_TEXT, node, "#text", 5U,
                                                            html + position, html_length - position) == XW_DOM_NONE) break;
                    position = html_length;
                }
            }
        }
    }
    return document->node_count > 1U && !document->truncated;
}

void xw_dom_get_stats(const XwDocument *document, size_t input_bytes, XwDomStats *stats)
{
    if (document == NULL || stats == NULL) return;
    stats->input_bytes = input_bytes;
    stats->node_count = document->node_count;
    stats->attribute_count = document->attribute_count;
    stats->string_bytes = document->strings_used;
    stats->truncated = document->truncated;
}
