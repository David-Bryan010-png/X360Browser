# NetSurf backend status — 2.2.0-xenonscript-external-dev

`platform/xbox360/xsdk/netsurf_backend_stub.c` remains a capability stub. No real NetSurf/libcss/libdom frontend is linked. X360Browser's primary page rendering is the in-project XenonWeb engine, and inline scripting is handled by XenonScript, a bounded experimental subset. The app uses third-party libraries for specific supporting jobs such as transport, TLS and raster decoding; these are not used as a substitute page engine.
