# NetSurf backend status (0.8.0)

O backend NetSurf ainda é um stub em `platform/xbox360/xsdk/netsurf_backend_stub.c`; não está dentro do XEX. O dispatcher conserva o contrato e usa NativePlus/VisualLite enquanto `netsurf_backend_init()` não reportar uma integração real. O caminho de build `X360BROWSER_WITH_NETSURF=ON` exige código e dependências reais e deve falhar caso estejam ausentes.
