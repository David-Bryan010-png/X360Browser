# NativePlus + VisualLite (0.8.0)

NativePlus baixa HTML e inventaria recursos; VisualLite organiza o HTML retido em blocos e desenha um subset CSS. PNG é o primeiro formato de imagem decodificado; demais formatos permanecem placeholders. A camada não executa scripts.
