# UI do X360Browser 0.8.0

A UI xSDK exibe a barra do navegador, o viewport VisualLite, o leitor textual e as listas de links/recursos/favoritos. A superfície da página é desenhada pelo `visual_renderer.c`; não é uma janela WebView e não executa JavaScript.
