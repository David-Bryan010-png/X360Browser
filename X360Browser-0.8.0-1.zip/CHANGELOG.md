# Changelog

## 0.8.0 — VisualLite + PNG estático
- Adicionado renderizador VisualLite de página em superfície gráfica 1152×384 alinhada aos tiles do xenos.
- Adicionado layout HTML de fluxo estático e suporte a subset limitado de CSS em regras `tag`, `.class`, `#id` e estilos inline.
- Adicionado download PNG limitado e verificado, cache de arquivos PNG e decodificação RGBA via LodePNG (revisionado no script de build), com limites de RAM/dimensões.
- Mantidos leitor, links, favoritos, histórico, inventário de recursos e handoff opcional de vídeo direto.
- Adicionados testes para layout, cores, caixas, imagem cacheada, download e validação da assinatura PNG.
- Não inclui execução JavaScript, integração NetSurf real ou suporte a jogos web modernos.

## 0.7.0 — Console Compatibility and Direct Media
- Expandiu o inventário NativePlus de recursos HTML: `srcset`, URLs CSS, metadados, referências de stylesheet/script, formulário/embed e mídia direta.
- Adicionou busca na barra de endereço, histórico voltar/avançar e favoritos persistentes.
- Adicionou seleção de origem de vídeo direto, download limitado (512 MiB), rejeição de HTML/manifest e handoff opcional para player externo.
- NetSurf permaneceu um stub documentado.

## 0.5.0 — NativePlus Web Resource Inventory
- Adicionou inventário de recursos para imagens, URLs CSS, scripts, folhas de estilo, formulários, iframes e mídia.
- Adicionou dispatcher de backend com fallback NativePlus quando NetSurf real não está disponível.

## 0.4.0 — Web Engine Alpha
- Adicionou transporte HTTP/HTTPS, validação de certificado TLS e extração textual de links.
