# Xbox 360 target — X360Browser 0.8.0

The xSDK target provides the 720p shell, NativePlus HTTP/HTTPS backend, static VisualLite HTML/CSS layout, bounded PNG decoding via the pinned LodePNG source and optional direct-video download/handoff. NetSurf is still a stub. See `../..//docs/COMPATIBILITY-0.8.0.md` for exact support boundaries.
