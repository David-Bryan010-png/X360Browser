#include "visual_renderer.h"
#include "visual_layout.h"
#include "X360Browser_shaders.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifdef X360BROWSER_WITH_LODEPNG
#include "lodepng.h"
#endif

#include "xsdk/gpu.h"
#include "xsdk/kernel.h"
#include "xsdk/log.h"
#include "xsdk/shader.h"
#include "xsdk/texture.h"
#include "xsdk/text.h"

/* The 1152x384 page surface is aligned to Xenos' 32px texture tiles. */
enum {
    PAGE_SCREEN_X = 64,
    PAGE_SCREEN_Y = 192,
    PAGE_WIDTH = WEB_VISUAL_WIDTH,
    PAGE_HEIGHT = WEB_VISUAL_HEIGHT,
    PAGE_VERTEX_COUNT = 4,
    PAGE_VERTEX_STRIDE = 16,
    DRAW_WAIT_MS = 1000
};

#define WEB_VISUAL_DECODED_PNG_CACHE 4U
#define WEB_VISUAL_PNG_MAX_DIMENSION 1024U
#define WEB_VISUAL_PNG_MAX_PIXELS 1048576U

typedef struct {
    char path[WEB_ENGINE_IMAGE_CACHE_PATH_CAP];
    unsigned char *rgba;
    unsigned width;
    unsigned height;
} DecodedPng;

typedef struct {
    XsdkShader vertex;
    XsdkShader pixel;
    XsdkTexture texture;
    XsdkSamplerState sampler_state;
    volatile uint32_t *vertices;
    uint32_t width;
    uint32_t height;
    int ready;
    uint32_t *surface;
    uint64_t uploaded_hash;
    uint32_t screen_width;
    uint32_t screen_height;
    DecodedPng png_cache[WEB_VISUAL_DECODED_PNG_CACHE];
    size_t png_cache_count;
    size_t png_cache_next;
} VisualGpuState;

static VisualGpuState g_visual;

static uint64_t page_hash(const WebEnginePage *page, size_t scroll_pixels)
{
    uint64_t hash = UINT64_C(1469598103934665603);
    size_t i;
    if (page != NULL) {
        for (i = 0U; i < page->source_html_length; ++i) {
            hash ^= (unsigned char)page->source_html[i];
            hash *= UINT64_C(1099511628211);
        }
        for (i = 0U; i < page->image_count; ++i) {
            const char *path = page->images[i].cache_path;
            while (*path != '\0') {
                hash ^= (unsigned char)*path++;
                hash *= UINT64_C(1099511628211);
            }
        }
    }
    hash ^= (uint64_t)scroll_pixels;
    hash *= UINT64_C(1099511628211);
    return hash;
}

static void draw_surface_rect(uint32_t *pixels, const WebVisualRect *rect)
{
    int x0 = rect->x;
    int y0 = rect->y;
    int x1 = rect->x + rect->width;
    int y1 = rect->y + rect->height;
    int x, y;
    if (x0 < 0) x0 = 0;
    if (y0 < 0) y0 = 0;
    if (x1 > PAGE_WIDTH) x1 = PAGE_WIDTH;
    if (y1 > PAGE_HEIGHT) y1 = PAGE_HEIGHT;
    if (x0 >= x1 || y0 >= y1) return;
    if ((rect->color >> 24U) != 0U) {
        for (y = y0; y < y1; ++y) {
            uint32_t *row = pixels + (size_t)y * PAGE_WIDTH;
            for (x = x0; x < x1; ++x) row[x] = rect->color;
        }
    }
    if (rect->border_width > 0) {
        int bw = rect->border_width;
        if (bw > 4) bw = 4;
        for (y = y0; y < y1; ++y) {
            uint32_t *row = pixels + (size_t)y * PAGE_WIDTH;
            for (x = x0; x < x1; ++x) {
                if ((x - x0) < bw || (x1 - 1 - x) < bw || (y - y0) < bw || (y1 - 1 - y) < bw)
                    row[x] = rect->border_color;
            }
        }
    }
}

#ifdef X360BROWSER_WITH_LODEPNG
static unsigned png_be32(const unsigned char *p)
{
    return ((unsigned)p[0] << 24U) | ((unsigned)p[1] << 16U) | ((unsigned)p[2] << 8U) | (unsigned)p[3];
}

static const DecodedPng *decoded_png_for_path(const char *path)
{
    size_t i;
    FILE *file;
    unsigned char header[24];
    unsigned width;
    unsigned height;
    unsigned char *rgba = NULL;
    unsigned decoded_width = 0U;
    unsigned decoded_height = 0U;
    unsigned error;
    DecodedPng *slot;
    if (path == NULL || path[0] == '\0') return NULL;
    for (i = 0U; i < g_visual.png_cache_count; ++i)
        if (strcmp(g_visual.png_cache[i].path, path) == 0) return &g_visual.png_cache[i];
    file = fopen(path, "rb");
    if (file == NULL) return NULL;
    if (fread(header, 1U, sizeof(header), file) != sizeof(header)) {
        (void)fclose(file);
        return NULL;
    }
    (void)fclose(file);
    if (header[0] != 137U || header[1] != 80U || header[2] != 78U || header[3] != 71U ||
        header[4] != 13U || header[5] != 10U || header[6] != 26U || header[7] != 10U ||
        png_be32(header + 8U) != 13U || memcmp(header + 12U, "IHDR", 4U) != 0) return NULL;
    width = png_be32(header + 16U);
    height = png_be32(header + 20U);
    if (width == 0U || height == 0U || width > WEB_VISUAL_PNG_MAX_DIMENSION ||
        height > WEB_VISUAL_PNG_MAX_DIMENSION ||
        (uint64_t)width * (uint64_t)height > (uint64_t)WEB_VISUAL_PNG_MAX_PIXELS) return NULL;
    error = lodepng_decode32_file(&rgba, &decoded_width, &decoded_height, path);
    if (error != 0U || rgba == NULL || decoded_width != width || decoded_height != height) {
        free(rgba);
        return NULL;
    }
    if (g_visual.png_cache_count < WEB_VISUAL_DECODED_PNG_CACHE) {
        slot = &g_visual.png_cache[g_visual.png_cache_count++];
    } else {
        slot = &g_visual.png_cache[g_visual.png_cache_next];
        free(slot->rgba);
        g_visual.png_cache_next = (g_visual.png_cache_next + 1U) % WEB_VISUAL_DECODED_PNG_CACHE;
    }
    memset(slot, 0, sizeof(*slot));
    (void)snprintf(slot->path, sizeof(slot->path), "%s", path);
    slot->rgba = rgba;
    slot->width = width;
    slot->height = height;
    return slot;
}

static void blit_png_contain(uint32_t *pixels, const WebVisualImage *image, const DecodedPng *png)
{
    int target_width;
    int target_height;
    int target_x;
    int target_y;
    int x;
    int y;
    if (pixels == NULL || image == NULL || png == NULL || png->rgba == NULL ||
        image->width <= 0 || image->height <= 0) return;
    if ((uint64_t)png->width * (uint64_t)image->height > (uint64_t)png->height * (uint64_t)image->width) {
        target_width = image->width;
        target_height = (int)((uint64_t)png->height * (uint64_t)target_width / (uint64_t)png->width);
    } else {
        target_height = image->height;
        target_width = (int)((uint64_t)png->width * (uint64_t)target_height / (uint64_t)png->height);
    }
    if (target_width < 1) target_width = 1;
    if (target_height < 1) target_height = 1;
    target_x = image->x + (image->width - target_width) / 2;
    target_y = image->y + (image->height - target_height) / 2;
    for (y = 0; y < target_height; ++y) {
        int dy = target_y + y;
        unsigned sy;
        if (dy < 0 || dy >= PAGE_HEIGHT) continue;
        sy = (unsigned)((uint64_t)(unsigned)y * (uint64_t)png->height / (uint64_t)(unsigned)target_height);
        for (x = 0; x < target_width; ++x) {
            int dx = target_x + x;
            unsigned sx;
            const unsigned char *src;
            unsigned alpha;
            uint32_t *dst;
            unsigned sr, sg, sb, dr, dg, db;
            if (dx < 0 || dx >= PAGE_WIDTH) continue;
            sx = (unsigned)((uint64_t)(unsigned)x * (uint64_t)png->width / (uint64_t)(unsigned)target_width);
            src = png->rgba + (((size_t)sy * png->width + sx) * 4U);
            alpha = src[3];
            if (alpha == 0U) continue;
            dst = &pixels[(size_t)dy * PAGE_WIDTH + (size_t)dx];
            if (alpha == 255U) {
                *dst = 0xFF000000U | ((uint32_t)src[0] << 16U) | ((uint32_t)src[1] << 8U) | (uint32_t)src[2];
                continue;
            }
            sr = src[0]; sg = src[1]; sb = src[2];
            dr = (*dst >> 16U) & 0xFFU; dg = (*dst >> 8U) & 0xFFU; db = *dst & 0xFFU;
            sr = (sr * alpha + dr * (255U - alpha)) / 255U;
            sg = (sg * alpha + dg * (255U - alpha)) / 255U;
            sb = (sb * alpha + db * (255U - alpha)) / 255U;
            *dst = 0xFF000000U | ((uint32_t)sr << 16U) | ((uint32_t)sg << 8U) | (uint32_t)sb;
        }
    }
}

static int is_decoded_image_placeholder(const WebVisualFrame *frame, size_t text_index)
{
    size_t i;
    for (i = 0U; i < frame->image_count; ++i) {
        const WebVisualImage *image = &frame->images[i];
        if (image->placeholder_text_index == text_index && decoded_png_for_path(image->cache_path) != NULL) return 1;
    }
    return 0;
}
#else
static const void *decoded_png_for_path(const char *path)
{
    (void)path;
    return NULL;
}
static int is_decoded_image_placeholder(const WebVisualFrame *frame, size_t text_index)
{
    (void)frame;
    (void)text_index;
    return 0;
}
#endif

static void compose_surface(const WebVisualFrame *frame, uint32_t *pixels)
{
    size_t i;
    const size_t total = (size_t)PAGE_WIDTH * PAGE_HEIGHT;
    for (i = 0U; i < total; ++i) pixels[i] = frame->background;
    for (i = 0U; i < frame->rect_count; ++i) draw_surface_rect(pixels, &frame->rects[i]);
#ifdef X360BROWSER_WITH_LODEPNG
    for (i = 0U; i < frame->image_count; ++i) {
        const WebVisualImage *image = &frame->images[i];
        const DecodedPng *png = decoded_png_for_path(image->cache_path);
        if (png != NULL) blit_png_contain(pixels, image, png);
    }
#endif
}

static void set_quad_vertices(uint32_t screen_width, uint32_t screen_height)
{
    float x0 = -1.0f + 2.0f * (float)PAGE_SCREEN_X / (float)screen_width;
    float x1 = -1.0f + 2.0f * (float)(PAGE_SCREEN_X + PAGE_WIDTH) / (float)screen_width;
    float y0 = 1.0f - 2.0f * (float)PAGE_SCREEN_Y / (float)screen_height;
    float y1 = 1.0f - 2.0f * (float)(PAGE_SCREEN_Y + PAGE_HEIGHT) / (float)screen_height;
    const float data[PAGE_VERTEX_COUNT][4] = {
        {x0, y0, 0.0f, 0.0f}, {x1, y0, 1.0f, 0.0f},
        {x0, y1, 0.0f, 1.0f}, {x1, y1, 1.0f, 1.0f}
    };
    uint32_t words[PAGE_VERTEX_COUNT * (PAGE_VERTEX_STRIDE / 4)];
    size_t i;
    memcpy(words, data, sizeof(data));
    for (i = 0U; i < sizeof(words) / sizeof(words[0]); ++i) g_visual.vertices[i] = words[i];
    xsdk_gpu_invalidate(xsdk_gpu_address(g_visual.vertices), sizeof(words));
}

int web_visual_renderer_init(void)
{
    static const XsdkVertexElement layout[] = {
        {.usage = XSDK_USAGE_POSITION, .usage_index = 0U, .format = XSDK_VERTEX_FLOAT2,
         .stream = 0U, .offset_bytes = 0U, .components = {0U, 0U, 0U, 0U}, .per_instance = false},
        {.usage = XSDK_USAGE_TEXCOORD, .usage_index = 0U, .format = XSDK_VERTEX_FLOAT2,
         .stream = 0U, .offset_bytes = 8U, .components = {0U, 0U, 0U, 0U}, .per_instance = false}
    };
    static const uint32_t strides[] = {PAGE_VERTEX_STRIDE};
    static const XsdkSampler sampler = {
        .mag_filter = XSDK_FILTER_LINEAR, .min_filter = XSDK_FILTER_LINEAR, .mip_filter = XSDK_FILTER_POINT,
        .address_u = XSDK_ADDRESS_CLAMP, .address_v = XSDK_ADDRESS_CLAMP, .lod_bias = 0.0f,
        .max_anisotropy = 1U, .min_level = 0U, .level_count = 1U,
        .address_w = XSDK_ADDRESS_CLAMP, .border = XSDK_BORDER_BLACK
    };
    NTSTATUS status;
    memset(&g_visual, 0, sizeof(g_visual));
    g_visual.surface = (uint32_t *)malloc((size_t)PAGE_WIDTH * PAGE_HEIGHT * sizeof(uint32_t));
    if (g_visual.surface == NULL) {
        xsdk_log_write("X360Browser visual: not enough RAM for page surface");
        return 0;
    }
    status = xsdk_shader_load(&g_visual.vertex, page_vert.container, page_vert.container_bytes);
    if (NT_SUCCESS(status)) status = xsdk_shader_load(&g_visual.pixel, page_frag.container, page_frag.container_bytes);
    if (NT_SUCCESS(status)) status = xsdk_shader_set_vertex_layout(&g_visual.vertex, layout,
        (uint32_t)(sizeof(layout) / sizeof(layout[0])), strides);
    if (NT_SUCCESS(status)) status = xsdk_texture_create(&g_visual.texture, XSDK_FORMAT_A8R8G8B8,
        PAGE_WIDTH, PAGE_HEIGHT, 1U, true);
    if (!NT_SUCCESS(status)) {
        xsdk_log_write("X360Browser visual: shader/texture init failed 0x%08X", (unsigned)status);
        web_visual_renderer_shutdown();
        return 0;
    }
    g_visual.vertices = xsdk_gpu_alloc(PAGE_VERTEX_COUNT * PAGE_VERTEX_STRIDE);
    if (g_visual.vertices == NULL) {
        xsdk_log_write("X360Browser visual: GPU vertex allocation failed");
        web_visual_renderer_shutdown();
        return 0;
    }
    xsdk_texture_sampler_state(&g_visual.sampler_state, &sampler);
    g_visual.ready = 1;
    g_visual.uploaded_hash = 0U;
    xsdk_log_write("X360Browser visual: static HTML/CSS renderer initialized");
    return 1;
}

size_t web_visual_renderer_draw(const WebEnginePage *page, size_t scroll_pixels,
                                uint32_t screen_width, uint32_t screen_height)
{
    WebVisualFrame frame;
    uint64_t hash;
    NTSTATUS status;
    size_t i;
    if (!g_visual.ready || page == NULL || screen_width == 0U || screen_height == 0U) return 0U;
    web_visual_layout(page, scroll_pixels, &frame);
    hash = page_hash(page, scroll_pixels);
    if (hash != g_visual.uploaded_hash) {
        status = xsdk_gpu_wait(xsdk_gpu_fence(), DRAW_WAIT_MS);
        if (!NT_SUCCESS(status)) {
            xsdk_log_write("X360Browser visual: GPU fence wait failed 0x%08X", (unsigned)status);
            return frame.content_height;
        }
        compose_surface(&frame, g_visual.surface);
        xsdk_texture_upload(&g_visual.texture, 0U, g_visual.surface, PAGE_WIDTH * (uint32_t)sizeof(uint32_t));
        g_visual.uploaded_hash = hash;
    }
    if (g_visual.screen_width != screen_width || g_visual.screen_height != screen_height) {
        status = xsdk_gpu_wait(xsdk_gpu_fence(), DRAW_WAIT_MS);
        if (!NT_SUCCESS(status)) {
            xsdk_log_write("X360Browser visual: vertex fence wait failed 0x%08X", (unsigned)status);
            return frame.content_height;
        }
        set_quad_vertices(screen_width, screen_height);
        g_visual.screen_width = screen_width;
        g_visual.screen_height = screen_height;
    }
    xsdk_gpu_set_shaders(&g_visual.vertex, &g_visual.pixel);
    xsdk_gpu_set_texture(PAGE_FRAG_SAMPLER_0_0, &g_visual.texture, &g_visual.sampler_state);
    xsdk_gpu_set_vertices(0U, xsdk_gpu_address(g_visual.vertices), PAGE_VERTEX_COUNT * PAGE_VERTEX_STRIDE);
    xsdk_gpu_draw(XSDK_PRIMITIVE_TRIANGLE_STRIP, PAGE_VERTEX_COUNT);
    for (i = 0U; i < frame.text_count; ++i) {
        const WebVisualText *t = &frame.texts[i];
        if (is_decoded_image_placeholder(&frame, i)) continue;
        if (t->y < 0 || t->y >= PAGE_HEIGHT - 12) continue;
        xsdk_text_draw(PAGE_SCREEN_X + t->x, PAGE_SCREEN_Y + t->y, t->scale, t->color, t->text);
    }
    if (frame.truncated)
        xsdk_text_draw(PAGE_SCREEN_X + 16, PAGE_SCREEN_Y + PAGE_HEIGHT - 22, 1U, 0xFFB25A00U,
                       "Visual layout limit reached; use Reader/Links view for remaining content.");
    return frame.content_height;
}

void web_visual_renderer_shutdown(void)
{
#ifdef X360BROWSER_WITH_LODEPNG
    size_t i;
    for (i = 0U; i < g_visual.png_cache_count; ++i) {
        free(g_visual.png_cache[i].rgba);
        g_visual.png_cache[i].rgba = NULL;
    }
#endif
    if (g_visual.vertices != NULL) {
        xsdk_gpu_free(g_visual.vertices);
        g_visual.vertices = NULL;
    }
    if (g_visual.texture.texels != NULL) xsdk_texture_free(&g_visual.texture);
    xsdk_shader_free(&g_visual.pixel);
    xsdk_shader_free(&g_visual.vertex);
    free(g_visual.surface);
    memset(&g_visual, 0, sizeof(g_visual));
}
