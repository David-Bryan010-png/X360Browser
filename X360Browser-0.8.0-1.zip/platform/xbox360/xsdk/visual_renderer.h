#ifndef X360BROWSER_VISUAL_RENDERER_H
#define X360BROWSER_VISUAL_RENDERER_H

#include <stddef.h>
#include <stdint.h>
#include "web_engine.h"

int web_visual_renderer_init(void);
size_t web_visual_renderer_draw(const WebEnginePage *page, size_t scroll_pixels, uint32_t screen_width, uint32_t screen_height);
void web_visual_renderer_shutdown(void);

#endif
