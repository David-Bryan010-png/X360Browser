#include "visual_layout.h"

#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>

#define CSS_RULES_MAX 32
#define HTML_STACK_MAX 24
#define STYLE_TEXT_CAP 4096
#define LAYOUT_LINE_CAP WEB_VISUAL_TEXT_CAP
#define COLOR_INHERIT 0xFFFFFFFFU
#define COLOR_TRANSPARENT 0x00000000U

typedef struct {
    char selector[48];
    char declarations[256];
} CssRule;

typedef struct {
    uint32_t color;
    uint32_t background;
    uint32_t border_color;
    int font_size;
    int weight_bold;
    int align_center;
    int hidden;
    int margin_top;
    int margin_bottom;
    int padding;
    int border_width;
} VisualStyle;

typedef struct {
    char name[16];
    VisualStyle style;
    int block;
    int start_y;
} StackEntry;

typedef struct {
    WebVisualFrame *frame;
    int y;
    int x;
    int max_x;
    int line_height;
    char line[LAYOUT_LINE_CAP];
    size_t line_length;
    VisualStyle style;
    CssRule rules[CSS_RULES_MAX];
    size_t rule_count;
    StackEntry stack[HTML_STACK_MAX];
    size_t stack_count;
    int truncation;
} Layout;

static const char *find_case_insensitive(const char *text, const char *needle)
{
    size_t n;
    const char *p;
    if (text == NULL || needle == NULL || needle[0] == '\0') return NULL;
    n = strlen(needle);
    for (p = text; *p != '\0'; ++p) {
        if (strncasecmp(p, needle, n) == 0) return p;
    }
    return NULL;
}

static uint32_t color_parse(const char *value, uint32_t fallback)
{
    char token[48];
    size_t n = 0U;
    unsigned long parsed;
    if (value == NULL) return fallback;
    while (isspace((unsigned char)*value)) ++value;
    while (*value != '\0' && *value != ';' && *value != '!' && !isspace((unsigned char)*value) && n + 1U < sizeof(token))
        token[n++] = *value++;
    token[n] = '\0';
    if (token[0] == '#') {
        if (n == 4U) {
            unsigned int r = (unsigned int)(strtoul((char[]){ token[1], '\0' }, NULL, 16) & 15U) * 17U;
            unsigned int g = (unsigned int)(strtoul((char[]){ token[2], '\0' }, NULL, 16) & 15U) * 17U;
            unsigned int b = (unsigned int)(strtoul((char[]){ token[3], '\0' }, NULL, 16) & 15U) * 17U;
            return 0xFF000000U | (r << 16U) | (g << 8U) | b;
        }
        if (n == 7U && sscanf(token + 1, "%lx", &parsed) == 1)
            return 0xFF000000U | ((uint32_t)parsed & 0x00FFFFFFU);
    }
    if (strcasecmp(token, "black") == 0) return 0xFF000000U;
    if (strcasecmp(token, "white") == 0) return 0xFFFFFFFFU;
    if (strcasecmp(token, "red") == 0) return 0xFFE53935U;
    if (strcasecmp(token, "green") == 0) return 0xFF188038U;
    if (strcasecmp(token, "blue") == 0) return 0xFF1A73E8U;
    if (strcasecmp(token, "navy") == 0) return 0xFF102A43U;
    if (strcasecmp(token, "gray") == 0 || strcasecmp(token, "grey") == 0) return 0xFF777777U;
    if (strcasecmp(token, "silver") == 0) return 0xFFCCCCCCU;
    if (strcasecmp(token, "yellow") == 0) return 0xFFFFEB3BU;
    if (strcasecmp(token, "orange") == 0) return 0xFFEF6C00U;
    if (strcasecmp(token, "purple") == 0) return 0xFF7E57C2U;
    if (strcasecmp(token, "teal") == 0) return 0xFF008577U;
    if (strcasecmp(token, "pink") == 0) return 0xFFE91E63U;
    if (strcasecmp(token, "transparent") == 0) return COLOR_TRANSPARENT;
    return fallback;
}

static int parse_pixels(const char *value, int fallback)
{
    char *end = NULL;
    long result;
    if (value == NULL) return fallback;
    while (isspace((unsigned char)*value)) ++value;
    result = strtol(value, &end, 10);
    if (end == value) return fallback;
    if (result < 0) result = 0;
    if (result > 96) result = 96;
    return (int)result;
}

static void style_default(VisualStyle *s)
{
    s->color = 0xFF202124U;
    s->background = COLOR_TRANSPARENT;
    s->border_color = 0xFFDDDDDDU;
    s->font_size = 16;
    s->weight_bold = 0;
    s->align_center = 0;
    s->hidden = 0;
    s->margin_top = 0;
    s->margin_bottom = 0;
    s->padding = 0;
    s->border_width = 0;
}

static void apply_declarations(VisualStyle *style, const char *declarations)
{
    const char *p = declarations;
    while (p != NULL && *p != '\0') {
        char property[40];
        char value[96];
        size_t pn = 0U, vn = 0U;
        while (*p != '\0' && (isspace((unsigned char)*p) || *p == ';')) ++p;
        while (*p != '\0' && *p != ':' && *p != ';' && pn + 1U < sizeof(property))
            property[pn++] = (char)tolower((unsigned char)*p++);
        property[pn] = '\0';
        while (isspace((unsigned char)*p)) ++p;
        if (*p == ':') ++p;
        while (isspace((unsigned char)*p)) ++p;
        while (*p != '\0' && *p != ';' && vn + 1U < sizeof(value)) value[vn++] = *p++;
        value[vn] = '\0';
        if (pn == 0U && *p == '\0') break;
        if (strcmp(property, "color") == 0) style->color = color_parse(value, style->color);
        else if (strcmp(property, "background") == 0 || strcmp(property, "background-color") == 0)
            style->background = color_parse(value, style->background);
        else if (strcmp(property, "border-color") == 0) style->border_color = color_parse(value, style->border_color);
        else if (strcmp(property, "border") == 0) {
            if (strstr(value, "solid") != NULL || strstr(value, "dashed") != NULL || strstr(value, "dotted") != NULL)
                style->border_width = 1;
            style->border_color = color_parse(value, style->border_color);
        }
        else if (strcmp(property, "font-size") == 0) style->font_size = parse_pixels(value, style->font_size);
        else if (strcmp(property, "font-weight") == 0)
            style->weight_bold = (strstr(value, "bold") != NULL || parse_pixels(value, 400) >= 600) ? 1 : 0;
        else if (strcmp(property, "text-align") == 0) style->align_center = strncasecmp(value, "center", 6U) == 0;
        else if (strcmp(property, "display") == 0 && strncasecmp(value, "none", 4U) == 0) style->hidden = 1;
        else if (strcmp(property, "margin") == 0) {
            style->margin_top = parse_pixels(value, style->margin_top);
            style->margin_bottom = style->margin_top;
        }
        else if (strcmp(property, "margin-top") == 0) style->margin_top = parse_pixels(value, style->margin_top);
        else if (strcmp(property, "margin-bottom") == 0) style->margin_bottom = parse_pixels(value, style->margin_bottom);
        else if (strcmp(property, "padding") == 0) style->padding = parse_pixels(value, style->padding);
        else if (strcmp(property, "border-width") == 0) style->border_width = parse_pixels(value, style->border_width);
    }
}

static int copy_attr(const char *tag, size_t length, const char *wanted, char *out, size_t capacity)
{
    size_t i = 0U;
    size_t wanted_length = strlen(wanted);
    if (capacity == 0U) return 0;
    out[0] = '\0';
    while (i < length && !isspace((unsigned char)tag[i]) && tag[i] != '/') ++i;
    while (i < length) {
        size_t ns, nl, vs, vl;
        char quote = '\0';
        while (i < length && (isspace((unsigned char)tag[i]) || tag[i] == '/')) ++i;
        ns = i;
        while (i < length && !isspace((unsigned char)tag[i]) && tag[i] != '=' && tag[i] != '/') ++i;
        nl = i - ns;
        while (i < length && isspace((unsigned char)tag[i])) ++i;
        if (i >= length || tag[i] != '=') { if (i < length) ++i; continue; }
        ++i;
        while (i < length && isspace((unsigned char)tag[i])) ++i;
        if (i < length && (tag[i] == '\'' || tag[i] == '"')) { quote = tag[i++]; vs = i; while (i < length && tag[i] != quote) ++i; vl = i - vs; if (i < length) ++i; }
        else { vs = i; while (i < length && !isspace((unsigned char)tag[i]) && tag[i] != '>') ++i; vl = i - vs; }
        if (nl == wanted_length && strncasecmp(tag + ns, wanted, nl) == 0) {
            size_t n = vl < capacity - 1U ? vl : capacity - 1U;
            memcpy(out, tag + vs, n); out[n] = '\0'; return 1;
        }
    }
    return 0;
}

static int is_block(const char *name)
{
    static const char *const list[] = {"address","article","aside","blockquote","br","div","dl","dt","dd","fieldset","figcaption","figure","footer","form","h1","h2","h3","h4","h5","h6","header","hr","li","main","nav","ol","p","pre","section","table","tr","ul","video","audio","iframe","button"};
    size_t i;
    for (i = 0U; i < sizeof(list)/sizeof(list[0]); ++i) if (strcmp(name, list[i]) == 0) return 1;
    return 0;
}

static int is_void(const char *name)
{
    return strcmp(name,"img")==0 || strcmp(name,"br")==0 || strcmp(name,"hr")==0 || strcmp(name,"input")==0 || strcmp(name,"meta")==0 || strcmp(name,"link")==0 || strcmp(name,"source")==0 || strcmp(name,"area")==0 || strcmp(name,"wbr")==0;
}

static size_t skip_hidden_element(const char *html, size_t html_length, size_t after_open,
                                  const char *wanted_name)
{
    const char *end = html + html_length;
    const char *cursor = html + after_open;
    size_t depth = 1U;
    while (cursor < end) {
        const char *open = memchr(cursor, '<', (size_t)(end - cursor));
        const char *gt;
        const char *name_start;
        const char *name_end;
        size_t name_length;
        int closing = 0;
        if (open == NULL) break;
        if ((size_t)(end - open) >= 4U && memcmp(open, "<!--", 4U) == 0) {
            const char *comment_end = find_case_insensitive(open + 4U, "-->");
            if (comment_end == NULL || comment_end >= end) break;
            cursor = comment_end + 3U;
            continue;
        }
        gt = memchr(open, '>', (size_t)(end - open));
        if (gt == NULL) break;
        name_start = open + 1;
        while (name_start < gt && isspace((unsigned char)*name_start)) ++name_start;
        if (name_start < gt && *name_start == '/') { closing = 1; ++name_start; }
        while (name_start < gt && (*name_start == '!' || *name_start == '?')) ++name_start;
        name_end = name_start;
        while (name_end < gt && (isalnum((unsigned char)*name_end) || *name_end == '-')) ++name_end;
        name_length = (size_t)(name_end - name_start);
        if (name_length == strlen(wanted_name) && strncasecmp(name_start, wanted_name, name_length) == 0) {
            if (closing) {
                if (depth > 0U) --depth;
                if (depth == 0U) return (size_t)(gt - html) + 1U;
            } else if (!is_void(wanted_name)) {
                ++depth;
            }
        }
        cursor = gt + 1;
    }
    /* A hidden element without a closing tag must not leak its text into layout. */
    return html_length;
}

static void css_collect(Layout *layout, const char *html, size_t length)
{
    const char *p = html, *end = html + length;
    while (p < end && layout->rule_count < CSS_RULES_MAX) {
        const char *open = find_case_insensitive(p, "<style");
        const char *gt, *close;
        if (open == NULL || open >= end) break;
        gt = memchr(open, '>', (size_t)(end-open));
        if (gt == NULL) break;
        close = find_case_insensitive(gt+1, "</style");
        if (close == NULL || close > end) break;
        p = gt + 1;
        while (p < close && layout->rule_count < CSS_RULES_MAX) {
            const char *brace = memchr(p, '{', (size_t)(close-p));
            const char *endbrace;
            CssRule *r;
            size_t n;
            if (brace == NULL) break;
            endbrace = memchr(brace+1, '}', (size_t)(close-brace-1));
            if (endbrace == NULL) break;
            r = &layout->rules[layout->rule_count];
            n = (size_t)(brace-p);
            while (n > 0U && isspace((unsigned char)p[n-1U])) --n;
            while (n > 0U && isspace((unsigned char)*p)) { ++p; --n; }
            if (n > 0U && n < sizeof(r->selector) && (memchr(p, ',', n) == NULL)) {
                memcpy(r->selector, p, n); r->selector[n] = '\0';
                n = (size_t)(endbrace-brace-1);
                if (n >= sizeof(r->declarations)) n = sizeof(r->declarations)-1U;
                memcpy(r->declarations, brace+1, n); r->declarations[n] = '\0';
                ++layout->rule_count;
            }
            p = endbrace + 1;
        }
        p = close + 7;
    }
}

static void apply_tag_rules(Layout *layout, VisualStyle *style, const char *name, const char *tag, size_t tag_length)
{
    char id[48] = "", class_name[80] = "";
    size_t i;
    (void)copy_attr(tag, tag_length, "id", id, sizeof(id));
    (void)copy_attr(tag, tag_length, "class", class_name, sizeof(class_name));
    /* The limited cascade applies element, class and id rules in source order. */
    for (i=0U; i<layout->rule_count; ++i) {
        const char *sel = layout->rules[i].selector;
        int match = strcasecmp(sel, name) == 0;
        if (sel[0] == '.' && class_name[0] != '\0') {
            const char *c = class_name;
            while (*c != '\0') {
                while (isspace((unsigned char)*c)) ++c;
                const char *start = c;
                while (*c != '\0' && !isspace((unsigned char)*c)) ++c;
                if ((size_t)(c-start) == strlen(sel+1) && strncasecmp(start, sel+1, (size_t)(c-start)) == 0) match = 1;
            }
        } else if (sel[0] == '#' && id[0] != '\0') match = strcasecmp(id, sel+1) == 0;
        if (match) apply_declarations(style, layout->rules[i].declarations);
    }
}

static void add_rect(Layout *l, int x, int y, int w, int h, uint32_t color, uint32_t border, int bw)
{
    WebVisualRect *r;
    if (w <= 0 || h <= 0 || l->frame->rect_count >= WEB_VISUAL_MAX_RECTS) { l->frame->truncated = 1; return; }
    r=&l->frame->rects[l->frame->rect_count++];
    r->x=x; r->y=y; r->width=w; r->height=h; r->color=color; r->border_color=border; r->border_width=bw;
}

static void flush_line(Layout *l)
{
    WebVisualText *t;
    size_t i;
    if (l->line_length == 0U) { l->x = 16 + l->style.padding; return; }
    while (l->line_length > 0U && l->line[l->line_length-1U] == ' ') l->line[--l->line_length]='\0';
    if (l->line_length == 0U) { l->x=16+l->style.padding; return; }
    if (l->frame->text_count >= WEB_VISUAL_MAX_TEXTS) { l->frame->truncated=1; l->line_length=0U; l->line[0]='\0'; return; }
    if (l->style.background != COLOR_TRANSPARENT)
        add_rect(l, 12, l->y-2, WEB_VISUAL_WIDTH-24, l->line_height+4, l->style.background, l->style.border_color, l->style.border_width);
    t=&l->frame->texts[l->frame->text_count++];
    t->x=l->style.align_center ? (WEB_VISUAL_WIDTH-(int)l->line_length*(l->style.font_size>=24?12:6))/2 : l->x;
    t->y=l->y;
    t->color=l->style.color;
    t->scale=l->style.font_size>=24 ? 2U : 1U;
    for (i=0U; i<l->line_length && i+1U<sizeof(t->text); ++i) {
        unsigned char c=(unsigned char)l->line[i];
        t->text[i]=(c<0x20U || c>=0x80U) ? '?' : (char)c;
    }
    t->text[i]='\0';
    l->y += l->line_height;
    l->x=16+l->style.padding;
    l->line_length=0U;
    l->line[0]='\0';
}

static void append_text(Layout *l, const char *value, size_t length)
{
    size_t i=0U;
    const int scale=l->style.font_size>=24 ? 2 : 1;
    const int max_chars=(WEB_VISUAL_WIDTH-40-2*l->style.padding)/(6*scale);
    if (l->style.hidden) return;
    while (i<length) {
        unsigned char c=(unsigned char)value[i++];
        if (c=='&') {
            const char *semi=memchr(value+i, ';', length-i);
            if (semi!=NULL && (size_t)(semi-(value+i))<=8U) {
                size_t n=(size_t)(semi-(value+i));
                if (n==3U && strncasecmp(value+i,"amp",n)==0) c='&';
                else if (n==2U && strncasecmp(value+i,"lt",n)==0) c='<';
                else if (n==2U && strncasecmp(value+i,"gt",n)==0) c='>';
                else if (n==4U && strncasecmp(value+i,"quot",n)==0) c='"';
                else if (n==4U && strncasecmp(value+i,"nbsp",n)==0) c=' ';
                else c='?';
                i=(size_t)(semi-value)+1U;
            }
        }
        if (isspace(c)) {
            if (l->line_length>0U && l->line[l->line_length-1U]!=' ') l->line[l->line_length++]=' ';
            continue;
        }
        if (l->line_length>=(size_t)(max_chars>1?max_chars:1) || l->line_length+1U>=sizeof(l->line)) flush_line(l);
        if (l->line_length+1U<sizeof(l->line)) {
            l->line[l->line_length++]=(c<0x20U || c>=0x80U)?'?':(char)c;
            l->line[l->line_length]='\0';
        }
    }
}

static int image_dimension(const char *value, int fallback, int maximum)
{
    char *end = NULL;
    long parsed;
    if (value == NULL || value[0] == '\0') return fallback;
    parsed = strtol(value, &end, 10);
    if (end == value || parsed <= 0L) return fallback;
    if (parsed > maximum) parsed = maximum;
    return (int)parsed;
}

static int url_matches_image(const char *raw_src, const char *stored_url)
{
    const char *raw_end;
    const char *stored_end;
    const char *raw_path;
    const char *stored_path;
    size_t raw_length;
    size_t stored_length;
    if (raw_src == NULL || raw_src[0] == '\0' || stored_url == NULL || stored_url[0] == '\0') return 0;
    if (strcmp(raw_src, stored_url) == 0) return 1;
    raw_end = strpbrk(raw_src, "?#");
    stored_end = strpbrk(stored_url, "?#");
    raw_length = raw_end != NULL ? (size_t)(raw_end - raw_src) : strlen(raw_src);
    stored_length = stored_end != NULL ? (size_t)(stored_end - stored_url) : strlen(stored_url);
    raw_path = raw_src;
    stored_path = stored_url;
    {
        const char *slash = raw_src;
        const char *last = NULL;
        while ((slash = strchr(slash, '/')) != NULL && (size_t)(slash - raw_src) < raw_length) { last = slash; ++slash; }
        if (last != NULL) raw_path = last + 1;
    }
    {
        const char *slash = stored_url;
        const char *last = NULL;
        while ((slash = strchr(slash, '/')) != NULL && (size_t)(slash - stored_url) < stored_length) { last = slash; ++slash; }
        if (last != NULL) stored_path = last + 1;
    }
    raw_length -= (size_t)(raw_path - raw_src);
    stored_length -= (size_t)(stored_path - stored_url);
    return raw_length > 0U && raw_length == stored_length && strncmp(raw_path, stored_path, raw_length) == 0;
}

static const WebEngineImage *find_cached_image(const WebEnginePage *page, const char *src, const char *alt)
{
    size_t i;
    if (page == NULL || src == NULL || src[0] == '\0') return NULL;
    for (i = 0U; i < page->image_count; ++i) {
        const WebEngineImage *image = &page->images[i];
        if (image->cache_path[0] == '\0' || !url_matches_image(src, image->url)) continue;
        if (alt == NULL || alt[0] == '\0' || image->alt[0] == '\0' || strcmp(alt, image->alt) == 0) return image;
    }
    return NULL;
}

static size_t add_placeholder_sized(Layout *l, const char *label, int width, int height,
                                    int centered, int *out_x, int *out_y)
{
    size_t text_index = SIZE_MAX;
    int x;
    flush_line(l);
    if (width < 120) width = 120;
    if (width > WEB_VISUAL_WIDTH - 32) width = WEB_VISUAL_WIDTH - 32;
    if (height < 28) height = 28;
    if (height > WEB_VISUAL_HEIGHT - 28) height = WEB_VISUAL_HEIGHT - 28;
    x = centered ? (WEB_VISUAL_WIDTH - width) / 2 : 16;
    if (out_x != NULL) *out_x = x;
    if (out_y != NULL) *out_y = l->y;
    add_rect(l, x, l->y, width, height, 0xFFF4F6F8U, 0xFFB8C1CCU, 1);
    if (l->frame->text_count < WEB_VISUAL_MAX_TEXTS) {
        WebVisualText *t = &l->frame->texts[l->frame->text_count];
        text_index = l->frame->text_count++;
        t->x = x + 12; t->y = l->y + 6; t->color = 0xFF4A5568U; t->scale = 1U;
        (void)snprintf(t->text, sizeof(t->text), "%s", label != NULL ? label : "[content]");
    }
    l->y += height + 6;
    return text_index;
}

static void add_placeholder(Layout *l, const char *label, int height)
{
    (void)add_placeholder_sized(l, label, WEB_VISUAL_WIDTH - 32, height, 0, NULL, NULL);
}

void web_visual_layout(const WebEnginePage *page, size_t scroll_pixels, WebVisualFrame *frame)
{
    Layout l;
    const char *html;
    size_t length, i=0U;
    int in_head = 0;
    VisualStyle base;
    if (frame==NULL) return;
    memset(frame,0,sizeof(*frame));
    frame->background=0xFFFFFFFFU;
    if (page==NULL || page->source_html_length==0U || page->source_html[0]=='\0') {
        size_t pos = 0U;
        int y = 18 - (int)(scroll_pixels > 100000U ? 100000U : scroll_pixels);
        frame->background=0xFFF6F8FAU;
        if (page == NULL || page->text[0] == '\0') {
            frame->text_count=1U;
            (void)snprintf(frame->texts[0].text,sizeof(frame->texts[0].text),"No visual HTML source is available.");
            frame->texts[0].x=20; frame->texts[0].y=24; frame->texts[0].color=0xFF333333U; frame->texts[0].scale=1U;
            return;
        }
        while (pos < page->text_length && frame->text_count < WEB_VISUAL_MAX_TEXTS) {
            size_t end = pos;
            WebVisualText *t;
            while (end < page->text_length && page->text[end] != '\n' && end - pos < WEB_VISUAL_TEXT_CAP - 1U) ++end;
            if (y >= -16 && y < WEB_VISUAL_HEIGHT - 12) {
                t = &frame->texts[frame->text_count++];
                t->x=20; t->y=y; t->color=0xFF333333U; t->scale=1U;
                memcpy(t->text,page->text+pos,end-pos); t->text[end-pos]='\0';
            }
            y += 20;
            pos = end < page->text_length && page->text[end] == '\n' ? end + 1U : end;
        }
        frame->content_height = (size_t)(y > 0 ? y : 0) + scroll_pixels;
        return;
    }
    html=page->source_html; length=page->source_html_length;
    memset(&l,0,sizeof(l)); l.frame=frame; l.y=18-(int)(scroll_pixels>100000U?100000U:scroll_pixels); l.x=16; l.max_x=WEB_VISUAL_WIDTH-16; l.line_height=22;
    style_default(&base); l.style=base;
    css_collect(&l,html,length);
    /* Apply root CSS and the body inline style before choosing the surface background. */
    for(i=0U;i<l.rule_count;++i) if (strcasecmp(l.rules[i].selector,"body")==0 || strcasecmp(l.rules[i].selector,"html")==0) apply_declarations(&base,l.rules[i].declarations);
    {
        const char *body = find_case_insensitive(html, "<body");
        if (body != NULL && body < html + length) {
            const char *gt = memchr(body, '>', (size_t)((html + length) - body));
            if (gt != NULL) {
                char inline_style[256];
                size_t tag_length = (size_t)(gt - body - 1);
                if (tag_length < 2048U && copy_attr(body + 1, tag_length, "style", inline_style, sizeof(inline_style)))
                    apply_declarations(&base, inline_style);
            }
        }
    }
    frame->background=base.background==COLOR_TRANSPARENT?0xFFFFFFFFU:base.background;
    l.style=base;
    i=0U;
    while(i<length) {
        if(html[i]!='<') {
            size_t start=i; while(i<length && html[i]!='<') ++i;
            if (!in_head) append_text(&l,html+start,i-start);
            continue;
        }
        if(i+3U<length && memcmp(html+i,"<!--",4U)==0) { const char *close=strstr(html+i+4U,"-->"); if(close==NULL) break; i=(size_t)(close-html)+3U; continue; }
        {
            size_t start=i+1U, end=start, n, name_start, name_end;
            char name[16], style_attr[256], id[48], klass[80], alt[WEB_ENGINE_RESOURCE_LABEL_CAP], value[128], src[WEB_ENGINE_RESOURCE_URL_CAP];
            int closing=0;
            while(end<length && html[end]!='>' && end-start<2048U) ++end;
            if(end>=length || html[end]!='>') { ++i; continue; }
            n=end-start; while(start+n>start && isspace((unsigned char)html[start])) { ++start; --n; }
            name_start=start; if(name_start<end && html[name_start]=='/') { closing=1; ++name_start; }
            while(name_start<end && (html[name_start]=='!' || html[name_start]=='?')) ++name_start;
            name_end=name_start; while(name_end<end && (isalnum((unsigned char)html[name_end]) || html[name_end]=='-')) ++name_end;
            { size_t nn=name_end-name_start; if(nn>=sizeof(name)) nn=sizeof(name)-1U; memcpy(name,html+name_start,nn); name[nn]='\0'; }
            for(size_t z=0U; name[z]!='\0'; ++z) name[z]=(char)tolower((unsigned char)name[z]);
            if (strcmp(name, "head") == 0) {
                in_head = closing ? 0 : 1;
                i = end + 1U;
                continue;
            }
            if (in_head && strcmp(name, "style") != 0 && strcmp(name, "script") != 0) {
                i = end + 1U;
                continue;
            }
            if(!closing && (strcmp(name,"script")==0 || strcmp(name,"style")==0)) {
                char close_tag[24]; const char *close;
                (void)snprintf(close_tag,sizeof(close_tag),"</%s",name);
                close=find_case_insensitive(html+end+1U,close_tag);
                if(close==NULL) break;
                i=(size_t)(close-html); continue;
            }
            if(closing) {
                flush_line(&l);
                if(strcmp(name,"h1")==0 || strcmp(name,"h2")==0 || strcmp(name,"h3")==0 || strcmp(name,"h4")==0 || strcmp(name,"p")==0 || strcmp(name,"div")==0 || strcmp(name,"section")==0 || strcmp(name,"article")==0 || strcmp(name,"li")==0 || strcmp(name,"header")==0 || strcmp(name,"footer")==0 || strcmp(name,"main")==0 || strcmp(name,"nav")==0 || strcmp(name,"blockquote")==0 || strcmp(name,"pre")==0 || strcmp(name,"form")==0 || strcmp(name,"ul")==0 || strcmp(name,"ol")==0 || strcmp(name,"button")==0 || strcmp(name,"video")==0 || strcmp(name,"audio")==0 || strcmp(name,"iframe")==0) l.y+=4;
                if(l.stack_count>0U) {
                    size_t j=l.stack_count;
                    while(j>0U && strcmp(l.stack[j-1U].name,name)!=0) --j;
                    if(j>0U) { l.style=l.stack[j-1U].style; l.stack_count=j-1U; }
                }
                i=end+1U; continue;
            }
            if(is_block(name)) {
                flush_line(&l);
                l.y+=l.style.margin_bottom;
                l.y+=l.style.margin_top;
                l.x=16+l.style.padding;
                l.line_height=l.style.font_size>=24?32:22;
            }
            {
                VisualStyle next=l.style;
                (void)copy_attr(html+name_start,end-name_start,"id",id,sizeof(id));
                (void)copy_attr(html+name_start,end-name_start,"class",klass,sizeof(klass));
                apply_tag_rules(&l,&next,name,html+name_start,end-name_start);
                if(copy_attr(html+name_start,end-name_start,"style",style_attr,sizeof(style_attr))) apply_declarations(&next,style_attr);
                if(strcmp(name,"h1")==0) { next.font_size=28; next.weight_bold=1; if(next.margin_top<6) next.margin_top=6; if(next.margin_bottom<8) next.margin_bottom=8; }
                else if(strcmp(name,"h2")==0) { next.font_size=24; next.weight_bold=1; if(next.margin_bottom<6) next.margin_bottom=6; }
                else if(strcmp(name,"h3")==0 || strcmp(name,"h4")==0) { next.font_size=20; next.weight_bold=1; }
                else if(strcmp(name,"strong")==0 || strcmp(name,"b")==0) next.weight_bold=1;
                else if(strcmp(name,"a")==0 && next.color==l.style.color) next.color=0xFF1A73E8U;
                if(next.hidden) {
                    i = is_void(name) ? end + 1U : skip_hidden_element(html, length, end + 1U, name);
                    if (i <= end) i = end + 1U;
                    continue;
                }
                if(!is_void(name) && strcmp(name,"html")!=0 && strcmp(name,"head")!=0 && strcmp(name,"body")!=0 && l.stack_count<HTML_STACK_MAX) {
                    StackEntry *e=&l.stack[l.stack_count++]; (void)snprintf(e->name,sizeof(e->name),"%s",name); e->style=l.style; e->block=is_block(name); e->start_y=l.y;
                }
                l.style=next;
            }
            if(strcmp(name,"br")==0) { flush_line(&l); l.y+=4; }
            else if(strcmp(name,"hr")==0) { flush_line(&l); add_rect(&l,16,l.y,WEB_VISUAL_WIDTH-32,2,0xFFDDDDDDU,0xFFDDDDDDU,0); l.y+=12; }
            else if(strcmp(name,"img")==0) {
                const WebEngineImage *cached;
                int w = 400, h = 220, image_x = 16, image_y = l.y;
                size_t placeholder_index;
                src[0] = '\0'; alt[0] = '\0'; value[0] = '\0';
                (void)copy_attr(html+name_start,end-name_start,"src",src,sizeof(src));
                (void)copy_attr(html+name_start,end-name_start,"alt",alt,sizeof(alt));
                (void)copy_attr(html+name_start,end-name_start,"width",value,sizeof(value));
                w = image_dimension(value, w, WEB_VISUAL_WIDTH - 32);
                value[0] = '\0';
                (void)copy_attr(html+name_start,end-name_start,"height",value,sizeof(value));
                h = image_dimension(value, h, WEB_VISUAL_HEIGHT - 28);
                if(alt[0]=='\0') (void)snprintf(alt,sizeof(alt),"Image resource");
                cached = find_cached_image(page, src, alt);
                placeholder_index = add_placeholder_sized(&l, alt, w, h, 1, &image_x, &image_y);
                if(cached != NULL && frame->image_count < WEB_VISUAL_MAX_IMAGES) {
                    WebVisualImage *image = &frame->images[frame->image_count++];
                    image->x = image_x; image->y = image_y; image->width = w; image->height = h;
                    image->placeholder_text_index = placeholder_index;
                    (void)snprintf(image->cache_path, sizeof(image->cache_path), "%s", cached->cache_path);
                }
            }
            else if(strcmp(name,"input")==0 || strcmp(name,"button")==0) {
                (void)copy_attr(html+name_start,end-name_start,"placeholder",value,sizeof(value));
                if(value[0]=='\0') (void)copy_attr(html+name_start,end-name_start,"value",value,sizeof(value));
                if(value[0]=='\0') (void)snprintf(value,sizeof(value),"%s",strcmp(name,"button")==0?"Button":"Input field");
                add_placeholder(&l,value,32);
            }
            else if(strcmp(name,"iframe")==0) add_placeholder(&l,"Embedded content (frame engine not available)",56);
            else if(strcmp(name,"video")==0) add_placeholder(&l,"Video player placeholder (native playback unavailable)",92);
            else if(strcmp(name,"audio")==0) add_placeholder(&l,"Audio player placeholder (native playback unavailable)",40);
            else if(strcmp(name,"li")==0) { flush_line(&l); l.x=32+l.style.padding; l.line[0]=' '; l.line[1]=' '; l.line[2]='-'; l.line[3]=' '; l.line_length=4U; }
            i=end+1U;
        }
    }
    flush_line(&l);
    frame->content_height=(size_t)(l.y > 0 ? l.y : 0) + scroll_pixels;
    if(l.truncation) frame->truncated=1;
    /* CPU-side visible clipping: background and box rectangles are painted by the GPU module. */
    for(i=0U;i<frame->rect_count;++i) {
        WebVisualRect *r=&frame->rects[i];
        r->y -= (int)scroll_pixels;
    }
    for(i=0U;i<frame->text_count;++i) frame->texts[i].y -= (int)scroll_pixels;
    for(i=0U;i<frame->image_count;++i) frame->images[i].y -= (int)scroll_pixels;
}
