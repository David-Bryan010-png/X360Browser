#ifndef X360BROWSER_VISUAL_LAYOUT_H
#define X360BROWSER_VISUAL_LAYOUT_H

#include <stddef.h>
#include <stdint.h>
#include "web_engine.h"

#ifdef __cplusplus
extern "C" {
#endif

#define WEB_VISUAL_WIDTH 1152
#define WEB_VISUAL_HEIGHT 384
#define WEB_VISUAL_MAX_RECTS 160
#define WEB_VISUAL_MAX_TEXTS 192
#define WEB_VISUAL_MAX_IMAGES 8
#define WEB_VISUAL_TEXT_CAP 224

typedef struct {
    int x, y, width, height;
    uint32_t color;
    uint32_t border_color;
    int border_width;
} WebVisualRect;

typedef struct {
    int x, y;
    uint32_t color;
    uint32_t scale;
    char text[WEB_VISUAL_TEXT_CAP];
} WebVisualText;

typedef struct {
    int x, y, width, height;
    size_t placeholder_text_index;
    char cache_path[WEB_ENGINE_IMAGE_CACHE_PATH_CAP];
} WebVisualImage;

typedef struct {
    uint32_t background;
    WebVisualRect rects[WEB_VISUAL_MAX_RECTS];
    size_t rect_count;
    WebVisualText texts[WEB_VISUAL_MAX_TEXTS];
    size_t text_count;
    WebVisualImage images[WEB_VISUAL_MAX_IMAGES];
    size_t image_count;
    size_t content_height;
    int truncated;
} WebVisualFrame;

/* Static, bounded HTML/CSS layout; does not execute scripts or fetch resources. */
void web_visual_layout(const WebEnginePage *page, size_t scroll_pixels, WebVisualFrame *frame);

#ifdef __cplusplus
}
#endif
#endif
