X360Browser 0.8.0 — VisualLite

Keep cacert.pem beside X360Browser.xex. VisualLite draws static HTML flow and a limited CSS subset, and displays PNGs when the PNG decoder was available at build time and the cache directory is writable. Each PNG download is capped at 1 MiB and each decoded image at 1024x1024 pixels.

Other image formats, CSS backgrounds, scripts, dynamic DOM, iframe content, form submission, embedded audio/video, Canvas, WebGL, WebAssembly and modern web games are not supported. Audio/video resources can be inventoried; direct video files may be downloaded and optionally handed off to a compatible external player.

Controls: D-pad scroll/select; LB/RB page scroll; A address/open; X cycles VisualLite/reader/links/resources; Y reload/remove favorite; B/Left back; Right forward; Start home; Left Thumb favorite; Right Thumb favorites; Back exit.
