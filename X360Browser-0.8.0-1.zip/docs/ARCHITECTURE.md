# X360Browser 0.8.0 — arquitetura

## Camadas

- **UI xSDK** (`platform/xbox360/xsdk/main.c`): interface 720p, controles, endereço, histórico, favoritos e alternância de visualizações.
- **Dispatcher** (`web_engine_dispatch.c`): tenta NetSurf se um backend real declarar disponibilidade; fallback automático para NativePlus.
- **NetSurf adapter stub** (`netsurf_backend_stub.c`): não renderiza páginas. O NetSurf real ainda não foi portado/ligado.
- **NativePlus** (`web_engine.c`): libcurl HTTP/HTTPS, TLS verificado, limite de HTML, parser leve, metadados, links e inventário de recursos; baixa folhas CSS pequenas e PNGs com limites.
- **VisualLite layout** (`visual_layout.c`): layout estático de fluxo e subset de CSS. Não roda scripts nem constrói um DOM dinâmico completo.
- **VisualLite renderer** (`visual_renderer.c`): desenha caixas/backgrounds para uma superfície CPU, decodifica PNGs por LodePNG quando disponível, envia a textura à GPU xSDK e desenha os textos sobre a página.

## Fluxo

1. UI valida HTTP(S) e abre uma thread de rede.
2. O dispatcher testa o backend NetSurf; no build atual ele reporta indisponibilidade e o NativePlus recebe o URL.
3. NativePlus descarrega HTML com limite, extrai metadados/recursos e copia até um limite a fonte HTML para o renderer.
4. São buscadas no máximo quatro folhas CSS pequenas e até quatro imagens PNG candidatas, com timeouts, TLS verificado e limites de bytes.
5. VisualLite calcula boxes/textos e a GPU apresenta a superfície renderizada. X alterna para leitor textual, links e recursos.

## Limites e segurança

- A página HTML tem limite de download de 512 KiB; o buffer visual retém apenas uma parte limitada da fonte.
- Cada PNG tem limite de 1 MiB, é aceito apenas com MIME `image/png` e assinatura PNG, e a dimensão decodificada é limitada a 1024×1024.
- Requests de imagens/folhas de estilo aceitam HTTP/HTTPS, verificam certificados TLS e têm timeout.
- O parser CSS só entende propriedades comuns e seletores simples; regras complexas são ignoradas.
- JavaScript não é executado; URLs de `<script>` são apenas catalogadas.
- Uma integração real NetSurf requer portar e ligar suas dependências e frontend para o xSDK, além de testes de RAM/performance no console.
