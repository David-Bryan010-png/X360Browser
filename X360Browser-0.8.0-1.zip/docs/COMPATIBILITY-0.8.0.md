# Compatibility matrix — 0.8.0

| Feature | Status | Notes |
|---|---|---|
| HTTP/HTTPS | Implemented in NativePlus | TLS verify + bounded HTML |
| HTML page visual | Partial | Static flow, no complete DOM/CSS spec |
| Inline CSS | Partial | Common colors, size, alignment, spacing, borders |
| `<style>` / small external stylesheet | Partial | Simple tag/class/id rules; 4 stylesheets maximum |
| PNG image pixels | Partial | Up to 4 download attempts, 1 MiB per file, 1024×1024 decode cap |
| JPEG / WebP / GIF / SVG | No | Placeholder/resource list only |
| Links / history / favorites | Implemented in source | Console behavior must be checked |
| Forms | Placeholder only | No actual browser form submission flow |
| Iframes / embeds | Placeholder only | No nested browsing contexts |
| Audio / video | Partial | Direct file download + optional external player; not embedded playback |
| JavaScript / dynamic DOM | No | Scripts are not executed |
| Canvas / WebGL / WebAssembly / WebSockets | No | Modern web games not supported |
| Real NetSurf engine | No | Adapter remains a stub |
