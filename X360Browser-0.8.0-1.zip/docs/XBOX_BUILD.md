# Build X360Browser 0.8.0 para Xbox 360

O caminho principal é o workflow `.github/workflows/build-xbox-engine.yml`, que roda testes de host e, se passarem, tenta compilar o XEX com xSDK/curl-xenon/mbedtls-xenon. LodePNG é baixado de uma revisão fixa durante o build.

1. Envie as alterações de código e o workflow para o repositório.
2. Em GitHub, abra **Actions → Build X360Browser 0.8.0 VisualLite**.
3. Aguarde o job `host-tests` e depois o job `build-xbox360` terminarem com sucesso.
4. Baixe `X360Browser-0.8.0-web-engine` nos artifacts.
5. Copie `X360Browser.xex` e `cacert.pem` para o console; mantenha-os juntos.

Sucesso nos testes do host não garante que o XEX compile. Se o build de PowerPC falhar, baixe o log do artifact e use a mensagem do compilador para corrigir o port. O teste final deve ser feito em um Xbox 360 RGH/JTAG.
