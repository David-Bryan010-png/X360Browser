# Testes X360Browser 0.8.0

## Testes no host

Execute na raiz do projeto:

```sh
python3 tests/run_host_tests.py
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release -DX360BROWSER_BUILD_TESTS=ON
cmake --build build --parallel 2
ctest --test-dir build --output-on-failure
```

O runner testa transporte/HTML e dispatcher com servidor HTTP local; testa VisualLite separadamente; e os checks do workflow verificam sintaxe da UI/renderizador contra stubs de API xSDK, incluindo o caminho de compilação com LodePNG.

## O que os testes não provam

Eles não validam código PowerPC compilado, shaders realmente executados em GPU Xenos, rede/TLS no console ou comportamento de controllers/arquivos em hardware. Esses aspectos dependem do job de cross-build e de um teste no Xbox 360.
