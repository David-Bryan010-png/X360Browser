# X360Browser 0.8.0 — status

## Implementado no código
- HTTP/HTTPS por libcurl com verificação de certificado e limite de 512 KiB para HTML.
- Extração de metadados, links, URLs de imagem/srcset/CSS, referências de script/style, formulários, iframes e fontes de áudio/vídeo.
- Viewport VisualLite com layout estático para títulos, parágrafos, blocos, listas simples, links, cores, bordas, espaçamento e subset de CSS por tag/classe/id/inline.
- Download de até quatro PNGs candidatos por página, máximo 1 MiB cada, validação MIME/assinatura e decode limitado a 1024×1024 (quando LodePNG está presente no build).
- Leitor textual, listas de links/recursos, favoritos, navegação histórica e handoff opcional de vídeo direto.
- Testes de host para parser/dispatcher, download PNG, validação de recursos e layout visual portátil.

## Ainda não implementado
- NetSurf real: `netsurf_backend_stub.c` segue sendo um stub, portanto o dispatcher usa NativePlus/VisualLite.
- JavaScript/DOM dinâmico, cascade/layout CSS completo, flex/grid, fontes web, animações ou aplicações SPA.
- Decodificação JPEG/WebP/GIF/SVG, imagem inline/data URI e imagens de fundo CSS.
- Players nativos de áudio/vídeo, HLS/DASH, WebSockets, Canvas/WebGL/WebAssembly e jogos web.

## Verificação necessária
Testes do host e compilação sintática não equivalem a um build XEX de PowerPC. Ainda é necessário aguardar o workflow de cross-build e testar o artefato em um Xbox 360 RGH/JTAG, incluindo permissões para gravar cache no diretório de trabalho, TLS/DNS, velocidade de rolagem e integridade visual.
