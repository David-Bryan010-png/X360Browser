# Roadmap after X360Browser 0.8.0

1. Verify an actual PowerPC XEX build and console GPU output; fix texture cache/layout issues observed on hardware.
2. Expand CSS subset carefully with tests (block inline behavior, width/height/max-width, backgrounds) without claiming full browser compatibility.
3. Add more image decoders only if they can be built against the Xbox toolchain with bounded memory; maintain explicit input limits.
4. Port a real HTML/CSS engine such as NetSurf as a separate large project, including its dependency stack and native frontend. Remove the stub only after the engine demonstrably lays out and paints a test page on console.
5. Evaluate a JavaScript engine and web platform APIs after renderer integration; modern SPAs/games depend on much more than parsing HTML.

Web-game compatibility is not a near-term guarantee: browser JavaScript APIs, networking/WebSockets, Canvas/WebGL, media codecs and possibly WebAssembly need independent implementations and compatibility testing.
