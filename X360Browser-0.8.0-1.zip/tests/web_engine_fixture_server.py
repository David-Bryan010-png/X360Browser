from http.server import BaseHTTPRequestHandler, HTTPServer
import struct
import zlib

def png_chunk(kind: bytes, payload: bytes) -> bytes:
    return struct.pack(">I", len(payload)) + kind + payload + struct.pack(">I", zlib.crc32(kind + payload) & 0xFFFFFFFF)

PNG_1X1 = (b"\x89PNG\r\n\x1a\n" +
           png_chunk(b"IHDR", struct.pack(">IIBBBBB", 1, 1, 8, 6, 0, 0, 0)) +
           png_chunk(b"IDAT", zlib.compress(b"\x00\xff\x00\x00\xff")) +
           png_chunk(b"IEND", b""))

HTML = b'''<!doctype html>
<html><head>
<title>X360Browser Test</title>
<meta name="description" content="Fixture page for NativePlus">
<link rel="stylesheet" href="/site.css">
<script>document.write("must not execute")</script>
</head><body>
<style>.hero { background-image: url('/assets/background.webp'); }</style>
<h1>Heading</h1><p style="background-image: url('/assets/inline.png')">Welcome to the test.</p>
<a href="/next">Next page</a>
<img src="/assets/picture.png" srcset="/assets/picture-small.png 320w, /assets/picture-large.png 1280w" alt="Sample photo" width="640" height="480">
<video controls><source src="/clip.mp4" type="video/mp4"><source src="/playlist.m3u8" type="application/vnd.apple.mpegurl"></video>
<audio src="/audio.mp3" type="audio/mpeg"></audio>
<iframe src="/embed"></iframe>
<form><input name="q"></form>
</body></html>'''

class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path == "/page.html":
            body, ctype = HTML, "text/html; charset=utf-8"
        elif self.path == "/big.bin":
            body, ctype = b"x" * (2 * 1024 * 1024), "video/mp4"
        elif self.path == "/clip.mp4":
            body, ctype = b"FAKE-MP4-V0.7", "video/mp4"
        elif self.path == "/html-looks-like-video.mp4":
            body, ctype = b"<html><title>not a video</title></html>", "text/html; charset=utf-8"
        elif self.path == "/playlist.m3u8":
            body, ctype = b"#EXTM3U\n#EXTINF:10,\nsegment.ts\n", "application/vnd.apple.mpegurl"
        elif self.path == "/assets/picture.png":
            body, ctype = PNG_1X1, "image/png"
        elif self.path.endswith((".png", ".webp", ".mp4", ".mp3", ".css", ".js")):
            body, ctype = b"x", ("video/mp4" if self.path.endswith(".mp4") else
                                   "audio/mpeg" if self.path.endswith(".mp3") else
                                   "image/webp" if self.path.endswith(".webp") else
                                   "image/png" if self.path.endswith(".png") else
                                   "text/css" if self.path.endswith(".css") else
                                   "application/javascript")
        else:
            body, ctype = b"not found", "text/plain; charset=utf-8"
        self.send_response(200 if self.path in ("/page.html", "/big.bin", "/clip.mp4", "/html-looks-like-video.mp4", "/playlist.m3u8", "/assets/picture.png") else 404)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        try:
            self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def log_message(self, *_args):
        pass

if __name__ == "__main__":
    HTTPServer(("127.0.0.1", 18765), Handler).serve_forever()
