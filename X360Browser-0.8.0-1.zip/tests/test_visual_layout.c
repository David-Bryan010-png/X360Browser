#include "visual_layout.h"

#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

static int text_contains(const WebVisualFrame *frame, const char *needle)
{
    size_t i;
    for (i = 0U; i < frame->text_count; ++i)
        if (strstr(frame->texts[i].text, needle) != NULL) return 1;
    return 0;
}

int main(void)
{
    static const char html[] =
        "<html><head><title>Not shown in page flow</title>"
        "<style>body { background-color: #eeeeee; }"
        "h1 { color: #ff0000; font-size: 30px; }"
        ".card { background-color: #ddeeff; padding: 8px; border: 1px solid #aabbcc; }"
        "a { color: #0000ff; }.hidden { display: none; }</style></head>"
        "<body style='background-color:#fafafa'><div class='card'>"
        "<h1 id='hero'>Visual test heading</h1>"
        "<p style='color:#008000'>Green paragraph text for layout</p>"
        "<a href='/go'>Visit test link</a>"
        "<p class='hidden'>SHOULD NOT SHOW</p>"
        "<img src='/tiny.png' alt='Image placeholder' width='120' height='50'>"
        "<input placeholder='Search field'><video></video>"
        "</div></body></html>";
    WebEnginePage page;
    WebVisualFrame frame;
    size_t i;
    int saw_heading_color = 0;
    int saw_body_background = 0;
    int saw_link_color = 0;
    memset(&page, 0, sizeof(page));
    memcpy(page.source_html, html, sizeof(html));
    page.source_html_length = sizeof(html) - 1U;
    page.image_count = 1U;
    (void)snprintf(page.images[0].url, sizeof(page.images[0].url), "https://example.test/tiny.png");
    (void)snprintf(page.images[0].alt, sizeof(page.images[0].alt), "Image placeholder");
    (void)snprintf(page.images[0].cache_path, sizeof(page.images[0].cache_path), "X360Browser-cache-test.png");
    web_visual_layout(&page, 0U, &frame);
    assert(frame.text_count >= 5U);
    assert(frame.rect_count >= 4U);
    assert(frame.background == 0xFFFAFAFAU);
    assert(text_contains(&frame, "Visual test heading"));
    assert(text_contains(&frame, "Green paragraph text"));
    assert(text_contains(&frame, "Visit test link"));
    assert(text_contains(&frame, "Image placeholder"));
    assert(frame.image_count == 1U);
    assert(frame.images[0].width == 120 && frame.images[0].height == 50);
    assert(frame.images[0].placeholder_text_index < frame.text_count);
    assert(text_contains(&frame, "Search field"));
    assert(!text_contains(&frame, "Not shown in page flow"));
    assert(!text_contains(&frame, "SHOULD NOT SHOW"));
    for (i = 0U; i < frame.text_count; ++i) {
        if (strstr(frame.texts[i].text, "Visual test heading") != NULL && frame.texts[i].color == 0xFFFF0000U)
            saw_heading_color = 1;
        if (strstr(frame.texts[i].text, "Visit test link") != NULL && frame.texts[i].color == 0xFF0000FFU)
            saw_link_color = 1;
    }
    for (i = 0U; i < frame.rect_count; ++i)
        if (frame.rects[i].color == 0xFFDDEEFFU) saw_body_background = 1;
    assert(saw_heading_color);
    assert(saw_link_color);
    assert(saw_body_background);
    assert(frame.content_height > 100U);

    web_visual_layout(&page, 60U, &frame);
    for (i = 0U; i < frame.text_count; ++i) {
        if (strstr(frame.texts[i].text, "Visual test heading") != NULL)
            assert(frame.texts[i].y < 100);
    }
    puts("PASS: VisualLite HTML/CSS flow, colors, image cache binding, block boxes and placeholders");
    return 0;
}
