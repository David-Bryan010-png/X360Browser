#ifndef MOCK_LODEPNG_H
#define MOCK_LODEPNG_H
unsigned lodepng_decode32_file(unsigned char **out, unsigned *w, unsigned *h, const char *filename);
#endif
