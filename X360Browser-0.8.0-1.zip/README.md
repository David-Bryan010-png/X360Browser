# X360Browser 0.8.0 — VisualLite

Navegador homebrew para Xbox 360 RGH/JTAG. A versão 0.8.0 adiciona uma superfície de página desenhada pela GPU e um renderizador estático de HTML/CSS, além do leitor de texto e do inventário de recursos que já existiam.

## O que mudou na 0.8.0

- **VisualLite:** desenha uma página como blocos visuais no viewport 720p — títulos, parágrafos, quebras de linha, listas, links coloridos, caixas, bordas, cores de texto/fundo, alinhamento central, margens e padding simples.
- **CSS limitado:** lê regras `tag`, `.classe` e `#id` de `<style>` e propriedades inline comuns. CSS externo pequeno também é baixado com limites de tamanho, timeout e verificação TLS.
- **Imagens PNG estáticas:** tenta baixar até quatro candidatos PNG por página, verifica MIME, assinatura e limite de 1 MiB por arquivo; o decodificador LodePNG é fixado numa revisão upstream. O renderizador limita dimensões decodificadas a 1024×1024 e mantém um cache pequeno em memória.
- **Conteúdo não implementado não é fingido:** JPEG, WebP, GIF, SVG, iframes, formulários, áudio e vídeo continuam como caixas de placeholder/recursos. O leitor textual continua disponível como alternativa.
- **Testes do host:** cobre download PNG limitado, rejeição de respostas incorretas, inventário de recursos, dispatcher, layout estático e propriedades visuais básicas.

## Controles

- D-pad Up/Down: rolar a página ou selecionar item nas listas.
- LB/RB: rolagem por tela.
- A: abrir a barra de endereço ou ativar o item selecionado.
- X: alternar **VisualLite → Leitor → Links → Recursos → VisualLite**.
- Y: recarregar; na lista de favoritos, remover o favorito selecionado.
- B / D-pad Left: voltar; D-pad Right: avançar.
- Start: página inicial. Left Thumb: salvar favorito. Right Thumb: abrir favoritos. Back: sair.

## Limites atuais — leia antes de usar

**Esta versão é visual para páginas estáticas, mas ainda não é um navegador moderno completo.** Não executa JavaScript nem implementa DOM dinâmico, layout completo de CSS, fontes web, SVG, JPEG/WebP/GIF, Canvas 2D, WebGL, WebAssembly, WebSockets, service workers ou reprodução de vídeo embutido. Aplicações SPA modernas, sites que dependem de JavaScript e jogos web como ports de Among Us não são suportados.

O backend NetSurf continua sendo um stub de capacidade; o renderizador realmente usado é o VisualLite desenvolvido dentro deste projeto. O trabalho para integrar NetSurf de verdade é uma etapa separada de port de bibliotecas e frontend, não uma simples opção CMake.

## Build

O projeto usa GitHub Actions para executar testes do host e tentar compilar o XEX usando xSDK, curl-xenon e mbedtls-xenon. O script baixa LodePNG de uma revisão fixa antes da compilação. Os testes do host **não** comprovam que o XEX compila ou funciona no hardware real; esse passo só pode ser confirmado quando a etapa PowerPC do workflow terminar e o binário for testado no Xbox.

Para HTTPS, mantenha `cacert.pem` ao lado de `X360Browser.xex`. O relógio do console deve estar correto. As imagens PNG em cache são arquivos no diretório de trabalho atual do XEX; se esse diretório não for gravável, o navegador mantém placeholders.

## Projetos de terceiros

- xSDK: https://github.com/xenosworks/xsdk
- curl-xenon: https://github.com/xenosworks/curl-xenon
- mbedtls-xenon: https://github.com/xenosworks/mbedtls-xenon
- LodePNG (revisão fixada no script de build): https://github.com/lvandeve/lodepng
- NetSurf (não integrado nesta versão): https://www.netsurf-browser.org/
