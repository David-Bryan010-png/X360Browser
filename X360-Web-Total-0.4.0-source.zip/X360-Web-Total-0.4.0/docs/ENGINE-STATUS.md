# X360 Web Total 0.4.0 — estado técnico

## Interface

- Home nativa textual e menu de configurações executados pelo ELF.
- Prévia HTML completa em `browser/ui/home.html`; cópia de referência USB em `X360WebTotal/ui/home.html`.
- A página HTML não é renderizada pelo LibXenon atual: CSS/JavaScript ainda não existem no motor. A arte de capa DVDBRN é separada da interface e não é usada como splash.

## Entrada e controle

- O loop chama `usb_do_poll()` continuamente, permitindo que o stack USB/HID atualize os snapshots do controle.
- `get_controller_data()` só é processado quando retorna `> 0`; retorno `0` indica que não há novo relatório e não deve ser tratado como botão pressionado.
- Porta de controle configurável por `controller_port=0..3`. Padrão: porta 1 (índice 0).

## Rede

- `network_init()` inicializa lwIP e tenta DHCP. `network_poll()` continua sendo executado no loop principal.
- Modo estático usa `dhcp_stop()` e `netif_set_addr()` depois que a interface foi criada.
- Em falha de DHCP com link presente, os campos de IP estático configurados servem como fallback.
- DNS UDP próprio usa `dns_primary` e `dns_secondary` carregados do INI. Padrões: 1.1.1.1 e 8.8.8.8.
- `browser.ini` persiste modo, IP, máscara, gateway, DNS, homepage e porta do controle. As mudanças de modo/IP são aplicadas no próximo início do ELF.

## Motor web nativo

- HTTP/1.x por TCP raw lwIP com limites de memória e validação de status/cabeçalhos/framing.
- DNS A/IN via UDP, resolução não bloqueante e servidor secundário de contingência.
- Parser HTML limitado com títulos, blocos, âncoras, listas, texto alternativo e resolução de links.
- Layout das páginas continua textual. HTTPS/TLS, CSS, JavaScript, rasterização de imagens, áudio e vídeo não estão implementados.

## Verificações

- CMake host: compila módulos portáveis e executa os testes de URL, HTML, layout, HTTP, DNS e configuração.
- Python: valida ELF, caminhos/CRC/SHA do pacote USB e o fluxo do empacotador com entradas sintéticas.
- Compilação cruzada LibXenon/PowerPC e teste físico no Xbox ainda precisam ser executados pelo workflow e no console. Testes host não substituem esses testes.
