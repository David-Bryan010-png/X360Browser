# X360 Web Total 0.4.0

**Ambiente independente para Xbox 360 · Projeto DVDBRN**

O X360 Web Total é carregado como `xenon.elf` pelo XeLL Reloaded, usando LibXenon. `XellLaunch2.xex` é apenas o ponto de entrada do launcher a partir de uma dashboard homebrew; não é o navegador em si.

## O que mudou na 0.4.0

- Removida a imagem de prévia anterior da função de splash. A arte de capa/identidade do proprietário DVDBRN é separada da UI e não deve ser usada como tela inicial do navegador.
- Nova home/configurador HTML em `browser/ui/home.html`, também incluída no pacote como `X360WebTotal/ui/home.html`.
- Página HTML com Início, Rede e Internet, Navegador, Sistema, Controle e Sobre.
- Configuração HTML com armazenamento local no navegador do celular/PC e exportação de `browser.ini`.
- Configuração nativa persistente: DHCP ou IP estático, IP, máscara, gateway, DNS primário/secundário, homepage e porta de controle.
- DNS do motor passou a usar os endereços configurados, em vez de ficar permanentemente preso a 1.1.1.1 e 8.8.8.8.
- O loop principal agora chama `usb_do_poll()` continuamente. O estado do controle só é processado quando `get_controller_data()` entrega um relatório novo (`> 0`), evitando tratar dados antigos como eventos novos.
- O controle pode ser selecionado nas quatro portas LibXenon; START continua abrindo/atualizando, Y abre configurações, A seleciona, B volta, X apaga/volta conforme a tela e BACK encerra.

## Interface HTML: importante

`browser/ui/home.html` é uma prévia funcional de interface e um configurador de `browser.ini`. Ela roda em navegadores modernos no celular/PC. O runtime LibXenon desta versão **não possui um motor CSS/JavaScript para renderizar essa página no Xbox**. Por isso, o ELF mantém uma tela nativa textual de Home/Configurações e lê os mesmos campos do arquivo INI. A próxima etapa é portar o layout para o renderer gráfico nativo; não afirmamos que o HTML já é renderizado no console.

## Rede

Configuração padrão no pacote:

```ini
network_mode=dhcp
static_ip=192.168.1.99
netmask=255.255.255.0
gateway=192.168.1.1
dns_primary=1.1.1.1
dns_secondary=8.8.8.8
```

DHCP é a escolha recomendada. IP estático é aplicado depois que a interface LibXenon é inicializada; os valores devem pertencer à rede do roteador. O endereço `192.168.1.99` é somente um padrão de exemplo, não uma garantia de compatibilidade com qualquer rede. DNS pode ser alterado no menu nativo ou exportando `browser.ini` pela página HTML.

A pilha continua sendo lwIP em polling: `network_poll()` é chamado em cada iteração do loop principal. Isso mantém a pilha ativa durante navegação, mas não significa que toda rede/roteador vá funcionar; ainda é necessário testar link, gateway, DNS e HTTP no console real.

## Controle

- O LibXenon expõe `get_controller_data()` como um snapshot novo/pendente; `0` significa que não há relatório novo naquele instante. A aplicação agora só trata bordas de botão quando recebe um relatório novo.
- `usb_do_poll()` é chamado a cada iteração para alimentar a pilha USB/HID. A versão anterior só fazia polling durante a inicialização, o que explicava entradas ausentes ou inconsistentes.
- A porta padrão é a 1 (índice LibXenon 0). Pode ser alterada para as portas 2–4 em Configurações.

## Compilação

Testes de host:

```sh
cmake -S browser -B build-host -DCMAKE_BUILD_TYPE=Release
cmake --build build-host --parallel 2
ctest --test-dir build-host --output-on-failure
python3 scripts/test_package_usb.py
```

Xbox 360 com LibXenon:

```sh
cd browser
make clean all DEVKITXENON=/caminho/para/devkitxenon
```

Gera `browser/xenon.elf`, ELF32 big-endian PowerPC. Não é um XEX para iniciar diretamente pelo Aurora.

Pacote FAT32:

```sh
python3 scripts/package_usb.py \
  --elf browser/xenon.elf \
  --xell XellLaunch2.xex \
  --project . \
  --output X360-Web-Total-USB.zip
```

## Limites atuais do motor web nativo

| Recurso | Situação |
|---|---|
| Inicialização XeLL → ELF | Implementada no fluxo previsto; depende da toolchain e do XeLL |
| Home/configurações nativas | Implementadas em texto; HTML de prévia acompanha o pacote |
| Controle USB | Polling contínuo corrigido; precisa teste físico de portas/controles |
| Rede Ethernet / lwIP | DHCP + fallback estático; polling contínuo |
| DNS A/UDP | Dois servidores configuráveis |
| HTTP/1.x | Implementado em versão experimental |
| HTML / links | Parser estrutural limitado e visualização textual |
| CSS / JavaScript | Não implementados |
| HTTPS/TLS | Não implementado |
| Imagens de páginas / áudio / vídeo | Não implementados |

A compilação cruzada para PowerPC e o teste no Xbox real ainda precisam ser executados. Testes de host não demonstram compatibilidade completa do hardware.

## Arte de capa DVDBRN

A capa de proprietário é uma arte separada da home do aplicativo. A fonte original dessa capa não estava dentro do pacote 0.3.0 recebido para esta alteração, portanto não foi substituída pela imagem de prévia do YouTube nem por outra imagem. Ela deve permanecer como material de capa/identidade, não como tela inicial carregada pelo ELF.
