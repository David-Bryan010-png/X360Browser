# Changelog — X360 Web Total

## 0.4.0 — Home/configurações, rede persistente e polling do controle

- Retirada a prévia gráfica anterior do fluxo de boot. A capa DVDBRN é material separado da interface do navegador.
- Criada `browser/ui/home.html`, uma home HTML completa de prévia/configuração com painel de Rede, Navegador, Sistema e Controle.
- Incluída a página no pacote USB em `X360WebTotal/ui/home.html`.
- Expandido o INI: modo DHCP/estático, IP, máscara, gateway, DNS primário/secundário, homepage e porta de controle.
- Adicionada validação, normalização e gravação de configuração.
- DNS UDP usa os servidores definidos no INI.
- Aplicação de IP estático após inicialização da interface LibXenon.
- Corrigido o loop de controle: polling USB contínuo e tratamento somente de amostras novas.
- O menu nativo ganhou Configurações; Y abre, D-pad seleciona, A alterna/edita, START confirma e salva, B cancela/volta.

## 0.3.0 — tela de prévia gráfica

Foi a versão base recebida para esta atualização. Sua arte de prévia não era a capa de proprietário e foi removida do fluxo de tela inicial.

## Limites mantidos

O motor nativo ainda não implementa CSS, JavaScript, HTTPS/TLS, imagens de páginas ou áudio/vídeo. A home HTML é uma prévia/configurador e não é renderizada pelo ELF atual.
