/*
 * X360 Web Total 0.4.0 — standalone LibXenon system environment.
 * The executable is loaded by XeLL as xenon.elf. It owns its UI, input,
 * storage, network polling and browser navigation after XeLL transfers control.
 * HTTPS/TLS, CSS, JavaScript, raster images and audio/video are not claimed.
 */
#include <stdio.h>
#include <string.h>

#include <console/console.h>
#include <diskio/ata.h>
#include <input/input.h>
#include <libfat/fat.h>
#include <network/network.h>
#include <time/time.h>
#include <usb/usbmain.h>
#include <xenon_soc/xenon_power.h>
#include <xenos/xenos.h>
#include <lwip/dhcp.h>
#include <lwip/ip_addr.h>

#include "xw_config.h"
#include "xw_html.h"
#include "xw_http_client.h"
#include "xw_layout.h"
#include "xw_url.h"
#include "xw_dns_client.h"

#define ADDRESS_CAP 256
#define KEY_ROWS 6
#define KEY_COLS 8
#define HISTORY_MAX 24

static const char keyboard[KEY_ROWS][KEY_COLS + 1] = {
    "abcdefgh", "ijklmnop", "qrstuvwx", "yz012345", "6789.-_/", ":?&=%+# "
};

static char address[ADDRESS_CAP] = "http://neverssl.com/";
static XwConfig browser_config;
static unsigned key_row;
static unsigned key_col;
static int network_ready;
static XwHtmlDocument current_document;
static XwLayout current_layout;
static int current_http_status;
static char ui_message[160];
static unsigned loading_frames;
static unsigned selected_link_index;
static size_t page_scroll;
static unsigned redirect_count;
static char history[HISTORY_MAX][ADDRESS_CAP];
static unsigned history_count;
static unsigned history_position;
static unsigned settings_item;
static int edit_field = -1;
static char edit_value[ADDRESS_CAP];
static unsigned edit_key_row;
static unsigned edit_key_col;

typedef enum { SCREEN_HOME = 0, SCREEN_LOADING, SCREEN_PAGE, SCREEN_ERROR, SCREEN_SETTINGS, SCREEN_EDIT } Screen;
static Screen screen = SCREEN_HOME;

static void load_browser_config(void)
{
    FILE *file = fopen("X360WebTotal/config/browser.ini", "rb");
    char contents[XW_CONFIG_MAX_BYTES];
    char error[128];
    size_t length;
    int overflow;
    xw_config_defaults(&browser_config);
    if (file != NULL) {
        length = fread(contents, 1u, sizeof(contents), file);
        overflow = fgetc(file) != EOF;
        if (ferror(file) == 0 && overflow == 0 &&
            xw_config_parse(contents, length, &browser_config, error, sizeof(error)) == 0) {
            (void)snprintf(address, sizeof(address), "%s", browser_config.homepage);
        } else {
            (void)snprintf(ui_message, sizeof(ui_message), "config invalida; usando valores padrao");
            xw_config_defaults(&browser_config);
        }
        (void)fclose(file);
    }
    (void)xw_dns_set_servers(browser_config.dns_primary, browser_config.dns_secondary);
}

static int save_browser_config(void)
{
    char contents[XW_CONFIG_MAX_BYTES];
    int length = xw_config_format(&browser_config, contents, sizeof(contents));
    FILE *file;
    if (length < 0) {
        (void)snprintf(ui_message, sizeof(ui_message), "configuracao invalida; revise IP/DNS/homepage");
        return -1;
    }
    file = fopen("X360WebTotal/config/browser.ini", "wb");
    if (file == NULL) {
        (void)snprintf(ui_message, sizeof(ui_message), "nao foi possivel gravar browser.ini no USB");
        return -1;
    }
    {
        size_t written = fwrite(contents, 1u, (size_t)length, file);
        int close_result = fclose(file);
        if (written != (size_t)length || close_result != 0) {
            (void)snprintf(ui_message, sizeof(ui_message), "falha ao salvar configuracao no USB");
            return -1;
        }
    }
    (void)xw_dns_set_servers(browser_config.dns_primary, browser_config.dns_secondary);
    (void)snprintf(address, sizeof(address), "%s", browser_config.homepage);
    (void)snprintf(ui_message, sizeof(ui_message), "config salva; rede/IP aplicados ao reiniciar o X360 Web Total");
    return 0;
}

static int apply_static_network_config(void)
{
    ip_addr_t ip, mask, gateway;
    if (ipaddr_aton(browser_config.static_ip, &ip) == 0 ||
        ipaddr_aton(browser_config.netmask, &mask) == 0 ||
        ipaddr_aton(browser_config.gateway, &gateway) == 0)
        return -1;
    dhcp_stop(&netif);
    netif_set_addr(&netif, &ip, &mask, &gateway);
    netif_set_up(&netif);
    return 0;
}

static const char *setting_value(unsigned item)
{
    switch (item) {
        case 0: return browser_config.network_mode;
        case 1: return browser_config.static_ip;
        case 2: return browser_config.netmask;
        case 3: return browser_config.gateway;
        case 4: return browser_config.dns_primary;
        case 5: return browser_config.dns_secondary;
        case 6: return browser_config.homepage;
        case 7: {
            static char port_text[8];
            (void)snprintf(port_text, sizeof(port_text), "%u", browser_config.controller_port + 1u);
            return port_text;
        }
        default: return "";
    }
}

static const char *setting_name(unsigned item)
{
    static const char *names[] = {
        "Modo de rede", "Endereco IP", "Mascara de sub-rede", "Gateway",
        "DNS primario", "DNS secundario", "Pagina inicial", "Porta do controle",
        "Salvar configuracoes", "Voltar para Home"
    };
    return item < sizeof(names) / sizeof(names[0]) ? names[item] : "";
}

static void draw_home(void)
{
    console_set_colors(CONSOLE_COLOR_BLACK, CONSOLE_COLOR_WHITE);
    console_clrscr();
    printf("X360 WEB TOTAL  |  HOME  |  DVDBRN\n");
    printf("================================================================\n\n");
    printf("NAVEGADOR\n");
    printf("Endereco: %.180s\n", address);
    printf("D-pad: teclado | A: inserir | X: apagar | START: abrir\n\n");
    printf("TECLADO VIRTUAL\n");
    for (unsigned r = 0; r < KEY_ROWS; ++r) {
        for (unsigned c = 0; c < KEY_COLS; ++c) {
            if (r == key_row && c == key_col) {
                console_set_colors(CONSOLE_COLOR_BLUE, CONSOLE_COLOR_WHITE);
                printf("[%c]", keyboard[r][c] == ' ' ? '_' : keyboard[r][c]);
                console_set_colors(CONSOLE_COLOR_BLACK, CONSOLE_COLOR_WHITE);
            } else printf(" %c ", keyboard[r][c] == ' ' ? '_' : keyboard[r][c]);
        }
        putchar('\n');
    }
    printf("\nREDE: %s | Modo: %s | IP: %s\n",
           (network_ready && network_link_up()) ? "LINK ATIVO" : "SEM LINK",
           browser_config.network_mode,
           (network_ready && netif.ip_addr.addr != 0) ? ipaddr_ntoa(&netif.ip_addr) : "0.0.0.0");
    printf("HTTP/1.x + DNS configuravel | HTTPS/TLS ainda nao integrado\n");
    printf("Y: CONFIGURACOES | BACK: encerrar\n");
    if (ui_message[0]) printf("\n%s\n", ui_message);
}

static void draw_settings(void)
{
    console_set_colors(CONSOLE_COLOR_BLACK, CONSOLE_COLOR_WHITE);
    console_clrscr();
    printf("X360 WEB TOTAL  |  CONFIGURACOES\n");
    printf("================================================================\n");
    printf("REDE E CONTROLE  |  alteracoes salvas no USB\n\n");
    for (unsigned i = 0; i < 10u; ++i) {
        if (i == settings_item) console_set_colors(CONSOLE_COLOR_BLUE, CONSOLE_COLOR_WHITE);
        printf("%c %-25s", i == settings_item ? '>' : ' ', setting_name(i));
        if (i < 8u) printf(" : %s", setting_value(i));
        putchar('\n');
        console_set_colors(CONSOLE_COLOR_BLACK, CONSOLE_COLOR_WHITE);
    }
    printf("\nControles: D-pad selecionar | A editar/alternar | B voltar\n");
    printf("START no editor confirma | X apaga caractere\n");
    printf("Rede: %s | O modo/IP sera aplicado ao reiniciar o aplicativo.\n",
           network_ready ? "interface inicializada" : "sem link");
    if (ui_message[0]) printf("\n%s\n", ui_message);
}

static int edit_is_numeric(void)
{
    return edit_field >= 1 && edit_field <= 5;
}

static void begin_setting_edit(unsigned field)
{
    const char *value = setting_value(field);
    edit_field = (int)field;
    (void)snprintf(edit_value, sizeof(edit_value), "%s", value);
    edit_key_row = 0u;
    edit_key_col = 0u;
    screen = SCREEN_EDIT;
}

static void draw_editor(void)
{
    console_set_colors(CONSOLE_COLOR_BLACK, CONSOLE_COLOR_WHITE);
    console_clrscr();
    printf("X360 WEB TOTAL  |  EDITAR: %s\n", setting_name((unsigned)edit_field));
    printf("================================================================\n\n");
    printf("Valor: %s_\n\n", edit_value);
    for (unsigned r = 0; r < KEY_ROWS; ++r) {
        for (unsigned c = 0; c < KEY_COLS; ++c) {
            char ch = keyboard[r][c];
            if (edit_is_numeric() && !((ch >= '0' && ch <= '9') || ch == '.')) ch = ' ';
            if (r == edit_key_row && c == edit_key_col) {
                console_set_colors(CONSOLE_COLOR_BLUE, CONSOLE_COLOR_WHITE);
                printf("[%c]", ch == ' ' ? '_' : ch);
                console_set_colors(CONSOLE_COLOR_BLACK, CONSOLE_COLOR_WHITE);
            } else printf(" %c ", ch == ' ' ? '_' : ch);
        }
        putchar('\n');
    }
    printf("\nD-pad: escolher | A: inserir | X: apagar | START: confirmar | B: cancelar\n");
}

static void append_edit_char(char ch)
{
    size_t length = strlen(edit_value);
    if (ch == ' ' || (edit_is_numeric() && !((ch >= '0' && ch <= '9') || ch == '.'))) return;
    if (length + 1u < sizeof(edit_value)) {
        edit_value[length] = ch;
        edit_value[length + 1u] = '\0';
    }
}

static int commit_setting_edit(void)
{
    XwConfig candidate = browser_config;
    char validation[XW_CONFIG_MAX_BYTES];
    switch (edit_field) {
        case 1: (void)snprintf(candidate.static_ip,sizeof(candidate.static_ip),"%s",edit_value); break;
        case 2: (void)snprintf(candidate.netmask,sizeof(candidate.netmask),"%s",edit_value); break;
        case 3: (void)snprintf(candidate.gateway,sizeof(candidate.gateway),"%s",edit_value); break;
        case 4: (void)snprintf(candidate.dns_primary,sizeof(candidate.dns_primary),"%s",edit_value); break;
        case 5: (void)snprintf(candidate.dns_secondary,sizeof(candidate.dns_secondary),"%s",edit_value); break;
        case 6: (void)snprintf(candidate.homepage,sizeof(candidate.homepage),"%s",edit_value); break;
        default: return -1;
    }
    if (xw_config_format(&candidate, validation, sizeof(validation)) < 0) {
        (void)snprintf(ui_message,sizeof(ui_message),"valor invalido; use IPv4 ou URL HTTP valida");
        return -1;
    }
    browser_config = candidate;
    edit_field = -1;
    screen = SCREEN_SETTINGS;
    (void)snprintf(ui_message,sizeof(ui_message),"campo atualizado; pressione Salvar configuracoes");
    return 0;
}

static void draw_loading(void)
{
    console_set_colors(CONSOLE_COLOR_BLACK, CONSOLE_COLOR_WHITE);
    console_clrscr();
    printf("X360 WEB TOTAL\n");
    printf("Conectando a: %s\n\n", address);
    switch (xw_http_state()) {
        case XW_HTTP_RESOLVING: printf("Resolvendo DNS...\n"); break;
        case XW_HTTP_CONNECTING: printf("Abrindo conexao TCP...\n"); break;
        case XW_HTTP_RECEIVING: printf("Recebendo resposta HTTP...\n"); break;
        default: printf("Preparando requisicao...\n"); break;
    }
    printf("B: cancelar | BACK: sair\n");
}

static int link_block_at(unsigned ordinal, unsigned *block_index)
{
    unsigned found = 0;
    for (size_t i = 0; i < current_document.block_count; ++i) {
        const XwHtmlBlock *block = &current_document.blocks[i];
        if (block->type == XW_BLOCK_LINK && block->href[0] != '\0') {
            if (found == ordinal) {
                if (block_index != NULL) *block_index = (unsigned)i;
                return 1;
            }
            ++found;
        }
    }
    return 0;
}

static unsigned link_count(void)
{
    unsigned count = 0;
    for (size_t i = 0; i < current_document.block_count; ++i)
        if (current_document.blocks[i].type == XW_BLOCK_LINK && current_document.blocks[i].href[0] != '\0') ++count;
    return count;
}

static void draw_document(void)
{
    unsigned width = 64, height = 32, selected_block = 0;
    size_t visible, end;
    int has_selected = link_block_at(selected_link_index, &selected_block);
    console_get_dimensions(&width, &height);
    if (width < 32 || width > 110) width = 64;
    visible = height > 8 ? (size_t)height - 8u : 1u;
    if (page_scroll > current_layout.line_count) page_scroll = current_layout.line_count;
    end = page_scroll + visible;
    if (end > current_layout.line_count) end = current_layout.line_count;
    console_set_colors(CONSOLE_COLOR_BLACK, CONSOLE_COLOR_WHITE);
    console_clrscr();
    printf("X360 WEB TOTAL  |  HTTP %d\n", current_http_status);
    printf("URL: %.180s\n", address);
    printf("================================================================\n");
    if (current_document.title[0]) printf("Pagina: %.150s\n", current_document.title);
    for (size_t i = page_scroll; i < end; ++i) {
        const XwVisualLine *line = &current_layout.lines[i];
        int active = has_selected && line->source_block == selected_block && line->is_link;
        if (active) console_set_colors(CONSOLE_COLOR_BLUE, CONSOLE_COLOR_WHITE);
        else if (line->is_link) console_set_colors(CONSOLE_COLOR_BLACK, CONSOLE_COLOR_GREEN);
        if (active) printf("> "); else printf("  ");
        for (unsigned spaces = 0; spaces < line->indent; ++spaces) putchar(' ');
        puts(line->text);
        console_set_colors(CONSOLE_COLOR_BLACK, CONSOLE_COLOR_WHITE);
    }
    if (current_document.truncated || current_layout.dropped_lines)
        printf("[Aviso: pagina limitada pela memoria desta versao]\n");
    printf("\n----------------------------------------------------------------\n");
    printf("Links: %u | Scroll: %u/%u\n", link_count(), (unsigned)page_scroll,
           (unsigned)(current_layout.line_count > visible ? current_layout.line_count - visible : 0));
    printf("UP/DOWN: rolar | LEFT/RIGHT: link | A: abrir | X: voltar | B: inicio\n");
}

static void draw_error(const char *message)
{
    console_set_colors(CONSOLE_COLOR_BLACK, CONSOLE_COLOR_ORANGE);
    console_clrscr();
    printf("X360 WEB TOTAL - FALHA DE NAVEGACAO\n\n");
    printf("URL: %s\n", address);
    printf("Erro: %s\n\n", message ? message : "erro desconhecido");
    printf("B: voltar ao inicio | BACK: sair\n");
    console_set_colors(CONSOLE_COLOR_BLACK, CONSOLE_COLOR_WHITE);
}

static void history_push(const char *url)
{
    if (history_count != 0 && strcmp(history[history_position], url) == 0) return;
    if (history_count != 0 && history_position + 1u < history_count) history_count = history_position + 1u;
    if (history_count >= browser_config.history_entries) {
        unsigned limit = browser_config.history_entries;
        if (limit > HISTORY_MAX) limit = HISTORY_MAX;
        memmove(history, history + 1, sizeof(history[0]) * (limit - 1u));
        history_count = limit - 1u;
        if (history_position != 0) --history_position;
    }
    (void)snprintf(history[history_count], sizeof(history[history_count]), "%s", url);
    history_position = history_count;
    ++history_count;
}

static void start_navigation(int record_history)
{
    int result;
    if (record_history) history_push(address);
    redirect_count = 0;
    result = xw_http_start(address);
    if (result != 0) {
        (void)snprintf(ui_message, sizeof(ui_message), "%s", xw_http_error());
        screen = SCREEN_ERROR;
        draw_error(ui_message);
        return;
    }
    screen = SCREEN_LOADING;
    loading_frames = 0;
    draw_loading();
}

static void navigate_to(const char *target, int add_history)
{
    if (target == NULL || strlen(target) >= sizeof(address)) {
        (void)snprintf(ui_message, sizeof(ui_message), "endereco de destino muito longo");
        screen = SCREEN_ERROR;
        draw_error(ui_message);
        return;
    }
    (void)snprintf(address, sizeof(address), "%s", target);
    start_navigation(add_history);
}

static void open_selected_link(void)
{
    unsigned block_index;
    XwUrl base;
    char target[XW_URL_INPUT_MAX + 8];
    char error[96];
    if (!link_block_at(selected_link_index, &block_index)) {
        (void)snprintf(ui_message, sizeof(ui_message), "esta pagina nao possui link selecionavel");
        return;
    }
    if (xw_url_parse(address, &base, error, sizeof(error)) != 0 ||
        xw_url_resolve(&base, current_document.blocks[block_index].href, target, sizeof(target)) != 0) {
        (void)snprintf(ui_message, sizeof(ui_message), "link nao suportado ou endereco relativo invalido");
        screen = SCREEN_ERROR;
        draw_error(ui_message);
        return;
    }
    navigate_to(target, 1);
}

static void history_back(void)
{
    if (history_count < 2 || history_position == 0) {
        (void)snprintf(ui_message, sizeof(ui_message), "nao ha pagina anterior no historico");
        draw_document();
        return;
    }
    --history_position;
    navigate_to(history[history_position], 0);
}

static void finish_navigation(void)
{
    const unsigned char *body = NULL;
    size_t body_length = 0;
    const char *location;
    if (xw_http_result(&body, &body_length, &current_http_status) != 0) {
        screen = SCREEN_ERROR;
        (void)snprintf(ui_message, sizeof(ui_message), "%s", xw_http_error());
        draw_error(ui_message);
        return;
    }
    if (current_http_status == 301 || current_http_status == 302 || current_http_status == 303 ||
        current_http_status == 307 || current_http_status == 308) {
        char target[XW_URL_INPUT_MAX + 8];
        XwUrl base;
        char error[96];
        location = xw_http_location();
        if (location == NULL || location[0] == '\0' || redirect_count >= 5u ||
            xw_url_parse(address, &base, error, sizeof(error)) != 0 ||
            xw_url_resolve(&base, location, target, sizeof(target)) != 0) {
            screen = SCREEN_ERROR;
            (void)snprintf(ui_message, sizeof(ui_message), "redirecionamento HTTP ausente, invalido ou acima do limite de 5");
            draw_error(ui_message);
            return;
        }
        ++redirect_count;
        (void)snprintf(address, sizeof(address), "%s", target);
        if (xw_http_start(address) != 0) {
            screen = SCREEN_ERROR;
            (void)snprintf(ui_message, sizeof(ui_message), "%s", xw_http_error());
            draw_error(ui_message);
            return;
        }
        screen = SCREEN_LOADING;
        loading_frames = 0;
        draw_loading();
        return;
    }
    if (current_http_status < 200 || current_http_status >= 300) {
        screen = SCREEN_ERROR;
        (void)snprintf(ui_message, sizeof(ui_message), "servidor respondeu HTTP %d", current_http_status);
        draw_error(ui_message);
        return;
    }
    if (xw_html_parse((const char *)body, body_length, &current_document) != 0 ||
        xw_layout_build(&current_document, 68, &current_layout) != 0) {
        screen = SCREEN_ERROR;
        draw_error("nao foi possivel interpretar a pagina");
        return;
    }
    selected_link_index = 0;
    page_scroll = 0;
    screen = SCREEN_PAGE;
    draw_document();
}

static void append_key(char c)
{
    size_t n = strlen(address);
    if (n + 1 < sizeof(address) && c != ' ') {
        address[n] = c;
        address[n + 1] = '\0';
    }
}

int main(void)
{
    struct controller_data_s pad, previous;
    int net_result;
    memset(&pad, 0, sizeof(pad));
    memset(&previous, 0, sizeof(previous));
    xenos_init(VIDEO_MODE_AUTO);
    console_set_colors(CONSOLE_COLOR_BLACK, CONSOLE_COLOR_WHITE);
    console_init();
    console_clrscr();
    printf("X360 Web Total 0.4.0: preparando ambiente...\n");
    xenon_make_it_faster(XENON_SPEED_FULL);

    printf("Inicializando USB...\n");
    (void)usb_init();
    for (int i = 0; i < 10; ++i) { usb_do_poll(); mdelay(25); }
    printf("Montando armazenamento...\n");
    (void)xenon_ata_init();
    if (!fatInitDefault()) printf("Aviso: FAT nao foi montado pelo libfat.\n");
    load_browser_config();

    printf("Inicializando rede...\n");
    net_result = network_init();
    network_ready = (net_result == NETWORK_INIT_SUCCESS) ||
                    (net_result == NETWORK_INIT_DHCP_FAILURE && network_link_up());
    if (network_ready && (strcmp(browser_config.network_mode, "static") == 0 ||
                          net_result == NETWORK_INIT_DHCP_FAILURE)) {
        if (apply_static_network_config() != 0) network_ready = 0;
    }
    if (net_result == NETWORK_INIT_SUCCESS && strcmp(browser_config.network_mode,"dhcp") == 0)
        network_print_config();
    else if (network_ready) printf("Rede pronta; modo %s configurado.\n", browser_config.network_mode);
    else printf("Rede indisponivel; confira cabo, roteador e configuracao.\n");

    screen = SCREEN_HOME;
    (void)snprintf(ui_message, sizeof(ui_message), "Y abre configuracoes; START abre a homepage; controle na porta %u", browser_config.controller_port + 1u);
    draw_home();

    for (;;) {
        int got_pad;
        /* LibXenon requires USB polling continuously; the old build polled only at boot. */
        usb_do_poll();
        network_poll();
        network_ready = network_link_up() && netif.ip_addr.addr != 0;
        xw_http_poll();
        got_pad = get_controller_data(&pad, (int)browser_config.controller_port);
        /* 0 means no fresh HID report. Do not process stale button state as a new event. */
        if (got_pad > 0) {
            int pressed_a = pad.a && !previous.a;
            int pressed_b = pad.b && !previous.b;
            int pressed_x = pad.x && !previous.x;
            int pressed_y = pad.y && !previous.y;
            int pressed_start = pad.start && !previous.start;
            int pressed_back = pad.back && !previous.back;
            int pressed_up = pad.up && !previous.up;
            int pressed_down = pad.down && !previous.down;
            int pressed_left = pad.left && !previous.left;
            int pressed_right = pad.right && !previous.right;

            if (pressed_back) {
                xw_http_cancel();
                break;
            }
            if (screen == SCREEN_HOME) {
                if (pressed_y) { screen = SCREEN_SETTINGS; settings_item = 0u; draw_settings(); }
                else {
                    if (pressed_up) key_row = (key_row + KEY_ROWS - 1u) % KEY_ROWS;
                    if (pressed_down) key_row = (key_row + 1u) % KEY_ROWS;
                    if (pressed_left) key_col = (key_col + KEY_COLS - 1u) % KEY_COLS;
                    if (pressed_right) key_col = (key_col + 1u) % KEY_COLS;
                    if (pressed_a) append_key(keyboard[key_row][key_col]);
                    if (pressed_x) { size_t n = strlen(address); if (n) address[n - 1u] = '\0'; }
                    if (pressed_start) start_navigation(1);
                    if (pressed_a || pressed_x || pressed_up || pressed_down || pressed_left || pressed_right) draw_home();
                }
            } else if (screen == SCREEN_SETTINGS) {
                if (pressed_b || pressed_y) { screen = SCREEN_HOME; draw_home(); }
                else if (pressed_up) { settings_item = (settings_item + 9u) % 10u; draw_settings(); }
                else if (pressed_down) { settings_item = (settings_item + 1u) % 10u; draw_settings(); }
                else if (pressed_a) {
                    if (settings_item == 0u) {
                        (void)snprintf(browser_config.network_mode,sizeof(browser_config.network_mode),"%s",
                            strcmp(browser_config.network_mode,"dhcp")==0 ? "static" : "dhcp");
                        draw_settings();
                    } else if (settings_item >= 1u && settings_item <= 6u) {
                        begin_setting_edit(settings_item); draw_editor();
                    } else if (settings_item == 7u) {
                        browser_config.controller_port = (browser_config.controller_port + 1u) % 4u;
                        draw_settings();
                    } else if (settings_item == 8u) {
                        (void)save_browser_config(); draw_settings();
                    } else if (settings_item == 9u) { screen = SCREEN_HOME; draw_home(); }
                }
            } else if (screen == SCREEN_EDIT) {
                if (pressed_b) { screen = SCREEN_SETTINGS; edit_field = -1; draw_settings(); }
                else if (pressed_up) { edit_key_row = (edit_key_row + KEY_ROWS - 1u) % KEY_ROWS; draw_editor(); }
                else if (pressed_down) { edit_key_row = (edit_key_row + 1u) % KEY_ROWS; draw_editor(); }
                else if (pressed_left) { edit_key_col = (edit_key_col + KEY_COLS - 1u) % KEY_COLS; draw_editor(); }
                else if (pressed_right) { edit_key_col = (edit_key_col + 1u) % KEY_COLS; draw_editor(); }
                else if (pressed_a) { append_edit_char(keyboard[edit_key_row][edit_key_col]); draw_editor(); }
                else if (pressed_x) { size_t n=strlen(edit_value); if(n) edit_value[n-1u]='\0'; draw_editor(); }
                else if (pressed_start) {
                    if (commit_setting_edit() == 0) draw_settings();
                    else draw_editor();
                }
            } else if (screen == SCREEN_LOADING) {
                if (pressed_b) { xw_http_cancel(); screen = SCREEN_HOME; draw_home(); }
            } else if (screen == SCREEN_PAGE) {
                unsigned links = link_count();
                if (pressed_y) { screen = SCREEN_SETTINGS; settings_item = 0u; draw_settings(); }
                else if (pressed_b) { xw_http_cancel(); screen = SCREEN_HOME; draw_home(); }
                else if (pressed_x) history_back();
                else if (pressed_start) navigate_to(address, 0);
                else if (pressed_left && links) { selected_link_index = (selected_link_index + links - 1u) % links; draw_document(); }
                else if (pressed_right && links) { selected_link_index = (selected_link_index + 1u) % links; draw_document(); }
                else if (pressed_a) open_selected_link();
                else if (pressed_up && page_scroll > 0u) { --page_scroll; draw_document(); }
                else if (pressed_down && page_scroll + 1u < current_layout.line_count) { ++page_scroll; draw_document(); }
            } else if (screen == SCREEN_ERROR) {
                if (pressed_y) { screen = SCREEN_SETTINGS; settings_item = 0u; draw_settings(); }
                else if (pressed_b) { xw_http_cancel(); screen = SCREEN_HOME; draw_home(); }
                else if (pressed_x) history_back();
                else if (pressed_start) start_navigation(0);
            }
            previous = pad;
        }

        if (screen == SCREEN_LOADING) {
            if (xw_http_state() == XW_HTTP_DONE) finish_navigation();
            else if (xw_http_state() == XW_HTTP_FAILED) {
                screen = SCREEN_ERROR;
                (void)snprintf(ui_message, sizeof(ui_message), "%s", xw_http_error());
                draw_error(ui_message);
            } else {
                ++loading_frames;
                if (loading_frames > 1800u) {
                    xw_http_cancel(); screen = SCREEN_ERROR;
                    (void)snprintf(ui_message, sizeof(ui_message), "tempo limite: DNS/TCP nao respondeu em 30 segundos");
                    draw_error(ui_message);
                } else if ((loading_frames % 60u) == 0u) draw_loading();
            }
        }
        mdelay(16);
    }

    console_set_colors(CONSOLE_COLOR_BLACK, CONSOLE_COLOR_WHITE);
    console_clrscr();
    printf("X360 Web Total encerrado.\n");
    return 0;
}
