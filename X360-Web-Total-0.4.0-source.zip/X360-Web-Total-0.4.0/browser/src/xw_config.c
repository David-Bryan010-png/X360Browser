#include "xw_config.h"

#include <ctype.h>
#include <stdio.h>
#include <string.h>

static int config_error(char *error, size_t capacity, const char *message)
{
    if (error != NULL && capacity != 0u) (void)snprintf(error, capacity, "%s", message);
    return -1;
}

static int key_equals(const char *text, size_t length, const char *expected)
{
    size_t i;
    if (strlen(expected) != length) return 0;
    for (i = 0; i < length; ++i)
        if (tolower((unsigned char)text[i]) != tolower((unsigned char)expected[i])) return 0;
    return 1;
}

static void trim_bounds(const char *data, size_t *begin, size_t *end)
{
    while (*begin < *end && isspace((unsigned char)data[*begin])) ++*begin;
    while (*end > *begin && isspace((unsigned char)data[*end - 1u])) --*end;
}

int xw_config_valid_ipv4(const char *text)
{
    unsigned part = 0, digits = 0, count = 0;
    const unsigned char *p = (const unsigned char *)text;
    if (text == NULL || *text == '\0') return 0;
    while (*p != '\0') {
        if (*p >= '0' && *p <= '9') {
            part = part * 10u + (unsigned)(*p - '0');
            if (part > 255u || ++digits > 3u) return 0;
        } else if (*p == '.') {
            if (digits == 0u || ++count > 3u) return 0;
            part = 0; digits = 0;
        } else return 0;
        ++p;
    }
    return count == 3u && digits != 0u;
}

void xw_config_defaults(XwConfig *config)
{
    if (config == NULL) return;
    memset(config, 0, sizeof(*config));
    (void)snprintf(config->homepage, sizeof(config->homepage), "%s", "http://neverssl.com/");
    (void)snprintf(config->network_mode, sizeof(config->network_mode), "%s", "dhcp");
    (void)snprintf(config->static_ip, sizeof(config->static_ip), "%s", "192.168.1.99");
    (void)snprintf(config->netmask, sizeof(config->netmask), "%s", "255.255.255.0");
    (void)snprintf(config->gateway, sizeof(config->gateway), "%s", "192.168.1.1");
    (void)snprintf(config->dns_primary, sizeof(config->dns_primary), "%s", "1.1.1.1");
    (void)snprintf(config->dns_secondary, sizeof(config->dns_secondary), "%s", "8.8.8.8");
    config->controller_port = 0u;
    config->history_entries = 16u;
}

static int copy_value(char *destination, size_t capacity, const char *data,
                      size_t begin, size_t end, const char *error_text,
                      char *error, size_t error_capacity)
{
    size_t length = end - begin;
    if (length == 0u || length >= capacity || memchr(data + begin, '\0', length) != NULL)
        return config_error(error, error_capacity, error_text);
    memcpy(destination, data + begin, length);
    destination[length] = '\0';
    return 0;
}

int xw_config_parse(const char *data, size_t length, XwConfig *config,
                    char *error, size_t error_capacity)
{
    XwConfig candidate;
    unsigned seen = 0u;
    size_t position = 0u;
    if (data == NULL || config == NULL) return config_error(error, error_capacity, "argumento de configuracao nulo");
    if (length > XW_CONFIG_MAX_BYTES) return config_error(error, error_capacity, "arquivo INI excede 4096 bytes");
    candidate = *config;

    while (position < length) {
        size_t line_start = position, line_end, begin, end, equals;
        unsigned bit = 0u;
        char *target = NULL;
        size_t target_size = 0u;
        while (position < length && data[position] != '\n') ++position;
        line_end = position;
        if (position < length) ++position;
        begin = line_start; end = line_end;
        trim_bounds(data, &begin, &end);
        if (begin == end || data[begin] == '#' || data[begin] == ';') continue;
        for (equals = begin; equals < end && data[equals] != '='; ++equals) { }
        if (equals == end) return config_error(error, error_capacity, "linha INI sem '='");
        {
            size_t kb = begin, ke = equals, vb = equals + 1u, ve = end;
            trim_bounds(data, &kb, &ke); trim_bounds(data, &vb, &ve);
            if (key_equals(data + kb, ke - kb, "homepage")) { bit=1u<<0; target=candidate.homepage; target_size=sizeof(candidate.homepage); }
            else if (key_equals(data + kb, ke - kb, "network_mode")) { bit=1u<<1; target=candidate.network_mode; target_size=sizeof(candidate.network_mode); }
            else if (key_equals(data + kb, ke - kb, "static_ip")) { bit=1u<<2; target=candidate.static_ip; target_size=sizeof(candidate.static_ip); }
            else if (key_equals(data + kb, ke - kb, "netmask")) { bit=1u<<3; target=candidate.netmask; target_size=sizeof(candidate.netmask); }
            else if (key_equals(data + kb, ke - kb, "gateway")) { bit=1u<<4; target=candidate.gateway; target_size=sizeof(candidate.gateway); }
            else if (key_equals(data + kb, ke - kb, "dns_primary")) { bit=1u<<5; target=candidate.dns_primary; target_size=sizeof(candidate.dns_primary); }
            else if (key_equals(data + kb, ke - kb, "dns_secondary")) { bit=1u<<6; target=candidate.dns_secondary; target_size=sizeof(candidate.dns_secondary); }
            else if (key_equals(data + kb, ke - kb, "controller_port")) {
                unsigned value = 0u;
                if (vb == ve) return config_error(error, error_capacity, "controller_port vazio");
                for (size_t i=vb; i<ve; ++i) {
                    if (data[i]<'0' || data[i]>'9') return config_error(error,error_capacity,"controller_port invalido");
                    value=value*10u+(unsigned)(data[i]-'0');
                    if (value>3u) return config_error(error,error_capacity,"controller_port deve ser 0..3");
                }
                bit=1u<<7; candidate.controller_port=value;
            } else if (key_equals(data + kb, ke - kb, "history_entries")) {
                unsigned value = 0u;
                if (vb == ve) return config_error(error,error_capacity,"history_entries vazio");
                for (size_t i=vb; i<ve; ++i) {
                    if (data[i]<'0' || data[i]>'9') return config_error(error,error_capacity,"history_entries invalido");
                    value=value*10u+(unsigned)(data[i]-'0');
                }
                if (value!=8u && value!=16u && value!=24u) return config_error(error,error_capacity,"history_entries deve ser 8, 16 ou 24");
                bit=1u<<8; candidate.history_entries=value;
            } else continue; /* unknown keys remain forward-compatible */
            if ((seen & bit) != 0u) return config_error(error, error_capacity, "chave duplicada no INI");
            seen |= bit;
            if (target != NULL && copy_value(target,target_size,data,vb,ve,"valor vazio, longo ou com NUL",error,error_capacity)!=0) return -1;
        }
    }
    if (strcmp(candidate.network_mode,"dhcp")!=0 && strcmp(candidate.network_mode,"static")!=0)
        return config_error(error,error_capacity,"network_mode deve ser dhcp ou static");
    if (!xw_config_valid_ipv4(candidate.static_ip) || !xw_config_valid_ipv4(candidate.netmask) ||
        !xw_config_valid_ipv4(candidate.gateway) || !xw_config_valid_ipv4(candidate.dns_primary) ||
        !xw_config_valid_ipv4(candidate.dns_secondary))
        return config_error(error,error_capacity,"IP, mascara, gateway e DNS devem ser IPv4 validos");
    {
        XwUrl parsed; char url_error[96];
        if (xw_url_parse(candidate.homepage,&parsed,url_error,sizeof(url_error))!=0 || parsed.tls)
            return config_error(error,error_capacity,"homepage precisa ser URL HTTP valida nesta versao");
    }
    *config=candidate;
    if(error!=NULL && error_capacity!=0u) error[0]='\0';
    return 0;
}

int xw_config_format(const XwConfig *config, char *output, size_t capacity)
{
    int length;
    if (config==NULL || output==NULL || capacity==0u ||
        (strcmp(config->network_mode,"dhcp")!=0 && strcmp(config->network_mode,"static")!=0) ||
        !xw_config_valid_ipv4(config->static_ip) || !xw_config_valid_ipv4(config->netmask) ||
        !xw_config_valid_ipv4(config->gateway) || !xw_config_valid_ipv4(config->dns_primary) ||
        !xw_config_valid_ipv4(config->dns_secondary) || config->controller_port>3u || (config->history_entries!=8u && config->history_entries!=16u && config->history_entries!=24u)) return -1;
    {
        XwUrl parsed; char error[96];
        if (xw_url_parse(config->homepage,&parsed,error,sizeof(error))!=0 || parsed.tls) return -1;
    }
    length=snprintf(output,capacity,
        "# X360 Web Total - configuracao persistente\nversion=0.4.0\n"
        "homepage=%s\nnetwork_mode=%s\nstatic_ip=%s\nnetmask=%s\n"
        "gateway=%s\ndns_primary=%s\ndns_secondary=%s\ncontroller_port=%u\nhistory_entries=%u\n",
        config->homepage,config->network_mode,config->static_ip,config->netmask,
        config->gateway,config->dns_primary,config->dns_secondary,config->controller_port,config->history_entries);
    return length<0 || (size_t)length>=capacity ? -1 : length;
}
