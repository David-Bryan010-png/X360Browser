X360 WEB TOTAL 0.4.0 - GUIA DE INSTALACAO
Projeto: DVDBRN

1. Extraia TODO o conteudo do arquivo X360-Web-Total-USB.zip diretamente na raiz de um pendrive FAT32.
2. O arquivo xenon.elf e o XellLaunch2.xex devem ficar na raiz do USB.
3. Conecte o USB ao Xbox 360 RGH/JTAG.
4. Pela dashboard homebrew, execute XellLaunch2.xex.
5. O launcher chama XeLL Reloaded; o XeLL procura/carrega xenon.elf.

CONFIGURACAO
O ELF le X360WebTotal/config/browser.ini. Esse arquivo guarda modo DHCP/IP estatico, IP, mascara, gateway, DNS, homepage e porta do controle.
DHCP e o modo recomendado. Para IP manual, informe valores compativeis com a rede do roteador.
O menu nativo abre com Y. A salva/abre, B volta, D-pad seleciona. Use a opcao Salvar configuracoes para gravar no USB; reinicie o aplicativo para aplicar uma mudanca de modo/IP.

INTERFACE HTML
X360WebTotal/ui/home.html e uma pre-visualizacao/configurador para navegador moderno no celular/PC. Ela permite ajustar os campos e exportar browser.ini.
A pagina HTML NAO e renderizada pelo ELF atual: o runtime ainda nao tem CSS/JavaScript. O ELF usa uma interface nativa textual e le as mesmas configuracoes do INI.

CONTROLE
O USB e consultado continuamente pelo loop (usb_do_poll); o programa so trata botoes quando ha um novo relatorio HID. A porta padrao e 1. A porta pode ser escolhida nas configuracoes e gravada em browser.ini.

LIMITES
HTTP/1.x, DNS UDP e HTML textual limitado. HTTPS/TLS, CSS, JavaScript, renderizacao de imagens de sites e video ainda nao existem nesta versao.
O pacote nao atualiza NAND. Nao grave nem atualize NAND por causa deste aplicativo.
