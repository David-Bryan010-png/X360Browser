X360 WEB TOTAL 0.13.0 — XENON LINUX DESKTOP
Criador/referência: DVDBRN

REQUISITOS
- Xbox 360 com XeLL Reloaded em instalação RGH/JTAG compatível.
- Unidade USB FAT32.
- Ethernet integrada para teste inicial recomendado.
- Para Wi-Fi, dongle USB com chipset/firmware compatíveis.
- Controle Xbox USB ou teclado USB.

INSTALACAO
1. Extraia o pacote X360-Web-Total-0.13.0-Xenon-Linux-USB.zip para a raiz do USB FAT32.
2. Confirme kboot.conf na raiz.
3. Confirme X360WebTotal/Linux/zImage.xenon e rootfs.cpio.gz.
4. Conecte o USB e inicie XeLL Reloaded.
5. Escolha xwt_linux_usb no menu XeLL (o kboot.conf usa o marcador exigido pelo XeLL e uma entrada entre aspas).
6. O Linux inicia e abre o desktop gráfico XWT.

DESKTOP
- Navegador: NetSurf SDL/framebuffer.
- Wi-Fi: procurar redes, selecionar SSID, informar senha, conectar e esquecer perfil.
- Internet: diagnóstico real de IP, rota, DNS, relógio e HTTPS validado.
- Arquivos: navegação pelo USB e diretórios Linux; HTML abre no navegador e texto no less.
- Sistema: memória, uptime e estado de rede.
- Terminal: shell Linux de manutenção.
- Áudio: lista dispositivos ALSA e abre mixer quando disponível.
- Energia: reiniciar ou desligar.

CONTROLE
O D-pad navega. A/Enter seleciona. B/Esc volta. Também é possível usar teclado USB.

WI-FI
O Xbox 360 não ganha Wi-Fi apenas por software. Use dongle USB com chipset compatível com um driver e firmware incluídos. Modelos com mesmo nome comercial podem usar chipsets diferentes.

LIMITES
NetSurf é leve e não equivale ao Chromium. YouTube moderno, DRM, WebAssembly e vídeo HTML5 não são garantidos. O desktop não é um PC moderno completo; é uma base Linux modular sob as limitações do Xenon e dos drivers experimentais.

SEGURANCA
O pacote é carregado por XeLL para a memória. Não flashea NAND, KV, SMC ou firmware. Não renomeie nenhum arquivo para updflash.bin. Teste em hardware por sua conta e mantenha um método de recuperação funcional.
