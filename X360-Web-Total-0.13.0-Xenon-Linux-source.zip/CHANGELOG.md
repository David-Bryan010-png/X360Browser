# Changelog — X360 Web Total

## 0.13.0 — Xenon Linux Desktop

- Introduz desktop gráfico nativo SDL 1.2 + SDL_ttf no framebuffer; a interface principal não é HTML.
- Mantém o NetSurf como aplicação separada e abre outros utilitários em processos independentes.
- Adiciona explorador de arquivos, painel de sistema, terminal, diagnósticos de áudio e ações de energia.
- Acrescenta DejaVu Sans, SDL_ttf, ferramentas `nano`/`less` e ALSA utilities ao Buildroot.
- Amplia suporte do kernel para teclado/mouse USB HID e áudio USB class-compliant.
- Mantém gerenciador Wi-Fi USB, diagnóstico real de Internet e armazenamento persistente no USB.
- Compila o desktop e o bridge do controle no hook post-build do Buildroot.
- Corrige o `kboot.conf` para o formato XeLL Reloaded: `#KBOOTCONFIG` na primeira linha, entrada de boot entre aspas e seleção automática do modo de vídeo.
- O empacotador agora valida o marcador, a entrada padrão, os caminhos do kernel/initramfs e o tempo de seleção do menu antes de gerar o USB.
- O desktop gráfico retorna ao menu textual de manutenção se SDL/framebuffer não iniciar.

### Limitações conhecidas

- Port Linux Xenon/Xenos é experimental e exige validação física.
- NetSurf não implementa todas as APIs web modernas; YouTube e vídeo não certificados.
- Áudio depende de driver ALSA reconhecido; o suporte HDMI/áudio interno Xenon não é afirmado.
- Wi-Fi depende do chipset exato de adaptador USB; não habilita rádio interno sem driver conhecido.
- Não há X11/Wayland nem desktop PC completo. Esta é a fundação modular.
