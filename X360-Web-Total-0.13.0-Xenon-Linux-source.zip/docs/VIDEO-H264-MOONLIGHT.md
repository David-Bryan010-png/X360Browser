# Pipeline de vídeo H.264 / Xenos — integração opcional

## O que foi adicionado nesta revisão

O projeto passa a ter um importador reproduzível para o pipeline H.264 apresentado no pedido. Ele busca os arquivos `video.c`, `gpu.c`, `video.h`, `gpu.h`, `hw.c`, `hw.h`, `audio.c`, `audio.h` e o worker `hwpthread` do Xenonlight, fixando o commit `ef26bf4dccd1f3a2ec02b712b30395763e920309`. A importação preserva a licença GPLv3 e os avisos dos shaders.

```sh
make -C browser video-backend
```

Para substituir uma cópia já importada:

```sh
./scripts/fetch_moonlight_video_backend.sh --force
```

Os arquivos ficam em `browser/video/moonlight/`. O importador não executa comandos de firmware, NAND, SMC ou bootloader; só baixa e copia código-fonte dentro dessa pasta.

## O que o pipeline realmente recebe

O código fornecido não recebe um URL de vídeo nem um arquivo MP4. `video_submit(PDECODE_UNIT du)` recebe unidades de decodificação H.264 já montadas pelo Moonlight. Depois, o FFmpeg decodifica YUV420P e o módulo apresenta o frame via Xenos GPU, CPU ou a opção experimental de matriz de cor. O complemento `audio.c` decodifica Opus multistream em estéreo de 48 kHz e envia PCM à fila DMA de áudio do Xbox 360.

Isso é um **backend de recepção/decodificação de stream Moonlight**, não um player universal da Web. Ele não demultiplexa MP4, WebM, MPEG-TS, HLS ou DASH, não interpreta `<video>` e não faz download de segmentos. O Opus incluído atende somente ao protocolo Moonlight; não implementa HTML audio, demux de trilhas de mídia nem sincronização A/V para páginas web. A saída de áudio LibXenon é estéreo, não 5.1.

## Dependências para compilar o backend completo

O código depende do ambiente que o projeto Xenonlight montou:

- LibXenon e toolchain PowerPC;
- FFmpeg 7.1 configurado só com decoder/parser H.264 e pthreads;
- `hwpthread` para os workers de slice;
- Opus 1.5.2 e driver `xenon_sound` para áudio estéreo do Moonlight;
- `moonlight-common-c` para `Limelight.h`, tipos de callback e unidades de decode;
- camada de compatibilidade de pthread/POSIX/socket sobre lwIP usada pelo Moonlight;
- Xenos e acesso ao framebuffer da LibXenon.

O Makefile do navegador não liga esses fontes por padrão. O build base continua independente e estável; o backend é fonte opcional até que todas as dependências do cliente Moonlight sejam integradas ao mesmo ELF. O simples `make -C browser video-backend` só importa e fixa o código upstream.

## Integração futura com vídeo de sites

Para transformar isso em suporte real à tag HTML `<video>`, ainda é necessário construir uma ponte separada:

1. detectar e interpretar o elemento HTML e seus atributos;
2. implementar transporte HTTP com suporte a Range/streaming e TLS;
3. incluir demuxers apropriados (MP4/fMP4, MPEG-TS, WebM, HLS/DASH conforme escopo);
4. extrair access units H.264 e encaminhá-las ao decoder;
5. integrar um demuxer de áudio, decoder adequado, mixer/DMA e sincronização A/V da página (o decoder Opus Moonlight não é uma solução genérica para isso);
6. adicionar controles de pausa, busca, volume, tempo e estados ao UI do navegador.

A configuração FFmpeg descrita no Xenonlight desativa `avformat`, rede, `swscale`, `swresample` e filtros; portanto, ela não fornece esses recursos de Web media.

## Fonte e licenças

- Xenonlight: https://github.com/roderick-neuhoff/Xenonlight
- Commit fixado: `ef26bf4dccd1f3a2ec02b712b30395763e920309`
- Licença upstream: GNU GPL v3.0; o importador copia `LICENSE` junto do código.
- `gpu.c` mantém o crédito do shader pré-compilado derivado do MPlayer `libvo/vo_xenon.c` por Ced2911, GPLv2+.

Este módulo não muda, por si só, a licença dos outros componentes. Antes de distribuir um binário que combine o módulo com o navegador, é necessário revisar a compatibilidade e cumprir os termos das licenças aplicáveis.
