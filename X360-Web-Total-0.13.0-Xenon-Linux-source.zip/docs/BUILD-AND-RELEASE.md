# Build e release Linux 0.13.0

O workflow `.github/workflows/build-x360-linux.yml` é a fonte de verdade da compilação.

1. Detecta a pasta do projeto na raiz ou dentro do ZIP fonte 0.13.0.
2. Extrai com validação de caminho e restaura o bit executável dos scripts.
3. Busca Buildroot e o port Free60 por commits fixados.
4. Configura PowerPC 970 big-endian, kernel Xenon 7.2, Xenos DRM, SIS190, USB HID/storage, Wi-Fi e áudio USB.
5. Compila NetSurf SDL, OpenSSL/libcurl/CA, SDL_ttf/DejaVu, ferramentas de rede, ALSA e utilitários.
6. O hook post-build compila o desktop SDL e o bridge gamepad para PowerPC64.
7. Verifica configuração do kernel, arquivos/permissões do CPIO, scripts, testes Python/C e limites NAND.
8. Gera o pacote USB XeLL, manifesto e hashes.
9. Publica pre-release apenas quando todas as etapas anteriores passam na branch principal.

O workflow não atualiza NAND nem bootloader. Compilação automatizada não comprova funcionamento físico de vídeo, áudio, Ethernet ou dongles Wi-Fi.
