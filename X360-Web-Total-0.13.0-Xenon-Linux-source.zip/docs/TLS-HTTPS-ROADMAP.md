# HTTPS e navegador — Linux 0.13.0

A edição principal abandona o cliente HTTP/lwIP restrito do antigo executável LibXenon e usa NetSurf 3.10 compilado pelo Buildroot. A seleção de pacote inclui libcurl com backend OpenSSL e pacote de certificados CA. Assim, o NetSurf tem um caminho real para HTTPS validado, em vez de transformar HTTPS em HTTP.

## O que ainda precisa ser confirmado no Xbox 360

- O pacote compila `libcurl`, OpenSSL e CA bundle para PowerPC 970 big-endian.
- O relógio e os certificados precisam estar corretos para validar datas das cadeias X.509.
- A resolução DNS, rota e ligação externa devem ser testadas no console com `xwt-network check`.
- Um build aprovado no GitHub não prova que cada site carregue no console.

NetSurf não é Chromium. É um browser compacto com HTML/CSS e Duktape JavaScript; páginas que exigem ECMAScript muito recente, APIs modernas, WebAssembly, DRM ou codecs proprietários podem não funcionar. O YouTube atual e vídeo HTML5 não estão certificados nesta edição.

O código legado `browser/src/xw_http_lwip.c` ainda recusa HTTPS e não é usado como browser principal na imagem Linux 0.13.0.
