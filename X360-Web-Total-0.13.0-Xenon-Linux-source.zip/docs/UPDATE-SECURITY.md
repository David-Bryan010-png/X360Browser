# Publicação, atualização e segurança — Linux 0.13.0

O workflow ativo é `.github/workflows/build-x360-linux.yml`. Ele clona Buildroot e o port Xenon Free60 em revisões fixadas, compila Linux 7.2 e rootfs, valida kernel/initramfs, cria o pacote USB e publica uma pre-release.

O sistema do console não instala atualizações automaticamente. A Release é baixada e extraída pelo usuário em USB FAT32; XeLL carrega o kernel/rootfs para RAM. Não há escrita em NAND ou firmware. Os hashes SHA-256 detectam corrupção, mas não são uma assinatura. Antes de qualquer atualizador embutido, seria necessário assinar manifestos e verificar assinatura com chave pública incorporada.

A rede do sistema Linux usa libcurl/OpenSSL e certificados CA para HTTPS. A validação real depende de hora/certificados atualizados e será verificada no próprio console. O antigo cliente LibXenon em `browser/` continua sendo legado e não recebe a camada TLS do Linux.
