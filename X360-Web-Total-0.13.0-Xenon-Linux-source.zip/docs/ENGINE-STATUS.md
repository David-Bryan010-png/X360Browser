# Estado do X360 Web Total 0.13.0

## Sistema

- Linux 7.2 com patch Xenon/Xenos do Free60, commits fixados no workflow.
- Alvo PowerPC 970, big-endian, 64-bit userspace.
- Xenos DRM/framebuffer, console framebuffer, USB, Ethernet SIS190.
- Kernel seleciona USB HID, armazenamento, xpad/joydev/uinput, ALSA USB Audio e módulos Wi-Fi suportados.

## Desktop nativo

- Aplicação SDL 1.2 + SDL_ttf em C, iniciada pelo inittab no tty0.
- Layout verde/branco/grafite; navegação via teclado USB e controle Xbox por uinput.
- Aplicações independentes: NetSurf, Wi-Fi, diagnóstico Internet, explorador de arquivos, sistema, terminal, áudio e energia.
- Explorador abre HTML pelo NetSurf e arquivos texto pelo less usando argv sem shell interpolation.
- Fallback dialog/texto se framebuffer ou fontes SDL não iniciarem.

## Navegador

- NetSurf 3.10 SDL/framebuffer com Duktape e libcurl/OpenSSL/CA.
- Browser real, mas não Chromium. Compatibilidade com sites atuais varia.
- YouTube, DRM e vídeo HTML5 não estão certificados.

## Rede e armazenamento

- Ethernet via DHCP real sem endereço falso de fallback.
- Diagnóstico inclui link, IP, rota, DNS, relógio/NTP e HTTPS validado.
- Wi-Fi por adaptador USB, `iw`, `wpa_supplicant`, firmware e DHCP; depende do chipset exato.
- Configurações NetSurf e Wi-Fi persistem no USB FAT32; NAND não é alterada.

## Próxima arquitetura

O desktop é modular: cada aplicativo executa em processo separado. Próximas camadas possíveis: gerenciador de aplicações, bibliotecas de UI, serviços de áudio/mídia, drivers adicionais e APIs de janelas. Cada expansão deve respeitar o limite de RAM, CPU e estabilidade do port Xenon.

## Legado

O código LibXenon em `browser/` permanece no repositório como referência/testes, mas não é o sistema Linux nem o navegador principal do pacote USB.
