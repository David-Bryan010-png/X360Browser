# Fluxo de inicialização — 0.13.0 Xenon Linux Desktop

XeLL Reloaded
  → lê `kboot.conf` do USB FAT32
  → seleciona `xwt_linux_usb`
  → carrega `X360WebTotal/Linux/zImage.xenon`
  → carrega `X360WebTotal/Linux/rootfs.cpio.gz` como initramfs
  → Linux Xenon inicializa Xenos DRM/framebuffer, USB, SIS190 e dispositivos
  → BusyBox monta procfs/sysfs/devtmpfs/devpts/tmpfs e executa `mdev`
  → serviços montam USB, restauram perfil Wi-Fi e inicializam rede
  → `xwt-system-menu` inicia o desktop SDL/TTF
  → usuário abre NetSurf, Wi-Fi, arquivos, terminal, sistema ou áudio

Se a interface SDL ou as fontes não estiverem disponíveis, o wrapper inicia `xwt-system-menu-text` como modo de compatibilidade.

O kernel e rootfs são carregados temporariamente em RAM. O pacote não instala bootloader, não modifica NAND/KV/SMC e não grava firmware.
