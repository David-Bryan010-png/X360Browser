# Local URL stores

`history.dat` and `bookmarks.dat` store browser URLs only. They are not account, profile, console identity, or NAND backups.

Format:

```text
XWLIST1|<kind>|<count>|<CRC32-hex>
<URL 1>
<URL 2>
...
```

- UTF-8/ASCII-compatible URL text; one URL per line.
- Supported URL schemes are validated by the browser URL parser (`http` and `https`). This does not imply the transport supports both schemes.
- Maximum 24 rows for history and 12 for bookmarks.
- URL length maximum: 255 bytes in this revision, matching the app's address field.
- CRC32 uses the IEEE polynomial `0xEDB88320` over all URL lines, including their newline bytes.
- A verified `.tmp` is prepared before a save. The old file is rotated to `.bak`; if a later load finds the main file invalid, a valid backup may be restored.
- Empty/missing stores start as empty lists. If both primary and backup are invalid, the invalid store is ignored; settings and NAND recovery are not attempted.
