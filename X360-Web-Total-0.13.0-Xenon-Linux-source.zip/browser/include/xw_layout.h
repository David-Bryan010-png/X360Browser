#ifndef XW_LAYOUT_H
#define XW_LAYOUT_H

#include "xw_html.h"

#include <stddef.h>

typedef struct {
    char text[128];
    unsigned indent;
    unsigned source_block;
    int is_link;
} XwVisualLine;

typedef struct {
    XwVisualLine lines[768];
    size_t line_count;
    size_t dropped_lines;
} XwLayout;

int xw_layout_build(const XwHtmlDocument *document, unsigned columns, XwLayout *layout);

#endif
