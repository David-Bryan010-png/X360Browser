#ifndef XW_CONFIG_H
#define XW_CONFIG_H

#include <stddef.h>
#include "xw_url.h"

#ifdef __cplusplus
extern "C" {
#endif

#define XW_CONFIG_MAX_BYTES 4096u

typedef struct {
    char homepage[XW_URL_INPUT_MAX + 1];
    char network_mode[8];       /* dhcp or static */
    char static_ip[16];
    char netmask[16];
    char gateway[16];
    char dns_primary[16];
    char dns_secondary[16];
    unsigned controller_port;  /* LibXenon controller port 0..3 */
    unsigned history_entries;  /* 8, 16 or 24 session entries */
} XwConfig;

void xw_config_defaults(XwConfig *config);
int xw_config_parse(const char *data, size_t length, XwConfig *config,
                    char *error, size_t error_capacity);
/* Writes a normalized INI representation. Returns bytes written or -1. */
int xw_config_format(const XwConfig *config, char *output, size_t capacity);
int xw_config_valid_ipv4(const char *text);

#ifdef __cplusplus
}
#endif
#endif
