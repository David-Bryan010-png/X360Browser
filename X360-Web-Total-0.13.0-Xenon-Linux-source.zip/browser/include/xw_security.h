#ifndef XW_SECURITY_H
#define XW_SECURITY_H

/* HTTPS stays fail-closed until TLS, trusted roots, a valid clock and a
   cryptographically secure entropy provider are all available and tested. */
int xw_security_https_supported(void);
const char *xw_security_https_status(void);

#endif
