#ifndef XW_DNS_RETRY_H
#define XW_DNS_RETRY_H

#include <stdint.h>

#define XW_DNS_RETRY_INTERVAL_MS 2500u
#define XW_DNS_ATTEMPTS_PER_SERVER 3u

typedef struct {
    uint64_t last_attempt_ms;
    unsigned attempts_on_server;
    unsigned server_index;
    unsigned active;
} XwDnsRetry;

typedef enum {
    XW_DNS_RETRY_WAIT = 0,
    XW_DNS_RETRY_SEND = 1,
    XW_DNS_RETRY_SWITCH_SERVER = 2,
    XW_DNS_RETRY_FAILED = -1
} XwDnsRetryAction;

void xw_dns_retry_begin(XwDnsRetry *state, uint64_t now_ms);
XwDnsRetryAction xw_dns_retry_advance(XwDnsRetry *state, uint64_t now_ms);

#endif
