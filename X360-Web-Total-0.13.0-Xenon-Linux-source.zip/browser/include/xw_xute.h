#ifndef XW_XUTE_H
#define XW_XUTE_H

#include <stddef.h>
#include <stdint.h>

typedef enum {
    XW_XUTE_NATIVE = 0,
    XW_XUTE_TRANSLATED,
    XW_XUTE_EMULATED,
    XW_XUTE_UNSUPPORTED
} XwXuteCapability;

typedef struct {
    size_t html5_elements_translated;
    size_t scripts_detected;
    size_t inline_handlers_detected;
    size_t css_blocks_detected;
    size_t css_rules_detected;
    size_t css_declarations_detected;
    size_t css_properties_recognized;
    size_t css_at_rules_detected;
    size_t video_elements_detected;
    size_t audio_elements_detected;
    size_t canvas_elements_detected;
    size_t svg_elements_detected;
    size_t iframe_elements_detected;
    size_t image_elements_detected;
    size_t malformed_css;
    size_t bytes_processed;
    int input_truncated;
} XwXuteReport;

/*
 * In-place, bounded HTML5 compatibility pass. It rewrites selected semantic
 * tags to tags understood by the current native document parser. No expansion
 * of the input buffer occurs. CSS is analyzed but not cascaded/rendered; page
 * JavaScript is detected but deliberately never executed.
 */
int xw_xute_process_html(char *html, size_t capacity, size_t *length,
                         XwXuteReport *report);
XwXuteCapability xw_xute_capability(const char *feature);
const char *xw_xute_capability_name(XwXuteCapability capability);
int xw_xute_parse_color(const char *value, uint32_t *argb);
int xw_xute_parse_px(const char *value, int *pixels);
void xw_xute_format_report(const XwXuteReport *report, char *out, size_t capacity);

#endif
