#ifndef XW_SEARCH_H
#define XW_SEARCH_H

#include <stddef.h>

/* Converts controller-bar input into an HTTP URL or a classic-web search URL. */
int xw_search_resolve_input(const char *input, char *output, size_t capacity);

#endif
