#ifndef XW_STORE_H
#define XW_STORE_H

#include <stddef.h>

#define XW_STORE_URL_MAX 256u
#define XW_STORE_MAX_HISTORY 24u
#define XW_STORE_MAX_BOOKMARKS 12u

typedef struct {
    char items[XW_STORE_MAX_HISTORY][XW_STORE_URL_MAX];
    unsigned count;
} XwStoreList;

void xw_store_list_clear(XwStoreList *list);
/* Adds a unique URL. When full, the oldest entry is discarded. */
int xw_store_list_add(XwStoreList *list, const char *url, unsigned capacity);
int xw_store_list_remove(XwStoreList *list, unsigned index);
/* Returns 0 for primary, 1 for backup recovery, -1 for invalid/corrupt data. */
int xw_store_load(const char *path, const char *kind, XwStoreList *list);
/* Writes and verifies a temporary file, then rotates the previous file to .bak. */
int xw_store_save(const char *path, const char *kind, const XwStoreList *list);

#endif
