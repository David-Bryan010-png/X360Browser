#ifndef XW_DNS_WIRE_H
#define XW_DNS_WIRE_H

#include <stddef.h>
#include <stdint.h>

#define XW_DNS_PACKET_MAX 512u

/* Builds a bounded DNS A/IN query. Returns 0 on success. */
int xw_dns_build_query(const char *hostname, uint16_t transaction_id,
                       unsigned char *output, size_t capacity, size_t *output_length);

/* Parses only a response for the requested hostname and transaction ID.
   Returns 1 for an IPv4 answer, 0 when no A answer is present, -1 on error. */
int xw_dns_parse_a_response(const unsigned char *packet, size_t packet_length,
                            uint16_t transaction_id, const char *hostname,
                            unsigned char ipv4[4]);

#endif
