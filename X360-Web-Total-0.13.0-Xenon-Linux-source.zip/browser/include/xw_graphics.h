#ifndef XW_GRAPHICS_H
#define XW_GRAPHICS_H

#include <stddef.h>
#include <stdint.h>

typedef struct {
    uint32_t *pixels;
    uint32_t *scanout;
    unsigned width;
    unsigned height;
    unsigned owns_pixels;
} XwGraphics;

/* Memory-backed mode is used by host tests; Xenos mode binds the active display. */
int xw_gfx_init_memory(XwGraphics *gfx, unsigned width, unsigned height);
int xw_gfx_init_xenos(XwGraphics *gfx);
void xw_gfx_shutdown(XwGraphics *gfx);
void xw_gfx_clear(XwGraphics *gfx, uint32_t argb);
void xw_gfx_rect(XwGraphics *gfx, int x, int y, int width, int height, uint32_t argb);
void xw_gfx_border(XwGraphics *gfx, int x, int y, int width, int height, int thickness, uint32_t argb);
void xw_gfx_line(XwGraphics *gfx, int x0, int y0, int x1, int y1, uint32_t argb);
void xw_gfx_text(XwGraphics *gfx, int x, int y, const char *text, unsigned scale, uint32_t argb);
size_t xw_gfx_tiled_offset(unsigned padded_width, unsigned x, unsigned y);
void xw_gfx_present(XwGraphics *gfx);

#endif
