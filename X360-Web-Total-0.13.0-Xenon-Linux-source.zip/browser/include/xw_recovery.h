#ifndef XW_RECOVERY_H
#define XW_RECOVERY_H

#include <stddef.h>
#include "xw_config.h"

/* This module only protects X360 Web Total configuration files on USB.
   It contains deliberately no NAND/flash read or write operations. */
int xw_recovery_load(const char *primary_path, const char *slot_a_path,
                     const char *slot_b_path, const char *factory_path,
                     XwConfig *config, char *message, size_t message_capacity);
int xw_recovery_save(const char *primary_path, const char *slot_a_path,
                     const char *slot_b_path, const char *factory_path,
                     const XwConfig *config, char *message, size_t message_capacity);

#endif
