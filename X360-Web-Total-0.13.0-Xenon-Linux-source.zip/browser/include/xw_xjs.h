#ifndef XW_XJS_H
#define XW_XJS_H

#include <stddef.h>

typedef enum {
    XW_XJS_NUMBER = 1,
    XW_XJS_BOOLEAN = 2
} XwXjsValueType;

typedef struct {
    XwXjsValueType type;
    double number;
    int boolean;
} XwXjsValue;

/*
 * Restricted scalar-expression VM for trusted browser internals.
 * It is NOT an ECMAScript engine and must never be used to execute page scripts.
 * Grammar: numeric/boolean literals, parentheses, unary +/-/!, arithmetic,
 * comparisons, equality, && and ||. Bounded to 256 bytes and 128 tokens.
 */
int xw_xjs_eval_expression(const char *expression, XwXjsValue *result,
                           char *error, size_t error_capacity);
const char *xw_xjs_vm_status(void);

#endif
