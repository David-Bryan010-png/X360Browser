#ifndef XW_DNS_CLIENT_H
#define XW_DNS_CLIENT_H

#include <lwip/ip_addr.h>

/* Non-blocking raw-UDP resolver for LibXenon's NO_SYS lwIP build.
   start: 0 success, -1 invalid/resource error.
   poll: 0 pending, 1 resolved, -1 failed. */
int xw_dns_set_servers(const char *primary, const char *secondary);
int xw_dns_start(const char *hostname);
int xw_dns_poll(ip_addr_t *address);
void xw_dns_cancel(void);

#endif
