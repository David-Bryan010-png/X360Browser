# Local integration changes

Compared with the pinned Xenonlight sources, this copy adds defensive checks:

- video dimensions are bounded to 1920x1080 before allocations;
- nullable video/audio callback, stats, options, decoder and packet pointers are checked;
- the video mailbox slot is checked before indexing;
- packet fragments and declared frame length are validated before copying;
- partial FFmpeg and Xenos allocations are checked and cleaned up;
- the Opus path restricts the current DMA implementation to 48 kHz stereo and checks packet/sample bounds;
- the hwpthread shim validates arguments, mutex ownership, hardware-thread indices and worker allocation failures.

These changes have not yet been cross-compiled with the complete FFmpeg/Moonlight SDK combination or tested on a physical Xbox 360. Keep the upstream license and source attribution intact.
