/*
 * Opus decode + stereo playback through the Xbox 360 Xenon audio DMA ring.
 * Imported from Xenonlight; see UPSTREAM-REVISION.txt and LICENSE.
 */
#include "audio.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <opus_multistream.h>
#include <xenon_sound/sound.h>

#define MAX_FRAME_SAMPLES 960   /* 20 ms at 48 kHz */
#define MAX_QUEUED_BYTES (48000 * 4 * 60 / 1000)

static OpusMSDecoder *decoder;
static int channels;
static int16_t pcm[MAX_FRAME_SAMPLES * 2];
static uint32_t dropped_frames;

static int audio_init(int config, const POPUS_MULTISTREAM_CONFIGURATION opus,
                      void *ctx, int flags)
{
    int err;
    (void)config;
    (void)ctx;
    (void)flags;

    if (opus == NULL || opus->channelCount != 2 || opus->sampleRate != 48000 ||
        opus->streams < 1 || opus->coupledStreams < 0 ||
        opus->coupledStreams > opus->streams) {
        printf("audio: invalid or unsupported Opus stream configuration\n");
        return -1;
    }

    if (decoder != NULL) {
        opus_multistream_decoder_destroy(decoder);
        decoder = NULL;
    }
    channels = opus->channelCount;
    decoder = opus_multistream_decoder_create(opus->sampleRate, opus->channelCount,
                                              opus->streams, opus->coupledStreams,
                                              opus->mapping, &err);
    if (decoder == NULL) {
        printf("audio: Opus decoder init failed (%d)\n", err);
        return -1;
    }
    dropped_frames = 0;
    return 0;
}

static void audio_cleanup(void)
{
    if (decoder != NULL) {
        opus_multistream_decoder_destroy(decoder);
        decoder = NULL;
    }
    channels = 0;
}

static void audio_decode_and_play(char *data, int len)
{
    int samples, bytes, i;

    if (decoder == NULL || data == NULL || len <= 0 || channels != 2)
        return;

    samples = opus_multistream_decode(decoder, (const unsigned char *)data,
                                      len, pcm, MAX_FRAME_SAMPLES, 0);
    if (samples <= 0 || samples > MAX_FRAME_SAMPLES)
        return;

    bytes = samples * channels * (int)sizeof(int16_t);
    if (xenon_sound_get_unplayed() > MAX_QUEUED_BYTES ||
        xenon_sound_get_free() < bytes) {
        dropped_frames++;
        return;
    }

    for (i = 0; i < samples * channels; i++)
        pcm[i] = (int16_t)__builtin_bswap16((uint16_t)pcm[i]);

    xenon_sound_submit(pcm, bytes);
}

void audio_init_callbacks(AUDIO_RENDERER_CALLBACKS *cb)
{
    if (cb == NULL)
        return;
    LiInitializeAudioCallbacks(cb);
    cb->init = audio_init;
    cb->cleanup = audio_cleanup;
    cb->decodeAndPlaySample = audio_decode_and_play;
    cb->capabilities = CAPABILITY_DIRECT_SUBMIT;
}

bool audio_has_surround(void)
{
    return false;
}
