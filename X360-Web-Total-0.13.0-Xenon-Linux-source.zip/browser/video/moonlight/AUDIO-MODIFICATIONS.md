# Local audio safety checks

The optional stereo Opus path follows the pinned Xenonlight implementation and adds:

- validation of the callback pointer and Opus stream configuration;
- explicit 48 kHz stereo restriction, matching the fixed PCM/DMA path;
- cleanup of an earlier decoder before reinitialization;
- validation of the decoder, packet pointer, packet length and decoded sample count;
- safe no-op behavior for unsupported configurations.

This audio path is only for the Moonlight protocol. It is not connected to the browser's HTML audio element and does not add browser A/V synchronization.
