# Backend de mídia Moonlight — H.264, Xenos e Opus

Este diretório contém o backend opcional de recepção e apresentação de mídia do cliente Moonlight para Xbox 360.

## Componentes

- `video.c` / `video.h`: callbacks Limelight, fila circular de unidades H.264, FFmpeg decoder, workers de slice e mailbox de três frames.
- `gpu.c` / `gpu.h`: upload Y/U/V, shader Xenos YUV→RGB e dupla bufferização.
- `hw.c` / `hw.h`: tarefas nos hardware threads secundários e timebase PowerPC.
- `audio.c` / `audio.h`: decoder Opus multistream estéreo e saída via DMA `xenon_sound`.
- `hwpthread/`: pthreads limitados que reservam os hardware threads 3, 5 e 1 para os workers FFmpeg.

## Dependências

LibXenon e toolchain Xenon, FFmpeg com H.264 parser/decoder e pthreads, hwpthread, Opus, moonlight-common-c/Limelight, a camada POSIX/socket/lwIP compatível com Xenon, Xenos e driver de som.

A função `gpu_init()` deve ser chamada no contexto de inicialização principal depois de `console_init()` e antes de iniciar uma sessão que escolha o renderer GPU. A inicialização e os callbacks Limelight precisam ser conectados ao cliente Moonlight completo. Não chame API Xenos a partir das threads de decode; a apresentação usa o renderer em thread dedicada.

## Limites de funcionalidade

Este backend recebe unidades H.264 e pacotes Opus já organizados pelo protocolo Moonlight. Não recebe URL ou elemento DOM, não baixa vídeos de sites e não faz demux de MP4, WebM, MPEG-TS, HLS ou DASH. O áudio implementado é estéreo Moonlight; não é saída de HTML audio nem sincronização A/V de navegador.

O X360 Web Total não liga este backend ao ELF principal nesta revisão. O build padrão do navegador continua independente dessas dependências.

## Segurança, limites e teste

- Limite de dimensionamento do vídeo neste port: 1920x1080.
- A saída Opus é limitada a estéreo/48 kHz.
- A via CPU+matriz de cor é experimental; GPU Xenos é a opção padrão do backend.
- O código não acessa NAND, SMC firmware, KV, bootloader ou flash.
- Nenhum cross-build PowerPC/FFmpeg/Opus deste módulo foi confirmado nesta revisão, e não há teste físico no console associado a este pacote.

## Origem e licença

Projeto de origem: https://github.com/roderick-neuhoff/Xenonlight
Commit fixado: `ef26bf4dccd1f3a2ec02b712b30395763e920309`
Licença upstream: GPL v3.0, incluída em `LICENSE`. Os shaders pré-compilados em `gpu.c` preservam a atribuição ao port MPlayer `libvo/vo_xenon.c` de Ced2911 (GPLv2+). Consulte também `IMPORT-NOTICE.txt`, `UPSTREAM-REVISION.txt`, `MODIFICATIONS.md` e `AUDIO-MODIFICATIONS.md`.
