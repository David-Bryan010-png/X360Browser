#pragma once

#include <stdbool.h>
#include <Limelight.h>

void audio_init_callbacks(AUDIO_RENDERER_CALLBACKS *cb);

/* LibXenon audio DMA implementation currently supports stereo only. */
bool audio_has_surround(void);
