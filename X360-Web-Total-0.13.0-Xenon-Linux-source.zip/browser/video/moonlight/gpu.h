#pragma once

#include <stdbool.h>
#include <libavutil/frame.h>

bool gpu_init(void);
bool gpu_ready(void);
bool gpu_stream_begin(int width, int height);
void gpu_present(const AVFrame *frame, bool vsync);
void gpu_stream_end(void);
