#pragma once

#include <stdbool.h>
#include <stdint.h>
#include <Limelight.h>

enum video_renderer {
    RENDERER_GPU,
    RENDERER_CPU,
    RENDERER_CPU_HWCOLOR,
    RENDERER_COUNT
};

struct video_options {
    bool fast_decode;
    int renderer;
    bool vsync;
    int gpu_filter;
};

struct video_stats {
    uint32_t received, decoded, rendered, dropped, decode_errors;
    uint32_t avg_decode_us, avg_render_us;
    int display_w, display_h;
    int decode_threads;
    int renderer;
    uint32_t received_bytes;
};

const char *video_renderer_name(int renderer);
void video_set_options(const struct video_options *opts);
void video_init_callbacks(DECODER_RENDERER_CALLBACKS *cb);
void video_get_display_size(int *w, int *h);
void video_get_stats(struct video_stats *out);
bool video_has_overlay(void);
void video_set_overlay(const uint32_t *px, int w, int h);
