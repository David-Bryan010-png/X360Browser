/*
 * Helpers for work that runs on the secondary hardware threads (1-5).
 * Hardware thread 0 runs the xthread scheduler; nothing here may call
 * xthread, lwIP or moonlight-common-c functions.
 */
#pragma once

#include <stdint.h>
#include <stdbool.h>

#define HW_THREAD_DECODE 2
#define HW_THREAD_RENDER 4

bool hw_start(int hw_thread, void (*fn)(void));
bool hw_running(int hw_thread);

static inline void hw_sync(void) { __asm__ volatile("sync" ::: "memory"); }
static inline void hw_lwsync(void) { __asm__ volatile("lwsync" ::: "memory"); }
static inline void hw_relax(void) { __asm__ volatile("or 1,1,1\n\tor 2,2,2" ::: "memory"); }

uint64_t hw_now_us(void);
