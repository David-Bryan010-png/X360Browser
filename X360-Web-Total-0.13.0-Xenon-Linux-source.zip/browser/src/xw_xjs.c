#include "xw_xjs.h"

#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define XW_XJS_MAX_EXPR 256u
#define XW_XJS_MAX_TOKENS 128u
#define XW_XJS_MAX_DEPTH 32u

typedef enum {
    T_END = 0, T_NUMBER, T_TRUE, T_FALSE, T_LPAREN, T_RPAREN,
    T_PLUS, T_MINUS, T_STAR, T_SLASH, T_BANG,
    T_LT, T_GT, T_LE, T_GE, T_EQ, T_NE, T_AND, T_OR, T_BAD
} TokenType;

typedef struct {
    TokenType type;
    double number;
} Token;

typedef struct {
    const char *source;
    size_t length;
    size_t position;
    size_t token_count;
    unsigned depth;
    Token current;
    char *error;
    size_t error_capacity;
} Parser;

static void set_error(Parser *p, const char *message)
{
    if (p->error && p->error_capacity)
        (void)snprintf(p->error, p->error_capacity, "%s", message);
}

static int is_word_boundary(char c)
{
    return c == '\0' || !(isalnum((unsigned char)c) || c == '_');
}

static void next_token(Parser *p)
{
    size_t start;
    while (p->position < p->length && isspace((unsigned char)p->source[p->position]))
        ++p->position;
    if (++p->token_count > XW_XJS_MAX_TOKENS) {
        p->current.type = T_BAD;
        set_error(p, "limite de tokens excedido");
        return;
    }
    if (p->position >= p->length) { p->current.type = T_END; return; }
    start = p->position;
    switch (p->source[p->position++]) {
        case '(': p->current.type = T_LPAREN; return;
        case ')': p->current.type = T_RPAREN; return;
        case '+': p->current.type = T_PLUS; return;
        case '-': p->current.type = T_MINUS; return;
        case '*': p->current.type = T_STAR; return;
        case '/': p->current.type = T_SLASH; return;
        case '!':
            if (p->position < p->length && p->source[p->position] == '=') {
                ++p->position; p->current.type = T_NE;
            } else p->current.type = T_BANG;
            return;
        case '<':
            if (p->position < p->length && p->source[p->position] == '=') {
                ++p->position; p->current.type = T_LE;
            } else p->current.type = T_LT;
            return;
        case '>':
            if (p->position < p->length && p->source[p->position] == '=') {
                ++p->position; p->current.type = T_GE;
            } else p->current.type = T_GT;
            return;
        case '=':
            if (p->position < p->length && p->source[p->position] == '=') {
                ++p->position;
                if (p->position < p->length && p->source[p->position] == '=') ++p->position;
                p->current.type = T_EQ;
            } else p->current.type = T_BAD;
            return;
        case '&':
            if (p->position < p->length && p->source[p->position] == '&') {
                ++p->position; p->current.type = T_AND;
            } else p->current.type = T_BAD;
            return;
        case '|':
            if (p->position < p->length && p->source[p->position] == '|') {
                ++p->position; p->current.type = T_OR;
            } else p->current.type = T_BAD;
            return;
        default: break;
    }
    if (isdigit((unsigned char)p->source[start]) || p->source[start] == '.') {
        char number[48];
        size_t n;
        char *end = NULL;
        double value;
        p->position = start;
        while (p->position < p->length &&
               (isdigit((unsigned char)p->source[p->position]) || p->source[p->position] == '.' ||
                p->source[p->position] == 'e' || p->source[p->position] == 'E' ||
                ((p->source[p->position] == '+' || p->source[p->position] == '-') && p->position > start &&
                 (p->source[p->position - 1u] == 'e' || p->source[p->position - 1u] == 'E'))))
            ++p->position;
        n = p->position - start;
        if (!n || n >= sizeof(number)) { p->current.type = T_BAD; return; }
        memcpy(number, p->source + start, n); number[n] = '\0';
        value = strtod(number, &end);
        if (!end || *end != '\0' || value != value || value > 1.0e100 || value < -1.0e100) {
            p->current.type = T_BAD; return;
        }
        p->current.type = T_NUMBER; p->current.number = value; return;
    }
    if (isalpha((unsigned char)p->source[start])) {
        if (p->length - start >= 4u && memcmp(p->source + start, "true", 4u) == 0 &&
            is_word_boundary(start + 4u < p->length ? p->source[start + 4u] : '\0')) {
            p->position = start + 4u; p->current.type = T_TRUE; return;
        }
        if (p->length - start >= 5u && memcmp(p->source + start, "false", 5u) == 0 &&
            is_word_boundary(start + 5u < p->length ? p->source[start + 5u] : '\0')) {
            p->position = start + 5u; p->current.type = T_FALSE; return;
        }
    }
    p->current.type = T_BAD;
}

static int parse_or(Parser *p, XwXjsValue *out);
static int parse_primary(Parser *p, XwXjsValue *out)
{
    if (++p->depth > XW_XJS_MAX_DEPTH) { set_error(p, "profundidade excedida"); --p->depth; return -1; }
    if (p->current.type == T_NUMBER) {
        out->type = XW_XJS_NUMBER; out->number = p->current.number; out->boolean = 0;
        next_token(p); --p->depth; return 0;
    }
    if (p->current.type == T_TRUE || p->current.type == T_FALSE) {
        out->type = XW_XJS_BOOLEAN; out->boolean = p->current.type == T_TRUE; out->number = 0.0;
        next_token(p); --p->depth; return 0;
    }
    if (p->current.type == T_LPAREN) {
        next_token(p);
        if (parse_or(p, out) != 0 || p->current.type != T_RPAREN) {
            set_error(p, "parenteses invalidos"); --p->depth; return -1;
        }
        next_token(p); --p->depth; return 0;
    }
    set_error(p, "expressao contem sintaxe nao suportada");
    --p->depth; return -1;
}

static double numeric_value(const XwXjsValue *v)
{
    return v->type == XW_XJS_BOOLEAN ? (v->boolean ? 1.0 : 0.0) : v->number;
}

static int parse_unary(Parser *p, XwXjsValue *out)
{
    TokenType op = p->current.type;
    if (op == T_PLUS || op == T_MINUS || op == T_BANG) {
        XwXjsValue value;
        if (++p->depth > XW_XJS_MAX_DEPTH) {
            set_error(p, "profundidade excedida"); --p->depth; return -1;
        }
        next_token(p);
        if (parse_unary(p, &value) != 0) { --p->depth; return -1; }
        --p->depth;
        if (op == T_BANG) {
            out->type = XW_XJS_BOOLEAN; out->boolean = numeric_value(&value) == 0.0; out->number = 0.0;
        } else {
            out->type = XW_XJS_NUMBER; out->number = op == T_MINUS ? -numeric_value(&value) : numeric_value(&value); out->boolean = 0;
        }
        return 0;
    }
    return parse_primary(p, out);
}

static int parse_mul(Parser *p, XwXjsValue *out)
{
    if (parse_unary(p, out) != 0) return -1;
    while (p->current.type == T_STAR || p->current.type == T_SLASH) {
        TokenType op = p->current.type; XwXjsValue rhs; double a = numeric_value(out), b;
        next_token(p); if (parse_unary(p, &rhs) != 0) return -1; b = numeric_value(&rhs);
        if (op == T_SLASH && b == 0.0) { set_error(p, "divisao por zero"); return -1; }
        out->type = XW_XJS_NUMBER; out->boolean = 0; out->number = op == T_STAR ? a * b : a / b;
        if (out->number != out->number || out->number > 1.0e100 || out->number < -1.0e100) { set_error(p, "resultado numerico invalido"); return -1; }
    }
    return 0;
}

static int parse_add(Parser *p, XwXjsValue *out)
{
    if (parse_mul(p, out) != 0) return -1;
    while (p->current.type == T_PLUS || p->current.type == T_MINUS) {
        TokenType op = p->current.type; XwXjsValue rhs; double a = numeric_value(out), b;
        next_token(p); if (parse_mul(p, &rhs) != 0) return -1; b = numeric_value(&rhs);
        out->type = XW_XJS_NUMBER; out->boolean = 0; out->number = op == T_PLUS ? a + b : a - b;
        if (out->number != out->number || out->number > 1.0e100 || out->number < -1.0e100) {
            set_error(p, "resultado numerico fora do limite"); return -1;
        }
    }
    return 0;
}

static int parse_compare(Parser *p, XwXjsValue *out)
{
    if (parse_add(p, out) != 0) return -1;
    while (p->current.type == T_LT || p->current.type == T_GT || p->current.type == T_LE || p->current.type == T_GE) {
        TokenType op = p->current.type; XwXjsValue rhs; double a = numeric_value(out), b;
        next_token(p); if (parse_add(p, &rhs) != 0) return -1; b = numeric_value(&rhs);
        out->type = XW_XJS_BOOLEAN; out->number = 0.0;
        out->boolean = op == T_LT ? a < b : op == T_GT ? a > b : op == T_LE ? a <= b : a >= b;
    }
    return 0;
}

static int parse_equal(Parser *p, XwXjsValue *out)
{
    if (parse_compare(p, out) != 0) return -1;
    while (p->current.type == T_EQ || p->current.type == T_NE) {
        TokenType op = p->current.type; XwXjsValue rhs; double a = numeric_value(out), b;
        next_token(p); if (parse_compare(p, &rhs) != 0) return -1; b = numeric_value(&rhs);
        out->type = XW_XJS_BOOLEAN; out->number = 0.0; out->boolean = op == T_EQ ? a == b : a != b;
    }
    return 0;
}

static int parse_and(Parser *p, XwXjsValue *out)
{
    if (parse_equal(p, out) != 0) return -1;
    while (p->current.type == T_AND) {
        XwXjsValue rhs; int lhs = numeric_value(out) != 0.0;
        next_token(p); if (parse_equal(p, &rhs) != 0) return -1;
        out->type = XW_XJS_BOOLEAN; out->number = 0.0; out->boolean = lhs && numeric_value(&rhs) != 0.0;
    }
    return 0;
}

static int parse_or(Parser *p, XwXjsValue *out)
{
    if (parse_and(p, out) != 0) return -1;
    while (p->current.type == T_OR) {
        XwXjsValue rhs; int lhs = numeric_value(out) != 0.0;
        next_token(p); if (parse_and(p, &rhs) != 0) return -1;
        out->type = XW_XJS_BOOLEAN; out->number = 0.0; out->boolean = lhs || numeric_value(&rhs) != 0.0;
    }
    return 0;
}

int xw_xjs_eval_expression(const char *expression, XwXjsValue *result,
                           char *error, size_t error_capacity)
{
    Parser parser;
    size_t length;
    if (error && error_capacity) error[0] = '\0';
    if (!expression || !result) return -1;
    length = strlen(expression);
    if (!length || length > XW_XJS_MAX_EXPR) {
        if (error && error_capacity) (void)snprintf(error, error_capacity, "expressao vazia ou acima de 256 bytes");
        return -1;
    }
    memset(&parser, 0, sizeof(parser));
    parser.source = expression; parser.length = length;
    parser.error = error; parser.error_capacity = error_capacity;
    next_token(&parser);
    if (parse_or(&parser, result) != 0 || parser.current.type != T_END) {
        if (error && error_capacity && !error[0]) (void)snprintf(error, error_capacity, "token final inesperado");
        return -1;
    }
    return 0;
}

const char *xw_xjs_vm_status(void)
{
    return "XJST scalar VM: expressoes numericas/booleanas; sem DOM, rede ou execucao de scripts web";
}
