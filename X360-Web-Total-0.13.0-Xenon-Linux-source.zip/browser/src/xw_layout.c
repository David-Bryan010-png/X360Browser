#include "xw_layout.h"

#include <stdio.h>
#include <string.h>

static void push_line(XwLayout *layout, const char *text, unsigned indent,
                      unsigned block, int link)
{
    XwVisualLine *line;
    if (layout->line_count >= sizeof(layout->lines) / sizeof(layout->lines[0])) {
        ++layout->dropped_lines;
        return;
    }
    line = &layout->lines[layout->line_count++];
    memset(line, 0, sizeof(*line));
    (void)snprintf(line->text, sizeof(line->text), "%s", text);
    line->indent = indent;
    line->source_block = block;
    line->is_link = link;
}

static size_t utf8_unit(const unsigned char *s, size_t remain)
{
    unsigned char c;
    size_t n;
    if (!remain) return 0;
    c = s[0];
    if (c < 0x80) return 1;
    if ((c & 0xe0) == 0xc0) n = 2;
    else if ((c & 0xf0) == 0xe0) n = 3;
    else if ((c & 0xf8) == 0xf0) n = 4;
    else return 1;
    if (n > remain) return 1;
    for (size_t i = 1; i < n; ++i) if ((s[i] & 0xc0) != 0x80) return 1;
    return n;
}

static unsigned utf8_columns(const char *s)
{
    unsigned count = 0;
    size_t n = strlen(s), i = 0;
    while (i < n) { i += utf8_unit((const unsigned char *)s + i, n - i); ++count; }
    return count;
}

static void emit_preformatted(XwLayout *layout, const char *src, unsigned limit,
                              unsigned indent, unsigned block, int is_link)
{
    char line[128];
    size_t used = 0, pos = 0, length = strlen(src);
    unsigned columns = 0;
    while (pos < length) {
        unsigned char c = (unsigned char)src[pos];
        if (c == '\r') { ++pos; continue; }
        if (c == '\n') {
            line[used] = '\0'; push_line(layout, line, indent, block, is_link);
            used = 0; columns = 0; ++pos; continue;
        }
        if (c == '\t') {
            unsigned spaces = 4u - (columns & 3u);
            while (spaces--) {
                if (columns >= limit || used + 1u >= sizeof(line)) {
                    line[used] = '\0'; push_line(layout, line, indent, block, is_link);
                    used = 0; columns = 0;
                }
                line[used++] = ' '; ++columns;
            }
            ++pos;
            continue;
        }
        size_t unit = utf8_unit((const unsigned char *)src + pos, length - pos);
        if (columns >= limit || used + unit >= sizeof(line)) {
            line[used] = '\0'; push_line(layout, line, indent, block, is_link);
            used = 0; columns = 0;
        }
        memcpy(line + used, src + pos, unit);
        used += unit; pos += unit; ++columns;
    }
    if (used || length == 0 || (length && src[length-1] == '\n')) {
        line[used] = '\0'; push_line(layout, line, indent, block, is_link);
    }
}

static void emit_wrapped_text(XwLayout *layout, const char *src, unsigned limit,
                              unsigned indent, unsigned block, int is_link,
                              const char *prefix)
{
    char line[128];
    size_t used = 0, pos = 0, length = strlen(src);
    unsigned columns = 0;
    if (limit == 0) limit = 1;
    if (prefix) {
        size_t n = strlen(prefix);
        if (n >= sizeof(line)) n = sizeof(line)-1;
        memcpy(line, prefix, n); used = n; columns = utf8_columns(prefix);
    }
    while (pos < length) {
        size_t word_start, word_end;
        while (pos < length && (src[pos] == ' ' || src[pos] == '\t' || src[pos] == '\r' || src[pos] == '\n')) ++pos;
        if (pos >= length) break;
        word_start = pos;
        while (pos < length && src[pos] != ' ' && src[pos] != '\t' && src[pos] != '\r' && src[pos] != '\n')
            pos += utf8_unit((const unsigned char *)src + pos, length - pos);
        word_end = pos;
        {
            unsigned word_cols = utf8_columns(src + word_start);
            if (columns != 0 && columns + 1u + word_cols > limit) {
                line[used] = '\0'; push_line(layout, line, indent, block, is_link);
                used = 0; columns = 0;
            } else if (columns != 0) {
                if (used + 1u < sizeof(line)) { line[used++] = ' '; ++columns; }
            }
            while (word_start < word_end) {
                size_t unit = utf8_unit((const unsigned char *)src + word_start, word_end - word_start);
                if (columns >= limit || used + unit >= sizeof(line)) {
                    line[used] = '\0'; push_line(layout, line, indent, block, is_link);
                    used = 0; columns = 0;
                }
                memcpy(line + used, src + word_start, unit);
                used += unit; word_start += unit; ++columns;
                if (columns >= limit && word_start < word_end) {
                    line[used] = '\0'; push_line(layout, line, indent, block, is_link);
                    used = 0; columns = 0;
                }
            }
        }
    }
    if (used || length == 0) {
        line[used] = '\0'; push_line(layout, line, indent, block, is_link);
    }
}

static unsigned block_indent(const XwHtmlBlock *b)
{
    switch (b->type) {
        case XW_BLOCK_HEADING: return b->level > 2u ? 1u : 0u;
        case XW_BLOCK_LIST_ITEM: return 2u;
        case XW_BLOCK_LINK: return 1u;
        case XW_BLOCK_QUOTE: return 3u;
        case XW_BLOCK_TABLE_ROW: return 1u;
        case XW_BLOCK_FORM_CONTROL: return 2u;
        default: return 0u;
    }
}

int xw_layout_build(const XwHtmlDocument *document, unsigned columns, XwLayout *layout)
{
    if (document == NULL || layout == NULL || columns < 12u || columns > 120u) return -1;
    memset(layout, 0, sizeof(*layout));
    for (size_t i = 0; i < document->block_count; ++i) {
        const XwHtmlBlock *block = &document->blocks[i];
        unsigned indent = block_indent(block);
        unsigned limit = columns > indent ? columns - indent : columns;
        const char *prefix = NULL;
        char suffix[128];
        int link = block->type == XW_BLOCK_LINK;

        if (block->type == XW_BLOCK_BREAK) {
            if (layout->line_count && layout->lines[layout->line_count-1].text[0] != '\0')
                push_line(layout, "", 0, (unsigned)i, 0);
            continue;
        }
        if (block->type == XW_BLOCK_RULE) {
            push_line(layout, "----------------------------------------------------------------", 0, (unsigned)i, 0);
            continue;
        }
        switch (block->type) {
            case XW_BLOCK_HEADING: prefix = block->level <= 2u ? "## " : "# "; break;
            case XW_BLOCK_LIST_ITEM: prefix = "* "; break;
            case XW_BLOCK_LINK: prefix = "[LINK] "; break;
            case XW_BLOCK_IMAGE: prefix = "[IMG] "; break;
            case XW_BLOCK_QUOTE: prefix = "> "; break;
            case XW_BLOCK_FORM_CONTROL: prefix = "[CAMPO] "; break;
            default: break;
        }
        if (block->type == XW_BLOCK_PARAGRAPH || block->type == XW_BLOCK_HEADING ||
            block->type == XW_BLOCK_LIST_ITEM || block->type == XW_BLOCK_IMAGE ||
            block->type == XW_BLOCK_PREFORMATTED || block->type == XW_BLOCK_LINK ||
            block->type == XW_BLOCK_QUOTE || block->type == XW_BLOCK_TABLE_ROW ||
            block->type == XW_BLOCK_FORM_CONTROL) {
            if (layout->line_count && layout->lines[layout->line_count-1].text[0] != '\0')
                push_line(layout, "", 0, (unsigned)i, 0);
        }
        if (prefix) {
            unsigned prefix_cols = utf8_columns(prefix);
            limit = columns > prefix_cols ? columns - prefix_cols : 1u;
        }
        if (block->type == XW_BLOCK_PREFORMATTED) {
            emit_preformatted(layout, block->text, limit, indent, (unsigned)i, 0);
        } else {
            emit_wrapped_text(layout, block->text, limit, indent, (unsigned)i, link, prefix);
        }
        if (block->type == XW_BLOCK_LINK && block->href[0]) {
            (void)snprintf(suffix, sizeof(suffix), "  URL: %.112s", block->href);
            push_line(layout, suffix, indent, (unsigned)i, 1);
        } else if (block->type == XW_BLOCK_IMAGE && block->href[0]) {
            (void)snprintf(suffix, sizeof(suffix), "  SRC: %.116s", block->href);
            push_line(layout, suffix, indent, (unsigned)i, 0);
        }
    }
    return 0;
}
