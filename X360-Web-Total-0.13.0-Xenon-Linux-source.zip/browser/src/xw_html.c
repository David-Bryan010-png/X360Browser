#include "xw_html.h"

#include <ctype.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

typedef struct {
    char name[16];
    XwHtmlBlock *block;
    int preserve_whitespace;
} HtmlFrame;

static int equal_ci(const char *a, size_t n, const char *b)
{
    size_t i;
    if (strlen(b) != n) return 0;
    for (i = 0; i < n; ++i)
        if (tolower((unsigned char)a[i]) != tolower((unsigned char)b[i])) return 0;
    return 1;
}

static void append_utf8(char *out, size_t cap, size_t *used, uint32_t cp)
{
    unsigned char b[4];
    size_t n;
    if (cp <= 0x7f) { b[0] = (unsigned char)cp; n = 1; }
    else if (cp <= 0x7ff) {
        b[0] = (unsigned char)(0xc0 | (cp >> 6));
        b[1] = (unsigned char)(0x80 | (cp & 0x3f)); n = 2;
    } else if (cp <= 0xffff && !(cp >= 0xd800 && cp <= 0xdfff)) {
        b[0] = (unsigned char)(0xe0 | (cp >> 12));
        b[1] = (unsigned char)(0x80 | ((cp >> 6) & 0x3f));
        b[2] = (unsigned char)(0x80 | (cp & 0x3f)); n = 3;
    } else if (cp <= 0x10ffff) {
        b[0] = (unsigned char)(0xf0 | (cp >> 18));
        b[1] = (unsigned char)(0x80 | ((cp >> 12) & 0x3f));
        b[2] = (unsigned char)(0x80 | ((cp >> 6) & 0x3f));
        b[3] = (unsigned char)(0x80 | (cp & 0x3f)); n = 4;
    } else return;
    if (cap == 0 || *used + n >= cap) return;
    memcpy(out + *used, b, n);
    *used += n;
}

static int entity_value(const char *name, size_t n, uint32_t *cp)
{
    struct Named { const char *name; uint32_t value; };
    static const struct Named entities[] = {
        {"amp", '&'}, {"lt", '<'}, {"gt", '>'}, {"quot", '"'}, {"apos", '\''},
        {"nbsp", 0x00a0}, {"copy", 0x00a9}, {"reg", 0x00ae}, {"trade", 0x2122},
        {"ndash", 0x2013}, {"mdash", 0x2014}, {"hellip", 0x2026}, {"bull", 0x2022},
        {"middot", 0x00b7}, {"lsquo", 0x2018}, {"rsquo", 0x2019},
        {"ldquo", 0x201c}, {"rdquo", 0x201d}, {"euro", 0x20ac},
        {"pound", 0x00a3}, {"yen", 0x00a5}, {"cent", 0x00a2},
        {"times", 0x00d7}, {"divide", 0x00f7}, {"plusmn", 0x00b1},
        {"deg", 0x00b0}, {"micro", 0x00b5}, {"para", 0x00b6},
        {"sect", 0x00a7}, {"laquo", 0x00ab}, {"raquo", 0x00bb}
    };
    for (size_t i = 0; i < sizeof(entities) / sizeof(entities[0]); ++i) {
        if (strlen(entities[i].name) == n && memcmp(name, entities[i].name, n) == 0) {
            *cp = entities[i].value;
            return 1;
        }
    }
    if (n >= 2 && name[0] == '#') {
        size_t k = 1;
        unsigned base = 10;
        uint32_t value = 0;
        if (k < n && (name[k] == 'x' || name[k] == 'X')) { base = 16; ++k; }
        if (k == n) return 0;
        for (; k < n; ++k) {
            unsigned char c = (unsigned char)name[k];
            unsigned digit;
            if (c >= '0' && c <= '9') digit = (unsigned)(c - '0');
            else if (base == 16 && tolower(c) >= 'a' && tolower(c) <= 'f') digit = (unsigned)(tolower(c) - 'a' + 10);
            else return 0;
            if (value > (0x10ffffu - digit) / base) return 0;
            value = value * base + digit;
        }
        if (value == 0 || value > 0x10ffffu || (value >= 0xd800u && value <= 0xdfffu)) return 0;
        *cp = value;
        return 1;
    }
    return 0;
}

static size_t decode_entities(char *out, size_t cap, const char *src, size_t len)
{
    size_t i = 0, used = 0;
    if (cap == 0) return 0;
    while (i < len && used + 1 < cap) {
        if (src[i] == '&') {
            const char *semi = memchr(src + i + 1, ';', len - i - 1);
            if (semi != NULL && (size_t)(semi - (src + i)) <= 16) {
                uint32_t cp;
                size_t n = (size_t)(semi - (src + i + 1));
                if (entity_value(src + i + 1, n, &cp)) {
                    append_utf8(out, cap, &used, cp);
                    i = (size_t)(semi - src) + 1;
                    continue;
                }
            }
        }
        out[used++] = src[i++];
    }
    out[used] = '\0';
    return used;
}

static size_t utf8_unit(const unsigned char *s, size_t remain)
{
    unsigned char c;
    size_t n;
    if (!remain) return 0;
    c = s[0];
    if (c < 0x80) return 1;
    if ((c & 0xe0) == 0xc0) n = 2;
    else if ((c & 0xf0) == 0xe0) n = 3;
    else if ((c & 0xf8) == 0xf0) n = 4;
    else return 1;
    if (n > remain) return 1;
    for (size_t i = 1; i < n; ++i) if ((s[i] & 0xc0) != 0x80) return 1;
    return n;
}

static void append_text(char *dst, size_t cap, const char *text, size_t len, int preserve)
{
    size_t used = strlen(dst), i = 0;
    while (i < len && used + 1 < cap) {
        unsigned char c = (unsigned char)text[i];
        if (!preserve && (c == '\n' || c == '\r' || c == '\t' || c == ' ' || c == '\f')) {
            if (used && dst[used - 1] != ' ') dst[used++] = ' ';
            ++i;
        } else {
            size_t n = utf8_unit((const unsigned char *)text + i, len - i);
            if (used + n >= cap) break;
            memcpy(dst + used, text + i, n);
            used += n;
            i += n;
        }
    }
    dst[used] = '\0';
}

static void trim(char *s)
{
    size_t n = strlen(s), start = 0;
    while (start < n && (s[start] == ' ' || s[start] == '\t' || s[start] == '\r' || s[start] == '\n')) ++start;
    while (n > start && (s[n - 1] == ' ' || s[n - 1] == '\t' || s[n - 1] == '\r' || s[n - 1] == '\n')) --n;
    if (start) memmove(s, s + start, n - start);
    s[n - start] = '\0';
}

static XwHtmlBlock *new_block(XwHtmlDocument *doc, XwBlockType type, unsigned level)
{
    XwHtmlBlock *b;
    if (doc->block_count >= XW_HTML_MAX_BLOCKS) {
        doc->truncated = 1;
        ++doc->dropped_blocks;
        return NULL;
    }
    b = &doc->blocks[doc->block_count++];
    memset(b, 0, sizeof(*b));
    b->type = type;
    b->level = level;
    return b;
}

static void copy_attribute(const char *tag, size_t tag_len, const char *wanted, char *out, size_t cap)
{
    size_t i = 0;
    if (cap == 0) return;
    out[0] = '\0';
    while (i < tag_len) {
        size_t ns, ne, vs, vl;
        while (i < tag_len && (isspace((unsigned char)tag[i]) || tag[i] == '/' || tag[i] == '<' || tag[i] == '>')) ++i;
        ns = i;
        while (i < tag_len && (isalnum((unsigned char)tag[i]) || tag[i] == '-' || tag[i] == '_' || tag[i] == ':')) ++i;
        ne = i;
        if (ne == ns) { if (i < tag_len) ++i; continue; }
        while (i < tag_len && isspace((unsigned char)tag[i])) ++i;
        if (i >= tag_len || tag[i] != '=') continue;
        ++i;
        while (i < tag_len && isspace((unsigned char)tag[i])) ++i;
        if (i >= tag_len) break;
        if (tag[i] == '\'' || tag[i] == '"') {
            char quote = tag[i++];
            vs = i;
            while (i < tag_len && tag[i] != quote) ++i;
            vl = i - vs;
            if (i < tag_len) ++i;
        } else {
            vs = i;
            while (i < tag_len && !isspace((unsigned char)tag[i]) && tag[i] != '>') ++i;
            vl = i - vs;
        }
        if (equal_ci(tag + ns, ne - ns, wanted)) {
            (void)decode_entities(out, cap, tag + vs, vl);
            return;
        }
    }
}

static size_t find_tag_end(const char *html, size_t length, size_t start)
{
    char quote = '\0';
    for (size_t i = start; i < length; ++i) {
        char c = html[i];
        if (quote) { if (c == quote) quote = '\0'; }
        else if (c == '\'' || c == '"') quote = c;
        else if (c == '>') return i;
    }
    return length;
}

static int is_void_tag(const char *name, size_t n)
{
    static const char *const tags[] = {"area","base","br","col","embed","hr","img","input","link","meta","param","source","track","wbr"};
    for (size_t i = 0; i < sizeof(tags)/sizeof(tags[0]); ++i) if (equal_ci(name,n,tags[i])) return 1;
    return 0;
}

static int is_hidden_tag(const char *name, size_t n)
{
    return equal_ci(name,n,"script") || equal_ci(name,n,"style") ||
           equal_ci(name,n,"svg") || equal_ci(name,n,"canvas") ||
           equal_ci(name,n,"template") ||
           equal_ci(name,n,"iframe") || equal_ci(name,n,"object") ||
           equal_ci(name,n,"embed");
}

static int classify_tag(const char *name, size_t n, XwBlockType *type, unsigned *level)
{
    if (n == 2 && tolower((unsigned char)name[0]) == 'h' && name[1] >= '1' && name[1] <= '6') {
        *type = XW_BLOCK_HEADING; *level = (unsigned)(name[1] - '0'); return 1;
    }
    if (equal_ci(name,n,"p") || equal_ci(name,n,"div") || equal_ci(name,n,"section") ||
        equal_ci(name,n,"article") || equal_ci(name,n,"main") || equal_ci(name,n,"header") ||
        equal_ci(name,n,"footer") || equal_ci(name,n,"nav") || equal_ci(name,n,"aside") ||
        equal_ci(name,n,"figure") || equal_ci(name,n,"figcaption") || equal_ci(name,n,"address") ||
        equal_ci(name,n,"details") || equal_ci(name,n,"summary") || equal_ci(name,n,"form")) {
        *type = XW_BLOCK_PARAGRAPH; *level = 0; return 1;
    }
    if (equal_ci(name,n,"li")) { *type = XW_BLOCK_LIST_ITEM; *level = 0; return 1; }
    if (equal_ci(name,n,"a")) { *type = XW_BLOCK_LINK; *level = 0; return 1; }
    if (equal_ci(name,n,"pre")) { *type = XW_BLOCK_PREFORMATTED; *level = 0; return 1; }
    if (equal_ci(name,n,"blockquote")) { *type = XW_BLOCK_QUOTE; *level = 0; return 1; }
    if (equal_ci(name,n,"tr")) { *type = XW_BLOCK_TABLE_ROW; *level = 0; return 1; }
    if (equal_ci(name,n,"button") || equal_ci(name,n,"select") || equal_ci(name,n,"textarea")) {
        *type = XW_BLOCK_FORM_CONTROL; *level = 0; return 1;
    }
    if (equal_ci(name,n,"dt")) { *type = XW_BLOCK_HEADING; *level = 4; return 1; }
    if (equal_ci(name,n,"dd")) { *type = XW_BLOCK_PARAGRAPH; *level = 0; return 1; }
    return 0;
}

static void close_frame(HtmlFrame *stack, size_t *count, const char *name, size_t name_len)
{
    for (size_t k = *count; k > 0; --k) {
        if (equal_ci(stack[k-1].name, strlen(stack[k-1].name), name) && strlen(stack[k-1].name) == name_len) {
            while (*count >= k) {
                HtmlFrame *f = &stack[--(*count)];
                if (f->block) trim(f->block->text);
            }
            return;
        }
    }
}

static void close_if_open(HtmlFrame *stack, size_t *count, const char *name)
{
    close_frame(stack, count, name, strlen(name));
}

static void push_frame(HtmlFrame *stack, size_t *count, const char *name, size_t name_len,
                       XwHtmlBlock *block, int preserve)
{
    if (*count >= XW_HTML_MAX_DEPTH) return;
    HtmlFrame *f = &stack[(*count)++];
    memset(f, 0, sizeof(*f));
    if (name_len >= sizeof(f->name)) name_len = sizeof(f->name)-1;
    memcpy(f->name, name, name_len);
    f->name[name_len] = '\0';
    f->block = block;
    f->preserve_whitespace = preserve;
}

int xw_html_parse(const char *html, size_t length, XwHtmlDocument *doc)
{
    HtmlFrame stack[XW_HTML_MAX_DEPTH];
    size_t stack_count = 0, pos = 0;
    int in_title = 0, in_head = 0, hidden_depth = 0;
    if (html == NULL || doc == NULL) return -1;
    memset(doc, 0, sizeof(*doc));
    memset(stack, 0, sizeof(stack));
    doc->source_bytes = length;

    while (pos < length) {
        if (html[pos] == '<') {
            size_t end;
            if (pos + 4 <= length && memcmp(html + pos, "<!--", 4) == 0) {
                size_t k = pos + 4;
                while (k + 3 <= length && memcmp(html + k, "-->", 3) != 0) ++k;
                pos = k + 3 <= length ? k + 3 : length;
                continue;
            }
            end = find_tag_end(html, length, pos + 1);
            if (end >= length) { ++doc->malformed_elements; break; }
            {
                const char *tag = html + pos + 1;
                size_t tag_len = end - pos - 1, ns = 0, ne;
                int closing = 0, self_closing;
                XwBlockType type = XW_BLOCK_TEXT;
                unsigned level = 0;
                while (ns < tag_len && isspace((unsigned char)tag[ns])) ++ns;
                if (ns < tag_len && tag[ns] == '/') { closing = 1; ++ns; }
                while (ns < tag_len && isspace((unsigned char)tag[ns])) ++ns;
                ne = ns;
                while (ne < tag_len && (isalnum((unsigned char)tag[ne]) || tag[ne] == '-')) ++ne;
                if (ne == ns) { pos = end + 1; continue; }
                size_t name_len = ne - ns;
                self_closing = is_void_tag(tag + ns, name_len) ||
                    (tag_len > 0 && memchr(tag + ns, '/', tag_len - ns) != NULL && tag[tag_len-1] == '/');

                if (equal_ci(tag + ns, name_len, "head")) {
                    in_head = !closing;
                } else if (!closing && equal_ci(tag + ns, name_len, "base")) {
                    if (!doc->base_href[0])
                        copy_attribute(tag + ns, tag_len - ns, "href", doc->base_href, sizeof(doc->base_href));
                } else if (equal_ci(tag + ns, name_len, "title")) {
                    in_title = !closing;
                } else if (is_hidden_tag(tag + ns, name_len)) {
                    if (closing) { if (hidden_depth) --hidden_depth; }
                    else if (!self_closing) { ++hidden_depth; ++doc->skipped_unsafe_elements; }
                } else if (closing) {
                    if (equal_ci(tag + ns, name_len, "ul") || equal_ci(tag + ns, name_len, "ol"))
                        close_if_open(stack, &stack_count, "li");
                    if (equal_ci(tag + ns, name_len, "table"))
                        close_if_open(stack, &stack_count, "tr");
                    close_frame(stack, &stack_count, tag + ns, name_len);
                    if (equal_ci(tag + ns, name_len, "title")) in_title = 0;
                } else if (!hidden_depth && !in_title) {
                    if (equal_ci(tag + ns, name_len, "p") || equal_ci(tag + ns, name_len, "div") ||
                        equal_ci(tag + ns, name_len, "section") || equal_ci(tag + ns, name_len, "article") ||
                        equal_ci(tag + ns, name_len, "main") || equal_ci(tag + ns, name_len, "blockquote") ||
                        equal_ci(tag + ns, name_len, "pre") || equal_ci(tag + ns, name_len, "table") ||
                        equal_ci(tag + ns, name_len, "ul") || equal_ci(tag + ns, name_len, "ol") ||
                        equal_ci(tag + ns, name_len, "form") ||
                        (name_len == 2 && tolower((unsigned char)tag[ns]) == 'h' && tag[ns+1] >= '1' && tag[ns+1] <= '6'))
                        close_if_open(stack, &stack_count, "p");
                    if (equal_ci(tag + ns, name_len, "li")) close_if_open(stack, &stack_count, "li");
                    else if (equal_ci(tag + ns, name_len, "tr")) close_if_open(stack, &stack_count, "tr");
                    else if (equal_ci(tag + ns, name_len, "td") || equal_ci(tag + ns, name_len, "th")) {
                        close_if_open(stack, &stack_count, "td");
                        close_if_open(stack, &stack_count, "th");
                        if (stack_count) {
                            XwHtmlBlock *parent = stack[stack_count-1].block;
                            if (parent && parent->type == XW_BLOCK_TABLE_ROW && parent->text[0])
                                append_text(parent->text, sizeof(parent->text), " | ", 3, 1);
                        }
                    }
                    if (classify_tag(tag + ns, name_len, &type, &level)) {
                        XwHtmlBlock *block = new_block(doc, type, level);
                        if (block && type == XW_BLOCK_LINK) {
                            copy_attribute(tag + ns, tag_len - ns, "href", block->href, sizeof(block->href));
                            copy_attribute(tag + ns, tag_len - ns, "title", block->title, sizeof(block->title));
                            if (!block->href[0]) ++doc->malformed_elements;
                        }
                        if (block && type == XW_BLOCK_FORM_CONTROL) {
                            copy_attribute(tag + ns, tag_len - ns, "placeholder", block->text, sizeof(block->text));
                            if (!block->text[0]) copy_attribute(tag + ns, tag_len - ns, "aria-label", block->text, sizeof(block->text));
                            if (!block->text[0]) copy_attribute(tag + ns, tag_len - ns, "value", block->text, sizeof(block->text));
                            if (!block->text[0]) (void)snprintf(block->text, sizeof(block->text), "controle de formulario");
                        }
                        if (!self_closing) push_frame(stack, &stack_count, tag + ns, name_len, block,
                                                       type == XW_BLOCK_PREFORMATTED);
                    } else if (equal_ci(tag + ns, name_len, "img")) {
                        XwHtmlBlock *image = new_block(doc, XW_BLOCK_IMAGE, 0);
                        if (image) {
                            copy_attribute(tag + ns, tag_len - ns, "alt", image->text, sizeof(image->text));
                            copy_attribute(tag + ns, tag_len - ns, "src", image->href, sizeof(image->href));
                            if (!image->text[0]) (void)snprintf(image->text, sizeof(image->text), "[imagem]");
                        }
                    } else if (equal_ci(tag + ns, name_len, "hr")) {
                        (void)new_block(doc, XW_BLOCK_RULE, 0);
                    } else if (equal_ci(tag + ns, name_len, "br")) {
                        if (stack_count && stack[stack_count-1].block) {
                            XwHtmlBlock *previous = stack[stack_count-1].block;
                            XwHtmlBlock *next = new_block(doc, previous->type, previous->level);
                            if (next) stack[stack_count-1].block = next;
                        } else {
                            (void)new_block(doc, XW_BLOCK_BREAK, 0);
                        }
                    } else if (equal_ci(tag + ns, name_len, "input")) {
                        XwHtmlBlock *control = new_block(doc, XW_BLOCK_FORM_CONTROL, 0);
                        if (control) {
                            char input_type[24] = "text";
                            copy_attribute(tag + ns, tag_len - ns, "type", input_type, sizeof(input_type));
                            copy_attribute(tag + ns, tag_len - ns, "aria-label", control->text, sizeof(control->text));
                            if (!control->text[0]) copy_attribute(tag + ns, tag_len - ns, "placeholder", control->text, sizeof(control->text));
                            if (!control->text[0]) copy_attribute(tag + ns, tag_len - ns, "value", control->text, sizeof(control->text));
                            if (equal_ci(input_type, strlen(input_type), "submit") || equal_ci(input_type, strlen(input_type), "button")) {
                                char value[96];
                                copy_attribute(tag + ns, tag_len - ns, "value", value, sizeof(value));
                                if (value[0]) (void)snprintf(control->text, sizeof(control->text), "%s", value);
                            }
                            if (!control->text[0]) (void)snprintf(control->text, sizeof(control->text), "campo %s", input_type);
                        }
                    }
                }
            }
            pos = end + 1;
        } else {
            size_t end = pos;
            while (end < length && html[end] != '<') ++end;
            if (!hidden_depth && end > pos) {
                char decoded[XW_HTML_TEXT_BYTES];
                size_t n = decode_entities(decoded, sizeof(decoded), html + pos, end - pos);
                if (in_title) {
                    trim(decoded);
                    if (decoded[0]) {
                        if (doc->title[0]) append_text(doc->title, sizeof(doc->title), " ", 1, 0);
                        append_text(doc->title, sizeof(doc->title), decoded, strlen(decoded), 0);
                    }
                } else if (!in_head && stack_count && stack[stack_count-1].block) {
                    XwHtmlBlock *block = stack[stack_count-1].block;
                    append_text(block->text, sizeof(block->text), decoded, n,
                                stack[stack_count-1].preserve_whitespace);
                } else if (!in_head) {
                    trim(decoded);
                    if (decoded[0]) {
                        XwHtmlBlock *block = new_block(doc, XW_BLOCK_TEXT, 0);
                        if (block) append_text(block->text, sizeof(block->text), decoded, strlen(decoded), 0);
                    }
                }
            }
            pos = end;
        }
    }
    for (size_t i = 0; i < stack_count; ++i) if (stack[i].block) trim(stack[i].block->text);
    if (hidden_depth) ++doc->malformed_elements;
    return 0;
}


int xw_html_parse_plain_text(const char *text, size_t length, XwHtmlDocument *doc)
{
    size_t pos = 0;
    if (text == NULL || doc == NULL) return -1;
    memset(doc, 0, sizeof(*doc));
    doc->source_bytes = length;
    while (pos < length) {
        size_t line_end = pos;
        while (line_end < length && text[line_end] != '\n') ++line_end;
        size_t chunk = pos;
        if (line_end == pos) {
            (void)new_block(doc, XW_BLOCK_PREFORMATTED, 0);
        }
        while (chunk < line_end) {
            size_t end = chunk;
            while (end < line_end) {
                size_t unit = utf8_unit((const unsigned char *)text + end, line_end - end);
                if (end + unit - chunk >= XW_HTML_TEXT_BYTES) break;
                end += unit;
            }
            if (end == chunk) break;
            XwHtmlBlock *block = new_block(doc, XW_BLOCK_PREFORMATTED, 0);
            if (block) append_text(block->text, sizeof(block->text), text + chunk, end - chunk, 1);
            chunk = end;
        }
        if (line_end < length) {
            (void)new_block(doc, XW_BLOCK_BREAK, 0);
            pos = line_end + 1;
        } else pos = line_end;
        if (doc->truncated) break;
    }
    return 0;
}
