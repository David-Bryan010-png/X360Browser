#include "xw_store.h"
#include "xw_url.h"

#include <stdio.h>
#include <string.h>
#include <stdint.h>

#define XW_STORE_FILE_LIMIT (XW_STORE_MAX_HISTORY * XW_STORE_URL_MAX + 2048u)

static uint32_t crc32_bytes(const unsigned char *data, size_t length)
{
    uint32_t crc = 0xFFFFFFFFu;
    for (size_t i = 0; i < length; ++i) {
        crc ^= data[i];
        for (unsigned bit = 0; bit < 8u; ++bit)
            crc = (crc >> 1) ^ (0xEDB88320u & (uint32_t)-(int32_t)(crc & 1u));
    }
    return ~crc;
}

static int safe_kind(const char *kind)
{
    if (!kind || !*kind || strlen(kind) > 16u) return 0;
    for (const char *p = kind; *p; ++p)
        if (!( (*p >= 'a' && *p <= 'z') || (*p >= '0' && *p <= '9') || *p == '-')) return 0;
    return 1;
}

void xw_store_list_clear(XwStoreList *list)
{
    if (list) memset(list, 0, sizeof(*list));
}

int xw_store_list_add(XwStoreList *list, const char *url, unsigned capacity)
{
    XwUrl parsed;
    char error[64];
    size_t length;
    if (!list || !url || capacity == 0u || capacity > XW_STORE_MAX_HISTORY) return -1;
    length = strlen(url);
    if (length == 0u || length >= XW_STORE_URL_MAX ||
        strchr(url, '\n') || strchr(url, '\r') || strchr(url, '|') ||
        xw_url_parse(url, &parsed, error, sizeof(error)) != 0) return -1;
    for (unsigned i = 0; i < list->count; ++i)
        if (strcmp(list->items[i], url) == 0) return 0;
    if (list->count >= capacity) {
        memmove(list->items, list->items + 1u, sizeof(list->items[0]) * (capacity - 1u));
        list->count = capacity - 1u;
    }
    memcpy(list->items[list->count], url, length + 1u);
    ++list->count;
    return 1;
}

int xw_store_list_remove(XwStoreList *list, unsigned index)
{
    if (!list || index >= list->count) return -1;
    if (index + 1u < list->count)
        memmove(list->items[index], list->items[index + 1u],
                sizeof(list->items[0]) * (list->count - index - 1u));
    --list->count;
    memset(list->items[list->count], 0, sizeof(list->items[0]));
    return 0;
}

static int read_one(const char *path, const char *kind, XwStoreList *output)
{
    FILE *file;
    char buffer[XW_STORE_FILE_LIMIT + 1u];
    char header[80];
    size_t bytes;
    char *newline;
    unsigned declared_count;
    unsigned expected_crc;
    unsigned actual_crc;
    int header_consumed = 0;
    XwStoreList candidate;

    file = fopen(path, "rb");
    if (!file) return -2;
    bytes = fread(buffer, 1u, sizeof(buffer) - 1u, file);
    if (ferror(file) || !feof(file)) { fclose(file); return -1; }
    if (fclose(file) != 0) return -1;
    buffer[bytes] = '\0';
    newline = memchr(buffer, '\n', bytes);
    if (!newline) return -1;
    *newline = '\0';
    if (sscanf(buffer, "XWLIST1|%16[abcdefghijklmnopqrstuvwxyz0123456789-]|%u|%8x%n",
               header, &declared_count, &expected_crc, &header_consumed) != 3 ||
        header_consumed <= 0 || buffer[header_consumed] != '\0') return -1;
    {
        const char *crc_text = strrchr(buffer, '|');
        if (!crc_text || strlen(crc_text + 1) != 8u) return -1;
        for (unsigned i = 0; i < 8u; ++i)
            if (!((crc_text[1u + i] >= '0' && crc_text[1u + i] <= '9') ||
                  (crc_text[1u + i] >= 'A' && crc_text[1u + i] <= 'F') ||
                  (crc_text[1u + i] >= 'a' && crc_text[1u + i] <= 'f'))) return -1;
    }
    if (strcmp(header, kind) != 0 || declared_count > XW_STORE_MAX_HISTORY ||
        (strcmp(kind, "bookmarks") == 0 && declared_count > XW_STORE_MAX_BOOKMARKS)) return -1;
    {
        size_t payload_offset = (size_t)(newline + 1 - buffer);
        actual_crc = crc32_bytes((const unsigned char *)buffer + payload_offset, bytes - payload_offset);
        if (actual_crc != expected_crc) return -1;
    }

    xw_store_list_clear(&candidate);
    {
        char *cursor = newline + 1;
        char *end = buffer + bytes;
        while (cursor < end) {
            char *line_end = memchr(cursor, '\n', (size_t)(end - cursor));
            size_t line_length;
            if (!line_end) return -1;
            line_length = (size_t)(line_end - cursor);
            if (line_length == 0u || line_length >= XW_STORE_URL_MAX || candidate.count >= XW_STORE_MAX_HISTORY)
                return -1;
            {
                char entry[XW_STORE_URL_MAX];
                XwUrl parsed;
                char error[64];
                memcpy(entry, cursor, line_length);
                entry[line_length] = '\0';
                if (strchr(entry, '|') || xw_url_parse(entry, &parsed, error, sizeof(error)) != 0)
                    return -1;
                if (xw_store_list_add(&candidate, entry, XW_STORE_MAX_HISTORY) < 0) return -1;
            }
            cursor = line_end + 1;
        }
    }
    if (candidate.count != declared_count) return -1;
    *output = candidate;
    return 0;
}

int xw_store_load(const char *path, const char *kind, XwStoreList *list)
{
    char backup[512];
    if (!path || !safe_kind(kind) || !list || strlen(path) > 480u) return -1;
    {
        int primary_result = read_one(path, kind, list);
        if (primary_result == 0) return 0;
        if (snprintf(backup, sizeof(backup), "%s.bak", path) >= (int)sizeof(backup)) return -1;
        {
            int backup_result = read_one(backup, kind, list);
            if (backup_result == -2 && primary_result == -2) {
                xw_store_list_clear(list);
                return 0;
            }
            if (backup_result != 0) {
                xw_store_list_clear(list);
                return -1;
            }
        }
    }
    {
        char temp[512];
        if (snprintf(temp, sizeof(temp), "%s.restore", path) < (int)sizeof(temp)) {
            FILE *src = fopen(backup, "rb"), *dst = fopen(temp, "wb");
            if (src && dst) {
                int ch, failed = 0;
                while ((ch = fgetc(src)) != EOF) if (fputc(ch, dst) == EOF) { failed = 1; break; }
                if (ferror(src)) failed = 1;
                if (fclose(src) != 0) failed = 1;
                if (fclose(dst) != 0) failed = 1;
                if (!failed) { (void)remove(path); (void)rename(temp, path); }
                else (void)remove(temp);
            } else {
                if (src) fclose(src);
                if (dst) fclose(dst);
                (void)remove(temp);
            }
        }
        return 1;
    }
}

int xw_store_save(const char *path, const char *kind, const XwStoreList *list)
{
    char temp[512], backup[512], header[80];
    FILE *file;
    XwStoreList verify;
    uint32_t crc;
    size_t payload_length = 0u;
    char payload[XW_STORE_FILE_LIMIT];
    if (!path || !safe_kind(kind) || !list || strlen(path) > 470u || list->count > XW_STORE_MAX_HISTORY ||
        (strcmp(kind, "bookmarks") == 0 && list->count > XW_STORE_MAX_BOOKMARKS))
        return -1;
    for (unsigned i = 0; i < list->count; ++i) {
        size_t n = strlen(list->items[i]);
        XwUrl parsed;
        char error[64];
        if (n == 0u || n >= XW_STORE_URL_MAX || strchr(list->items[i], '\n') ||
            strchr(list->items[i], '\r') || strchr(list->items[i], '|') ||
            xw_url_parse(list->items[i], &parsed, error, sizeof(error)) != 0 ||
            payload_length + n + 1u >= sizeof(payload)) return -1;
        memcpy(payload + payload_length, list->items[i], n);
        payload_length += n;
        payload[payload_length++] = '\n';
    }
    crc = crc32_bytes((const unsigned char *)payload, payload_length);
    if (snprintf(header, sizeof(header), "XWLIST1|%s|%u|%08X\n", kind, list->count, (unsigned)crc) >= (int)sizeof(header) ||
        snprintf(temp, sizeof(temp), "%s.tmp", path) >= (int)sizeof(temp) ||
        snprintf(backup, sizeof(backup), "%s.bak", path) >= (int)sizeof(backup)) return -1;
    file = fopen(temp, "wb");
    if (!file) return -1;
    {
        int failed = 0;
        if (fwrite(header, 1u, strlen(header), file) != strlen(header)) failed = 1;
        if (!failed && payload_length && fwrite(payload, 1u, payload_length, file) != payload_length) failed = 1;
        if (fflush(file) != 0) failed = 1;
        if (fclose(file) != 0) failed = 1;
        if (failed) { (void)remove(temp); return -1; }
    }
    if (read_one(temp, kind, &verify) != 0 || verify.count != list->count) { (void)remove(temp); return -1; }
    for (unsigned i = 0; i < list->count; ++i)
        if (strcmp(verify.items[i], list->items[i]) != 0) { (void)remove(temp); return -1; }
    (void)remove(backup);
    if (rename(path, backup) != 0) (void)remove(backup); /* first save or target not present */
    if (rename(temp, path) != 0) {
        (void)rename(backup, path);
        (void)remove(temp);
        return -1;
    }
    return 0;
}
