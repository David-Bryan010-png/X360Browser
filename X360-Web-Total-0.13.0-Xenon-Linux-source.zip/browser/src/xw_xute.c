#include "xw_xute.h"

#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static int equal_ci_n(const char *a, size_t n, const char *b)
{
    size_t i;
    if (strlen(b) != n) return 0;
    for (i = 0; i < n; ++i)
        if (tolower((unsigned char)a[i]) != tolower((unsigned char)b[i])) return 0;
    return 1;
}

static size_t find_tag_end(const char *s, size_t length, size_t start)
{
    char quote = '\0';
    for (size_t i = start; i < length; ++i) {
        if (quote) { if (s[i] == quote) quote = '\0'; }
        else if (s[i] == '\'' || s[i] == '"') quote = s[i];
        else if (s[i] == '>') return i;
    }
    return length;
}

static size_t find_ci(const char *haystack, size_t length, const char *needle, size_t start)
{
    size_t n = strlen(needle);
    if (!n || start > length || n > length - start) return length;
    for (size_t i = start; i + n <= length; ++i)
        if (equal_ci_n(haystack + i, n, needle)) return i;
    return length;
}

static int parse_tag(const char *tag, size_t length, size_t *name_start,
                     size_t *name_length, int *closing)
{
    size_t i = 0;
    while (i < length && isspace((unsigned char)tag[i])) ++i;
    *closing = 0;
    if (i < length && tag[i] == '/') { *closing = 1; ++i; }
    while (i < length && isspace((unsigned char)tag[i])) ++i;
    *name_start = i;
    while (i < length && (isalnum((unsigned char)tag[i]) || tag[i] == '-')) ++i;
    *name_length = i - *name_start;
    return *name_length != 0;
}

static void replace_tag_name(char *tag, size_t name_start, size_t old_length,
                             const char *replacement, size_t replacement_length)
{
    if (replacement_length > old_length) return;
    memcpy(tag + name_start, replacement, replacement_length);
    if (old_length > replacement_length)
        memset(tag + name_start + replacement_length, ' ', old_length - replacement_length);
}

static int css_known_property(const char *name, size_t n)
{
    static const char *const properties[] = {
        "color", "background", "background-color", "font", "font-family", "font-size",
        "font-style", "font-weight", "text-align", "text-decoration", "text-transform",
        "white-space", "display", "visibility", "width", "height", "max-width", "min-width",
        "margin", "margin-top", "margin-right", "margin-bottom", "margin-left", "padding",
        "padding-top", "padding-right", "padding-bottom", "padding-left", "border", "border-color",
        "border-width", "border-style", "border-radius", "line-height", "overflow", "position",
        "top", "left", "right", "bottom", "float", "clear", "opacity", "vertical-align"
    };
    for (size_t i = 0; i < sizeof(properties) / sizeof(properties[0]); ++i)
        if (equal_ci_n(name, n, properties[i])) return 1;
    return 0;
}

static void analyze_declarations(const char *css, size_t length, XwXuteReport *report)
{
    size_t pos = 0;
    while (pos < length) {
        size_t start, colon, end, a, b;
        while (pos < length && (isspace((unsigned char)css[pos]) || css[pos] == ';')) ++pos;
        if (pos >= length) break;
        start = pos; colon = pos;
        while (colon < length && css[colon] != ':' && css[colon] != ';' && css[colon] != '}') ++colon;
        if (colon >= length || css[colon] != ':') { pos = colon < length ? colon + 1u : length; continue; }
        end = colon + 1u;
        while (end < length && css[end] != ';' && css[end] != '}') ++end;
        a = start; b = colon;
        while (a < b && isspace((unsigned char)css[a])) ++a;
        while (b > a && isspace((unsigned char)css[b - 1u])) --b;
        if (b > a) {
            ++report->css_declarations_detected;
            if (css_known_property(css + a, b - a)) ++report->css_properties_recognized;
        }
        pos = end < length && css[end] == ';' ? end + 1u : end;
        if (pos < length && css[pos] == '}') break;
    }
}

static void analyze_css(const char *css, size_t length, XwXuteReport *report)
{
    size_t pos = 0;
    while (pos < length) {
        while (pos < length && isspace((unsigned char)css[pos])) ++pos;
        if (pos + 1u < length && css[pos] == '/' && css[pos + 1u] == '*') {
            size_t end = find_ci(css, length, "*/", pos + 2u);
            pos = end < length ? end + 2u : length;
            continue;
        }
        if (pos >= length) break;
        if (css[pos] == '@') {
            size_t end = pos;
            while (end < length && css[end] != ';' && css[end] != '{') ++end;
            ++report->css_at_rules_detected;
            pos = end < length && css[end] == ';' ? end + 1u : end;
            if (pos < length && css[pos] == '{') {
                unsigned depth = 1u; ++pos;
                while (pos < length && depth) {
                    if (css[pos] == '{') ++depth;
                    else if (css[pos] == '}') --depth;
                    ++pos;
                }
            }
            continue;
        }
        {
            size_t open = pos;
            while (open < length && css[open] != '{' && css[open] != '}') ++open;
            if (open >= length || css[open] != '{') { pos = open < length ? open + 1u : length; continue; }
            ++report->css_rules_detected;
            pos = open + 1u;
            {
                size_t close = pos;
                unsigned depth = 0u;
                while (close < length) {
                    if (css[close] == '{') ++depth;
                    else if (css[close] == '}') {
                        if (depth == 0u) break;
                        --depth;
                    }
                    ++close;
                }
                analyze_declarations(css + pos, close - pos, report);
                pos = close < length ? close + 1u : length;
            }
        }
    }
}

static void analyze_inline_style(const char *tag, size_t length, XwXuteReport *report)
{
    size_t pos = 0;
    while (pos < length) {
        size_t name_start, name_end, value_start, value_end;
        while (pos < length && (isspace((unsigned char)tag[pos]) || tag[pos] == '/' || tag[pos] == '<')) ++pos;
        name_start = pos;
        while (pos < length && (isalnum((unsigned char)tag[pos]) || tag[pos] == '-' || tag[pos] == '_')) ++pos;
        name_end = pos;
        if (name_end == name_start) { ++pos; continue; }
        while (pos < length && isspace((unsigned char)tag[pos])) ++pos;
        if (pos >= length || tag[pos] != '=') continue;
        ++pos;
        while (pos < length && isspace((unsigned char)tag[pos])) ++pos;
        if (pos >= length) break;
        if (tag[pos] == '\'' || tag[pos] == '"') {
            char q = tag[pos++]; value_start = pos;
            while (pos < length && tag[pos] != q) ++pos;
            value_end = pos; if (pos < length) ++pos;
        } else {
            value_start = pos;
            while (pos < length && !isspace((unsigned char)tag[pos]) && tag[pos] != '>') ++pos;
            value_end = pos;
        }
        if (equal_ci_n(tag + name_start, name_end - name_start, "style"))
            analyze_declarations(tag + value_start, value_end - value_start, report);
        if (name_end - name_start > 2u && (tag[name_start] == 'o' || tag[name_start] == 'O') &&
            (tag[name_start + 1u] == 'n' || tag[name_start + 1u] == 'N'))
            ++report->inline_handlers_detected;
    }
}

static int alias_for_tag(const char *name, size_t n, const char **replacement, size_t *replacement_length)
{
    struct Alias { const char *from; const char *to; };
    static const struct Alias aliases[] = {
        {"hgroup", "div"}, {"dialog", "div"}, {"search", "nav"},
        {"menu", "ul"}, {"menuitem", "li"}, {"picture", "div"},
        {"output", "div"}, {"progress", "div"}, {"meter", "div"},
        {"slot", "span"}, {"mark", "span"}, {"time", "span"},
        {"data", "span"}, {"bdi", "span"}, {"bdo", "span"}
    };
    for (size_t i = 0; i < sizeof(aliases) / sizeof(aliases[0]); ++i) {
        if (equal_ci_n(name, n, aliases[i].from)) {
            *replacement = aliases[i].to; *replacement_length = strlen(aliases[i].to); return 1;
        }
    }
    return 0;
}

int xw_xute_process_html(char *html, size_t capacity, size_t *length, XwXuteReport *report)
{
    size_t pos = 0, original_length;
    if (!html || !length || !report || *length > capacity) return -1;
    memset(report, 0, sizeof(*report));
    original_length = *length;
    while (pos < *length) {
        size_t end;
        if (pos + 4u <= *length && memcmp(html + pos, "<!--", 4u) == 0) {
            size_t comment_end = find_ci(html, *length, "-->", pos + 4u);
            pos = comment_end < *length ? comment_end + 3u : *length;
            continue;
        }
        if (html[pos] != '<') { ++pos; continue; }
        end = find_tag_end(html, *length, pos + 1u);
        if (end >= *length) { report->input_truncated = 1; break; }
        {
            size_t name_start, name_length;
            int closing = 0;
            char *tag = html + pos + 1u;
            size_t tag_length = end - pos - 1u;
            if (!parse_tag(tag, tag_length, &name_start, &name_length, &closing)) { pos = end + 1u; continue; }
            if (!closing && equal_ci_n(tag + name_start, name_length, "script")) {
                size_t close_start = find_ci(html, *length, "</script", end + 1u);
                ++report->scripts_detected;
                pos = close_start < *length ? close_start : *length;
                continue;
            }
            if (!closing && equal_ci_n(tag + name_start, name_length, "style")) {
                size_t close_start = find_ci(html, *length, "</style", end + 1u);
                ++report->css_blocks_detected;
                if (close_start < *length) {
                    size_t css_end = find_tag_end(html, *length, close_start + 2u);
                    analyze_css(html + end + 1u, close_start - (end + 1u), report);
                    pos = css_end < *length ? css_end + 1u : *length;
                } else {
                    analyze_css(html + end + 1u, *length - (end + 1u), report);
                    report->input_truncated = 1; pos = *length;
                }
                continue;
            }
            analyze_inline_style(tag, tag_length, report);
            if (!closing) {
                if (equal_ci_n(tag + name_start, name_length, "video")) ++report->video_elements_detected;
                else if (equal_ci_n(tag + name_start, name_length, "audio")) ++report->audio_elements_detected;
                else if (equal_ci_n(tag + name_start, name_length, "canvas")) ++report->canvas_elements_detected;
                else if (equal_ci_n(tag + name_start, name_length, "svg")) ++report->svg_elements_detected;
                else if (equal_ci_n(tag + name_start, name_length, "iframe")) ++report->iframe_elements_detected;
                else if (equal_ci_n(tag + name_start, name_length, "img")) ++report->image_elements_detected;
            }
            {
                const char *replacement = NULL; size_t replacement_length = 0;
                if (alias_for_tag(tag + name_start, name_length, &replacement, &replacement_length)) {
                    replace_tag_name(tag, name_start, name_length, replacement, replacement_length);
                    if (!closing) ++report->html5_elements_translated;
                }
            }
            pos = end + 1u;
        }
    }
    report->bytes_processed = original_length;
    return 0;
}

XwXuteCapability xw_xute_capability(const char *feature)
{
    if (!feature) return XW_XUTE_UNSUPPORTED;
    if (strcmp(feature, "http-1.x") == 0 || strcmp(feature, "html-semantic-core") == 0 ||
        strcmp(feature, "utf8-text") == 0 || strcmp(feature, "dns-a") == 0)
        return XW_XUTE_NATIVE;
    if (strcmp(feature, "html5-semantic-aliases") == 0 || strcmp(feature, "safe-scalar-expressions") == 0)
        return XW_XUTE_TRANSLATED;
    if (strcmp(feature, "css-diagnostics") == 0) return XW_XUTE_NATIVE;
    if (strcmp(feature, "css-cascade") == 0 || strcmp(feature, "javascript-dom") == 0 ||
        strcmp(feature, "https-tls") == 0 || strcmp(feature, "raster-images") == 0 ||
        strcmp(feature, "html-video") == 0 || strcmp(feature, "webgl") == 0 ||
        strcmp(feature, "webassembly") == 0 || strcmp(feature, "service-workers") == 0)
        return XW_XUTE_UNSUPPORTED;
    return XW_XUTE_UNSUPPORTED;
}

const char *xw_xute_capability_name(XwXuteCapability capability)
{
    switch (capability) {
        case XW_XUTE_NATIVE: return "NATIVE";
        case XW_XUTE_TRANSLATED: return "TRANSLATED";
        case XW_XUTE_EMULATED: return "EMULATED";
        default: return "UNSUPPORTED";
    }
}

static int hex_value(char c)
{
    if (c >= '0' && c <= '9') return c - '0';
    c = (char)tolower((unsigned char)c);
    if (c >= 'a' && c <= 'f') return c - 'a' + 10;
    return -1;
}

static int parse_byte_pair(const char *s, unsigned *value)
{
    int a = hex_value(s[0]), b = hex_value(s[1]);
    if (a < 0 || b < 0) return -1;
    *value = (unsigned)(a * 16 + b); return 0;
}

int xw_xute_parse_color(const char *value, uint32_t *argb)
{
    size_t length;
    unsigned r, g, b, a = 255u;
    if (!value || !argb) return -1;
    while (isspace((unsigned char)*value)) ++value;
    length = strlen(value);
    while (length && isspace((unsigned char)value[length - 1u])) --length;
    if (length == 4u && value[0] == '#') {
        int rr = hex_value(value[1]), gg = hex_value(value[2]), bb = hex_value(value[3]);
        if (rr < 0 || gg < 0 || bb < 0) return -1;
        r = (unsigned)(rr * 17); g = (unsigned)(gg * 17); b = (unsigned)(bb * 17);
    } else if (length == 7u && value[0] == '#') {
        if (parse_byte_pair(value + 1u, &r) || parse_byte_pair(value + 3u, &g) || parse_byte_pair(value + 5u, &b)) return -1;
    } else if (length == 5u && value[0] == '#') {
        int rr = hex_value(value[1]), gg = hex_value(value[2]);
        int bb = hex_value(value[3]), aa = hex_value(value[4]);
        if (rr < 0 || gg < 0 || bb < 0 || aa < 0) return -1;
        r = (unsigned)(rr * 17); g = (unsigned)(gg * 17);
        b = (unsigned)(bb * 17); a = (unsigned)(aa * 17);
    } else if (length == 9u && value[0] == '#') {
        /* CSS 8-digit hex is #RRGGBBAA, not the framebuffer's ARGB order. */
        if (parse_byte_pair(value + 1u, &r) || parse_byte_pair(value + 3u, &g) ||
            parse_byte_pair(value + 5u, &b) || parse_byte_pair(value + 7u, &a)) return -1;
    } else if (equal_ci_n(value, length, "black")) r = g = b = 0u;
    else if (equal_ci_n(value, length, "white")) r = g = b = 255u;
    else if (equal_ci_n(value, length, "red")) { r = 255u; g = b = 0u; }
    else if (equal_ci_n(value, length, "green")) { r = 0u; g = 128u; b = 0u; }
    else if (equal_ci_n(value, length, "blue")) { r = g = 0u; b = 255u; }
    else if (equal_ci_n(value, length, "transparent")) { r = g = b = 0u; a = 0u; }
    else return -1;
    *argb = (a << 24) | (r << 16) | (g << 8) | b;
    return 0;
}

int xw_xute_parse_px(const char *value, int *pixels)
{
    char buffer[32]; char *end = NULL; double number;
    size_t length;
    if (!value || !pixels) return -1;
    while (isspace((unsigned char)*value)) ++value;
    length = strlen(value);
    while (length && isspace((unsigned char)value[length - 1u])) --length;
    if (length >= sizeof(buffer) || !length) return -1;
    if (length >= 2u && tolower((unsigned char)value[length - 2u]) == 'p' &&
        tolower((unsigned char)value[length - 1u]) == 'x') length -= 2u;
    else if (!(length == 1u && value[0] == '0')) return -1;
    if (!length || length >= sizeof(buffer)) return -1;
    memcpy(buffer, value, length); buffer[length] = '\0';
    number = strtod(buffer, &end);
    if (!end || *end || number < -4096.0 || number > 4096.0 || number != number) return -1;
    *pixels = (int)(number >= 0.0 ? number + 0.5 : number - 0.5);
    return 0;
}

void xw_xute_format_report(const XwXuteReport *report, char *out, size_t capacity)
{
    if (!out || !capacity) return;
    if (!report) { (void)snprintf(out, capacity, "XUTE: sem diagnostico"); return; }
    (void)snprintf(out, capacity,
        "XUTE: HTML5=%u | CSS=%u/%u | JS=%u | IMG=%u | VIDEO=%u | AUDIO=%u",
        (unsigned)report->html5_elements_translated,
        (unsigned)report->css_properties_recognized, (unsigned)report->css_declarations_detected,
        (unsigned)report->scripts_detected, (unsigned)report->image_elements_detected,
        (unsigned)report->video_elements_detected, (unsigned)report->audio_elements_detected);
}
