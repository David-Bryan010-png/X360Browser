/*
 * X360 Web Total 0.13.0 — XUTE compatibility translation layer.
 * The executable is loaded by XeLL as xenon.elf. It owns its UI, input,
 * storage, network polling and browser navigation after XeLL transfers control.
 * HTTPS/TLS, CSS cascade/layout, page JavaScript, raster images and HTML media are not claimed.
 * XUTE only translates selected semantic tags and diagnoses CSS/script/media features.
 */
#include <ctype.h>
#include <stdio.h>
#include <string.h>

#include <console/console.h>
#include <diskio/ata.h>
#include <input/input.h>
#include <libfat/fat.h>
#include <network/network.h>
#include <time/time.h>
#include <usb/usbmain.h>
#include <xenon_soc/xenon_power.h>
#include <xenon_smc/xenon_smc.h>
#include <xenos/xenos.h>
#include <lwip/dhcp.h>
#include <lwip/ip_addr.h>
#include <lwip/timers.h>

#include "xw_config.h"
#include "xw_html.h"
#include "xw_http_client.h"
#include "xw_layout.h"
#include "xw_url.h"
#include "xw_search.h"
#include "xw_dns_client.h"
#include "xw_graphics.h"
#include "xw_recovery.h"
#include "xw_ui.h"
#include "xw_store.h"
#include "xw_xute.h"

#define ADDRESS_CAP 256
#define KEY_ROWS 5
#define KEY_COLS 10
#define HISTORY_MAX 24

static const char keyboard[KEY_ROWS][KEY_COLS + 1] = {
    "1234567890", "QWERTYUIOP", "ASDFGHJKL ", "ZXCVBNM.-_", " /:?&=%+# "
};

static char address[ADDRESS_CAP] = "";
static XwConfig browser_config;
static unsigned key_row;
static unsigned key_col;
static int network_ready;
static int storage_ready;
static int graphics_ready;
static XwGraphics graphics;
static XwHtmlDocument current_document;
static XwXuteReport current_xute_report;
static XwLayout current_layout;
static int current_http_status;
static char ui_message[160];
static unsigned loading_frames;
static unsigned selected_link_index;
static size_t page_scroll;
static unsigned redirect_count;
static XwStoreList history;
static XwStoreList bookmarks;
static unsigned bookmark_selection;
static unsigned history_selection;
static unsigned history_position;
static unsigned settings_item;
static int edit_field = -1;
static char edit_value[ADDRESS_CAP];
static unsigned edit_key_row;
static unsigned edit_key_col;

typedef enum { SCREEN_HOME = 0, SCREEN_LOADING, SCREEN_PAGE, SCREEN_ERROR, SCREEN_SETTINGS, SCREEN_EDIT, SCREEN_BOOKMARKS, SCREEN_DIAGNOSTICS, SCREEN_HISTORY, SCREEN_REBOOT_CONFIRM } Screen;
static Screen screen = SCREEN_HOME;

/* network_init() already performs its own DHCP wait. After initialization,
   pump Ethernet and the complete lwIP timeout queue. The library's legacy
   network_poll() manually advances only a subset of timers. */
extern void enet_poll(struct netif *interface);
static void xw_network_pump(void)
{
    enet_poll(&netif);
    sys_check_timeouts();
}

static void clear_automatic_fallback_address(void)
{
    ip_addr_t zero;
    ip_addr_set_zero(&zero);
    dhcp_stop(&netif);
    netif_set_addr(&netif, &zero, &zero, &zero);
}
static Screen screen_before_settings = SCREEN_HOME;

static void load_browser_config(void)
{
    char recovery_message[160];
    xw_config_defaults(&browser_config);
    if (storage_ready) {
        (void)xw_recovery_load("X360WebTotal/config/browser.ini",
                               "X360WebTotal/data/browser.recovery.0",
                               "X360WebTotal/data/browser.recovery.1",
                               "X360WebTotal/data/browser.factory",
                               &browser_config, recovery_message, sizeof(recovery_message));
        address[0] = '\0';
        (void)snprintf(ui_message, sizeof(ui_message), "%s", recovery_message);
    } else {
        (void)snprintf(ui_message, sizeof(ui_message), "USB nao montado: configuracao temporaria; nenhum acesso a NAND");
    }
    (void)xw_dns_set_servers(browser_config.dns_primary, browser_config.dns_secondary);
    xw_store_list_clear(&history);
    xw_store_list_clear(&bookmarks);
    if (storage_ready) {
        int history_result = xw_store_load("X360WebTotal/data/history.dat", "history", &history);
        int bookmarks_result = xw_store_load("X360WebTotal/data/bookmarks.dat", "bookmarks", &bookmarks);
        unsigned limit = browser_config.history_entries;
        if (limit == 0u || limit > HISTORY_MAX) limit = HISTORY_MAX;
        while (history.count > limit) (void)xw_store_list_remove(&history, 0u);
        if (history_result < 0 || bookmarks_result < 0)
            (void)snprintf(ui_message, sizeof(ui_message), "aviso: historico/favoritos corrompidos; dados invalidos foram ignorados");
        if (history.count) (void)xw_store_save("X360WebTotal/data/history.dat", "history", &history);
    }
    history_position = history.count ? history.count - 1u : 0u;
}

static int save_browser_config(void)
{
    char recovery_message[160];
    if (!storage_ready) {
        (void)snprintf(ui_message, sizeof(ui_message), "USB nao esta montado; configuracao nao foi salva");
        return -1;
    }
    if (xw_recovery_save("X360WebTotal/config/browser.ini",
                         "X360WebTotal/data/browser.recovery.0",
                         "X360WebTotal/data/browser.recovery.1",
                         "X360WebTotal/data/browser.factory",
                         &browser_config, recovery_message, sizeof(recovery_message)) != 0) {
        (void)snprintf(ui_message, sizeof(ui_message), "%s", recovery_message);
        return -1;
    }
    (void)xw_dns_set_servers(browser_config.dns_primary, browser_config.dns_secondary);
    (void)snprintf(ui_message, sizeof(ui_message), "%s", recovery_message);
    return 0;
}

static int apply_static_network_config(void)
{
    ip_addr_t ip, mask, gateway;
    if (ipaddr_aton(browser_config.static_ip, &ip) == 0 ||
        ipaddr_aton(browser_config.netmask, &mask) == 0 ||
        ipaddr_aton(browser_config.gateway, &gateway) == 0)
        return -1;
    dhcp_stop(&netif);
    netif_set_addr(&netif, &ip, &mask, &gateway);
    netif_set_up(&netif);
    return 0;
}

static const char *setting_value(unsigned item)
{
    switch (item) {
        case 0: return browser_config.network_mode;
        case 1: return browser_config.static_ip;
        case 2: return browser_config.netmask;
        case 3: return browser_config.gateway;
        case 4: return browser_config.dns_primary;
        case 5: return browser_config.dns_secondary;
        case 6: return browser_config.homepage;
        case 7: {
            static char port_text[8];
            (void)snprintf(port_text, sizeof(port_text), "%u", browser_config.controller_port + 1u);
            return port_text;
        }
        default: return "";
    }
}

static const char *setting_name(unsigned item)
{
    static const char *names[] = {
        "Modo de rede", "Endereco IP", "Mascara de sub-rede", "Gateway",
        "DNS primario", "DNS secundario", "Pagina inicial", "Porta do controle",
        "Salvar configuracoes", "Salvar pagina atual nos favoritos", "Abrir favoritos",
        "Diagnostico do sistema", "Reiniciar o console", "Voltar"
    };
    return item < sizeof(names) / sizeof(names[0]) ? names[item] : "";
}

static void draw_home(void)
{
    if (graphics_ready) {
        const char *network = (network_ready && network_link_up()) ? "LINK ATIVO" : "SEM LINK";
        const char *ip = (network_ready && netif.ip_addr.addr != 0) ? ipaddr_ntoa(&netif.ip_addr) : "0.0.0.0";
        xw_ui_home(&graphics, address, key_row, key_col, network, ip, ui_message);
        return;
    }
    console_set_colors(CONSOLE_COLOR_BLACK, CONSOLE_COLOR_WHITE);
    console_clrscr();
    printf("X360 WEB TOTAL  |  HOME  |  DVDBRN\n");
    printf("================================================================\n\n");
    printf("NAVEGADOR\n");
    printf("Endereco: %.180s\n", address);
    printf("D-pad: teclado | A: inserir | X: apagar | START: abrir\n\n");
    printf("TECLADO VIRTUAL\n");
    for (unsigned r = 0; r < KEY_ROWS; ++r) {
        for (unsigned c = 0; c < KEY_COLS; ++c) {
            if (r == key_row && c == key_col) {
                console_set_colors(CONSOLE_COLOR_BLUE, CONSOLE_COLOR_WHITE);
                printf("[%c]", keyboard[r][c] == ' ' ? '_' : keyboard[r][c]);
                console_set_colors(CONSOLE_COLOR_BLACK, CONSOLE_COLOR_WHITE);
            } else printf(" %c ", keyboard[r][c] == ' ' ? '_' : keyboard[r][c]);
        }
        putchar('\n');
    }
    printf("\nREDE: %s | Modo: %s | IP: %s\n",
           (network_ready && network_link_up()) ? "LINK ATIVO" : "SEM LINK",
           browser_config.network_mode,
           (network_ready && netif.ip_addr.addr != 0) ? ipaddr_ntoa(&netif.ip_addr) : "0.0.0.0");
    printf("HTTP/1.x + DNS configuravel | HTTPS/TLS ainda nao integrado\n");
    printf("Y: CONFIGURACOES | B: HISTORICO | BACK: encerrar\n");
    if (ui_message[0]) printf("\n%s\n", ui_message);
}

static void draw_settings(void)
{
    if (graphics_ready) {
        const char *names[14];
        const char *values[8];
        for (unsigned i = 0; i < 14u; ++i) names[i] = setting_name(i);
        for (unsigned i = 0; i < 8u; ++i) values[i] = setting_value(i);
        xw_ui_settings(&graphics, settings_item, names, values, ui_message);
        return;
    }
    console_set_colors(CONSOLE_COLOR_BLACK, CONSOLE_COLOR_WHITE);
    console_clrscr();
    printf("X360 WEB TOTAL  |  CONFIGURACOES\n");
    printf("================================================================\n");
    printf("REDE E CONTROLE  |  alteracoes salvas no USB\n\n");
    for (unsigned i = 0; i < 14u; ++i) {
        if (i == settings_item) console_set_colors(CONSOLE_COLOR_BLUE, CONSOLE_COLOR_WHITE);
        printf("%c %-25s", i == settings_item ? '>' : ' ', setting_name(i));
        if (i < 8u) printf(" : %s", setting_value(i));
        putchar('\n');
        console_set_colors(CONSOLE_COLOR_BLACK, CONSOLE_COLOR_WHITE);
    }
    printf("\nControles: D-pad selecionar | A editar/alternar | B voltar\n");
    printf("START no editor confirma | X apaga caractere\n");
    printf("Rede: %s | O modo/IP sera aplicado ao reiniciar o aplicativo.\n",
           network_ready ? "interface inicializada" : "sem link");
    if (ui_message[0]) printf("\n%s\n", ui_message);
}

static int edit_is_numeric(void)
{
    return edit_field >= 1 && edit_field <= 5;
}

static void begin_setting_edit(unsigned field)
{
    const char *value = setting_value(field);
    edit_field = (int)field;
    (void)snprintf(edit_value, sizeof(edit_value), "%s", value);
    edit_key_row = 0u;
    edit_key_col = 0u;
    screen = SCREEN_EDIT;
}

static void draw_bookmarks(void)
{
    if (bookmark_selection >= bookmarks.count && bookmarks.count) bookmark_selection = bookmarks.count - 1u;
    if (graphics_ready) {
        xw_ui_bookmarks(&graphics, &bookmarks, bookmark_selection, ui_message);
        return;
    }
    console_set_colors(CONSOLE_COLOR_BLACK, CONSOLE_COLOR_WHITE);
    console_clrscr();
    printf("X360 WEB TOTAL | FAVORITOS\n\n");
    if (!bookmarks.count) printf("Nenhum favorito salvo.\n");
    for (unsigned i = 0; i < bookmarks.count; ++i)
        printf("%c %u. %s\n", i == bookmark_selection ? '>' : ' ', i + 1u, bookmarks.items[i]);
    printf("\nD-pad: selecionar | A: abrir | X: remover | B: voltar\n");
    if (ui_message[0]) printf("%s\n", ui_message);
}

static void draw_history(void)
{
    if (history_selection >= history.count && history.count) history_selection = history.count - 1u;
    if (graphics_ready) {
        xw_ui_history(&graphics, &history, history_selection, ui_message);
        return;
    }
    console_set_colors(CONSOLE_COLOR_BLACK, CONSOLE_COLOR_WHITE);
    console_clrscr();
    printf("X360 WEB TOTAL | HISTORICO\n\n");
    if (!history.count) printf("Nenhuma pagina no historico.\n");
    for (unsigned i = 0; i < history.count; ++i)
        printf("%c %u. %s\n", i == history_selection ? '>' : ' ', i + 1u, history.items[i]);
    printf("\nD-pad: selecionar | A: abrir | X: remover | B: voltar\n");
    if (ui_message[0]) printf("%s\n", ui_message);
}

static void draw_diagnostics(void)
{
    char storage[80], network[80], address_text[96], history_text[80], favorites_text[80];
    char tls_text[80], nand_text[80], engine_text[96];
    const char *lines[8];
    (void)snprintf(storage, sizeof(storage), "USB: %s", storage_ready ? "MONTADO" : "NAO MONTADO");
    (void)snprintf(network, sizeof(network), "REDE: %s", network_ready && network_link_up() ? "LINK ATIVO" : "SEM LINK");
    (void)snprintf(address_text, sizeof(address_text), "IP: %s", (network_ready && netif.ip_addr.addr) ? ipaddr_ntoa(&netif.ip_addr) : "0.0.0.0");
    (void)snprintf(history_text, sizeof(history_text), "HISTORICO LOCAL: %u/%u", history.count, HISTORY_MAX);
    (void)snprintf(favorites_text, sizeof(favorites_text), "FAVORITOS USB: %u/%u", bookmarks.count, XW_STORE_MAX_BOOKMARKS);
    (void)snprintf(tls_text, sizeof(tls_text), "HTTPS/TLS: BLOQUEADO ATE INTEGRACAO E TESTES");
    (void)snprintf(nand_text, sizeof(nand_text), "NAND: NAO VERIFICADA | SEM LEITURA/GRAVACAO");
    xw_xute_format_report(&current_xute_report, engine_text, sizeof(engine_text));
    lines[0] = storage; lines[1] = network; lines[2] = address_text; lines[3] = history_text;
    lines[4] = favorites_text; lines[5] = tls_text; lines[6] = nand_text; lines[7] = engine_text;
    if (graphics_ready) { xw_ui_diagnostics(&graphics, lines); return; }
    console_set_colors(CONSOLE_COLOR_BLACK, CONSOLE_COLOR_WHITE);
    console_clrscr();
    printf("X360 WEB TOTAL | DIAGNOSTICO\n\n");
    for (unsigned i = 0; i < 8u; ++i) printf("%s\n", lines[i]);
    printf("\nB: voltar | BACK: sair\n");
}

static void draw_editor(void)
{
    if (graphics_ready) {
        xw_ui_editor(&graphics, setting_name((unsigned)edit_field), edit_value,
                     edit_key_row, edit_key_col, edit_is_numeric());
        return;
    }
    console_set_colors(CONSOLE_COLOR_BLACK, CONSOLE_COLOR_WHITE);
    console_clrscr();
    printf("X360 WEB TOTAL  |  EDITAR: %s\n", setting_name((unsigned)edit_field));
    printf("================================================================\n\n");
    printf("Valor: %s_\n\n", edit_value);
    for (unsigned r = 0; r < KEY_ROWS; ++r) {
        for (unsigned c = 0; c < KEY_COLS; ++c) {
            char ch = keyboard[r][c];
            if (edit_is_numeric() && !((ch >= '0' && ch <= '9') || ch == '.')) ch = ' ';
            if (r == edit_key_row && c == edit_key_col) {
                console_set_colors(CONSOLE_COLOR_BLUE, CONSOLE_COLOR_WHITE);
                printf("[%c]", ch == ' ' ? '_' : ch);
                console_set_colors(CONSOLE_COLOR_BLACK, CONSOLE_COLOR_WHITE);
            } else printf(" %c ", ch == ' ' ? '_' : ch);
        }
        putchar('\n');
    }
    printf("\nD-pad: escolher | A: inserir | X: apagar | START: confirmar | B: cancelar\n");
}

static void append_edit_char(char ch)
{
    size_t length = strlen(edit_value);
    if (ch == ' ' || (edit_is_numeric() && !((ch >= '0' && ch <= '9') || ch == '.'))) return;
    if (length + 1u < sizeof(edit_value)) {
        edit_value[length] = ch;
        edit_value[length + 1u] = '\0';
    }
}

static int commit_setting_edit(void)
{
    XwConfig candidate = browser_config;
    char validation[XW_CONFIG_MAX_BYTES];
    switch (edit_field) {
        case 1: (void)snprintf(candidate.static_ip,sizeof(candidate.static_ip),"%s",edit_value); break;
        case 2: (void)snprintf(candidate.netmask,sizeof(candidate.netmask),"%s",edit_value); break;
        case 3: (void)snprintf(candidate.gateway,sizeof(candidate.gateway),"%s",edit_value); break;
        case 4: (void)snprintf(candidate.dns_primary,sizeof(candidate.dns_primary),"%s",edit_value); break;
        case 5: (void)snprintf(candidate.dns_secondary,sizeof(candidate.dns_secondary),"%s",edit_value); break;
        case 6: (void)snprintf(candidate.homepage,sizeof(candidate.homepage),"%s",edit_value); break;
        default: return -1;
    }
    if (xw_config_format(&candidate, validation, sizeof(validation)) < 0) {
        (void)snprintf(ui_message,sizeof(ui_message),"valor invalido; use IPv4 ou URL HTTP valida");
        return -1;
    }
    browser_config = candidate;
    edit_field = -1;
    screen = SCREEN_SETTINGS;
    (void)snprintf(ui_message,sizeof(ui_message),"campo atualizado; pressione Salvar configuracoes");
    return 0;
}

static void draw_loading(void)
{
    if (graphics_ready) {
        const char *phase = "PREPARANDO REQUISICAO";
        switch (xw_http_state()) {
            case XW_HTTP_RESOLVING: phase = "DNS: 3 TENTATIVAS POR SERVIDOR, ATE 15 S"; break;
            case XW_HTTP_CONNECTING: phase = "ABRINDO CONEXAO TCP"; break;
            case XW_HTTP_RECEIVING: phase = "RECEBENDO RESPOSTA HTTP"; break;
            default: break;
        }
        xw_ui_loading(&graphics, address, phase);
        return;
    }
    console_set_colors(CONSOLE_COLOR_BLACK, CONSOLE_COLOR_WHITE);
    console_clrscr();
    printf("X360 WEB TOTAL\n");
    printf("Conectando a: %s\n\n", address);
    switch (xw_http_state()) {
        case XW_HTTP_RESOLVING: printf("Resolvendo DNS...\n"); break;
        case XW_HTTP_CONNECTING: printf("Abrindo conexao TCP...\n"); break;
        case XW_HTTP_RECEIVING: printf("Recebendo resposta HTTP...\n"); break;
        default: printf("Preparando requisicao...\n"); break;
    }
    printf("B: cancelar | BACK: sair\n");
}

static int link_block_at(unsigned ordinal, unsigned *block_index)
{
    unsigned found = 0;
    for (size_t i = 0; i < current_document.block_count; ++i) {
        const XwHtmlBlock *block = &current_document.blocks[i];
        if (block->type == XW_BLOCK_LINK && block->href[0] != '\0') {
            if (found == ordinal) {
                if (block_index != NULL) *block_index = (unsigned)i;
                return 1;
            }
            ++found;
        }
    }
    return 0;
}

static unsigned link_count(void)
{
    unsigned count = 0;
    for (size_t i = 0; i < current_document.block_count; ++i)
        if (current_document.blocks[i].type == XW_BLOCK_LINK && current_document.blocks[i].href[0] != '\0') ++count;
    return count;
}

static void draw_document(void)
{
    if (graphics_ready) {
        xw_ui_page(&graphics, address, current_document.title, current_http_status,
                   &current_layout, page_scroll, selected_link_index);
        return;
    }
    unsigned width = 64, height = 32, selected_block = 0;
    size_t visible, end;
    int has_selected = link_block_at(selected_link_index, &selected_block);
    console_get_dimensions(&width, &height);
    if (width < 32 || width > 110) width = 64;
    visible = height > 8 ? (size_t)height - 8u : 1u;
    if (page_scroll > current_layout.line_count) page_scroll = current_layout.line_count;
    end = page_scroll + visible;
    if (end > current_layout.line_count) end = current_layout.line_count;
    console_set_colors(CONSOLE_COLOR_BLACK, CONSOLE_COLOR_WHITE);
    console_clrscr();
    printf("X360 WEB TOTAL  |  HTTP %d\n", current_http_status);
    printf("URL: %.180s\n", address);
    printf("================================================================\n");
    if (current_document.title[0]) printf("Pagina: %.150s\n", current_document.title);
    for (size_t i = page_scroll; i < end; ++i) {
        const XwVisualLine *line = &current_layout.lines[i];
        int active = has_selected && line->source_block == selected_block && line->is_link;
        if (active) console_set_colors(CONSOLE_COLOR_BLUE, CONSOLE_COLOR_WHITE);
        else if (line->is_link) console_set_colors(CONSOLE_COLOR_BLACK, CONSOLE_COLOR_GREEN);
        if (active) printf("> "); else printf("  ");
        for (unsigned spaces = 0; spaces < line->indent; ++spaces) putchar(' ');
        puts(line->text);
        console_set_colors(CONSOLE_COLOR_BLACK, CONSOLE_COLOR_WHITE);
    }
    if (current_document.truncated || current_layout.dropped_lines)
        printf("[Aviso: pagina limitada pela memoria desta versao]\n");
    printf("\n----------------------------------------------------------------\n");
    printf("Links: %u | Scroll: %u/%u\n", link_count(), (unsigned)page_scroll,
           (unsigned)(current_layout.line_count > visible ? current_layout.line_count - visible : 0));
    printf("UP/DOWN: rolar | LEFT/RIGHT: link | A: abrir | LB/X: voltar | RB: avancar | START: recarregar | B: inicio\n");
}

static void draw_error(const char *message)
{
    if (graphics_ready) {
        xw_ui_error(&graphics, address, message);
        return;
    }
    console_set_colors(CONSOLE_COLOR_BLACK, CONSOLE_COLOR_ORANGE);
    console_clrscr();
    printf("X360 WEB TOTAL - FALHA DE NAVEGACAO\n\n");
    printf("URL: %s\n", address);
    printf("Erro: %s\n\n", message ? message : "erro desconhecido");
    printf("B: voltar ao inicio | BACK: sair\n");
    console_set_colors(CONSOLE_COLOR_BLACK, CONSOLE_COLOR_WHITE);
}

static void history_push(const char *url)
{
    unsigned limit = browser_config.history_entries;
    if (limit == 0u || limit > HISTORY_MAX) limit = HISTORY_MAX;
    if (history.count != 0u && strcmp(history.items[history_position], url) == 0) return;
    if (history.count != 0u && history_position + 1u < history.count)
        history.count = history_position + 1u;
    if (history.count >= limit) {
        memmove(history.items, history.items + 1u, sizeof(history.items[0]) * (limit - 1u));
        history.count = limit - 1u;
        if (history_position != 0u) --history_position;
    }
    (void)snprintf(history.items[history.count], sizeof(history.items[0]), "%s", url);
    history_position = history.count;
    ++history.count;
    if (storage_ready && xw_store_save("X360WebTotal/data/history.dat", "history", &history) != 0)
        (void)snprintf(ui_message, sizeof(ui_message), "historico mantido na memoria; falha ao gravar USB");
}

static void add_current_bookmark(void)
{
    XwStoreList candidate = bookmarks;
    int result;
    if (!storage_ready) {
        (void)snprintf(ui_message, sizeof(ui_message), "USB nao montado: favorito nao pode ser salvo");
        return;
    }
    result = xw_store_list_add(&candidate, address, XW_STORE_MAX_BOOKMARKS);
    if (result < 0) (void)snprintf(ui_message, sizeof(ui_message), "URL invalida: favorito nao salvo");
    else if (result == 0) (void)snprintf(ui_message, sizeof(ui_message), "esta pagina ja esta nos favoritos");
    else if (xw_store_save("X360WebTotal/data/bookmarks.dat", "bookmarks", &candidate) != 0)
        (void)snprintf(ui_message, sizeof(ui_message), "falha ao gravar favoritos no USB");
    else {
        bookmarks = candidate;
        (void)snprintf(ui_message, sizeof(ui_message), "pagina adicionada aos favoritos do USB");
    }
}

static void open_settings(void)
{
    screen_before_settings = screen;
    screen = SCREEN_SETTINGS;
    settings_item = 0u;
    draw_settings();
}

static void start_navigation(int record_history)
{
    int result;
    char resolved[ADDRESS_CAP];
    const char *input = address[0] ? address : browser_config.homepage;
    if (xw_search_resolve_input(input, resolved, sizeof(resolved)) != 0) {
        (void)snprintf(ui_message, sizeof(ui_message), "busca vazia ou longa demais; reduza o texto");
        screen = SCREEN_ERROR;
        draw_error(ui_message);
        return;
    }
    (void)snprintf(address, sizeof(address), "%s", resolved);
    if (record_history) history_push(address);
    redirect_count = 0;
    result = xw_http_start(address);
    if (result != 0) {
        (void)snprintf(ui_message, sizeof(ui_message), "%s", xw_http_error());
        screen = SCREEN_ERROR;
        draw_error(ui_message);
        return;
    }
    screen = SCREEN_LOADING;
    loading_frames = 0;
    draw_loading();
}

static void navigate_to(const char *target, int add_history)
{
    if (target == NULL || strlen(target) >= sizeof(address)) {
        (void)snprintf(ui_message, sizeof(ui_message), "endereco de destino muito longo");
        screen = SCREEN_ERROR;
        draw_error(ui_message);
        return;
    }
    (void)snprintf(address, sizeof(address), "%s", target);
    start_navigation(add_history);
}

static void open_selected_link(void)
{
    unsigned block_index;
    XwUrl base;
    char target[XW_URL_INPUT_MAX + 8];
    char effective_base[XW_URL_INPUT_MAX + 8];
    char error[96];
    if (!link_block_at(selected_link_index, &block_index)) {
        (void)snprintf(ui_message, sizeof(ui_message), "esta pagina nao possui link selecionavel");
        return;
    }
    if (xw_url_parse(address, &base, error, sizeof(error)) != 0 ||
        (current_document.base_href[0] &&
         (xw_url_resolve(&base, current_document.base_href, effective_base, sizeof(effective_base)) != 0 ||
          xw_url_parse(effective_base, &base, error, sizeof(error)) != 0)) ||
        xw_url_resolve(&base, current_document.blocks[block_index].href, target, sizeof(target)) != 0) {
        (void)snprintf(ui_message, sizeof(ui_message), "link nao suportado ou endereco relativo invalido");
        screen = SCREEN_ERROR;
        draw_error(ui_message);
        return;
    }
    navigate_to(target, 1);
}

static void history_back(void)
{
    if (history.count < 2u || history_position == 0u) {
        (void)snprintf(ui_message, sizeof(ui_message), "nao ha pagina anterior no historico");
        draw_document();
        return;
    }
    --history_position;
    navigate_to(history.items[history_position], 0);
}

static void history_forward(void)
{
    if (history_position + 1u >= history.count) {
        (void)snprintf(ui_message, sizeof(ui_message), "nao ha proxima pagina no historico");
        draw_document();
        return;
    }
    ++history_position;
    navigate_to(history.items[history_position], 0);
}

static void finish_navigation(void)
{
    unsigned char *body = NULL;
    size_t body_length = 0;
    const char *location;
    if (xw_http_result(&body, &body_length, &current_http_status) != 0) {
        screen = SCREEN_ERROR;
        (void)snprintf(ui_message, sizeof(ui_message), "%s", xw_http_error());
        draw_error(ui_message);
        return;
    }
    if (current_http_status == 301 || current_http_status == 302 || current_http_status == 303 ||
        current_http_status == 307 || current_http_status == 308) {
        char target[XW_URL_INPUT_MAX + 8];
        XwUrl base;
        char error[96];
        location = xw_http_location();
        if (location == NULL || location[0] == '\0' || redirect_count >= 5u ||
            xw_url_parse(address, &base, error, sizeof(error)) != 0 ||
            xw_url_resolve(&base, location, target, sizeof(target)) != 0) {
            screen = SCREEN_ERROR;
            (void)snprintf(ui_message, sizeof(ui_message), "redirecionamento HTTP ausente, invalido ou acima do limite de 5");
            draw_error(ui_message);
            return;
        }
        ++redirect_count;
        (void)snprintf(address, sizeof(address), "%s", target);
        if (xw_http_start(address) != 0) {
            screen = SCREEN_ERROR;
            (void)snprintf(ui_message, sizeof(ui_message), "%s", xw_http_error());
            draw_error(ui_message);
            return;
        }
        screen = SCREEN_LOADING;
        loading_frames = 0;
        draw_loading();
        return;
    }
    if (current_http_status < 200 || current_http_status >= 300) {
        screen = SCREEN_ERROR;
        (void)snprintf(ui_message, sizeof(ui_message), "servidor respondeu HTTP %d", current_http_status);
        draw_error(ui_message);
        return;
    }
    {
        const char *mime = xw_http_content_type();
        int is_plain = 0;
        if (mime != NULL && mime[0] != '\0') {
            char media[96];
            size_t n = strcspn(mime, ";");
            if (n >= sizeof(media)) n = sizeof(media) - 1u;
            memcpy(media, mime, n); media[n] = '\0';
            for (size_t i = 0; media[i]; ++i) media[i] = (char)tolower((unsigned char)media[i]);
            is_plain = strcmp(media, "text/plain") == 0;
            if (!is_plain && strcmp(media, "text/html") != 0 && strcmp(media, "application/xhtml+xml") != 0) {
                screen = SCREEN_ERROR;
                (void)snprintf(ui_message, sizeof(ui_message), "tipo de conteudo nao renderizavel: %.70s", media);
                draw_error(ui_message);
                return;
            }
        }
        memset(&current_xute_report, 0, sizeof(current_xute_report));
        if (!is_plain && xw_xute_process_html((char *)body, body_length, &body_length,
                                               &current_xute_report) != 0) {
            screen = SCREEN_ERROR;
            draw_error("XUTE: falha ao traduzir documento HTML");
            return;
        }
        if ((is_plain ? xw_html_parse_plain_text((const char *)body, body_length, &current_document)
                      : xw_html_parse((const char *)body, body_length, &current_document)) != 0 ||
            xw_layout_build(&current_document, 68, &current_layout) != 0) {
        screen = SCREEN_ERROR;
        draw_error("nao foi possivel interpretar a pagina");
        return;
        }
    }
    selected_link_index = 0;
    page_scroll = 0;
    screen = SCREEN_PAGE;
    draw_document();
}

static void append_key(char c)
{
    size_t n = strlen(address);
    if (n + 1 < sizeof(address)) {
        address[n] = c;
        address[n + 1] = '\0';
    }
}

int main(void)
{
    struct controller_data_s pad, previous;
    int net_result;
    memset(&pad, 0, sizeof(pad));
    memset(&previous, 0, sizeof(previous));
    xenos_init(VIDEO_MODE_AUTO);
    console_set_colors(CONSOLE_COLOR_BLACK, CONSOLE_COLOR_WHITE);
    console_init();
    graphics_ready = (xw_gfx_init_xenos(&graphics) == 0);
    console_clrscr();
    printf("X360 Web Total 0.13.0: navegador autonomo; NAND nao verificada.\n");
    xenon_make_it_faster(XENON_SPEED_FULL);

    printf("Inicializando USB...\n");
    (void)usb_init();
    for (int i = 0; i < 8; ++i) { usb_do_poll(); mdelay(10); }
    printf("Montando armazenamento...\n");
    (void)xenon_ata_init();
    storage_ready = fatInitDefault() ? 1 : 0;
    if (!storage_ready) printf("Aviso: FAT nao foi montado pelo libfat.\n");
    load_browser_config();

    printf("Inicializando rede...\n");
    net_result = network_init();
    if (strcmp(browser_config.network_mode, "static") == 0) {
        network_ready = network_link_up() && apply_static_network_config() == 0 && netif.ip_addr.addr != 0;
    } else if (net_result == NETWORK_INIT_SUCCESS && network_link_up() && netif.ip_addr.addr != 0) {
        network_ready = 1;
        network_print_config();
    } else {
        /* LibXenon's network_init() writes 192.168.1.99 after DHCP failure.
           Do not present that emergency address as a working Internet link. */
        clear_automatic_fallback_address();
        network_ready = 0;
        (void)snprintf(ui_message, sizeof(ui_message),
                       "DHCP falhou: endereco de emergencia removido; verifique cabo/roteador ou use IP estatico correto");
    }
    if (network_ready && strcmp(browser_config.network_mode, "static") == 0)
        printf("Rede configurada manualmente; confirme gateway e DNS.\n");
    else if (!network_ready)
        printf("Rede sem configuracao valida; IP nao significa Internet.\n");

    screen = SCREEN_HOME;
    (void)snprintf(ui_message, sizeof(ui_message), "X360 WEB TOTAL 0.13.0 | NAND NAO VERIFICADA | Y: preferencias | START: pesquisar | controle %u", browser_config.controller_port + 1u);
    draw_home();

    for (;;) {
        int got_pad;
        /* LibXenon requires USB polling continuously; the old build polled only at boot. */
        usb_do_poll();
        xw_network_pump();
        network_ready = network_link_up() && netif.ip_addr.addr != 0;
        xw_http_poll();
        got_pad = get_controller_data(&pad, (int)browser_config.controller_port);
        /* 0 means no fresh HID report. Do not process stale button state as a new event. */
        if (got_pad > 0) {
            int pressed_a = pad.a && !previous.a;
            int pressed_b = pad.b && !previous.b;
            int pressed_x = pad.x && !previous.x;
            int pressed_y = pad.y && !previous.y;
            int pressed_start = pad.start && !previous.start;
            int pressed_back = pad.back && !previous.back;
            int pressed_up = pad.up && !previous.up;
            int pressed_down = pad.down && !previous.down;
            int pressed_left = pad.left && !previous.left;
            int pressed_right = pad.right && !previous.right;
            int pressed_lb = pad.lb && !previous.lb;
            int pressed_rb = pad.rb && !previous.rb;

            if (pressed_back) {
                xw_http_cancel();
                break;
            }
            if (screen == SCREEN_HOME) {
                if (pressed_y) { open_settings(); }
                else if (pressed_b) { history_selection = history_position; screen = SCREEN_HISTORY; draw_history(); }
                else {
                    if (pressed_up) key_row = (key_row + KEY_ROWS - 1u) % KEY_ROWS;
                    if (pressed_down) key_row = (key_row + 1u) % KEY_ROWS;
                    if (pressed_left) key_col = (key_col + KEY_COLS - 1u) % KEY_COLS;
                    if (pressed_right) key_col = (key_col + 1u) % KEY_COLS;
                    if (pressed_a) append_key(keyboard[key_row][key_col]);
                    if (pressed_x) { size_t n = strlen(address); if (n) address[n - 1u] = '\0'; }
                    if (pressed_start) start_navigation(1);
                    if (pressed_a || pressed_x || pressed_up || pressed_down || pressed_left || pressed_right) draw_home();
                }
            } else if (screen == SCREEN_SETTINGS) {
                if (pressed_b || pressed_y) { screen = screen_before_settings; if (screen == SCREEN_PAGE) draw_document(); else if (screen == SCREEN_ERROR) draw_error(ui_message); else draw_home(); }
                else if (pressed_up) { settings_item = (settings_item + 13u) % 14u; draw_settings(); }
                else if (pressed_down) { settings_item = (settings_item + 1u) % 14u; draw_settings(); }
                else if (pressed_a) {
                    if (settings_item == 0u) {
                        (void)snprintf(browser_config.network_mode,sizeof(browser_config.network_mode),"%s",
                            strcmp(browser_config.network_mode,"dhcp")==0 ? "static" : "dhcp");
                        draw_settings();
                    } else if (settings_item >= 1u && settings_item <= 6u) {
                        begin_setting_edit(settings_item); draw_editor();
                    } else if (settings_item == 7u) {
                        browser_config.controller_port = (browser_config.controller_port + 1u) % 4u;
                        draw_settings();
                    } else if (settings_item == 8u) {
                        (void)save_browser_config(); draw_settings();
                    } else if (settings_item == 9u) {
                        add_current_bookmark(); draw_settings();
                    } else if (settings_item == 10u) {
                        bookmark_selection = 0u; screen = SCREEN_BOOKMARKS; draw_bookmarks();
                    } else if (settings_item == 11u) {
                        screen = SCREEN_DIAGNOSTICS; draw_diagnostics();
                    } else if (settings_item == 12u) {
                        screen = SCREEN_REBOOT_CONFIRM;
                        if (graphics_ready) xw_ui_reboot_confirm(&graphics);
                        else { console_clrscr(); printf("REINICIAR O XBOX 360?\nA: confirmar | B: cancelar\n"); }
                    } else if (settings_item == 13u) {
                        screen = screen_before_settings;
                        if (screen == SCREEN_PAGE) draw_document(); else if (screen == SCREEN_ERROR) draw_error(ui_message); else draw_home();
                    }
                }
            } else if (screen == SCREEN_REBOOT_CONFIRM) {
                if (pressed_b) { screen = SCREEN_SETTINGS; draw_settings(); }
                else if (pressed_a) {
                    xw_http_cancel();
                    xenon_smc_power_reboot();
                }
            } else if (screen == SCREEN_EDIT) {
                if (pressed_b) { screen = SCREEN_SETTINGS; edit_field = -1; draw_settings(); }
                else if (pressed_up) { edit_key_row = (edit_key_row + KEY_ROWS - 1u) % KEY_ROWS; draw_editor(); }
                else if (pressed_down) { edit_key_row = (edit_key_row + 1u) % KEY_ROWS; draw_editor(); }
                else if (pressed_left) { edit_key_col = (edit_key_col + KEY_COLS - 1u) % KEY_COLS; draw_editor(); }
                else if (pressed_right) { edit_key_col = (edit_key_col + 1u) % KEY_COLS; draw_editor(); }
                else if (pressed_a) { append_edit_char(keyboard[edit_key_row][edit_key_col]); draw_editor(); }
                else if (pressed_x) { size_t n=strlen(edit_value); if(n) edit_value[n-1u]='\0'; draw_editor(); }
                else if (pressed_start) {
                    if (commit_setting_edit() == 0) draw_settings();
                    else draw_editor();
                }
            } else if (screen == SCREEN_BOOKMARKS) {
                if (pressed_b) { screen = SCREEN_SETTINGS; draw_settings(); }
                else if (pressed_up && bookmarks.count) { bookmark_selection = (bookmark_selection + bookmarks.count - 1u) % bookmarks.count; draw_bookmarks(); }
                else if (pressed_down && bookmarks.count) { bookmark_selection = (bookmark_selection + 1u) % bookmarks.count; draw_bookmarks(); }
                else if (pressed_x && bookmarks.count) {
                    XwStoreList candidate = bookmarks;
                    (void)xw_store_list_remove(&candidate, bookmark_selection);
                    if (!storage_ready || xw_store_save("X360WebTotal/data/bookmarks.dat", "bookmarks", &candidate) != 0)
                        (void)snprintf(ui_message, sizeof(ui_message), "falha ao atualizar favoritos no USB");
                    else {
                        bookmarks = candidate;
                        if (bookmark_selection >= bookmarks.count && bookmark_selection) --bookmark_selection;
                        (void)snprintf(ui_message, sizeof(ui_message), "favorito removido");
                    }
                    draw_bookmarks();
                } else if (pressed_a && bookmarks.count) {
                    (void)snprintf(address, sizeof(address), "%s", bookmarks.items[bookmark_selection]);
                    navigate_to(address, 1);
                }
            } else if (screen == SCREEN_DIAGNOSTICS) {
                if (pressed_b || pressed_y) { screen = SCREEN_SETTINGS; draw_settings(); }
            } else if (screen == SCREEN_HISTORY) {
                if (pressed_b) { screen = SCREEN_HOME; draw_home(); }
                else if (pressed_up && history.count) { history_selection = (history_selection + history.count - 1u) % history.count; draw_history(); }
                else if (pressed_down && history.count) { history_selection = (history_selection + 1u) % history.count; draw_history(); }
                else if (pressed_x && history.count) {
                    XwStoreList candidate = history;
                    (void)xw_store_list_remove(&candidate, history_selection);
                    if (!storage_ready || xw_store_save("X360WebTotal/data/history.dat", "history", &candidate) != 0)
                        (void)snprintf(ui_message, sizeof(ui_message), "falha ao atualizar historico no USB");
                    else {
                        history = candidate;
                        if (history_position > history_selection) --history_position;
                        else if (history_position == history_selection)
                            history_position = history.count ? (history_selection < history.count ? history_selection : history.count - 1u) : 0u;
                        if (history_selection >= history.count && history_selection) --history_selection;
                        (void)snprintf(ui_message, sizeof(ui_message), "entrada removida do historico");
                    }
                    draw_history();
                } else if (pressed_a && history.count) {
                    history_position = history_selection;
                    (void)snprintf(address, sizeof(address), "%s", history.items[history_selection]);
                    navigate_to(address, 0);
                }
            } else if (screen == SCREEN_LOADING) {
                if (pressed_b) { xw_http_cancel(); screen = SCREEN_HOME; draw_home(); }
            } else if (screen == SCREEN_PAGE) {
                unsigned links = link_count();
                if (pressed_y) { open_settings(); }
                else if (pressed_b) { xw_http_cancel(); screen = SCREEN_HOME; draw_home(); }
                else if (pressed_lb || pressed_x) history_back();
                else if (pressed_rb) history_forward();
                else if (pressed_start) navigate_to(address, 0);
                else if (pressed_left && links) { selected_link_index = (selected_link_index + links - 1u) % links; draw_document(); }
                else if (pressed_right && links) { selected_link_index = (selected_link_index + 1u) % links; draw_document(); }
                else if (pressed_a) open_selected_link();
                else if (pressed_up && page_scroll > 0u) { --page_scroll; draw_document(); }
                else if (pressed_down && page_scroll + 1u < current_layout.line_count) { ++page_scroll; draw_document(); }
            } else if (screen == SCREEN_ERROR) {
                if (pressed_y) { open_settings(); }
                else if (pressed_b) { xw_http_cancel(); screen = SCREEN_HOME; draw_home(); }
                else if (pressed_x) history_back();
                else if (pressed_start) start_navigation(0);
            }
            previous = pad;
        }

        if (screen == SCREEN_LOADING) {
            if (xw_http_state() == XW_HTTP_DONE) finish_navigation();
            else if (xw_http_state() == XW_HTTP_FAILED) {
                screen = SCREEN_ERROR;
                (void)snprintf(ui_message, sizeof(ui_message), "%s", xw_http_error());
                draw_error(ui_message);
            } else {
                ++loading_frames;
                if (loading_frames > 1800u) {
                    xw_http_cancel(); screen = SCREEN_ERROR;
                    (void)snprintf(ui_message, sizeof(ui_message), "tempo limite: DNS/TCP nao respondeu em 30 segundos");
                    draw_error(ui_message);
                } else if ((loading_frames % 60u) == 0u) draw_loading();
            }
        }
        mdelay(16);
    }

    console_set_colors(CONSOLE_COLOR_BLACK, CONSOLE_COLOR_WHITE);
    console_clrscr();
    printf("X360 Web Total encerrado.\n");
    xw_gfx_shutdown(&graphics);
    return 0;
}
