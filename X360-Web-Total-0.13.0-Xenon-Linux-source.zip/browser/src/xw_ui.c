#include "xw_ui.h"

#include <stdio.h>
#include <string.h>

/* Modern browser chrome: light surfaces, clear hierarchy, Xbox-green identity. */
#define C_BG       0xFFF1F4F1u
#define C_WHITE    0xFFFFFFFFu
#define C_DARK     0xFF142018u
#define C_TEXT     0xFF17251Cu
#define C_MUTED    0xFF68766Du
#define C_GREEN    0xFF107C10u
#define C_GREEN2   0xFF0C6410u
#define C_PALE     0xFFE6F3E6u
#define C_PANEL    0xFFFFFFFFu
#define C_LINE     0xFFD7E0D8u
#define C_ACCENT     0xFF107C10u
#define C_RED      0xFFB3261Eu
#define C_YELLOW   0xFF7A5200u

static int sx(const XwGraphics *g, int x) { return (int)((long)x * (long)g->width / 1280L); }
static int sy(const XwGraphics *g, int y) { return (int)((long)y * (long)g->height / 720L); }
static int sw(const XwGraphics *g, int w) { return sx(g, w); }
static int sh(const XwGraphics *g, int h) { return sy(g, h); }
static unsigned text_scale(const XwGraphics *g) { return g->width >= 1000u ? 2u : 1u; }
static void rect(XwGraphics *g,int x,int y,int w,int h,uint32_t c){xw_gfx_rect(g,sx(g,x),sy(g,y),sw(g,w),sh(g,h),c);}
static void border(XwGraphics *g,int x,int y,int w,int h,int t,uint32_t c){xw_gfx_border(g,sx(g,x),sy(g,y),sw(g,w),sh(g,h),sx(g,t)>0?sx(g,t):1,c);}
static void line(XwGraphics *g,int x1,int y1,int x2,int y2,uint32_t c){xw_gfx_line(g,sx(g,x1),sy(g,y1),sx(g,x2),sy(g,y2),c);}
static void text(XwGraphics *g,int x,int y,const char *s,uint32_t c){xw_gfx_text(g,sx(g,x),sy(g,y),s,text_scale(g),c);}

static uint32_t mix_color(uint32_t a,uint32_t b,unsigned n,unsigned d)
{
    uint32_t out=0;
    for(unsigned shift=0;shift<=16;shift+=8){
        unsigned av=(a>>shift)&255u,bv=(b>>shift)&255u;
        unsigned v=(av*(d-n)+bv*n)/d;
        out|=v<<shift;
    }
    return 0xFF000000u|out;
}

static void wave(XwGraphics *g,int x0,int y0,int cx,int cy,int x1,int y1,uint32_t color,int thickness)
{
    int px=x0,py=y0;
    for(int i=1;i<=80;++i){
        int t=i,u=80-i;
        int x=(u*u*x0+2*u*t*cx+t*t*x1)/6400;
        int y=(u*u*y0+2*u*t*cy+t*t*y1)/6400;
        for(int k=0;k<thickness;++k)line(g,px,py+k,x,y+k,color);
        px=x;py=y;
    }
}

static void disc(XwGraphics *g,int cx,int cy,int radius,uint32_t color)
{
    for(int y=-radius;y<=radius;++y){
        int xx=0;
        while(xx*xx+y*y<=radius*radius)++xx;
        line(g,cx-xx+1,cy+y,cx+xx-1,cy+y,color);
    }
}

static void triangle(XwGraphics *g,int x1,int y1,int x2,int y2,int x3,int y3,uint32_t color)
{
    int miny=y1<y2?(y1<y3?y1:y3):(y2<y3?y2:y3);
    int maxy=y1>y2?(y1>y3?y1:y3):(y2>y3?y2:y3);
    for(int y=miny;y<=maxy;++y){
        int xs[3],count=0;
        const int px[3]={x1,x2,x3},py[3]={y1,y2,y3};
        for(int e=0;e<3;++e){
            int j=(e+1)%3;
            int ay=py[e],by=py[j];
            if(ay==by)continue;
            if(y<(ay<by?ay:by)||y>=(ay>by?ay:by))continue;
            xs[count++]=px[e]+(int)(((long long)(px[j]-px[e])*(y-ay))/(by-ay));
        }
        if(count>=2){
            if(xs[0]>xs[1]){int t=xs[0];xs[0]=xs[1];xs[1]=t;}
            line(g,xs[0],y,xs[1],y,color);
        }
    }
}

static void cloud(XwGraphics *g,int x,int y,uint32_t color)
{
    disc(g,x,y+8,12,color);
    disc(g,x+14,y+1,16,color);
    disc(g,x+33,y+8,12,color);
    rect(g,x-2,y+7,38,13,color);
}

static void paint_hero(XwGraphics *g)
{
    /* Low-cost, locally drawn landscape: no image download or extra texture memory. */
    for(int y=174;y<440;y+=4){
        unsigned n=(unsigned)(y-174),d=265u;
        uint32_t c=mix_color(0xFF214A32u,0xFFC9DDC8u,n,d);
        rect(g,30,y,1220,4,c);
    }
    disc(g,1082,248,58,0xFFE7DDBAu);
    disc(g,1082,248,43,0xFFF2E9C9u);
    cloud(g,260,222,0xFFE7F0EDu);
    cloud(g,740,195,0xFFDCE9E6u);
    triangle(g,30,440,345,273,690,440,0xFF426F4Bu);
    triangle(g,410,440,805,249,1250,440,0xFF315E3Du);
    triangle(g,30,440,270,335,540,440,0xFF789A70u);
    triangle(g,600,440,920,327,1250,440,0xFF658B60u);
    rect(g,30,412,1220,28,0xFF456D5D);
    /* Fine contour lines add depth without pretending to be live page imagery. */
    wave(g,50,421,420,393,770,422,0xFFA9C69Au,2);
    wave(g,610,424,920,397,1230,425,0xFFB4CDA6u,2);
}

static void toolbar_button(XwGraphics *g,int x,const char *glyph,int active)
{
    uint32_t fill=active?C_PALE:0xFFF5F7F5u;
    rect(g,x,69,42,42,fill);
    border(g,x,69,42,42,1,active?0xFFB5D9B0u:C_LINE);
    text(g,x+15,84,glyph,active?C_GREEN:C_TEXT);
}

static void chrome(XwGraphics *g,const char *section,const char *url)
{
    char address_label[104];
    xw_gfx_clear(g,0xFFF3F6F5u);
    rect(g,0,0,1280,54,C_WHITE);
    rect(g,0,0,7,54,C_GREEN);
    disc(g,43,27,17,C_GREEN);
    text(g,37,22,"X",C_WHITE);
    text(g,73,13,"X360 WEB TOTAL",C_TEXT);
    text(g,73,34,"NAVEGADOR PARA XBOX 360",C_MUTED);
    text(g,1105,22,"DVDBRN",C_GREEN);

    rect(g,0,55,1280,69,0xFFFBFCFBu);
    toolbar_button(g,28,"<",0);
    toolbar_button(g,78,">",0);
    toolbar_button(g,128,"R",0);
    toolbar_button(g,178,"H",section&&strcmp(section,"NOVA ABA")==0);
    rect(g,232,69,1018,42,C_WHITE);
    border(g,232,69,1018,42,1,C_LINE);
    disc(g,255,90,7,0xFF5A8B68u);
    line(g,255,83,255,97,C_WHITE);
    line(g,248,90,262,90,C_WHITE);
    (void)snprintf(address_label,sizeof(address_label),"%.90s",url&&url[0]?url:"PESQUISE OU DIGITE UM ENDERECO");
    text(g,278,84,address_label,url&&url[0]?C_TEXT:C_MUTED);

    rect(g,0,125,1280,39,0xFFE9EEEBu);
    rect(g,28,129,270,32,C_WHITE);
    rect(g,28,158,270,3,C_GREEN);
    text(g,46,140,section?section:"NOVA ABA",C_TEXT);
    rect(g,300,129,1,28,C_LINE);
    text(g,320,140,"NAVEGACAO NATIVA",C_MUTED);
}

void xw_ui_home(XwGraphics *g,const char *url,unsigned key_row,unsigned key_col,
                const char *network,const char *ip,const char *message)
{
    static const char keyboard[5][11]={"1234567890","QWERTYUIOP","ASDFGHJKL ","ZXCVBNM.-_"," /:?&=%+# "};
    char linebuf[190];
    if(!g||!g->pixels)return;
    chrome(g,"NOVA ABA",url);

    /* Bing-inspired discovery landing page with Xbox identity. */
    rect(g,30,174,1220,266,C_DARK);
    paint_hero(g);
    text(g,92,211,"DESCUBRA A WEB",C_WHITE);
    text(g,92,244,"PESQUISE. ENCONTRE. NAVEGUE.",0xFFF4F8F5u);
    rect(g,90,294,1100,62,C_WHITE);
    border(g,90,294,1100,62,2,0xFFDAE6DFu);
    (void)snprintf(linebuf,sizeof(linebuf),"%.105s",url&&url[0]?url:"Digite o que deseja pesquisar ou o endereco do site");
    text(g,116,318,linebuf,url&&url[0]?C_TEXT:C_MUTED);
    rect(g,1098,294,92,62,C_GREEN);
    disc(g,1142,322,12,C_WHITE);
    disc(g,1142,322,7,C_GREEN);
    line(g,1150,330,1160,340,C_WHITE);
    text(g,94,377,"PESQUISA WEB CLASSICA  |  MOTOR WIBY",0xFFF2F7F3u);
    rect(g,30,438,1220,2,0xFFD6E4DDu);

    text(g,48,458,"ACESSO RAPIDO",C_TEXT);
    text(g,1040,458,"ATALHOS DO CONTROLE",C_MUTED);

    /* Informational tiles mirror real controls; no decorative tile pretends to be clickable. */
    rect(g,42,482,278,61,C_WHITE);border(g,42,482,278,61,1,C_LINE);rect(g,42,482,5,61,C_GREEN);
    disc(g,72,512,12,0xFFE5F2E6u);text(g,66,507,"W",C_GREEN);
    text(g,94,493,"PESQUISA WEB",C_TEXT);text(g,94,519,"START: PESQUISAR",C_MUTED);

    rect(g,334,482,278,61,C_WHITE);border(g,334,482,278,61,1,C_LINE);rect(g,334,482,5,61,C_ACCENT);
    disc(g,364,512,12,0xFFE5F2E6u);text(g,358,507,"H",C_ACCENT);
    text(g,386,493,"HISTORICO",C_TEXT);text(g,386,519,"B PARA ABRIR",C_MUTED);

    rect(g,626,482,278,61,C_WHITE);border(g,626,482,278,61,1,C_LINE);rect(g,626,482,5,61,0xFFB48A35u);
    disc(g,656,512,12,0xFFFFF2D6u);text(g,650,507,"Y",0xFF8A641E);
    text(g,678,493,"PREFERENCIAS",C_TEXT);text(g,678,519,"Y PARA CONFIGURAR",C_MUTED);

    rect(g,918,482,320,61,C_WHITE);border(g,918,482,320,61,1,C_LINE);rect(g,918,482,5,61,network&&strcmp(network,"LINK ATIVO")==0?C_GREEN:C_YELLOW);
    disc(g,948,512,12,0xFFE7F0E8u);text(g,942,507,"N",C_GREEN);
    text(g,970,493,"ESTADO DA REDE",C_TEXT);
    (void)snprintf(linebuf,sizeof(linebuf),"LINK %.15s",ip?ip:"0.0.0.0");
    text(g,970,519,linebuf,C_MUTED);

    rect(g,42,554,1196,108,C_WHITE);border(g,42,554,1196,108,1,C_LINE);
    text(g,58,563,"TECLADO DO CONTROLE",C_TEXT);
    text(g,300,563,"D-PAD ESCOLHE  |  A INSERE  |  X APAGA",C_MUTED);
    {
        static const int row_offset[5]={0,0,20,40,0};
        for(unsigned r=0;r<5u;++r){
            for(unsigned c=0;c<10u;++c){
                int x=194+(int)c*90+row_offset[r],y=580+(int)r*15;
                int selected=(r==key_row&&c==key_col);
                rect(g,x,y,82,14,selected?C_GREEN:0xFFF0F3F1u);
                if(selected)border(g,x,y,82,14,1,C_GREEN2);
                linebuf[0]=keyboard[r][c]==' '?'_':keyboard[r][c];linebuf[1]='\0';
                text(g,x+37,y+1,linebuf,selected?C_WHITE:C_TEXT);
            }
        }
    }
    rect(g,0,672,1280,48,C_DARK);
    if(message&&message[0]){
        (void)snprintf(linebuf,sizeof(linebuf),"%.178s",message);
        text(g,44,690,linebuf,0xFFFFE4A6u);
    }else{
        text(g,44,690,"START PESQUISAR    B HISTORICO    Y PREFERENCIAS    BACK SAIR",C_WHITE);
        text(g,970,690,"X360 WEB TOTAL  |  0.13.0",0xFFC5DEC7u);
    }
    xw_gfx_present(g);
}

void xw_ui_loading(XwGraphics *g,const char *url,const char *phase)
{
    if(!g||!g->pixels)return;
    chrome(g,"CARREGANDO",url);
    rect(g,190,220,900,250,C_WHITE);border(g,190,220,900,250,1,C_LINE);
    rect(g,190,220,8,250,C_GREEN);
    text(g,238,258,"CONECTANDO",C_GREEN);
    text(g,238,310,phase?phase:"AGUARDE",C_TEXT);
    text(g,238,350,url?url:"",C_MUTED);
    rect(g,238,398,800,8,C_BG);rect(g,238,398,300,8,C_GREEN);
    text(g,238,436,"B CANCELAR   BACK SAIR",C_MUTED);
    xw_gfx_present(g);
}

void xw_ui_page(XwGraphics *g,const char *url,const char *title,int status,
                const XwLayout *layout,size_t scroll,unsigned selected_link)
{
    size_t visible,end;unsigned selected_block=0,links=0;int found=0;char status_text[104];
    if(!g||!g->pixels)return;
    chrome(g,"PAGINA WEB",url);
    rect(g,30,174,1220,478,C_WHITE);border(g,30,174,1220,478,1,C_LINE);
    rect(g,30,174,1220,52,0xFFF7FAF8u);
    rect(g,30,174,5,52,C_GREEN);
    (void)snprintf(status_text,sizeof(status_text),"%.92s",title&&title[0]?title:"PAGINA WEB");
    text(g,52,184,status_text,C_TEXT);
    (void)snprintf(status_text,sizeof(status_text),"HTTP %d   |   %.70s",status,url?url:"");
    text(g,52,204,status_text,status>=200&&status<300?C_GREEN:C_MUTED);
    if(layout){
        for(size_t i=0;i<layout->line_count;++i)if(layout->lines[i].is_link){
            int first_for_block = i == 0u || !layout->lines[i-1u].is_link ||
                layout->lines[i-1u].source_block != layout->lines[i].source_block;
            if(first_for_block){if(links==selected_link){selected_block=layout->lines[i].source_block;found=1;break;}++links;}
        }
        visible=g->height>600u?20u:12u;
        if(scroll>layout->line_count)scroll=layout->line_count;
        end=scroll+visible;if(end>layout->line_count)end=layout->line_count;
        for(size_t i=scroll;i<end;++i){
            const XwVisualLine *l=&layout->lines[i];
            int y=242+(int)(i-scroll)*(g->height>600u?19:22);
            uint32_t color=(found&&l->is_link&&l->source_block==selected_block)?C_GREEN2:(l->is_link?C_ACCENT:C_TEXT);
            if(found&&l->is_link&&l->source_block==selected_block)rect(g,44,y-2,1178,18,C_PALE);
            xw_gfx_text(g,sx(g,56+(int)l->indent*8),sy(g,y),l->text,text_scale(g),color);
        }
    }
    rect(g,28,660,1224,40,C_DARK);
    text(g,44,674,"LB VOLTAR   RB AVANCAR   START RECARREGAR   LEFT/RIGHT LINKS   A ABRIR   B INICIO",C_WHITE);
    xw_gfx_present(g);
}

void xw_ui_error(XwGraphics *g,const char *url,const char *message)
{
    if(!g||!g->pixels)return;
    chrome(g,"PAGINA INDISPONIVEL",url);
    rect(g,150,220,980,260,C_WHITE);border(g,150,220,980,260,1,C_LINE);rect(g,150,220,8,260,C_RED);
    text(g,198,258,"NAO FOI POSSIVEL ABRIR ESTA PAGINA",C_RED);
    text(g,198,310,url?url:"",C_TEXT);text(g,198,356,message?message:"ERRO DE REDE",C_MUTED);
    text(g,198,430,"B VOLTAR AO INICIO   START TENTAR NOVAMENTE",C_GREEN);
    xw_gfx_present(g);
}

void xw_ui_settings(XwGraphics *g,unsigned selected,const char *const names[14],
                    const char *const values[8],const char *message)
{
    char linebuf[220];
    if(!g||!g->pixels)return;
    chrome(g,"PREFERENCIAS",NULL);
    text(g,42,178,"PERSONALIZE O X360 WEB TOTAL",C_GREEN);
    for(unsigned i=0;i<14u;++i){
        int y=210+(int)i*29;uint32_t fill=i==selected?C_PALE:C_WHITE;
        rect(g,40,y,1200,27,fill);if(i==selected){rect(g,40,y,5,27,C_GREEN);border(g,40,y,1200,27,1,C_GREEN);}
        (void)snprintf(linebuf,sizeof(linebuf),"%s",names&&names[i]?names[i]:"");
        text(g,60,y+8,linebuf,C_TEXT);
        if(i<8u&&values&&values[i])text(g,650,y+8,values[i],C_MUTED);
    }
    text(g,44,636,"D-PAD SELECIONAR   A ABRIR   B VOLTAR",C_DARK);
    if(message&&message[0])text(g,44,676,message,C_YELLOW);
    xw_gfx_present(g);
}

void xw_ui_reboot_confirm(XwGraphics *g)
{
    if(!g||!g->pixels)return;
    chrome(g,"REINICIAR CONSOLE",NULL);
    rect(g,190,226,900,260,C_WHITE);border(g,190,226,900,260,1,C_LINE);rect(g,190,226,8,260,C_RED);
    text(g,240,270,"REINICIAR O XBOX 360?",C_RED);
    text(g,240,322,"O console sera reiniciado imediatamente ao confirmar.",C_TEXT);
    text(g,240,356,"Salve qualquer atividade antes de continuar.",C_MUTED);
    rect(g,240,408,220,48,C_RED);text(g,278,426,"A CONFIRMAR",C_WHITE);
    rect(g,484,408,220,48,C_BG);border(g,484,408,220,48,1,C_LINE);text(g,522,426,"B CANCELAR",C_TEXT);
    xw_gfx_present(g);
}

void xw_ui_editor(XwGraphics *g,const char *field,const char *value,unsigned key_row,unsigned key_col,int numeric)
{
    static const char keyboard[5][11]={"1234567890","QWERTYUIOP","ASDFGHJKL ","ZXCVBNM.-_"," /:?&=%+# "};
    char linebuf[180];(void)numeric;if(!g||!g->pixels)return;
    chrome(g,"EDITAR PREFERENCIA",NULL);
    (void)snprintf(linebuf,sizeof(linebuf),"CAMPO: %.120s",field?field:"");text(g,44,180,linebuf,C_GREEN);
    rect(g,40,210,1200,56,C_WHITE);border(g,40,210,1200,56,1,C_LINE);text(g,60,232,value?value:"",C_TEXT);
    for(unsigned r=0;r<5u;++r)for(unsigned c=0;c<10u;++c){int x=42+(int)c*120,y=290+(int)r*48;uint32_t fill=(r==key_row&&c==key_col)?C_GREEN:C_WHITE;rect(g,x,y,108,36,fill);border(g,x,y,108,36,1,C_LINE);linebuf[0]=keyboard[r][c]==' '?'_':keyboard[r][c];linebuf[1]='\0';text(g,x+48,y+13,linebuf,(r==key_row&&c==key_col)?C_WHITE:C_TEXT);}
    text(g,44,602,"D-PAD ESCOLHER   A INSERIR   X APAGAR   START SALVAR   B CANCELAR",C_DARK);xw_gfx_present(g);
}

void xw_ui_bookmarks(XwGraphics *g,const XwStoreList *bookmarks,unsigned selected,const char *message)
{
    char linebuf[190];if(!g||!g->pixels)return;chrome(g,"FAVORITOS",NULL);text(g,42,180,"PAGINAS SALVAS NESTE DISPOSITIVO",C_GREEN);
    if(!bookmarks||!bookmarks->count){text(g,70,242,"NENHUM FAVORITO SALVO",C_MUTED);text(g,70,282,"Abra uma pagina e salve em Preferencias",C_TEXT);}else for(unsigned i=0;i<bookmarks->count;++i){int y=220+(int)i*38;rect(g,40,y,1200,32,i==selected?C_PALE:C_WHITE);if(i==selected)border(g,40,y,1200,32,1,C_GREEN);(void)snprintf(linebuf,sizeof(linebuf),"%u. %.168s",i+1u,bookmarks->items[i]);text(g,58,y+11,linebuf,C_TEXT);}
    text(g,44,636,"UP/DOWN SELECIONAR   A ABRIR   X REMOVER   B VOLTAR",C_DARK);if(message&&message[0])text(g,44,676,message,C_YELLOW);xw_gfx_present(g);
}

void xw_ui_history(XwGraphics *g,const XwStoreList *history,unsigned selected,const char *message)
{
    char linebuf[190];if(!g||!g->pixels)return;chrome(g,"HISTORICO",NULL);text(g,42,180,"PAGINAS VISITADAS RECENTEMENTE",C_GREEN);
    if(!history||!history->count){text(g,70,242,"NENHUM HISTORICO DISPONIVEL",C_MUTED);}else{unsigned first=selected>=12u?selected-11u:0u,last=first+12u;if(last>history->count)last=history->count;for(unsigned i=first;i<last;++i){int y=220+(int)(i-first)*34;rect(g,40,y,1200,29,i==selected?C_PALE:C_WHITE);if(i==selected)border(g,40,y,1200,29,1,C_GREEN);(void)snprintf(linebuf,sizeof(linebuf),"%u. %.168s",i+1u,history->items[i]);text(g,58,y+10,linebuf,C_TEXT);}}
    text(g,44,636,"UP/DOWN SELECIONAR   A ABRIR   X REMOVER   B VOLTAR",C_DARK);if(message&&message[0])text(g,44,676,message,C_YELLOW);xw_gfx_present(g);
}

void xw_ui_diagnostics(XwGraphics *g,const char *const lines[8])
{
    if(!g||!g->pixels)return;
    chrome(g,"DIAGNOSTICO",NULL);
    text(g,42,180,"ESTADO DOS COMPONENTES DO NAVEGADOR",C_GREEN);
    for(unsigned i=0;i<8u;++i){int y=220+(int)i*48;rect(g,40,y,1200,38,C_WHITE);border(g,40,y,1200,38,1,C_LINE);text(g,60,y+13,lines&&lines[i]?lines[i]:"",C_TEXT);}
    text(g,44,668,"B VOLTAR   |   BACK ENCERRAR",C_DARK);xw_gfx_present(g);
}
