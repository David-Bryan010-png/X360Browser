#include "xw_url.h"

#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static int fail(char *error, size_t size, const char *message)
{
    if (error != NULL && size > 0) {
        (void)snprintf(error, size, "%s", message);
    }
    return -1;
}

static int copy_range(char *destination, size_t capacity, const char *begin, size_t length)
{
    if (length + 1 > capacity) return -1;
    memcpy(destination, begin, length);
    destination[length] = '\0';
    return 0;
}

static int equal_ci(const char *a, size_t n, const char *b)
{
    size_t i;
    if (strlen(b) != n) return 0;
    for (i = 0; i < n; ++i)
        if (tolower((unsigned char)a[i]) != tolower((unsigned char)b[i])) return 0;
    return 1;
}

static int parse_port(const char *begin, const char *end, uint16_t *port_out)
{
    unsigned value = 0;
    if (begin == end) return -1;
    for (const char *p = begin; p < end; ++p) {
        if (*p < '0' || *p > '9') return -1;
        {
            unsigned digit = (unsigned)(*p - '0');
            if (value > (65535u - digit) / 10u) return -1;
            value = value * 10u + digit;
        }
    }
    if (value == 0) return -1;
    *port_out = (uint16_t)value;
    return 0;
}

static int valid_domain(const char *host)
{
    size_t label_length = 0, total = strlen(host);
    if (total == 0 || total > 253) return 0;
    for (size_t i = 0; i < total; ++i) {
        unsigned char c = (unsigned char)host[i];
        if (c == '.') {
            if (label_length == 0 || label_length > 63 || host[i - 1] == '-') return 0;
            label_length = 0;
        } else {
            if (!(isalnum(c) || c == '-')) return 0;
            if (label_length == 0 && c == '-') return 0;
            ++label_length;
        }
    }
    if (label_length == 0) return host[total - 1] == '.';
    return label_length <= 63 && host[total - 1] != '-';
}

int xw_url_parse(const char *input, XwUrl *out, char *error, size_t error_size)
{
    char normalized[XW_URL_INPUT_MAX + 8];
    const char *cursor;
    const char *authority_end;
    const char *host_begin;
    const char *host_end;
    const char *path_begin;
    size_t input_length;
    size_t scheme_length;
    uint16_t parsed_port;

    if (out == NULL || input == NULL) return fail(error, error_size, "argumento nulo");
    memset(out, 0, sizeof(*out));
    input_length = strlen(input);
    if (input_length == 0 || input_length > XW_URL_INPUT_MAX)
        return fail(error, error_size, "URL vazia ou longa demais");
    for (size_t i = 0; i < input_length; ++i) {
        unsigned char ch = (unsigned char)input[i];
        if (isspace(ch) || ch < 0x20 || ch == 0x7f)
            return fail(error, error_size, "URL contém espaço ou caractere de controle");
    }

    if (strstr(input, "://") == NULL) {
        if (snprintf(normalized, sizeof(normalized), "http://%s", input) >= (int)sizeof(normalized))
            return fail(error, error_size, "URL longa demais");
    } else {
        if (copy_range(normalized, sizeof(normalized), input, input_length) != 0)
            return fail(error, error_size, "URL longa demais");
    }

    cursor = strstr(normalized, "://");
    if (cursor == NULL) return fail(error, error_size, "esquema inválido");
    scheme_length = (size_t)(cursor - normalized);
    if (scheme_length == 4 && equal_ci(normalized, scheme_length, "http")) {
        memcpy(out->scheme, "http", 5);
        out->port = 80;
        out->tls = 0;
    } else if (scheme_length == 5 && equal_ci(normalized, scheme_length, "https")) {
        memcpy(out->scheme, "https", 6);
        out->port = 443;
        out->tls = 1;
    } else {
        return fail(error, error_size, "somente http e https são reconhecidos");
    }

    host_begin = cursor + 3;
    authority_end = host_begin + strcspn(host_begin, "/?#");
    if (authority_end == host_begin) return fail(error, error_size, "host ausente");
    if (memchr(host_begin, '@', (size_t)(authority_end - host_begin)) != NULL)
        return fail(error, error_size, "credenciais embutidas na URL não são aceitas");

    if (*host_begin == '[') {
        const char *closing = memchr(host_begin, ']', (size_t)(authority_end - host_begin));
        if (closing == NULL) return fail(error, error_size, "IPv6 sem colchete final");
        host_end = closing + 1;
        if (closing == host_begin + 1) return fail(error, error_size, "IPv6 vazio");
        for (const char *p = host_begin + 1; p < closing; ++p) {
            if (!(isxdigit((unsigned char)*p) || *p == ':' || *p == '.'))
                return fail(error, error_size, "endereco IPv6 invalido");
        }
        if (copy_range(out->host, sizeof(out->host), host_begin, (size_t)(host_end - host_begin)) != 0)
            return fail(error, error_size, "host longo demais");
        for (size_t i = 0; out->host[i] != '\0'; ++i)
            out->host[i] = (char)tolower((unsigned char)out->host[i]);
        if (host_end < authority_end) {
            if (*host_end != ':' || parse_port(host_end + 1, authority_end, &parsed_port) != 0)
                return fail(error, error_size, "porta fora do intervalo");
            out->port = parsed_port;
        }
    } else {
        const char *colon = memchr(host_begin, ':', (size_t)(authority_end - host_begin));
        host_end = colon != NULL ? colon : authority_end;
        if (copy_range(out->host, sizeof(out->host), host_begin, (size_t)(host_end - host_begin)) != 0)
            return fail(error, error_size, "host longo demais");
        for (size_t i = 0; out->host[i] != '\0'; ++i)
            out->host[i] = (char)tolower((unsigned char)out->host[i]);
        if (!valid_domain(out->host)) return fail(error, error_size, "host invalido");
        if (colon != NULL) {
            if (parse_port(colon + 1, authority_end, &parsed_port) != 0)
                return fail(error, error_size, "porta fora do intervalo");
            out->port = parsed_port;
        }
    }

    if (out->host[0] == '\0') return fail(error, error_size, "host ausente");
    path_begin = authority_end;
    if (*path_begin == '\0' || *path_begin == '#' || *path_begin == '?') {
        if (*path_begin == '?') {
            if (snprintf(out->path, sizeof(out->path), "/%s", path_begin) >= (int)sizeof(out->path))
                return fail(error, error_size, "caminho longo demais");
        } else {
            memcpy(out->path, "/", 2);
        }
    } else {
        const char *fragment = strchr(path_begin, '#');
        size_t path_length = fragment != NULL ? (size_t)(fragment - path_begin) : strlen(path_begin);
        if (copy_range(out->path, sizeof(out->path), path_begin, path_length) != 0)
            return fail(error, error_size, "caminho longo demais");
    }

    if (error != NULL && error_size > 0) error[0] = '\0';
    return 0;
}


static int build_url(const XwUrl *url, char *output, size_t capacity)
{
    int written;
    uint16_t default_port = url->tls ? 443u : 80u;
    if (url->port == default_port)
        written = snprintf(output, capacity, "%s://%s%s", url->scheme, url->host, url->path);
    else
        written = snprintf(output, capacity, "%s://%s:%u%s", url->scheme, url->host,
                           (unsigned)url->port, url->path);
    return written < 0 || (size_t)written >= capacity ? -1 : 0;
}

static int normalize_reference_path(char *path, size_t capacity)
{
    char input[XW_URL_PATH_MAX];
    char output[XW_URL_PATH_MAX];
    char *query;
    size_t used = 0;
    if (strlen(path) >= sizeof(input)) return -1;
    strcpy(input, path);
    query = strpbrk(input, "?#");
    if (query != NULL) {
        char suffix[XW_URL_PATH_MAX];
        if (strlen(query) >= sizeof(suffix)) return -1;
        strcpy(suffix, query);
        *query = '\0';
        output[0] = '\0';
        /* Normalize the path part first, then append the untouched query/fragment. */
        {
            const char *cursor = input;
            char segments[96][128];
            size_t count = 0;
            while (*cursor) {
                const char *slash;
                size_t n;
                while (*cursor == '/') ++cursor;
                if (!*cursor) break;
                slash = strchr(cursor, '/');
                n = slash ? (size_t)(slash - cursor) : strlen(cursor);
                if (n == 1 && cursor[0] == '.') { }
                else if (n == 2 && cursor[0] == '.' && cursor[1] == '.') { if (count) --count; }
                else if (n) {
                    if (count >= 96 || n >= sizeof(segments[0])) return -1;
                    memcpy(segments[count], cursor, n); segments[count][n] = '\0'; ++count;
                }
                cursor += n;
            }
            if (used + 1 >= capacity) return -1;
            output[used++] = '/';
            for (size_t i = 0; i < count; ++i) {
                size_t n = strlen(segments[i]);
                if (used + n + 1 >= sizeof(output)) return -1;
                memcpy(output + used, segments[i], n); used += n;
                if (i + 1 < count) output[used++] = '/';
            }
            output[used] = '\0';
        }
        if (used + strlen(suffix) + 1 > sizeof(output) || used + strlen(suffix) + 1 > capacity) return -1;
        strcat(output, suffix);
        strcpy(path, output);
        return 0;
    }
    {
        const char *cursor = input;
        char segments[96][128];
        size_t count = 0;
        while (*cursor) {
            const char *slash;
            size_t n;
            while (*cursor == '/') ++cursor;
            if (!*cursor) break;
            slash = strchr(cursor, '/');
            n = slash ? (size_t)(slash - cursor) : strlen(cursor);
            if (n == 1 && cursor[0] == '.') { }
            else if (n == 2 && cursor[0] == '.' && cursor[1] == '.') { if (count) --count; }
            else if (n) {
                if (count >= 96 || n >= sizeof(segments[0])) return -1;
                memcpy(segments[count], cursor, n); segments[count][n] = '\0'; ++count;
            }
            cursor += n;
        }
        output[used++] = '/';
        for (size_t i = 0; i < count; ++i) {
            size_t n = strlen(segments[i]);
            if (used + n + 1 >= sizeof(output)) return -1;
            memcpy(output + used, segments[i], n); used += n;
            if (i + 1 < count) output[used++] = '/';
        }
        output[used] = '\0';
    }
    if (used + 1 > capacity) return -1;
    strcpy(path, output);
    return 0;
}

int xw_url_resolve(const XwUrl *base, const char *reference, char *output, size_t capacity)
{
    char working[XW_URL_INPUT_MAX + 8];
    char base_text[XW_URL_INPUT_MAX + 8];
    char *fragment;
    XwUrl parsed;
    char error[96];
    size_t reference_length;
    if (base == NULL || reference == NULL || output == NULL || capacity == 0) return -1;
    reference_length = strlen(reference);
    if (reference_length == 0 || reference_length > XW_URL_INPUT_MAX) return -1;
    {
        const char *colon = strchr(reference, ':');
        const char *delimiter = strpbrk(reference, "/?#");
        if (colon != NULL && (delimiter == NULL || colon < delimiter) && strstr(reference, "://") == NULL)
            return -1; /* Reject javascript:, mailto:, data: and other active/non-web schemes. */
    }
    if (strstr(reference, "://") != NULL) {
        if (xw_url_parse(reference, &parsed, error, sizeof(error)) != 0) return -1;
        return build_url(&parsed, output, capacity);
    }
    if (reference[0] == '/' && reference[1] == '/') {
        if (snprintf(working, sizeof(working), "%s:%s", base->scheme, reference) >= (int)sizeof(working)) return -1;
        if (xw_url_parse(working, &parsed, error, sizeof(error)) != 0) return -1;
        return build_url(&parsed, output, capacity);
    }
    if (build_url(base, base_text, sizeof(base_text)) != 0) return -1;
    if (reference[0] == '#') {
        /* A fragment-only link targets the same document. */
        return snprintf(output, capacity, "%s", base_text) >= (int)capacity ? -1 : 0;
    }
    if (reference[0] == '?') {
        char *query = strchr(base_text, '?');
        if (query != NULL) *query = '\0';
        /* A query-only reference keeps the complete base path, not its directory. */
        if (snprintf(working, sizeof(working), "%s%s", base_text, reference) >= (int)sizeof(working)) return -1;
    } else if (reference[0] == '/') {
        const char *authority = strstr(base_text, "://");
        char *path_start;
        if (authority == NULL) return -1;
        path_start = strchr((char *)(authority + 3), '/');
        if (path_start == NULL) path_start = base_text + strlen(base_text);
        *path_start = '\0';
        if (snprintf(working, sizeof(working), "%s%s", base_text, reference) >= (int)sizeof(working)) return -1;
    } else {
        char *query = strchr(base_text, '?');
        char *slash;
        if (query != NULL) *query = '\0';
        slash = strrchr(base_text, '/');
        if (slash == NULL) return -1;
        *(slash + 1) = '\0';
        if (snprintf(working, sizeof(working), "%s%s", base_text, reference) >= (int)sizeof(working)) return -1;
    }
    fragment = strchr(working, '#');
    if (fragment != NULL) *fragment = '\0';
    if (xw_url_parse(working, &parsed, error, sizeof(error)) != 0) return -1;
    if (normalize_reference_path(parsed.path, sizeof(parsed.path)) != 0) return -1;
    return build_url(&parsed, output, capacity);
}
