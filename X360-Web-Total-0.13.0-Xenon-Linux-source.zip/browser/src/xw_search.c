#include "xw_search.h"

#include <ctype.h>
#include <string.h>
#include <string.h>

static int prefix_ci(const unsigned char *value, const char *prefix, size_t length)
{
    for (size_t i = 0; i < length; ++i)
        if (tolower(value[i]) != tolower((unsigned char)prefix[i])) return 0;
    return 1;
}

static int append_char(char *out, size_t cap, size_t *used, char c)
{
    if (*used + 1u >= cap) return -1;
    out[(*used)++] = c;
    out[*used] = '\0';
    return 0;
}

static int copy_text(const char *src, char *out, size_t cap)
{
    size_t n = strlen(src);
    if (n + 1u > cap) return -1;
    memcpy(out, src, n + 1u);
    return 0;
}

int xw_search_resolve_input(const char *input, char *output, size_t capacity)
{
    const unsigned char *begin, *end;
    size_t used = 0u;
    int has_space = 0, looks_like_host = 0;
    if (input == NULL || output == NULL || capacity == 0u) return -1;
    output[0] = '\0';
    begin = (const unsigned char *)input;
    while (*begin != '\0' && isspace(*begin)) ++begin;
    end = begin + strlen((const char *)begin);
    while (end > begin && isspace(end[-1])) --end;
    if (end == begin) return -1;
    for (const unsigned char *p = begin; p < end; ++p) {
        if (*p < 0x20u || *p == 0x7fu) return -1;
        if (isspace(*p)) has_space = 1;
        if (*p == '.' || *p == '/' || *p == ':') looks_like_host = 1;
    }

    {
        size_t n = (size_t)(end - begin);
        if ((n >= 7u && prefix_ci(begin, "http://", 7u)) ||
            (n >= 8u && prefix_ci(begin, "https://", 8u))) {
            if (n + 1u > capacity) return -1;
            memcpy(output, begin, n); output[n] = '\0';
            return 0;
        }
        if (!has_space && n >= 4u && prefix_ci(begin, "www.", 4u)) {
            if (capacity < n + 8u) return -1;
            memcpy(output, "http://", 7u); memcpy(output + 7u, begin, n); output[n + 7u] = '\0';
            return 0;
        }
        if (!has_space && looks_like_host) {
            if (capacity < n + 8u) return -1;
            memcpy(output, "http://", 7u); memcpy(output + 7u, begin, n); output[n + 7u] = '\0';
            return 0;
        }
    }

    if (copy_text("http://wiby.me/?q=", output, capacity) != 0) return -1;
    used = strlen(output);
    for (const unsigned char *p = begin; p < end; ++p) {
        unsigned char c = *p;
        if (c == ' ') {
            if (append_char(output, capacity, &used, '+') != 0) return -1;
        } else if (isalnum(c) || c == '-' || c == '_' || c == '.' || c == '~') {
            if (append_char(output, capacity, &used, (char)c) != 0) return -1;
        } else {
            static const char hex[] = "0123456789ABCDEF";
            if (append_char(output, capacity, &used, '%') != 0 ||
                append_char(output, capacity, &used, hex[c >> 4]) != 0 ||
                append_char(output, capacity, &used, hex[c & 15u]) != 0) return -1;
        }
    }
    return 0;
}
