#include "xw_security.h"

/* Revision Expanded: no TLS transport has been linked into the LibXenon build.
   Do not silently downgrade HTTPS to HTTP or accept unverifiable certificates. */
int xw_security_https_supported(void)
{
    return 0;
}

const char *xw_security_https_status(void)
{
    return "HTTPS bloqueado: TLS/CA/clock/entropy ainda nao validados";
}
