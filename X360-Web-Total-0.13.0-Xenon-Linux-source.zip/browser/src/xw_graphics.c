#include "xw_graphics.h"

#include <ctype.h>
#include <stdlib.h>
#include <string.h>

#if defined(XENON)
#include <ppc/cache.h>
#endif

/* Compact 5x7 uppercase font; lowercase input is normalized to uppercase. */
static const unsigned char font_az09[36][7] = {
    {14,17,17,31,17,17,17}, {30,17,17,30,17,17,30}, {14,17,16,16,16,17,14},
    {30,17,17,17,17,17,30}, {31,16,16,30,16,16,31}, {31,16,16,30,16,16,16},
    {14,17,16,23,17,17,15}, {17,17,17,31,17,17,17}, {14,4,4,4,4,4,14},
    {7,2,2,2,18,18,12}, {17,18,20,24,20,18,17}, {16,16,16,16,16,16,31},
    {17,27,21,21,17,17,17}, {17,25,21,19,17,17,17}, {14,17,17,17,17,17,14},
    {30,17,17,30,16,16,16}, {14,17,17,17,21,18,13}, {30,17,17,30,20,18,17},
    {15,16,16,14,1,1,30}, {31,4,4,4,4,4,4}, {17,17,17,17,17,17,14},
    {17,17,17,17,17,10,4}, {17,17,17,21,21,21,10}, {17,17,10,4,10,17,17},
    {17,17,10,4,4,4,4}, {31,1,2,4,8,16,31},
    {14,17,19,21,25,17,14}, {4,12,4,4,4,4,14}, {14,17,1,2,4,8,31},
    {30,1,1,14,1,1,30}, {2,6,10,18,31,2,2}, {31,16,16,30,1,1,30},
    {14,16,16,30,17,17,14}, {31,1,2,4,8,8,8}, {14,17,17,14,17,17,14},
    {14,17,17,15,1,1,14}
};

static const unsigned char *glyph_rows(char ch, unsigned char punctuation[7])
{
    memset(punctuation, 0, 7);
    ch = (char)toupper((unsigned char)ch);
    if (ch >= 'A' && ch <= 'Z') return font_az09[ch - 'A'];
    if (ch >= '0' && ch <= '9') return font_az09[26 + ch - '0'];
    switch (ch) {
        case '.': punctuation[5]=12; punctuation[6]=12; break;
        case ',': punctuation[5]=12; punctuation[6]=8; break;
        case ':': punctuation[2]=12; punctuation[5]=12; break;
        case ';': punctuation[2]=12; punctuation[5]=12; punctuation[6]=8; break;
        case '-': punctuation[3]=14; break;
        case '_': punctuation[6]=31; break;
        case '/': punctuation[0]=1; punctuation[1]=2; punctuation[2]=2; punctuation[3]=4; punctuation[4]=8; punctuation[5]=8; punctuation[6]=16; break;
        case '\\': punctuation[0]=16; punctuation[1]=8; punctuation[2]=8; punctuation[3]=4; punctuation[4]=2; punctuation[5]=2; punctuation[6]=1; break;
        case '?': punctuation[0]=14; punctuation[1]=17; punctuation[2]=1; punctuation[3]=2; punctuation[4]=4; punctuation[6]=4; break;
        case '!': punctuation[0]=4; punctuation[1]=4; punctuation[2]=4; punctuation[3]=4; punctuation[4]=4; punctuation[6]=4; break;
        case '+': punctuation[2]=4; punctuation[3]=31; punctuation[4]=4; break;
        case '=': punctuation[2]=31; punctuation[4]=31; break;
        case '%': punctuation[0]=17; punctuation[1]=2; punctuation[2]=4; punctuation[3]=8; punctuation[4]=17; break;
        case '#': punctuation[1]=10; punctuation[2]=31; punctuation[3]=10; punctuation[4]=31; punctuation[5]=10; break;
        case '(': punctuation[0]=2; punctuation[1]=4; punctuation[2]=8; punctuation[3]=8; punctuation[4]=8; punctuation[5]=4; punctuation[6]=2; break;
        case ')': punctuation[0]=8; punctuation[1]=4; punctuation[2]=2; punctuation[3]=2; punctuation[4]=2; punctuation[5]=4; punctuation[6]=8; break;
        case '[': punctuation[0]=14; punctuation[1]=8; punctuation[2]=8; punctuation[3]=8; punctuation[4]=8; punctuation[5]=8; punctuation[6]=14; break;
        case ']': punctuation[0]=14; punctuation[1]=2; punctuation[2]=2; punctuation[3]=2; punctuation[4]=2; punctuation[5]=2; punctuation[6]=14; break;
        case '\'': punctuation[0]=4; punctuation[1]=4; break;
        case '"': punctuation[0]=10; punctuation[1]=10; break;
        case '*': punctuation[1]=17; punctuation[2]=10; punctuation[3]=4; punctuation[4]=10; punctuation[5]=17; break;
        case '<': punctuation[1]=2; punctuation[2]=4; punctuation[3]=8; punctuation[4]=4; punctuation[5]=2; break;
        case '>': punctuation[1]=8; punctuation[2]=4; punctuation[3]=2; punctuation[4]=4; punctuation[5]=8; break;
        case '|': punctuation[0]=4; punctuation[1]=4; punctuation[2]=4; punctuation[3]=4; punctuation[4]=4; punctuation[5]=4; punctuation[6]=4; break;
        case ' ': break;
        default: punctuation[0]=14; punctuation[1]=17; punctuation[2]=1; punctuation[3]=2; punctuation[4]=4; punctuation[6]=4; break;
    }
    return punctuation;
}

int xw_gfx_init_memory(XwGraphics *gfx, unsigned width, unsigned height)
{
    size_t count;
    if (!gfx || width < 160u || height < 120u || width > 1920u || height > 1080u) return -1;
    count = (size_t)width * (size_t)height;
    if (count > (size_t)1920u * 1080u) return -1;
    memset(gfx, 0, sizeof(*gfx));
    gfx->pixels = (uint32_t *)calloc(count, sizeof(uint32_t));
    if (!gfx->pixels) return -1;
    gfx->width = width;
    gfx->height = height;
    gfx->owns_pixels = 1u;
    return 0;
}

#if defined(XENON)
struct xw_ati_info {
    uint32_t unknown1[4];
    uint32_t base;
    uint32_t unknown2[8];
    uint32_t width;
    uint32_t height;
} __attribute__((packed));
#endif

int xw_gfx_init_xenos(XwGraphics *gfx)
{
#if defined(XENON)
    struct xw_ati_info *info = (struct xw_ati_info *)(uintptr_t)0xec806100u;
    if (!info || info->base == 0u || info->width < 320u || info->height < 240u) return -1;
    if (xw_gfx_init_memory(gfx, info->width, info->height) != 0) return -1;
    gfx->scanout = (uint32_t *)(uintptr_t)(info->base | 0x80000000u);
    return 0;
#else
    (void)gfx;
    return -1;
#endif
}

void xw_gfx_shutdown(XwGraphics *gfx)
{
    if (!gfx) return;
    if (gfx->owns_pixels) free(gfx->pixels);
    memset(gfx, 0, sizeof(*gfx));
}

void xw_gfx_clear(XwGraphics *gfx, uint32_t color)
{
    size_t count;
    if (!gfx || !gfx->pixels) return;
    count = (size_t)gfx->width * gfx->height;
    for (size_t i = 0; i < count; ++i) gfx->pixels[i] = color;
}

void xw_gfx_rect(XwGraphics *gfx, int x, int y, int width, int height, uint32_t color)
{
    int x0, y0, x1, y1;
    if (!gfx || !gfx->pixels || width <= 0 || height <= 0) return;
    x0 = x < 0 ? 0 : x; y0 = y < 0 ? 0 : y;
    x1 = x + width; y1 = y + height;
    if (x1 > (int)gfx->width) x1 = (int)gfx->width;
    if (y1 > (int)gfx->height) y1 = (int)gfx->height;
    if (x0 >= x1 || y0 >= y1) return;
    for (int row = y0; row < y1; ++row) {
        uint32_t *dst = gfx->pixels + (size_t)row * gfx->width + (unsigned)x0;
        for (int col = x0; col < x1; ++col) *dst++ = color;
    }
}

void xw_gfx_border(XwGraphics *gfx, int x, int y, int width, int height, int thickness, uint32_t color)
{
    if (thickness < 1) return;
    xw_gfx_rect(gfx, x, y, width, thickness, color);
    xw_gfx_rect(gfx, x, y + height - thickness, width, thickness, color);
    xw_gfx_rect(gfx, x, y, thickness, height, color);
    xw_gfx_rect(gfx, x + width - thickness, y, thickness, height, color);
}

void xw_gfx_line(XwGraphics *gfx, int x0, int y0, int x1, int y1, uint32_t color)
{
    int dx = abs(x1 - x0), sx = x0 < x1 ? 1 : -1;
    int dy = -abs(y1 - y0), sy = y0 < y1 ? 1 : -1;
    int err = dx + dy;
    if (!gfx || !gfx->pixels) return;
    for (;;) {
        if (x0 >= 0 && y0 >= 0 && x0 < (int)gfx->width && y0 < (int)gfx->height)
            gfx->pixels[(size_t)y0 * gfx->width + (unsigned)x0] = color;
        if (x0 == x1 && y0 == y1) break;
        { int e2 = 2 * err; if (e2 >= dy) { err += dy; x0 += sx; } if (e2 <= dx) { err += dx; y0 += sy; } }
    }
}

void xw_gfx_text(XwGraphics *gfx, int x, int y, const char *text, unsigned scale, uint32_t color)
{
    unsigned char punctuation[7];
    int cursor;
    if (!gfx || !gfx->pixels || !text) return;
    if (scale < 1u) scale = 1u;
    if (scale > 4u) scale = 4u;
    cursor = x;
    while (*text) {
        const unsigned char *rows = glyph_rows(*text++, punctuation);
        for (int gy = 0; gy < 7; ++gy) {
            for (int gx = 0; gx < 5; ++gx) {
                if (rows[gy] & (1u << (4 - gx)))
                    xw_gfx_rect(gfx, cursor + gx * (int)scale, y + gy * (int)scale,
                                (int)scale, (int)scale, color);
            }
        }
        cursor += 6 * (int)scale;
        if (cursor >= (int)gfx->width) break;
    }
}

size_t xw_gfx_tiled_offset(unsigned padded_width, unsigned x, unsigned y)
{
    return (size_t)((((y >> 5) * 32u * padded_width + ((x >> 5) << 10) +
        (x & 3u) + ((y & 1u) << 2) + (((x & 31u) >> 2) << 3) +
        (((y & 31u) >> 1) << 6)) ^ ((y & 8u) << 2)));
}

void xw_gfx_present(XwGraphics *gfx)
{
    if (!gfx || !gfx->pixels || !gfx->scanout) return;
    unsigned padded_width = (gfx->width + 31u) & ~31u;
#if defined(XENON)
    unsigned padded_height = (gfx->height + 31u) & ~31u;
#endif
    for (unsigned y = 0; y < gfx->height; ++y) {
        const uint32_t *src = gfx->pixels + (size_t)y * gfx->width;
        for (unsigned x = 0; x < gfx->width; ++x)
            gfx->scanout[xw_gfx_tiled_offset(padded_width, x, y)] = src[x];
    }
#if defined(XENON)
    memdcbst(gfx->scanout, (int)((size_t)padded_width * padded_height * sizeof(uint32_t)));
#endif
}
