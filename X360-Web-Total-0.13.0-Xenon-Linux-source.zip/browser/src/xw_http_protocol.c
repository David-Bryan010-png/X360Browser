#include "xw_http_protocol.h"

#include <ctype.h>
#include <errno.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static int set_error(char *out, size_t capacity, const char *message)
{
    if (out != NULL && capacity != 0) (void)snprintf(out, capacity, "%s", message);
    return -1;
}

static const unsigned char *find_bytes(const unsigned char *data, size_t length,
                                       const char *needle, size_t needle_length)
{
    size_t i;
    if (needle_length > length) return NULL;
    for (i = 0; i <= length - needle_length; ++i)
        if (memcmp(data + i, needle, needle_length) == 0) return data + i;
    return NULL;
}

static int ci_equal_n(const char *a, size_t length, const char *b)
{
    size_t i;
    if (strlen(b) != length) return 0;
    for (i = 0; i < length; ++i)
        if (tolower((unsigned char)a[i]) != tolower((unsigned char)b[i])) return 0;
    return 1;
}

static void trim_range(const unsigned char **value, size_t *length)
{
    while (*length && (**value == ' ' || **value == '\t')) { ++*value; --*length; }
    while (*length && ((*value)[*length - 1] == ' ' || (*value)[*length - 1] == '\t')) --*length;
}

static int copy_header_value(char *out, size_t capacity,
                             const unsigned char *value, size_t length)
{
    if (capacity == 0 || length >= capacity) return -1;
    memcpy(out, value, length);
    out[length] = '\0';
    return 0;
}

static int is_token_char(unsigned char c)
{
    if (isalnum(c)) return 1;
    return strchr("!#$%&'*+-.^_`|~", c) != NULL;
}

static int parse_decimal_size(const unsigned char *value, size_t length, size_t *result)
{
    size_t number = 0;
    if (length == 0) return -1;
    for (size_t i = 0; i < length; ++i) {
        unsigned digit;
        if (value[i] < '0' || value[i] > '9') return -1;
        digit = (unsigned)(value[i] - '0');
        if (number > (SIZE_MAX - digit) / 10u) return -1;
        number = number * 10u + digit;
    }
    *result = number;
    return 0;
}

static int parse_status_line(const unsigned char *line, size_t length, int *status)
{
    int code;
    if (length < 12 || memcmp(line, "HTTP/1.", 7) != 0 ||
        (line[7] != '0' && line[7] != '1') || line[8] != ' ' ||
        line[9] < '0' || line[9] > '9' ||
        line[10] < '0' || line[10] > '9' ||
        line[11] < '0' || line[11] > '9' ||
        (length > 12 && line[12] != ' ')) return -1;
    code = (line[9] - '0') * 100 + (line[10] - '0') * 10 + line[11] - '0';
    if (code < 100 || code > 599) return -1;
    *status = code;
    return 0;
}

static int parse_headers(const unsigned char *data, size_t length, XwHttpHeaders *headers)
{
    const unsigned char *line_end = find_bytes(data, length, "\r\n", 2);
    size_t position;
    if (line_end == NULL || parse_status_line(data, (size_t)(line_end - data), &headers->status_code) != 0)
        return -1;
    position = (size_t)(line_end - data) + 2;
    while (position + 1 < length) {
        size_t end = position;
        const unsigned char *colon;
        const unsigned char *value;
        size_t name_length, value_length;
        while (end + 1 < length && !(data[end] == '\r' && data[end + 1] == '\n')) ++end;
        if (end + 1 >= length) return -1;
        if (end == position) return end + 2 == length ? 0 : -1;
        colon = memchr(data + position, ':', end - position);
        if (colon == NULL) return -1;
        name_length = (size_t)(colon - (data + position));
        if (name_length == 0) return -1;
        for (size_t i = 0; i < name_length; ++i)
            if (!is_token_char(data[position + i])) return -1;
        value = colon + 1;
        value_length = end - (size_t)(value - data);
        for (size_t i = 0; i < value_length; ++i)
            if ((value[i] < 0x20 && value[i] != '\t') || value[i] == 0x7f) return -1;
        trim_range(&value, &value_length);

        if (ci_equal_n((const char *)data + position, name_length, "content-length")) {
            size_t parsed;
            if (parse_decimal_size(value, value_length, &parsed) != 0) return -1;
            if (headers->has_content_length && headers->content_length != parsed) return -1;
            headers->content_length = parsed;
            headers->has_content_length = 1;
        } else if (ci_equal_n((const char *)data + position, name_length, "transfer-encoding")) {
            if (!ci_equal_n((const char *)value, value_length, "chunked")) return -1;
            if (headers->chunked) return -1;
            headers->chunked = 1;
        } else if (ci_equal_n((const char *)data + position, name_length, "content-type")) {
            if (copy_header_value(headers->content_type, sizeof(headers->content_type), value, value_length) != 0) return -1;
        } else if (ci_equal_n((const char *)data + position, name_length, "content-encoding")) {
            if (copy_header_value(headers->content_encoding, sizeof(headers->content_encoding), value, value_length) != 0) return -1;
        } else if (ci_equal_n((const char *)data + position, name_length, "location")) {
            if (copy_header_value(headers->location, sizeof(headers->location), value, value_length) != 0) return -1;
        }
        position = end + 2;
    }
    return -1;
}

static int parse_hex_size(const unsigned char *line, size_t length, size_t *chunk_size)
{
    size_t value = 0, digits = 0;
    for (size_t i = 0; i < length; ++i) {
        unsigned char c = line[i];
        unsigned digit;
        if (c == ';') break;
        if (c >= '0' && c <= '9') digit = (unsigned)(c - '0');
        else if (c >= 'a' && c <= 'f') digit = (unsigned)(c - 'a' + 10);
        else if (c >= 'A' && c <= 'F') digit = (unsigned)(c - 'A' + 10);
        else return -1;
        if (value > (SIZE_MAX - digit) / 16u) return -1;
        value = value * 16u + digit;
        ++digits;
    }
    if (digits == 0) return -1;
    *chunk_size = value;
    return 0;
}

static int decode_chunked(const unsigned char *source, size_t length,
                          unsigned char *output, size_t capacity, size_t *output_length)
{
    size_t position = 0, used = 0;
    while (position < length) {
        size_t line_end = position, chunk_size;
        while (line_end + 1 < length && !(source[line_end] == '\r' && source[line_end + 1] == '\n')) ++line_end;
        if (line_end + 1 >= length || parse_hex_size(source + position, line_end - position, &chunk_size) != 0)
            return -1;
        position = line_end + 2;
        if (chunk_size == 0) {
            /* Consume trailer fields without accepting malformed framing. */
            while (position + 1 < length) {
                size_t trailer_end = position;
                const unsigned char *colon;
                while (trailer_end + 1 < length && !(source[trailer_end] == '\r' && source[trailer_end + 1] == '\n')) ++trailer_end;
                if (trailer_end + 1 >= length) return -1;
                if (trailer_end == position) {
                    if (trailer_end + 2u != length) return -1;
                    *output_length = used;
                    return 0;
                }
                colon = memchr(source + position, ':', trailer_end - position);
                if (colon == NULL || colon == source + position) return -1;
                for (const unsigned char *name = source + position; name < colon; ++name)
                    if (!is_token_char(*name)) return -1;
                for (size_t i = (size_t)(colon + 1 - (source + position)); i < trailer_end - position; ++i)
                    if ((source[position + i] < 0x20 && source[position + i] != '\t') || source[position + i] == 0x7f)
                        return -1;
                position = trailer_end + 2u;
            }
            return -1;
        }
        if (chunk_size > capacity - used || chunk_size > length - position) return -1;
        memcpy(output + used, source + position, chunk_size);
        used += chunk_size;
        position += chunk_size;
        if (position + 2 > length || source[position] != '\r' || source[position + 1] != '\n') return -1;
        position += 2;
    }
    return -1;
}

int xw_http_decode_response(const unsigned char *raw, size_t raw_length,
                            XwHttpHeaders *headers,
                            unsigned char *output, size_t output_capacity,
                            size_t *output_length,
                            char *error, size_t error_capacity)
{
    const unsigned char *separator;
    size_t header_length, body_length;
    XwHttpHeaders local;
    if (raw == NULL || headers == NULL || output == NULL || output_length == NULL)
        return set_error(error, error_capacity, "argumento nulo");
    *output_length = 0;
    memset(&local, 0, sizeof(local));
    separator = find_bytes(raw, raw_length, "\r\n\r\n", 4);
    if (separator == NULL) return set_error(error, error_capacity, "cabecalho HTTP incompleto");
    header_length = (size_t)(separator - raw) + 4;
    if (header_length > XW_HTTP_HEADER_BYTES) return set_error(error, error_capacity, "cabecalho HTTP grande demais");
    if (parse_headers(raw, header_length, &local) != 0)
        return set_error(error, error_capacity, "cabecalho HTTP invalido ou ambiguo");
    if (local.chunked && local.has_content_length)
        return set_error(error, error_capacity, "resposta HTTP ambigua: chunked e Content-Length juntos");
    if (local.content_encoding[0] != '\0' && !ci_equal_n(local.content_encoding, strlen(local.content_encoding), "identity"))
        return set_error(error, error_capacity, "Content-Encoding comprimido nao e suportado");
    body_length = raw_length - header_length;
    if (local.chunked) {
        if (decode_chunked(separator + 4, body_length, output, output_capacity, output_length) != 0)
            return set_error(error, error_capacity, "corpo chunked invalido ou grande demais");
    } else {
        if (local.has_content_length) {
            if (local.content_length > body_length)
                return set_error(error, error_capacity, "corpo HTTP incompleto");
            if (local.content_length < body_length)
                return set_error(error, error_capacity, "dados excedentes depois do Content-Length");
            body_length = local.content_length;
        }
        if (body_length > output_capacity) return set_error(error, error_capacity, "pagina excede limite de memoria");
        if (body_length != 0) memcpy(output, separator + 4, body_length);
        *output_length = body_length;
    }
    *headers = local;
    if (error != NULL && error_capacity != 0) error[0] = '\0';
    return 0;
}
