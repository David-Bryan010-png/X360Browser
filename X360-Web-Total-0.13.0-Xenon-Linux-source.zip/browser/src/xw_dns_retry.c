#include "xw_dns_retry.h"

#include <string.h>

void xw_dns_retry_begin(XwDnsRetry *state, uint64_t now_ms)
{
    if (state == NULL) return;
    memset(state, 0, sizeof(*state));
    state->last_attempt_ms = now_ms;
    state->attempts_on_server = 1u;
    state->server_index = 0u;
    state->active = 1u;
}

XwDnsRetryAction xw_dns_retry_advance(XwDnsRetry *state, uint64_t now_ms)
{
    if (state == NULL || !state->active || now_ms < state->last_attempt_ms)
        return XW_DNS_RETRY_FAILED;
    if (now_ms - state->last_attempt_ms < XW_DNS_RETRY_INTERVAL_MS)
        return XW_DNS_RETRY_WAIT;
    state->last_attempt_ms = now_ms;
    if (state->attempts_on_server < XW_DNS_ATTEMPTS_PER_SERVER) {
        ++state->attempts_on_server;
        return XW_DNS_RETRY_SEND;
    }
    if (state->server_index == 0u) {
        state->server_index = 1u;
        state->attempts_on_server = 1u;
        return XW_DNS_RETRY_SWITCH_SERVER;
    }
    state->active = 0u;
    return XW_DNS_RETRY_FAILED;
}
