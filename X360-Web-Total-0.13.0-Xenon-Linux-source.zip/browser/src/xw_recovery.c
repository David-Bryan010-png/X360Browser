#include "xw_recovery.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define RECOVERY_MAX_BYTES XW_CONFIG_MAX_BYTES
#define RECOVERY_HEADER_MAX 80u

typedef struct {
    unsigned sequence;
    size_t length;
    char data[RECOVERY_MAX_BYTES];
    int valid;
} RecoverySlot;

static unsigned crc32_bytes(const unsigned char *data, size_t length)
{
    unsigned crc = 0xFFFFFFFFu;
    for (size_t i = 0; i < length; ++i) {
        crc ^= data[i];
        for (unsigned bit = 0; bit < 8u; ++bit)
            crc = (crc >> 1) ^ (0xEDB88320u & (unsigned)-(int)(crc & 1u));
    }
    return ~crc;
}

static int read_file(const char *path, char *data, size_t capacity, size_t *length)
{
    FILE *f;
    size_t n;
    int extra;
    if (!path || !data || !length) return -1;
    f = fopen(path, "rb");
    if (!f) return -1;
    n = fread(data, 1u, capacity, f);
    extra = fgetc(f);
    { int failed = ferror(f) || extra != EOF; if (fclose(f) != 0) failed = 1; if (failed) return -1; }
    *length = n;
    return 0;
}

static int parse_config(const char *data, size_t length, XwConfig *config)
{
    char error[128];
    return xw_config_parse(data, length, config, error, sizeof(error));
}

static int read_slot(const char *path, RecoverySlot *slot)
{
    FILE *f;
    char header[RECOVERY_HEADER_MAX];
    char magic[16];
    unsigned sequence, bytes, expected_crc;
    size_t n;
    int extra;
    XwConfig parsed;
    if (!path || !slot) return -1;
    memset(slot, 0, sizeof(*slot));
    f = fopen(path, "rb");
    if (!f) return -1;
    if (!fgets(header, sizeof(header), f)) { fclose(f); return -1; }
    if (sscanf(header, "%15s %u %u %x", magic, &sequence, &bytes, &expected_crc) != 4 ||
        strcmp(magic, "XWREC1") != 0 || bytes == 0u || bytes > RECOVERY_MAX_BYTES) {
        fclose(f); return -1;
    }
    n = fread(slot->data, 1u, bytes, f);
    extra = fgetc(f);
    {
        int failed = ferror(f) || n != bytes || extra != EOF;
        if (fclose(f) != 0) failed = 1;
        if (failed) return -1;
    }
    if (crc32_bytes((const unsigned char *)slot->data, bytes) != expected_crc ||
        parse_config(slot->data, bytes, &parsed) != 0) return -1;
    slot->sequence = sequence;
    slot->length = bytes;
    slot->valid = 1;
    return 0;
}

static int write_slot(const char *path, unsigned sequence, const char *data, size_t length)
{
    char temp[512];
    char header[RECOVERY_HEADER_MAX];
    unsigned crc;
    FILE *f;
    RecoverySlot check;
    if (!path || !data || length == 0u || length > RECOVERY_MAX_BYTES || strlen(path) + 5u >= sizeof(temp)) return -1;
    (void)snprintf(temp, sizeof(temp), "%s.tmp", path);
    crc = crc32_bytes((const unsigned char *)data, length);
    (void)snprintf(header, sizeof(header), "XWREC1 %u %u %08X\n", sequence, (unsigned)length, crc);
    f = fopen(temp, "wb");
    if (!f) return -1;
    {
        int failed = 0;
        if (fwrite(header, 1u, strlen(header), f) != strlen(header) ||
            fwrite(data, 1u, length, f) != length || fflush(f) != 0) failed = 1;
        if (fclose(f) != 0) failed = 1;
        if (failed) { (void)remove(temp); return -1; }
    }
    if (read_slot(temp, &check) != 0 || check.sequence != sequence || check.length != length ||
        memcmp(check.data, data, length) != 0) {
        (void)remove(temp);
        return -1;
    }
    (void)remove(path);
    if (rename(temp, path) != 0) { (void)remove(temp); return -1; }
    return 0;
}

static int write_primary(const char *path, const char *data, size_t length)
{
    char temp[512];
    FILE *f;
    char verify[RECOVERY_MAX_BYTES];
    size_t verified_length = 0;
    if (!path || !data || length == 0u || length > RECOVERY_MAX_BYTES || strlen(path) + 5u >= sizeof(temp)) return -1;
    (void)snprintf(temp, sizeof(temp), "%s.tmp", path);
    f = fopen(temp, "wb");
    if (!f) return -1;
    {
        int failed = 0;
        if (fwrite(data, 1u, length, f) != length || fflush(f) != 0) failed = 1;
        if (fclose(f) != 0) failed = 1;
        if (failed) { (void)remove(temp); return -1; }
    }
    if (read_file(temp, verify, sizeof(verify), &verified_length) != 0 ||
        verified_length != length || memcmp(verify, data, length) != 0) {
        (void)remove(temp);
        return -1;
    }
    (void)remove(path);
    if (rename(temp, path) != 0) { (void)remove(temp); return -1; }
    return 0;
}

static int load_factory(const char *path, XwConfig *config, RecoverySlot *slot)
{
    if (read_slot(path, slot) != 0) return -1;
    return parse_config(slot->data, slot->length, config);
}

int xw_recovery_save(const char *primary_path, const char *slot_a_path,
                     const char *slot_b_path, const char *factory_path,
                     const XwConfig *config, char *message, size_t message_capacity)
{
    char data[RECOVERY_MAX_BYTES];
    int length;
    RecoverySlot a, b;
    unsigned latest = 0u, next;
    const char *target;
    RecoverySlot factory;
    XwConfig factory_config;
    char factory_data[RECOVERY_MAX_BYTES];
    int factory_length;
    if (!primary_path || !slot_a_path || !slot_b_path || !factory_path || !config) return -1;
    length = xw_config_format(config, data, sizeof(data));
    if (length <= 0) return -1;
    (void)read_slot(slot_a_path, &a);
    (void)read_slot(slot_b_path, &b);
    if (a.valid && a.sequence > latest) latest = a.sequence;
    if (b.valid && b.sequence > latest) latest = b.sequence;
    if (latest == 0xFFFFFFFFu) return -1;
    next = latest + 1u;
    target = (next & 1u) ? slot_a_path : slot_b_path;
    /* The other slot remains untouched until the new slot has been verified. */
    if (write_slot(target, next, data, (size_t)length) != 0) {
        if (message && message_capacity) (void)snprintf(message, message_capacity, "falha ao gravar ponto de recuperacao no USB");
        return -1;
    }
    /* Keep a known-good factory baseline, independent from user settings. */
    if (load_factory(factory_path, &factory_config, &factory) != 0) {
        xw_config_defaults(&factory_config);
        factory_length = xw_config_format(&factory_config, factory_data, sizeof(factory_data));
        if (factory_length > 0)
            (void)write_slot(factory_path, 0u, factory_data, (size_t)factory_length);
    }
    if (write_primary(primary_path, data, (size_t)length) != 0) {
        if (message && message_capacity) (void)snprintf(message, message_capacity, "backup USB salvo; config principal sera restaurada no proximo inicio");
        return -1;
    }
    if (message && message_capacity) (void)snprintf(message, message_capacity, "config salva com recuperacao dupla no USB; NAND intocada");
    return 0;
}

int xw_recovery_load(const char *primary_path, const char *slot_a_path,
                     const char *slot_b_path, const char *factory_path,
                     XwConfig *config, char *message, size_t message_capacity)
{
    RecoverySlot a, b, factory, *best = NULL;
    XwConfig primary_config;
    char primary_data[RECOVERY_MAX_BYTES];
    size_t primary_length = 0;
    int primary_valid = 0;
    if (!primary_path || !slot_a_path || !slot_b_path || !factory_path || !config) return -1;
    memset(&a, 0, sizeof(a)); memset(&b, 0, sizeof(b));
    (void)read_slot(slot_a_path, &a);
    (void)read_slot(slot_b_path, &b);
    if (a.valid && (!b.valid || a.sequence >= b.sequence)) best = &a;
    else if (b.valid) best = &b;
    if (read_file(primary_path, primary_data, sizeof(primary_data), &primary_length) == 0 &&
        parse_config(primary_data, primary_length, &primary_config) == 0) primary_valid = 1;

    if (primary_valid) {
        *config = primary_config;
        if (best && primary_length == best->length &&
            memcmp(primary_data, best->data, best->length) == 0) {
            if (message && message_capacity) (void)snprintf(message, message_capacity, "config integra; snapshot USB validado");
            return 0;
        }
        /* A valid primary always wins over an inconsistent/damaged snapshot. */
        if (message && message_capacity)
            (void)snprintf(message, message_capacity, best ?
                "config integra; backup divergente sera reconstruido" :
                "primeira inicializacao: criando backups do navegador");
        (void)xw_recovery_save(primary_path, slot_a_path, slot_b_path, factory_path,
                               config, NULL, 0u);
        return 0;
    }

    if (best && parse_config(best->data, best->length, config) == 0 &&
        write_primary(primary_path, best->data, best->length) == 0) {
        if (message && message_capacity) (void)snprintf(message, message_capacity,
            "config principal corrompida: restaurada do backup USB %u", best->sequence);
        return 1;
    }

    if (load_factory(factory_path, config, &factory) == 0) {
        if (write_primary(primary_path, factory.data, factory.length) == 0) {
            if (message && message_capacity) (void)snprintf(message, message_capacity, "config restaurada do padrao de fabrica do navegador no USB");
            return 1;
        }
    }

    xw_config_defaults(config);
    if (message && message_capacity) (void)snprintf(message, message_capacity, "sem backup valido; usando configuracao padrao, NAND nao foi acessada");
    (void)xw_recovery_save(primary_path, slot_a_path, slot_b_path, factory_path,
                           config, NULL, 0u);
    return 0;
}
