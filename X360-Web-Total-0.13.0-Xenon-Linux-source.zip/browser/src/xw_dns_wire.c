#include "xw_dns_wire.h"

#include <ctype.h>
#include <string.h>

static uint16_t read_u16(const unsigned char *p)
{
    return (uint16_t)(((uint16_t)p[0] << 8) | (uint16_t)p[1]);
}

static void write_u16(unsigned char *p, uint16_t value)
{
    p[0] = (unsigned char)(value >> 8);
    p[1] = (unsigned char)(value & 0xffu);
}

static int normalize_hostname(const char *hostname, char *output, size_t capacity)
{
    size_t length;
    if (hostname == NULL || output == NULL || capacity == 0) return -1;
    length = strlen(hostname);
    if (length != 0 && hostname[length - 1] == '.') --length;
    if (length == 0 || length > 253u || length + 1u > capacity) return -1;
    for (size_t i = 0; i < length; ++i)
        output[i] = (char)tolower((unsigned char)hostname[i]);
    output[length] = '\0';
    return 0;
}

int xw_dns_build_query(const char *hostname, uint16_t id,
                       unsigned char *output, size_t capacity, size_t *output_length)
{
    size_t used = 12, pos = 0, length;
    char normalized[254];
    if (output == NULL || output_length == NULL || capacity < 17u || capacity > XW_DNS_PACKET_MAX ||
        normalize_hostname(hostname, normalized, sizeof(normalized)) != 0) return -1;
    length = strlen(normalized);
    memset(output, 0, capacity);
    write_u16(output, id);
    write_u16(output + 2, 0x0100u); /* standard query, recursion desired */
    write_u16(output + 4, 1u);
    while (pos < length) {
        size_t start = pos, label_length;
        while (pos < length && normalized[pos] != '.') ++pos;
        label_length = pos - start;
        if (label_length == 0u || label_length > 63u || used + label_length + 1u + 5u > capacity)
            return -1;
        if (normalized[start] == '-' || normalized[start + label_length - 1u] == '-') return -1;
        output[used++] = (unsigned char)label_length;
        for (size_t i = 0; i < label_length; ++i) {
            unsigned char c = (unsigned char)normalized[start + i];
            if (!(isalnum(c) || c == '-')) return -1;
            output[used++] = c;
        }
        if (pos < length) ++pos;
    }
    output[used++] = 0;
    write_u16(output + used, 1u); used += 2; /* A */
    write_u16(output + used, 1u); used += 2; /* IN */
    *output_length = used;
    return 0;
}

/* Decode a DNS name, including compression pointers, without following a loop. */
static int read_dns_name(const unsigned char *packet, size_t length,
                         size_t *offset, char *output, size_t capacity)
{
    size_t position, consumed = 0, used = 0, steps = 0;
    int jumped = 0;
    if (packet == NULL || offset == NULL || output == NULL || capacity == 0 || *offset >= length)
        return -1;
    position = *offset;
    while (position < length && steps++ <= length) {
        unsigned char label = packet[position++];
        if ((label & 0xc0u) == 0xc0u) {
            size_t pointer;
            if (position >= length) return -1;
            pointer = ((size_t)(label & 0x3fu) << 8) | packet[position++];
            if (pointer >= length) return -1;
            if (!jumped) consumed = position;
            jumped = 1;
            position = pointer;
            continue;
        }
        if ((label & 0xc0u) != 0u || label > 63u) return -1;
        if (label == 0u) {
            if (!jumped) consumed = position;
            if (consumed <= *offset) return -1;
            output[used] = '\0';
            *offset = consumed;
            return 0;
        }
        if ((size_t)label > length - position) return -1;
        if (used != 0u) {
            if (used + 1u >= capacity) return -1;
            output[used++] = '.';
        }
        if (used + (size_t)label >= capacity || used + (size_t)label > 253u ||
            packet[position] == '-' || packet[position + (size_t)label - 1u] == '-') return -1;
        for (unsigned i = 0; i < label; ++i) {
            unsigned char character = packet[position + i];
            if (!(isalnum(character) || character == '-')) return -1;
            output[used++] = (char)tolower(character);
        }
        position += label;
    }
    return -1;
}

int xw_dns_parse_a_response(const unsigned char *packet, size_t length,
                            uint16_t id, const char *hostname, unsigned char ipv4[4])
{
    uint16_t flags, questions, answers;
    size_t offset = 12;
    char expected[254], question[254], owner[254];
    if (packet == NULL || ipv4 == NULL || length < 12u || length > XW_DNS_PACKET_MAX ||
        normalize_hostname(hostname, expected, sizeof(expected)) != 0) return -1;
    if (read_u16(packet) != id) return -1;
    flags = read_u16(packet + 2);
    if ((flags & 0x8000u) == 0u || (flags & 0x7800u) != 0u || (flags & 0x0200u) != 0u ||
        (flags & 0x000fu) != 0u) return -1;
    questions = read_u16(packet + 4);
    answers = read_u16(packet + 6);
    if (questions != 1u || answers > 64u) return -1;
    if (read_dns_name(packet, length, &offset, question, sizeof(question)) != 0 ||
        strcmp(question, expected) != 0 || offset > length || length - offset < 4u) return -1;
    if (read_u16(packet + offset) != 1u || read_u16(packet + offset + 2u) != 1u) return -1;
    offset += 4u;

    /* Accept only A records for the queried name or its validated CNAME chain. */
    memcpy(owner, expected, strlen(expected) + 1u);
    for (uint16_t i = 0; i < answers; ++i) {
        uint16_t type, klass, rdlength;
        size_t record_end;
        if (read_dns_name(packet, length, &offset, question, sizeof(question)) != 0 ||
            offset > length || length - offset < 10u) return -1;
        type = read_u16(packet + offset);
        klass = read_u16(packet + offset + 2u);
        rdlength = read_u16(packet + offset + 8u);
        offset += 10u;
        if ((size_t)rdlength > length - offset) return -1;
        record_end = offset + rdlength;
        if (klass == 1u && type == 5u && strcmp(question, owner) == 0) {
            size_t cname_offset = offset;
            char canonical[254];
            if (read_dns_name(packet, length, &cname_offset, canonical, sizeof(canonical)) != 0 ||
                cname_offset != record_end || strcmp(canonical, owner) == 0) return -1;
            memcpy(owner, canonical, strlen(canonical) + 1u);
        } else if (klass == 1u && type == 1u && rdlength == 4u && strcmp(question, owner) == 0) {
            memcpy(ipv4, packet + offset, 4u);
            if (ipv4[0] == 0u || ipv4[0] >= 224u ||
                (ipv4[0] == 255u && ipv4[1] == 255u && ipv4[2] == 255u && ipv4[3] == 255u))
                return -1;
            return 1;
        }
        offset = record_end;
    }
    return 0;
}
