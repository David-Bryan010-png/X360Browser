#!/usr/bin/env python3
"""Fail the build if browser sources acquire direct NAND/flash write APIs."""
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
FORBIDDEN = (
    r"xenon_nand",
    r"nand_write",
    r"nand_erase",
    r"flash_write",
    r"flash_erase",
    r"raw_flash_write",
    r"write_flash_block",
)


def main() -> int:
    files = list((ROOT / "browser" / "src").glob("*.c")) + list((ROOT / "browser" / "include").glob("*.h"))
    failures = []
    for path in files:
        source = path.read_text(encoding="utf-8", errors="replace")
        for pattern in FORBIDDEN:
            if re.search(pattern, source, flags=re.IGNORECASE):
                failures.append(f"{path.relative_to(ROOT)} contains forbidden flash API token: {pattern}")
    recovery = (ROOT / "browser" / "src" / "xw_recovery.c").read_text(encoding="utf-8")
    for required in ("XWREC1", "crc32_bytes", "write_primary"):
        if required not in recovery:
            failures.append(f"recovery implementation is missing required integrity mechanism: {required}")
    if failures:
        for failure in failures:
            print("FAIL:", failure)
        return 1
    print(f"NAND boundary check passed: {len(files)} source/header files scanned; no NAND/flash writer APIs.")
    print("Recovery scope is browser.ini and USB snapshots only.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
