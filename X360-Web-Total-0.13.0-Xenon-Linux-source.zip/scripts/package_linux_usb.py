#!/usr/bin/env python3
"""Build and verify a XeLL-loadable X360 Web Total Linux USB package."""
from __future__ import annotations

import argparse
import gzip
import hashlib
import json
import re
import struct
import zipfile
from pathlib import Path, PurePosixPath

VERSION = "0.13.0"
REVISION = "linux-xenon-desktop-shell"


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def validate_kernel(path: Path) -> None:
    data = path.read_bytes()
    if len(data) < 52 or data[:7] != b"\x7fELF\x01\x02\x01":
        raise ValueError("zImage.xenon is not a 32-bit big-endian ELF image")
    e_type, machine = struct.unpack(">HH", data[16:20])
    version = struct.unpack(">I", data[20:24])[0]
    entry = struct.unpack(">I", data[24:28])[0]
    if e_type not in (2, 3) or machine != 20 or version != 1 or entry == 0:
        raise ValueError("kernel ELF header is not executable PowerPC32 big-endian")



def validate_kboot(data: bytes) -> None:
    try:
        text = data.decode("ascii")
    except UnicodeDecodeError as exc:
        raise ValueError("kboot.conf must be plain ASCII") from exc
    lines = text.splitlines()
    if not lines or lines[0] != "#KBOOTCONFIG":
        raise ValueError("kboot.conf must start with #KBOOTCONFIG on the first line")
    entries = {}
    for line in lines[1:]:
        stripped = line.strip()
        if not stripped or stripped.startswith(("#", ";")) or "=" not in stripped:
            continue
        key, value = stripped.split("=", 1)
        if key in {"default", "timeout", "speedup", "videomode", "ip", "netmask", "gateway", "tftp_server"}:
            continue
        if not re.fullmatch(r"[A-Za-z0-9_-]+", key):
            raise ValueError(f"invalid XeLL boot-entry label: {key!r}")
        if len(value) < 2 or value[0] != '\"' or value[-1] != '\"':
            raise ValueError(f"XeLL boot entry {key!r} must have a quoted value")
        entries[key] = value[1:-1]
    default = next((line.split("=", 1)[1].strip() for line in lines[1:] if line.startswith("default=")), "")
    if not default or default not in entries:
        raise ValueError("kboot.conf default must name an existing quoted boot entry")
    boot = entries[default]
    required = ("uda:/X360WebTotal/Linux/zImage.xenon",
                "initrd=uda:/X360WebTotal/Linux/rootfs.cpio.gz")
    if not all(token in boot for token in required):
        raise ValueError("default XeLL entry must reference the XWT Xenon kernel and initramfs on USB")
    timeout = next((line.split("=", 1)[1].strip() for line in lines[1:] if line.startswith("timeout=")), "0")
    if not timeout.isdigit() or int(timeout) < 1:
        raise ValueError("kboot.conf timeout must be a positive integer so the XeLL menu remains selectable")

def validate_initrd(path: Path) -> None:
    with gzip.open(path, "rb") as f:
        magic = f.read(6)
    if not magic.startswith(b"070701") and not magic.startswith(b"070702"):
        raise ValueError("rootfs.cpio.gz does not contain a newc cpio archive")


def safe_member(name: str) -> None:
    p = PurePosixPath(name)
    if not name or p.is_absolute() or ".." in p.parts or "\\" in name or "\x00" in name:
        raise ValueError(f"unsafe package path: {name!r}")


def verify_package(path: Path) -> None:
    with zipfile.ZipFile(path) as z:
        names = set(z.namelist())
        required = {
            "kboot.conf",
            "X360WebTotal/Linux/zImage.xenon",
            "X360WebTotal/Linux/rootfs.cpio.gz",
            "X360WebTotal/VERSION.txt",
            "X360WebTotal/REVISION.txt",
            "X360WebTotal/README-INSTALL-PT-BR.txt",
            "SHA256SUMS.txt",
        }
        missing = sorted(required - names)
        if missing:
            raise ValueError("package missing: " + ", ".join(missing))
        for n in names:
            safe_member(n)
        validate_kboot(z.read("kboot.conf"))
        bad = z.testzip()
        if bad:
            raise ValueError(f"ZIP CRC error: {bad}")
        sums = {}
        for line in z.read("SHA256SUMS.txt").decode("ascii").splitlines():
            digest, filename = line.split("  ", 1)
            safe_member(filename)
            if filename not in names or filename in sums:
                raise ValueError(f"invalid checksum entry: {filename}")
            actual = hashlib.sha256(z.read(filename)).hexdigest()
            if actual != digest:
                raise ValueError(f"SHA-256 mismatch: {filename}")
            sums[filename] = digest
        if set(sums) != names - {"SHA256SUMS.txt"}:
            raise ValueError("SHA256SUMS.txt does not cover every package member")
        validate_kernel_bytes(z.read("X360WebTotal/Linux/zImage.xenon"))
        import gzip as _gzip
        import io
        with _gzip.GzipFile(fileobj=io.BytesIO(z.read("X360WebTotal/Linux/rootfs.cpio.gz"))) as f:
            if f.read(6)[:6] not in (b"070701", b"070702"):
                raise ValueError("initrd is not a newc cpio archive")


def validate_kernel_bytes(data: bytes) -> None:
    if len(data) < 52 or data[:7] != b"\x7fELF\x01\x02\x01":
        raise ValueError("packaged kernel header is invalid")
    e_type, machine = struct.unpack(">HH", data[16:20])
    version = struct.unpack(">I", data[20:24])[0]
    entry = struct.unpack(">I", data[24:28])[0]
    if e_type not in (2, 3) or machine != 20 or version != 1 or entry == 0:
        raise ValueError("packaged kernel is not a PowerPC32 ELF executable")


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--kernel", required=True, type=Path)
    ap.add_argument("--initrd", required=True, type=Path)
    ap.add_argument("--project", type=Path, default=Path(__file__).resolve().parents[1])
    ap.add_argument("--output", required=True, type=Path)
    args = ap.parse_args()

    for p in (args.kernel, args.initrd):
        if not p.is_file() or p.stat().st_size == 0:
            raise FileNotFoundError(p)
    validate_kernel(args.kernel)
    validate_initrd(args.initrd)

    project = args.project.resolve()
    kboot = project / "linux/boot/kboot.conf"
    readme = project / "README-INSTALL-PT-BR.txt"
    if not kboot.is_file() or not readme.is_file():
        raise FileNotFoundError("project is missing kboot.conf or installation instructions")
    kboot_data = kboot.read_bytes()
    validate_kboot(kboot_data)

    members: dict[str, bytes] = {
        "kboot.conf": kboot_data,
        "X360WebTotal/Linux/zImage.xenon": args.kernel.read_bytes(),
        "X360WebTotal/Linux/rootfs.cpio.gz": args.initrd.read_bytes(),
        "X360WebTotal/VERSION.txt": (VERSION + "\n").encode("ascii"),
        "X360WebTotal/REVISION.txt": (REVISION + "\n").encode("ascii"),
        "X360WebTotal/README-INSTALL-PT-BR.txt": readme.read_bytes(),
    }
    sums = "".join(f"{hashlib.sha256(data).hexdigest()}  {name}\n" for name, data in sorted(members.items()))
    members["SHA256SUMS.txt"] = sums.encode("ascii")

    args.output.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(args.output, "w") as z:
        for name, data in sorted(members.items()):
            safe_member(name)
            compress = zipfile.ZIP_STORED if name.endswith((".gz", "zImage.xenon")) else zipfile.ZIP_DEFLATED
            z.writestr(name, data, compress_type=compress, compresslevel=6 if compress == zipfile.ZIP_DEFLATED else None)
    verify_package(args.output)
    print(json.dumps({
        "version": VERSION,
        "revision": REVISION,
        "package": str(args.output),
        "size_bytes": args.output.stat().st_size,
        "sha256": sha256(args.output),
    }, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
