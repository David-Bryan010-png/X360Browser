#!/usr/bin/env python3
"""Source/configuration guardrails for the native Xenon SDL desktop."""
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]

class DesktopTests(unittest.TestCase):
    def test_desktop_is_native_sdl_not_web_html(self):
        source = (ROOT / "linux/src/xwt-desktop.c").read_text(encoding="utf-8")
        self.assertIn("#include <SDL/SDL.h>", source)
        self.assertIn("#include <SDL/SDL_ttf.h>", source)
        self.assertIn("TTF_RenderUTF8_Blended", source)
        self.assertIn("PAGE_FILES", source)
        self.assertIn("/usr/sbin/xwt-wifi", source)
        self.assertIn("netsurf", source)
        self.assertNotIn("C_BLUE", source)

    def test_desktop_build_hook_links_sdl_and_ttf(self):
        hook = (ROOT / "linux/post-build.sh").read_text(encoding="utf-8")
        self.assertIn("xwt-desktop.c", hook)
        self.assertIn("-lSDL_ttf -lSDL", hook)
        self.assertIn("--sysroot=", hook)
        self.assertIn("/usr/sbin/xwt-desktop", hook)

    def test_buildroot_installs_sdl_fonts_terminal_and_alsa(self):
        config = (ROOT / "linux/buildroot.config").read_text(encoding="utf-8")
        for option in (
            "BR2_PACKAGE_SDL_TTF=y",
            "BR2_PACKAGE_DEJAVU_SANS=y",
            "BR2_PACKAGE_ALSA_UTILS=y",
            "BR2_PACKAGE_NANO=y",
            "BR2_PACKAGE_LESS=y",
        ):
            self.assertIn(option, config)

    def test_boot_uses_desktop_wrapper_with_text_fallback(self):
        wrapper = (ROOT / "linux/overlay/usr/sbin/xwt-system-menu").read_text(encoding="utf-8")
        inittab = (ROOT / "linux/overlay/etc/inittab").read_text(encoding="utf-8")
        self.assertIn("/usr/sbin/xwt-desktop", wrapper)
        self.assertIn("xwt-system-menu-text", wrapper)
        self.assertIn("tty0::respawn:/usr/sbin/xwt-system-menu", inittab)

    def test_usb_boot_persistence_still_avoids_nand(self):
        source = (ROOT / "linux/overlay/etc/init.d/S30storage").read_text(encoding="utf-8")
        self.assertIn("/X360WebTotal/User", source)
        self.assertNotIn("nand_write", source.lower())

if __name__ == "__main__":
    unittest.main(verbosity=2)
