#!/usr/bin/env python3
"""Guardrails for real network state and Wi-Fi management."""
from pathlib import Path
import unittest
import hashlib
import subprocess
import sys
import tempfile
import importlib.util
import struct

ROOT = Path(__file__).resolve().parents[1]
OVERLAY = ROOT / "linux/overlay"

class LinuxNetworkTests(unittest.TestCase):
    def test_wired_dhcp_never_assigns_a_fake_fallback(self):
        source = (OVERLAY / "etc/init.d/S40network").read_text(encoding="utf-8")
        self.assertIn("udhcpc", source)
        self.assertNotIn("192.168.1.99", source)
        self.assertNotIn("192.168.1.1", source)

    def test_internet_test_checks_gateway_dns_and_validated_https(self):
        source = (OVERLAY / "usr/sbin/xwt-network").read_text(encoding="utf-8")
        self.assertIn("ip route show default", source)
        self.assertIn('socket.getaddrinfo("example.com", 443', source)
        self.assertIn("https://example.com/", source)
        self.assertIn("--fail", source)

    def test_wifi_manager_uses_linux_wireless_stack(self):
        source = (OVERLAY / "usr/sbin/xwt-wifi").read_text(encoding="utf-8")
        for required in ("iw dev", "iw dev \"$iface\" scan", "wpa_supplicant", "xwt-wifi-config.py", "udhcpc", "forget"):
            self.assertIn(required, source)


    def test_wifi_waits_for_association_before_dhcp(self):
        manager = (OVERLAY / "usr/sbin/xwt-wifi").read_text(encoding="utf-8")
        boot = (OVERLAY / "etc/init.d/S45wifi").read_text(encoding="utf-8")
        for source in (manager, boot):
            self.assertIn("iw dev \"$iface\" link", source)
            self.assertIn("^Connected to ", source)
            self.assertLess(source.index("^Connected to "), source.index("udhcpc"))

    def test_buildroot_passes_post_build_script_arguments_to_correct_hook(self):
        config = (ROOT / "linux/buildroot.config").read_text(encoding="utf-8")
        self.assertIn("BR2_ROOTFS_POST_BUILD_SCRIPT_ARGS=", config)
        self.assertNotIn("BR2_ROOTFS_POST_SCRIPT_ARGS=", config)

    def test_wifi_profile_derives_psk_without_password_argument(self):
        helper = OVERLAY / "usr/sbin/xwt-wifi-config.py"
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            ssid, password, output = root / "ssid", root / "password", root / "wpa.conf"
            ssid.write_bytes(b"Test Network")
            password.write_bytes(b"correct horse battery staple")
            subprocess.run([sys.executable, str(helper), str(ssid), str(password), str(output)], check=True)
            config = output.read_text(encoding="ascii")
            expected = hashlib.pbkdf2_hmac("sha1", b"correct horse battery staple", b"Test Network", 4096, 32).hex()
            self.assertIn(f"psk={expected}", config)
            self.assertNotIn("correct horse battery staple", config)
            self.assertEqual(output.stat().st_mode & 0o777, 0o600)

    def test_legacy_native_ui_uses_green_accent_not_blue_palette(self):
        source = (ROOT / "browser/src/xw_ui.c").read_text(encoding="utf-8")
        self.assertIn("#define C_ACCENT", source)
        self.assertIn("0xFF107C10u", source)
        self.assertNotIn("C_BLUE", source)

    def test_native_dialog_palette_has_no_blue_tones(self):
        theme = (OVERLAY / "etc/dialogrc").read_text(encoding="utf-8")
        palette_values = "\n".join(line.split("=", 1)[1] for line in theme.splitlines() if "=" in line)
        self.assertNotIn("BLUE", palette_values.upper())
        self.assertIn("(GREEN,BLACK,ON)", theme)
        for rel in ("usr/sbin/xwt-system-menu", "usr/sbin/xwt-wifi"):
            self.assertIn("DIALOGRC=/etc/dialogrc", (OVERLAY / rel).read_text(encoding="utf-8"))

    def test_xbox_controller_bridge_loads_joydev_and_uinput(self):
        source = (OVERLAY / "etc/init.d/S15gamepad").read_text(encoding="utf-8")
        self.assertIn("modprobe xpad", source)
        self.assertIn("modprobe joydev", source)
        self.assertIn("modprobe uinput", source)
        workflow = (ROOT / ".github/workflows/build-x360-linux.yml").read_text(encoding="utf-8")
        self.assertIn("ensure_kernel_option CONFIG_JOYSTICK_XPAD m", workflow)
        self.assertIn("ensure_kernel_option CONFIG_INPUT_UINPUT m", workflow)

    def test_linux_boot_mounts_virtual_filesystems_and_starts_mdev_before_services(self):
        inittab = (OVERLAY / "etc/inittab").read_text(encoding="utf-8")
        required = (
            "/bin/mount -t proc proc /proc",
            "/bin/mount -t sysfs sysfs /sys",
            "/bin/mount -t devpts devpts /dev/pts",
            "/bin/mount -t tmpfs tmpfs /run",
            "/bin/mount -t devtmpfs devtmpfs /dev",
            "/sbin/mdev -s",
            "echo /sbin/mdev > /proc/sys/kernel/hotplug",
            "/etc/init.d/rcS",
        )
        positions = [inittab.index(item) for item in required]
        self.assertEqual(positions, sorted(positions))
        mdev = (OVERLAY / "etc/mdev.conf").read_text(encoding="utf-8")
        self.assertIn("$MODALIAS=.*", mdev)
        self.assertIn('@modprobe "$MODALIAS"', mdev)

    def test_storage_init_creates_run_before_writing_status(self):
        source = (OVERLAY / "etc/init.d/S30storage").read_text(encoding="utf-8")
        self.assertIn("mkdir -p /run /var/run", source)
        self.assertLess(source.index("mkdir -p /run /var/run"), source.index("/run/xwt-storage.env"))

    def test_time_sync_rejects_unsynchronized_ntp_reply(self):
        helper = OVERLAY / "usr/sbin/xwt-time-sync.py"
        spec = importlib.util.spec_from_file_location("xwt_time_sync", helper)
        module = importlib.util.module_from_spec(spec)
        assert spec.loader is not None
        spec.loader.exec_module(module)
        packet = bytearray(48)
        packet[0] = (4 << 3) | 4  # server mode, NTPv4
        packet[1] = 2  # stratum
        seconds = module.NTP_UNIX_EPOCH + 1_800_000_000
        struct.pack_into("!II", packet, 40, seconds, 0)
        self.assertEqual(module.decode_ntp_response(packet), 1_800_000_000)
        packet[0] = (3 << 6) | (4 << 3) | 4  # unsynchronized leap indicator
        with self.assertRaises(ValueError):
            module.decode_ntp_response(packet)

    def test_time_service_runs_after_network_setup(self):
        self.assertTrue((OVERLAY / "etc/init.d/S46time").is_file())
        source = (OVERLAY / "etc/init.d/S46time").read_text(encoding="utf-8")
        self.assertIn("ip route show default", source)
        self.assertIn("xwt-time-sync.py", source)

    def test_main_ui_is_not_an_html_homepage(self):
        self.assertFalse((ROOT / "browser/ui/home.html").exists())
        self.assertFalse((ROOT / "usb/X360WebTotal/ui/home.html").exists())
        self.assertIn("NetSurf", (ROOT / "README.md").read_text(encoding="utf-8"))

if __name__ == "__main__":
    unittest.main(verbosity=2)
