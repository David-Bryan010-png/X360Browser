# X360 Web Total 0.13.0 — Xenon Linux Desktop

**Criador/referência: DVDBRN**  
**Revisão:** `linux-xenon-desktop-shell`

O X360 Web Total está evoluindo de navegador dedicado para um ambiente Linux leve para Xbox 360. Nesta versão, Linux é o sistema principal carregado por XeLL; o navegador é um aplicativo separado do desktop.

## O que existe nesta versão

- Kernel Linux 7.2 baseado no port experimental Xenon/Xenos do projeto Free60, compilado para PowerPC 970 big-endian.
- Desktop gráfico nativo em C com SDL 1.2 + SDL_ttf, framebuffer e paleta verde/branco/grafite. Não é uma página HTML.
- Navegador NetSurf SDL/framebuffer com libcurl, OpenSSL e bundle de certificados CA.
- Menu por controle Xbox USB através de `xpad`, `joydev` e um bridge `uinput`; teclado USB também é suportado pelo HID do kernel.
- Gerenciador Wi-Fi com varredura, escolha de SSID, senha WPA/WPA2, associação real, DHCP, reconexão e esquecimento de perfil. Exige um dongle USB com chipset/firmware compatíveis.
- Ethernet integrada SIS190; DHCP só é considerado concluído quando existe lease real. O sistema não inventa IP estático quando falha.
- Diagnóstico separado de link, endereço IP, rota default, resolução DNS, relógio e requisição HTTPS com validação de certificado.
- Explorador de arquivos SDL para armazenamento USB e diretórios Linux; documentos de texto podem ser abertos no `less` e HTML no navegador.
- Visão de sistema com memória, uptime, plataforma e estado de rede.
- Terminal Linux, ferramentas `nano`/`less`, diagnóstico de USB, ALSA e controles de energia.
- Preferências do NetSurf e perfil Wi-Fi persistidos na unidade FAT32 `X360WebTotal/User/`; nenhuma gravação NAND.
- Buildroot e port Free60 fixados por commit no workflow para reprodutibilidade do ambiente.

## O que o desktop NÃO promete

Este é um desktop embarcado leve, não um PC moderno completo. A CPU Xenon, a RAM disponível, a GPU Xenos e os drivers experimentais impõem limites. Não há X11/Wayland, aceleração 3D geral, compatibilidade com todos os programas Linux, nem instalação automática de pacotes. O sistema fornece uma base modular para acrescentar aplicações nativas no futuro.

NetSurf é um navegador real, mas não é Chromium. Sites atuais podem falhar por JavaScript/API moderna. **YouTube atual e reprodução de vídeo não estão certificados nesta versão.** O suporte de áudio está limitado a dispositivos reconhecidos pelo ALSA, principalmente USB Audio nesta imagem.

## Rede e Wi-Fi

A Ethernet integrada do console usa o driver SIS190 do kernel Xenon. O sistema verifica IP e rota em vez de tratar a simples presença de um IP como Internet funcional. O teste final consulta DNS e tenta HTTPS com CA e TLS validados.

Wi-Fi depende de adaptador USB externo. O código não ativa o rádio interno desconhecido nem cria Wi-Fi por software. A imagem inclui famílias de driver/firmware selecionadas (Ralink/MediaTek, Atheros e Realtek), mas o nome comercial do dongle não garante compatibilidade: é necessário conferir o chipset e a revisão exatos.

## Compilação e publicação

O workflow `.github/workflows/build-x360-linux.yml`:

1. encontra a pasta 0.13.0 na raiz ou extrai automaticamente um ZIP-fonte 0.13.0;
2. baixa o port Xenon e o Buildroot nas revisões fixadas;
3. configura o kernel Xenon, drivers, desktop, navegador e rootfs;
4. compila kernel, desktop SDL, bridge de controle e initramfs;
5. verifica scripts, permissões, conteúdo CPIO, formato real do `kboot.conf` do XeLL, testes de rede/empacotamento e limites NAND;
6. monta pacote FAT32 para XeLL, hashes e manifesto;
7. publica pre-release apenas depois de todas as etapas passarem.

Depois de instalar o código e o workflow no repositório, atualizações futuras podem ser feitas por commits normais; não é preciso extrair o ZIP manualmente no celular.

## Instalação no Xbox 360

1. Extraia o pacote `X360-Web-Total-0.13.0-Xenon-Linux-USB.zip` para a raiz de uma unidade FAT32.
2. Confirme `kboot.conf` na raiz e `X360WebTotal/Linux/zImage.xenon` + `rootfs.cpio.gz`.
3. Inicie XeLL Reloaded com o USB conectado.
4. Selecione `xwt_linux_usb` no menu XeLL.
5. Aguarde o kernel e o desktop iniciarem.

O pacote carrega kernel e initramfs em RAM. Não instala bootloader e não grava NAND, KV ou firmware.

## Validação

A compilação do GitHub Actions pode validar compilação cruzada e integridade do pacote, mas não substitui testes em um Xbox 360 físico. HDMI, framebuffer Xenos, teclado/controle, Ethernet, USB, áudio e cada modelo de dongle Wi-Fi precisam ser testados no console real.
