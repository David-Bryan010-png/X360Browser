/*
 * X360 Web Total: translate a USB Xbox-compatible joystick into key events so
 * dialog menus can be used from the console controller as well as a keyboard.
 * No console firmware/NAND/SMC interfaces are accessed.
 */
#define _POSIX_C_SOURCE 200809L
#include <errno.h>
#include <fcntl.h>
#include <linux/input.h>
#include <linux/joystick.h>
#include <linux/uinput.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <sys/ioctl.h>
#include <time.h>
#include <unistd.h>

static void pause_ms(long ms)
{
    struct timespec ts = { ms / 1000, (ms % 1000) * 1000000L };
    while (nanosleep(&ts, &ts) < 0 && errno == EINTR) { }
}

static int create_virtual_keyboard(void)
{
    int fd = open("/dev/uinput", O_WRONLY | O_NONBLOCK);
    struct uinput_user_dev device;
    if (fd < 0) return -1;
    if (ioctl(fd, UI_SET_EVBIT, EV_KEY) < 0 ||
        ioctl(fd, UI_SET_EVBIT, EV_SYN) < 0 ||
        ioctl(fd, UI_SET_KEYBIT, KEY_UP) < 0 ||
        ioctl(fd, UI_SET_KEYBIT, KEY_DOWN) < 0 ||
        ioctl(fd, UI_SET_KEYBIT, KEY_LEFT) < 0 ||
        ioctl(fd, UI_SET_KEYBIT, KEY_RIGHT) < 0 ||
        ioctl(fd, UI_SET_KEYBIT, KEY_ENTER) < 0 ||
        ioctl(fd, UI_SET_KEYBIT, KEY_ESC) < 0) {
        close(fd);
        return -1;
    }
    memset(&device, 0, sizeof(device));
    (void)snprintf(device.name, UINPUT_MAX_NAME_SIZE, "XWT Xbox Controller Keyboard");
    device.id.bustype = BUS_USB;
    device.id.vendor = 0x045e;
    device.id.product = 0x028e;
    device.id.version = 1;
    if (write(fd, &device, sizeof(device)) != (ssize_t)sizeof(device) || ioctl(fd, UI_DEV_CREATE) < 0) {
        close(fd);
        return -1;
    }
    pause_ms(250);
    return fd;
}

static void emit_key(int fd, unsigned short code, int down)
{
    struct input_event event;
    memset(&event, 0, sizeof(event));
    event.type = EV_KEY;
    event.code = code;
    event.value = down ? 1 : 0;
    (void)write(fd, &event, sizeof(event));
    memset(&event, 0, sizeof(event));
    event.type = EV_SYN;
    event.code = SYN_REPORT;
    (void)write(fd, &event, sizeof(event));
}

static unsigned short axis_key(int16_t x, int16_t y)
{
    if (y < -16000) return KEY_UP;
    if (y > 16000) return KEY_DOWN;
    if (x < -16000) return KEY_LEFT;
    if (x > 16000) return KEY_RIGHT;
    return 0;
}

int main(void)
{
    int joy = -1, keydev = -1;
    unsigned short held_axis = 0;
    for (;;) {
        if (keydev < 0) {
            keydev = create_virtual_keyboard();
            if (keydev < 0) { pause_ms(2000); continue; }
        }
        if (joy < 0) {
            joy = open("/dev/input/js0", O_RDONLY | O_NONBLOCK);
            if (joy < 0) { pause_ms(1000); continue; }
            held_axis = 0;
        }
        {
            struct js_event event;
            ssize_t got = read(joy, &event, sizeof(event));
            if (got == (ssize_t)sizeof(event)) {
                event.type &= (unsigned char)~JS_EVENT_INIT;
                if (event.type == JS_EVENT_AXIS && event.number <= 7) {
                    static int16_t axis_x, axis_y, hat_x, hat_y;
                    if (event.number == 0) axis_x = event.value;
                    else if (event.number == 1) axis_y = event.value;
                    else if (event.number == 6) hat_x = event.value;
                    else if (event.number == 7) hat_y = event.value;
                    /* D-pad (hat) takes priority while it is deflected. */
                    unsigned short wanted = axis_key((hat_x || hat_y) ? hat_x : axis_x,
                                                     (hat_x || hat_y) ? hat_y : axis_y);
                    if (wanted != held_axis) {
                        if (held_axis) emit_key(keydev, held_axis, 0);
                        if (wanted) emit_key(keydev, wanted, 1);
                        held_axis = wanted;
                    }
                } else if (event.type == JS_EVENT_BUTTON && event.value) {
                    if (event.number == 0 || event.number == 7) emit_key(keydev, KEY_ENTER, 1);
                    if (event.number == 1 || event.number == 6) emit_key(keydev, KEY_ESC, 1);
                } else if (event.type == JS_EVENT_BUTTON && !event.value) {
                    if (event.number == 0 || event.number == 7) emit_key(keydev, KEY_ENTER, 0);
                    if (event.number == 1 || event.number == 6) emit_key(keydev, KEY_ESC, 0);
                }
            } else if (got < 0 && errno != EAGAIN && errno != EINTR) {
                if (held_axis) emit_key(keydev, held_axis, 0);
                held_axis = 0;
                close(joy);
                joy = -1;
            } else {
                pause_ms(10);
            }
        }
    }
    return 0;
}
