# Diagnóstico de rede

O XWT mantém estados separados:

1. **Interface e link:** adaptador presente, cabo conectado ou associação Wi-Fi.
2. **Endereço IP:** DHCP recebeu endereço real.
3. **Rota default:** existe gateway configurado.
4. **DNS:** `example.com` resolve via `getaddrinfo`.
5. **Relógio:** NTP sincronizado; certificado TLS depende da data/hora corretas.
6. **HTTPS:** `curl` executa uma requisição HTTPS com TLS mínimo 1.2 e validação de certificados CA.

Um endereço IP sozinho não prova conectividade com a Internet. `xwt-network check` não considera a rede online até a requisição HTTPS validada funcionar. O sistema não atribui IP estático de emergência.

Ethernet usa o driver SIS190 integrado e DHCP BusyBox (`udhcpc`). Wi-Fi depende de adaptador USB com chipset e firmware suportados; o gerenciador usa `iw`, `wpa_supplicant`, espera associação e só depois pede DHCP.
