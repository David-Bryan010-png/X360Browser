#!/bin/sh
# Buildroot post-build hook: compile native Xenon desktop and gamepad bridge.
set -eu
TARGET_DIR=$1
BUILDROOT_OUTPUT=$2
PROJECT_ROOT=$3
HOST_BIN="$BUILDROOT_OUTPUT/host/bin"
STAGING="$BUILDROOT_OUTPUT/staging"
CROSS_GCC="$HOST_BIN/powerpc64-buildroot-linux-gnu-gcc"
if [ ! -x "$CROSS_GCC" ]; then
  for candidate in "$HOST_BIN"/powerpc64*-gcc; do
    [ -x "$candidate" ] || continue
    CROSS_GCC=$candidate
    break
  done
fi
if [ -z "$CROSS_GCC" ] || [ ! -x "$CROSS_GCC" ]; then
  echo "PowerPC64 Buildroot cross-compiler not found under $HOST_BIN" >&2
  exit 1
fi
if [ ! -f "$STAGING/usr/include/SDL/SDL.h" ] || [ ! -f "$STAGING/usr/include/SDL/SDL_ttf.h" ]; then
  echo "SDL/SDL_ttf headers are missing from Buildroot staging; check BR2_PACKAGE_SDL_TTF." >&2
  exit 1
fi
if [ ! -f "$STAGING/usr/lib/libSDL_ttf.so" ] && [ ! -f "$STAGING/usr/lib/libSDL_ttf.a" ]; then
  echo "SDL_ttf library is missing from Buildroot staging." >&2
  exit 1
fi
mkdir -p "$TARGET_DIR/usr/sbin"
"$CROSS_GCC" --sysroot="$STAGING" -Os -std=c11 \
  -Wall -Wextra -Wpedantic -Werror -D_REENTRANT \
  -I"$STAGING/usr/include/SDL" \
  -L"$STAGING/usr/lib" -Wl,-rpath-link,"$STAGING/usr/lib" \
  -o "$TARGET_DIR/usr/sbin/xwt-desktop" \
  "$PROJECT_ROOT/linux/src/xwt-desktop.c" -lSDL_ttf -lSDL
chmod 0755 "$TARGET_DIR/usr/sbin/xwt-desktop"
"$CROSS_GCC" --sysroot="$STAGING" -Os -std=c11 \
  -Wall -Wextra -Wpedantic -Werror \
  -o "$TARGET_DIR/usr/sbin/xwt-gamepad-keys" \
  "$PROJECT_ROOT/linux/src/xwt-gamepad-keys.c"
chmod 0755 "$TARGET_DIR/usr/sbin/xwt-gamepad-keys"
