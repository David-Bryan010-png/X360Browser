#!/usr/bin/env python3
"""Synchronize the Xbox 360 Linux clock from a public NTP server over UDP."""
from __future__ import annotations

import signal
import socket
import struct
import time

NTP_UNIX_EPOCH = 2_208_988_800
MIN_VALID_UNIX = 1_704_067_200  # 2024-01-01; reject uninitialized/invalid replies.
SERVERS = ("time.cloudflare.com", "pool.ntp.org", "time.google.com")


def decode_ntp_response(packet: bytes) -> float:
    if len(packet) < 48:
        raise ValueError("NTP response is shorter than 48 bytes")
    leap = (packet[0] >> 6) & 0x03
    mode = packet[0] & 0x07
    stratum = packet[1]
    if leap == 3 or mode != 4 or not (1 <= stratum <= 15):
        raise ValueError("NTP response is unsynchronized or not from a server")
    seconds, fraction = struct.unpack("!II", packet[40:48])
    unix_time = seconds - NTP_UNIX_EPOCH + fraction / 4_294_967_296.0
    if unix_time < MIN_VALID_UNIX:
        raise ValueError("NTP timestamp is implausibly old")
    return unix_time


def fetch_time(server: str, timeout: float = 3.0) -> float:
    addresses = socket.getaddrinfo(server, 123, type=socket.SOCK_DGRAM)
    last_error: Exception | None = None
    for family, socktype, proto, _canon, address in addresses:
        try:
            with socket.socket(family, socktype, proto) as sock:
                sock.settimeout(timeout)
                request = bytearray(48)
                request[0] = 0x1B  # LI=0, VN=3, client mode.
                sock.sendto(request, address)
                packet, _peer = sock.recvfrom(512)
                return decode_ntp_response(packet)
        except (OSError, ValueError) as exc:
            last_error = exc
    if last_error:
        raise last_error
    raise OSError(f"No usable address for NTP server {server}")


def main() -> int:
    errors: list[str] = []
    for server in SERVERS:
        try:
            signal.alarm(7)
            try:
                epoch = fetch_time(server)
            finally:
                signal.alarm(0)
            time.clock_settime(time.CLOCK_REALTIME, epoch)
            print(f"Relógio sincronizado por NTP: {server} ({time.strftime('%Y-%m-%d %H:%M:%S UTC', time.gmtime(epoch))})")
            return 0
        except Exception as exc:  # keep trying alternative NTP pools
            signal.alarm(0)
            errors.append(f"{server}: {exc}")
    for error in errors:
        print(error)
    print("Não foi possível sincronizar o relógio. Verifique DNS, rota e UDP/123.")
    return 1


if __name__ == "__main__":
    signal.signal(signal.SIGALRM, lambda *_: (_ for _ in ()).throw(TimeoutError("NTP timeout")))
    raise SystemExit(main())
