#!/usr/bin/env python3
"""Generate a wpa_supplicant profile without exposing the password in argv."""
from __future__ import annotations
import hashlib
import os
import sys
from pathlib import Path


def main() -> int:
    if len(sys.argv) != 4:
        print("usage: xwt-wifi-config.py SSID_FILE PASSWORD_FILE OUTPUT", file=sys.stderr)
        return 64
    ssid_file, password_file, output = map(Path, sys.argv[1:])
    ssid = ssid_file.read_bytes()
    password = password_file.read_bytes()
    if not (1 <= len(ssid) <= 32) or b"\x00" in ssid:
        raise SystemExit("SSID must contain 1 to 32 non-NUL bytes")

    lines = [
        "ctrl_interface=/var/run/wpa_supplicant",
        "update_config=1",
        "country=BR",
        "network={",
        f"    ssid={ssid.hex()}",
    ]
    if password:
        if len(password) == 64:
            try:
                psk = bytes.fromhex(password.decode("ascii"))
            except (ValueError, UnicodeError):
                psk = b""
            if len(psk) != 32:
                raise SystemExit("A chave hexadecimal de 64 caracteres é inválida")
            psk_hex = psk.hex()
        else:
            if not (8 <= len(password) <= 63):
                raise SystemExit("WPA/WPA2 passphrase must contain 8 to 63 bytes (or 64 hex digits)")
            psk_hex = hashlib.pbkdf2_hmac("sha1", password, ssid, 4096, 32).hex()
        lines.append(f"    psk={psk_hex}")
    else:
        lines.append("    key_mgmt=NONE")
    lines.append("}")
    output.write_text("\n".join(lines) + "\n", encoding="ascii")
    os.chmod(output, 0o600)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
