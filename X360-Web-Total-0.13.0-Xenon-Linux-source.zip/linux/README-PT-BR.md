# X360 Web Total 0.13.0 — Xenon Linux Desktop

Esta edição usa Linux como sistema principal carregado por XeLL e abre um desktop gráfico próprio em SDL 1.2 + SDL_ttf no framebuffer Xenos. A interface principal não é HTML e não depende do antigo leitor estático LibXenon.

## Desktop e aplicativos

- Desktop SDL em C, com tema verde/branco/grafite e navegação por D-pad/A/B ou teclado USB.
- NetSurf SDL como navegador independente.
- Gerenciador Wi-Fi USB (`iw`, `wpa_supplicant`, DHCP).
- Diagnóstico de rede completo (`xwt-network`).
- Explorador de arquivos: navega em `/mnt/xwt-usb` e diretórios Linux; abre HTML no NetSurf e texto no `less`.
- Painel de sistema: CPU detectada, memória, uptime e endereço de rede.
- Terminal `/bin/sh`, editor `nano`, leitor `less`.
- Ferramentas de áudio ALSA, quando há dispositivo reconhecido pelo kernel.
- Ações de reiniciar/desligar.
- Menu `dialog` de compatibilidade caso o framebuffer/SDL ou as fontes não iniciem.

## Rede

- Ethernet onboard pelo driver SIS190 com DHCP real.
- O sistema não atribui IP estático falso se DHCP falhar.
- O teste separa interface/link, endereço, rota default, DNS, relógio/NTP e HTTPS validado por certificado.
- O Wi-Fi exige dongle USB externo. A imagem inclui drivers/firmwares selecionados para famílias Atheros, Ralink/MediaTek e Realtek, mas o chipset/revisão exato do adaptador precisa ser compatível.

## Armazenamento e segurança

- O USB de boot é montado em `/mnt/xwt-usb`.
- NetSurf e perfil WPA são persistidos em `X360WebTotal/User/` na unidade FAT32.
- Kernel e initramfs são carregados na RAM por XeLL. Nenhuma operação de escrita NAND/flash é incluída.

## Navegador e limites

NetSurf 3.10 com SDL/framebuffer, Duktape, libcurl/OpenSSL e certificados CA. Isso é uma melhoria real sobre o antigo cliente lwIP/HTTP, mas não equivale a Chromium. Sites com JavaScript moderno, APIs avançadas, WebAssembly, DRM ou codecs podem falhar. YouTube atual e vídeo web não estão certificados. O desktop é uma base Linux embarcada, não um PC moderno completo; aceleração 3D e áudio HDMI interno não são garantidos.

## Inicialização

XeLL Reloaded lê `kboot.conf` e carrega `X360WebTotal/Linux/zImage.xenon` mais `rootfs.cpio.gz`. BusyBox monta procfs/sysfs/devtmpfs, inicia `mdev`, serviços de USB/rede e então o wrapper inicia `xwt-desktop`. Caso SDL falhe, abre o menu textual de compatibilidade.
