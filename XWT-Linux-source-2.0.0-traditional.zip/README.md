# XWT OS 2.0.0 — distribuição Linux tradicional para Xbox 360

**XWT OS** é um sistema Linux dedicado ao Xbox 360 Xenon, baseado no Debian Ports `ppc64` big-endian e integrado ao kernel Free60 Xenon 7.2 e ao XWT Boot.

A versão tradicional substitui a instalação anterior de rootfs temporário + pacotes SquashFS por um **rootfs ext4 persistente**, com `systemd`, `apt` e `dpkg`. O projeto preserva a interface SDL/framebuffer, o suporte ao controle Xbox, os utilitários XWT e o caminho de boot específico do console.

## Compilar a distribuição tradicional

No GitHub, abra **Actions → XWT OS - Build Traditional Distro → Run workflow**. O workflow compila o kernel e os módulos Xenon, compila o XWT Boot, cria um rootfs Debian Ports ppc64 e gera os artefatos da distribuição.

Saída principal: `XWT-OS-Traditional-Xbox360-2.0.0.zip`, dentro do artefato `xwt-os-traditional-<commit>`.

## Instalar no USB

Em um computador Linux, extraia o ZIP de release e execute:

```bash
sudo ./install-usb.sh /dev/sdX
```

O instalador apaga o dispositivo indicado e cria FAT32 (`XWTBOOT`), swap (`XWTSWAP`) e ext4 (`XWTROOT`). Confirme o disco correto e faça backup antes de executar. Requisitos completos e limitações: `README-INSTALACAO-PT-BR.md`.

No Xbox 360, use o caminho XWT/XeLL que já funciona no console. O XWT Boot carrega `zImage.xenon` e o kernel monta diretamente `root=PARTUUID=<assinatura-MBR>-03`; o Debian inicia a partir do USB, sem initramfs completo.

## O que muda

- Base de sistema: Debian Ports `ppc64` big-endian, não `ppc64el`.
- Gerenciador de pacotes: `apt` / `dpkg`.
- Inicialização: `systemd` / `udev`.
- Root: ext4 persistente no USB.
- Memória: zram e swap, considerando os 512 MiB de RAM do console.
- Hardware e desktop: kernel Free60 Xenon, drivers específicos, SDL/framebuffer e serviços XWT.

Buildroot continua no pipeline como ferramenta de construção do kernel, toolchain e runtime SDL auxiliar; ele não é o sistema operacional instalado nessa variante.

## Compatibilidade e limites

A porta Debian Ports `ppc64` big-endian é experimental/não oficial. Pacotes podem faltar, falhar ou precisar ser recompilados para o Xenon, especialmente os que usam AltiVec/VMX. A distribuição não promete aceleração 3D completa, navegador moderno, áudio universal ou compatibilidade com todo adaptador Wi-Fi. O build em GitHub Actions não substitui o teste físico de boot, vídeo, USB, rede e controle no Xbox 360 real.

A imagem não grava NAND, KV, SMC ou firmware. O instalador formata somente o dispositivo USB que você indicar.

## Variante antiga

A pipeline de Buildroot com rootfs CPIO + SquashFS e atualizações `.xwpkg` continua no repositório como variante modular/legada. Para a distribuição tradicional, use o workflow **XWT OS - Build Traditional Distro**.

## Licenças

Consulte `THIRD-PARTY-NOTICES.md`. O XWT não é afiliado à Microsoft nem ao projeto Free60. Não distribua jogos protegidos por direitos autorais; use seus próprios arquivos ou conteúdo livre, como Freedoom.
