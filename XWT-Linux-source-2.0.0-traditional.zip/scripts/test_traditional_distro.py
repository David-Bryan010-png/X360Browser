#!/usr/bin/env python3
"""Safety and integration checks for the traditional Xbox 360 distribution."""
from pathlib import Path
import re
import unittest

ROOT = Path(__file__).resolve().parents[1]


class TraditionalDistroTests(unittest.TestCase):
    def test_debian_ports_big_endian_rootfs_and_package_manager(self):
        build = (ROOT / "distro/build-rootfs.sh").read_text()
        for token in (
            "ARCH=ppc64", "debootstrap", "apt-get install", "dpkg-deb --build",
            "chroot \"$ROOTFS\" dpkg -i /tmp/xwt-os.deb",
            'LABEL=XWTROOT  /', 'LABEL=XWTSWAP', 'LABEL=XWTBOOT',
            'systemd-networkd', 'systemd-resolved', 'zram-tools',
        ):
            self.assertIn(token, build)
        self.assertIn("rootfs.tar.zst", build)
        self.assertIn("root=PARTUUID=12345678-03", build)
        self.assertNotIn("rootfs.cpio.gz\" -C", build)

    def test_boot_profile_directly_mounts_persistent_ext4_without_initrd(self):
        installer = (ROOT / "distro/installer/install-usb.sh").read_text()
        profile = installer.split('cat > "$BOOT_MNT/XWTBoot/config.cfg" <<CFG', 1)[1].split("\nCFG", 1)[0]
        self.assertIn("kernel=zImage.xenon", profile)
        self.assertIn("initrd=", profile)
        self.assertIn("mode=4", profile)  # BOOT_MODE_CUSTOM in xwt_boot.h
        self.assertIn("KERNEL_CMDLINE=\"root=PARTUUID=$ROOT_PARTUUID rootfstype=ext4", installer)
        self.assertIn("custom_cmdline=$KERNEL_CMDLINE", profile)
        self.assertIn('sfdisk --disk-id "$DEVICE"', installer)
        self.assertIn('blkid -s PARTUUID -o value "$P3"', installer)
        self.assertIn('[[ "$ROOT_PARTUUID" =~ ^[0-9A-Fa-f]{8}-03$ ]]', installer)
        self.assertIn("autoboot=1", profile)
        cmdline = installer.split('KERNEL_CMDLINE="', 1)[1].split('"', 1)[0]
        cmdline = cmdline.replace("$ROOT_PARTUUID", "12345678-03")
        self.assertLessEqual(len("custom_cmdline=" + cmdline), 255)
        self.assertLess(installer.index('sfdisk --disk-id "$DEVICE"'), installer.index('partprobe "$DEVICE"'))

    def test_installer_has_explicit_destructive_confirmation(self):
        installer = (ROOT / "distro/installer/install-usb.sh").read_text()
        self.assertIn('[[ "$TYPE" == disk ]]', installer)
        self.assertIn('SCRIPT_DIR=', installer)
        self.assertIn('sha256sum -c SHA256SUMS', installer)
        self.assertIn('Digite exatamente APAGAR %s', installer)
        self.assertIn('[[ "$CONFIRM" == "APAGAR $DEVICE" ]]', installer)
        self.assertLess(installer.index('[[ "$CONFIRM" == "APAGAR $DEVICE" ]]'), installer.index('wipefs -af "$DEVICE"'))
        self.assertIn('mkfs.vfat -F 32 -n XWTBOOT', installer)
        self.assertIn('mkswap -L XWTSWAP', installer)
        self.assertIn('mkfs.ext4 -F -L XWTROOT', installer)
        self.assertNotRegex(installer.lower(), r'\b(updxell|nand_write|rawflash)\b')

    def test_xwt_hardware_and_ui_are_started_by_systemd(self):
        names = ("xwt-hardware.service", "xwt-gamepad.service", "xwt-desktop.service")
        for name in names:
            self.assertTrue((ROOT / "distro/units" / name).is_file())
        desktop = (ROOT / "distro/units/xwt-desktop.service").read_text()
        self.assertIn("SDL_VIDEODRIVER=fbcon", desktop)
        self.assertIn("/usr/sbin/xwt-system-menu", desktop)
        self.assertNotIn("After=multi-user.target", desktop)

    def test_kernel_config_supports_persistent_debian_root(self):
        config = (ROOT / "linux/xenon-7.2.defconfig").read_text()
        for option in (
            "CONFIG_BLOCK=y", "CONFIG_MSDOS_PARTITION=y", "CONFIG_EXT4_FS=y",
            "CONFIG_SWAP=y", "CONFIG_FHANDLE=y", "CONFIG_INOTIFY_USER=y",
            "CONFIG_DEVTMPFS=y", "CONFIG_DEVTMPFS_MOUNT=y",
        ):
            self.assertIn(option, config)
        fragment = (ROOT / "linux/xwt-kernel.fragment").read_text()
        for option in (
            "CONFIG_BLOCK=y", "CONFIG_MSDOS_PARTITION=y", "CONFIG_EXT4_FS=y",
            "CONFIG_SWAP=y", "CONFIG_CGROUPS=y", "CONFIG_MEMCG=y",
            "CONFIG_FHANDLE=y", "CONFIG_INOTIFY_USER=y", "CONFIG_SIGNALFD=y",
            "CONFIG_TIMERFD=y", "CONFIG_ZRAM=m",
        ):
            self.assertIn(option, fragment)

    def test_dedicated_workflow_builds_both_xenon_and_debian_artifacts(self):
        workflow = (ROOT / ".github/workflows/build-traditional-distro.yml").read_text()
        self.assertIn("./.github/workflows/build-core.yml", workflow)
        self.assertIn("./.github/workflows/build-bootloader.yml", workflow)
        self.assertIn("xwt-linux-core-${{ github.sha }}", workflow)
        self.assertIn("xwt-bootloader-${{ github.sha }}", workflow)
        self.assertIn("distro/build-rootfs.sh", workflow)
        self.assertIn("Extract and validate the complete XWT source tree", workflow)
        self.assertIn('echo "PROJECT_DIR=$PROJECT_DEST" >> "$GITHUB_ENV"', workflow)
        self.assertIn('bash "$PROJECT_DIR/distro/build-rootfs.sh"', workflow)
        self.assertIn('DISTRO_OUT="$PROJECT_DIR/out/distro"', workflow)
        self.assertIn("XWT-OS-Traditional-Xbox360-2.0.0.zip", workflow)

    def test_distribution_documentation_states_experimental_port_and_limits(self):
        readme = (ROOT / "distro/README-PT-BR.md").read_text()
        self.assertIn("ppc64` big-endian", readme)
        self.assertIn("não oficial", readme)
        self.assertIn("512 MiB", readme)
        self.assertIn("não** grava NAND", readme)


if __name__ == "__main__":
    unittest.main(verbosity=2)
