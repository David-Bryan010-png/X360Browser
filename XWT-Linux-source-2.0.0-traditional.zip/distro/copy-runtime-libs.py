#!/usr/bin/env python3
"""Copy non-glibc runtime dependencies of XWT PPC64 apps from the Buildroot sysroot."""
from __future__ import annotations
import argparse
import os
import re
import shutil
import subprocess
from pathlib import Path

CORE = {
    "libc.so.6", "libm.so.6", "libpthread.so.0", "libdl.so.2",
    "librt.so.1", "libresolv.so.2", "libutil.so.1", "libgcc_s.so.1",
    "libnss_files.so.2", "libnss_dns.so.2", "libanl.so.1",
}
NEEDED_RE = re.compile(r"\(NEEDED\).*Shared library: \[(.*?)\]")


def needed(path: Path) -> list[str]:
    result = subprocess.run(["readelf", "-d", str(path)], text=True,
                            stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if result.returncode != 0:
        return []
    return NEEDED_RE.findall(result.stdout)


def library_index(root: Path) -> dict[str, Path]:
    index: dict[str, Path] = {}
    search_roots = [root / "lib", root / "lib64", root / "usr/lib", root / "usr/lib64"]
    for base in search_roots:
        if not base.exists():
            continue
        for current, dirs, files in os.walk(base, followlinks=True):
            dirs[:] = [d for d in dirs if d not in {"pkgconfig", "cmake"}]
            for filename in files:
                candidate = Path(current) / filename
                if filename not in index and candidate.is_file():
                    index[filename] = candidate
    return index


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--source-root", required=True, type=Path)
    ap.add_argument("--destination", required=True, type=Path)
    ap.add_argument("binaries", nargs="+", type=Path)
    args = ap.parse_args()

    source = args.source_root.resolve()
    dest = args.destination
    dest.mkdir(parents=True, exist_ok=True)
    idx = library_index(source)
    queue = [p for p in args.binaries if p.exists()]
    seen: set[Path] = set()
    copied: set[str] = set()
    missing: set[str] = set()

    while queue:
        binary = queue.pop(0).resolve()
        if binary in seen or not binary.is_file():
            continue
        seen.add(binary)
        for name in needed(binary):
            if name in CORE or name.startswith("ld64.so"):
                continue
            lib = idx.get(name)
            if lib is None:
                # libc, libgcc and low-level system libraries are supplied by Debian.
                missing.add(name)
                continue
            real = lib.resolve()
            if name not in copied:
                target = dest / name
                if real != target:
                    shutil.copy2(real, target)
                copied.add(name)
            if real not in seen:
                queue.append(real)

    # A missing dependency is acceptable only when it is a standard Debian runtime
    # library; the post-build audit in the workflow checks the final ELF environment.
    unexpected = sorted(n for n in missing if n not in CORE and not n.startswith("ld64.so"))
    print(f"Copied {len(copied)} XWT runtime libraries to {dest}")
    if unexpected:
        print("Libraries expected from Debian packages:", ", ".join(unexpected))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
