#!/usr/bin/env bash
set -Eeuo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
DISTRO_DIR="$ROOT_DIR/distro"
VERSION="${XWT_VERSION:-2.0.0}"
ROOTFS="${XWT_ROOTFS_DIR:-$ROOT_DIR/out/debian-rootfs}"
OUT="${XWT_OUT_DIR:-$ROOT_DIR/out/distro}"
CORE_DIR="${XWT_CORE_DIR:?XWT_CORE_DIR must point to downloaded Buildroot core artifacts}"
BUILDROOT_CPIO="$CORE_DIR/rootfs-full.cpio.gz"
KERNEL="$CORE_DIR/zImage.xenon"
BOOT_DIR="${XWT_BOOT_DIR:?XWT_BOOT_DIR must point to downloaded XWT bootloader artifacts}"
MIRROR="${DEBIAN_PORTS_MIRROR:-https://ftp.ports.debian.org/debian-ports}"
SUITE="${DEBIAN_PORTS_SUITE:-unstable}"
ARCH=ppc64

fail() { echo "XWT distro build: $*" >&2; exit 1; }
need() { command -v "$1" >/dev/null 2>&1 || fail "missing host command: $1"; }
for cmd in debootstrap chroot cpio gzip readelf dpkg-deb zstd tar rsync python3; do need "$cmd"; done
[[ $EUID -eq 0 ]] || fail "run this builder as root"
[[ -s "$BUILDROOT_CPIO" ]] || fail "missing $BUILDROOT_CPIO"
[[ -s "$KERNEL" ]] || fail "missing $KERNEL"
[[ -s "$BOOT_DIR/xenon.elf" && -s "$BOOT_DIR/xwt-1f.bin" && -s "$BOOT_DIR/xwt-2f.bin" ]] || fail "incomplete XWT bootloader artifacts"

BRROOT="$ROOT_DIR/out/buildroot-root"
rm -rf "$ROOTFS" "$OUT" "$BRROOT"
mkdir -p "$ROOTFS" "$OUT" "$BRROOT"

echo "[1/8] Extracting the existing Xenon Buildroot runtime"
gzip -dc "$BUILDROOT_CPIO" | (cd "$BRROOT" && cpio -idm --quiet --no-absolute-filenames)

if [[ ! -d "$BRROOT/lib/modules" ]]; then
  fail "Buildroot artifact does not contain /lib/modules"
fi
mapfile -t MODULE_DIRS < <(find "$BRROOT/lib/modules" -mindepth 1 -maxdepth 1 -type d -printf '%f\n' | sort)
[[ ${#MODULE_DIRS[@]} -eq 1 ]] || fail "expected one Xenon module directory, found: ${MODULE_DIRS[*]:-none}"
KERNEL_RELEASE="${MODULE_DIRS[0]}"
echo "Using kernel modules for $KERNEL_RELEASE"

echo "[2/8] Bootstrapping Debian Ports $SUITE for big-endian $ARCH"
# The Debian Ports ppc64 archive is an unofficial port, not the released ppc64el ABI.
# HTTPS is used for transport; the archive keyring is installed before signed APT use.
debootstrap --arch="$ARCH" --foreign --variant=minbase --no-check-gpg \
  "$SUITE" "$ROOTFS" "$MIRROR"
if [[ -x /usr/bin/qemu-ppc64-static ]]; then
  install -m 0755 /usr/bin/qemu-ppc64-static "$ROOTFS/usr/bin/qemu-ppc64-static"
else
  fail "qemu-ppc64-static is required on the build host (install qemu-user-static)"
fi
chroot "$ROOTFS" /debootstrap/debootstrap --second-stage

# Temporarily trust only the HTTPS Debian Ports endpoint to bootstrap its own keyring.
mkdir -p "$ROOTFS/etc/apt/sources.list.d"
cat > "$ROOTFS/etc/apt/sources.list.d/debian-ports.list" <<EOF
# Temporary bootstrap source; replaced with signed configuration below.
deb [trusted=yes] $MIRROR $SUITE main
EOF
export DEBIAN_FRONTEND=noninteractive
chroot "$ROOTFS" apt-get update
chroot "$ROOTFS" apt-get install -y --no-install-recommends debian-ports-archive-keyring
cat > "$ROOTFS/etc/apt/sources.list.d/debian-ports.sources" <<EOF
Types: deb
URIs: $MIRROR
Suites: $SUITE
Components: main
Signed-By: /usr/share/keyrings/debian-ports-archive-keyring.gpg
EOF
rm -f "$ROOTFS/etc/apt/sources.list.d/debian-ports.list"
chroot "$ROOTFS" apt-get update

echo "[3/8] Installing the traditional Debian userspace"
chroot "$ROOTFS" apt-get install -y --no-install-recommends \
  apt systemd systemd-sysv systemd-networkd systemd-resolved systemd-timesyncd udev kmod dbus \
  locales ca-certificates sudo passwd login bash-completion busybox \
  coreutils findutils grep sed gawk util-linux procps ncurses-bin \
  iproute2 isc-dhcp-client wpasupplicant iw wireless-tools rfkill \
  curl wget less nano htop dialog pciutils usbutils evtest \
  e2fsprogs dosfstools parted zstd xz-utils gzip tar rsync file \
  fonts-dejavu-core fbset alsa-utils \
  zram-tools

# XWT's existing Wi-Fi and Ethernet helpers use the BusyBox udhcpc interface.
# Debian's BusyBox package may ship applets without creating all compatibility links.
if chroot "$ROOTFS" /bin/busybox --list 2>/dev/null | grep -qx udhcpc; then
  ln -sfn /usr/bin/busybox "$ROOTFS/usr/sbin/udhcpc"
  ln -sfn /usr/bin/busybox "$ROOTFS/usr/bin/udhcpc"
else
  echo "Warning: BusyBox was installed without the udhcpc applet; XWT Wi-Fi DHCP will need a dhclient adapter."
fi

# SDL packages are installed as a fallback. The XWT SDL 1.2 runtime itself is
# bundled from the pinned Buildroot build to retain its framebuffer backend.
chroot "$ROOTFS" apt-get install -y --no-install-recommends \
  libsdl1.2debian libsdl-ttf2.0-0 || {
    echo "Warning: Debian SDL runtime package set unavailable; bundled XWT SDL libraries will be used."
  }

mkdir -p "$ROOTFS/etc/apt/apt.conf.d"
cat > "$ROOTFS/etc/apt/apt.conf.d/80xwt-recommends" <<'EOF'
APT::Install-Recommends "false";
APT::Install-Suggests "false";
EOF

# Configure the standard filesystem and the console's low-memory defaults.
cat > "$ROOTFS/etc/hostname" <<'EOF'
xwt-xbox360
EOF
cat > "$ROOTFS/etc/hosts" <<'EOF'
127.0.0.1 localhost
127.0.1.1 xwt-xbox360
::1 localhost ip6-localhost ip6-loopback
EOF
cat > "$ROOTFS/etc/fstab" <<'EOF'
# XWT OS: persistent root filesystem on the USB ext4 partition.
LABEL=XWTROOT  /          ext4  defaults,noatime,errors=remount-ro  0  1
LABEL=XWTSWAP  none       swap  sw                                  0  0
LABEL=XWTBOOT  /mnt/xwt-usb  vfat  nofail,umask=0022                   0  2
EOF
mkdir -p "$ROOTFS/mnt/xwt-usb" "$ROOTFS/etc/systemd/network" "$ROOTFS/etc/modules-load.d" \
  "$ROOTFS/etc/wpa_supplicant" "$ROOTFS/usr/libexec" "$ROOTFS/opt/xwt/lib"
cp "$DISTRO_DIR/network/10-xwt-ethernet.network" "$ROOTFS/etc/systemd/network/10-xwt-ethernet.network"
cp "$DISTRO_DIR/network/wpa_supplicant.conf.example" "$ROOTFS/etc/wpa_supplicant/wpa_supplicant.conf.example"
chmod 0600 "$ROOTFS/etc/wpa_supplicant/wpa_supplicant.conf.example"
printf 'xpad\njoydev\nuinput\n' > "$ROOTFS/etc/modules-load.d/xwt.conf"
printf 'ALGO=zstd\nPERCENT=35\nPRIORITY=100\n' > "$ROOTFS/etc/default/zramswap"

# Locale: Brazilian Portuguese by default, with English UTF-8 also available.
grep -q '^pt_BR.UTF-8 UTF-8$' "$ROOTFS/etc/locale.gen" || echo 'pt_BR.UTF-8 UTF-8' >> "$ROOTFS/etc/locale.gen"
grep -q '^en_US.UTF-8 UTF-8$' "$ROOTFS/etc/locale.gen" || echo 'en_US.UTF-8 UTF-8' >> "$ROOTFS/etc/locale.gen"
chroot "$ROOTFS" locale-gen pt_BR.UTF-8 en_US.UTF-8 || true
cat > "$ROOTFS/etc/default/locale" <<'EOF'
LANG=pt_BR.UTF-8
LANGUAGE=pt_BR:pt:en
LC_ALL=
EOF

# Include the Xbox kernel modules and firmware from the very same kernel build.
mkdir -p "$ROOTFS/lib/modules" "$ROOTFS/lib/firmware"
rsync -a "$BRROOT/lib/modules/$KERNEL_RELEASE/" "$ROOTFS/lib/modules/$KERNEL_RELEASE/"
if [[ -d "$BRROOT/lib/firmware" ]]; then
  rsync -a "$BRROOT/lib/firmware/" "$ROOTFS/lib/firmware/"
fi
chroot "$ROOTFS" depmod -a "$KERNEL_RELEASE"

# Preserve the existing XWT interface, helper tools and free game assets.
echo "[4/8] Packaging XWT desktop, controls, tools and framebuffer libraries"
mkdir -p "$ROOTFS/usr/sbin" "$ROOTFS/usr/share/xwt" "$ROOTFS/usr/games" "$ROOTFS/usr/share/games"
for f in "$BRROOT"/usr/sbin/xwt-*; do
  [[ -f "$f" ]] || continue
  install -m 0755 "$f" "$ROOTFS/usr/sbin/$(basename "$f")"
done
for f in xwt-desktop xwt-gamepad-keys xwt-osk; do
  [[ -x "$BRROOT/usr/sbin/$f" ]] || fail "missing compiled XWT binary: $f"
  install -m 0755 "$BRROOT/usr/sbin/$f" "$ROOTFS/usr/sbin/$f"
done
if [[ -d "$ROOT_DIR/linux/overlay/usr/share/xwt" ]]; then
  rsync -a "$ROOT_DIR/linux/overlay/usr/share/xwt/" "$ROOTFS/usr/share/xwt/"
fi
for d in fonts games; do
  [[ ! -d "$BRROOT/usr/share/$d" ]] || rsync -a "$BRROOT/usr/share/$d/" "$ROOTFS/usr/share/$d/"
done
if [[ -d "$BRROOT/usr/games" ]]; then rsync -a "$BRROOT/usr/games/" "$ROOTFS/usr/games/"; fi
if [[ -d "$BRROOT/usr/share/games" ]]; then rsync -a "$BRROOT/usr/share/games/" "$ROOTFS/usr/share/games/"; fi
cp "$DISTRO_DIR/xwt-hardware-init" "$ROOTFS/usr/libexec/xwt-hardware-init"
chmod 0755 "$ROOTFS/usr/libexec/xwt-hardware-init"
cp "$DISTRO_DIR/xwt-firstboot-setup" "$ROOTFS/usr/sbin/xwt-firstboot-setup"
chmod 0755 "$ROOTFS/usr/sbin/xwt-firstboot-setup"

# Bundle the exact Buildroot SDL runtime dependency closure so fbcon remains available.
BINARIES=("$ROOTFS/usr/sbin/xwt-desktop" "$ROOTFS/usr/sbin/xwt-osk")
if [[ -d "$ROOTFS/usr/games" ]]; then
  while IFS= read -r -d '' f; do
    if file -b "$f" | grep -q '^ELF'; then BINARIES+=("$f"); fi
  done < <(find "$ROOTFS/usr/games" -maxdepth 1 -type f -print0)
fi
python3 "$DISTRO_DIR/copy-runtime-libs.py" --source-root "$BRROOT" \
  --destination "$ROOTFS/opt/xwt/lib" "${BINARIES[@]}"

# Include standard init hooks only when they do not rely on BusyBox/mdev internals.
mkdir -p "$ROOTFS/usr/share/doc/xwt-os"
cat > "$ROOTFS/etc/issue" <<'EOF'
XWT OS for Xbox 360 - Debian Ports ppc64
Kernel: Free60 Xenon - persistent ext4 root

EOF

# Install native systemd units. XWT desktop runs on the real framebuffer, with
# text-menu fallback if the video driver or SDL backend is unavailable.
for unit in xwt-hardware.service xwt-gamepad.service xwt-desktop.service; do
  install -m 0644 "$DISTRO_DIR/units/$unit" "$ROOTFS/usr/lib/systemd/system/$unit"
done
mkdir -p "$ROOTFS/etc/systemd/system/multi-user.target.wants"
for unit in xwt-hardware.service xwt-gamepad.service xwt-desktop.service; do
  ln -sfn "/usr/lib/systemd/system/$unit" "$ROOTFS/etc/systemd/system/multi-user.target.wants/$unit"
done
for unit in systemd-networkd.service systemd-resolved.service systemd-timesyncd.service zramswap.service; do
  if [[ -e "$ROOTFS/usr/lib/systemd/system/$unit" || -e "$ROOTFS/lib/systemd/system/$unit" ]]; then
    ln -sfn "/lib/systemd/system/$unit" "$ROOTFS/etc/systemd/system/multi-user.target.wants/$unit"
  fi
done
ln -sfn /run/systemd/resolve/stub-resolv.conf "$ROOTFS/etc/resolv.conf"

# No remotely reachable default account. The XWT desktop is started locally as root,
# as in the original appliance image; SSH server is deliberately not installed.
chroot "$ROOTFS" passwd -l root >/dev/null 2>&1 || true

# Clean package caches and temporary bootstrap files.
rm -f "$ROOTFS/usr/bin/qemu-ppc64-static"
rm -rf "$ROOTFS/var/lib/apt/lists"/* "$ROOTFS/var/cache/apt"/* "$ROOTFS/tmp"/*
mkdir -p "$ROOTFS/tmp"
chmod 1777 "$ROOTFS/tmp"

# Validate the root tree before it is serialized.
[[ -x "$ROOTFS/usr/sbin/xwt-desktop" ]] || fail "XWT desktop was not installed"
[[ -x "$ROOTFS/usr/sbin/xwt-gamepad-keys" ]] || fail "gamepad daemon was not installed"
[[ -d "$ROOTFS/lib/modules/$KERNEL_RELEASE" ]] || fail "kernel modules missing from Debian rootfs"
[[ -s "$ROOTFS/etc/fstab" ]] || fail "fstab missing"

echo "[5/8] Building the Debian dpkg package for XWT components"
PKG="$ROOT_DIR/out/xwt-os-package"
rm -rf "$PKG"
mkdir -p "$PKG/DEBIAN"
cat > "$PKG/DEBIAN/control" <<EOF
Package: xwt-os
Version: $VERSION
Section: misc
Priority: optional
Architecture: ppc64
Maintainer: XWT Linux Project
Depends: systemd, bash, kmod, udev
Description: Xbox 360 desktop and hardware integration for XWT OS
 XWT desktop, Xbox controller bridge, Xenon hardware startup and framebuffer assets.
EOF
# The installed files are packaged from the finished rootfs; standard Debian files
# are intentionally excluded so dpkg owns only the XWT-specific payload.
for path in usr/sbin/xwt-* usr/share/xwt usr/libexec/xwt-hardware-init opt/xwt/lib usr/lib/systemd/system/xwt-*.service; do
  if [[ -e "$ROOTFS/$path" ]]; then
    mkdir -p "$PKG/$(dirname "$path")"
    cp -a "$ROOTFS/$path" "$PKG/$path"
  fi
done
mkdir -p "$OUT"
dpkg-deb --build --root-owner-group "$PKG" "$OUT/xwt-os_${VERSION}_ppc64.deb" >/dev/null

# Build a clean installation tree for the USB installer.
echo "[6/8] Creating the persistent Debian root filesystem archive"
cp "$KERNEL" "$OUT/zImage.xenon"
cp "$BOOT_DIR/xenon.elf" "$OUT/xenon.elf"
cp "$BOOT_DIR/xwt-1f.bin" "$OUT/xwt-1f.bin"
cp "$BOOT_DIR/xwt-2f.bin" "$OUT/xwt-2f.bin"
# Record useful platform metadata in the installed OS.
cat > "$ROOTFS/etc/xwt-release" <<EOF
NAME="XWT OS"
VERSION="$VERSION"
BASE="Debian Ports unstable"
ARCH="ppc64 (big-endian)"
PLATFORM="Xbox 360 Xenon"
KERNEL="$KERNEL_RELEASE"
EOF

# Register XWT's own desktop/hardware payload in dpkg, just like a normal
# Debian package. The package is also shipped separately for later upgrades.
cp "$OUT/xwt-os_${VERSION}_ppc64.deb" "$ROOTFS/tmp/xwt-os.deb"
chroot "$ROOTFS" dpkg -i /tmp/xwt-os.deb
rm -f "$ROOTFS/tmp/xwt-os.deb"

# The tar is a conventional persistent root filesystem, not a CPIO/squashfs layer set.
tar --numeric-owner --xattrs --acls --zstd -I 'zstd -T0 -15' \
  -cpf "$OUT/rootfs.tar.zst" -C "$ROOTFS" .

cp "$DISTRO_DIR/installer/install-usb.sh" "$OUT/install-usb.sh"
chmod 0755 "$OUT/install-usb.sh"
cp "$DISTRO_DIR/README-PT-BR.md" "$OUT/README-INSTALACAO-PT-BR.md"
if [[ -d "$ROOT_DIR/usb/X360WebTotal" ]]; then
  rsync -a "$ROOT_DIR/usb/X360WebTotal/" "$OUT/X360WebTotal/"
fi
mkdir -p "$OUT/X360WebTotal/config" "$OUT/X360WebTotal/cache" "$OUT/X360WebTotal/data" "$OUT/X360WebTotal/logs"
printf '%s\n' "$VERSION" > "$OUT/VERSION"
printf '%s\n' "xwt-os-${VERSION}-debian-ports-ppc64-xenon" > "$OUT/REVISION.txt"

# Verify the boot command line template stays within the menu/parser limits.
python3 - "$OUT" <<'PY'
from pathlib import Path
import sys
out = Path(sys.argv[1])
cmdline = "root=PARTUUID=12345678-03 rootfstype=ext4 rw rootwait rootdelay=5 console=tty0 console=ttyS0,115200n8 panic=60 maxcpus=6 coherent_pool=16M"
if len(cmdline) > 255:
    raise SystemExit(f"XWT Boot kernel command line too long: {len(cmdline)} bytes")
for name in ("zImage.xenon", "xenon.elf", "xwt-1f.bin", "xwt-2f.bin", "rootfs.tar.zst", "xwt-os_" + (out / "VERSION").read_text().strip() + "_ppc64.deb"):
    p = out / name
    if not p.is_file() or p.stat().st_size == 0:
        raise SystemExit(f"missing or empty build output: {p}")
print("XWT distro payload validation passed")
PY

echo "[7/8] Writing SHA-256 manifest"
(
  cd "$OUT"
  find . -maxdepth 1 -type f ! -name SHA256SUMS -printf '%f\n' | sort | while IFS= read -r f; do sha256sum "$f"; done > SHA256SUMS
)

echo "[8/8] Done"
echo "Output: $OUT"
ls -lh "$OUT"
