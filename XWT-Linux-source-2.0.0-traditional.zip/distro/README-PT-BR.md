# XWT OS — distribuição tradicional para Xbox 360

O **XWT OS** é uma distribuição Linux dedicada ao Xbox 360 (Xenon), construída sobre o **Debian Ports `ppc64` big-endian** e integrada ao kernel Free60 Xenon e ao XWT Boot do projeto.

Ela muda o modelo anterior de rootfs temporário + pacotes SquashFS para um sistema de arquivos raiz persistente em **ext4**, com gerenciamento de pacotes Debian (`apt`/`dpkg`) e inicialização por `systemd`. A interface XWT em SDL/framebuffer e os serviços de controle e hardware são preservados como componentes específicos do console.

> Esta é uma porta experimental. `ppc64` big-endian é uma porta Debian Ports não oficial; não confunda com `ppc64el`, que é little-endian e incompatível com o ABI do Xenon. O boot e os periféricos precisam ser validados no Xbox 360 real.

## Arquitetura

```text
Aurora / XeXMenu / XeLL (método de entrada já usado no console)
                         │
                         ▼
               XWT Boot / XellLaunch2
                         │
                         ▼
              zImage.xenon (wrapper ELF32)
              kernel Free60 Xenon PPC64
                         │
                         ▼
             USB: root=PARTUUID=<assinatura-MBR>-03
                         │
                         ▼
              Debian Ports ppc64 / ext4
                systemd + udev + apt/dpkg
                         │
              ┌──────────┴──────────┐
              ▼                     ▼
        XWT SDL desktop       Serviços de hardware
        menu de texto         controle / rede / USB
```

O gerenciador XWT Boot e o wrapper ELF32 continuam necessários: o kernel PPC64 não deve ser entregue diretamente ao carregador ELF32 do caminho XeLL/libxenon. O bootloader carrega o `zImage.xenon`; o kernel, por sua vez, monta a partição ext4 diretamente, sem carregar o rootfs Debian inteiro em um initramfs.

## Layout do pendrive

O instalador apaga o dispositivo USB escolhido e cria uma tabela MBR com três partições:

| Partição | Tamanho | Formato | Rótulo | Função |
|---|---:|---|---|---|
| 1 | 1 GiB | FAT32 | `XWTBOOT` | XWT Boot, kernel, perfil e arquivos de inicialização |
| 2 | 512 MiB | Swap | `XWTSWAP` | Swap de emergência |
| 3 | restante | ext4 | `XWTROOT` | Sistema Debian persistente, programas e dados |

O dispositivo precisa ter pelo menos 8 GiB. Um pendrive maior é recomendado. O sistema também pode usar um HDD/SSD USB compatível, desde que o XeLL/XWT Boot consiga enumerá-lo.

## Como compilar

1. Envie esta fonte para o repositório GitHub do XWT.
2. Abra **Actions → XWT OS - Build Traditional Distro → Run workflow**.
3. O workflow compila o kernel/rootfs Buildroot auxiliar já usado pelo projeto, compila o XWT Boot, prepara o Debian Ports `ppc64`, instala os componentes XWT e valida os artefatos.
4. Baixe o artefato `xwt-os-traditional-<commit>` e extraia `XWT-OS-Traditional-Xbox360-2.0.0.zip`.

O Buildroot continua sendo usado no processo de compilação para fornecer o kernel, os módulos Xenon e a toolchain, mas **não é mais o sistema instalado**. O sistema instalado é Debian Ports, com banco dpkg e APT.

## Como instalar

**Atenção: o instalador apaga completamente o dispositivo selecionado.** Faça backup dos dados e confirme cuidadosamente o nome do disco.

Em um computador Linux, extraia o ZIP de release e execute:

```bash
sudo ./install-usb.sh /dev/sdX
```

Troque `/dev/sdX` pelo disco USB inteiro (por exemplo `/dev/sdb`), nunca por uma partição como `/dev/sdb1`. O script exige que você digite a frase de confirmação completa antes de formatar.

Depois de instalar, conecte o USB ao Xbox 360 RGH/JTAG e use o mesmo caminho de entrada XWT/XeLL que já funciona no console. O perfil criado em `XWTBoot/config.cfg` seleciona `zImage.xenon`, não carrega initrd e passa `root=PARTUUID=<assinatura-MBR>-03` ao kernel. O instalador atribui uma assinatura à tabela MBR e consulta o `PARTUUID` real da partição ext4; assim, o próprio kernel encontra a raiz sem depender de initramfs ou de nomes USB como `/dev/sda3`. O arquivo `xenon.elf` e as imagens `xwt-1f.bin`/`xwt-2f.bin` também ficam na partição FAT32.

O instalador prepara o USB; ele **não** grava NAND, KV, SMC ou firmware e não instala nada no armazenamento interno do console.

## Gerenciamento de pacotes

No terminal do XWT OS, com conexão à Internet:

```bash
sudo apt update
sudo apt install nome-do-pacote
sudo apt remove nome-do-pacote
sudo apt upgrade
```

A senha da conta root fica bloqueada por padrão. No menu textual, abra **Terminal** e execute `xwt-firstboot-setup` para definir uma senha local; depois disso, o login local de manutenção e o `sudo` ficam disponíveis. O servidor SSH não é instalado nem habilitado por padrão.

Para consultar a arquitetura:

```bash
dpkg --print-architecture
uname -m
cat /etc/xwt-release
```

A arquitetura esperada do pacote Debian é `ppc64` (big-endian), não `ppc64el`.

## Rede e Wi-Fi

- Ethernet: o `systemd-networkd` tenta DHCP nas interfaces Ethernet reconhecidas (`eth*`/`en*`).
- Wi-Fi USB: a compatibilidade depende do chipset e do driver disponível no kernel. O assistente XWT mantém a configuração em `X360WebTotal/config/wpa_supplicant.conf` na partição FAT32, e usa `wpa_supplicant`, `iw` e `udhcpc` ou `dhclient`, conforme o pacote disponível.
- A presença de um pacote ou módulo não garante que todo adaptador USB funcione: confirme o chipset e o firmware exigidos pelo dispositivo.

## Memória e desempenho

O Xbox 360 tem 512 MiB de RAM. O sistema é configurado para ser enxuto, com serviços essenciais, zram e swap. Evite instalar ambientes desktop pesados, bancos grandes ou serviços simultâneos desnecessários. A disponibilidade de pacotes Debian não significa que todos sejam utilizáveis no console: aplicativos podem exigir instruções AltiVec/VMX, memória ou drivers que a plataforma não oferece de forma compatível.

## Limitações conhecidas

- O Debian Ports `ppc64` big-endian é experimental/não oficial; alguns pacotes podem estar ausentes, quebrados ou exigir compilação específica.
- A porta Xenon tem particularidades de DMA, framebuffer, USB e SMP. O kernel deste projeto e seus drivers continuam sendo específicos do Xbox 360.
- A interface XWT é SDL sobre framebuffer; não é GNOME/KDE nem um desktop X11/Wayland.
- Aceleração 3D completa, navegador moderno, áudio universal, HDMI e suporte universal a Wi-Fi não são prometidos por esta versão.
- O build do rootfs Debian é feito no GitHub Actions e depende da disponibilidade dos repositórios Debian Ports. Este ZIP de fonte contém o gerador e o instalador, não uma imagem binária pré-compilada.
- É obrigatório testar o resultado no modelo/revisão do console e no dispositivo USB usados. Se o vídeo falhar, inicialize pelo perfil de texto/recuperação do XWT Boot e consulte `journalctl -b`/`dmesg`.

## Fontes técnicas

- Debian Ports: <https://www.debian.org/ports/>
- Debian Ports ppc64: <https://ftp.ports.debian.org/debian-ports/>
- Guia comunitário de Debian ppc64 no Xbox 360: <https://free60.org/Linux/Debian/>
- Buildroot manual: <https://buildroot.org/downloads/manual/manual.html>
