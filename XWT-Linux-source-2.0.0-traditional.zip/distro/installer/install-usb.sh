#!/usr/bin/env bash
set -Eeuo pipefail

# Destructive installer for the traditional XWT OS USB layout.
# Run from the extracted XWT-OS-Traditional release on a Linux host.

fail() { printf 'ERRO: %s\n' "$*" >&2; exit 1; }
need() { command -v "$1" >/dev/null 2>&1 || fail "comando ausente: $1"; }

[[ $EUID -eq 0 ]] || fail "execute com sudo/root"
[[ $# -eq 1 ]] || fail "uso: sudo $0 /dev/sdX"

DEVICE="$(readlink -f -- "$1")"
[[ -b "$DEVICE" ]] || fail "dispositivo não encontrado: $DEVICE"
need lsblk; need parted; need partprobe; need udevadm; need wipefs; need sfdisk; need od
need mkfs.vfat; need mkswap; need mkfs.ext4; need mount; need umount
need tar; need zstd; need blkid; need sha256sum; need rsync

TYPE="$(lsblk -dnro TYPE "$DEVICE" | head -n1)"
[[ "$TYPE" == disk ]] || fail "informe o disco inteiro, não uma partição ($DEVICE)"
SIZE_BYTES="$(lsblk -bdnro SIZE "$DEVICE" | head -n1)"
(( SIZE_BYTES >= 8 * 1024 * 1024 * 1024 )) || fail "o dispositivo precisa ter pelo menos 8 GiB"

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
# In the release ZIP this script is at the bundle root; in the source tree it lives
# under distro/installer. Support both layouts without guessing a filename.
if [[ -s "$SCRIPT_DIR/rootfs.tar.zst" ]]; then
  BASE_DIR="$SCRIPT_DIR"
else
  BASE_DIR="$(cd -- "$SCRIPT_DIR/../.." && pwd)"
fi
[[ -s "$BASE_DIR/SHA256SUMS" ]] || fail "manifesto SHA256SUMS ausente"
(cd "$BASE_DIR" && sha256sum -c SHA256SUMS) || fail "falha na verificação SHA-256 do pacote"
for f in rootfs.tar.zst zImage.xenon xenon.elf xwt-1f.bin xwt-2f.bin; do
  [[ -s "$BASE_DIR/$f" ]] || fail "arquivo obrigatório ausente: $BASE_DIR/$f"
done

# Refuse to modify any disk that currently has mounted descendants.
MOUNTS="$(lsblk -nrpo NAME,MOUNTPOINT "$DEVICE" | awk '$2 != "" {print $1 ":" $2}')"
[[ -z "$MOUNTS" ]] || fail "desmonte todas as partições antes. Montagens encontradas: $MOUNTS"

printf '\nATENÇÃO: TODOS OS DADOS DE %s SERÃO APAGADOS.\n' "$DEVICE"
printf 'Digite exatamente APAGAR %s para confirmar: ' "$DEVICE"
read -r CONFIRM
[[ "$CONFIRM" == "APAGAR $DEVICE" ]] || fail "confirmação incorreta; nada foi alterado"

PART_SUFFIX=""
[[ "$(basename "$DEVICE")" =~ [0-9]$ ]] && PART_SUFFIX="p"
P1="${DEVICE}${PART_SUFFIX}1"
P2="${DEVICE}${PART_SUFFIX}2"
P3="${DEVICE}${PART_SUFFIX}3"
TMP="$(mktemp -d /tmp/xwt-install.XXXXXX)"
BOOT_MNT="$TMP/boot"
ROOT_MNT="$TMP/root"
cleanup() {
  set +e
  mountpoint -q "$ROOT_MNT" && umount "$ROOT_MNT"
  mountpoint -q "$BOOT_MNT" && umount "$BOOT_MNT"
  rm -rf "$TMP"
}
trap cleanup EXIT
trap 'exit 130' INT
trap 'exit 143' TERM
mkdir -p "$BOOT_MNT" "$ROOT_MNT"

printf '[1/7] Criando tabela MBR e partições...\n'
wipefs -af "$DEVICE"
parted -s "$DEVICE" mklabel msdos
parted -s "$DEVICE" mkpart primary fat32 1MiB 1025MiB
parted -s "$DEVICE" set 1 boot on
parted -s "$DEVICE" mkpart primary linux-swap 1025MiB 1537MiB
parted -s "$DEVICE" mkpart primary ext4 1537MiB 100%
# The kernel cannot resolve filesystem LABEL= without userspace/initramfs.
# Give the MBR a non-zero disk signature so root=PARTUUID=... works in-kernel.
DISK_SIGNATURE="$(od -An -N4 -tx4 /dev/urandom | tr -d '[:space:]')"
[[ "$DISK_SIGNATURE" =~ ^[0-9a-fA-F]{8}$ ]] || fail "não foi possível gerar assinatura MBR"
sfdisk --disk-id "$DEVICE" "0x$DISK_SIGNATURE"
partprobe "$DEVICE"
udevadm settle
for attempt in {1..20}; do
  [[ -b "$P1" && -b "$P2" && -b "$P3" ]] && break
  sleep 0.5
done
[[ -b "$P1" && -b "$P2" && -b "$P3" ]] || fail "o kernel não disponibilizou as três partições"

printf '[2/7] Formatando FAT32, swap e ext4...\n'
mkfs.vfat -F 32 -n XWTBOOT "$P1"
mkswap -L XWTSWAP "$P2"
mkfs.ext4 -F -L XWTROOT -m 1 "$P3"

printf '[3/7] Instalando o sistema Debian persistente...\n'
mount "$P3" "$ROOT_MNT"
tar --zstd --numeric-owner --xattrs --acls -xpf "$BASE_DIR/rootfs.tar.zst" -C "$ROOT_MNT"

printf '[4/7] Instalando kernel e arquivos de boot...\n'
mount "$P1" "$BOOT_MNT"
mkdir -p "$BOOT_MNT/X360WebTotal/Linux" "$BOOT_MNT/X360WebTotal/config" \
  "$BOOT_MNT/X360WebTotal/cache" "$BOOT_MNT/X360WebTotal/data" \
  "$BOOT_MNT/X360WebTotal/logs" "$BOOT_MNT/XWTBoot"
if [[ -d "$BASE_DIR/X360WebTotal" ]]; then
  rsync -a "$BASE_DIR/X360WebTotal/" "$BOOT_MNT/X360WebTotal/"
fi
install -m 0644 "$BASE_DIR/zImage.xenon" "$BOOT_MNT/X360WebTotal/Linux/zImage.xenon"
install -m 0644 "$BASE_DIR/xenon.elf" "$BOOT_MNT/xenon.elf"
install -m 0644 "$BASE_DIR/xwt-1f.bin" "$BOOT_MNT/xwt-1f.bin"
install -m 0644 "$BASE_DIR/xwt-2f.bin" "$BOOT_MNT/xwt-2f.bin"

ROOT_PARTUUID="$(blkid -s PARTUUID -o value "$P3")"
[[ "$ROOT_PARTUUID" =~ ^[0-9A-Fa-f]{8}-03$ ]] || fail "PARTUUID MBR inválido para a partição root: $ROOT_PARTUUID"
KERNEL_CMDLINE="root=PARTUUID=$ROOT_PARTUUID rootfstype=ext4 rw rootwait rootdelay=5 console=tty0 console=ttyS0,115200n8 panic=60 maxcpus=6 coherent_pool=16M"
(( ${#KERNEL_CMDLINE} <= 255 )) || fail "linha de comando do kernel ultrapassa 255 bytes"

printf '[5/7] Configurando XWT Boot para montar o root ext4...\n'
cat > "$BOOT_MNT/XWTBoot/config.cfg" <<CFG
# XWT OS tradicional - Debian Ports ppc64 big-endian
profile_name=XWT OS Debian PPC64
folder=uda:/X360WebTotal/Linux
kernel=zImage.xenon
initrd=
mode=4
custom_cmdline=$KERNEL_CMDLINE
timeout=5
autoboot=1
CFG

printf '[6/7] Instalando documentação e manifestos...\n'
cp "$BASE_DIR/README-INSTALACAO-PT-BR.md" "$BOOT_MNT/README-INSTALACAO-PT-BR.md"
cp "$BASE_DIR/SHA256SUMS" "$BOOT_MNT/SHA256SUMS.release"
if [[ -f "$ROOT_MNT/etc/xwt-release" ]]; then
  printf 'XWT OS instalado em %s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)" > "$ROOT_MNT/etc/xwt-installed"
fi
sync

printf '[7/7] Finalizando...\n'
ROOT_UUID="$(blkid -s UUID -o value "$P3")"
BOOT_UUID="$(blkid -s UUID -o value "$P1")"
SWAP_UUID="$(blkid -s UUID -o value "$P2")"
sync
printf '\nInstalação concluída.\n'
printf 'USB: %s\nRoot ext4: %s (UUID %s)\nBoot FAT32: %s (UUID %s)\nSwap: %s (UUID %s)\n' \
  "$DEVICE" "$P3" "$ROOT_UUID" "$P1" "$BOOT_UUID" "$P2" "$SWAP_UUID"
printf 'Boot profile: XWTBoot/config.cfg (root=PARTUUID=%s)\n' "$ROOT_PARTUUID"
printf 'Não remova o USB durante o uso do sistema.\n'
