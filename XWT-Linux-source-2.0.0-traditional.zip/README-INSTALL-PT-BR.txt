XWT OS 2.0.0 — INSTALAÇÃO DA DISTRIBUIÇÃO TRADICIONAL

Esta fonte adiciona uma variante de distribuição Linux tradicional para Xbox 360: Debian Ports ppc64 big-endian, rootfs persistente ext4, systemd, apt/dpkg e integração com o kernel Free60 Xenon / XWT Boot.

COMPILAÇÃO
1. Envie a fonte atualizada para o GitHub.
2. Abra Actions -> XWT OS - Build Traditional Distro -> Run workflow.
3. Aguarde os jobs do kernel, bootloader e rootfs Debian terminarem.
4. Baixe o artefato xwt-os-traditional-<commit> e extraia XWT-OS-Traditional-Xbox360-2.0.0.zip.

INSTALAÇÃO NO USB (LINUX)
1. Conecte o pendrive ao computador e identifique o disco inteiro com lsblk.
2. Faça backup: o instalador apaga todas as partições do dispositivo escolhido.
3. Execute: sudo ./install-usb.sh /dev/sdX (substitua pelo disco correto).
4. Digite a confirmação exata solicitada pelo script.
5. Conecte o USB ao Xbox 360 RGH/JTAG e use o caminho XWT/XeLL já funcional no console.

LAYOUT
- FAT32 XWTBOOT: XWT Boot, kernel, configuração e dados XWT.
- SWAP XWTSWAP: swap de emergência.
- ext4 XWTROOT: sistema Debian persistente.

BOOT
O XWT Boot carrega o wrapper ELF32 zImage.xenon. O kernel PPC64 monta a partição ext4 pelo PARTUUID MBR (gerado pelo instalador) e inicia o Debian sem initramfs completo. O kernel PPC64 não deve ser substituído por vmlinux ELF64 no carregador ELF32.

PACOTES
Com rede disponível: apt update; apt install nome-do-pacote; apt upgrade.
A arquitetura Debian é ppc64 big-endian, não ppc64el.

SEGURANÇA E LIMITES
O instalador só modifica o USB informado; não grava NAND, KV, SMC ou firmware. Debian Ports ppc64 é uma porta experimental/não oficial e alguns pacotes podem precisar de ajustes ou recompilação. O Xbox 360 tem 512 MiB de RAM. A interface XWT usa SDL/framebuffer. Teste físico de boot, vídeo, USB, rede e controle ainda é obrigatório.

Consulte README-INSTALACAO-PT-BR.md no pacote de release para detalhes, troubleshooting e arquitetura.
