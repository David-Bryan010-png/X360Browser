# X360Browser 6.0.0 — estado da fonte

## Alterações desta versão

- A navegação usa o caminho gráfico como modo padrão em páginas HTML.
- O leitor textual de páginas foi removido do caminho principal; o corpo de uma resposta não é mais desenhado por `draw_scrolled_page_text`.
- X percorre página gráfica, links e recursos.
- Falhas do renderer, recursos binários e erros de rede recebem superfícies de diagnóstico em vez de uma página textual disfarçada de navegador.
- O estado visual é invalidado quando uma resposta é atribuída à página ativa.
- Atualizador continua usando GitHub Releases e validação SHA-256; não exige Vercel nem arquivo de configuração de URL.

## Validação realizada neste ambiente

- Integridade do pacote: 76 arquivos obrigatórios, versão 6.0.0.
- Contratos de visualização: 11/11.
- Contratos shader/runtime: 14/14.
- Contratos de paths do workflow: 13/13.
- Contratos do atualizador: 12/12.
- Testes de host XenonWeb, XenonScript, XenonMedia, transporte, dispatch, layout e compatibilidade de URL passaram.
- CMake/CTest de host: 3/3 testes passaram.

## Ainda exige validação externa

- O GitHub Actions precisa compilar o XEX usando o toolchain PowerPC/xSDK.
- O executável deve ser testado em Xbox 360 RGH/JTAG real para validar GPU, shaders, teclado/gamepad, rede e navegação.
- Sites atuais e jogos web ainda excedem o subconjunto de HTML/CSS/JavaScript deste motor. O objetivo de navegador moderno completo não foi alcançado por este marco.
