#!/usr/bin/env python3
"""Fail-fast integrity checks for the selected X360Browser source version."""
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
REQUIRED = [
    "VERSION", "CMakeLists.txt", "README.md", "CHANGELOG.md", "TEST-RESULTS.txt",
    "THIRD_PARTY_NOTICES.md", "X360Browser-video-config.example.txt",
    "tests/run_host_tests.py", "tests/validate_project_integrity.py",
    "tests/web_engine_fixture_server.py", "tests/test_web_engine_native.c",
    "tests/test_web_engine_dispatch.c", "tests/test_youtube_compatibility.c", "tests/test_visual_layout.c",
    "tests/test_xenonweb.c", "tests/test_xenonweb_layout.c", "tests/test_xenonscript.c",
    "tests/test_xenonmedia.c", "tests/test_xbox_shader_contract.py", "tests/test_workflow_artifact_paths.py", "tests/test_auto_update_contract.py", "tests/test_auto_release_contract.py", "tests/test_default_xex_contract.py", "tests/test_runtime_view_contract.py", "tests/jpeg_baseline_fixture.h",
    "examples/media-playback.html", "examples/responsive-layout-leap.html",
    "include/x360browser/version.hpp", "engine/xenonweb/xw_dom.c",
    "engine/xenonweb/xw_css.c", "engine/xenonweb/xw_css.h",
    "engine/xenonweb/xw_script.c", "engine/xenonweb/xw_layout.c",
    "engine/xenonmedia/xm_media.c", "engine/xenonmedia/xm_media.h",
    "engine/xenonmedia/xm_playback.c", "engine/xenonmedia/xm_playback.h",
    "platform/xbox360/xsdk/main.c", "platform/xbox360/xsdk/web_engine.c",
    "platform/xbox360/xsdk/web_engine.h", "platform/xbox360/xsdk/web_engine_dispatch.c",
    "platform/xbox360/xsdk/visual_renderer.c", "platform/xbox360/xsdk/CMakeLists.txt",
    "platform/xbox360/xsdk/update_manager.c", "platform/xbox360/xsdk/update_manager.h",
    "platform/xbox360/xsdk/update_manifest.c", "platform/xbox360/xsdk/update_manifest.h", "tests/test_update_manifest.c",
    "tools/build_xbox_shell.sh", ".github/workflows/build-xex-from-zip.yml",
    "docs/MEDIA-PLAYBACK.md", "docs/COMPATIBILITY-3.5.0-native-web-media.md",
    "docs/COMPATIBILITY-3.6.0-web-compatibility-preview.md",
    "docs/ENGINE-GAP-AUDIT-3.5.0.md", "docs/XENONMEDIA-ENGINE.md",
    "docs/XENONWEB-ENGINE.md", "docs/STATUS.md", "docs/ARCHITECTURE.md",
    "docs/RESUMO-3.6.0-pt-BR.md", "docs/COMPATIBILITY-4.1.0.md", "docs/COMPATIBILITY-4.3.0.md", "docs/COMPATIBILITY-5.0.0.md", "docs/COMPATIBILITY-5.1.0.md", "docs/SOURCE-CHANGES-5.1.0.md", "docs/COMPATIBILITY-5.2.0.md", "docs/SOURCE-CHANGES-5.2.0.md", "docs/GRAPHICAL-ENGINE-5.2.0-pt-BR.md", "docs/COMPATIBILITY-5.3.0.md", "docs/SOURCE-CHANGES-5.3.0.md", "docs/GRAPHICAL-ENGINE-5.3.0-pt-BR.md", "docs/COMPATIBILITY-6.0.0.md", "docs/SOURCE-CHANGES-6.0.0.md", "docs/GRAPHICAL-ENGINE-6.0.0-pt-BR.md", "docs/COMPATIBILITY-6.1.0.md", "docs/SOURCE-CHANGES-6.1.0.md", "docs/AUTO-UPDATE-GITHUB-6.1.0-pt-BR.md", "docs/COMPATIBILITY-6.2.0.md", "docs/SOURCE-CHANGES-6.2.0.md", "docs/ENGINE-AUDIT-6.2.0.md", "docs/AUTO-UPDATE-GITHUB-6.2.0-pt-BR.md", "docs/AUDIT-4.0.0-SOURCE.md",
    "docs/TESTING.md", "docs/XBOX_BUILD.md", "docs/SOURCE-CHANGES-4.3.0.md", "docs/50-LACUNAS-PRIORITARIAS-pt-BR.md",
]
missing = [name for name in REQUIRED if not (ROOT / name).is_file() or (ROOT / name).stat().st_size == 0]
if missing:
    print("FAIL: source package is incomplete:", file=sys.stderr)
    for name in missing:
        print(f"  - {name}", file=sys.stderr)
    raise SystemExit(2)


def read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8", errors="replace")

version = read("VERSION").strip()
if not re.fullmatch(r"[0-9]+\.[0-9]+\.[0-9]+", version):
    raise SystemExit(f"FAIL: VERSION must be MAJOR.MINOR.PATCH, found {version!r}")
EXPECTED_VERSION = version
version_major = int(version.split(".", 1)[0])

cmake = read("CMakeLists.txt")
platform_cmake = read("platform/xbox360/xsdk/CMakeLists.txt")
workflow = read(".github/workflows/build-xex-from-zip.yml")
version_header = read("include/x360browser/version.hpp")
build_script = read("tools/build_xbox_shell.sh")
main = read("platform/xbox360/xsdk/main.c")
renderer = read("platform/xbox360/xsdk/visual_renderer.c")
css = read("engine/xenonweb/xw_css.c")
css_header = read("engine/xenonweb/xw_css.h")
media = read("engine/xenonmedia/xm_media.c")
media_header = read("engine/xenonmedia/xm_media.h")
test_media = read("tests/test_xenonmedia.c")
test_css = read("tests/test_xenonweb.c")
dispatch = read("platform/xbox360/xsdk/web_engine_dispatch.c")
test_dispatch = read("tests/test_web_engine_dispatch.c")
audit = read("docs/ENGINE-GAP-AUDIT-3.5.0.md")
priority_gaps_pt = read("docs/50-LACUNAS-PRIORITARIAS-pt-BR.md")
compat = read("docs/COMPATIBILITY-5.2.0.md")
media_doc = read("docs/MEDIA-PLAYBACK.md")
config = read("X360Browser-video-config.example.txt")
third_party = read("THIRD_PARTY_NOTICES.md")

markers = [
    ("CMakeLists.txt", cmake, "file(STRINGS \"${CMAKE_CURRENT_SOURCE_DIR}/VERSION\" X360BROWSER_PROJECT_VERSION"),
    ("platform/xbox360/xsdk/CMakeLists.txt", platform_cmake, "file(STRINGS \"${CMAKE_CURRENT_SOURCE_DIR}/../../../VERSION\" X360BROWSER_PROJECT_VERSION"),
    ("include/x360browser/version.hpp", version_header, f'#define X360BROWSER_VERSION_STRING "{version}"'),
    ("include/x360browser/version.hpp", version_header, f"#define X360BROWSER_VERSION_MAJOR {version_major}"),
    ("tools/build_xbox_shell.sh", build_script, 'PROJECT_VERSION="$(tr -d'),
    ("engine/xenonweb/xw_css.h", css_header, "XW_CSS_MAX_CUSTOM_PROPERTIES"),
    ("engine/xenonweb/xw_css.c", css, "css_resolve_vars"),
    ("engine/xenonweb/xw_css.c", css, "css_collect_root_custom_properties"),
    ("tests/test_xenonweb.c", test_css, "CSS :root custom properties resolve through var()"),
    ("engine/xenonmedia/xm_media.h", media_header, "XM_CODEC_IMA_ADPCM"),
    ("engine/xenonmedia/xm_media.h", media_header, "xm_media_webvtt_find_active_cue"),
    ("engine/xenonmedia/xm_media.c", media, "xm_media_decode_wav_pcm16"),
    ("engine/xenonmedia/xm_media.c", media, "xm_media_webvtt_find_active_cue"),
    ("tests/test_xenonmedia.c", test_media, "IMA ADPCM stereo blocks decode"),
    ("tests/test_xenonmedia.c", test_media, "WebVTT active-cue lookup"),
    ("platform/xbox360/xsdk/visual_renderer.c", renderer, "xm_media_decode_image_rgba"),
    ("platform/xbox360/xsdk/visual_renderer.c", renderer, "xw_layout_page(page, scroll_pixels, frame)"),
    ("platform/xbox360/xsdk/web_engine.h", read("platform/xbox360/xsdk/web_engine.h"), "WEB_ENGINE_SOURCE_HTML_CAP (4U * 1024U * 1024U)"),
    ("engine/xenonweb/xw_layout.c", read("engine/xenonweb/xw_layout.c"), "YouTube embed is not inline yet"),
    ("platform/xbox360/xsdk/web_engine_dispatch.c", dispatch, "XenonWeb + XenonNet transport"),
    ("tests/test_web_engine_dispatch.c", test_dispatch, "first-party XenonWeb page engine"),
    ("workflow", workflow, 'X360Browser-${PROJECT_VERSION}-source.zip'),
    ("workflow", workflow, "Always cross-build and package Xbox 360 XEX"),
    ("workflow", workflow, "timeout-minutes: 90"),
    ("default.xex cross-layer contract", read("tests/test_default_xex_contract.py"), "manifest consumes only default.xex asset names"),
    ("relative URL resolver", read("platform/xbox360/xsdk/web_engine.c"), "normalize_url_path"),
    ("relative URL regression", read("tests/test_web_engine_native.c"), "query-only URL preserves the current path"),
    ("Xbox UI label", main, '"X360Browser " X360BROWSER_VERSION_STRING'),
    ("workflow", workflow, "artifact-path-safe"),
    ("workflow", workflow, "find \"$DOWNLOAD_DIR\" -type f"),
    ("GitHub update manifest parser test", read("tests/test_update_manifest.c"), "untrusted executable URL is rejected"),
    ("YouTube media resolver", read("platform/xbox360/xsdk/web_engine.c"), "youtube_resolve_stream"),
    ("YouTube URL dispatch", read("platform/xbox360/xsdk/main.c"), "web_engine_is_youtube_url(normalized)"),
    ("YouTube port validation", read("platform/xbox360/xsdk/web_engine.c"), "youtube_strip_valid_port(host, 1)"),
    ("YouTube complete JSON array guard", read("platform/xbox360/xsdk/web_engine.c"), "array_end[-1] != ']'") ,
    ("YouTube MP4 signature validation", read("platform/xbox360/xsdk/web_engine.c"), "youtube_download_has_mp4_signature(destination)"),
    ("lazy image source discovery", read("platform/xbox360/xsdk/web_engine.c"), '"data-lazy-src"'),
    ("lazy srcset discovery regression", read("tests/test_web_engine_native.c"), "found_lazy_srcset"),
    ("YouTube malformed port regression", read("tests/test_youtube_compatibility.c"), "reject nonnumeric port"),
    ("YouTube truncated JSON regression", read("tests/test_youtube_compatibility.c"), "rejects truncated JSON/arrays"),
    ("DOM capacity", read("engine/xenonweb/xw_dom.h"), "XW_DOM_MAX_NODES 6144U"),
    ("script capacity", read("engine/xenonweb/xw_script.h"), "XW_SCRIPT_MAX_SOURCE 65536U"),
    ("script token budget", read("engine/xenonweb/xw_script.c"), "XW_JS_MAX_TOKENS 30000U"),
    ("texture fallback", renderer, "using linear fallback"),
    ("shader input contract", read("platform/xbox360/xsdk/page.vert"), "location = 2) in vec2 a_texcoord"),
    ("actionable layout diagnostic", renderer, "vertex layout rejected (expected POSITION0 + TEXCOORD0; check page.vert locations)"),
    ("runtime video config packaged", platform_cmake, "X360Browser-video-config.txt"),
    ("runtime empty bookmarks database", platform_cmake, "X360Browser-bookmarks.txt"),
    ("image cache invalidation", renderer, "file_mtime"),
    ("static render frame cache", renderer, "WebVisualFrame cached_frame"),
    ("no per-frame layout hash scan", renderer, "page_hash_for_scroll"),
    ("render cache invalidation API", renderer, "web_visual_renderer_invalidate(void)"),
    ("YouTube stream-url resolver API", read("platform/xbox360/xsdk/web_engine.c"), "web_engine_resolve_youtube_stream"),
    ("YouTube stream-url background task", main, "resolve_youtube"),
    ("search provider shortcuts", main, "google_prefix[]"),
    ("auto FFPlay discovery", main, "resolve_auto_media_player"),
    ("runtime view diagnostic test", read("tests/test_runtime_view_contract.py"), "successful HTML page selects graphical mode independent of renderer readiness"),
    ("text-reader fallback prohibition", main, "This surface deliberately never prints page->text."),
    ("resource diagnostic surface", main, "WEB RESOURCE"),
    ("automatic updater integration", main, "x360_update_check_and_install"),
    ("transactional updater rollback", read("platform/xbox360/xsdk/update_manager.c"), "rename(UPDATE_XEX_BACKUP, install_target)"),
    ("SHA-256 update validation", read("platform/xbox360/xsdk/update_manager.c"), "mbedtls_md_finish"),
    ("GitHub latest-release API", read("platform/xbox360/xsdk/update_manager.c"), "api.github.com/repos/David-Bryan010-png/X360Browser/releases/latest"),
    ("CSS background-image parser", css, "PROP_BACKGROUND_IMAGE"),
    ("CSS background visual layer", read("engine/xenonweb/xw_layout.c"), "CSS background image"),
    ("full-width viewport", read("platform/xbox360/xsdk/visual_layout.h"), "WEB_VISUAL_WIDTH 1280"),
    ("virtual cursor hit testing", read("platform/xbox360/xsdk/visual_renderer.c"), "web_visual_renderer_hit_test"),
]
for rel, content, marker in markers:
    if marker not in content:
        raise SystemExit(f"FAIL: missing expected implementation marker in {rel}: {marker}")


source_transport_test = read("tests/test_web_engine_native.c")
if re.search(r'\(\s*void\s*\)\s*fread\s*\(', source_transport_test):
    raise SystemExit("FAIL: native test source must validate fread return values")

# 164 unique items are the engineering inventory, not a claim of 164 completed features.
gap_ids = set(re.findall(r"\bGAP-(\d{3})\b", audit))
if len(gap_ids) != 164:
    raise SystemExit(f"FAIL: gap audit should contain exactly 164 unique IDs; found {len(gap_ids)}")
if "Total inventariado: 164 itens" not in audit:
    raise SystemExit("FAIL: gap audit total should be updated alongside its items")
if len(re.findall(r"\bGAP-\d{3}\b", priority_gaps_pt)) < 50:
    raise SystemExit("FAIL: Portuguese priority-gap list must include at least 50 IDs")
for gap_marker in ("GAP-032", "GAP-043", "GAP-109", "GAP-127"):
    if gap_marker not in audit:
        raise SystemExit(f"FAIL: audit must reflect new media/CSS status for {gap_marker}")

# Browser/page/media engines must be first-party by default; TLS and platform support are declared separately.
if "netsurf_backend_stub.c" in platform_cmake or (ROOT / "platform/xbox360/xsdk/netsurf_backend_stub.c").exists():
    raise SystemExit("FAIL: nonfunctional NetSurf adapter must not be in active source/build")
if "netsurf_backend_" in dispatch or "WEB_ENGINE_BACKEND_NETSURF" in read("platform/xbox360/xsdk/web_engine.h"):
    raise SystemExit("FAIL: active dispatcher/header must not advertise a fake third-party browser engine")
if re.search(r'#define\s+VIDEO_PLAYER_PATH\s+"auto"', main) is None:
    raise SystemExit("FAIL: external media player must be disabled by default")
if "if (!external_media_player_enabled())" not in main:
    raise SystemExit("FAIL: external-player launch paths must guard disabled state")
if "stb_image" in platform_cmake or "X360BROWSER_WITH_STB_IMAGE" in platform_cmake:
    raise SystemExit("FAIL: third-party raster decoder integration must be removed")
if "stb_image" in renderer or "stbi_" in renderer or "stb_image" in build_script:
    raise SystemExit("FAIL: third-party raster decoder must not be called or fetched")
meaningful_config = [line.strip() for line in config.splitlines() if line.strip() and not line.lstrip().startswith(("#", ";"))]
if not meaningful_config or meaningful_config[0].lower() != "auto":
    raise SystemExit("FAIL: example media config must attempt safe FFPlay auto-detection")
for marker in ("libcurl", "Mbed TLS", "xSDK"):
    if marker.lower() not in third_party.lower():
        raise SystemExit(f"FAIL: third-party boundary must disclose {marker}")
for marker in ("não é chromium", "não transforma xenonscript em ecmascript completo", "não implementados", "youtube"):
    if marker.lower() not in compat.lower():
        raise SystemExit(f"FAIL: compatibility doc must explain limitation: {marker}")
for marker in ("WebVTT", "IMA ADPCM", "H.264", "subtitle overlay", "not yet an integrated"):
    if marker.lower() not in media_doc.lower():
        raise SystemExit(f"FAIL: media documentation missing boundary marker: {marker}")

print(
    f"PASS: package integrity; {len(REQUIRED)} required files; version={version}; "
    f"{len(gap_ids)} unique historical gap IDs; DOM/CSS renderer integration, large HTML capacity, CSS vars, WAV IMA ADPCM, WebVTT and first-party dispatch verified; "
    "external player auto-detection; XEX build runs automatically after validation"
)
