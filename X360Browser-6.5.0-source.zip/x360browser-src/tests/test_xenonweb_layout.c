#include "../platform/xbox360/xsdk/visual_layout.h"
#include <stdio.h>
#include <string.h>

static int failures;
static void check(int condition, const char *name)
{
    if (condition) printf("PASS: %s\n", name);
    else { printf("FAIL: %s\n", name); ++failures; }
}

int main(void)
{
    static const char html[] =
        "<!doctype html><html><head><title>hidden title</title>"
        "<style>body{background:#f0f0f0;color:#222} .card{background:#abc;padding:8px}"
        "#special{color:red;font-size:24px} .hide{display:none} main .card a{font-weight:bold}"
        ".background-probe{background-image:url(\'/wallpaper.png\');background-color:#123456;padding:6px}"
        "#transform-probe{text-transform:uppercase;text-decoration:underline line-through;line-height:28px}"
        ".generated{color:green}.flex-probe{display:flex;flex-wrap:wrap;gap:20px}.flex-probe .flex-item{background:#eee;padding:4px;width:320px}"
        ".grid-probe{display:grid;grid-template-columns:repeat(2, 1fr);gap:16px}.grid-probe .grid-item{background:#ddd;padding:4px}"
        ".width-probe{width:100%;max-width:180px;background:#fed}"
        ".padding-probe{padding:4px 8px 12px 16px;background:#fdb}"
        ".center-probe{width:300px;max-width:300px;margin:0 auto;background:#bdf}</style>"
        "<script>document.getElementById('runtime').textContent = 'XenonScript is active';"
        " var injected = document.createElement('p'); injected.id='generated-node';"
        " injected.classList.add('generated','active'); injected.textContent='Generated DOM node';"
        " document.body.appendChild(injected);</script></head>"
        "<body><main><div class='card'><h1 id='special'>XenonWeb Engine</h1>"
        "<p id='runtime'>static fallback text</p>"
        "<p id='transform-probe'>make this loud</p>"
        "<p>DOM and CSS are active.</p><a href='/play'>Open game page</a>"
        "<a href='#run' onclick=\"document.getElementById('runtime').textContent = 'Clicked by script';\">Run action</a>"
        "<button id='button-probe' onclick=\"document.getElementById('runtime').textContent = 'Button worked';\">Press me</button>"
        "<input id='field-probe' type='text' value='old value' placeholder='enter text'>"
        "<p class='hide'>THIS SHOULD NOT RENDER</p><img src='/hero.png' alt='Hero artwork' width='180' height='60'>"
        "<div class='flex-probe'><div class='flex-item'>FLEX-LEFT</div><div class='flex-item'>FLEX-RIGHT</div><div class='flex-item'>FLEX-THIRD</div><div class='flex-item'>FLEX-FOURTH</div></div>"
        "<div class='grid-probe'><div class='grid-item'>GRID-ONE</div><div class='grid-item'>GRID-TWO</div><div class='grid-item'>GRID-THREE</div></div>"
        "<div class='width-probe'>WIDTH-CONSTRAINED</div>"
        "<div class='padding-probe'>PADDING-SIDES</div>"
        "<div class='center-probe'>CENTERED-BLOCK</div>"
        "<div class='background-probe'>BACKGROUND-IMAGE-BOX</div>"
        "</div></main></body></html>";
    WebEnginePage page;
    WebVisualFrame frame;
    size_t i;
    int found_title = 0, found_hidden = 0, found_anchor = 0, found_image = 0, found_styled_box = 0;
    int found_script_text = 0;
    int found_stretched_background = 0;
    int found_transform = 0, found_generated = 0, found_width_limited = 0, found_padding_sides = 0, found_centered = 0;
    int flex_left_x = -1, flex_right_x = -1, flex_left_y = -1, flex_right_y = -1;
    int flex_third_y = -1, flex_fourth_y = -1;
    int grid_one_x = -1, grid_two_x = -1, grid_one_y = -1, grid_two_y = -1, grid_three_y = -1;
    memset(&page, 0, sizeof(page));
    (void)snprintf(page.page_url, sizeof(page.page_url), "%s", "https://example.com/index.html");
    memcpy(page.source_html, html, sizeof(html));
    page.source_html_length = sizeof(html) - 1U;
    page.link_count = 2U;
    page.image_count = 1U;
    (void)snprintf(page.images[0].url, sizeof(page.images[0].url), "%s", "https://example.com/wallpaper.png");
    (void)snprintf(page.images[0].alt, sizeof(page.images[0].alt), "%s", "CSS background image");
    (void)snprintf(page.images[0].cache_path, sizeof(page.images[0].cache_path), "%s", "test-background.img");
    (void)snprintf(page.links[0].url, sizeof(page.links[0].url), "%s", "https://example.com/play");
    (void)snprintf(page.links[0].label, sizeof(page.links[0].label), "%s", "Open game page");
    (void)snprintf(page.links[1].url, sizeof(page.links[1].url), "%s", "https://example.com/index.html#run");
    (void)snprintf(page.links[1].label, sizeof(page.links[1].label), "%s", "Run action");

    web_visual_layout(&page, 0U, &frame);
    check(frame.text_count > 0U, "new XenonWeb path emits visible text runs");
    check(frame.background == 0xFFF0F0F0U, "body background CSS is applied to page surface");
    for (i = 0U; i < frame.image_count; ++i) {
        if (frame.images[i].stretch && frame.images[i].height > 1 &&
            strstr(frame.images[i].cache_path, "test-background.img") != NULL)
            found_stretched_background = 1;
    }
    check(found_stretched_background, "CSS background-image is emitted as a stretched graphical layer");
    for (i = 0U; i < frame.text_count; ++i) {
        if (strstr(frame.texts[i].text, "XenonScript is active") != NULL) found_script_text = 1;
        if (strstr(frame.texts[i].text, "Generated DOM node") != NULL) found_generated = 1;
        if (strstr(frame.texts[i].text, "PADDING-SIDES") != NULL) {
            size_t r;
            for (r = 0U; r < frame.rect_count; ++r) {
                if (frame.rects[r].color == 0xFFFFDDBBU && frame.texts[i].x == frame.rects[r].x + 16 &&
                    frame.texts[i].y == frame.rects[r].y + 4) found_padding_sides = 1;
            }
        }
        if (strstr(frame.texts[i].text, "FLEX-LEFT") != NULL) { flex_left_x = frame.texts[i].x; flex_left_y = frame.texts[i].y; }
        if (strstr(frame.texts[i].text, "FLEX-RIGHT") != NULL) { flex_right_x = frame.texts[i].x; flex_right_y = frame.texts[i].y; }
        if (strstr(frame.texts[i].text, "FLEX-THIRD") != NULL) flex_third_y = frame.texts[i].y;
        if (strstr(frame.texts[i].text, "FLEX-FOURTH") != NULL) flex_fourth_y = frame.texts[i].y;
        if (strstr(frame.texts[i].text, "GRID-ONE") != NULL) { grid_one_x = frame.texts[i].x; grid_one_y = frame.texts[i].y; }
        if (strstr(frame.texts[i].text, "GRID-TWO") != NULL) { grid_two_x = frame.texts[i].x; grid_two_y = frame.texts[i].y; }
        if (strstr(frame.texts[i].text, "GRID-THREE") != NULL) grid_three_y = frame.texts[i].y;
        if (strstr(frame.texts[i].text, "XenonWeb Engine") != NULL) {
            found_title = 1;
            check(frame.texts[i].color == 0xFFFF0000U && frame.texts[i].scale >= 2U,
                  "ID CSS selector affects visible heading style");
        }
        if (strstr(frame.texts[i].text, "MAKE THIS LOUD") != NULL) {
            found_transform = 1;
            check(frame.texts[i].decoration == (WEB_VISUAL_DECORATION_UNDERLINE | WEB_VISUAL_DECORATION_LINE_THROUGH),
                  "text-decoration flags reach the renderer frame");
        }
        if (strstr(frame.texts[i].text, "THIS SHOULD NOT RENDER") != NULL) found_hidden = 1;
        if (strstr(frame.texts[i].text, "[Image: Hero artwork]") != NULL) found_image = 1;
    }
    for (i = 0U; i < frame.link_count; ++i)
        if (frame.links[i].page_link_index == 0U && frame.links[i].width > 0) found_anchor = 1;
    for (i = 0U; i < frame.rect_count; ++i) {
        if (frame.rects[i].color == 0xFFAABBCCU) found_styled_box = 1;
        if (frame.rects[i].color == 0xFFFFEEDD && frame.rects[i].width == 180) found_width_limited = 1;
        if (frame.rects[i].color == 0xFFBBDDFF && frame.rects[i].width == 300 && frame.rects[i].x > 100)
            found_centered = 1;
    }
    check(found_title, "styled heading is present");
    check(found_script_text, "first-party script runtime mutates the DOM before visual rendering");
    check(found_generated, "dynamically created DOM nodes and classList styles reach the visual renderer");
    check(found_transform, "text-transform uppercase changes rendered text content");
    check(!found_hidden, "display:none subtree is not rendered");
    check(found_anchor, "relative anchor maps to browser's canonical link index");
    check(found_image, "image element creates an accessible placeholder");
    check(found_styled_box, "CSS background is represented by GPU rectangle");
    check(found_width_limited, "percentage width and max-width constrain a real rendered block");
    check(found_padding_sides, "individual padding sides affect actual content coordinates");
    check(found_centered, "margin:0 auto centers a constrained-width block in its containing box");
    check(flex_left_x >= 0 && flex_right_x > flex_left_x + 150 && flex_left_y == flex_right_y,
          "display:flex lays out bounded child boxes side-by-side with the same row baseline");
    check(flex_third_y == flex_left_y && flex_fourth_y > flex_third_y,
          "flex-wrap moves overflowing flex items to a subsequent row instead of collapsing them");
    check(grid_one_x >= 0 && grid_two_x > grid_one_x + 150 && grid_one_y == grid_two_y && grid_three_y > grid_one_y,
          "CSS Grid lays out two equal columns and wraps the third cell into a new row");
    {
        int navigation_consumed = 0;
        WebVisualFrame changed;
        int dispatched = web_visual_dispatch_link(&page, 1U, &navigation_consumed);
        web_visual_layout(&page, 0U, &changed);
        check(dispatched && navigation_consumed,
              "focused fragment anchor dispatches its inline onclick handler without navigation");
        found_script_text = 0;
        for (i = 0U; i < changed.text_count; ++i)
            if (strstr(changed.texts[i].text, "Clicked by script") != NULL) found_script_text = 1;
        check(found_script_text, "event-handler DOM mutations invalidate and rebuild the visual frame");
        {
            uint16_t button_node = UINT16_MAX;
            int dispatched_button = 0;
            for (i = 0U; i < changed.control_count; ++i) {
                if (changed.controls[i].kind == 2U) {
                    button_node = changed.controls[i].dom_node_index;
                    break;
                }
            }
            if (button_node != UINT16_MAX) dispatched_button = web_visual_dispatch_control(&page, button_node);
            web_visual_layout(&page, 0U, &changed);
            found_script_text = 0;
            for (i = 0U; i < changed.text_count; ++i)
                if (strstr(changed.texts[i].text, "Button worked") != NULL) found_script_text = 1;
            check(button_node != UINT16_MAX, "button control has a bounded hit-test rectangle");
            check(dispatched_button && found_script_text,
                  "button click dispatches its bounded XenonScript onclick handler");
            {
                char field_value[64] = { 0 };
                uint16_t input_node = UINT16_MAX;
                size_t c;
                for (c = 0U; c < changed.control_count; ++c) {
                    if (changed.controls[c].kind == 1U) {
                        input_node = changed.controls[c].dom_node_index;
                        break;
                    }
                }
                check(input_node != UINT16_MAX, "input field has a bounded hit-test rectangle");
                check(input_node != UINT16_MAX && web_visual_get_control_value(&page, input_node,
                      field_value, sizeof(field_value)) && strcmp(field_value, "old value") == 0,
                      "input field exposes its current value to the virtual keyboard");
                check(input_node != UINT16_MAX && web_visual_set_control_value(&page, input_node, "updated") &&
                      web_visual_get_control_value(&page, input_node, field_value, sizeof(field_value)) &&
                      strcmp(field_value, "updated") == 0,
                      "input keyboard changes DOM value and invalidates the visual frame");
            }
        }
    }
    {
        WebVisualFrame scrolled;
        size_t original_height = frame.content_height;
        web_visual_layout(&page, 35U, &scrolled);
        check(scrolled.content_height == original_height, "scrolling preserves document content height");
        check(scrolled.text_count > 0U && scrolled.texts[0].y == frame.texts[0].y - 35,
              "viewport scroll is applied exactly once to generated text");
    }
    {
        static const char iframe_html[] =
            "<!doctype html><html><body><h1>Embed fallback</h1>"
            "<iframe title=\"video\" src=\"https://www.youtube.com/embed/example-id\"></iframe>"
            "</body></html>";
        int found_embed_card = 0;
        int found_embed_link = 0;
        memset(&page, 0, sizeof(page));
        (void)snprintf(page.page_url, sizeof(page.page_url), "%s", "https://example.com/embedded.html");
        memcpy(page.source_html, iframe_html, sizeof(iframe_html));
        page.source_html_length = sizeof(iframe_html) - 1U;
        page.link_count = 1U;
        (void)snprintf(page.links[0].url, sizeof(page.links[0].url), "%s",
                       "https://www.youtube.com/embed/example-id");
        (void)snprintf(page.links[0].label, sizeof(page.links[0].label), "%s", "Embedded content");
        web_visual_layout(&page, 0U, &frame);
        for (i = 0U; i < frame.text_count; ++i)
            if (strstr(frame.texts[i].text, "YouTube embed is not inline yet") != NULL &&
                frame.texts[i].page_link_index == 0U) found_embed_card = 1;
        for (i = 0U; i < frame.link_count; ++i)
            if (frame.links[i].page_link_index == 0U && frame.links[i].width > 0) found_embed_link = 1;
        check(found_embed_card && found_embed_link,
              "unsupported embedded YouTube player becomes a controller-focusable URL instead of a dead placeholder");
    }
    {
        static const char media_html[] =
            "<!doctype html><html><body><h1>Media test</h1>"
            "<video controls><source src=\"/clip.mp4\" type=\"video/mp4\"></video>"
            "<audio controls src=\"/track.mp3\" type=\"audio/mpeg\"></audio>"
            "</body></html>";
        int found_video_card = 0;
        int found_audio_card = 0;
        int video_link_rect = 0;
        int audio_link_rect = 0;
        memset(&page, 0, sizeof(page));
        (void)snprintf(page.page_url, sizeof(page.page_url), "%s", "https://example.com/media.html");
        memcpy(page.source_html, media_html, sizeof(media_html));
        page.source_html_length = sizeof(media_html) - 1U;
        page.link_count = 2U;
    page.image_count = 1U;
    (void)snprintf(page.images[0].url, sizeof(page.images[0].url), "%s", "https://example.com/wallpaper.png");
    (void)snprintf(page.images[0].alt, sizeof(page.images[0].alt), "%s", "CSS background image");
    (void)snprintf(page.images[0].cache_path, sizeof(page.images[0].cache_path), "%s", "test-background.img");
        (void)snprintf(page.links[0].url, sizeof(page.links[0].url), "%s", "https://example.com/clip.mp4");
        (void)snprintf(page.links[0].label, sizeof(page.links[0].label), "%s", "HTML video source");
        page.links[0].is_video = 1;
        (void)snprintf(page.links[1].url, sizeof(page.links[1].url), "%s", "https://example.com/track.mp3");
        (void)snprintf(page.links[1].label, sizeof(page.links[1].label), "%s", "HTML audio source");
        page.links[1].is_audio = 1;
        web_visual_layout(&page, 0U, &frame);
        for (i = 0U; i < frame.text_count; ++i) {
            if (strstr(frame.texts[i].text, "[ PLAY VIDEO ]") != NULL && frame.texts[i].page_link_index == 0U)
                found_video_card = 1;
            if (strstr(frame.texts[i].text, "[ PLAY AUDIO ]") != NULL && frame.texts[i].page_link_index == 1U)
                found_audio_card = 1;
        }
        for (i = 0U; i < frame.link_count; ++i) {
            if (frame.links[i].page_link_index == 0U) video_link_rect = 1;
            if (frame.links[i].page_link_index == 1U) audio_link_rect = 1;
        }
        check(found_video_card && video_link_rect,
              "video element renders a focusable play card linked to its source");
        check(found_audio_card && audio_link_rect,
              "audio element renders a focusable play card linked to its source");
    }
    if (failures) { printf("%d XenonWeb layout test(s) failed\n", failures); return 1; }
    printf("All XenonWeb layout tests passed\n");
    return 0;
}
