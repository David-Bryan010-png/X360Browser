#!/usr/bin/env python3
"""Cross-layer contract: default.xex is the one canonical Xbox launch artifact."""
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
version = (ROOT / "VERSION").read_text(encoding="utf-8").strip()
workflow = (ROOT / ".github/workflows/build-xex-from-zip.yml").read_text(encoding="utf-8")
build = (ROOT / "tools/build_xbox_shell.sh").read_text(encoding="utf-8")
main = (ROOT / "platform/xbox360/xsdk/main.c").read_text(encoding="utf-8")
manager = (ROOT / "platform/xbox360/xsdk/update_manager.c").read_text(encoding="utf-8")
manifest = (ROOT / "platform/xbox360/xsdk/update_manifest.c").read_text(encoding="utf-8")
readme = (ROOT / "platform/xbox360/xsdk/README.txt").read_text(encoding="utf-8")
checks = {
    "semantic version is 6.2.0": version == "6.2.0",
    "PowerPC build stages default.xex": 'XEX="$ROOT_DIR/build-xbox360/default.xex"' in build and 'cp "$BUILT_XEX" "$XEX"' in build,
    "build rejects undersized or updater-incompatible oversize XEX": 'XEX_BYTES < 1024 || XEX_BYTES > 67108864' in build,
    "runtime launch/calling-app path is default.xex": r'#define BROWSER_XEX_PATH "game:\\default.xex"' in main,
    "updater has no alternate X360Browser.xex destination": r'UPDATE_XEX_DEFAULT "game:\\default.xex"' in manager and "UPDATE_XEX_CURRENT" not in manager,
    "updater stages and backs up with default base name": 'default.update.xex' in manager and 'default.previous.xex' in manager,
    "manifest consumes only default.xex asset names": 'strcmp(name, "default.xex") == 0' in manifest and 'strcmp(name, "default.xex.sha256") == 0' in manifest and 'strcmp(name, "X360Browser.xex") == 0' not in manifest,
    "workflow builds and packages default.xex": 'test -s build-xbox360/default.xex' in workflow and 'for file in default.xex cacert.pem' in workflow,
    "GitHub release exposes exact default.xex asset": 'x360browser-xex-dist/default.xex' in workflow and 'x360browser-xex-dist/default.xex.sha256' in workflow,
    "installer README documents canonical name": "default.xex" in readme and "X360Browser.xex" not in readme,
}
for label, ok in checks.items():
    print(("PASS" if ok else "FAIL") + ": " + label)
failed = [label for label, ok in checks.items() if not ok]
if failed:
    raise SystemExit(f"FAIL: {len(failed)} default.xex contracts failed")
print(f"PASS: all {len(checks)} default.xex contracts")
