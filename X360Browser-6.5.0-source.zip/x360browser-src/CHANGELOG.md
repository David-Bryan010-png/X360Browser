# Changelog

## [6.5.0] — 2026-10-28

- **Compatibilidade com sites:** o navegador se identifica como um navegador de desktop, para os sites enviarem a página normal em vez de uma versão vazia ou de bot.
- **Idioma:** envia `Accept-Language: pt-BR` para receber páginas em português quando o site suportar.
- **`<base href>`:** links e imagens relativos passam a respeitar a tag base da página.
- **XenonScript:** `window`, `location`, `document.cookie`, `document.readyState`, `getElementsByTagName` e leitura de `innerHTML` para scripts simples não quebrarem a página.
- **CSS:** `float` deixa de ser ignorado de forma que quebre o fluxo; o elemento continua visível como bloco.
- Isso aumenta a compatibilidade com páginas reais. Não torna o Xbox 360 capaz de rodar Chrome ou sites modernos complexos.

## [6.4.0] — 2026-10-28

- **XenonWeb / DOM:** tabela de entidades HTML ampliada (acentos portugueses e latinos, aspas tipográficas, símbolos comuns).
- **XenonWeb / CSS:** mais nomes de cor (`silver`, `maroon`, `olive`, `lime`, `aqua`, `fuchsia`, `transparent`) e `visibility: hidden` / `collapse` escondem o elemento.
- **XenonWeb / layout:** checkbox e radio desenhados como caixas reais; `small`/`big`/`sub`/`sup` ajustam o tamanho do texto.
- **XenonScript:** `while` limitado, `Math.abs/min/max/floor/ceil/round`, `parseInt`, `parseFloat`, `Number`, `isNaN` e `String`.
- **XenonMedia:** `.webp`, `.avif`, `.svg` e `.ico` são reconhecidos e marcados como não decodificáveis nativamente, em vez de serem tratados como desconhecidos genéricos.
- Continua sendo um subconjunto próprio. Não é Chromium, WebKit nem Internet Explorer completo.

## [6.3.0] — 2026-10-28

- **Estilo padrão de navegador (estilo Internet Explorer):** fundo branco, texto preto, títulos com tamanhos e margens, links azuis sublinhados, parágrafos, blockquote, pre/code, listas e tabelas com estilo próprio.
- **Atributos HTML clássicos:** `bgcolor`, `color`, `align`, `width`, `border` e `<font size/color>` passam a afetar a aparência, como nas páginas da época do Internet Explorer.
- **Listas:** marcadores de lista e numeração em `<ol>`.
- **Tabelas:** linhas usam layout flex; células `td`/`th` ganham borda, preenchimento e fundo. Não é um motor de tabelas completo, mas fica legível.
- **Imagens:** o rótulo `[Image: ...]` some quando a imagem real é carregada.
- **Controles:** melhorias da 6.2.1 mantidas (campos gráficos, `hidden` omitido).

## [6.2.1] — 2026-10-28

- **Controles de formulário gráficos:** inputs, textareas, selects e botões deixam de ser desenhados como rótulos entre colchetes (`[ text: ]`, `[ hidden: ... ]`). Campos `hidden` são omitidos. Inputs usam caixa branca com borda; botões/submit usam fundo azul e texto branco; placeholders aparecem em cinza. O texto é recortado para caber na caixa.
- **Fallback VisualLite:** inputs `hidden` também são omitidos no caminho legado.

## [6.2.0] — 2026-10-28

- **Executável canônico:** o arquivo distribuído e publicado agora é `default.xex`, como exigido pelo launcher usado na instalação alvo. O nome interno do target CMake pode continuar `X360Browser`; o script de build renomeia/copia o artefato final e valida seu tamanho.
- **GitHub Releases:** depois de validar fonte, executar regressões e compilar o XEX, o workflow publica `default.xex`, `default.xex.sha256`, o ZIP de instalação e o checksum do ZIP.
- **Auto-update alinhado:** o cliente procura apenas `default.xex` na Release oficial e usa nomes de estágio/backup coerentes (`default.update.xex`, `default.previous.xex`).
- **XenonNet:** resolução de referências relativas melhorada para `./`, `../`, `?query`, caminhos root-relative e URLs protocol-relative. Caminhos HTTP são normalizados sem atravessar a raiz e escapes percentuais não são decodificados como segmentos.
- **Validação de versão:** parsing estrito de MAJOR.MINOR.PATCH, sem zeros à esquerda, sufixos ou overflow.
- **Regressões:** testes cobrem resolução de URLs e contrato de nome `default.xex` em script de build, aplicação, parser do manifest e workflow.
- **Limites:** motores permanecem próprios e parciais; a compilação final e a operação real precisam ser verificadas no Xbox 360.

## [6.1.0] — 2026-10-28 (contrato de arquivo substituído na 6.2.0)

- **Publicação automática (contrato antigo):** após validação e build XEX bem-sucedidos na branch principal configurada, o GitHub Actions publicava uma release estável contendo `X360Browser.xex`, checksum SHA-256, pacote de instalação e seu checksum.
- **Atualizador para a instalação real:** tenta `game:\\default.xex` primeiro e `game:\\X360Browser.xex` como alternativa, compatível com o nome de arquivo do log do console.
- **Segurança de versão:** impede que binários diferentes sejam republicados com a mesma versão; novas atualizações exigem bump semântico.
- **Workflow atualizado:** `actions/checkout@v7.0.1`, `actions/cache@v6.0.0`, `actions/upload-artifact@v7.0.2`, `actions/download-artifact@v8.0.2` e `softprops/action-gh-release@v3.0.3` (versões fixadas), permissão `contents: write`, e publicação após a compilação — sem gatilho de tags que provoque uma segunda compilação.
- **Honestidade de atualização:** se o sistema de arquivos bloquear o XEX em uso, o cliente mantém a atualização verificada em estágio e indica que a instalação exige sair/substituir o arquivo.

 X360Browser

## 6.0.0 — interface gráfica como caminho obrigatório — 2026-10-28

- Remove o modo de navegação `NATIVEPLUS TEXT READER VIEW`; o conteúdo da página não é mais desenhado a partir do texto extraído como fallback.
- O comando X agora percorre página gráfica, links e recursos; nunca ativa a vista textual.
- Respostas HTML usam a superfície gráfica por padrão mesmo quando a inicialização do renderer falha, exibindo um diagnóstico explícito em vez de uma página textual.
- URLs de recursos binários exibem um cartão de recurso com MIME/controles, em vez de despejar dados de texto.
- Falhas de navegação exibem uma tela de erro que mantém a barra de endereço e os atalhos funcionais.
- Invalida o estado visual novamente ao confirmar uma resposta HTTP, além da invalidação ao iniciar navegação, reduzindo o risco de quadro obsoleto entre páginas.
- Mantém o formato de código-fonte, CMake/xSDK e workflow GitHub Actions; adiciona contratos de regressão para proibir retorno do leitor textual.
- Não promete Chromium/WebKit, suporte completo a JavaScript moderno, jogos web atuais ou reprodução HTML5 universal. O XEX final continua exigindo compilação no workflow e teste em console real.

## 5.2.0 — 2026-10-28

- Expanded the page renderer to a 1280×544 full-width visual viewport for 720p output.
- Added CSS `background-image` extraction and raster-image lookup for HTML and external CSS resources.
- CSS background images stretch to their element box while normal images keep aspect-ratio contain behavior.
- Preserved border outlines after raster image composition and prioritized content images before CSS decoration.
- Replaced the configurable Vercel update endpoint with a direct GitHub Releases API client.
- Added release asset allowlisting, GitHub digest/checksum fallback, strict HTTPS/TLS checks, 64 MiB download limit, SHA-256 verification and rollback attempt.
- Removed runtime dependency on `X360Browser-update-config.txt`.
- Added host tests for the GitHub update-manifest parser and visual CSS background layers.
- Console operation, automatic in-place replacement and modern website compatibility still require hardware validation; this is not Chromium/WebKit.

## 5.1.0 — cursor, viewport expandido e atualização remota verificada
- Aumenta a altura da área de renderização web para 500 px e move o conteúdo para mais perto da barra superior.
- Reorganiza a interface para uma barra de endereço/título mais compacta e neutraliza o fundo externo azul.
- Adiciona cursor controlado pelo D-pad na vista visual, ativável/desativável com RS, com hit-testing de links e controles HTML visíveis. A tecla A abre o link sob cursor, executa handlers `onclick` suportados ou abre a entrada de endereço.
- Adiciona cliente de atualização HTTPS: lê endpoint de configuração, exige versão semântica, limita manifesto e XEX, valida SHA-256 via Mbed TLS e tenta troca com rollback. Se a troca falhar, preserva o XEX validado e informa o procedimento.
- Adiciona endpoint Vercel para consultar a última GitHub Release e manifesto JSON; workflow publica `.xex` e checksum junto ao ZIP nas tags de release.
- Adiciona edição de `input`/`textarea` via teclado virtual do Xbox e regressões para hit-test, valores DOM e dispatch de `onclick` em botão; atualiza documentação e workflow.
- Limites: ainda depende de validação no Xbox para confirmar renomeação do executável ativo; JavaScript e mídia continuam parciais, e YouTube não é garantido.


## 5.0.0 — XenonWeb Next / performance, controls and media handoff
- Cachear a estrutura WebVisualFrame fora da pilha de draw e evitar recalcular hashes do HTML em todo quadro; reconstruir apenas após navegação, ação DOM ou rolagem.
- Evitar a chamada duplicada à rota de layout quando a pipeline DOM/CSS falha; fallback direto para o renderizador legado.
- Adicionar invalidação explícita do cache visual na navegação e em dispatches DOM.
- Corrigir o caminho de `stream-url` do YouTube: resolução MP4 ocorre em worker de rede antes do handoff, em vez de entregar a URL watch ao player.
- Auto-detectar FFPlay.xex em locais comuns, permitir caminho explicitamente configurado e mostrar diagnóstico de configuração ausente/desativada.
- Acrescentar busca multi-provedor com `!g`, `!b` e `!d`; DuckDuckGo continua sendo o padrão.
- Ampliar XenonScript com propriedades e métodos comuns de string (`length`, `trim`, maiúsculas/minúsculas, busca, prefixo/sufixo e recorte), com testes de regressão.
- Reduzir consultas de arquivos de imagem ao preparar os índices de placeholders uma vez por layout, em vez de procurar novamente cada imagem para cada linha de texto em todo quadro.
- Atualizar identidade da aplicação, fluxo de build e documentação de compatibilidade.
- Limites mantidos explicitamente: runtime JavaScript parcial, sem pipeline HTML5 moderno de vídeo, WebGL/WASM ou compatibilidade universal com jogos atuais.

# Changelog — X360Browser

## 5.3.0 — diagnóstico gráfico e início mais limpo — 2026-10-28

- Registra o estado real da vista escolhida após cada carregamento: HTTP, MIME, bytes, recurso direto, renderizador, modo, links, imagens, mídia e formulários.
- Registra a primeira chamada do renderizador gráfico por URL, para identificar quando o XEX apenas inicializou o motor e quando realmente entrou no caminho de desenho.
- Registra erros de carregamento de URL com a causa reportada pela rede.
- Adia a busca por FFPlay.xex até o usuário pedir reprodução; faltas do player opcional deixam de poluir o log durante a navegação normal.
- Mantém a mesma estrutura CMake/xSDK e workflow do GitHub Actions.
- Não declara teste em hardware nem compatibilidade universal com sites modernos.

## 4.3.0 — confiabilidade do build e correções de interface

- Corrige a causa da falha `Extract validated source`: o ZIP era extraído de um caminho fixo que não correspondia à estrutura do artefato quando o log alterava o diretório comum do upload.
- Separa o artefato de fonte (ZIP + SHA-256) do artefato de log de validação.
- Pesquisa o ZIP recursivamente, exige exatamente um resultado, verifica o SHA-256, valida caminhos do ZIP e verifica `VERSION` antes de iniciar o compilador.
- Cria log da etapa de extração antes da primeira validação para preservar diagnóstico se a etapa falhar.
- Adiciona teste de regressão de estrutura do artefato e corrige o título de UI que ainda informava versão 3.3.
- Inicializa explicitamente o buffer de entrada do teclado de endereços e calcula seu comprimento uma vez, removendo um alerta de leitura potencial de bytes não inicializados.
- Deixa de reter ponteiros temporários de `stats`/código-fonte no interpretador global após retornar, preservando a identidade do documento e as variáveis entre eventos da mesma página; adiciona fallback defensivo para valores CSS nulos.
- Mantém a correção do shader 4.2.0; não declara que um XEX foi produzido até a execução real do workflow.



## 4.3.0 — correção crítica do renderizador Xbox

- Corrige a localização de entrada do shader de textura: em xSDK, GLSL `location=1` corresponde a `COLOR`, e `location=2` a `TEXCOORD0`. A localização errada causava a mensagem `vertex layout lacks an input the shader fetches` e desligava o renderizador visual.
- Adiciona teste de regressão para o contrato GLSL ↔ `XsdkVertexElement`, incluindo formato, índice de uso, offsets e stride.
- Separa mensagens de falha para carregamento de shader, layout de vértices e alocação de textura.
- Cria arquivos padrão de configuração de mídia e favoritos no diretório de build, reduzindo falhas de abertura esperadas na primeira execução; o player externo continua desativado.
- Remove a exclusão redundante de um arquivo de cache antes de abri-lo em modo de escrita e substitui a cópia `snprintf` por cópia limitada explícita.
- Atualiza o User-Agent e a documentação para 4.3.0.
- Não declara compatibilidade total com Chromium, WebGL, WebAssembly ou vídeo HTML5 nativo.

## 4.1.0 — URL hardening e manutenção do motor

- Corrige a validação de portas para rejeitar valores enormes antes de ocorrer overflow inteiro.
- Rejeita sequências percent-encoded incompletas ou com dígitos não hexadecimais em URLs HTTP/HTTPS.
- Adiciona testes de regressão para portas excessivas e escapes `%` inválidos, preservando escapes válidos.
- Mantém as melhorias de renderização, scripts, imagens e resolução experimental de mídia da 4.0.0.
- Não declara suporte novo a codecs de vídeo, JavaScript moderno, WebGL ou WebAssembly sem implementação e testes próprios.

## 4.0.0 — engine refresh

- Maior capacidade delimitada no DOM, CSS, layout e execução XenonScript.
- Negociação de compressão HTTP para documento, estilos e scripts quando disponível na build do libcurl.
- Suporte ampliado a scripts externos pequenos, com limites máximos, verificação de tipo MIME, TLS validado e timeouts mantidos.
- Fallback de textura tiled para linear e invalidação da cache raster quando o arquivo muda.
- Resolução experimental de links de vídeo do YouTube via Invidious para MP4 muxado até 480p, com restrição a host Google Video, TLS e limite de download. Exige player externo configurado e uma instância pública funcional.
- Atualização de metadados, título da aplicação e User-Agent para 4.0.0.
- Documentação explícita das lacunas de compatibilidade.

- Strict YouTube URL authority parsing now rejects empty, non-numeric, overflowing and malformed ports; watch links with fragments retain correct video-ID parsing.
- Resolved media URLs now accept only HTTPS Google Video hosts on the default TLS port, and downloaded YouTube payloads must pass an MP4 `ftyp` signature/box-length check before external-player handoff.
- The stream JSON parser now rejects truncated/incomplete top-level objects and unclosed format arrays instead of accepting a partially parsed result.
- Image URL discovery now recognizes additional lazy-loading attributes (`data-lazy-src`, `data-original-src`, `data-src-large`, and `data-lazy-srcset`) without overriding a normal `src`.

## 3.6.0

- Preview de compatibilidade web com engine XenonWeb DOM/CSS/XenonScript, XenonMedia e rede TLS via libcurl/Mbed TLS.
