# X360Browser 6.2.0 — XenonWeb URL resolution, default.xex and GitHub auto-release

Navegador homebrew para Xbox 360 RGH/JTAG, escrito em C/C++. Esta versão concentra-se na apresentação gráfica de páginas: viewport de 1280×544, renderizador próprio XenonWeb, CSS `background-image`, descoberta de imagens referenciadas por folhas de estilo externas, interação por gamepad e atualização consultando diretamente o GitHub Releases. Não é um port do Chromium/WebKit e não deve ser descrito como navegador moderno completo.

## O que mudou na 6.2.0

- **Nome correto do executável:** o artefato instalado, o ZIP do Xbox, a GitHub Release e o atualizador usam exclusivamente `default.xex`. O target interno do xSDK continua chamado `X360Browser`, mas o script de build copia o binário compilado para `build-xbox360/default.xex`, valida tamanho e empacota somente esse nome.
- **Atualização automática com o GitHub:** depois dos testes e do build cruzado bem-sucedidos na branch `main`, `master` ou `principal`, o workflow publica uma GitHub Release estável com `default.xex`, `default.xex.sha256`, o ZIP de instalação e seu checksum. O repositório precisa ser público para o cliente do console consultar a API sem autenticação.
- **Atualizador alinhado à instalação:** baixa apenas o asset `default.xex` da release oficial, valida SHA-256 pelo digest do GitHub ou pelo arquivo de checksum e prepara `default.update.xex` se o sistema de arquivos bloquear a troca em execução. Não aceita mais o antigo asset nomeado `X360Browser.xex`.
- **URLs relativas mais corretas:** XenonNet agora resolve `./`, `../`, caminhos relativos, URLs com query, query-only e URLs scheme-relative; elimina segmentos literais `.` e `..` sem manipular escapes `%2e`. O resultado segue limitado a HTTP/HTTPS.
- **Hardening de versões:** o cliente e o parser de release rejeitam versões malformadas, componentes com zeros à esquerda e overflow numérico.
- **Novos contratos de regressão:** o workflow testa o nome de arquivo em todas as camadas, o manifest exige `default.xex` e o host testa casos de resolução de URL.

## Princípios de arquitetura e limites

XenonWeb, XenonScript e XenonMedia continuam sendo motores próprios, delimitados para o Xbox 360: o suporte a HTML/CSS/JavaScript e mídia é parcial. A atualização não transforma esses motores em Chromium/WebKit e não promete suporte universal a sites atuais, jogos web, Canvas/WebGL/WASM, iframes ou codecs modernos. O caminho completo de build usa CMake/xSDK e é executado pelo GitHub Actions.

## Publicar uma release e usar auto-update

1. Envie `X360Browser-6.2.0-source.zip` à raiz do repositório e substitua `.github/workflows/build-xex-from-zip.yml` pelo YAML desta versão.
2. Faça commit na branch principal (`main`, `master` ou `principal`). O repositório deve estar público para o cliente de atualização anônimo.
3. O GitHub Actions valida a fonte, executa testes, compila o XEX para Xbox 360 e depois publica `v6.2.0` com `default.xex` e checksums. Se a compilação falhar, a release não é publicada.
4. Instale uma vez o novo `default.xex` no console; versões anteriores ainda podem procurar assets com o nome antigo. Depois disso, a versão consulta `https://api.github.com/repos/David-Bryan010-png/X360Browser/releases/latest` e valida o SHA-256 antes de tentar aplicar atualizações futuras.
5. Cada release deve usar uma versão semântica inédita. Para a próxima, atualize `VERSION` e `include/x360browser/version.hpp` juntos.

Não é necessário Vercel nem segredo de API. Se o sistema de arquivos bloquear a substituição do executável que está em uso, a atualização verificada fica em `default.update.xex`; será necessário sair do navegador e aplicar o arquivo no lugar de `default.xex`. Atualização sem reinício/sem ação manual não pode ser garantida pelo sistema de arquivos do console.

## Histórico da arquitetura gráfica 6.0.0

- A vista gráfica é o modo padrão; o comando X percorre página gráfica, links e recursos, sem oferecer leitor textual.
- A procura do FFPlay opcional foi movida para o momento em que se solicita reprodução; navegar sem esse executável não gera tentativas de abertura no arranque.
- Erros de rede e falhas da pipeline gráfica mostram superfícies de diagnóstico próprias em vez de despejar o texto extraído do site.

- Suporte no renderizador a fundos CSS `background-image`, respeitando camada de fundo atrás do conteúdo. Imagens `<img>` continuam preservando proporção; fundos CSS podem preencher o elemento.
- Pré-carregamento de imagens de conteúdo priorizado antes de fundos decorativos, incluindo URLs encontradas em CSS externo.
- Cursor por gamepad, seleção de links/controles, campos de entrada com teclado virtual e execução limitada de `onclick`.
- Atualizador sem serviço pago ou URL de configuração: consulta `https://api.github.com/repos/David-Bryan010-png/X360Browser/releases/latest`, limita downloads, aceita somente assets da release oficial e valida SHA-256 vindo do `digest` do GitHub ou do asset de checksum. O programa tenta troca transacional e rollback; se o sistema de arquivos não permitir trocar o executável em uso, deixa o arquivo verificado como `default.update.xex` para substituição manual depois de sair do programa.
- Testes automatizados para manifesto de release, checksum, renderização de fundo CSS, layout, DOM, scripts limitados, mídia e workflow.

## Procedimento histórico de publicação 6.1.0 (não use os nomes antigos)

1. Envie `X360Browser-6.1.0-source.zip` e substitua `.github/workflows/build-xex-from-zip.yml` pelo workflow desta versão.
2. Faça commit na branch principal configurada (`main`, `master` ou `principal`) ou execute manualmente o workflow nessa branch.
3. O GitHub Actions valida a fonte, executa os testes, compila o XEX e só depois publica a release `v6.1.0` com o XEX e os checksums.
4. O navegador consulta a API pública `https://api.github.com/repos/David-Bryan010-png/X360Browser/releases/latest`, compara a versão e verifica o SHA-256 antes de instalar.
5. Para cada versão futura, incremente `VERSION` e a versão em `include/x360browser/version.hpp`. O workflow rejeita substituir uma release publicada por bytes diferentes sem aumentar a versão.

Não é necessário Vercel, segredo de API ou arquivo de configuração de atualização. O workflow usa `GITHUB_TOKEN` e declara `contents: write`. Se o console bloquear a substituição do XEX enquanto o navegador está aberto, o arquivo validado será preparado como `default.update.xex` e exigirá instalação após sair do programa.

## Limites de compatibilidade

XenonWeb é um renderizador gráfico de subconjunto HTML/CSS, não um motor equivalente ao Chromium ou WebKit. XenonScript executa um subconjunto limitado de JavaScript. Canvas/WebGL/WebAssembly, módulos modernos, promises completas, layouts CSS complexos, iframes executáveis, DRM e sites/jogos modernos não têm suporte garantido. A reprodução de YouTube é experimental e pode depender de um resolvedor MP4 e de `FFPlay.xex`; não é reprodução HTML5 completa integrada.

Os testes de host validam código portável e contratos; **não demonstram funcionamento no Xbox físico**. O novo build cruzado e a publicação real dependem da execução bem-sucedida do workflow no seu repositório. Para certificar uma release, execute o workflow de build e teste o XEX em console RGH/JTAG real.

## Testes locais

```sh
python3 tests/validate_project_integrity.py
python3 tests/test_xbox_shader_contract.py
python3 tests/test_workflow_artifact_paths.py
python3 tests/test_auto_update_contract.py
python3 tests/run_host_tests.py
cmake -S . -B build-host -DX360BROWSER_BUILD_TESTS=ON
cmake --build build-host
ctest --test-dir build-host --output-on-failure
```
