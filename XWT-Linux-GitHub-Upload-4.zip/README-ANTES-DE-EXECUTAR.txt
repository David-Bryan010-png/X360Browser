XWT LINUX 0.14.0-alpha.2 — ATUALIZACAO DO REPOSITORIO

REPOSITORIO: David-Bryan010-png/X360Browser
BRANCH: main

1. Baixe o pacote de configuracao e extraia-o no celular.
2. Envie XWT-Linux-source.zip para a raiz do repositorio.
3. Substitua .github/workflows/build-xex-from-zip.yml pelo build-xex-from-zip.yml fornecido.
4. Substitua .github/workflows/xwt-small-updates.yml pelo arquivo fornecido.
5. Mantenha o SOURCE-MANIFEST.sha256 dentro do ZIP; o workflow valida todos os arquivos antes do build.
6. Faça commit na branch main.

PRIMEIRA COMPILACAO (UMA VEZ)
GitHub -> Actions -> XWT Linux - Build minimal Xenon core -> Run workflow.
Primeiro executa `linux-configure` e confere `CONFIG_PPC_XENON`; só depois começa a compilação integral. Compila o kernel Xenon, drivers essenciais, toolchain e rootfs mínimo. Empacota default.xex + wrapper `zImage.xenon` em ELF32 PowerPC + initramfs e publica o primeiro módulo system.

ATUALIZACOES PEQUENAS DEPOIS
GitHub -> Actions -> XWT Linux - Small Updates -> Run workflow.
Informe o nome de um diretorio que exista em updates/ (por exemplo: system).

Com GitHub CLI:
gh workflow run xwt-small-updates.yml --ref main -f component=system

O workflow não chama Buildroot. Ele empacota apenas o módulo escolhido em .xwpkg e atualiza a release xwt-linux-dev.

NO XBOX 360
xwt-update list
xwt-update install system
xwt-update rollback system

A primeira instalação do módulo guarda estado anterior; atualizações seguintes preservam tanto arquivos como pacote anterior. O rollback é reaplicável após reiniciar.

BOOT
default.xex -> XellLaunch2 -> XeLL Reloaded -> wrapper zImage.xenon (ELF32 PowerPC) + rootfs.cpio.gz por kboot.conf. O kernel Linux contido no wrapper é PPC64; não use vmlinux ELF64 diretamente no XeLL.
A unidade USB deve estar em FAT32. O console precisa ser RGH/JTAG com ambiente compatível. Nenhuma escrita na NAND é feita.

MODULOS FUTUROS
Adicione um diretório updates/NOME/opt/xwt/modules/NOME/ ao código-fonte. Para um programa C/C++ compilável, inclua updates/NOME/build.sh; ele recebe o destino como primeiro argumento e utiliza o cross-toolchain em cache. Atualize XWT-Linux-source.zip e rode o mesmo workflow com component=NOME.

LIMITES
A primeira compilação completa ainda demora; é necessária para gerar o kernel e a toolchain uma vez. As atualizações de programas e serviços seguintes não recompilam kernel nem initramfs. O workflow corrigido ainda precisa concluir uma compilação completa; o teste físico do Xbox 360 continua obrigatório.
