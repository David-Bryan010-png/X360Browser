# Xbox 360 target — X360Browser 5.1.0

The target uses the xSDK shader contract: location 0 = POSITION, location 1 = COLOR, location 2 = TEXCOORD0. Version 5.1.0 expands the visual viewport to 1152×500, adds a D-pad pointer and bounded hit-testing for links/HTML controls, and integrates a verified update client using HTTPS and SHA-256.

Build with `tools/build_xbox_shell.sh` under the supported xSDK PowerPC toolchain. The runtime package contains `X360Browser.xex`, `cacert.pem`, `X360Browser-video-config.txt`, `X360Browser-update-config.txt`, `X360Browser-bookmarks.txt`, `README.txt`, and relevant licenses. Copy the full package beside the XEX rather than copying only the executable.

The updater endpoint is not preconfigured: deploy `vercel/`, add a stable GitHub Release with the exact XEX/checksum assets, and replace the first line in `X360Browser-update-config.txt` with the actual Vercel URL. The first upgrade from 5.0.0 remains manual. A successful host build/test is not a substitute for a PowerPC XEX build and a smoke test on Xbox 360 RGH/JTAG hardware.
