#ifndef X360BROWSER_VISUAL_LAYOUT_H
#define X360BROWSER_VISUAL_LAYOUT_H

#include <stddef.h>
#include <stdint.h>
#include "web_engine.h"

#ifdef __cplusplus
extern "C" {
#endif

#define WEB_VISUAL_WIDTH 1152
#define WEB_VISUAL_HEIGHT 500
#define WEB_VISUAL_MAX_RECTS 512
#define WEB_VISUAL_MAX_TEXTS 384
#define WEB_VISUAL_MAX_IMAGES 32
#define WEB_VISUAL_MAX_LINK_RECTS 320
#define WEB_VISUAL_MAX_CONTROLS 96
#define WEB_VISUAL_TEXT_CAP 224
#define WEB_VISUAL_DECORATION_UNDERLINE 1U
#define WEB_VISUAL_DECORATION_LINE_THROUGH 2U

typedef struct {
    int x, y, width, height;
    uint32_t color;
    uint32_t border_color;
    int border_width;
} WebVisualRect;

typedef struct {
    int x, y;
    uint32_t color;
    uint32_t scale;
    char text[WEB_VISUAL_TEXT_CAP];
    size_t page_link_index; /* SIZE_MAX when this is not rendered link text */
    uint8_t decoration; /* WEB_VISUAL_DECORATION_* flags */
} WebVisualText;

typedef struct {
    int x, y, width, height;
    size_t page_link_index;
} WebVisualLink;

typedef struct {
    int x, y, width, height;
    uint16_t dom_node_index;
    uint8_t kind; /* 1=input, 2=button, 3=textarea, 4=select */
} WebVisualControl;

typedef struct {
    int x, y, width, height;
    size_t placeholder_text_index;
    char cache_path[WEB_ENGINE_IMAGE_CACHE_PATH_CAP];
} WebVisualImage;

typedef struct {
    uint32_t background;
    WebVisualRect rects[WEB_VISUAL_MAX_RECTS];
    size_t rect_count;
    WebVisualText texts[WEB_VISUAL_MAX_TEXTS];
    size_t text_count;
    WebVisualImage images[WEB_VISUAL_MAX_IMAGES];
    size_t image_count;
    WebVisualLink links[WEB_VISUAL_MAX_LINK_RECTS];
    size_t link_count;
    WebVisualControl controls[WEB_VISUAL_MAX_CONTROLS];
    size_t control_count;
    size_t content_height;
    int truncated;
} WebVisualFrame;

/* Static, bounded HTML/CSS layout; does not execute scripts or fetch resources.
 * Link boxes map rendered anchor text back to WebEnginePage.links for controller focus. */
void web_visual_layout(const WebEnginePage *page, size_t scroll_pixels, WebVisualFrame *frame);
/* Run an inline anchor handler and report whether it consumes fragment navigation. */
int web_visual_dispatch_link(const WebEnginePage *page, size_t page_link_index,
                             int *navigation_consumed);
int web_visual_dispatch_control(const WebEnginePage *page, uint16_t dom_node_index);
int web_visual_get_control_value(const WebEnginePage *page, uint16_t dom_node_index,
                                 char *output, size_t output_capacity);
int web_visual_set_control_value(const WebEnginePage *page, uint16_t dom_node_index,
                                 const char *value);
/* Original parser retained as an explicit regression fallback. */
void web_visual_layout_legacy(const WebEnginePage *page, size_t scroll_pixels, WebVisualFrame *frame);

#ifdef __cplusplus
}
#endif
#endif
