#ifndef X360BROWSER_UPDATE_MANAGER_H
#define X360BROWSER_UPDATE_MANAGER_H

#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef enum {
    X360_UPDATE_DISABLED = 0,
    X360_UPDATE_CURRENT = 1,
    X360_UPDATE_INSTALLED = 2,
    X360_UPDATE_STAGED = 3,
    X360_UPDATE_ERROR = -1
} X360UpdateResult;

/* Checks an HTTPS Vercel manifest, downloads a newer XEX, verifies SHA-256, and
 * performs a rollback-capable swap. Returns installed only after the rename succeeds. */
X360UpdateResult x360_update_check_and_install(const char *manifest_url,
                                               const char *current_version,
                                               char *message, size_t message_capacity);

#ifdef __cplusplus
}
#endif
#endif
