X360Browser 5.1.0 — XenonWeb + verified update client

This is the Xbox 360 xSDK target. The main HTML/DOM/CSS/layout implementation is XenonWeb; bounded script execution is XenonScript; supported image and elementary media decoding lives in XenonMedia.

The 5.1.0 visual surface is 1152x500, with a compact top status/address strip and a gamepad-controlled pointer. Press RS to enable/disable the pointer in visual page mode; use the D-pad to move and A to activate links or visible controls. HTML controls only dispatch a bounded onclick handler where present; input editing, native form submission and modern browser APIs remain incomplete.

Raster decoding is exclusively first-party XenonMedia. No third-party raster decoder fallback is linked; unsupported profiles fail closed. External audio/video player launch is disabled by default. YouTube remains experimental and needs a compatible external player plus a public resolver that can deliver a compatible MP4. Do not assume modern YouTube HTML5, DRM, MP4/H.264/AAC or current web games will work.

The package includes X360Browser-video-config.txt and X360Browser-update-config.txt beside X360Browser.xex. HTTPS uses libcurl, Mbed TLS and cacert.pem. For updates, import the `vercel/` project into your own Vercel account, create a stable GitHub Release with X360Browser.xex and X360Browser.xex.sha256, then replace the first line of X360Browser-update-config.txt with your deployed HTTPS `/api/update` URL. The updater checks the manifest at startup, verifies SHA-256 and attempts a rollback-capable swap. This requires real console testing; if the running XEX cannot be renamed, a verified X360Browser.update.xex is left staged. Updating from 5.0.0 to 5.1.0 requires one manual copy because older builds do not include the updater.

Host tests do not prove successful PowerPC compilation or physical-console operation. Run the GitHub Actions workflow and then test on a console. See docs/XBOX_BUILD.md and vercel/README.md.
