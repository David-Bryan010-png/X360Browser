#include "update_manager.h"
#include "../../../include/x360browser/version.hpp"

#include <curl/curl.h>
#include <mbedtls/md.h>
#include <ctype.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>

#define UPDATE_MANIFEST_CAP 8192U
#define UPDATE_XEX_MAX_BYTES (64U * 1024U * 1024U)
#define UPDATE_MANIFEST_DEFAULT "disabled"
#define UPDATE_XEX_CURRENT "game:\\X360Browser.xex"
#define UPDATE_XEX_TEMP "game:\\X360Browser.update.tmp"
#define UPDATE_XEX_STAGE "game:\\X360Browser.update.xex"
#define UPDATE_XEX_BACKUP "game:\\X360Browser.previous.xex"
#define UPDATE_XEX_BACKUP_OLD "game:\\X360Browser.previous.old.xex"

typedef struct { char *data; size_t length; size_t capacity; int overflow; } MemorySink;
typedef struct { FILE *file; size_t bytes; int overflow; } FileSink;
typedef struct { char version[32]; char url[1024]; char sha256[65]; } UpdateManifest;

static void set_message(char *out, size_t cap, const char *text)
{
    if (out == NULL || cap == 0U) return;
    (void)snprintf(out, cap, "%s", text != NULL ? text : "");
}

static size_t receive_memory(char *data, size_t size, size_t count, void *user)
{
    MemorySink *sink = (MemorySink *)user;
    size_t bytes;
    if (size != 0U && count > SIZE_MAX / size) return 0U;
    bytes = size * count;
    if (sink == NULL || sink->length > sink->capacity || bytes > sink->capacity - sink->length) {
        if (sink != NULL) sink->overflow = 1;
        return 0U;
    }
    memcpy(sink->data + sink->length, data, bytes);
    sink->length += bytes;
    return bytes;
}

static size_t receive_file(char *data, size_t size, size_t count, void *user)
{
    FileSink *sink = (FileSink *)user;
    size_t bytes, wrote;
    if (size != 0U && count > SIZE_MAX / size) return 0U;
    bytes = size * count;
    if (sink == NULL || sink->file == NULL || sink->bytes > UPDATE_XEX_MAX_BYTES ||
        bytes > UPDATE_XEX_MAX_BYTES - sink->bytes) {
        if (sink != NULL) sink->overflow = 1;
        return 0U;
    }
    wrote = fwrite(data, 1U, bytes, sink->file);
    sink->bytes += wrote;
    return wrote;
}

static int curl_get_memory(const char *url, MemorySink *sink, long timeout_seconds)
{
    CURL *curl;
    CURLcode result;
    long status = 0L;
    if (url == NULL || sink == NULL || strncasecmp(url, "https://", 8U) != 0) return 0;
    curl = curl_easy_init();
    if (curl == NULL) return 0;
    (void)curl_easy_setopt(curl, CURLOPT_URL, url);
    (void)curl_easy_setopt(curl, CURLOPT_USERAGENT, "X360Browser/" X360BROWSER_VERSION_STRING " update-client");
    (void)curl_easy_setopt(curl, CURLOPT_NOSIGNAL, 1L);
    (void)curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, receive_memory);
    (void)curl_easy_setopt(curl, CURLOPT_WRITEDATA, sink);
    (void)curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1L);
    (void)curl_easy_setopt(curl, CURLOPT_MAXREDIRS, 3L);
    (void)curl_easy_setopt(curl, CURLOPT_CONNECTTIMEOUT, 5L);
    (void)curl_easy_setopt(curl, CURLOPT_TIMEOUT, timeout_seconds);
    (void)curl_easy_setopt(curl, CURLOPT_CAINFO, "cacert.pem");
    (void)curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 1L);
    (void)curl_easy_setopt(curl, CURLOPT_SSL_VERIFYHOST, 2L);
    (void)curl_easy_setopt(curl, CURLOPT_PROTOCOLS_STR, "https");
    (void)curl_easy_setopt(curl, CURLOPT_REDIR_PROTOCOLS_STR, "https");
    result = curl_easy_perform(curl);
    (void)curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &status);
    curl_easy_cleanup(curl);
    return result == CURLE_OK && status >= 200L && status < 300L && !sink->overflow;
}

static int json_string_value(const char *json, const char *key, char *out, size_t cap)
{
    char needle[64];
    const char *p, *end;
    size_t n = 0U;
    if (json == NULL || key == NULL || out == NULL || cap == 0U) return 0;
    if (snprintf(needle, sizeof(needle), "\"%s\"", key) < 0) return 0;
    p = strstr(json, needle);
    if (p == NULL) return 0;
    p += strlen(needle);
    while (*p != '\0' && isspace((unsigned char)*p)) ++p;
    if (*p++ != ':') return 0;
    while (*p != '\0' && isspace((unsigned char)*p)) ++p;
    if (*p++ != '"') return 0;
    end = p;
    while (*end != '\0' && *end != '"') {
        if (*end == '\\') return 0; /* URLs/version/hash must not require JSON escapes. */
        ++end;
    }
    if (*end != '"' || (size_t)(end - p) >= cap) return 0;
    n = (size_t)(end - p);
    memcpy(out, p, n);
    out[n] = '\0';
    return n != 0U;
}

static int valid_version(const char *version, unsigned long parts[3])
{
    char tail;
    if (version == NULL || sscanf(version, "%lu.%lu.%lu%c", &parts[0], &parts[1], &parts[2], &tail) != 3) return 0;
    return strchr(version, '-') == NULL && strchr(version, '+') == NULL;
}

static int compare_version(const char *a, const char *b)
{
    unsigned long av[3] = {0UL,0UL,0UL}, bv[3] = {0UL,0UL,0UL};
    size_t i;
    if (!valid_version(a, av) || !valid_version(b, bv)) return 0;
    for (i = 0U; i < 3U; ++i) {
        if (av[i] > bv[i]) return 1;
        if (av[i] < bv[i]) return -1;
    }
    return 0;
}

static int parse_manifest(const char *json, UpdateManifest *manifest)
{
    size_t i;
    if (!json_string_value(json, "version", manifest->version, sizeof(manifest->version)) ||
        !json_string_value(json, "xex_url", manifest->url, sizeof(manifest->url)) ||
        !json_string_value(json, "sha256", manifest->sha256, sizeof(manifest->sha256))) return 0;
    if (!valid_version(manifest->version, (unsigned long[3]){0UL,0UL,0UL})) return 0;
    {
        static const char trusted_release_prefix[] = "https://github.com/David-Bryan010-png/X360Browser/releases/download/";
        if (strncasecmp(manifest->url, trusted_release_prefix, sizeof(trusted_release_prefix) - 1U) != 0) return 0;
    }
    if (strlen(manifest->sha256) != 64U) return 0;
    for (i = 0U; i < 64U; ++i)
        if (!isxdigit((unsigned char)manifest->sha256[i])) return 0;
    return 1;
}

static int sha256_file_hex(const char *path, char out[65])
{
    FILE *file = fopen(path, "rb");
    const mbedtls_md_info_t *info = mbedtls_md_info_from_type(MBEDTLS_MD_SHA256);
    mbedtls_md_context_t ctx;
    unsigned char buffer[8192], digest[32];
    size_t got, i;
    int result = -1;
    static const char hex[] = "0123456789abcdef";
    if (file == NULL || info == NULL) { if (file != NULL) fclose(file); return 0; }
    mbedtls_md_init(&ctx);
    if (mbedtls_md_setup(&ctx, info, 0) != 0 || mbedtls_md_starts(&ctx) != 0) goto done;
    while ((got = fread(buffer, 1U, sizeof(buffer), file)) > 0U)
        if (mbedtls_md_update(&ctx, buffer, got) != 0) goto done;
    if (ferror(file) || mbedtls_md_finish(&ctx, digest) != 0) goto done;
    for (i = 0U; i < sizeof(digest); ++i) { out[i * 2U] = hex[digest[i] >> 4U]; out[i * 2U + 1U] = hex[digest[i] & 15U]; }
    out[64] = '\0';
    result = 1;
done:
    mbedtls_md_free(&ctx);
    fclose(file);
    return result;
}

static int download_xex(const char *url, const char *path)
{
    CURL *curl;
    CURLcode result;
    long status = 0L;
    FileSink sink;
    sink.file = fopen(path, "wb"); sink.bytes = 0U; sink.overflow = 0;
    if (sink.file == NULL) return 0;
    curl = curl_easy_init();
    if (curl == NULL) { fclose(sink.file); remove(path); return 0; }
    (void)curl_easy_setopt(curl, CURLOPT_URL, url);
    (void)curl_easy_setopt(curl, CURLOPT_USERAGENT, "X360Browser/" X360BROWSER_VERSION_STRING " update-client");
    (void)curl_easy_setopt(curl, CURLOPT_NOSIGNAL, 1L);
    (void)curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, receive_file);
    (void)curl_easy_setopt(curl, CURLOPT_WRITEDATA, &sink);
    (void)curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1L);
    (void)curl_easy_setopt(curl, CURLOPT_MAXREDIRS, 4L);
    (void)curl_easy_setopt(curl, CURLOPT_CONNECTTIMEOUT, 8L);
    (void)curl_easy_setopt(curl, CURLOPT_TIMEOUT, 180L);
    (void)curl_easy_setopt(curl, CURLOPT_LOW_SPEED_LIMIT, 128L);
    (void)curl_easy_setopt(curl, CURLOPT_LOW_SPEED_TIME, 15L);
    (void)curl_easy_setopt(curl, CURLOPT_CAINFO, "cacert.pem");
    (void)curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 1L);
    (void)curl_easy_setopt(curl, CURLOPT_SSL_VERIFYHOST, 2L);
    (void)curl_easy_setopt(curl, CURLOPT_PROTOCOLS_STR, "https");
    (void)curl_easy_setopt(curl, CURLOPT_REDIR_PROTOCOLS_STR, "https");
    result = curl_easy_perform(curl);
    (void)curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &status);
    curl_easy_cleanup(curl);
    if (fclose(sink.file) != 0) result = CURLE_WRITE_ERROR;
    if (result != CURLE_OK || status < 200L || status >= 300L || sink.bytes < 1024U || sink.overflow) {
        remove(path); return 0;
    }
    return 1;
}

X360UpdateResult x360_update_check_and_install(const char *manifest_url,
                                               const char *current_version,
                                               char *message, size_t message_capacity)
{
    char manifest_data[UPDATE_MANIFEST_CAP + 1U] = {0};
    MemorySink sink = { manifest_data, 0U, UPDATE_MANIFEST_CAP, 0 };
    UpdateManifest manifest;
    char calculated_hash[65] = {0};
    int compare;
    if (manifest_url == NULL || manifest_url[0] == '\0' || strcasecmp(manifest_url, UPDATE_MANIFEST_DEFAULT) == 0) {
        set_message(message, message_capacity, "Auto-update disabled: configure X360Browser-update-config.txt.");
        return X360_UPDATE_DISABLED;
    }
    if (!curl_get_memory(manifest_url, &sink, 12L) || sink.length == 0U) {
        set_message(message, message_capacity, "Update check failed; browser will continue offline-safe.");
        return X360_UPDATE_ERROR;
    }
    manifest_data[sink.length] = '\0';
    memset(&manifest, 0, sizeof(manifest));
    if (!parse_manifest(manifest_data, &manifest)) {
        set_message(message, message_capacity, "Update manifest invalid; no files changed.");
        return X360_UPDATE_ERROR;
    }
    compare = compare_version(manifest.version, current_version);
    if (compare <= 0) {
        set_message(message, message_capacity, "X360Browser is up to date.");
        return X360_UPDATE_CURRENT;
    }
    remove(UPDATE_XEX_TEMP);
    remove(UPDATE_XEX_STAGE);
    if (!download_xex(manifest.url, UPDATE_XEX_TEMP)) {
        set_message(message, message_capacity, "New version found, but XEX download failed.");
        return X360_UPDATE_ERROR;
    }
    if (!sha256_file_hex(UPDATE_XEX_TEMP, calculated_hash) || strcasecmp(calculated_hash, manifest.sha256) != 0) {
        remove(UPDATE_XEX_TEMP);
        set_message(message, message_capacity, "Update checksum mismatch; rejected safely.");
        return X360_UPDATE_ERROR;
    }
    if (rename(UPDATE_XEX_TEMP, UPDATE_XEX_STAGE) != 0) {
        remove(UPDATE_XEX_TEMP);
        set_message(message, message_capacity, "Verified update saved but could not stage it on this device.");
        return X360_UPDATE_STAGED;
    }
    /* Swap with rollback. If the running XEX cannot be renamed, keep the verified staged copy. */
    remove(UPDATE_XEX_BACKUP_OLD);
    if (rename(UPDATE_XEX_BACKUP, UPDATE_XEX_BACKUP_OLD) != 0) {
        /* No old backup is a normal first-run case; continue if it does not exist. */
        FILE *backup = fopen(UPDATE_XEX_BACKUP, "rb");
        if (backup != NULL) { fclose(backup); set_message(message, message_capacity, "Could not rotate prior backup; update left staged safely."); return X360_UPDATE_STAGED; }
    }
    if (rename(UPDATE_XEX_CURRENT, UPDATE_XEX_BACKUP) != 0) {
        (void)rename(UPDATE_XEX_BACKUP_OLD, UPDATE_XEX_BACKUP);
        set_message(message, message_capacity, "Update verified and staged; close the app and replace X360Browser.xex with X360Browser.update.xex.");
        return X360_UPDATE_STAGED;
    }
    if (rename(UPDATE_XEX_STAGE, UPDATE_XEX_CURRENT) != 0) {
        (void)rename(UPDATE_XEX_BACKUP, UPDATE_XEX_CURRENT);
        (void)rename(UPDATE_XEX_BACKUP_OLD, UPDATE_XEX_BACKUP);
        set_message(message, message_capacity, "Update install failed; previous executable restored.");
        return X360_UPDATE_ERROR;
    }
    remove(UPDATE_XEX_BACKUP_OLD);
    set_message(message, message_capacity, "Update installed. Restart X360Browser once to run the new version.");
    return X360_UPDATE_INSTALLED;
}
