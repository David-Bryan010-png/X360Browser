# X360Browser update service (Vercel)

This folder is a tiny deployable Vercel project. It does not compile the Xbox executable; GitHub Actions builds and attaches `X360Browser.xex` plus `X360Browser.xex.sha256` to a stable GitHub Release. The API discovers the latest release and publishes a JSON manifest at `/api/update`.

## Deploy from phone or computer

1. Import `David-Bryan010-png/X360Browser` into Vercel, set **Root Directory** to `vercel`, Framework Preset to **Other**, and deploy.
2. The endpoint is `https://YOUR-PROJECT.vercel.app/api/update`. Open it and verify JSON contains `version`, `xex_url` and a 64-character `sha256`. Until a stable GitHub Release with both assets exists, the endpoint intentionally returns `503`.
3. Copy the endpoint URL into `X360Browser-update-config.txt` beside `X360Browser.xex` on the Xbox USB device. Put only the full HTTPS endpoint on the first line. To disable, put `disabled`.
4. Publish a release by pushing a matching version tag (example `v5.1.0`) after the source commits are on `main`. The workflow validates source, builds the XEX, and attaches binary/checksum/package assets to the release.

The client verifies HTTPS and checks the XEX SHA-256 before attempting to stage/install it. A hash detects corruption but is not a signature; trust the GitHub account and Vercel deployment. An Xbox build/hardware smoke test remains necessary.
