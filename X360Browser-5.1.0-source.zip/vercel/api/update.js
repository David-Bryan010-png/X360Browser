export default async function handler(req, res) {
  res.setHeader("Cache-Control", "public, s-maxage=60, stale-while-revalidate=300");
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Content-Type", "application/json; charset=utf-8");
  if (req.method !== "GET" && req.method !== "HEAD") {
    res.setHeader("Allow", "GET, HEAD");
    return res.status(405).json({ error: "method_not_allowed" });
  }
  const repo = process.env.X360BROWSER_GITHUB_REPO || "David-Bryan010-png/X360Browser";
  try {
    const response = await fetch(`https://api.github.com/repos/${repo}/releases/latest`, {
      headers: { "Accept": "application/vnd.github+json", "User-Agent": "X360Browser-Update-Service", "X-GitHub-Api-Version": "2022-11-28" },
      signal: AbortSignal.timeout(8000)
    });
    if (!response.ok) return res.status(503).json({ error: "latest_release_unavailable", upstream_status: response.status });
    const release = await response.json();
    if (release.draft || release.prerelease || !release.tag_name) return res.status(503).json({ error: "no_stable_release" });
    const assets = Array.isArray(release.assets) ? release.assets : [];
    const xex = assets.find(a => a.name === "X360Browser.xex" && a.browser_download_url);
    const sums = assets.find(a => a.name === "X360Browser.xex.sha256" && a.browser_download_url);
    if (!xex || !sums) return res.status(503).json({ error: "release_missing_xex_or_checksum", release_url: release.html_url });
    const sumResponse = await fetch(sums.browser_download_url, { headers: { "User-Agent": "X360Browser-Update-Service" }, signal: AbortSignal.timeout(8000) });
    if (!sumResponse.ok) return res.status(503).json({ error: "checksum_unavailable" });
    const sumText = (await sumResponse.text()).trim();
    const match = sumText.match(/^([a-f0-9]{64})(?:\s+\*?X360Browser\.xex)?$/i);
    if (!match) return res.status(503).json({ error: "invalid_release_checksum" });
    const version = String(release.tag_name).replace(/^v/i, "");
    if (!/^\d+\.\d+\.\d+$/.test(version)) return res.status(503).json({ error: "invalid_release_version" });
    return res.status(200).json({
      product: "X360Browser",
      channel: "stable",
      version,
      xex_url: xex.browser_download_url,
      sha256: match[1].toLowerCase(),
      release_url: release.html_url,
      published_at: release.published_at || null
    });
  } catch (error) {
    return res.status(503).json({ error: "update_service_unavailable", detail: "GitHub release lookup timed out or failed" });
  }
}
