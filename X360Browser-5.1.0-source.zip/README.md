# X360Browser 5.1.0 — XenonWeb + verified update client

Navegador homebrew para Xbox 360 RGH/JTAG, escrito em C/C++ com renderizador próprio **XenonWeb**, runtime parcial **XenonScript**, decodificadores **XenonMedia** e rede HTTP/HTTPS via libcurl + Mbed TLS. Esta release melhora a área de página, adiciona um cursor controlado pelo gamepad e prepara um fluxo de atualização por Vercel/GitHub Releases com validação SHA-256.

## Destaques da 5.1.0

- **Mais área para páginas:** o surface visual passa de 1152×384 para 1152×500, reduzindo a altura da interface acima do conteúdo. O fundo externo fica em cinza-escuro neutro, não azul.
- **Cursor de controle e interações:** na visualização de página, pressione o stick direito (RS) para ligar/desligar o cursor; D-pad move; A abre links sob o cursor ou ativa a barra de endereço quando ela é apontada. `input` e `textarea` usam o teclado virtual do Xbox para atualizar o DOM; botões HTML podem executar `onclick` no subconjunto XenonScript. Seletores nativos e submissão completa de formulários continuam limitados. Fora da vista visual, RS continua abrindo os favoritos.
- **Atualização remota preparada:** o cliente lê `X360Browser-update-config.txt`, chama um endpoint HTTPS de Vercel, valida versão, baixa o XEX com limite de tamanho, verifica SHA-256 usando Mbed TLS e tenta trocar o executável com rollback. Se o sistema de arquivos não permitir renomear o XEX em execução, preserva o arquivo verificado `X360Browser.update.xex` e mostra uma instrução. A versão instalada só é executada na próxima abertura do app.
- **Vercel API:** `vercel/api/update.js` procura a última release estável do repositório GitHub configurado e serve manifesto com versão, URL e SHA-256. GitHub Actions publica o `.xex` e o checksum quando uma tag `v*` passa pelo build.
- **Workflow modernizado:** usa checkout/artifacts/cache com ações de versão atual, valida a fonte e testa os caminhos do artefato; build PowerPC/XEX continua sendo uma etapa real do CI, não uma suposição local.

## Ativar atualização automática

1. Importe o repositório `David-Bryan010-png/X360Browser` no Vercel e defina **Root Directory** como `vercel` (ver `vercel/README.md`).
2. Depois do deploy, abra `https://SEU-PROJETO.vercel.app/api/update`. O JSON precisa conter `version`, `xex_url` e `sha256`. Antes de haver release estável com `X360Browser.xex` e `X360Browser.xex.sha256`, o endpoint retorna 503 corretamente.
3. No USB do Xbox, edite `X360Browser-update-config.txt` ao lado de `X360Browser.xex` e coloque a URL real do seu endpoint Vercel na primeira linha. Não use uma URL inventada; ela é específica ao projeto criado na sua conta.
4. Instalação inicial: o auto-updater só existe a partir da 5.1.0; atualizar uma instalação 5.0.0 ou anterior exige copiar manualmente a primeira 5.1.0 para o USB. Depois disso, com a URL real configurada, as próximas versões podem ser verificadas automaticamente.

Para publicar uma versão: envie a versão fonte com `VERSION` correspondente à tag `vMAJOR.MINOR.PATCH`, depois crie e envie a tag. O Actions valida, compila e publica os binários na release. Se nenhuma release atual existir, o atualizador não instala nada.

**Nota importante:** o cliente tenta uma troca com rollback, mas não foi possível validar nesta sessão se o filesystem/loader do Xbox permite renomear o XEX atualmente executado. Caso a operação seja bloqueada, a atualização é baixada e verificada mas fica em `X360Browser.update.xex` para aplicar depois de fechar o app. O teste final desse comportamento precisa ser feito no Xbox 360 RGH/JTAG.

## Controles

| Botão | Ação |
|---|---|
| A | Abre o link selecionado/sob cursor ou a barra de endereço |
| D-pad | Move cursor quando ativo; fora disso rola/seleciona |
| RS (stick direito) | Cursor on/off na vista visual; favoritos fora dela |
| LB/RB | Rola em blocos |
| X | Alterna vista visual, leitor, lista de links e recursos |
| Y | Recarrega a página ou remove favorito selecionado |
| B | Voltar |
| START | Página inicial |
| LS (stick esquerdo) | Salvar favorito |

## YouTube, JavaScript e páginas modernas

A reprodução do YouTube continua experimental: o navegador não possui pipeline HTML5 interno completo e depende do resolvedor MP4 público e de um player externo compatível, quando habilitado na configuração. XenonScript é apenas um subconjunto de JavaScript; não equivale ao Chromium/WebKit/ECMAScript completo. Canvas/WebGL/WebAssembly, DRM, codecs modernos e jogos web atuais não têm compatibilidade garantida. A 5.1.0 não deve ser anunciada como navegador moderno completo.

## Testes locais

```bash
python3 tests/validate_project_integrity.py
python3 tests/run_host_tests.py
python3 tests/test_workflow_artifact_paths.py
python3 tests/test_auto_update_contract.py
node tests/test_vercel_update_api.mjs
cmake -S . -B build-host -DCMAKE_BUILD_TYPE=Release -DX360BROWSER_BUILD_TESTS=ON -DX360BROWSER_BUILD_DEMO=ON -DBUILD_TESTING=ON
cmake --build build-host --parallel 2
ctest --test-dir build-host --output-on-failure
```

Testes host cobrem a lógica compilável no host; não substituem a compilação PowerPC nem testes no console físico.
