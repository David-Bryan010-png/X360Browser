# X360Browser 5.1.0 — estado da release

## Mudanças concluídas na fonte

- Versão 5.1.0 e arquivos de release atualizados.
- Viewport visual ampliado para 1152×500, faixa superior compacta e fundo neutro.
- Cursor pelo D-pad na vista visual, hit-test de links e retângulos de controles HTML.
- Despacho de `onclick` em links e controles compatíveis com o subconjunto XenonScript, com regressão automatizada para botão.
- Cliente de atualização HTTPS com limite de download, validação de versão, SHA-256 por Mbed TLS e tentativa de rollback; endpoint Vercel consulta a última GitHub Release estável.
- GitHub Actions valida a fonte, roda regressões, faz build xSDK/XEX, publica checksums e cria uma release em tags `v*`.
- Documentação atualizada para informar o que está implementado e o que exige teste real.

## Validação desta árvore de fonte

- `tests/run_host_tests.py`: passou, incluindo XenonWeb DOM/CSS, XenonScript, compatibilidade de URL YouTube e XenonMedia (98 verificações sem falhas).
- `tests/validate_project_integrity.py`: passou com 66 arquivos obrigatórios.
- `tests/test_workflow_artifact_paths.py`: passou.
- `tests/test_xbox_shader_contract.py`: 13/13 passaram.
- `tests/test_auto_update_contract.py`: 13/13 passaram.
- `tests/test_vercel_update_api.mjs`: 4/4 testes da API passaram.
- CMake/CTest host: 2/2 testes passaram.
- Verificação de sintaxe C17 estrita dos arquivos tocados: passou com headers mock do xSDK.

## Pendente para lançamento físico validado

- Executar GitHub Actions para comprovar a compilação PowerPC/xSDK e gerar o `.xex`.
- Implantar `vercel/` na conta Vercel e configurar a URL real no Xbox.
- Testar boot, desenho, rolagem, mouse virtual, `onclick`, TLS, descarga/hash/instalação do atualizador no Xbox 360 RGH/JTAG.
- Validar reprodução real de MP4/YouTube com o player externo disponível. Resolver público e codecs podem falhar.

## Limites

XenonWeb é um engine nativo limitado, não Chromium/WebKit. XenonScript é um subconjunto de JavaScript. Canvas/WebGL/WebAssembly, ECMAScript completo, formulários nativos completos, DRM e reprodução HTML5 moderna do YouTube não são declarados como implementados.
