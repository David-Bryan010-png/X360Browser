# X360Browser 5.1.0 — validação e compilação automática para Xbox 360

O workflow `.github/workflows/build-xex-from-zip.yml` valida a árvore `VERSION=5.1.0` desta release e, se os testes passarem, tenta compilar e empacotar o XEX PowerPC/xSDK. O arquivo `.xex` só é confirmado como construído quando a execução do GitHub Actions termina com sucesso.

O pacote final inclui `X360Browser.xex`, `cacert.pem`, `X360Browser-video-config.txt`, `X360Browser-update-config.txt`, `X360Browser-bookmarks.txt`, documentação e licenças. Copie o pacote inteiro para a mesma pasta do Xbox, não apenas o `.xex`.

O código desta versão adiciona cursor pelo gamepad, hit-testing de links/controles, dispatch de `onclick` limitado e cliente de atualização HTTPS com SHA-256. O atualizador exige deploy manual do endpoint `vercel/` e release estável com os assets `X360Browser.xex` e `X360Browser.xex.sha256`; a primeira atualização de 5.0.0 para 5.1.0 é manual.

Os testes de host não substituem uma execução PowerPC/XEX nem teste no console. Somente o log de CI confirma a compilação real, e somente o console confirma inicialização gráfica, TLS e comportamento de troca do executável.
