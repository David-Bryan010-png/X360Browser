#!/usr/bin/env python3
"""Static regression checks for the remote update and release contract."""
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
updater = (ROOT / "platform/xbox360/xsdk/update_manager.c").read_text(encoding="utf-8")
main = (ROOT / "platform/xbox360/xsdk/main.c").read_text(encoding="utf-8")
workflow = (ROOT / ".github/workflows/build-xex-from-zip.yml").read_text(encoding="utf-8")
vercel = (ROOT / "vercel/api/update.js").read_text(encoding="utf-8")
cmake = (ROOT / "platform/xbox360/xsdk/CMakeLists.txt").read_text(encoding="utf-8")
checks = {
    "client requires HTTPS for manifest": 'strncasecmp(url, "https://", 8U)' in updater,
    "client limits update binary size": "UPDATE_XEX_MAX_BYTES (64U * 1024U * 1024U)" in updater,
    "client computes SHA-256 using Mbed TLS": "mbedtls_md_info_from_type(MBEDTLS_MD_SHA256)" in updater and "mbedtls_md_finish" in updater,
    "client trusts the configured project's release asset prefix": "releases/download/" in updater and "X360Browser.xex" in updater,
    "client attempts rollback on install failure": "rename(UPDATE_XEX_BACKUP, UPDATE_XEX_CURRENT)" in updater,
    "running browser starts updater in background": "start_update_check();" in main and "pthread_create(&g_update_thread" in main,
    "cursor can hit-test rendered links": "web_visual_renderer_hit_test" in main and "web_visual_renderer_hit_test" in (ROOT / "platform/xbox360/xsdk/visual_renderer.c").read_text(encoding="utf-8"),
    "pointer can activate bounded DOM control onclick handlers": "web_visual_renderer_hit_test_control" in main and "xw_layout_dispatch_control" in (ROOT / "engine/xenonweb/xw_layout.c").read_text(encoding="utf-8") and "WEB_VISUAL_MAX_CONTROLS" in (ROOT / "platform/xbox360/xsdk/visual_layout.h").read_text(encoding="utf-8"),
    "input and textarea fields open a virtual keyboard and update the DOM": "begin_control_keyboard" in main and "web_visual_renderer_set_control_value" in main and "xw_layout_set_control_value" in (ROOT / "engine/xenonweb/xw_layout.c").read_text(encoding="utf-8"),
    "manifest API rejects absent release assets": "release_missing_xex_or_checksum" in vercel,
    "manifest API fetches latest stable release": "/releases/latest" in vercel and "release.prerelease" in vercel,
    "GitHub Actions publishes XEX and checksum on tags": "softprops/action-gh-release@v2" in workflow and 'tags: ["v*"]' in workflow and "X360Browser.xex.sha256" in workflow,
    "update config is shipped with the XEX": 'X360Browser-update-config.txt' in cmake and "disabled" in (ROOT / "X360Browser-update-config.example.txt").read_text(encoding="utf-8"),
}
failed = [name for name, ok in checks.items() if not ok]
for name, ok in checks.items():
    print(("PASS" if ok else "FAIL") + ": " + name)
if failed:
    raise SystemExit(f"FAIL: {len(failed)} update contract checks failed")
print(f"PASS: all {len(checks)} update contract checks")
