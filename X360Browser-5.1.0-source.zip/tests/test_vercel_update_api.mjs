import handler from "../vercel/api/update.js";

const checksum = "a".repeat(64);
let mode = "success";

globalThis.fetch = async (url) => {
  const value = String(url);
  if (value.includes("/releases/latest")) {
    if (mode === "upstream-error") return new Response("rate limit", { status: 403 });
    if (mode === "missing-assets") {
      return new Response(JSON.stringify({
        tag_name: "v5.2.0", draft: false, prerelease: false,
        html_url: "https://github.com/David-Bryan010-png/X360Browser/releases/tag/v5.2.0",
        assets: []
      }), { status: 200, headers: { "Content-Type": "application/json" } });
    }
    return new Response(JSON.stringify({
      tag_name: "v5.2.0", draft: false, prerelease: false,
      html_url: "https://github.com/David-Bryan010-png/X360Browser/releases/tag/v5.2.0",
      published_at: "2026-10-28T12:00:00Z",
      assets: [
        { name: "X360Browser.xex", browser_download_url: "https://github.com/David-Bryan010-png/X360Browser/releases/download/v5.2.0/X360Browser.xex" },
        { name: "X360Browser.xex.sha256", browser_download_url: "https://github.com/David-Bryan010-png/X360Browser/releases/download/v5.2.0/X360Browser.xex.sha256" }
      ]
    }), { status: 200, headers: { "Content-Type": "application/json" } });
  }
  if (value.endsWith("X360Browser.xex.sha256")) return new Response(`${checksum}  X360Browser.xex\n`, { status: 200 });
  throw new Error(`Unexpected test URL: ${value}`);
};

function responseRecorder() {
  return {
    code: 200, headers: {}, body: null,
    setHeader(name, value) { this.headers[name] = value; },
    status(code) { this.code = code; return this; },
    json(value) { this.body = value; return this; }
  };
}

let response = responseRecorder();
await handler({ method: "GET" }, response);
if (response.code !== 200 || response.body?.version !== "5.2.0" ||
    response.body?.sha256 !== checksum || !response.body?.xex_url?.endsWith("X360Browser.xex")) {
  throw new Error(`Latest-release manifest test failed: ${JSON.stringify(response)}`);
}
console.log("PASS: Vercel API returns version, XEX URL and SHA-256 for a stable release");

mode = "missing-assets";
response = responseRecorder();
await handler({ method: "GET" }, response);
if (response.code !== 503 || response.body?.error !== "release_missing_xex_or_checksum") {
  throw new Error(`Missing-asset fail-closed test failed: ${JSON.stringify(response)}`);
}
console.log("PASS: Vercel API rejects a release without XEX/checksum assets");

mode = "upstream-error";
response = responseRecorder();
await handler({ method: "GET" }, response);
if (response.code !== 503 || response.body?.error !== "latest_release_unavailable") {
  throw new Error(`GitHub upstream failure test failed: ${JSON.stringify(response)}`);
}
console.log("PASS: Vercel API fails closed when GitHub is unavailable");

response = responseRecorder();
await handler({ method: "POST" }, response);
if (response.code !== 405 || response.body?.error !== "method_not_allowed") {
  throw new Error(`Method guard test failed: ${JSON.stringify(response)}`);
}
console.log("PASS: Vercel API rejects non-GET/HEAD methods");
