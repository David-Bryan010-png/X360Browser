# X360Browser 5.0.0 — validação e compilação automática para Xbox 360

O workflow `.github/workflows/build-xex-from-zip.yml` valida a árvore completa de `VERSION=5.0.0` e, se a validação passar, tenta compilar e empacotar o XEX automaticamente. Não existe opção manual para habilitar a compilação.

O pacote final contém `X360Browser.xex`, `cacert.pem`, `X360Browser-video-config.txt`, `X360Browser-bookmarks.txt`, documentação e licenças. Copie o pacote inteiro para a mesma pasta do Xbox; não copie somente o `.xex`, porque o certificado TLS e os arquivos de primeiro uso também são necessários/recomendados. O player externo de mídia permanece desativado por padrão.

A causa mostrada no log de 4.0.0 era `shader: the vertex layout lacks an input the shader fetches`: a entrada de textura estava em GLSL `location=1`, que no xSDK corresponde a `COLOR`, enquanto `TEXCOORD0` é `location=2`. A 5.0.0 alinha o shader ao layout, separa o diagnóstico de falhas gráficas e testa esse contrato.

Os testes de host não substituem uma execução PowerPC/XEX no console. Uma execução bem-sucedida do workflow prova que o arquivo foi compilado e empacotado; só o log do console pode confirmar se a inicialização gráfica foi corrigida no hardware.
