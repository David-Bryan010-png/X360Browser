# X360Browser 5.0.0 — estado da release

## Mudanças concluídas na fonte

- Versão 5.0.0 atualizada de forma consistente.
- Cache estático de frame visual e de hash para reduzir trabalho repetido por quadro.
- XenonScript ampliado com helpers de string comuns e cobertura de teste própria.
- Verificação de placeholder de imagem cacheada por layout, evitando consultar repetidamente os mesmos caminhos em cada texto de cada quadro.
- Invalidação explícita do cache nas navegações e no despacho de ações DOM.
- Fallback visual mais direto quando o layout DOM/CSS retorna falha.
- Busca por DuckDuckGo, Google e Bing via prefixos no campo de endereço.
- Resolver de MP4 do YouTube integrado ao modo de handoff por URL, executado em thread para evitar travar o loop de entrada.
- Detecção `auto` opcional de FFPlay e mensagens de erro que orientam a configuração.
- Atualização de UI, README, checklist de compatibilidade e workflow.

## Validação desta árvore de fonte

- `tests/run_host_tests.py`: passou após as alterações finais, incluindo os novos testes XenonScript.
- `tests/validate_project_integrity.py`: passou.
- `tests/test_workflow_artifact_paths.py`: 7/7 passaram.
- `tests/test_xbox_shader_contract.py`: 12/12 passaram.
- CMake/CTest: 2/2 testes passaram.

## Pendente para considerar lançamento físico validado

- Executar `.github/workflows/build-xex-from-zip.yml` para compilar o XEX PowerPC/xSDK e coletar logs de CI.
- Copiar o artefato para um Xbox 360 RGH/JTAG e verificar boot, desenho, rolagem, link focus, pesquisa e TLS.
- Testar reprodução de MP4 real com o player externo que o usuário possui. Instâncias públicas de resolução do YouTube e codecs podem falhar; não se presume sucesso sem teste.

## Limites

XenonWeb continua sendo um engine próprio limitado, não Chromium/WebKit. XenonScript continua um subconjunto de JavaScript. Canvas/WebGL/WASM, full ECMAScript, DRM e reprodução HTML5 atual do YouTube não são declarados como implementados.
