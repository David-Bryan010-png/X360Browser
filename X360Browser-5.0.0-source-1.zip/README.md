# X360Browser 5.0.0 — XenonWeb Next

Navegador homebrew para Xbox 360 RGH/JTAG, escrito em C/C++ e com motor próprio **XenonWeb**, runtime limitado **XenonScript**, decodificadores de imagem **XenonMedia** e transporte HTTP/HTTPS por libcurl + Mbed TLS.

## O que mudou na 5.0.0

- **Renderização sem trabalho repetido por quadro:** a estrutura visual grande saiu da pilha da função de desenho; o layout, o hash do HTML e o hash de imagens ficam em cache até uma navegação, ação DOM ou rolagem real. Isso reduz CPU e risco de stack overflow/engasgos, sem prometer FPS fixo em toda página.
- **YouTube — fluxo corrigido:** o modo `stream-url` resolve primeiro links `watch`, `youtu.be`, `shorts`, `embed` e `live` para uma URL MP4 compatível em uma thread de rede, em vez de passar a página `youtube.com/watch` diretamente para FFplay. O modo de download continua usando o resolvedor MP4 validado.
- **Player opcional com auto-detecção:** o arquivo de configuração procura `FFPlay.xex` em locais comuns e apresenta instruções específicas caso ele não exista. O player não é distribuído com o navegador.
- **Pesquisa por endereço:** DuckDuckGo continua como padrão; prefixe a pesquisa com `!g ` para Google, `!b ` para Bing ou `!d ` para DuckDuckGo.
- **Interface renovada:** versão/título consistentes, diagnósticos de rede/mídia em vermelho quando há falhas, textos mais diretos e controles claros para foco de links, rolagem, favoritos e pesquisa.
- **JavaScript básico ampliado:** XenonScript agora inclui `length`, `trim`, `toLowerCase`, `toUpperCase`, `includes`, `startsWith`, `endsWith`, `indexOf`, `charAt`, `slice` e `substring`, além do DOM limitado existente. Conversão de caixa é ASCII-only e o runtime continua delimitado.
- **Cache invalidável:** navegação e ações DOM invalidam explicitamente o layout guardado para evitar páginas antigas após atualizações.

## Controles

| Controle | Ação |
|---|---|
| A | Abrir link focado ou digitar endereço/pesquisa |
| D-pad esquerdo/direito | Trocar o link focado no modo visual; voltar/avançar fora dele |
| D-pad cima/baixo | Rolar ou selecionar item em listas |
| LB/RB | Rolar a página em blocos |
| X | Alternar visual, leitor, links e recursos |
| Y | Recarregar página ou remover favorito selecionado |
| B | Voltar |
| START | Página inicial |
| Stick esquerdo | Salvar página nos favoritos |
| Stick direito | Abrir favoritos |

## YouTube: como configurar

1. Coloque um `FFPlay.xex` compatível no mesmo diretório de `X360Browser.xex`, ou configure o caminho no arquivo `X360Browser-video-config.txt`.
2. Use `auto` na primeira linha para detecção automática. Se você já possui um arquivo de configuração antigo com `disabled`, troque essa linha para `auto` ou para o caminho correto.
3. `download` é o modo padrão e salva um MP4 compatível antes de abrir o player. `stream-url` tenta entregar a URL MP4 resolvida diretamente ao player, que precisa oferecer suporte à rede HTTPS e ao codec.

O resolvedor depende de instâncias públicas de terceiros e pode falhar por indisponibilidade, restrições do vídeo, região, CAPTCHA ou falta de MP4 compatível. O browser **não** implementa reprodução HTML5 interna completa, DRM, DASH ou todos os formatos do YouTube. Instâncias públicas são voláteis; a documentação do Invidious informa que a lista pública é curta e que disponibilidade pode mudar. <https://docs.invidious.io/instances/>

## Limites reais

XenonScript é um subconjunto experimental de JavaScript, não ECMAScript completo. Canvas 2D, WebGL, WebAssembly, workers, módulos/promises completos, codecs H.264/AAC/VP9/AV1, iframes vivos e a maioria dos jogos web atuais não têm compatibilidade garantida. Uma build aprovada não comprova funcionamento no console físico.

## Validar e construir

A validação local é feita por:

```bash
python3 tests/validate_project_integrity.py
python3 tests/run_host_tests.py
python3 tests/test_workflow_artifact_paths.py
cmake -S . -B build-host -DCMAKE_BUILD_TYPE=Release -DX360BROWSER_BUILD_TESTS=ON -DX360BROWSER_BUILD_DEMO=ON -DBUILD_TESTING=ON
cmake --build build-host --parallel 2
ctest --test-dir build-host --output-on-failure
```

O workflow `.github/workflows/build-xex-from-zip.yml` testa o projeto e tenta produzir o ZIP com o `.xex` para Xbox 360. É necessário executar o workflow e testar o artefato num Xbox 360 RGH/JTAG; nenhum build de console físico foi afirmado neste pacote.
