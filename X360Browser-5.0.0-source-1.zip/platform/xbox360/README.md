# Xbox 360 target — X360Browser 5.0.0

The active renderer uses `page.vert` input locations according to the xSDK convention: location 0 = POSITION, location 1 = COLOR, location 2 = TEXCOORD0. The old shader assigned texture coordinates to location 1; xSDK then rejected the vertex-fetch layout and the app fell back to the text reader. Version 5.0.0 corrects this mapping and adds a host regression test.

Build with `tools/build_xbox_shell.sh` using the xSDK PowerPC toolchain. The build output includes `X360Browser.xex`, `cacert.pem`, `X360Browser-video-config.txt`, `X360Browser-bookmarks.txt`, and `README.txt`. Copy the full package beside the XEX, rather than copying only the executable.

The correction has passed source and host tests, but needs a fresh XEX launch on an Xbox 360 RGH/JTAG to prove the GPU renderer starts on hardware.
