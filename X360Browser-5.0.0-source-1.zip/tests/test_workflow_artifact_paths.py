#!/usr/bin/env python3
"""Regression tests for the Actions source-artifact download/extraction path."""
from pathlib import Path
from tempfile import TemporaryDirectory
import re

ROOT = Path(__file__).resolve().parents[1]
workflow = (ROOT / ".github/workflows/build-xex-from-zip.yml").read_text(encoding="utf-8")

checks = {
    "source archive is uploaded as a separate artifact": "name: X360Browser-5.0.0-validated-source" in workflow,
    "validation log is not mixed into the source artifact": "name: X360Browser-5.0.0-validation-log" in workflow,
    "extract step searches downloaded artifact recursively": 'find "$DOWNLOAD_DIR" -type f' in workflow and "X360Browser-5.0.0-source.zip" in workflow,
    "archive checksum is required and verified": 'sha256sum -c' in workflow and 'X360Browser-5.0.0-source.zip.sha256' in workflow,
    "extract step validates version after extraction": 'FOUND_VERSION" != "5.0.0"' in workflow,
    "legacy brittle path was removed": 'ARCHIVE="$RUNNER_TEMP/validated/X360Browser-5.0.0-source.zip"' not in workflow,
}
for label, ok in checks.items():
    print(("PASS" if ok else "FAIL") + ": " + label)
if not all(checks.values()):
    raise SystemExit(1)

# Simulate both a flat artifact and the previous nested-common-ancestor structure.
with TemporaryDirectory() as tmp:
    base = Path(tmp)
    flat = base / "flat"
    nested = base / "nested" / "x360browser-dist"
    flat.mkdir(parents=True)
    nested.mkdir(parents=True)
    (flat / "X360Browser-5.0.0-source.zip").write_bytes(b"zip fixture")
    (nested / "X360Browser-5.0.0-source.zip").write_bytes(b"nested zip fixture")
    for root in (flat, base / "nested"):
        found = sorted(root.rglob("X360Browser-5.0.0-source.zip"))
        if len(found) != 1:
            raise SystemExit(f"FAIL: recursive archive discovery found {len(found)} files in {root}")
    print("PASS: archive discovery handles flat and nested artifact layouts")

print(f"PASS: all {len(checks) + 1} workflow artifact-path checks")
