# XWT Linux 0.14.0-alpha.2 — Minimal Core

Distribuição Linux experimental para Xbox 360 Xenon. A estratégia desta versão é **fazer o console inicializar e oferecer uma base utilizável primeiro**; recursos maiores serão acrescentados em módulos independentes.

## Primeira entrega

- Kernel Linux 7.2 baseado no port Xenon do Free60.
- Rootfs mínimo Buildroot/glibc PowerPC64 big-endian.
- Console textual e shell BusyBox.
- USB FAT32 para dados e atualizações.
- Ethernet SIS190 com DHCP.
- HTTPS/curl e certificados CA para buscar pacotes.
- Suporte de kernel para framebuffer/Xenos experimental e módulos de controle Xbox.
- Atualizador `.xwpkg`, backup e rollback.
- Inicialização: `default.xex` (XellLaunch2) -> XeLL Reloaded -> `xwt-linux.elf` + initramfs via `kboot.conf`.

É necessário teclado USB para operar o primeiro menu e terminal. Os drivers do controle são incluídos, mas a navegação completa do menu pelo controle será adicionada depois.

## O que fica para atualizações posteriores

Desktop gráfico, explorador de arquivos, navegador NetSurf, áudio, Wi-Fi USB, mapeamento completo do controle, APIs gráficas e evolução do driver Xenos serão módulos separados em `.xwpkg`. A compilação de um módulo não recompila kernel nem initramfs.

## Como atualizar

No GitHub, execute **Actions -> XWT Linux - Small Updates -> Run workflow** e informe o nome de um módulo que exista em `updates/`.

Com GitHub CLI:

```sh
gh workflow run xwt-small-updates.yml --ref main -f component=system
```

No Xbox:

```sh
xwt-update list
xwt-update install system
xwt-update rollback system
```

Os pacotes ficam no USB e são reaplicados no próximo boot. Para criar módulos, veja `docs/INCREMENTAL-MODULES.md`.

## Compilação

O primeiro build completo ainda é necessário uma única vez: ele constrói kernel, drivers, toolchain e rootfs mínimo. O workflow preserva cache de downloads, compilador e cross-toolchain. Depois, módulos de aplicativos/serviços são construídos e publicados de forma independente. Apenas mudanças em kernel, drivers, boot, ABI ou bibliotecas essenciais do rootfs exigem novo build completo.

## Limites e segurança

- O pacote XEX exige console modificado compatível com XellLaunch2/FreeBoot; não é para consoles retail bloqueados.
- A cadeia XEX/XeLL/ELF precisa ser validada no modelo e no hack específicos do console.
- O pacote não grava NAND, KV, SMC ou firmware.
- Xenos framebuffer é experimental; aceleração 3D geral não está implementada.
- Esta versão é console textual, não desktop gráfico completo.
- A compilação Buildroot e o teste físico no Xbox ainda não foram executados nesta entrega. Os workflows verificam o formato dos artefatos antes de publicá-los.
