# XWT Linux 1.0.0 — Linux com interface grafica para Xbox 360

Linux (Buildroot + kernel Free60 Xenon 7.2) com desktop SDL, controle, armazenamento USB, rede, atualizacoes `.xwpkg` e Doom.
Roda **somente a partir do pendrive** e nao grava na NAND do console.

## Requisitos
- Xbox 360 com exploit/JTAG/RGH funcional e acesso a `default.xex` (XellLaunch2). O pacote traz `xell-1f.bin` ao lado do `default.xex` (XeLL Reloaded compilado pelo workflow).
- Pendrive **FAT32** de 2 GB ou mais. Controle desconectado ate o Linux iniciar.

## Compilar
GitHub: **Actions -> XWT Linux - Build 1.0.0 -> Run workflow**. O job valida a fonte, roda os testes, compila e so publica se tudo passar.
Saida: `XWT-Linux-1.0.0-USB.zip` (pendrive), fonte, `system.xwpkg` e SHA-256.

## Instalar
1. Extraia o zip USB na raiz do pendrive: `default.xex`, `xell-1f.bin`, `kboot.conf`, `vmlinux`, `initrd.img` e a pasta `xwt/` (mantenha `xwt/packs/`).
2. Inicie `default.xex` no console: o XeLL lê o `kboot.conf` e entra direto no Linux (`timeout=0`, sem tocar no controle). `vmlinux` é o wrapper ELF32 `zImage.xenon`.
3. Detalhes e problemas: `BOOT-TROUBLESHOOTING-PT-BR.md`, `PACKS-PT-BR.md`, `JOGOS-PT-BR.md`, `KNOWN-ISSUES.md`.

## Como e organizado
- **Stage 1:** `initrd.img` pequeno (o XeLL aceita 1 initrd de ate 32 MiB).
- **Stage 2:** pacotes squashfs de ate 30 MiB em `xwt/packs/`, montados pelo Linux.
- **Atualizacoes pequenas:** modulos `.xwpkg` (`xwt-update`).

## Interface
Desktop com icones, barra de tarefas e janela de Configuracoes (renderizado em SDL sobre o framebuffer do Xenos; nao usa X11).

## Controles
D-pad/analogico navega, A confirma, B volta. No Doom: A atira, B usa, X corre, Y mapa, LB/RB desviam, Start menu.

## Licencas e aviso
Veja `THIRD-PARTY-NOTICES.md`. Uso por sua conta e risco; o projeto nao e afiliado a Microsoft nem ao projeto Free60.
Nao distribua jogos protegidos por direitos autorais: use seus proprios WADs ou o Freedoom.
