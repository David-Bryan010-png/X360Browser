# XWT Linux 1.0.0 — Linux com interface grafica para Xbox 360

Linux (Buildroot + kernel Free60 Xenon 7.2) com desktop SDL, controle, armazenamento USB, rede, atualizacoes `.xwpkg` e Doom.
Roda **somente a partir do pendrive** e nao grava na NAND do console.

## Requisitos
- Xbox 360 com exploit/JTAG/RGH funcional e acesso a `default.xex` (XellLaunch2). O gerenciador **XWT Boot** vai no pacote (inicia sem depender do XeLL); sem ele o pacote usa o XeLL como antes.
- Pendrive **FAT32** de 2 GB ou mais. Controle desconectado ate o Linux iniciar.

## Compilar
GitHub: **Actions -> XWT Linux - Build 1.0.0 -> Run workflow**. O job valida a fonte, roda os testes, compila e so publica se tudo passar.
Saida: `XWT-Linux-1.0.0-USB.zip` (pendrive), fonte, `system.xwpkg` e SHA-256.

## Instalar
1. Extraia o zip USB na raiz do pendrive (mantenha a pasta `X360WebTotal/Linux/packs/`).
2. Inicie `default.xex` no console; o XWT Boot abre o menu e, com o perfil salvo, inicia o Linux sozinho em 5 s (veja `XWT-BOOT-PT-BR.txt`). Sem o XWT Boot no pacote, o XeLL entra direto no Linux.
3. Detalhes e problemas: `BOOT-TROUBLESHOOTING-PT-BR.md`, `PACKS-PT-BR.md`, `JOGOS-PT-BR.md`, `KNOWN-ISSUES.md`.

## Como e organizado
- **Stage 1:** `rootfs.cpio.gz` pequeno (o XeLL aceita 1 initrd de ate 32 MiB).
- **Stage 2:** pacotes squashfs de ate 30 MiB em `packs/`, montados pelo Linux.
- **Atualizacoes pequenas:** modulos `.xwpkg` (`xwt-update`).

## Interface
Desktop com icones, barra de tarefas e janela de Configuracoes (renderizado em SDL sobre o framebuffer do Xenos; nao usa X11).

## Controles
D-pad/analogico navega, A confirma, B volta. No Doom: A atira, B usa, X corre, Y mapa, LB/RB desviam, Start menu.

## Licencas e aviso
Veja `THIRD-PARTY-NOTICES.md`. Uso por sua conta e risco; o projeto nao e afiliado a Microsoft nem ao projeto Free60.
Nao distribua jogos protegidos por direitos autorais: use seus proprios WADs ou o Freedoom.
