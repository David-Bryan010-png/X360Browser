XWT LINUX 1.0.0 - INSTALACAO (estilo Free60 classico)

O pacote USB tem tudo na raiz do pendrive, como os Linux classicos do Free60:

  /
  |-- default.xex        (XellLaunch2: inicia o XeLL)
  |-- xell-1f.bin        (XeLL Reloaded; o default.xex procura este arquivo ao lado dele)
  |-- kboot.conf         (diz ao XeLL qual kernel e initrd carregar)
  |-- vmlinux            (kernel: wrapper ELF32 PowerPC zImage.xenon, que contem o kernel PPC64)
  |-- initrd.img         (sistema inicial, stage 1; precisa ficar abaixo de 32 MiB)
  `-- xwt/
      |-- packs/         (stage 2: pacotes squashfs de ate 30 MiB + packs.list)
      |-- config/        (Wi-Fi: wpa_supplicant.conf, fuso horario)
      |-- persist/       (dados persistentes de /root e /home)
      |-- logs/          (boot-report.txt)
      `-- tools/         (xwt-kboot.py, xwt-preflight.py, xell-2f.bin reserva)

IMPORTANTE: o arquivo se chama vmlinux, mas o conteudo e o zImage.xenon (ELF32 PowerPC).
O XeLL so carrega ELF32; o vmlinux PPC64 cru do kernel NAO funciona.

INSTALAR
1. Formate o pendrive em FAT32 (MBR, nao GPT/exFAT).
2. Extraia o zip USB na raiz do pendrive, mantendo as pastas.
3. Deixe controle e outros USB desconectados, e inicie default.xex pelo Aurora/XeXMenu.
   O boot e automatico (timeout=0 no kboot.conf): nao precisa tocar no controle.
4. Se o seu console precisa da imagem 2f, copie xwt/tools/xell-2f.bin para a raiz com o nome xell-1f.bin.

NO PC (opcional)
- python3 xwt/tools/xwt-preflight.py <pendrive>   confere a estrutura antes de ir ao console
- python3 xwt/tools/xwt-kboot.py <pendrive> --mode menu|text|safe|debug|auto

WI-FI
Copie /etc/xwt/wpa_supplicant.conf.example para xwt/config/wpa_supplicant.conf no pendrive e preencha SSID e senha.
O chipset precisa ter driver Linux no kernel.

MIGRANDO DO LAYOUT ANTIGO
A pasta X360WebTotal/ nao e mais usada. Para manter Wi-Fi e dados, copie:
  X360WebTotal/config  -> xwt/config
  X360WebTotal/User/persist -> xwt/persist
Depois apague X360WebTotal/ e o arquivo xenon.elf, se existirem (xenon.elf na raiz so e usado pelo XeLL quando nao ha kboot.conf).

LIMITES
- Nao ha teste fisico confirmado em console. Nenhum script grava NAND, KV, SMC ou firmware.
- O driver Xenos oferece framebuffer; nao ha aceleracao 2D/3D.
