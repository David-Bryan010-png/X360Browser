# XWT Linux 0.15.0 — Xbox 360

Esta é a atualização direta da fonte **0.14.0-alpha.2 para 0.15.0**. O pacote mantém o boot existente (XellLaunch2 → XeLL → `zImage.xenon` + initramfs), o sistema de atualização `.xwpkg` e a instalação persistente somente no USB.

## O que mudou

- Desktop SDL 1.2 + SDL_ttf agora é compilado e instalado no rootfs. O sistema verifica o framebuffer real; quando não há um modo utilizável, retorna ao menu textual.
- O daemon `xwt-gamepad-keys` agora é compilado e iniciado no boot. Ele monitora até quatro joysticks, reconecta controles e entrega setas/Enter/Escape por `uinput`.
- Diagnóstico de vídeo executado no boot e salvo em `/run/xwt-video-report.txt`.
- Assistente Wi-Fi para adaptadores USB cujo chipset tenha driver Linux disponível. Configure as credenciais em `X360WebTotal/config/wpa_supplicant.conf` no USB.
- Pacotes SDL, SDL_ttf, DejaVu, dialog, iw, wpa_supplicant e ferramentas ALSA adicionados ao Buildroot.
- Correção de alinhamento/limites do framebuffer Xenos integrada ao workflow de kernel.

## Compilar

No repositório GitHub, execute **Actions → XWT Linux — Build 0.15.0 → Run workflow**. O job primeiro valida o código-fonte, executa os testes, configura o kernel/Buildroot e só publica os artefatos se a compilação terminar com sucesso.

Artefatos esperados: pacote USB bootável, fonte atualizada, manifesto, módulo inicial `system.xwpkg` e relatórios SHA-256.

## Controles

Controle Xbox USB compatível com `xpad`: D-pad/analógico navega; A/Start confirma; B/Back volta. Controles sem fio precisam do receptor USB compatível. O mapa exato de botões pode variar conforme o driver/dispositivo.

## Wi-Fi

1. Monte o USB em `/mnt/xwt-usb`.
2. Copie `etc/xwt/wpa_supplicant.conf.example` para `X360WebTotal/config/wpa_supplicant.conf` no USB.
3. Preencha `ssid` e `psk` no arquivo local do USB.
4. No desktop, abra Wi-Fi e escolha status/scan/connect pelo menu textual ou shell.

O suporte depende do chipset e do driver presente no kernel; não existe compatibilidade universal com qualquer dongle.

## Diagnóstico de vídeo

O boot grava `/run/xwt-video-report.txt`. Execute `xwt-video-check` para consultar `/dev/fb0`, modo, driver e mensagens DRM/Xenos. A interface só inicia se a geometria e a memória reportadas pelo framebuffer forem coerentes.

## Limites declarados

- Esta versão não promete aceleração 3D completa nem compatibilidade com todo modo/resolução.
- O navegador completo ainda não é instalado pelo Buildroot; o ícone informa quando o componente não estiver presente.
- Áudio depende de driver e hardware compatíveis; a presença de `alsamixer`/`aplay` não prova que o áudio Xenon esteja funcional.
- Não há teste físico confirmado em console nesta entrega. Nenhum script grava NAND, KV, SMC ou firmware.
