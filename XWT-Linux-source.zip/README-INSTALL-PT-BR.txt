XWT LINUX 0.14.0-alpha.2 — CORE MINIMO — XBOX 360 XENON
Criador/referência: DVDBRN

OBJETIVO
Entregar primeiro uma base que inicializa, mostra um console Linux, reconhece USB, configura Ethernet e consegue receber módulos pequenos. Desktop, navegador, áudio, Wi-Fi e recursos avançados serão adicionados depois.

REQUISITOS
- Xbox 360 RGH/JTAG com FreeBoot e ambiente XeLL/XellLaunch2 compatível.
- USB FAT32.
- Teclado USB recomendado para operar o menu textual nesta versão.
- Cabo Ethernet recomendado para testar rede e atualizador.

INSTALAÇÃO E BOOT
1. Extraia todo o conteúdo do pacote USB na raiz do USB FAT32.
2. Confirme default.xex e kboot.conf na raiz.
3. Confirme X360WebTotal/Linux/xwt-linux.elf e rootfs.cpio.gz.
4. Conecte o USB e abra default.xex pelo Aurora ou XeXMenu.
5. XellLaunch2 inicia XeLL Reloaded.
6. XeLL lê kboot.conf, carrega o ELF e o initramfs.
7. O Linux inicia em RAM; dados e atualizações ficam no USB.

PRIMEIRO TESTE
- Menu textual: Diagnóstico do sistema.
- Rede: Diagnóstico de rede. O cabo deve estar conectado antes do boot.
- Atualizações: xwt-update list.
- Módulo inicial: xwt-update install system.

ATUALIZAÇÕES PEQUENAS
No GitHub: Actions -> XWT Linux - Small Updates -> Run workflow -> informe o componente.
GitHub CLI: gh workflow run xwt-small-updates.yml --ref main -f component=system
No Xbox: xwt-update install system
Rollback: xwt-update rollback system

Os pacotes instalados no USB são reaplicados no boot. O rollback restaura os arquivos e o pacote da versão anterior, inclusive depois de reiniciar.

EVOLUÇÃO
Desktop gráfico, explorador, NetSurf, áudio, Wi-Fi USB, navegação por controle e melhorias gráficas serão módulos separados. Alterações de aplicativos e serviços não exigem rebuild do kernel. Kernel, drivers, boot e ABI exigem nova compilação-base.

SEGURANÇA E LIMITES
- O XEX exige ambiente modificado compatível; não é para console retail bloqueado.
- Não grava NAND, KV, SMC ou firmware.
- Driver Xenos/framebuffer é experimental; aceleração 3D geral não está pronta.
- O core inicial é um console textual, não um desktop gráfico completo.
- A validação de pacote e os testes automatizados não substituem a compilação real e o teste físico no Xbox 360.
