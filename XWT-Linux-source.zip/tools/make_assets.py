#!/usr/bin/env python3
"""Generate the XWT desktop art (wallpapers, icons, logos) as 24-bit BMP files for SDL 1.2.

Developer tool (needs Pillow + numpy); the generated files are committed, CI does not run it.
Colour key for transparency: pure magenta (255, 0, 255). Usage: python3 tools/make_assets.py [--version 1.0.0]
"""
from __future__ import annotations

import argparse
import math
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw, ImageFilter, ImageFont

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "linux/overlay/usr/share/xwt"
FONTS = Path("/usr/share/fonts/truetype/dejavu")
KEY = (255, 0, 255)
NAVY = (8, 16, 38)
PANEL = (14, 24, 48)  # settings window background (C_WIN in xwt-desktop.c)
SIZES = [(640, 480), (720, 480), (848, 480), (1024, 768), (1280, 720), (1280, 1024), (1920, 1080)]


def font(name: str, size: int) -> ImageFont.FreeTypeFont:
    return ImageFont.truetype(str(FONTS / name), max(8, int(size)))


def save_bmp(img: Image.Image, name: str) -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    img.convert("RGB").save(OUT / name, format="BMP")


def keyed(rgba: Image.Image, size: int, under=NAVY) -> Image.Image:
    """Downscale an RGBA drawing; blend edges onto 'under' and make transparent pixels the colour key."""
    small = rgba.resize((size, size), Image.LANCZOS)
    arr = np.array(small).astype(np.float32)
    a = arr[..., 3:4] / 255.0
    rgb = arr[..., :3] * a + np.array(under, np.float32) * (1 - a)
    out = rgb.astype(np.uint8)
    out[arr[..., 3] < 110] = KEY
    return Image.fromarray(out, "RGB")


def vgrad(w, h, top, bottom):
    t = np.linspace(0, 1, h)[:, None, None]
    return (np.array(top)[None, None, :] * (1 - t) + np.array(bottom)[None, None, :] * t).repeat(w, 1)


def linear(c1, c2, t):
    return tuple(int(c1[i] * (1 - t) + c2[i] * t) for i in range(3))


# ------------------------------------------------------------------ logo / wallpaper
def swirl(size: int) -> Image.Image:
    """Green glowing 'X' with an orbit ring, drawn on a transparent square."""
    s = size * 4
    img = Image.new("RGBA", (s, s), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    cx = cy = s / 2
    for k, (a0, a1) in enumerate(((200, 340), (20, 160))):
        r1, r2 = s * 0.46, s * 0.40
        for i in range(60):
            t = i / 59
            ang = math.radians(a0 + (a1 - a0) * t)
            rr = r1 - (r1 - r2) * math.sin(math.pi * t)
            wdt = s * 0.028 * math.sin(math.pi * t) + 2
            x, y = cx + rr * math.cos(ang), cy + rr * math.sin(ang)
            d.ellipse([x - wdt, y - wdt, x + wdt, y + wdt], fill=linear((20, 150, 40), (170, 255, 110), t) + (255,))
    for (x0, y0, x1, y1) in ((0.18, 0.18, 0.82, 0.82), (0.82, 0.18, 0.18, 0.82)):
        for i in range(70):
            t = i / 69
            x = s * (x0 + (x1 - x0) * t)
            y = s * (y0 + (y1 - y0) * t)
            bow = math.sin(math.pi * t) * s * 0.03 * (1 if x0 < x1 else -1)
            wdt = s * 0.05 * (1 - abs(t - 0.5) * 1.5) + 2
            d.ellipse([x + bow - wdt, y - wdt, x + bow + wdt, y + wdt],
                      fill=linear((16, 124, 16), (190, 255, 130), 1 - abs(t - 0.5) * 2) + (255,))
    glow = img.filter(ImageFilter.GaussianBlur(s * 0.025))
    out = Image.alpha_composite(glow, img)
    return out.resize((size, size), Image.LANCZOS)


def wallpaper(w: int, h: int, version: str) -> Image.Image:
    s = h / 720.0
    arr = vgrad(w, h, (3, 8, 20), (9, 44, 66)).astype(np.float32)
    yy, xx = np.mgrid[0:h, 0:w]
    glow = np.exp(-(((xx - w * 0.36) / (w * 0.30)) ** 2 + ((yy - h * 0.42) / (h * 0.36)) ** 2))
    arr[..., 1] += glow * 34
    arr[..., 2] += glow * 22
    base = Image.fromarray(np.clip(arr, 0, 255).astype(np.uint8), "RGB").convert("RGBA")
    sw = int(330 * s)
    base.alpha_composite(swirl(sw), (int(w * 0.20), int(h * 0.42 - sw / 2)))
    d = ImageDraw.Draw(base)
    tx, ty = int(w * 0.455), int(h * 0.28)
    big = font("DejaVuSans-BoldOblique.ttf", 150 * s)
    d.text((tx + 4, ty + 4), "XWT", font=big, fill=(0, 0, 0, 120))
    d.text((tx, ty), "XWT", font=big, fill=(236, 240, 248, 255))
    sub = font("DejaVuSans-Oblique.ttf", 44 * s)
    x = tx + int(6 * s)
    for ch in "LINUX":
        d.text((x, int(h * 0.55)), ch, font=sub, fill=(190, 200, 214, 255))
        x += int(sub.getlength(ch) + 22 * s)
    d.text((x - int(64 * s), int(h * 0.62)), f"v{version}", font=font("DejaVuSans.ttf", 22 * s), fill=(200, 210, 220, 255))
    return base.convert("RGB")


# ------------------------------------------------------------------ icons
def canvas(n=256):
    img = Image.new("RGBA", (n, n), (0, 0, 0, 0))
    return img, ImageDraw.Draw(img)


def vgradient_rect(img, box, top, bottom, radius=0):
    x0, y0, x1, y1 = [int(v) for v in box]
    g = Image.fromarray(vgrad(x1 - x0, y1 - y0, top, bottom).astype(np.uint8), "RGB").convert("RGBA")
    mask = Image.new("L", g.size, 0)
    ImageDraw.Draw(mask).rounded_rectangle([0, 0, g.size[0] - 1, g.size[1] - 1], radius=radius, fill=255)
    img.paste(g, (x0, y0), mask)


def icon_computer():
    img, d = canvas()
    vgradient_rect(img, (24, 34, 232, 168), (70, 110, 190), (30, 60, 130), 14)
    vgradient_rect(img, (40, 50, 216, 152), (90, 190, 255), (20, 80, 190), 6)
    d.rectangle([116, 168, 140, 196], fill=(150, 160, 180, 255))
    vgradient_rect(img, (64, 194, 192, 214), (190, 200, 215), (120, 130, 150), 8)
    return img


def icon_globe():
    img, d = canvas()
    d.ellipse([20, 20, 236, 236], fill=(20, 80, 190, 255))
    vgradient_rect(img, (24, 24, 232, 232), (80, 180, 255), (10, 60, 170), 104)
    d = ImageDraw.Draw(img)
    for box in ((84, 24, 172, 232), (128 - 20, 24, 128 + 20, 232)):
        d.ellipse(box, outline=(235, 245, 255, 255), width=7)
    for y in (84, 128, 172):
        d.line([34, y, 222, y], fill=(235, 245, 255, 255), width=7)
    d.ellipse([20, 20, 236, 236], outline=(230, 244, 255, 255), width=9)
    return img


def icon_folder():
    img, d = canvas()
    vgradient_rect(img, (22, 54, 118, 100), (250, 205, 90), (230, 160, 40), 10)
    vgradient_rect(img, (22, 76, 234, 214), (255, 214, 100), (226, 150, 30), 14)
    d.rounded_rectangle([22, 96, 234, 106], radius=4, fill=(255, 235, 170, 255))
    return img


def icon_gear():
    img, d = canvas()
    cx = cy = 128
    pts = []
    for i in range(16):
        for (r, off) in ((112, -0.10), (112, 0.10), (88, 0.18), (88, 0.40)):
            a = (i + off + (0.5 if r == 88 else 0)) * 2 * math.pi / 8
            pts.append((cx + r * math.cos(a), cy + r * math.sin(a)))
    pts = []
    for i in range(8):
        base = i * math.pi / 4
        for (r, o) in ((84, -0.30), (112, -0.17), (112, 0.17), (84, 0.30)):
            pts.append((cx + r * math.cos(base + o), cy + r * math.sin(base + o)))
    d.polygon(pts, fill=(205, 214, 230, 255))
    d.ellipse([cx - 84, cy - 84, cx + 84, cy + 84], fill=(176, 190, 214, 255))
    d.ellipse([cx - 40, cy - 40, cx + 40, cy + 40], fill=(0, 0, 0, 0))
    out = img.copy()
    ImageDraw.Draw(out).ellipse([cx - 46, cy - 46, cx + 46, cy + 46], fill=(40, 70, 130, 255))
    ImageDraw.Draw(out).ellipse([cx - 28, cy - 28, cx + 28, cy + 28], fill=(10, 20, 50, 255))
    return out


def icon_gamepad():
    img, d = canvas()
    vgradient_rect(img, (16, 70, 240, 190), (190, 196, 206), (96, 104, 120), 54)
    d = ImageDraw.Draw(img)
    d.ellipse([20, 120, 96, 220], fill=(110, 118, 134, 255))
    d.ellipse([160, 120, 236, 220], fill=(110, 118, 134, 255))
    d.rectangle([58, 98, 94, 112], fill=(40, 44, 54, 255)); d.rectangle([69, 87, 83, 123], fill=(40, 44, 54, 255))
    for (x, y, c) in ((176, 92, (240, 200, 40)), (200, 112, (220, 50, 50)), (152, 112, (60, 110, 230)), (176, 132, (60, 190, 70))):
        d.ellipse([x - 13, y - 13, x + 13, y + 13], fill=c + (255,))
    d.ellipse([112, 100, 144, 132], fill=(60, 190, 70, 255))
    return img


def icon_terminal():
    img, d = canvas()
    vgradient_rect(img, (16, 28, 240, 228), (70, 80, 100), (24, 30, 42), 16)
    d = ImageDraw.Draw(img)
    d.rectangle([24, 58, 232, 220], fill=(10, 14, 20, 255))
    for i, c in enumerate(((240, 90, 80), (240, 190, 60), (80, 200, 90))):
        d.ellipse([34 + i * 26, 36, 50 + i * 26, 52], fill=c + (255,))
    f = font("DejaVuSansMono-Bold.ttf", 92)
    d.text((38, 92), ">_", font=f, fill=(90, 230, 90, 255))
    return img


def icon_help():
    img, d = canvas()
    vgradient_rect(img, (20, 20, 236, 236), (90, 180, 255), (14, 80, 190), 108)
    d = ImageDraw.Draw(img)
    d.ellipse([20, 20, 236, 236], outline=(230, 244, 255, 255), width=8)
    f = font("DejaVuSans-Bold.ttf", 170)
    w = f.getlength("?")
    d.text((128 - w / 2, 18), "?", font=f, fill=(255, 255, 255, 255))
    return img


def icon_apps():
    img, d = canvas()
    cols = [(60, 160, 255), (255, 170, 40), (80, 200, 90), (240, 80, 80), (170, 110, 240), (30, 190, 200),
            (250, 210, 60), (120, 130, 150), (60, 120, 220)]
    for i, c in enumerate(cols):
        x, y = 22 + (i % 3) * 72, 22 + (i // 3) * 72
        vgradient_rect(img, (x, y, x + 62, y + 62), tuple(min(255, v + 40) for v in c), tuple(int(v * 0.65) for v in c), 14)
    return img


def icon_power():
    img, d = canvas()
    vgradient_rect(img, (20, 20, 236, 236), (255, 110, 90), (170, 30, 30), 108)
    d = ImageDraw.Draw(img)
    d.arc([68, 74, 188, 194], start=-52, end=232, fill=(255, 255, 255, 255), width=17)
    d.line([128, 52, 128, 128], fill=(255, 255, 255, 255), width=17)
    d.ellipse([20, 20, 236, 236], outline=(255, 226, 220, 255), width=7)
    return img


def white_glyph(draw_fn, size=32):
    img, d = canvas()
    draw_fn(d)
    return keyed(img, size, PANEL)


def g_monitor(d):
    d.rounded_rectangle([20, 34, 236, 168], radius=16, outline=(255, 255, 255, 255), width=16)
    d.rectangle([110, 168, 146, 206], fill=(255, 255, 255, 255)); d.rectangle([70, 204, 186, 222], fill=(255, 255, 255, 255))


def g_wifi(d):
    for r in (96, 66, 36):
        d.arc([128 - r, 150 - r, 128 + r, 150 + r], start=-135, end=-45, fill=(255, 255, 255, 255), width=20)
    d.ellipse([112, 176, 144, 208], fill=(255, 255, 255, 255))


def g_speaker(d):
    d.polygon([(30, 98), (88, 98), (150, 40), (150, 216), (88, 158), (30, 158)], fill=(255, 255, 255, 255))
    for r in (46, 82):
        d.arc([150 - r, 128 - r, 150 + r, 128 + r], start=-50, end=50, fill=(255, 255, 255, 255), width=16)


def g_pad(d):
    d.rounded_rectangle([14, 70, 242, 190], radius=56, fill=(255, 255, 255, 255))
    d.rectangle([58, 108, 98, 122], fill=(29, 36, 31, 255)); d.rectangle([71, 95, 85, 135], fill=(29, 36, 31, 255))
    d.ellipse([160, 98, 186, 124], fill=(29, 36, 31, 255)); d.ellipse([190, 124, 216, 150], fill=(29, 36, 31, 255))


def g_info(d):
    d.ellipse([16, 16, 240, 240], outline=(255, 255, 255, 255), width=18)
    d.rectangle([112, 108, 144, 190], fill=(255, 255, 255, 255)); d.ellipse([110, 58, 146, 94], fill=(255, 255, 255, 255))


def g_disk(d):
    d.rounded_rectangle([24, 70, 232, 186], radius=20, outline=(255, 255, 255, 255), width=16)
    d.ellipse([176, 114, 204, 142], fill=(255, 255, 255, 255)); d.rectangle([52, 120, 130, 136], fill=(255, 255, 255, 255))


def g_update(d):
    d.arc([40, 40, 216, 216], start=20, end=300, fill=(255, 255, 255, 255), width=22)
    d.polygon([(206, 28), (236, 112), (150, 100)], fill=(255, 255, 255, 255))


def g_log(d):
    d.rounded_rectangle([44, 16, 212, 240], radius=18, outline=(255, 255, 255, 255), width=16)
    for y in (86, 128, 170):
        d.rectangle([82, y, 174, y + 14], fill=(255, 255, 255, 255))


def g_gear(d):
    cx = cy = 128
    pts = []
    for i in range(8):
        b = i * math.pi / 4
        for (r, o) in ((84, -0.30), (116, -0.17), (116, 0.17), (84, 0.30)):
            pts.append((cx + r * math.cos(b + o), cy + r * math.sin(b + o)))
    d.polygon(pts, fill=(255, 255, 255, 255))
    d.ellipse([cx - 84, cy - 84, cx + 84, cy + 84], fill=(255, 255, 255, 255))
    d.ellipse([cx - 36, cy - 36, cx + 36, cy + 36], fill=(0, 0, 0, 0))


def canvas_glyph(fn):
    img, d = canvas()
    fn(d)
    return img


def xwt_bar_logo(w=96, h=26):
    img = Image.new("RGB", (w * 4, h * 4), KEY)
    d = ImageDraw.Draw(img)
    d.text((8, 0), "XWT", font=font("DejaVuSans-BoldOblique.ttf", h * 4 * 0.80), fill=(236, 240, 248))
    img = img.resize((w, h), Image.LANCZOS)
    arr = np.array(img)
    near = (np.abs(arr.astype(int) - np.array(KEY)).sum(axis=2) < 150)
    arr[near] = KEY
    arr[~near] = np.clip(arr[~near], 0, 254)
    return Image.fromarray(arr, "RGB")


def g_wifi_bar(color):
    img, d = canvas()
    for r in (104, 72, 40):
        d.arc([128 - r, 170 - r, 128 + r, 170 + r], start=-135, end=-45, fill=color + (255,), width=24)
    d.ellipse([110, 160, 146, 196], fill=color + (255,))
    return keyed(img, 22, (10, 20, 44))


def g_drive_bar(color):
    img, d = canvas()
    d.rounded_rectangle([20, 70, 236, 186], radius=22, fill=color + (255,))
    d.ellipse([186, 112, 214, 140], fill=(10, 20, 44, 255))
    return keyed(img, 22, (10, 20, 44))


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--version", default="1.0.0")
    args = ap.parse_args()
    for (w, h) in SIZES:
        save_bmp(wallpaper(w, h, args.version), f"wallpaper-{w}x{h}.bmp")
    icons = {"computer": icon_computer, "web": icon_globe, "folder": icon_folder, "gear": icon_gear,
             "game": icon_gamepad, "term": icon_terminal, "help": icon_help, "power": icon_power, "apps": icon_apps}
    for name, fn in icons.items():
        save_bmp(keyed(fn(), 64), f"icon-{name}.bmp")
    glyphs = {"system": g_monitor, "network": g_wifi, "video": g_monitor, "audio": g_speaker, "pad": g_pad,
              "storage": g_disk, "update": g_update, "log": g_log, "about": g_info, "gear": g_gear}
    for name, fn in glyphs.items():
        save_bmp(white_glyph(fn), f"glyph-{name}.bmp")
    save_bmp(keyed(swirl(256), 112, PANEL), "xlogo.bmp")
    save_bmp(white_glyph(g_gear, 32).copy() if False else keyed(canvas_glyph(g_gear), 32, (24, 80, 190)), "glyph-gear-title.bmp")
    save_bmp(xwt_bar_logo(), "bar-logo.bmp")
    save_bmp(g_wifi_bar((107, 190, 70)), "bar-wifi-on.bmp")
    save_bmp(g_wifi_bar((232, 163, 23)), "bar-wifi-off.bmp")
    save_bmp(g_drive_bar((107, 190, 70)), "bar-drive-on.bmp")
    save_bmp(g_drive_bar((232, 163, 23)), "bar-drive-off.bmp")
    print("assets written to", OUT)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
