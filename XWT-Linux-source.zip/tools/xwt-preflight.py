#!/usr/bin/env python3
"""XWT Preflight: confere no celular/PC se o pendrive (ou o zip USB) vai ser aceito pelo XeLL.

So biblioteca padrao (Pydroid 3, Termux, PC). Nao emula nada e nao altera arquivos.
Uso:  python3 xwt-preflight.py <pasta-do-pendrive | XWT-Linux-1.0.0-USB.zip>
Sem argumento procura em /storage/*, /sdcard e na pasta atual.
"""
from __future__ import annotations

import glob
import gzip
import hashlib
import struct
import sys
import zipfile
from pathlib import Path

XELL_INITRD_MAX = 32 * 1024 * 1024
XELL_ELF_MAX = 0x05FE0000
PACK_MAX = 30 * 1024 * 1024
LIN = "X360WebTotal/Linux/"
NEEDED_IN_STAGE1 = ["bin/busybox", "etc/inittab", "etc/init.d/rcS", "etc/init.d/S30storage",
                    "usr/sbin/xwt-storage", "usr/sbin/xwt-packs", "usr/sbin/xwt-system-menu", "dev/console"]


class Source:
    def __init__(self, path: Path):
        self.zip = zipfile.ZipFile(path) if path.is_file() else None
        self.root = path
        self.label = str(path)

    def exists(self, rel):
        return rel in self.zip.namelist() if self.zip else (self.root / rel).is_file()

    def read(self, rel):
        return self.zip.read(rel) if self.zip else (self.root / rel).read_bytes()

    def names(self, prefix):
        if self.zip:
            return [n for n in self.zip.namelist() if n.startswith(prefix)]
        base = self.root / prefix
        return [prefix + p.name for p in sorted(base.glob("*"))] if base.is_dir() else []


def newc_names(data: bytes) -> set[str]:
    names, off = set(), 0
    while off + 110 <= len(data):
        if data[off:off + 6] not in (b"070701", b"070702"):
            raise ValueError("cabecalho CPIO invalido")
        f = [int(data[off + 6 + i * 8: off + 14 + i * 8], 16) for i in range(13)]
        size, nsize = f[6], f[11]
        name = data[off + 110: off + 110 + nsize - 1].decode("utf-8", "replace")
        if name == "TRAILER!!!":
            return names
        names.add(name.lstrip("./"))
        off = (off + 110 + nsize + 3) & ~3
        off = (off + size + 3) & ~3
    raise ValueError("CPIO sem TRAILER!!!")


def check(src: Source):
    res = []  # (ok, titulo, dica)

    def add(ok, title, hint=""):
        res.append((bool(ok), title, hint))

    for rel in ("default.xex", "kboot.conf", LIN + "xwt-linux.elf", LIN + "rootfs.cpio.gz"):
        add(src.exists(rel), f"arquivo {rel}", "copie a pasta inteira do zip USB para a raiz do pendrive")
    if not all(r[0] for r in res):
        return res
    add(src.read("default.xex")[:4] == b"XEX2", "default.xex e um XEX2 valido")

    kb = src.read("kboot.conf")
    text = kb.decode("utf-8", "replace")
    add(b"\r" not in kb, "kboot.conf sem CRLF", "salve com quebra de linha Unix (LF)")
    add(len(kb) <= 16000 and all(len(l) <= 255 for l in text.splitlines()), "kboot.conf dentro dos limites do XeLL")
    add("timeout=0" in text.replace(" ", ""), "boot automatico (timeout=0)", "use xwt-kboot.py --mode auto")
    add("xwt-linux.elf" in text and "rootfs.cpio.gz" in text, "entrada padrao aponta para kernel e initrd")

    k = src.read(LIN + "xwt-linux.elf")
    ok_elf = len(k) > 52 and k[:7] == b"\x7fELF\x01\x02\x01" and struct.unpack(">H", k[18:20])[0] == 20
    add(ok_elf, "kernel e ELF32 PowerPC big-endian (zImage.xenon)", "o XeLL nao carrega vmlinux ELF64")
    add(len(k) < XELL_ELF_MAX, f"kernel < limite do XeLL ({len(k) // 1024} KiB)")

    z = src.read(LIN + "rootfs.cpio.gz")
    add(len(z) <= XELL_INITRD_MAX, f"initrd <= 32 MiB ({len(z) // 1024} KiB)",
        "acima disso o XeLL mostra 'Failed! ... rootfs.cpio.gz / Aborting!'")
    try:
        names = newc_names(gzip.decompress(z))
        add(True, f"initrd e gzip + cpio newc valido ({len(names)} entradas)")
        add("init" in names or "sbin/init" in names, "initrd tem /init ou /sbin/init")
        miss = [n for n in NEEDED_IN_STAGE1 if n not in names]
        add(not miss, "arquivos criticos no stage 1", "faltando: " + ", ".join(miss))
    except Exception as exc:
        add(False, "initrd legivel", str(exc))

    lst = LIN + "packs/packs.list"
    if src.exists(lst):
        for line in src.read(lst).decode().splitlines():
            try:
                digest, name, size = line.split()
                data = src.read(LIN + "packs/" + name) if src.exists(LIN + "packs/" + name) else None
            except ValueError:
                add(False, f"linha invalida em packs.list: {line!r}")
                continue
            if data is None:
                add(False, f"pacote {name}", "arquivo ausente: copie a pasta packs/ inteira")
            else:
                add(len(data) == int(size) and len(data) <= PACK_MAX and hashlib.sha256(data).hexdigest() == digest,
                    f"pacote {name} ({len(data) // 1024} KiB) integro", "recopie o arquivo (cartao/copia corrompida)")
        add(src.exists(LIN + "packs/overlays.list"), "packs/overlays.list presente")
    else:
        add(False, "packs/packs.list presente", "sem pacotes o sistema inicia so no menu de texto")
    return res


def find_default() -> Path | None:
    for pattern in ("/storage/*/X360WebTotal", "/storage/emulated/0/X360WebTotal", "/sdcard/X360WebTotal", "./X360WebTotal"):
        for hit in glob.glob(pattern):
            return Path(hit).parent
    return None


def main(argv) -> int:
    target = Path(argv[0]) if argv else find_default()
    if not target or not target.exists():
        print("Informe a pasta do pendrive ou o zip USB: python3 xwt-preflight.py <caminho>")
        return 2
    results = check(Source(target))
    print(f"== XWT Preflight: {target} ==")
    for ok, title, hint in results:
        print(("[OK]   " if ok else "[FALHA] ") + title + (f"  -> {hint}" if hint and not ok else ""))
    bad = sum(1 for r in results if not r[0])
    print("\nResultado:", "PRONTO para o XeLL" if not bad else f"{bad} problema(s) - corrija antes de ligar o Xbox")
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
