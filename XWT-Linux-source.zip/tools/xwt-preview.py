#!/usr/bin/env python3
"""Preview do desktop XWT Linux no PC ou no celular (Termux), so com Python padrao.

Le a lista de apps direto de linux/src/xwt-desktop.c, entao o preview sempre acompanha o projeto.
NAO e o Linux real: o kernel Xenon so inicia no Xbox 360. Serve para ver menus, navegacao e textos.

Uso:  python3 xwt-preview.py [caminho/do/xwt-desktop.c]       (setas/WASD, Enter abre, q sai)
      python3 xwt-preview.py --text                           (so imprime a grade)
      python3 xwt-preview.py --tests                          (roda os testes do projeto, se achar scripts/)
"""
from __future__ import annotations

import re
import subprocess
import sys
from pathlib import Path

ENTRY = re.compile(r'\{\s*"([^"]+)"\s*,\s*"([^"]+)"\s*,\s*"([^"]+)"\s*\}')
ACTIONS = {
    "Navegador": "Abre o navegador (modulo .xwpkg opcional).",
    "Wi-Fi": "Menu xwt-wifi: status, scan, connect (adaptador USB).",
    "Internet": "xwt-network check: relatorio de rede.",
    "Arquivos": "Navegador de arquivos em xwt.",
    "Sistema": "CPU, memoria e temperatura.",
    "Armazenamento": "xwt-storage menu: escolhe USB/HD/cartao.",
    "Controle": "evtest para testar o gamepad.",
    "Audio": "xwt-audio menu (audio USB).",
    "Atualizacoes": "xwt-update: listar, instalar, reverter modulos.",
    "Logs": "Logs de boot, video e kernel.",
    "Terminal": "Shell de manutencao.",
    "Energia": "Reiniciar ou desligar.",
    "Jogos": "xwt-game: Doom (PrBoom) com WAD no pendrive.",
    "Video": "xwt-video: saidas e modos.",
    "Aplicativos": "xwt-apps: musica, imagens, editor, monitor, captura, zip.",
}


def load_apps(source: Path) -> list[tuple[str, str, str]]:
    text = source.read_text(encoding="utf-8")
    block = re.search(r"apps\[APP_COUNT\]\s*=\s*\{(.*?)\};", text, re.S)
    if not block:
        raise SystemExit("lista de apps nao encontrada em " + str(source))
    apps = ENTRY.findall(block.group(1))
    count = int(re.search(r"#define APP_COUNT (\d+)", text).group(1))
    if len(apps) != count:
        raise SystemExit(f"APP_COUNT={count} mas {len(apps)} apps listados")
    return apps


def find_source(arg: str | None) -> Path:
    if arg:
        return Path(arg)
    here = Path(__file__).resolve().parent
    for base in (here, here.parent, here.parent.parent):
        for rel in ("linux/src/xwt-desktop.c", "xwt-desktop.c"):
            if (base / rel).is_file():
                return base / rel
    raise SystemExit("xwt-desktop.c nao encontrado; passe o caminho como argumento")


def grid_text(apps, cols=4, selected=0) -> str:
    lines = []
    for i in range(0, len(apps), cols):
        row = apps[i:i + cols]
        lines.append("  ".join(("[%-13s]" if i + j == selected else " %-13s ") % a[0][:13] for j, a in enumerate(row)))
    return "\n".join(lines)


def run_curses(apps) -> None:
    import curses

    def main(scr):
        curses.curs_set(0)
        sel, cols, msg = 0, 4, ""
        while True:
            scr.erase()
            h, w = scr.getmaxyx()
            cols = max(1, min(4, w // 18))
            scr.addstr(0, 1, "XWT Linux 1.0.0 - preview (nao e o Linux real)"[: w - 2])
            for i, (title, sub, _sym) in enumerate(apps):
                r, c = 2 + (i // cols) * 3, 1 + (i % cols) * 18
                if r + 1 >= h - 3:
                    break
                attr = curses.A_REVERSE if i == sel else curses.A_NORMAL
                scr.addstr(r, c, f" {title[:15]:<15}", attr)
                scr.addstr(r + 1, c, f" {sub[:15]:<15}", curses.A_DIM)
            scr.addstr(h - 2, 1, (msg or ACTIONS.get(apps[sel][0], apps[sel][1]))[: w - 2])
            scr.addstr(h - 1, 1, "setas/WASD mover | Enter abrir | q sair"[: w - 2])
            k = scr.getch()
            if k in (ord("q"), 27):
                return
            if k in (curses.KEY_RIGHT, ord("d")): sel = min(len(apps) - 1, sel + 1)
            elif k in (curses.KEY_LEFT, ord("a")): sel = max(0, sel - 1)
            elif k in (curses.KEY_DOWN, ord("s")): sel = min(len(apps) - 1, sel + cols)
            elif k in (curses.KEY_UP, ord("w")): sel = max(0, sel - cols)
            elif k in (10, 13, curses.KEY_ENTER): msg = "(preview) " + ACTIONS.get(apps[sel][0], "")
            else: msg = ""

    curses.wrapper(main)


def main(argv: list[str]) -> int:
    if "--tests" in argv:
        scripts = Path(__file__).resolve().parent.parent / "scripts"
        if not scripts.is_dir():
            print("pasta scripts/ nao encontrada (use o zip da fonte)")
            return 1
        names = sorted(p.stem for p in scripts.glob("test_*.py"))
        return subprocess.call([sys.executable, "-m", "unittest", *names], cwd=scripts)
    args = [a for a in argv if not a.startswith("--")]
    apps = load_apps(find_source(args[0] if args else None))
    if "--text" in argv or not sys.stdout.isatty():
        print(grid_text(apps))
        return 0
    run_curses(apps)
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
