import sys
from PIL import Image, ImageDraw, ImageFont
ops, w, h, out = sys.argv[1], int(sys.argv[2]), int(sys.argv[3]), sys.argv[4]
assets = sys.argv[5]
img = Image.new("RGB", (w, h), (0, 0, 0)); d = ImageDraw.Draw(img)
reg = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"
for line in open(ops):
    p = line.rstrip("\n").split(" ", 7 if line[0] == "T" else 7)
    if p[0] == "I":
        x, y = int(p[1]), int(p[2]); name = p[7]
        im = Image.open(assets + "/" + name).convert("RGB")
        if not name.startswith("wallpaper"):
            m = Image.eval(im.split()[0], lambda v: 0) ; px = im.load()
            mask = Image.new("L", im.size, 255); mp = mask.load()
            for yy in range(im.size[1]):
                for xx in range(im.size[0]):
                    if px[xx, yy] == (255, 0, 255): mp[xx, yy] = 0
            img.paste(im, (x, y), mask)
        else: img.paste(im, (x, y))
    elif p[0] == "R":
        x, y, ww, hh, r, g, b = map(int, p[1:8]); d.rectangle([x, y, x + ww - 1, y + hh - 1], fill=(r, g, b))
    else:
        x, y, size, r, g, b = map(int, p[1:7]); text = p[7]
        d.text((x, y), text, font=ImageFont.truetype(reg, size), fill=(r, g, b))
img.save(out)
