#!/usr/bin/env python3
"""Add your own boot entries to the XeLL menu of an XWT USB drive (run on a PC).

Usage:  python xwt-kboot.py E:\\          (Windows)     python3 xwt-kboot.py /media/usb
        python xwt-kboot.py E:\\ --mode menu|auto|text|safe|debug
        python xwt-kboot.py E:\\ --dry-run   (only show what would be written)

Put .elf / .elf32 files (homebrew, other kernels) or a kernel + initrd in
X360WebTotal/Boot/ (or the USB root) and run this tool. Entries appear in the XeLL
menu, selectable with the Xbox 360 controller (D-pad + A). Only the block between the
XWT-EXTRA markers in kboot.conf is rewritten; your other lines stay untouched.
"""
from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path

BEGIN = "; --- XWT-EXTRA-BEGIN (gerado por X360WebTotal/tools/xwt-kboot.py; nao edite) ---"
END = "; --- XWT-EXTRA-END ---"
MAX_ENTRY = 255           # XeLL MAX_CMDLINE_SIZE
MAX_ENTRIES = 64          # XeLL MAX_KERNELS (core entries use 4)
CMDLINE = "console=tty0 console=ttyS0,115200n8 panic=60 maxcpus=6"
KERNEL_NAMES = {"vmlinux", "vmlinuz", "zimage", "zimage.xenon", "xenon.elf"}
INITRD_SUFFIXES = (".cpio.gz", ".cpio", "initrd.gz", "initramfs.gz", ".img.gz")


def sanitize(label: str) -> str:
    cleaned = re.sub(r"[^A-Za-z0-9_-]+", "_", label).strip("_")
    return cleaned or "item"


def device_path(usb: Path, path: Path) -> str:
    return "uda:/" + path.relative_to(usb).as_posix()


def scan(usb: Path) -> list[tuple[str, str]]:
    """Return (label, value) pairs for ELF files and kernel+initrd pairs."""
    roots = [usb / "X360WebTotal" / "Boot", usb / "X360WebTotal" / "Homebrew", usb / "Homebrew"]
    entries: list[tuple[str, str]] = []
    seen: set[str] = set()
    for root in roots:
        if not root.is_dir():
            continue
        files = sorted(p for p in root.rglob("*") if p.is_file())
        initrds = [p for p in files if p.name.lower().endswith(INITRD_SUFFIXES)]
        for path in files:
            lower = path.name.lower()
            value = None
            if lower.endswith((".elf", ".elf32")) and "xwt-linux" not in lower:
                value = device_path(usb, path)
            elif lower in KERNEL_NAMES or lower.startswith(("vmlinuz-", "vmlinux-")):
                sibling = next((i for i in initrds if i.parent == path.parent), None)
                value = device_path(usb, path)
                if sibling is not None:
                    value += " initrd=" + device_path(usb, sibling)
                value += " " + CMDLINE
            if value is None:
                continue
            label = sanitize("extra_" + path.relative_to(root).with_suffix("").as_posix())
            base, n = label, 2
            while label in seen:
                label, n = f"{base}_{n}", n + 1
            seen.add(label)
            if len(value) > MAX_ENTRY:
                print(f"skipped (path too long for XeLL, {len(value)} > {MAX_ENTRY}): {path}", file=sys.stderr)
                continue
            entries.append((label, value))
    return entries[: MAX_ENTRIES - 8]


MODES = {
    "auto": ("xwt_linux_usb", 0),        # boots immediately, never reads the controller
    "menu": ("xwt_linux_usb", 20),       # XeLL menu: D-pad + A, 20 s countdown
    "text": ("xwt_linux_usb_text", 0),
    "safe": ("xwt_linux_usb_safe", 0),
    "debug": ("xwt_linux_usb_debug", 0),
}


def apply_mode(text: str, mode: str) -> str:
    label, timeout = MODES[mode]
    lines = text.replace("\r\n", "\n").split("\n")
    if f'{label}="' not in "\n".join(line for line in lines if line.startswith(label + "=")):
        raise SystemExit(f"boot entry {label!r} not found in kboot.conf")
    out, seen_default, seen_timeout = [], False, False
    for line in lines:
        if line.startswith("default="):
            out.append(f"default={label}")
            seen_default = True
        elif line.startswith("timeout="):
            out.append(f"timeout={timeout}")
            seen_timeout = True
        else:
            out.append(line)
    if not (seen_default and seen_timeout):
        raise SystemExit("kboot.conf has no default= or timeout= line")
    return "\n".join(out)


def rewrite(text: str, entries: list[tuple[str, str]]) -> str:
    lines = text.replace("\r\n", "\n").split("\n")
    if not lines or lines[0].strip() != "#KBOOTCONFIG":
        raise SystemExit("kboot.conf does not start with #KBOOTCONFIG")
    block = [BEGIN] + [f'{label}="{value}"' for label, value in entries] + [END]
    if BEGIN in lines and END in lines:
        a, b = lines.index(BEGIN), lines.index(END)
        lines[a : b + 1] = block
    else:
        lines += block
    while lines and lines[-1] == "":
        lines.pop()
    return "\n".join(lines) + "\n"


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("usb", type=Path, help="USB drive root (where kboot.conf lives)")
    ap.add_argument("--mode", choices=sorted(MODES), help="auto: boot now (default shipped); menu: XeLL menu with the controller; text/safe/debug: boot that entry now")
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()
    conf = args.usb / "kboot.conf"
    if not conf.is_file():
        raise SystemExit(f"{conf} not found: pass the USB root that contains kboot.conf")
    entries = scan(args.usb)
    updated = rewrite(conf.read_text(encoding="ascii"), entries)
    if args.mode:
        updated = apply_mode(updated, args.mode)
        print(f"mode: {args.mode} -> default={MODES[args.mode][0]} timeout={MODES[args.mode][1]}")
    print(f"{len(entries)} extra boot entr{'y' if len(entries) == 1 else 'ies'} found")
    for label, value in entries:
        print(f"  {label}: {value}")
    if args.dry_run:
        return 0
    conf.write_text(updated, encoding="ascii", newline="\n")
    print("kboot.conf updated.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
