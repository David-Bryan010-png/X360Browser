/* Records the draw calls of xwt-desktop.c so a PNG preview can be rendered on the PC. */
#define main xwt_real_main
#include "xwt-desktop.c"
#undef main
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

struct Font { int size; };
typedef struct { SDL_PixelFormat *format; int w, h; char text[300]; int size; SDL_Color color; } Glyph;
static FILE *out;

int SDL_Init(Uint32 f){(void)f;return 0;} void SDL_Quit(void){} const char*SDL_GetError(void){return "";}
SDL_Surface*SDL_SetVideoMode(int w,int h,int b,Uint32 f){(void)w;(void)h;(void)b;(void)f;return NULL;}
Uint32 SDL_MapRGB(SDL_PixelFormat*f,Uint8 r,Uint8 g,Uint8 b){(void)f;return ((Uint32)r<<16)|((Uint32)g<<8)|b;}
int SDL_FillRect(SDL_Surface*s,SDL_Rect*r,Uint32 c){(void)s;fprintf(out,"R %d %d %d %d %u %u %u\n",r->x,r->y,r->w,r->h,(c>>16)&255,(c>>8)&255,c&255);return 0;}
int SDL_BlitSurface(SDL_Surface*s,SDL_Rect*a,SDL_Surface*d,SDL_Rect*r){(void)a;(void)d;Glyph*g=(Glyph*)s;if(g->size<0){fprintf(out,"I %d %d 0 0 0 0 %s\n",r->x,r->y,g->text);return 0;}fprintf(out,"T %d %d %d %u %u %u %s\n",r->x,r->y,g->size,g->color.r,g->color.g,g->color.b,g->text);return 0;}
void SDL_FreeSurface(SDL_Surface*s){free(s);} int SDL_Flip(SDL_Surface*s){(void)s;return 0;} int SDL_PollEvent(SDL_Event*e){(void)e;return 0;}
Uint32 SDL_GetTicks(void){return 0;} void SDL_Delay(Uint32 m){(void)m;} int SDL_ShowCursor(int v){(void)v;return 0;} void SDL_EnableKeyRepeat(int a,int b){(void)a;(void)b;}
void SDL_WM_SetCaption(const char*a,const char*b){(void)a;(void)b;}
int TTF_Init(void){return 0;} void TTF_Quit(void){} void TTF_CloseFont(TTF_Font*f){(void)f;}
TTF_Font*TTF_OpenFont(const char*p,int s){(void)p;struct Font*f=malloc(sizeof *f);f->size=s;return (TTF_Font*)f;}
int TTF_SizeUTF8(TTF_Font*f,const char*t,int*w,int*h){struct Font*x=(struct Font*)f;*w=(int)(strlen(t)*x->size*0.55);*h=x->size+4;return 0;}
SDL_Surface*TTF_RenderUTF8_Blended(TTF_Font*f,const char*t,SDL_Color c){struct Font*x=(struct Font*)f;Glyph*g=calloc(1,sizeof *g);g->w=(int)(strlen(t)*x->size*0.55);g->h=x->size+4;snprintf(g->text,sizeof g->text,"%s",t);g->size=x->size;g->color=c;return (SDL_Surface*)g;}

SDL_Surface*SDL_LoadBMP(const char*path){
  const char*dir=getenv("XWT_ASSETS"); char full[600]; const char*base=strrchr(path,'/'); base=base?base+1:path;
  snprintf(full,sizeof full,"%s/%s",dir,base); FILE*f=fopen(full,"rb"); if(!f) return NULL;
  unsigned char h[26]; if(fread(h,1,26,f)!=26){fclose(f);return NULL;} fclose(f);
  Glyph*g=calloc(1,sizeof *g); g->w=h[18]|h[19]<<8|h[20]<<16; g->h=h[22]|h[23]<<8|h[24]<<16; g->size=-1; snprintf(g->text,sizeof g->text,"%s",base); return (SDL_Surface*)g;}
int SDL_SetColorKey(SDL_Surface*s,Uint32 f,Uint32 k){(void)s;(void)f;(void)k;return 0;}
SDL_Surface*SDL_DisplayFormat(SDL_Surface*s){Glyph*g=calloc(1,sizeof *g);memcpy(g,s,sizeof *g);return (SDL_Surface*)g;}

int main(int argc, char **argv)
{
    int mode = argc > 3 ? atoi(argv[3]) : 0;
    out = fopen(argv[1], "w");
    screen_w = argc > 2 ? atoi(argv[2]) : 1280;
    screen_h = screen_w == 1280 ? 720 : 480;
    fb_info_w = screen_w; fb_info_h = screen_h; fb_info_bpp = 32;
    font_regular = TTF_OpenFont("", screen_h >= 600 ? 17 : 14);
    font_bold = TTF_OpenFont("", screen_h >= 600 ? 20 : 17);
    font_big = TTF_OpenFont("", screen_h >= 600 ? 84 : 52);
    font_mid = TTF_OpenFont("", screen_h >= 600 ? 28 : 20);
    status.cpus = 6; status.mem_total_kb = 512 * 1024; status.mem_avail_kb = 301 * 1024;
    status.temp_c = -1; status.usb_mounted = 1; status.usb_free_mb = 3200; status.net_up = 1;
    snprintf(status.clock, sizeof status.clock, "14:32"); snprintf(status.kernel, sizeof status.kernel, "Linux 7.2.0-xenon");
    snprintf(status.net, sizeof status.net, "eth0 192.168.0.104"); status.uptime_s = 360;
    screen = (SDL_Surface*)calloc(1, sizeof(SDL_Surface)); screen->w = screen_w; screen->h = screen_h;
    assets_load();
    selected_app = 0;
    if (mode == 0) draw_home();
    else { settings_sel = mode - 1; draw_settings(); }
    fclose(out);
    return 0;
}
