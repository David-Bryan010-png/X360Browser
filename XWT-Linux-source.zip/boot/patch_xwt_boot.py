#!/usr/bin/env python3
"""Patch libxenon for XWT Boot: a 128 MiB initrd window instead of XeLL's fixed 32 MiB.

XWT Boot itself (boot/xwtboot) is an independent program; the only thing it needs from the library is a
bigger initrd window, so this script touches libxenon's elf.c/elf.h only:
 - initrd goes to 0x94000000 (phys 320 MiB), up to 128 MiB (RAM usable by Linux ends at 0x1E000000);
 - kernel_initrd_buffer() lets the program read the initrd file straight into place (no malloc copy).
Every replacement asserts exactly one match, so a changed upstream fails loudly.
Usage: patch_xwt_boot.py <libxenon dir>
"""
import sys
from pathlib import Path

def sub(path, old, new):
    t = path.read_text()
    if t.count(old) != 1:
        raise SystemExit(f"patch failed: {path}: expected 1 match, found {t.count(old)} for: {old[:60]!r}")
    path.write_text(t.replace(old, new, 1))

def main(lx):
    lx = Path(lx)
    elf = lx / "libxenon/drivers/elf/elf.c"
    sub(elf, "#define INITRD_RELOC_START ((void *)0x86000000)\n#define INITRD_MAX_SIZE (32 * 1024 * 1024) // 0x02000000",
        "#define INITRD_RELOC_START ((void *)0x94000000)\n#define INITRD_MAX_SIZE (128 * 1024 * 1024) // XWT Boot: 0x94000000-0x9C000000, below FB at 0x9E000000")
    sub(elf, '    printf(" ! Initrd bigger than INITRD_MAX_SIZE (32 MB), Aborting!\\n");',
        '    printf(" ! Initrd bigger than INITRD_MAX_SIZE (128 MB), Aborting!\\n");')
    sub(elf, "  if (initrd_start != NULL)\n    free(initrd_start);\n\n  initrd_start = (uint8_t *)malloc(size);",
        "  if (start == INITRD_RELOC_START) { /* XWT: file was read in place */\n    initrd_start = (uint8_t *)start;\n    initrd_size = size;\n    return 0;\n  }\n  if (initrd_start != NULL && initrd_start != (uint8_t *)INITRD_RELOC_START)\n    free(initrd_start);\n\n  initrd_start = (uint8_t *)malloc(size);")
    sub(elf, '  printf(" * Relocating initrd...\\n");\n\n  memset(INITRD_RELOC_START, 0, INITRD_MAX_SIZE);\n  memcpy(INITRD_RELOC_START, start, size);',
        '  printf(" * Relocating initrd...\\n");\n\n  if (start != INITRD_RELOC_START) {\n    memset(INITRD_RELOC_START, 0, INITRD_MAX_SIZE);\n    memcpy(INITRD_RELOC_START, start, size);\n  }')
    sub(elf, "void kernel_reset_initrd(void) {\n  if (initrd_start != NULL)\n    free(initrd_start);",
        "void *kernel_initrd_buffer(size_t size) {\n  if (size == 0 || size > INITRD_MAX_SIZE)\n    return NULL;\n  return INITRD_RELOC_START;\n}\n\nvoid kernel_reset_initrd(void) {\n  if (initrd_start != NULL && initrd_start != (uint8_t *)INITRD_RELOC_START)\n    free(initrd_start);")
    sub(lx / "libxenon/drivers/elf/elf.h", "int kernel_prepare_initrd(", "void *kernel_initrd_buffer(size_t size);\nint kernel_prepare_initrd(")
    print("XWT Boot patches applied")

if __name__ == "__main__":
    if len(sys.argv) != 2:
        raise SystemExit(__doc__)
    main(*sys.argv[1:])
