#include "profile.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static const char *const kernel_names[] = {
    "xwt-linux.elf", "zImage.xenon", "vmlinux", "vmlinux.elf", "kernel.elf", "linux.elf", NULL};
static const char *const initrd_names[] = {
    "rootfs.cpio.gz", "initramfs.cpio.gz", "initrd.cpio.gz", "initrd.img", "initrd.gz", "initrd", NULL};

#define BASE_ARGS "console=tty0 console=ttyS0,115200n8 panic=60"

void profile_defaults(XwtProfile *p)
{
    memset(p, 0, sizeof(*p));
    snprintf(p->folder, sizeof(p->folder), "uda:/X360WebTotal/Linux");
    snprintf(p->kernel, sizeof(p->kernel), "xwt-linux.elf");
    snprintf(p->initrd, sizeof(p->initrd), "rootfs.cpio.gz");
    snprintf(p->mode, sizeof(p->mode), "normal");
    p->timeout = 5;
    p->autoboot = 1;
}

static void copy_field(char *dst, size_t size, const char *src)
{
    size_t n = strlen(src);
    if (n >= size) n = size - 1;
    memcpy(dst, src, n);
    dst[n] = '\0';
}

static int valid_mode(const char *m)
{
    return !strcmp(m, "normal") || !strcmp(m, "text") || !strcmp(m, "safe") || !strcmp(m, "debug") || !strcmp(m, "custom");
}

int profile_parse(const char *text, XwtProfile *p)
{
    int keys = 0;
    const char *line = text;
    while (*line) {
        const char *end = strchr(line, '\n');
        size_t len = end ? (size_t)(end - line) : strlen(line);
        char buf[XWT_PATH_MAX + 32];
        char *eq, *key, *val;
        if (len >= sizeof(buf)) len = sizeof(buf) - 1;
        memcpy(buf, line, len);
        buf[len] = '\0';
        while (len && (buf[len - 1] == '\r' || buf[len - 1] == ' ' || buf[len - 1] == '\t')) buf[--len] = '\0';
        key = buf;
        while (*key == ' ' || *key == '\t') key++;
        eq = strchr(key, '=');
        if (*key && *key != '#' && eq) {
            *eq = '\0';
            val = eq + 1;
            if (!strcmp(key, "folder")) { copy_field(p->folder, sizeof(p->folder), val); keys++; }
            else if (!strcmp(key, "kernel")) { copy_field(p->kernel, sizeof(p->kernel), val); keys++; }
            else if (!strcmp(key, "initrd")) { copy_field(p->initrd, sizeof(p->initrd), val); keys++; }
            else if (!strcmp(key, "mode") && valid_mode(val)) { copy_field(p->mode, sizeof(p->mode), val); keys++; }
            else if (!strcmp(key, "cmdline")) { copy_field(p->cmdline, sizeof(p->cmdline), val); keys++; }
            else if (!strcmp(key, "timeout")) {
                int t = atoi(val);
                p->timeout = t < 1 ? 1 : (t > 60 ? 60 : t);
                keys++;
            } else if (!strcmp(key, "autoboot")) { p->autoboot = atoi(val) != 0; keys++; }
        }
        if (!end) break;
        line = end + 1;
    }
    return keys;
}

int profile_format(const XwtProfile *p, char *out, size_t out_size)
{
    int n = snprintf(out, out_size,
        "# XWT Boot - saved boot instructions (edited by the boot menu; you can edit it on the PC too)\n"
        "folder=%s\nkernel=%s\ninitrd=%s\nmode=%s\ncmdline=%s\ntimeout=%d\nautoboot=%d\n",
        p->folder, p->kernel, p->initrd, p->mode, p->cmdline, p->timeout, p->autoboot ? 1 : 0);
    return (n < 0 || (size_t)n >= out_size) ? -1 : n;
}

int profile_join(const char *folder, const char *name, char *out, size_t out_size)
{
    size_t fl = strlen(folder);
    int n;
    while (fl > 0 && folder[fl - 1] == '/') fl--;
    while (*name == '/') name++;
    n = snprintf(out, out_size, "%.*s/%s", (int)fl, folder, name);
    return (n < 0 || (size_t)n >= out_size) ? -1 : 0;
}

int profile_detect(XwtProfile *p, XwtExistsFn exists, void *ctx)
{
    char path[XWT_PATH_MAX * 2];
    int i, found = 0;
    for (i = 0; kernel_names[i]; ++i) {
        if (profile_join(p->folder, kernel_names[i], path, sizeof(path)) == 0 && exists(path, ctx)) {
            copy_field(p->kernel, sizeof(p->kernel), kernel_names[i]);
            found = 1;
            break;
        }
    }
    p->initrd[0] = '\0';
    for (i = 0; initrd_names[i]; ++i) {
        if (profile_join(p->folder, initrd_names[i], path, sizeof(path)) == 0 && exists(path, ctx)) {
            copy_field(p->initrd, sizeof(p->initrd), initrd_names[i]);
            break;
        }
    }
    return found;
}

int profile_cmdline(const XwtProfile *p, char *out, size_t out_size)
{
    const char *line;
    int n;
    if (!strcmp(p->mode, "custom") && p->cmdline[0]) line = p->cmdline;
    else if (!strcmp(p->mode, "text")) line = BASE_ARGS " maxcpus=6 xwt.text=1";
    else if (!strcmp(p->mode, "safe")) line = BASE_ARGS " maxcpus=1 xwt.text=1 xwt.safe=1";
    else if (!strcmp(p->mode, "debug")) line = "console=tty0 console=ttyS0,115200n8 panic=0 maxcpus=1 ignore_loglevel initcall_debug xwt.text=1 xwt.safe=1 xwt.debug=1";
    else line = BASE_ARGS " maxcpus=6";
    n = snprintf(out, out_size, "%s", line);
    return (n < 0 || (size_t)n >= out_size || n > XWT_CMDLINE_MAX) ? -1 : 0;
}

void profile_next_mode(XwtProfile *p)
{
    static const char *const order[] = {"normal", "text", "safe", "debug"};
    size_t i;
    for (i = 0; i < 4; ++i) {
        if (!strcmp(p->mode, order[i])) { copy_field(p->mode, sizeof(p->mode), order[(i + 1) % 4]); return; }
    }
    copy_field(p->mode, sizeof(p->mode), "normal");
}

/* One level up. */
int profile_parent(char *path)
{
    size_t len = strlen(path);
    char *slash;
    while (len > 0 && path[len - 1] == '/' && !(len >= 2 && path[len - 2] == ':')) path[--len] = '\0';
    if (len >= 2 && path[len - 1] == '/' && path[len - 2] == ':') return 1;   /* "dev:/" */
    slash = strrchr(path, '/');
    if (!slash) return 1;
    *slash = '\0';
    if (slash > path && slash[-1] == ':') { slash[0] = '/'; slash[1] = '\0'; }  /* back to "dev:/" */
    return 0;
}

