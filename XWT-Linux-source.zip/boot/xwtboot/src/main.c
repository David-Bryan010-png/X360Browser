/*
 * XWT Boot Manager 2.0.0 - Independent graphical boot manager for Xbox 360 (RGH/JTAG)
 *
 * Flow: XeLL -> XWT Boot Manager -> Graphical Menu -> Linux
 * XeLL does NOT control the menu. This is a standalone ELF32 PowerPC program.
 *
 * Built on libxenon. Licence: GPL-2.0-or-later
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <dirent.h>
#include <stdarg.h>

#include <console/console.h>
#include <debug.h>
#include <diskio/ata.h>
#include <elf/elf.h>
#include <input/input.h>
#include <ppc/register.h>
#include <ppc/timebase.h>
#include <sys/iosupport.h>
#include <time/time.h>
#include <usb/usbmain.h>
#include <xb360/xb360.h>
#include <xenon_nand/xenon_sfcx.h>
#include <xenon_smc/xenon_smc.h>
#include <xenon_soc/xenon_io.h>
#include <xenon_soc/xenon_power.h>
#include <xenon_uart/xenon_uart.h>
#include <xenos/xenos.h>

#include "xwt_boot.h"

/* Global state */
xwt_boot_state_t g_state;
theme_t g_theme;

/* External device tree blob */
extern char dt_blob_start[];
extern char dt_blob_end[];

/* Forward declarations */
static void reset_timebase_task(void);
static void synchronize_timebases(void);
static int hardware_init_internal(void);
static void hardware_shutdown_internal(void);
static void load_config(void);
static int save_config(void);
static int choose_profile_menu(void);
static int main_menu(void);
static int settings_menu(void);
static int diagnostics_menu(void);
static int recovery_menu(void);
static void show_info_screen(void);
static void auto_boot_check(void);
static void draw_boot_splash(void);

/* ============================================================================
 * Hardware Initialization (libxenon standard sequence)
 * ============================================================================ */

static void reset_timebase_task(void)
{
    mtspr(284, 0);
    mtspr(285, 0);
    mtspr(284, 0);
}

static void synchronize_timebases(void)
{
    int i;
    xenon_thread_startup();
    std((void *)0x200611a0, 0);
    for (i = 1; i < 6; ++i) {
        xenon_run_thread_task(i, (void *)0x200611a0, (void *)reset_timebase_task);
        while (xenon_is_thread_task_running(i)) { }
    }
    reset_timebase_task();
    std((void *)0x200611a0, 0x1ff);
}

int hardware_init(void)
{
    /* Synchronize timebases - critical for Linux */
    synchronize_timebases();

    /* SMC pre-init */
    *(volatile uint32_t *)0xea00106c = 0x1000000;
    *(volatile uint32_t *)0xea001064 = 0x10;
    *(volatile uint32_t *)0xea00105c = 0xc000000;

    xenon_smc_set_led(0, 0);
    xenon_smc_start_bootanim();

    /* Initialize console for debug output */
    setbuf(stdout, NULL);

    /* Initialize Xenos video - auto-detect mode */
    xenos_init(VIDEO_MODE_AUTO);

    /* Get framebuffer info */
    struct xenos_edid edid;
    if (xenos_get_edid(&edid) == 0) {
        g_state.screen_width = edid.width;
        g_state.screen_height = edid.height;
    } else {
        g_state.screen_width = 1280;
        g_state.screen_height = 720;
    }
    g_state.framebuffer_bpp = 32;
    g_state.framebuffer = xenos_get_framebuffer();

    /* Initialize console on top of framebuffer */
    console_init();
    console_set_colors(CONSOLE_COLOR_BLUE, CONSOLE_COLOR_WHITE);

    /* Full CPU speed */
    xenon_make_it_faster(XENON_SPEED_FULL);

    /* SFCX init for controller (Corona/Phison) */
    if (xenon_get_console_type() != REV_CORONA_PHISON) {
        sfcx_init();
    }

    /* USB initialization */
    usb_init();
    usb_do_poll();

    /* ATA/ATAPI - required to prevent interrupt storm in Linux */
    xenon_ata_init();
    xenon_atapi_init();

    /* Mount all devices */
    mount_all_devices();
    g_state.usb_mounted = true;

    /* Initialize input */
    input_init();

    /* Initialize theme */
    theme_init_default();

    g_state.hardware_initialized = true;

    /* Draw initial splash */
    draw_boot_splash();

    return 0;
}

void hardware_shutdown(void)
{
    if (g_state.hardware_initialized) {
        unmount_all_devices();
        xenon_smc_set_led(0, 0);
        g_state.hardware_initialized = false;
    }
}

/* ============================================================================
 * Framebuffer Drawing (Xenos direct)
 * ============================================================================ */

void draw_pixel(int x, int y, uint32_t color)
{
    if (!g_state.framebuffer) return;
    if (x < 0 || x >= g_state.screen_width || y < 0 || y >= g_state.screen_height) return;

    uint32_t *fb = (uint32_t *)g_state.framebuffer;
    fb[y * g_state.screen_width + x] = color;
}

void draw_rect(int x, int y, int w, int h, uint32_t color)
{
    if (!g_state.framebuffer) return;
    if (w <= 0 || h <= 0) return;

    uint32_t *fb = (uint32_t *)g_state.framebuffer;
    int stride = g_state.screen_width;

    for (int row = 0; row < h; row++) {
        int yy = y + row;
        if (yy < 0 || yy >= g_state.screen_height) continue;
        uint32_t *line = fb + yy * stride + x;
        int ww = w;
        if (x + ww > g_state.screen_width) ww = g_state.screen_width - x;
        if (ww <= 0) continue;
        for (int i = 0; i < ww; i++) {
            line[i] = color;
        }
    }
}

void draw_image(int x, int y, const uint8_t *data, int w, int h, int stride)
{
    if (!g_state.framebuffer || !data) return;

    uint32_t *fb = (uint32_t *)g_state.framebuffer;
    int fb_stride = g_state.screen_width;

    for (int row = 0; row < h; row++) {
        int yy = y + row;
        if (yy < 0 || yy >= g_state.screen_height) continue;
        uint32_t *dst = fb + yy * fb_stride + x;
        const uint32_t *src = (const uint32_t *)(data + row * stride);
        int ww = w;
        if (x + ww > g_state.screen_width) ww = g_state.screen_width - x;
        if (ww <= 0) continue;
        for (int i = 0; i < ww; i++) {
            uint32_t pixel = src[i];
            /* Alpha blending - simple premultiplied */
            uint8_t a = (pixel >> 24) & 0xFF;
            if (a == 255) {
                dst[i] = pixel;
            } else if (a > 0) {
                uint32_t bg = dst[i];
                uint32_t r = ((pixel & 0xFF0000) * a + (bg & 0xFF0000) * (255 - a)) >> 8 & 0xFF0000;
                uint32_t g = ((pixel & 0x00FF00) * a + (bg & 0x00FF00) * (255 - a)) >> 8 & 0x00FF00;
                uint32_t b = ((pixel & 0x0000FF) * a + (bg & 0x0000FF) * (255 - a)) >> 8 & 0x0000FF;
                dst[i] = 0xFF000000 | r | g | b;
            }
        }
    }
}

void clear_screen(uint32_t color)
{
    draw_rect(0, 0, g_state.screen_width, g_state.screen_height, color);
}

void present_framebuffer(void)
{
    /* Xenos framebuffer is directly scanned out - no flip needed */
    /* But we can add a memory barrier for safety */
    asm volatile("sync" ::: "memory");
}

/* ============================================================================
 * Theme/UI Drawing
 * ============================================================================ */

void theme_init_default(void)
{
    g_theme.bg_color = 0xFF0A141E;      /* Dark blue-black */
    g_theme.fg_color = 0xFFFFFFFF;      /* White */
    g_theme.accent_color = 0xFF1A56AA;  /* XWT Blue */
    g_theme.selection_color = 0xFF184070; /* Darker blue */
    g_theme.border_color = 0xFF445346;  /* Muted green-gray */
    g_theme.warning_color = 0xFFE8A317; /* Amber */
    g_theme.panel_color = 0xFF1D241F;   /* Dark panel */
    g_theme.panel2_color = 0xFF262F28;  /* Lighter panel */
    g_theme.text_color = 0xFFF5F7F4;    /* Off-white */
    g_theme.muted_color = 0xFFAEB7AE;   /* Muted green-gray */
}

void theme_draw_header(const char *title, const char *version)
{
    int h = 70;
    /* Gradient background */
    for (int y = 0; y < h; y++) {
        uint8_t r = 26 - (y * 14) / h;
        uint8_t g = 86 - (y * 40) / h;
        uint8_t b = 170 - (y * 70) / h;
        draw_rect(0, y, g_state.screen_width, 1, (0xFF << 24) | (r << 16) | (g << 8) | b);
    }
    draw_rect(0, h - 2, g_state.screen_width, 2, g_theme.accent_color);

    /* Title text - using console for now */
    console_clrscr();
    printf("\n\n");
    printf("  ==============================================================\n");
    printf("  %s %s  -  Gerenciador de Boot Grafico\n", XWT_BOOT_NAME, version);
    printf("  ==============================================================\n\n");
    printf("  %s\n\n", title);
}

void theme_draw_footer(const char *hint)
{
    int y = g_state.screen_height - 50;
    draw_rect(0, y, g_state.screen_width, 50, g_theme.panel2_color);
    draw_rect(0, y, g_state.screen_width, 1, g_theme.accent_color);
    console_clrscr();
    /* Footer will be drawn by menu system */
}

void theme_draw_sidebar(int x, int y, int w, int h)
{
    draw_rect(x, y, w, h, g_theme.panel_color);
    draw_rect(x + w - 1, y, 1, h, g_theme.border_color);
}

void theme_draw_button(int x, int y, int w, int h, const char *label, bool selected)
{
    uint32_t bg = selected ? g_theme.selection_color : g_theme.panel_color;
    uint32_t border = selected ? g_theme.accent_color : g_theme.border_color;

    draw_rect(x, y, w, h, bg);
    draw_rect(x, y, w, 1, border);
    draw_rect(x, y + h - 1, w, 1, border);
    draw_rect(x, y, 1, h, border);
    draw_rect(x + w - 1, y, 1, h, border);

    if (label) {
        /* Text drawn via console for now */
    }
}

void theme_draw_progress(int x, int y, int w, int h, int percent)
{
    if (percent < 0) percent = 0;
    if (percent > 100) percent = 100;

    draw_rect(x, y, w, h, 0xFF111613);
    draw_rect(x, y, w, 1, g_theme.border_color);
    draw_rect(x, y + h - 1, w, 1, g_theme.border_color);
    draw_rect(x, y, 1, h, g_theme.border_color);
    draw_rect(x + w - 1, y, 1, h, g_theme.border_color);

    int inner_w = ((w - 4) * percent) / 100;
    draw_rect(x + 2, y + 2, inner_w, h - 4, g_theme.accent_color);
}

void theme_draw_icon(int x, int y, int type, bool selected)
{
    uint32_t colors[] = {
        g_theme.accent_color,    /* Web/Globe */
        0xFFC48016,              /* Folder */
        g_theme.warning_color,   /* Game */
        g_theme.text_color,      /* Terminal */
        0xFF465268,              /* Gear/Settings */
        0xFF0E8A94,              /* Help */
        0xFFB02626,              /* Power */
        0xFF6046B0,              /* Apps */
    };
    uint32_t color = colors[type % 8];
    if (selected) {
        draw_rect(x - 4, y - 4, 72, 72, g_theme.selection_color);
        draw_rect(x - 3, y - 3, 70, 70, g_theme.accent_color);
    }
    draw_rect(x, y, 64, 64, color);
}

/* ============================================================================
 * Boot Splash Screen
 * ============================================================================ */

static void draw_boot_splash(void)
{
    clear_screen(g_theme.bg_color);

    /* Centered XWT logo area */
    int cx = g_state.screen_width / 2;
    int cy = g_state.screen_height / 2 - 50;

    /* Draw logo placeholder (rounded rect) */
    draw_rect(cx - 80, cy - 80, 160, 160, g_theme.accent_color);
    draw_rect(cx - 76, cy - 76, 152, 152, g_theme.bg_color);
    draw_rect(cx - 72, cy - 72, 144, 144, g_theme.accent_color);

    /* Version text */
    console_clrscr();
    for (int i = 0; i < 12; i++) printf("\n");
    printf("                    %s %s\n", XWT_BOOT_NAME, XWT_BOOT_VERSION);
    printf("                    Xbox 360 Independent Boot Manager\n\n");
    printf("                    Inicializando hardware...\n");
    printf("                    Carregando perfis de boot...\n\n");
    printf("                    [A] Continuar  [B] Menu de Recuperacao\n");

    present_framebuffer();

    /* Wait a moment for user to see splash */
    udelay(1500000);
}

/* ============================================================================
 * Input Handling
 * ============================================================================ */

void input_init(void)
{
    /* USB already initialized in hardware_init */
    usb_do_poll();
}

input_key_t input_poll(void)
{
    static struct controller_data_s old = {0};
    struct controller_data_s now = {0};

    usb_do_poll();

    /* Check keyboard (serial/USB) */
    if (kbhit()) {
        int ch = getch();
        if (ch == 0x0D) return INPUT_OK;      /* Enter */
        if (ch == 0x1B) return INPUT_BACK;    /* Escape */
        if (ch == 0x41) return INPUT_UP;      /* Up arrow */
        if (ch == 0x42) return INPUT_DOWN;    /* Down arrow */
        if (ch == 0x43) return INPUT_RIGHT;   /* Right arrow */
        if (ch == 0x44) return INPUT_LEFT;    /* Left arrow */
        if (ch == 'q' || ch == 'Q') return INPUT_QUIT;
    }

    /* Check Xbox 360 controller (port 0) */
    if (get_controller_data(&now, 0)) {
        if (now.a > old.a || now.start > old.start) { old = now; return INPUT_OK; }
        if (now.b > old.b || now.back > old.back) { old = now; return INPUT_BACK; }
        if (now.up > old.up) { old = now; return INPUT_UP; }
        if (now.down > old.down) { old = now; return INPUT_DOWN; }
        if (now.left > old.left) { old = now; return INPUT_LEFT; }
        if (now.right > old.right) { old = now; return INPUT_RIGHT; }
        if (now.y > old.y) { old = now; return INPUT_QUIT; }
        old = now;
    }

    return INPUT_NONE;
}

void input_wait_any(void)
{
    while (input_poll() == INPUT_NONE) {
        udelay(10000);
    }
}

/* ============================================================================
 * Profile Management
 * ============================================================================ */

void profile_defaults(xwt_profile_t *p)
{
    memset(p, 0, sizeof(*p));
    snprintf(p->name, sizeof(p->name), "Padrao");
    snprintf(p->folder, sizeof(p->folder), "uda:/X360WebTotal/Linux");
    snprintf(p->kernel, sizeof(p->kernel), "xwt-linux.elf");
    snprintf(p->initrd, sizeof(p->initrd), "rootfs.cpio.gz");
    p->mode = BOOT_MODE_NORMAL;
    p->timeout = 5;
    p->autoboot = true;
    p->valid = false;
}

static int profile_join(const char *folder, const char *name, char *out, size_t out_size)
{
    size_t fl = strlen(folder);
    while (fl > 0 && folder[fl - 1] == '/') fl--;
    while (*name == '/') name++;
    int n = snprintf(out, out_size, "%.*s/%s", (int)fl, folder, name);
    return (n < 0 || (size_t)n >= out_size) ? -1 : 0;
}

static bool file_exists(const char *path)
{
    struct stat st;
    return stat(path, &st) == 0 && !S_ISDIR(st.st_mode) && st.st_size > 0;
}

int profile_detect_kernel(xwt_profile_t *p)
{
    static const char *kernel_names[] = {
        "xwt-linux.elf", "zImage.xenon", "vmlinux", "vmlinux.elf",
        "kernel.elf", "linux.elf", NULL
    };
    static const char *initrd_names[] = {
        "rootfs.cpio.gz", "initramfs.cpio.gz", "initrd.cpio.gz",
        "initrd.img", "initrd.gz", "initrd", NULL
    };

    char path[XWT_PATH_MAX * 2];
    int i;

    for (i = 0; kernel_names[i]; ++i) {
        if (profile_join(p->folder, kernel_names[i], path, sizeof(path)) == 0 && file_exists(path)) {
            snprintf(p->kernel, sizeof(p->kernel), "%s", kernel_names[i]);
            break;
        }
    }
    if (!kernel_names[i]) return -1;

    p->initrd[0] = '\0';
    for (i = 0; initrd_names[i]; ++i) {
        if (profile_join(p->folder, initrd_names[i], path, sizeof(path)) == 0 && file_exists(path)) {
            snprintf(p->initrd, sizeof(p->initrd), "%s", initrd_names[i]);
            break;
        }
    }

    p->valid = true;
    return 0;
}

int profile_validate(const xwt_profile_t *p)
{
    char path[XWT_PATH_MAX * 2];
    if (profile_join(p->folder, p->kernel, path, sizeof(path)) != 0 || !file_exists(path)) {
        return -1;
    }
    if (p->initrd[0] && profile_join(p->folder, p->initrd, path, sizeof(path)) != 0) {
        return -2;
    }
    return 0;
}

const char *boot_mode_name(boot_mode_t mode)
{
    static const char *names[] = {
        "Normal", "Texto", "Seguro", "Debug", "Personalizado", "Recuperacao"
    };
    if (mode >= 0 && mode < BOOT_MODE_COUNT) return names[mode];
    return "Desconhecido";
}

int profile_build_cmdline(const xwt_profile_t *p, char *out, size_t out_size)
{
    const char *base = "console=tty0 console=ttyS0,115200n8 panic=60";

    if (p->mode == BOOT_MODE_CUSTOM && p->custom_cmdline[0]) {
        return snprintf(out, out_size, "%s", p->custom_cmdline) < (int)out_size ? 0 : -1;
    }

    const char *mode_args;
    switch (p->mode) {
        case BOOT_MODE_TEXT:   mode_args = "maxcpus=6 xwt.text=1"; break;
        case BOOT_MODE_SAFE:   mode_args = "maxcpus=1 xwt.text=1 xwt.safe=1"; break;
        case BOOT_MODE_DEBUG:  mode_args = "maxcpus=1 panic=0 ignore_loglevel initcall_debug xwt.text=1 xwt.safe=1 xwt.debug=1"; break;
        case BOOT_MODE_RECOVERY: mode_args = "maxcpus=1 xwt.text=1 xwt.safe=1 xwt.recovery=1"; break;
        default:               mode_args = "maxcpus=6"; break;
    }

    return snprintf(out, out_size, "%s %s", base, mode_args) < (int)out_size ? 0 : -1;
}

/* ============================================================================
 * Config File Load/Save
 * ============================================================================ */

static void load_config(void)
{
    char roots[16][256];
    char text[4096];
    int n = list_roots(roots, 16);

    g_state.profile_count = 0;
    g_state.active_profile = 0;
    g_state.config_path[0] = '\0';

    for (int i = 0; i < n; ++i) {
        char path[XWT_PATH_MAX * 2];
        FILE *f;
        size_t got;

        if (profile_join(roots[i], CONFIG_FILE, path, sizeof(path)) != 0) continue;
        f = fopen(path, "r");
        if (!f) continue;

        got = fread(text, 1, sizeof(text) - 1, f);
        fclose(f);
        text[got] = '\0';

        /* Parse config - simple key=value format */
        xwt_profile_t profile;
        profile_defaults(&profile);

        char *line = text;
        while (*line) {
            char *end = strchr(line, '\n');
            size_t len = end ? (size_t)(end - line) : strlen(line);
            char buf[512];
            if (len >= sizeof(buf)) len = sizeof(buf) - 1;
            memcpy(buf, line, len);
            buf[len] = '\0';

            char *eq = strchr(buf, '=');
            if (eq && buf[0] != '#') {
                *eq = '\0';
                char *key = buf;
                char *val = eq + 1;

                if (!strcmp(key, "profile_name")) snprintf(profile.name, sizeof(profile.name), "%s", val);
                else if (!strcmp(key, "folder")) snprintf(profile.folder, sizeof(profile.folder), "%s", val);
                else if (!strcmp(key, "kernel")) snprintf(profile.kernel, sizeof(profile.kernel), "%s", val);
                else if (!strcmp(key, "initrd")) snprintf(profile.initrd, sizeof(profile.initrd), "%s", val);
                else if (!strcmp(key, "mode")) profile.mode = atoi(val);
                else if (!strcmp(key, "custom_cmdline")) snprintf(profile.custom_cmdline, sizeof(profile.custom_cmdline), "%s", val);
                else if (!strcmp(key, "timeout")) profile.timeout = atoi(val);
                else if (!strcmp(key, "autoboot")) profile.autoboot = atoi(val) != 0;
            }

            if (!end) break;
            line = end + 1;
        }

        profile_detect_kernel(&profile);

        if (g_state.profile_count < MAX_PROFILES) {
            g_state.profiles[g_state.profile_count++] = profile;
            snprintf(g_state.config_path, sizeof(g_state.config_path), "%s", path);
        }
    }

    /* If no config found, create default */
    if (g_state.profile_count == 0) {
        profile_defaults(&g_state.profiles[0]);
        profile_detect_kernel(&g_state.profiles[0]);
        g_state.profile_count = 1;
    }
}

static int save_config(void)
{
    if (!g_state.config_path[0]) {
        char roots[16][256];
        int n = list_roots(roots, 16);
        for (int i = 0; i < n; ++i) {
            char dir[XWT_PATH_MAX * 2];
            if (profile_join(roots[i], CONFIG_DIR, dir, sizeof(dir)) == 0) mkdir(dir, 0777);
            if (profile_join(roots[i], CONFIG_FILE, g_state.config_path, sizeof(g_state.config_path)) != 0) continue;
            break;
        }
    }

    if (!g_state.config_path[0]) return -1;

    FILE *f = fopen(g_state.config_path, "w");
    if (!f) return -1;

    xwt_profile_t *p = &g_state.profiles[g_state.active_profile];
    fprintf(f,
        "# XWT Boot Manager - saved profile\n"
        "profile_name=%s\n"
        "folder=%s\n"
        "kernel=%s\n"
        "initrd=%s\n"
        "mode=%d\n"
        "custom_cmdline=%s\n"
        "timeout=%d\n"
        "autoboot=%d\n",
        p->name, p->folder, p->kernel, p->initrd, p->mode, p->custom_cmdline, p->timeout, p->autoboot ? 1 : 0);

    fclose(f);
    return 0;
}

/* ============================================================================
 * Menu System
 * ============================================================================ */

menu_result_t menu_show(menu_t *menu)
{
    uint64_t start = mftb();
    int last_countdown = -1;

    while (1) {
        int countdown = -1;
        if (menu->timeout_sec > 0 && menu->show_countdown) {
            int elapsed = (int)tb_diff_sec(mftb(), start);
            countdown = menu->timeout_sec - elapsed;
            if (countdown <= 0) return MENU_RESULT_TIMEOUT;
        }

        if (countdown != last_countdown) {
            last_countdown = countdown;
            menu_draw(menu, countdown);
        }

        input_key_t k = input_poll();
        if (k != INPUT_NONE && menu->timeout_sec > 0 && menu->show_countdown) {
            menu->timeout_sec = 0;
            last_countdown = -1;
        }

        switch (k) {
            case INPUT_UP:
                if (menu->selected > 0) menu->selected--;
                break;
            case INPUT_DOWN:
                if (menu->selected < menu->item_count - 1) menu->selected++;
                break;
            case INPUT_OK:
                return menu->selected;
            case INPUT_BACK:
                return MENU_RESULT_BACK;
            case INPUT_QUIT:
                return MENU_RESULT_ERROR;
            default:
                break;
        }

        udelay(10000);
    }
}

void menu_draw(const menu_t *menu, int countdown)
{
    console_clrscr();

    printf("==============================================================\n");
    printf("  %s %s\n", XWT_BOOT_NAME, XWT_BOOT_VERSION);
    printf("==============================================================\n\n");

    if (menu->title) {
        printf("  %s\n\n", menu->title);
    }

    for (int i = 0; i < menu->item_count; ++i) {
        printf("  %s %s\n", i == menu->selected ? "> " : "  ", menu->items[i]);
    }

    printf("\n  %s\n", menu->hint ? menu->hint : "Cima/Baixo navega  A seleciona  B volta");

    if (countdown >= 0) {
        printf("\n  Iniciando em %d s... (qualquer botao cancela)\n", countdown);
    }
}

/* ============================================================================
 * Main Menu
 * ============================================================================ */

static int main_menu(void)
{
    char items[MAX_MENU_ITEMS][256];
    xwt_profile_t *p = &g_state.profiles[g_state.active_profile];

    while (1) {
        int n = 0;
        snprintf(items[n++], sizeof(items[0]), "Iniciar: %s (%s)", p->name, boot_mode_name(p->mode));
        snprintf(items[n++], sizeof(items[0]), "Escolher Perfil de Boot");
        snprintf(items[n++], sizeof(items[0]), "Configuracoes");
        snprintf(items[n++], sizeof(items[0]), "Diagnosticos de Hardware");
        snprintf(items[n++], sizeof(items[0]), "Modo de Recuperacao");
        snprintf(items[n++], sizeof(items[0]), "Informacoes do Sistema");
        snprintf(items[n++], sizeof(items[0]), "Reiniciar Console");
        snprintf(items[n++], sizeof(items[0]), "Desligar Console");

        menu_t menu = {
            .title = "Menu Principal",
            .hint = "Cima/Baixo move  A seleciona  B sai",
            .item_count = n,
            .selected = 0,
            .timeout_sec = p->autoboot ? p->timeout : 0,
            .show_countdown = p->autoboot
        };
        memcpy(menu.items, items, sizeof(items));

        menu_result_t result = menu_show(&menu);

        if (result == MENU_RESULT_TIMEOUT) result = 0;
        if (result < 0) continue;

        switch (result) {
            case 0: /* Boot selected profile */
                if (profile_validate(p) == 0) {
                    return 0; /* Signal to boot */
                }
                /* Show error and continue */
                console_clrscr();
                printf("Erro: Kernel/initrd nao encontrados no perfil '%s'\n", p->name);
                printf("Pressione qualquer tecla...\n");
                input_wait_any();
                break;
            case 1: /* Choose profile */
                choose_profile_menu();
                p = &g_state.profiles[g_state.active_profile];
                break;
            case 2: /* Settings */
                settings_menu();
                break;
            case 3: /* Diagnostics */
                diagnostics_menu();
                break;
            case 4: /* Recovery */
                recovery_menu();
                break;
            case 5: /* Info */
                show_info_screen();
                break;
            case 6: /* Reboot */
                xenon_smc_power_reboot();
                for (;;) { }
            case 7: /* Shutdown */
                xenon_smc_power_shutdown();
                for (;;) { }
        }
    }
    return 0;
}

/* ============================================================================
 * Profile Selection Menu
 * ============================================================================ */

static int choose_profile_menu(void)
{
    char items[MAX_MENU_ITEMS][256];
    char current[XWT_PATH_MAX] = "";
    bool at_roots = true;

    while (1) {
        int n = 0;
        char title[256];

        if (at_roots) {
            n = list_roots(items, MAX_MENU_ITEMS);
            snprintf(title, sizeof(title), "Escolha o dispositivo (B volta)");
            if (n == 0) {
                console_clrscr();
                printf("Nenhum dispositivo montado.\nConecte o pendrive/HD e tente de novo.\n");
                input_wait_any();
                return -1;
            }
        } else {
            xwt_profile_t probe = g_state.profiles[g_state.active_profile];
            snprintf(probe.folder, sizeof(probe.folder), "%s", current);
            int found = profile_detect_kernel(&probe);
            snprintf(title, sizeof(title), "Pasta: %s%s", current, found ? "  [Linux detectado]" : "");

            snprintf(items[n++], sizeof(items[0]), "[ Usar esta pasta ]");
            snprintf(items[n++], sizeof(items[0]), "[ .. Subir ]");
            int dirs = list_dirs(current, items + n, MAX_MENU_ITEMS - n);
            n += dirs;
        }

        menu_t menu = {
            .title = title,
            .hint = "A abre/seleciona  B volta",
            .item_count = n,
            .selected = 0,
            .timeout_sec = 0
        };
        memcpy(menu.items, items, sizeof(items));

        menu_result_t result = menu_show(&menu);
        if (result == MENU_RESULT_BACK || result < 0) {
            if (at_roots) return 0;
            if (current[0]) {
                char *slash = strrchr(current, '/');
                if (slash == current) current[1] = '\0';
                else if (slash) *slash = '\0';
                else at_roots = true;
            } else {
                at_roots = true;
            }
            continue;
        }

        if (at_roots) {
            snprintf(current, sizeof(current), "%s", items[result]);
            at_roots = false;
            continue;
        }

        if (result == 0) { /* Use this folder */
            xwt_profile_t probe = g_state.profiles[g_state.active_profile];
            snprintf(probe.folder, sizeof(probe.folder), "%s", current);
            if (profile_detect_kernel(&probe) == 0) {
                g_state.profiles[g_state.active_profile] = probe;
                save_config();
                console_clrscr();
                printf("Pasta do Linux salva: %s\n", current);
                printf("Kernel: %s\nInitrd: %s\n", probe.kernel, probe.initrd[0] ? probe.initrd : "(nenhum)");
                printf("\nPressione qualquer tecla...\n");
                input_wait_any();
            } else {
                console_clrscr();
                printf("Nao achei kernel nessa pasta.\nNomes validos: xwt-linux.elf, zImage.xenon, vmlinux...\n");
                printf("\nPressione qualquer tecla...\n");
                input_wait_any();
            }
            return 0;
        }

        if (result == 1) { /* Go up */
            if (current[0]) {
                char *slash = strrchr(current, '/');
                if (slash == current) current[1] = '\0';
                else if (slash) *slash = '\0';
                else at_roots = true;
            } else {
                at_roots = true;
            }
            continue;
        }

        /* Enter subdirectory */
        char next[XWT_PATH_MAX * 2];
        if (profile_join(current, items[result], next, sizeof(next)) == 0 && strlen(next) < sizeof(current)) {
            snprintf(current, sizeof(current), "%s", next);
        }
    }
}

/* ============================================================================
 * Settings Menu
 * ============================================================================ */

static int settings_menu(void)
{
    char items[MAX_MENU_ITEMS][256];
    xwt_profile_t *p = &g_state.profiles[g_state.active_profile];

    while (1) {
        int n = 0;
        snprintf(items[n++], sizeof(items[0]), "Modo de Boot: %s  (A altera)", boot_mode_name(p->mode));
        snprintf(items[n++], sizeof(items[0]), "Timeout: %d s  (A aumenta)", p->timeout);
        snprintf(items[n++], sizeof(items[0]), "Boot Automatico: %s  (A alterna)", p->autoboot ? "Sim" : "Nao");
        snprintf(items[n++], sizeof(items[0]), "Linha de Comando Personalizada");
        snprintf(items[n++], sizeof(items[0]), "Renomear Perfil: %s", p->name);
        snprintf(items[n++], sizeof(items[0]), "Salvar Configuracao");
        snprintf(items[n++], sizeof(items[0]), "Voltar");

        menu_t menu = {
            .title = "Configuracoes",
            .hint = "Cima/Baixo move  A edita  B volta",
            .item_count = n,
            .selected = 0,
            .timeout_sec = 0
        };
        memcpy(menu.items, items, sizeof(items));

        menu_result_t result = menu_show(&menu);
        if (result == MENU_RESULT_BACK || result < 0 || result == 6) return 0;

        switch (result) {
            case 0: /* Boot mode */
                p->mode = (p->mode + 1) % BOOT_MODE_COUNT;
                save_config();
                break;
            case 1: /* Timeout */
                if (p->timeout >= 30) p->timeout = 1;
                else if (p->timeout < 10) p->timeout++;
                else p->timeout += 5;
                save_config();
                break;
            case 2: /* Autoboot */
                p->autoboot = !p->autoboot;
                save_config();
                break;
            case 3: /* Custom cmdline - simple editor */
                console_clrscr();
                printf("Linha de comando personalizada (max %d chars):\n", XWT_CMDLINE_MAX - 1);
                printf("Atual: %s\n\n", p->custom_cmdline[0] ? p->custom_cmdline : "(vazio)");
                printf("Nova: ");
                /* Simple input - in real impl, use a proper line editor */
                if (fgets(p->custom_cmdline, sizeof(p->custom_cmdline), stdin)) {
                    p->custom_cmdline[strcspn(p->custom_cmdline, "\n")] = '\0';
                    p->mode = BOOT_MODE_CUSTOM;
                    save_config();
                }
                break;
            case 4: /* Rename profile */
                console_clrscr();
                printf("Nome do perfil (atual: %s):\n", p->name);
                printf("Novo: ");
                if (fgets(p->name, sizeof(p->name), stdin)) {
                    p->name[strcspn(p->name, "\n")] = '\0';
                    save_config();
                }
                break;
            case 5: /* Save */
                save_config();
                console_clrscr();
                printf("Configuracao salva!\n");
                udelay(500000);
                break;
        }
    }
}

/* ============================================================================
 * Diagnostics Menu
 * ============================================================================ */

static int diagnostics_menu(void)
{
    char items[MAX_MENU_ITEMS][256];

    while (1) {
        int n = 0;
        snprintf(items[n++], sizeof(items[0]), "Teste de Memoria (RAM)");
        snprintf(items[n++], sizeof(items[0]), "Teste de CPU (Stress)");
        snprintf(items[n++], sizeof(items[0]), "Teste de Video/Framebuffer");
        snprintf(items[n++], sizeof(items[0]), "Teste de USB/Armazenamento");
        snprintf(items[n++], sizeof(items[0]), "Teste de Rede/Ethernet");
        snprintf(items[n++], sizeof(items[0]), "Teste de Controle Xbox 360");
        snprintf(items[n++], sizeof(items[0]), "Informacoes de Hardware");
        snprintf(items[n++], sizeof(items[0]), "Executar Todos os Testes");
        snprintf(items[n++], sizeof(items[0]), "Voltar");

        menu_t menu = {
            .title = "Diagnosticos de Hardware",
            .hint = "Cima/Baixo move  A executa  B volta",
            .item_count = n,
            .selected = 0,
            .timeout_sec = 0
        };
        memcpy(menu.items, items, sizeof(items));

        menu_result_t result = menu_show(&menu);
        if (result == MENU_RESULT_BACK || result < 0 || result == 8) return 0;

        console_clrscr();
        printf("Executando teste...\n\n");

        switch (result) {
            case 0: diag_run_memory_test(); break;
            case 1: diag_run_cpu_test(); break;
            case 2: diag_run_video_test(); break;
            case 3: diag_run_usb_test(); break;
            case 4: diag_run_network_test(); break;
            case 5: /* Controller test */
                printf("Teste de controle: mova os analógicos, pressione botoes.\n");
                printf("Pressione BACK para sair.\n\n");
                while (input_poll() != INPUT_BACK) {
                    struct controller_data_s data;
                    if (get_controller_data(&data, 0)) {
                        printf("\rLX:%4d LY:%4d RX:%4d RY:%4d  A:%d B:%d X:%d Y:%d  LT:%3d RT:%3d  ",
                               data.lx, data.ly, data.rx, data.ry,
                               data.a, data.b, data.x, data.y,
                               data.lt, data.rt);
                        fflush(stdout);
                    }
                    udelay(50000);
                }
                printf("\n\n");
                break;
            case 6: /* Hardware info */
                show_info_screen();
                break;
            case 7: /* All tests */
                diag_run_memory_test();
                diag_run_cpu_test();
                diag_run_video_test();
                diag_run_usb_test();
                diag_run_network_test();
                break;
        }

        printf("\nPressione qualquer tecla para continuar...\n");
        input_wait_any();
    }
}

/* ============================================================================
 * Recovery Menu
 * ============================================================================ */

static int recovery_menu(void)
{
    char items[MAX_MENU_ITEMS][256];

    while (1) {
        int n = 0;
        snprintf(items[n++], sizeof(items[0]), "Boot Modo Seguro (Single CPU, Texto)");
        snprintf(items[n++], sizeof(items[0]), "Boot Modo Debug (Verbose, Single CPU)");
        snprintf(items[n++], sizeof(items[0]), "Boot Modo Recuperacao (Minimal)");
        snprintf(items[n++], sizeof(items[0]), "Redefinir Configuracao para Padrao");
        snprintf(items[n++], sizeof(items[0]), "Verificar Integridade Kernel/Initrd");
        snprintf(items[n++], sizeof(items[0]), "Voltar");

        menu_t menu = {
            .title = "Modo de Recuperacao",
            .hint = "Cima/Baixo move  A executa  B volta",
            .item_count = n,
            .selected = 0,
            .timeout_sec = 0
        };
        memcpy(menu.items, items, sizeof(items));

        menu_result_t result = menu_show(&menu);
        if (result == MENU_RESULT_BACK || result < 0 || result == 5) return 0;

        xwt_profile_t *p = &g_state.profiles[g_state.active_profile];

        switch (result) {
            case 0: p->mode = BOOT_MODE_SAFE; save_config(); return 0;
            case 1: p->mode = BOOT_MODE_DEBUG; save_config(); return 0;
            case 2: p->mode = BOOT_MODE_RECOVERY; save_config(); return 0;
            case 3:
                profile_defaults(p);
                profile_detect_kernel(p);
                save_config();
                console_clrscr();
                printf("Configuracao redefinida para padrao.\n");
                udelay(1000000);
                break;
            case 4: /* Verify integrity */
                console_clrscr();
                printf("Verificando integridade...\n");
                char kpath[XWT_PATH_MAX * 2], ipath[XWT_PATH_MAX * 2];
                if (profile_join(p->folder, p->kernel, kpath, sizeof(kpath)) == 0 && file_exists(kpath)) {
                    struct stat st;
                    stat(kpath, &st);
                    printf("Kernel: OK (%ld KB)\n", st.st_size / 1024);
                } else {
                    printf("Kernel: NAO ENCONTRADO\n");
                }
                if (p->initrd[0] && profile_join(p->folder, p->initrd, ipath, sizeof(ipath)) == 0 && file_exists(ipath)) {
                    struct stat st;
                    stat(ipath, &st);
                    printf("Initrd: OK (%ld KB)\n", st.st_size / 1024);
                } else {
                    printf("Initrd: NAO ENCONTRADO\n");
                }
                printf("\nPressione qualquer tecla...\n");
                input_wait_any();
                break;
        }
    }
}

/* ============================================================================
 * Info Screen
 * ============================================================================ */

static void show_info_screen(void)
{
    char roots[16][256];
    int n = list_roots(roots, 16);
    xwt_profile_t *p = &g_state.profiles[g_state.active_profile];

    console_clrscr();
    printf("==============================================================\n");
    printf("  %s %s - Informacoes\n", XWT_BOOT_NAME, XWT_BOOT_VERSION);
    printf("==============================================================\n\n");

    printf("  Perfil Ativo : %s\n", p->name);
    printf("  Pasta Linux  : %s\n", p->folder);
    printf("  Kernel       : %s\n", p->kernel);
    printf("  Initrd       : %s\n", p->initrd[0] ? p->initrd : "(nenhum)");
    printf("  Modo         : %s\n", boot_mode_name(p->mode));
    printf("  Timeout      : %d s\n", p->timeout);
    printf("  Auto Boot    : %s\n\n", p->autoboot ? "Sim" : "Nao");

    printf("  Dispositivos :");
    for (int i = 0; i < n; ++i) printf(" %s", roots[i]);
    printf("\n");

    printf("  Resolucao    : %dx%d @ %dbpp\n", g_state.screen_width, g_state.screen_height, g_state.framebuffer_bpp);
    printf("  Console Type : %d\n", xenon_get_console_type());
    printf("  Memoria      : 512 MB (Xbox 360)\n");
    printf("  Initrd Window: 128 MiB (0x94000000-0x9C000000)\n");
    printf("  NAND Write   : Nao (XWT nao grava NAND/KV/SMC)\n\n");

    printf("  Pressione qualquer tecla para voltar...\n");
    input_wait_any();
}

/* ============================================================================
 * Boot Linux
 * ============================================================================ */

int boot_linux(const xwt_profile_t *profile)
{
    char kpath[XWT_PATH_MAX * 2], ipath[XWT_PATH_MAX * 2], cmdline[XWT_CMDLINE_MAX + 1];
    long ksize, isize = 0;
    void *kbuf = NULL, *ibuf = NULL;
    char *argv[1];

    console_clrscr();
    printf("==============================================================\n");
    printf("  XWT Boot: Carregando Linux\n");
    printf("==============================================================\n\n");

    /* Build kernel path */
    if (profile_join(profile->folder, profile->kernel, kpath, sizeof(kpath)) != 0) {
        console_clrscr();
        printf("Erro: Caminho do kernel invalido.\n");
        input_wait_any();
        return -1;
    }

    ksize = file_size(kpath);
    if (ksize <= 0) {
        console_clrscr();
        printf("Kernel nao encontrado: %s\n", kpath);
        printf("\nEscolha a pasta do Linux no menu.\n");
        input_wait_any();
        return -1;
    }

    /* Build cmdline */
    if (profile_build_cmdline(profile, cmdline, sizeof(cmdline)) != 0) {
        console_clrscr();
        printf("Linha de comando do kernel invalida/longa demais.\n");
        input_wait_any();
        return -1;
    }

    /* Load initrd if specified */
    if (profile->initrd[0]) {
        if (profile_join(profile->folder, profile->initrd, ipath, sizeof(ipath)) != 0 ||
            (isize = file_size(ipath)) <= 0) {
            console_clrscr();
            printf("Initrd configurado mas nao encontrado: %s\n", ipath);
            input_wait_any();
            return -1;
        }

        /* Check initrd size (128 MiB window) */
        if (isize > 128 * 1024 * 1024) {
            console_clrscr();
            printf("Initrd maior que a janela de 128 MiB.\n");
            input_wait_any();
            return -1;
        }

        printf(" * Initrd: %s (%ld KiB)\n   ", ipath, isize / 1024);
        ibuf = (void *)0x94000000; /* XWT Boot initrd window */
        if (read_file_into(ipath, ibuf, (size_t)isize) != 0) {
            console_clrscr();
            printf("Falha ao ler o initrd.\n");
            input_wait_any();
            return -1;
        }
        if (kernel_prepare_initrd(ibuf, (size_t)isize) != 0) {
            console_clrscr();
            printf("Initrd recusado pelo carregador.\n");
            input_wait_any();
            return -1;
        }
        printf("ok\n");
    }

    /* Load kernel */
    kbuf = malloc((size_t)ksize);
    if (!kbuf) {
        console_clrscr();
        printf("Memoria insuficiente para o kernel.\n");
        input_wait_any();
        return -1;
    }

    printf(" * Kernel: %s (%ld KiB)\n   ", kpath, ksize / 1024);
    if (read_file_into(kpath, kbuf, (size_t)ksize) != 0) {
        free(kbuf);
        console_clrscr();
        printf("Falha ao ler o kernel.\n");
        input_wait_any();
        return -1;
    }
    printf("ok\n");

    /* Validate kernel is ELF32 PowerPC */
    if (memcmp(kbuf, "\x7f" "ELF", 4) != 0) {
        free(kbuf);
        console_clrscr();
        printf("O kernel nao e um ELF (precisa ser ELF32 PowerPC).\n");
        input_wait_any();
        return -1;
    }

    /* Boot it */
    argv[0] = kpath;
    elf_setArgcArgv(1, argv);

    printf(" * Iniciando o kernel...\n");

    /* Jump to kernel with device tree */
    elf_runWithDeviceTree(kbuf, (int)ksize, dt_blob_start, (int)(dt_blob_end - dt_blob_start));

    /* If we get here, kernel failed to start */
    free(kbuf);
    console_clrscr();
    printf("O kernel nao iniciou (veja mensagens acima).\n");
    printf("Tente modo seguro/debug no menu de recuperacao.\n");
    input_wait_any();
    return -1;
}

/* ============================================================================
 * File Helpers
 * ============================================================================ */

static long file_size(const char *path)
{
    struct stat st;
    memset(&st, 0, sizeof(st));
    if (stat(path, &st) != 0) return -1;
    return (long)st.st_size;
}

static int read_file_into(const char *path, void *buf, size_t size)
{
    FILE *f = fopen(path, "rb");
    if (!f) return -1;

    size_t done = 0;
    while (done < size) {
        size_t chunk = size - done > (1u << 20) ? (1u << 20) : size - done;
        size_t got = fread((char *)buf + done, 1, chunk, f);
        if (got == 0) break;
        done += got;
        if ((done & ((8u << 20) - 1)) == 0) {
            printf(".");
            fflush(stdout);
        }
    }
    fclose(f);
    return done == size ? 0 : -1;
}

/* ============================================================================
 * Diagnostics Stubs
 * ============================================================================ */

void diag_run_memory_test(void)
{
    printf("Teste de Memoria (RAM 512 MB)\n");
    printf("==============================\n\n");

    /* Test first 64 MB pattern */
    volatile uint32_t *mem = (volatile uint32_t *)0x00000000;
    uint32_t patterns[] = {0x00000000, 0xFFFFFFFF, 0xAAAAAAAA, 0x55555555, 0xDEADBEEF};
    int errors = 0;

    for (int p = 0; p < 5; p++) {
        uint32_t pattern = patterns[p];
        printf("  Padrao 0x%08X: ", pattern);

        for (int i = 0; i < 16 * 1024 * 1024 / 4; i++) {
            mem[i] = pattern;
        }
        for (int i = 0; i < 16 * 1024 * 1024 / 4; i++) {
            if (mem[i] != pattern) errors++;
        }
        printf("%s\n", errors ? "FALHOU" : "OK");
    }

    if (errors == 0) {
        printf("\nMemoria OK - 64 MB testados com sucesso.\n");
    } else {
        printf("\nERROS DE MEMORIA: %d falhas detectadas!\n", errors);
    }
}

void diag_run_cpu_test(void)
{
    printf("Teste de CPU (Xenon 3-core/6-thread PPC)\n");
    printf("=========================================\n\n");

    uint64_t start = mftb();
    volatile uint64_t sum = 0;

    /* Simple CPU stress - integer math */
    for (int i = 0; i < 10000000; i++) {
        sum += i * 31 + 17;
        sum ^= sum >> 33;
    }

    uint64_t end = mftb();
    double secs = (double)tb_diff_sec(end, start);

    printf("  10M iteracoes integer: %.3f s\n", secs);
    printf("  Checksum: 0x%016llX\n", (unsigned long long)sum);
    printf("  CPUs ativas: 6 threads (3 cores SMT2)\n");
    printf("  Frequencia: 3.2 GHz\n\n");
    printf("CPU test concluido.\n");
}

void diag_run_video_test(void)
{
    printf("Teste de Video/Framebuffer\n");
    printf("===========================\n\n");
    printf("  Resolucao: %dx%d @ %dbpp\n", g_state.screen_width, g_state.screen_height, g_state.framebuffer_bpp);
    printf("  Framebuffer: %p\n", g_state.framebuffer);
    printf("  Modo: Xenos DRM (experimental)\n\n");

    /* Draw test pattern */
    int w = g_state.screen_width;
    int h = g_state.screen_height;

    /* Color bars */
    int bar_w = w / 8;
    uint32_t colors[] = {
        0xFFFF0000, 0xFF00FF00, 0xFF0000FF, 0xFFFFFF00,
        0xFFFF00FF, 0xFF00FFFF, 0xFFFFFFFF, 0xFF000000
    };

    for (int i = 0; i < 8; i++) {
        draw_rect(i * bar_w, 0, bar_w, h / 4, colors[i]);
    }

    /* Gradient */
    for (int y = h / 4; y < h / 2; y++) {
        for (int x = 0; x < w; x++) {
            uint8_t r = (x * 255) / w;
            uint8_t g = (y * 255) / h;
            uint8_t b = 128;
            draw_pixel(x, y, (0xFF << 24) | (r << 16) | (g << 8) | b);
        }
    }

    present_framebuffer();

    printf("  Padroes de teste desenhados no framebuffer.\n");
    printf("  Verifique: cores solidas, gradiente suave, sem artifacts.\n\n");
}

void diag_run_usb_test(void)
{
    printf("Teste de USB/Armazenamento\n");
    printf("===========================\n\n");

    usb_do_poll();

    char roots[16][256];
    int n = list_roots(roots, 16);

    printf("  Dispositivos montados: %d\n", n);
    for (int i = 0; i < n; i++) {
        printf("    %s\n", roots[i]);
        /* Try to list root */
        char dirs[32][256];
        int d = list_dirs(roots[i], dirs, 32);
        printf("      Diretorios: %d\n", d);
        for (int j = 0; j < d && j < 5; j++) {
            printf("        %s\n", dirs[j]);
        }
        if (d > 5) printf("        ... e mais %d\n", d - 5);
    }

    if (n == 0) {
        printf("  Nenhum dispositivo USB detectado.\n");
        printf("  Conecte um pendrive/HD e pressione A para reescanear.\n");
        input_wait_any();
        usb_do_poll();
        n = list_roots(roots, 16);
        printf("  Apos reescan: %d dispositivos\n", n);
    }
}

void diag_run_network_test(void)
{
    printf("Teste de Rede/Ethernet\n");
    printf("======================\n\n");

    /* Check SIS190 Ethernet */
    printf("  Verificando Ethernet onboard (SIS190)...\n");
    /* In real impl, check PCI device and link status */
    printf("  Status: Requer driver SIS190 no kernel Linux.\n");
    printf("  No bootloader: interface nao inicializada.\n\n");

    printf("  USB-Ethernet adapters suportados:\n");
    printf("    - ASIX AX88179/178A (USB 3.0 Gigabit)\n");
    printf("    - ASIX AX88178 (USB 2.0 Gigabit)\n");
    printf("    - SMSC LAN7500/LAN9500\n");
    printf("    - Realtek RTL8152/RTL8153\n\n");
}

/* ============================================================================
 * Device/Storage Helpers
 * ============================================================================ */

int mount_all_devices(void)
{
    /* Mount all USB mass storage and SATA devices */
    /* This is handled by libxenon's device filesystem */
    return 0;
}

int unmount_all_devices(void)
{
    return 0;
}

int list_roots(char roots[][256], int max)
{
    int n = 0;
    for (int i = 3; i < 16 && n < max; ++i) {
        if (devoptab_list[i]->structSize) {
            snprintf(roots[n], 256, "%s:/", devoptab_list[i]->name);
            n++;
        }
    }
    return n;
}

int list_dirs(const char *path, char dirs[][256], int max)
{
    DIR *d = opendir(path);
    struct dirent *e;
    int n = 0;
    char full[XWT_PATH_MAX * 2];

    if (!d) return 0;

    while ((e = readdir(d)) != NULL && n < max) {
        if (e->d_name[0] == '.') continue;
        snprintf(full, sizeof(full), "%s/%s", path, e->d_name);
        struct stat st;
        if (stat(full, &st) == 0 && S_ISDIR(st.st_mode)) {
            snprintf(dirs[n], 256, "%s", e->d_name);
            n++;
        }
    }
    closedir(d);
    return n;
}

bool path_exists(const char *path)
{
    struct stat st;
    return stat(path, &st) == 0;
}

bool is_directory(const char *path)
{
    struct stat st;
    return stat(path, &st) == 0 && S_ISDIR(st.st_mode);
}

/* ============================================================================
 * Main Entry Point
 * ============================================================================ */

int main(void)
{
    /* Initialize hardware */
    if (hardware_init() != 0) {
        /* Fallback to console if video fails */
        console_init();
        console_set_colors(CONSOLE_COLOR_BLUE, CONSOLE_COLOR_WHITE);
    }

    /* Load saved profiles */
    load_config();

    /* Main loop */
    while (1) {
        int result = main_menu();

        if (result == 0) {
            /* Boot requested */
            xwt_profile_t *p = &g_state.profiles[g_state.active_profile];
            if (boot_linux(p) == 0) {
                /* Kernel took over - we never return */
                break;
            }
            /* Boot failed - return to menu */
        }
    }

    hardware_shutdown();
    return 0;
}