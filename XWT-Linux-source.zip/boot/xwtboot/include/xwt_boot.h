#ifndef XWT_BOOT_H
#define XWT_BOOT_H

#include <stdint.h>
#include <stdbool.h>

#define XWT_BOOT_VERSION "2.0.0"
#define XWT_BOOT_NAME "XWT Boot Manager"
#define XWT_PATH_MAX 4096
#define XWT_CMDLINE_MAX 2048
#define CONFIG_DIR "XWTBoot"
#define CONFIG_FILE "XWTBoot/config.cfg"
#define MAX_PROFILES 16
#define MAX_MENU_ITEMS 64

/* Boot modes */
typedef enum {
    BOOT_MODE_NORMAL = 0,
    BOOT_MODE_TEXT,
    BOOT_MODE_SAFE,
    BOOT_MODE_DEBUG,
    BOOT_MODE_CUSTOM,
    BOOT_MODE_RECOVERY,
    BOOT_MODE_COUNT
} boot_mode_t;

/* Profile structure */
typedef struct {
    char name[64];
    char folder[XWT_PATH_MAX];
    char kernel[256];
    char initrd[256];
    boot_mode_t mode;
    char custom_cmdline[XWT_CMDLINE_MAX];
    int timeout;
    bool autoboot;
    bool valid;
} xwt_profile_t;

/* Global state */
typedef struct {
    xwt_profile_t profiles[MAX_PROFILES];
    int profile_count;
    int active_profile;
    char config_path[XWT_PATH_MAX * 2];
    int screen_width;
    int screen_height;
    int framebuffer_bpp;
    void *framebuffer;
    bool hardware_initialized;
    bool usb_mounted;
    bool has_controller;
} xwt_boot_state_t;

/* Function declarations */
extern xwt_boot_state_t g_state;

/* Hardware initialization */
int hardware_init(void);
void hardware_shutdown(void);
int init_framebuffer(void);
void draw_pixel(int x, int y, uint32_t color);
void draw_rect(int x, int y, int w, int h, uint32_t color);
void draw_image(int x, int y, const uint8_t *data, int w, int h, int stride);
void clear_screen(uint32_t color);
void present_framebuffer(void);

/* Profile management */
void profile_defaults(xwt_profile_t *p);
int profile_load_all(void);
int profile_save(int index);
int profile_detect_kernel(xwt_profile_t *p);
int profile_validate(const xwt_profile_t *p);
const char *boot_mode_name(boot_mode_t mode);
int profile_build_cmdline(const xwt_profile_t *p, char *out, size_t out_size);

/* Menu system */
typedef enum {
    MENU_RESULT_SELECTED = 0,
    MENU_RESULT_BACK = -1,
    MENU_RESULT_TIMEOUT = -2,
    MENU_RESULT_ERROR = -3
} menu_result_t;

typedef struct {
    const char *title;
    const char *hint;
    char items[MAX_MENU_ITEMS][256];
    int item_count;
    int selected;
    int timeout_sec;
    bool show_countdown;
} menu_t;

menu_result_t menu_show(menu_t *menu);
void menu_draw(const menu_t *menu, int countdown);

/* Boot process */
int boot_linux(const xwt_profile_t *profile);
int load_kernel(const char *path, void **buffer, size_t *size);
int load_initrd(const char *path, void **buffer, size_t *size);
int validate_kernel_elf(const void *data, size_t size);
int validate_initrd(const void *data, size_t size);
void jump_to_kernel(void *kernel, size_t ksize, void *initrd, size_t isize, const char *cmdline, void *dtb, size_t dtb_size);

/* Device tree */
extern char dt_blob_start[];
extern char dt_blob_end[];

/* UI/Theme */
typedef struct {
    uint32_t bg_color;
    uint32_t fg_color;
    uint32_t accent_color;
    uint32_t selection_color;
    uint32_t border_color;
    uint32_t warning_color;
    uint32_t panel_color;
    uint32_t panel2_color;
    uint32_t text_color;
    uint32_t muted_color;
} theme_t;

extern theme_t g_theme;
void theme_init_default(void);
void theme_draw_header(const char *title, const char *version);
void theme_draw_footer(const char *hint);
void theme_draw_sidebar(int x, int y, int w, int h);
void theme_draw_button(int x, int y, int w, int h, const char *label, bool selected);
void theme_draw_progress(int x, int y, int w, int h, int percent);
void theme_draw_icon(int x, int y, int type, bool selected);

/* Input */
typedef enum {
    INPUT_NONE = 0,
    INPUT_UP,
    INPUT_DOWN,
    INPUT_LEFT,
    INPUT_RIGHT,
    INPUT_OK,
    INPUT_BACK,
    INPUT_QUIT
} input_key_t;

void input_init(void);
input_key_t input_poll(void);
void input_wait_any(void);

/* USB/Storage */
int mount_all_devices(void);
int unmount_all_devices(void);
int list_roots(char roots[][256], int max);
int list_dirs(const char *path, char dirs[][256], int max);
bool path_exists(const char *path);
bool is_directory(const char *path);

/* Diagnostics */
void diag_run_memory_test(void);
void diag_run_cpu_test(void);
void diag_run_video_test(void);
void diag_run_usb_test(void);
void diag_run_network_test(void);
void diag_show_results(void);

#endif /* XWT_BOOT_H */