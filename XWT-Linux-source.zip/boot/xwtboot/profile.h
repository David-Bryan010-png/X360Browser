/* XWT Boot - boot profile: which Linux folder to load and how. Pure C (no libxenon) so it is unit-tested on the PC. */
#ifndef XWT_PROFILE_H
#define XWT_PROFILE_H
#include <stddef.h>

#define XWT_PATH_MAX 256
#define XWT_CMDLINE_MAX 255   /* libxenon bootargs limit */

typedef struct {
    char folder[XWT_PATH_MAX];   /* e.g. uda:/X360WebTotal/Linux */
    char kernel[XWT_PATH_MAX];   /* file name inside folder (ELF32 PowerPC) */
    char initrd[XWT_PATH_MAX];   /* file name inside folder, may be empty */
    char mode[16];               /* normal | text | safe | debug | custom */
    char cmdline[XWT_CMDLINE_MAX + 1]; /* used when mode == custom */
    int timeout;                 /* seconds before auto boot (1..60) */
    int autoboot;                /* 1 = boot saved profile after timeout */
} XwtProfile;

typedef int (*XwtExistsFn)(const char *path, void *ctx);

void profile_defaults(XwtProfile *p);
/* key=value lines, '#' comments. Unknown keys are ignored. Returns number of recognised keys. */
int profile_parse(const char *text, XwtProfile *p);
/* Writes the config text. Returns bytes written (excluding NUL) or -1 if it does not fit. */
int profile_format(const XwtProfile *p, char *out, size_t out_size);
/* Looks for a kernel and an initrd in p->folder using known names. Returns 1 if a kernel was found. */
int profile_detect(XwtProfile *p, XwtExistsFn exists, void *ctx);
/* Builds the kernel command line for the profile's mode. Returns 0 or -1 if too long. */
int profile_cmdline(const XwtProfile *p, char *out, size_t out_size);
/* Joins folder and name with exactly one '/'. Returns 0 or -1 if it does not fit. */
int profile_join(const char *folder, const char *name, char *out, size_t out_size);
/* Next mode in the cycle normal -> text -> safe -> debug -> normal. */
void profile_next_mode(XwtProfile *p);

/* One level up ("uda:/a/b" -> "uda:/a" -> "uda:/"). Returns 1 when already at "dev:/" (go to the device list). */
int profile_parent(char *path);

#endif
