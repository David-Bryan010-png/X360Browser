/*
 * XWT Boot 1.0.0 - independent boot manager for the Xbox 360 (RGH/JTAG), built on libxenon.
 *
 * It is its own program: own start-up, own menu, own saved settings. It can be started by XeLL
 * (xenon.elf), by XellLaunch2 as xell-2f.bin, or by anything that runs a libxenon ELF - and once it
 * runs it does not use XeLL anymore. It does not contain Linux: it asks you for a folder that holds a
 * Linux kernel (ELF32 PowerPC) and an optional initrd, loads them (initrd window: 128 MiB), and saves
 * the choice (X360WebTotal/../XWTBoot/config.cfg) so the next boot needs no selection.
 * Licence: GPL-2.0-or-later (uses code derived from XeLL Reloaded / libxenon, see THIRD-PARTY-NOTICES).
 */
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

#include <console/console.h>
#include <debug.h>
#include <diskio/ata.h>
#include <elf/elf.h>
#include <input/input.h>
#include <ppc/register.h>
#include <ppc/timebase.h>
#include <sys/iosupport.h>
#include <time/time.h>
#include <usb/usbmain.h>
#include <xb360/xb360.h>
#include <xenon_nand/xenon_sfcx.h>
#include <xenon_smc/xenon_smc.h>
#include <xenon_soc/xenon_io.h>
#include <xenon_soc/xenon_power.h>
#include <xenon_uart/xenon_uart.h>
#include <xenos/xenos.h>

#include "config.h"
#include "profile.h"

#define XWT_BOOT_VERSION "1.0.0"
#define CONFIG_DIR "XWTBoot"
#define CONFIG_FILE "XWTBoot/config.cfg"
#define MAX_ITEMS 64
#define ITEM_LEN 96

extern char dt_blob_start[];
extern char dt_blob_end[];

static XwtProfile profile;
static char config_path[XWT_PATH_MAX * 2];   /* where config.cfg was found / will be written */
static unsigned char stacks[6][0x10000];

/* ---------- hardware start-up (same sequence libxenon programs/XeLL use) ---------- */

static void reset_timebase_task(void)
{
    mtspr(284, 0);
    mtspr(285, 0);
    mtspr(284, 0);
}

static void synchronize_timebases(void)
{
    int i;
    xenon_thread_startup();
    std((void *)0x200611a0, 0);
    for (i = 1; i < 6; ++i) {
        xenon_run_thread_task(i, &stacks[i][0xff00], (void *)reset_timebase_task);
        while (xenon_is_thread_task_running(i)) { }
    }
    reset_timebase_task();
    std((void *)0x200611a0, 0x1ff);
}

static void init_hardware(void)
{
    synchronize_timebases();                       /* Linux needs synchronized timebases */
    *(volatile uint32_t *)0xea00106c = 0x1000000;  /* SMC interrupt pre-init */
    *(volatile uint32_t *)0xea001064 = 0x10;
    *(volatile uint32_t *)0xea00105c = 0xc000000;
    xenon_smc_set_led(0, 0);
    xenon_smc_start_bootanim();
    setbuf(stdout, NULL);
    xenos_init(VIDEO_MODE_AUTO);
    console_set_colors(CONSOLE_COLOR_BLUE, CONSOLE_COLOR_WHITE);
    console_init();
    xenon_make_it_faster(XENON_SPEED_FULL);
    if (xenon_get_console_type() != REV_CORONA_PHISON) sfcx_init(); /* controller init only, nothing is written */
    usb_init();
    usb_do_poll();
    xenon_ata_init();      /* skipping this causes an interrupt storm in Linux */
    xenon_atapi_init();
    mount_all_devices();
}

/* ---------- input ---------- */

typedef enum { K_NONE, K_UP, K_DOWN, K_OK, K_BACK } Key;

static Key poll_key(void)
{
    static struct controller_data_s old;
    struct controller_data_s now;
    usb_do_poll();
    if (kbhit()) {
        int ch = getch();
        if (ch == 0x0D) return K_OK;
        if (ch == 0x41) return K_UP;
        if (ch == 0x42) return K_DOWN;
        if (ch == 0x63) return K_BACK;
    }
    if (get_controller_data(&now, 0)) {
        Key k = K_NONE;
        if (now.a > old.a || now.start > old.start) k = K_OK;
        else if (now.b > old.b || now.back > old.back) k = K_BACK;
        else if (now.up > old.up) k = K_UP;
        else if (now.down > old.down) k = K_DOWN;
        old = now;
        return k;
    }
    return K_NONE;
}

static void pause_screen(const char *message)
{
    printf("\n%s\n\n[A] continuar\n", message);
    for (;;) {
        Key k = poll_key();
        if (k == K_OK || k == K_BACK) return;
    }
}

/* ---------- menu ---------- */

#define MENU_BACK (-1)
#define MENU_TIMEOUT (-2)

static void draw_menu(const char *title, const char *hint, char items[][ITEM_LEN], int n, int sel, int countdown)
{
    int i;
    console_clrscr();
    printf("==============================================================\n");
    printf("  XWT Boot %s  -  gerenciador de boot independente\n", XWT_BOOT_VERSION);
    printf("==============================================================\n\n");
    printf("  %s\n\n", title);
    for (i = 0; i < n; ++i) printf("  %s %s\n", i == sel ? ">" : " ", items[i]);
    printf("\n  %s\n", hint);
    if (countdown >= 0) printf("\n  Iniciando em %d s... (qualquer botao cancela)\n", countdown);
}

/* Returns the chosen index, MENU_BACK (B) or MENU_TIMEOUT. timeout<=0 disables the countdown. */
static int menu(const char *title, const char *hint, char items[][ITEM_LEN], int n, int sel, int timeout)
{
    uint64_t start = mftb();
    int shown = -2, last_left = -2;
    int dirty = 1;
    while (1) {
        int left = -1;
        Key k;
        if (timeout > 0) {
            int elapsed = (int)tb_diff_sec(mftb(), start);
            left = timeout - elapsed;
            if (left <= 0) return MENU_TIMEOUT;
        }
        if (left != last_left) { last_left = left; dirty = 1; }
        if (dirty || sel != shown) {
            draw_menu(title, hint, items, n, sel, left);
            shown = sel;
            dirty = 0;
        }
        k = poll_key();
        if (k != K_NONE && timeout > 0) { timeout = 0; last_left = -2; dirty = 1; }
        if (k == K_UP && sel > 0) sel--;
        else if (k == K_DOWN && sel < n - 1) sel++;
        else if (k == K_OK) return sel;
        else if (k == K_BACK) return MENU_BACK;
    }
}

/* ---------- files ---------- */

static int file_exists(const char *path, void *ctx)
{
    struct stat st;
    (void)ctx;
    memset(&st, 0, sizeof(st));
    return stat(path, &st) == 0 && !S_ISDIR(st.st_mode) && st.st_size > 0;
}

static int is_dir(const char *path)
{
    struct stat st;
    memset(&st, 0, sizeof(st));
    return stat(path, &st) == 0 && S_ISDIR(st.st_mode);
}

/* Device roots ("uda:/", "sda:/", ...). */
static int list_roots(char items[][ITEM_LEN], int max)
{
    int i, n = 0;
    for (i = 3; i < 16 && n < max; ++i) {
        if (devoptab_list[i]->structSize) {
            snprintf(items[n], ITEM_LEN, "%s:/", devoptab_list[i]->name);
            n++;
        }
    }
    return n;
}

static int cmp_names(const void *a, const void *b) { return strcmp((const char *)a, (const char *)b); }

static int list_dirs(const char *path, char items[][ITEM_LEN], int max)
{
    DIR *d = opendir(path);
    struct dirent *e;
    int n = 0;
    char full[XWT_PATH_MAX * 2];
    if (!d) return 0;
    while ((e = readdir(d)) != NULL && n < max) {
        if (e->d_name[0] == '.') continue;
        if (profile_join(path, e->d_name, full, sizeof(full)) != 0) continue;
        if (!is_dir(full)) continue;
        snprintf(items[n], ITEM_LEN, "%.*s", ITEM_LEN - 2, e->d_name);
        n++;
    }
    closedir(d);
    qsort(items, (size_t)n, ITEM_LEN, cmp_names);
    return n;
}

/* ---------- saved settings ---------- */

static void load_config(void)
{
    char roots[16][ITEM_LEN];
    char text[2048];
    int i, n = list_roots(roots, 16);
    profile_defaults(&profile);
    config_path[0] = '\0';
    for (i = 0; i < n; ++i) {
        char path[XWT_PATH_MAX * 2];
        FILE *f;
        size_t got;
        if (profile_join(roots[i], CONFIG_FILE, path, sizeof(path)) != 0) continue;
        f = fopen(path, "r");
        if (!f) continue;
        got = fread(text, 1, sizeof(text) - 1, f);
        fclose(f);
        text[got] = '\0';
        profile_parse(text, &profile);
        snprintf(config_path, sizeof(config_path), "%s", path);
        return;
    }
}

static int save_config(void)
{
    char roots[16][ITEM_LEN];
    char text[2048], dir[XWT_PATH_MAX * 2];
    int i, n, len;
    FILE *f;
    len = profile_format(&profile, text, sizeof(text));
    if (len < 0) return -1;
    if (!config_path[0]) {
        n = list_roots(roots, 16);
        for (i = 0; i < n; ++i) {
            if (profile_join(roots[i], CONFIG_FILE, config_path, sizeof(config_path)) != 0) continue;
            if (profile_join(roots[i], CONFIG_DIR, dir, sizeof(dir)) == 0) mkdir(dir, 0777);
            f = fopen(config_path, "w");
            if (f) { fwrite(text, 1, (size_t)len, f); fclose(f); return 0; }
            config_path[0] = '\0';
        }
        return -1;
    }
    f = fopen(config_path, "w");
    if (!f) return -1;
    fwrite(text, 1, (size_t)len, f);
    fclose(f);
    return 0;
}

/* ---------- choose the Linux folder ---------- */

static void choose_folder(void)
{
    char items[MAX_ITEMS + 4][ITEM_LEN];
    char current[XWT_PATH_MAX];
    int at_roots = 1;
    current[0] = '\0';
    for (;;) {
        int n = 0, dirs, sel, i, found = 0;
        char title[XWT_PATH_MAX + 64];
        XwtProfile probe = profile;
        if (at_roots) {
            n = list_roots(items, MAX_ITEMS);
            snprintf(title, sizeof(title), "Escolha o dispositivo (B volta)");
            if (n == 0) { pause_screen("Nenhum dispositivo montado. Conecte o pendrive/HD e tente de novo."); return; }
        } else {
            snprintf(probe.folder, sizeof(probe.folder), "%s", current);
            found = profile_detect(&probe, file_exists, NULL);
            snprintf(title, sizeof(title), "Pasta: %s%s", current, found ? "   [Linux encontrado]" : "");
            snprintf(items[n++], ITEM_LEN, "[ Usar esta pasta ]");
            snprintf(items[n++], ITEM_LEN, "[ .. subir ]");
            dirs = list_dirs(current, items + n, MAX_ITEMS - n);
            n += dirs;
        }
        sel = menu(title, "A abre/seleciona   B volta   (precisa de kernel ELF32 + initrd opcional)", items, n, 0, 0);
        if (sel == MENU_BACK || sel < 0) {
            if (at_roots) return;
            /* B goes up one level, or back to the device list */
            if (profile_parent(current)) at_roots = 1;
            continue;
        }
        if (at_roots) {
            snprintf(current, sizeof(current), "%s", items[sel]);
            at_roots = 0;
            continue;
        }
        if (sel == 0) {
            if (!found) { pause_screen("Nao achei um kernel nessa pasta (xwt-linux.elf, zImage.xenon, vmlinux...)."); continue; }
            profile = probe;
            if (save_config() == 0) pause_screen("Pasta do Linux salva. Nos proximos boots ela inicia sozinha.");
            else pause_screen("Pasta escolhida, mas nao consegui salvar (pendrive protegido?).");
            return;
        }
        if (sel == 1) {
            if (profile_parent(current)) at_roots = 1;
            continue;
        }
        i = sel - 2;
        {
            char next[XWT_PATH_MAX * 2];
            if (profile_join(current, items[2 + i], next, sizeof(next)) == 0 && strlen(next) < sizeof(current))
                snprintf(current, sizeof(current), "%s", next);
        }
    }
}

/* ---------- boot Linux ---------- */

static int read_file_into(const char *path, void *buf, size_t size)
{
    FILE *f = fopen(path, "r");
    size_t done = 0;
    if (!f) return -1;
    while (done < size) {
        size_t chunk = size - done > (1u << 20) ? (1u << 20) : size - done;
        size_t got = fread((char *)buf + done, 1, chunk, f);
        if (got == 0) break;
        done += got;
        if ((done & ((8u << 20) - 1)) == 0) printf(".");
    }
    fclose(f);
    return done == size ? 0 : -1;
}

static long file_size(const char *path)
{
    struct stat st;
    memset(&st, 0, sizeof(st));
    if (stat(path, &st) != 0) return -1;
    return (long)st.st_size;
}

/* Returns only on failure. */
static void boot_linux(void)
{
    char kpath[XWT_PATH_MAX * 2], ipath[XWT_PATH_MAX * 2], cmd[XWT_CMDLINE_MAX + 1];
    long ksize, isize = 0;
    void *kbuf;
    char *argv[1];

    console_clrscr();
    printf("XWT Boot: carregando Linux\n\n");
    if (profile_join(profile.folder, profile.kernel, kpath, sizeof(kpath)) != 0 || (ksize = file_size(kpath)) <= 0) {
        pause_screen("Kernel nao encontrado. Escolha a pasta do Linux no menu.");
        return;
    }
    if (profile_cmdline(&profile, cmd, sizeof(cmd)) != 0) { pause_screen("Linha de comando do kernel invalida/longa demais."); return; }
    kernel_reset_initrd();
    kernel_build_cmdline(cmd, NULL);

    if (profile.initrd[0]) {
        void *ibuf;
        if (profile_join(profile.folder, profile.initrd, ipath, sizeof(ipath)) != 0 || (isize = file_size(ipath)) <= 0) {
            pause_screen("Initrd configurado mas nao encontrado na pasta.");
            return;
        }
        ibuf = kernel_initrd_buffer((size_t)isize);
        if (!ibuf) { pause_screen("Initrd maior que a janela de 128 MiB."); return; }
        printf(" * initrd %s (%ld KiB)\n   ", ipath, isize / 1024);
        if (read_file_into(ipath, ibuf, (size_t)isize) != 0) { pause_screen("Falha ao ler o initrd."); return; }
        if (kernel_prepare_initrd(ibuf, (size_t)isize) != 0) { pause_screen("Initrd recusado pelo carregador."); return; }
        printf(" ok\n");
    }

    kbuf = malloc((size_t)ksize);
    if (!kbuf) { pause_screen("Memoria insuficiente para o kernel."); return; }
    printf(" * kernel %s (%ld KiB)\n   ", kpath, ksize / 1024);
    if (read_file_into(kpath, kbuf, (size_t)ksize) != 0) { free(kbuf); pause_screen("Falha ao ler o kernel."); return; }
    printf(" ok\n");
    if (memcmp(kbuf, "\x7f" "ELF", 4) != 0) { free(kbuf); pause_screen("O kernel nao e um ELF (precisa ser ELF32 PowerPC)."); return; }

    argv[0] = kpath;
    elf_setArgcArgv(1, argv);
    printf(" * iniciando o kernel...\n");
    elf_runWithDeviceTree(kbuf, (int)ksize, dt_blob_start, (int)(dt_blob_end - dt_blob_start));
    free(kbuf);
    pause_screen("O kernel nao iniciou (veja as mensagens acima).");
}

/* ---------- info ---------- */

static void show_info(void)
{
    char roots[16][ITEM_LEN];
    int i, n = list_roots(roots, 16);
    console_clrscr();
    printf("XWT Boot %s - informacoes\n\n", XWT_BOOT_VERSION);
    printf("Pasta do Linux : %s\n", profile.folder);
    printf("Kernel         : %s\nInitrd         : %s\n", profile.kernel, profile.initrd[0] ? profile.initrd : "(nenhum)");
    printf("Modo           : %s   Tempo: %d s   Auto: %s\n", profile.mode, profile.timeout, profile.autoboot ? "sim" : "nao");
    printf("Config salva em: %s\n\nDispositivos   :", config_path[0] ? config_path : "(ainda nao salva)");
    for (i = 0; i < n; ++i) printf(" %s", roots[i]);
    printf("\n\nJanela do initrd: 128 MiB (0x94000000). O XWT Boot nao grava na NAND.\n");
    pause_screen("");
}

/* ---------- main ---------- */

int main(void)
{
    char items[8][ITEM_LEN];
    int sel = 0, first = 1;

    init_hardware();
    load_config();

    for (;;) {
        int choice, auto_ok;
        char kpath[XWT_PATH_MAX * 2];
        auto_ok = profile.autoboot && profile_join(profile.folder, profile.kernel, kpath, sizeof(kpath)) == 0 && file_exists(kpath, NULL);
        snprintf(items[0], ITEM_LEN, "Iniciar Linux: %.60s/%.20s", profile.folder, profile.kernel);
        snprintf(items[1], ITEM_LEN, "Escolher a pasta do Linux");
        snprintf(items[2], ITEM_LEN, "Modo de boot: %s  (A troca)", profile.mode);
        snprintf(items[3], ITEM_LEN, "Tempo ate iniciar sozinho: %d s  (A aumenta)", profile.timeout);
        snprintf(items[4], ITEM_LEN, "Boot automatico: %s  (A troca)", profile.autoboot ? "sim" : "nao");
        snprintf(items[5], ITEM_LEN, "Informacoes");
        snprintf(items[6], ITEM_LEN, "Reiniciar o console");
        snprintf(items[7], ITEM_LEN, "Desligar o console");
        choice = menu("Menu principal", "Cima/baixo move   A seleciona", items, 8, sel, (first && auto_ok) ? profile.timeout : 0);
        first = 0;
        if (choice == MENU_TIMEOUT) choice = 0;
        if (choice < 0) continue;
        sel = choice;
        switch (choice) {
        case 0: boot_linux(); break;
        case 1: choose_folder(); break;
        case 2: profile_next_mode(&profile); save_config(); break;
        case 3: profile.timeout = profile.timeout >= 30 ? 1 : (profile.timeout < 10 ? profile.timeout + 1 : profile.timeout + 5); save_config(); break;
        case 4: profile.autoboot = !profile.autoboot; save_config(); break;
        case 5: show_info(); break;
        case 6: xenon_smc_power_reboot(); for (;;) { } break;
        case 7: xenon_smc_power_shutdown(); for (;;) { } break;
        }
    }
    return 0;
}
