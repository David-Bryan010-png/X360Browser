# Plano do driver grafico XWT

Objetivo: permitir apps graficos leves no XWT Linux. Nao existe "um driver" que faca isso: e uma pilha (driver de tela, renderizacao, servidor grafico, toolkit, apps). Nenhuma fase abaixo foi testada no console.

## Limites
- Apps de PC (x86) ou de celular (ARM) nao rodam: a CPU do Xbox 360 e PowerPC. Cada app precisa ser compilado para PowerPC.
- O driver Xenos corrige a tela (buffer em tiles 32x32); nao ha aceleracao 2D/3D.
- Steam e Wine ficam fora do escopo.

## O que foi verificado no Buildroot fixado (15b0457...)
- Existem: `xserver_xorg-server`, `xf86-video-fbdev`, `xf86-input-evdev`, `openbox`, `xterm`, `xapp_xclock`, `matchbox-keyboard`, `fltk` (exige X11), `netsurf` (front-ends SDL 1.2 e GTK3), `libgtk3`, `mesa3d` com `softpipe`.
- Nao existem: `libgtk2`, `matchbox-wm`.
- GTK3 e `pcmanfm` exigem Mesa com OpenGL/EGL; `llvmpipe` exige LLVM (nao usar).
- SDL 2 existe, mas seus backends (KMSDRM, X11, Wayland) exigem GL/EGL ou X11; por isso o projeto usa SDL 1.2 com fbcon.
- Kernel ja tem `INPUT_EVDEV=y`, `FB=y`, `DRM_FBDEV_EMULATION=y`, `DRM_XENOS=y`, `INPUT_UINPUT=m`, `INPUT_JOYDEV=m`.

## Fases (estado no código; **nenhuma testada no console**)
1. Validar a base no console (foto do desktop 720p + `xwt-video report`). **Depende de você.**
2. Navegador sem X11: NetSurf SDL + `links` (`with_browser`, padrão ligado). **Incluído.**
3. X11 opcional (`with_x11`): KDrive (`Xfbdev`) + evdev + openbox + xterm + xclock + `xvkbd` + dillo; `xwt-x` com volta ao desktop SDL se falhar. **Incluído.**
4. Apps leves FLTK: `xwt-xpanel` (painel com Terminal, Relógio, Web, Arquivos, Teclado, Voltar) compilado no post-build só se o FLTK existir; falha de compilação não derruba o build. **Incluído** (sintaxe checada no PC com FLTK 1.3).
5. Integração: Aplicativos > Modo X11 / Diagnóstico da GPU; packs de até 30 MiB (regras `packs.rules` para X11/GTK/Mesa); fallback ao desktop SDL; teclado no desktop, no terminal/navegador e no X. **Incluído.**
6. Mesa por software + GTK3 + pcmanfm (`with_x11` + `with_gtk`, experimental). **Incluído como opção.** Risco: KDrive pode não expor GLX; se o GTK3 não abrir, o resto do X11 continua.
7. GPU Xenos: pesquisa de longo prazo. **Roteiro + ferramenta de coleta** (`xwt-gpu-probe`, `docs/PESQUISA-GPU-XENOS-PT-BR.md`); sem implementação.

## Ordem de teste sugerida no console
Base → `with_browser` → `with_x11` (xterm, painel) → `with_gtk` (pcmanfm). Cada passo: foto + `xwt/logs/boot-report.txt`.

## Entrada (mouse e teclado)
- L3 liga o mouse do controle; R3 abre o teclado: no desktop SDL e uma sobreposicao (busca na tela Arquivos), no terminal/navegador e o `xwt-osk` (uinput) e no X11 e o `xvkbd` (clicar com o mouse do L3).
- Em jogos o modo mouse fica desligado.

## Pronto so quando visto no console
Boot automatico ate o desktop; desktop estavel 10 min; navegador abre pagina local e HTTP; (depois) X11 com `xclock`/`xterm`, mouse L3 e teclado virtual; fallback ao desktop SDL; dados salvos apos reiniciar; packs <= 30 MiB.

Memoria (estimativa, nao medida): 512 MB no total; abrir um app pesado por vez.
