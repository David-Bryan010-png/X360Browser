# Sistema em pacotes (stage 1 + stage 2)

O XeLL carrega **um** initrd de no maximo 32 MiB. Se `rootfs.cpio.gz` passa disso, o XeLL mostra
`Failed! uda:/X360WebTotal/Linux/rootfs.cpio.gz... Aborting!` e volta ao menu (a tela "repetindo").

Por isso o build agora gera:

- `X360WebTotal/Linux/rootfs.cpio.gz` — **stage 1**, pequeno (busybox, init, scripts, modulos). E o unico initrd que o XeLL ve.
- `X360WebTotal/Linux/packs/xwt-pack-NN.sqfs` — **stage 2**, pacotes squashfs de ate 28 MiB (limite duro 30 MiB), com `packs.list` (SHA-256 e tamanho) e `overlays.list`.

Depois que o Linux monta o pendrive, `xwt-packs mount` monta cada pacote (loop) e faz overlay sobre
`/usr/share`, firmware etc. Se faltar pacote, a causa aparece em `/run/xwt-packs.log` e o sistema cai no menu de texto.

Copie a pasta `packs/` inteira junto com o resto. Para checar SHA-256 no boot, adicione `xwt.verify=1` na linha do kernel.
O que vai para pacote e definido em `linux/packs.rules` (uma linha `pack <diretorio>`).
