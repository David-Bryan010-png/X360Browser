# Jogos no XWT Linux

Hoje o jogo suportado e o **Doom** (motor PrBoom, SDL1, tela de 320x240 em 8 bits). Jogos x86 modernos da Steam
nao rodam no PowerPC do Xbox 360; a meta sao jogos de motor aberto.

1. Copie seu `doom.wad` / `doom2.wad` (da sua biblioteca Steam) ou `freedoom1.wad` (gratuito) para
   `xwt/games/doom/` no pendrive.
2. No desktop abra **Jogos > Doom**. Saves ficam em `xwt/persist/doom/`.
3. Controle: direcional/analogico move, A atira, B usa, X corre, Y mapa, LB/RB desviam, Start menu, Back confirma.
4. Som vem desligado (`-nosound`); para tentar, inicie com `XWT_GAME_SOUND=1 xwt-game doom` no terminal.
5. Pelo terminal: `xwt-game list` mostra o WAD encontrado.
