# Compilação e distribuição incremental

## Core inicial

Execute manualmente `XWT Linux - Build minimal Xenon core`. Essa compilação é a única que precisa montar o toolchain Buildroot, kernel Xenon e initramfs mínimo. Ela gera o pacote USB contendo `default.xex`, `kboot.conf`, ELF do kernel e initramfs.

O workflow guarda cache dos downloads, ccache e toolchain/sysroot. Isso reduz builds futuros e prepara a compilação separada de módulos nativos.

## Módulos pequenos

Execute `XWT Linux - Small Updates`, escolha o componente disponível (`system` nesta versão) e publique. Esse workflow não invoca Buildroot, não compila o kernel e cria somente o `.xwpkg` do módulo escolhido. O canal `xwt-linux-dev` recebe o pacote e o manifesto `latest.tsv`.

No console:

```sh
xwt-update list
xwt-update install system
xwt-update rollback system
```

Os pacotes ficam no USB e são reaplicados na inicialização. No futuro, `desktop`, `browser`, `audio`, `wifi` e módulos do driver poderão ser adicionados à lista conforme forem implementados.

## Quando uma compilação completa será necessária

Somente para alterações em kernel, drivers de baixo nível, toolchain/libc base, formato de initramfs ou boot. Alterações em scripts, programas e serviços permanecem em pacotes incrementais.
