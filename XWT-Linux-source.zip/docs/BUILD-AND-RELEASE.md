# Compilação e distribuição — XWT Linux 1.0.0

## Build completo

A versão 1.0.0 exige build completo porque muda a configuração do Buildroot, adiciona SDL/SDL_ttf, fontes e ferramentas, compila programas nativos para PPC64 e corrige o driver Xenos. Execute `XWT Linux 1.0.0 - Build Xenon desktop core` após atualizar a fonte e o workflow.

O workflow valida o manifesto SHA-256 e os testes, baixa os commits fixos do Buildroot/Free60, configura o kernel, aplica o patch Xenos guardado e executa a compilação completa. O post-build usa o cross-compiler Buildroot para compilar `xwt-desktop` e `xwt-gamepad-keys`. Só depois valida ELF32, initramfs e USB ZIP, publica os artefatos e o canal.

## Módulos pequenos

O workflow `XWT Linux - Small Updates` continua destinado a componentes já existentes em `updates/`. Ele não recompila o kernel e não substitui o build completo quando a ABI, drivers, Buildroot ou rootfs mudam.

No console:

```sh
xwt-update list
xwt-update install system
xwt-update rollback system
```

## Critérios para declarar a versão pronta

Uma compilação Actions concluída comprova a geração dos artefatos, não o funcionamento no hardware. A aprovação final requer inicialização física, framebuffer, navegação do desktop por controle, USB e rede. Áudio, Wi-Fi e navegador devem ser declarados como funcionais apenas após testar seus respectivos dispositivos/componentes.
