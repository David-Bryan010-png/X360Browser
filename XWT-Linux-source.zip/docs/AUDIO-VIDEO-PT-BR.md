# Audio e video

## Audio
O audio onboard do Xbox 360 nao tem driver no Linux principal. O som funciona por **dispositivos USB de audio**
(placa de som, headset, DAC) via `snd-usb-audio`. Ao iniciar, `S35audio` carrega o driver, escolhe a primeira
placa USB como padrao (`/etc/asound.conf`) e ajusta o volume para 80%.
No desktop abra **Audio**, ou no terminal: `xwt-audio status|init|volume 60|mute|unmute|test`.
Conectou depois do boot? Rode `xwt-audio init`. Log: `/run/xwt-audio.log`. Audio por HDMI **nao** e suportado.

## Video
O driver Xenos DRM cria `/dev/fb0`. No desktop abra **Video** (ou `xwt-video info|modes|set <modo>`) para ver as saidas
detectadas e trocar de modo, quando o driver listar mais de um. Se a imagem sumir, o modo anterior volta no proximo boot.
Relatorio do boot: `/run/xwt-video-report.txt`.

## Drivers
Os modulos do kernel (xpad, USB Ethernet, snd-usb-audio) ficam no sistema base; novos modulos de driver chegam por
`.xwpkg` em `X360WebTotal/Updates/` (`xwt-update`) e sao carregados no boot. Trocar o driver Xenos exige novo build do kernel.
