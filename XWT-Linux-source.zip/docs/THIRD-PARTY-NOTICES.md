# Avisos de terceiros

O XWT Linux reune software de terceiros, cada um sob sua propria licenca. Esta lista e de boa-fe e **deve ser conferida antes da distribuicao**.

| Componente | Licenca (resumo) |
|---|---|
| Linux kernel + patch Free60 Xenon | GPL-2.0 |
| Buildroot, BusyBox | GPL-2.0 |
| XeLL Reloaded (libxenon) | GPL, ver upstream |
| XellLaunch2 (default.xex) | MIT (`XellLaunch2-LICENSE.txt` no pacote) |
| PrBoom | GPL-2.0 |
| SDL 1.2, SDL_ttf, SDL_mixer, SDL_net | LGPL-2.1 / zlib |
| DejaVu fonts | licenca Bitstream Vera / DejaVu |
| linux-firmware (Wi-Fi USB) | licencas proprias por blob, redistribuiveis |
| wpa_supplicant, iw | BSD |

Como o sistema contem codigo GPL, o codigo-fonte correspondente e o `XWT-Linux-1.0.0-source.zip` mais as versoes fixadas do Buildroot e do kernel indicadas em `REVISION.txt` e `FREE60-KERNEL-COMMIT.txt`.
A licenca dos scripts proprios do projeto (`scripts/`, `linux/overlay`, `linux/src`) deve ser escolhida pelo autor e colocada em um arquivo `LICENSE`.

| XWT Boot (`boot/xwtboot`: mount.c, config.h, xenon.dts/dtb) | GPL-2.0-or-later, derivado do XeLL Reloaded e da libxenon (Free60 Project); fontes no pacote |
