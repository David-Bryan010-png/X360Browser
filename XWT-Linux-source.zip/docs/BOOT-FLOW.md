# Fluxo de inicialização — XWT Linux 0.14.0-alpha.2

1. O usuário abre `default.xex` pelo Aurora ou XeXMenu.
2. O XEX do XellLaunch2 inicia XeLL Reloaded.
3. XeLL localiza `kboot.conf` no USB.
4. XeLL apresenta o menu de boot e carrega o ELF Xenon e o initramfs externo indicados pelo `kboot.conf`.
5. O kernel inicializa o hardware habilitado: framebuffer/Xenos experimental, USB, armazenamento, SIS190 e entrada.
6. O BusyBox inicia, monta o USB FAT32, executa serviços essenciais e abre o menu textual.
7. O serviço de armazenamento reaplica os módulos `.xwpkg` guardados no USB.

XeLL-Reloaded documenta suporte a `kboot.conf`, argumentos de kernel e initramfs externo, além de carregar ELF32 a partir de USB. A cadeia exata com XellLaunch2 ainda precisa de validação física no console específico. Nenhum passo do XWT Linux escreve NAND, KV, SMC ou firmware.
