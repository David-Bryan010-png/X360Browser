# Fluxo de inicialização — XWT Linux 0.15.0

1. O usuário abre `default.xex` pelo Aurora ou XeXMenu.
2. O XEX do XellLaunch2 inicia XeLL Reloaded.
3. XeLL localiza `kboot.conf` no USB.
4. XeLL carrega o wrapper ELF32 PowerPC `zImage.xenon` e o initramfs externo indicados no `kboot.conf`. O kernel contido no wrapper é PPC64; `vmlinux` PPC64 não deve ser enviado diretamente ao XeLL.
5. O kernel inicializa USB, armazenamento, Ethernet SIS190, entrada e o framebuffer/DRM Xenos experimental.
6. BusyBox monta `proc`, `sysfs`, `devtmpfs`, `devpts` e `tmpfs`, executa os serviços de boot e inicia os módulos xpad/joydev/uinput.
7. O diagnóstico de vídeo salva o estado em `/run/xwt-video-report.txt`; o serviço de rede configura Ethernet/DHCP e o armazenamento USB reaplica os módulos `.xwpkg` guardados no USB.
8. O menu tenta iniciar o desktop SDL/fbcon somente após verificar o modo e a memória reais de `/dev/fb0`. Se o framebuffer ou SDL não estiverem utilizáveis, o menu textual serial continua disponível.

A correção Xenos 0.15.0 usa memória DMA coerente alinhada a tiles 32x32, verifica o limite de endereço de 32 bits e evita cópias além do buffer. Isso não significa aceleração 2D/3D. O boot exato, os timings e os periféricos ainda exigem teste físico no console específico. Nenhum passo grava NAND, KV, SMC ou firmware.
