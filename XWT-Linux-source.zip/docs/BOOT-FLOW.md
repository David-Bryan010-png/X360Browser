# Fluxo de inicialização — XWT Linux 1.0.0 (estilo Free60 clássico)

1. O usuário abre `default.xex` pelo Aurora ou XeXMenu (XellLaunch2).
2. O XellLaunch2 procura `xell-1f.bin` ao lado do XEX e inicia o **XeLL Reloaded**.
3. O XeLL inicializa o hardware e lê `kboot.conf` na raiz do pendrive (`timeout=0`: boot automático, sem ler o controle).
4. A entrada `xwt` carrega `uda:/vmlinux` e `initrd=uda:/initrd.img`. `vmlinux` é o wrapper ELF32 PowerPC (`zImage.xenon`) que contém o kernel PPC64; o XeLL não aceita o `vmlinux` PPC64 cru. O `initrd.img` (stage 1) precisa ter no máximo 32 MiB.
5. O kernel inicializa USB, armazenamento, Ethernet SIS190, entrada e o framebuffer/DRM Xenos experimental.
6. BusyBox monta `proc`, `sysfs`, `devtmpfs`, `devpts` e `tmpfs` e executa os serviços de boot.
7. `S30storage` acha o pendrive (marcador: `kboot.conf` ou pasta `xwt/`), cria `xwt/{packs,config,persist,logs,tools,...}`, monta os packs squashfs de `xwt/packs/` (stage 2) e ativa a persistência.
8. O desktop SDL/fbcon só inicia depois de verificar o modo e a memória reais de `/dev/fb0`; se falhar, o menu textual continua disponível.

O **XWT Boot Manager** (`boot/xwtboot`) é legado e não faz parte deste fluxo. Nenhum passo grava NAND, KV, SMC ou firmware. O boot exato e os periféricos ainda exigem teste físico no console.
