# Problemas conhecidos (1.0.0)

- **Nao testado em hardware pelo autor do build:** boot ate o desktop, video Xenos, Wi-Fi USB e Doom dependem do seu console.
- Controle ligado durante a tela do XeLL pode travar em "usb init": conecte so depois do Linux iniciar.
- Initrd acima de 32 MiB faz o XeLL mostrar `Failed! ... rootfs.cpio.gz` e repetir; o build limita o stage 1 a 30 MiB.
- Sem a pasta `packs/` o sistema cai no menu de texto (motivo em `/run/xwt-packs.log`).
- Doom sem som por padrao; navegador ainda e modulo opcional (`.xwpkg`).
- Jogos x86 modernos da Steam nao rodam (CPU PowerPC, 512 MB de RAM).
- 512 MB de RAM: pacotes squashfs e zram ajudam, mas aplicativos pesados podem faltar memoria.
