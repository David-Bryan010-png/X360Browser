# XWT Linux — boot, menu do XeLL e travamento em "usb init"

## Onde o travamento acontece

A linha ` * usb init` é escrita **pelo próprio XeLL** (o bootloader), antes do menu de boot e muito antes do kernel Linux ser carregado. Se a tela para ali, o Linux do XWT **ainda não começou a rodar** — o problema está na etapa de USB do XeLL (`usb_init()` do libxenon), não no kernel, no desktop nem no driver Xenos.

Sequência do XeLL: nand → rede → **usb init** → sata hdd → dvd → monta dispositivos → procura `kboot.conf` → mostra o menu.

> Não consigo testar em um Xbox 360 real. As causas abaixo são as mais prováveis pelo código do XeLL e pelas notas do XellLaunch2, não um diagnóstico confirmado.

## O que tentar (nesta ordem)

1. **Desligue da tomada por alguns segundos** e comece de novo. Um XeLL que travou deixa o console num estado pior para a tentativa seguinte.
2. **Tire tudo do USB, exceto o pendrive**: controles com fio, receptor de controle sem fio, hubs, teclado, headset, Kinect.
3. **Teste cada porta USB do console** (frente e trás). O XeLL usa os 3 barramentos USB do console; um deles pode estar problemático.
4. **Pendrive**: USB 2.0, até 32 GB, FAT32 com tabela MBR (não GPT, não exFAT), sem hub. Teste outro pendrive.
5. **Inicie sem USB e plugue depois** (contorna travamento na enumeração):
   - copie `default.xex` para o HD do Xbox (ou outro local que o seu launcher abra);
   - com **nenhum** USB conectado, execute o `default.xex`;
   - quando o XeLL chegar em "Looking for files", plugue o pendrive. O XeLL consulta o USB em laço (`usb_do_poll`) e monta o dispositivo em execução; o menu aparece quando achar `kboot.conf`.
6. **XeLL fornecido por você**: o XellLaunch2 usa, nesta ordem, `xell-1f.bin`, `xell-2f.bin`... ao lado do XEX antes do XeLL embutido. Coloque uma versão recente do XeLL-Reloaded ao lado do `default.xex`. O README do XellLaunch2 avisa que o XeLL é sensível quando iniciado com o sistema já rodando.
7. Se o seu console permite, **inicie o XeLL pela NAND/loader do seu exploit** em vez do XellLaunch2 (evita a partida "a quente").

## Boot automatico (padrao) — sem contagem e sem controle

O `kboot.conf` vem com `timeout=0`: o XeLL entra direto em `xwt`, sem esperar por escolha. Motivo (visto no codigo do XeLL): o menu le o controle durante a contagem e, se um botao mexer a selecao, **a contagem para para sempre**. Um controle USB ligado na tela do XeLL tambem foi a causa do travamento em "usb init". Regra pratica: **deixe o controle desligado/desconectado ate o Linux iniciar**; o driver `xpad` reconhece depois.

Se o boot falhar (arquivo ausente, initrd grande demais, kernel invalido), o XeLL volta a varrer arquivos e a mensagem se repete: leia a linha acima da repeticao (`Loading initrd ... Failed!`, `Initrd bigger than INITRD_MAX_SIZE`, `Aborting!`).

## Menu de boot (so se voce ativar)

No PC: `python3 xwt/tools/xwt-kboot.py <pendrive> --mode menu` (volte com `--mode auto`; `--mode text|safe|debug` inicia direto essa entrada). Com `menu`, o XeLL mostra um menu: **D-pad ↑/↓ escolhe, A confirma, B cancela**. Entradas deste pacote:

| Entrada | Quando usar |
|---|---|
| `xwt` | Normal: desktop gráfico, 6 threads. |
| `xwt_text` | Se a interface gráfica falhar: menu em texto. |
| `xwt_safe` | 1 CPU, sem zram/coldplug, texto. Para isolar travamentos do kernel. |
| `xwt_debug` | Como safe + `initcall_debug` e `ignore_loglevel`: mostra qual etapa do kernel trava. |

O tempo de escolha é 20 s (`timeout=20`); depois entra na entrada `default`.

### Adicionar seus próprios arquivos ao menu

1. Copie `.elf`/`.elf32` (homebrew) ou um kernel + initrd para `xwt/boot/` no pendrive.
2. No PC: `python3 xwt/tools/xwt-kboot.py <letra-ou-pasta-do-pendrive>` (use `--dry-run` para só ver).
3. As entradas `extra_*` aparecem no menu do XeLL. Só o bloco entre `XWT-EXTRA-BEGIN/END` é reescrito.

Limite do XeLL: cada entrada tem no máximo 255 caracteres e o `kboot.conf` até 16 KB.

## Depois do kernel: armazenamento

O Linux procura o pendrive por até 30 s (marcador: `kboot.conf` ou pasta `xwt`), tenta FAT32, exFAT, NTFS e ext4, e grava o resultado em `/run/xwt-storage.env` e `/run/xwt-storage.log`. No desktop, o app **Armazenamento** lista todos os dispositivos e abre qualquer um deles; **A** em um arquivo `.sh` executa o script.

O disco interno do Xbox 360 usa XTAF, que o Linux não monta.

## O que me enviar se continuar travando

A última tela completa do XeLL (foto), o modelo do console, o método de boot (RGH/JTAG) e o que estava ligado nas portas USB. Se chegar ao menu mas o Linux travar, use `xwt_debug` e envie a última tela.

## Relatorio automatico no pendrive

Depois que o Linux inicia, ele grava `xwt/logs/boot-report.txt` no pendrive (versao, linha do kernel, montagens, pacotes, video, audio, dmesg). Se algo falhar, tire o pendrive, abra esse arquivo no PC e envie. No Linux: `xwt-doctor save|print`.
