# Segurança das atualizações

- O `.xwpkg` é um arquivo tar.gz com manifesto interno e caminhos limitados a `/opt/xwt/modules/<componente>/`.
- O manifesto do canal fornece SHA-256; o updater exige URL no canal oficial GitHub Releases e compara o hash antes da extração.
- Links simbólicos, dispositivos, FIFOs, caminhos absolutos e travessia `..` são recusados.
- Os módulos são armazenados no USB e reaplicados no arranque; o sistema-base não é substituído.
- Um backup local do módulo anterior permite `xwt-update rollback COMPONENT`.
- SHA-256 detecta corrupção e divergência em relação ao manifesto, mas não é assinatura digital independente do mantenedor.
- Nenhuma operação de atualização pode escrever em NAND, KV, SMC ou firmware.
