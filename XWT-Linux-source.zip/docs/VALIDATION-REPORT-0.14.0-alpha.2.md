# Relatório de validação — XWT Linux 0.14.0-alpha.2

## Erro identificado na execução 86

A execução falhou no passo `Fetch pinned Free60 Xenon kernel port` com:

```text
Kernel option missing: ^CONFIG_PPC_XENON=y$
```

A checagem procurava `CONFIG_PPC_XENON=y` no defconfig bruto. Esse símbolo é declarado pelo patch Free60 em `arch/powerpc/platforms/xenon/Kconfig`, depende de `PPC64` e usa `default y`. Portanto, a checagem foi movida para depois do processamento Kconfig do Linux.

## Correções feitas

- O workflow verifica o patch Free60 e confirma a definição da plataforma Xenon e do alvo `zImage.xenon`.
- Adicionado `make linux-configure` como pré-verificação. O `.config` resultante precisa conter `CONFIG_PPC_XENON=y` e opções essenciais antes de começar a compilação integral.
- Removida a tentativa de empacotar `vmlinux` ELF64. O XeLL/libxenon atual implementa carregamento ELF32; o artefato esperado pelo port PowerPC é o wrapper `zImage.xenon`, produzido em ELF32 PowerPC mesmo quando incorpora o kernel PPC64.
- O empacotador agora valida cabeçalho ELF32 big-endian, máquina PowerPC, tabela de segmentos, segmento carregável, ponto de entrada, limites de memória e tamanho da imagem.
- O initramfs é validado como gzip contendo CPIO `newc` completo, com trailer, nomes seguros e tamanho comprimido dentro do limite de 32 MiB do carregador XeLL.
- O workflow de atualizações incrementais também verifica o manifesto SHA-256 e limita a extração do ZIP.
- Atualizadas as ações oficiais de checkout, cache e artefatos para versões Node 24 compatíveis.
- Corrigida a normalização de caminho no verificador CPIO do workflow, que antes poderia apagar `../` com `lstrip('./')`.

## Verificações executadas localmente

- 37 testes de host nos módulos de pacote, segurança, rede, core e atualizador.
- Parse dos dois arquivos YAML.
- `bash -n` em todos os blocos de execução: 17 etapas no workflow principal e 4 no workflow incremental.
- Conferência de integridade SHA-256 do ZIP de fonte antes de alterações e geração do novo manifesto ao empacotar a fonte final.

## O que ainda não foi comprovado

- A compilação completa Buildroot + Linux 7.2.
- A produção real de `zImage.xenon` com os program headers aceitos pelo XeLL.
- A inicialização do kernel e do initramfs em Xbox 360 físico.
- O funcionamento de vídeo, Ethernet, USB, controle e atualizador no hardware.

Os testes locais são estruturais e não substituem a execução de CI nem o teste físico.
