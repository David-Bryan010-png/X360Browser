# Estado do XWT Linux 0.15.0

## Integrado na fonte e na imagem prevista
- Boot XEX/XellLaunch2 -> XeLL Reloaded -> wrapper ELF32 `zImage.xenon` + initramfs, preservado da 0.14.0.
- Kernel Linux 7.2 baseado no port Free60, com DRM/framebuffer Xenos e USB.
- Correção Xenos preparada para tiles 32x32, largura/altura alinhadas, buffer DMA coerente, limites e troca transacional de buffers.
- Desktop SDL 1.2 + SDL_ttf compilado pelo `post-build.sh`, condicionado a `/dev/fb0` válido; fallback ao menu textual.
- Daemon `xwt-gamepad-keys` compilado e iniciado no boot, com reconexão para até quatro `/dev/input/js*`, D-pad/analógico e mapeamento A/Start, B/Back via uinput.
- Diagnóstico de vídeo executado no boot e salvo em `/run/xwt-video-report.txt`.
- Ferramenta Wi-Fi USB com `iw`, `wpa_supplicant` e DHCP; credenciais mantidas no USB.
- Ferramentas `dialog`, `less`, ALSA e fonte DejaVu selecionadas no Buildroot.
- BusyBox, shell, terminal, USB FAT32, Ethernet/DHCP, curl/OpenSSL/CA e atualizador incremental `.xwpkg` preservados.

## Ainda não entregue como componente funcional
- O navegador completo permanece separado; esta imagem não compila nem inclui NetSurf ou outro browser completo.
- Áudio real no hardware Xenon depende do driver/saída ALSA, ainda sem validação.
- Wi-Fi depende do chipset do adaptador USB e de seu driver no kernel; não há compatibilidade universal.
- Não há aceleração 2D/3D geral. O driver Xenos recebe uma correção de scanout/framebuffer, não um renderizador 3D.

## Validação pendente
- Compilação integral 0.15.0 pelo GitHub Actions após a atualização.
- Boot real em Xbox 360 RGH/JTAG, vídeo/HDMI, menu SDL e gamepad.
- Testes de Wi-Fi e áudio com periféricos compatíveis.

Os testes locais de host não são prova de boot físico. Nenhum passo grava NAND, KV, SMC ou firmware.
