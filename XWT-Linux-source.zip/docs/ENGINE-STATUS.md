# Estado do XWT Linux 0.14.0-alpha.2

## Disponível na base proposta
- Boot via XEX/XellLaunch2 -> XeLL Reloaded -> kernel Xenon ELF + initramfs.
- Kernel 7.2 com port Free60, framebuffer/Xenos experimental e suporte USB/armazenamento.
- BusyBox, console, terminal, menu textual, USB FAT32 e persistência dos módulos.
- Ethernet SIS190, DHCP, curl/OpenSSL/CA e atualizador incremental.
- Pacotes `.xwpkg` limitados a `/opt/xwt/modules/<componente>`.

## Adiado para módulos
- Desktop SDL, explorador gráfico e navegação completa por controle.
- NetSurf e motor do navegador.
- Áudio ALSA, Wi-Fi USB e firmwares específicos.
- Camada de compatibilidade gráfica e recursos avançados do Xenos.

## Não confirmado
- Buildroot completo em Actions nesta revisão.
- Boot em hardware físico, vídeo HDMI, controle, som e compatibilidade com periféricos.
- Aceleração 3D geral. O driver Xenos existente é experimental.
