# XWT Boot Manager — LEGADO

> **Fora do fluxo principal.** Desde esta versão, o XeLL carrega `vmlinux` + `initrd.img` direto da raiz do pendrive (veja `BOOT-FLOW.md`). O código em `boot/xwtboot` continua no repositório só como referência/experimento: o workflow não o compila e o pacote USB não o inclui. O layout abaixo (`X360WebTotal/Linux/`, `xwt-linux.elf`, `XWTBoot/config.cfg`) **não** é mais gerado.

# XWT Boot, persistência e teclado/mouse virtual (1.0.0)

## XWT Boot: o gerenciador de boot (separado do Linux)
O **XWT Boot** é um programa próprio (`xenon.elf`, feito com a libxenon). Ele **não é o Linux** e **não é o XeLL**:

- tem a **própria inicialização** (vídeo, USB, HD, montagem das partições, controle), o **próprio menu** e as
  **próprias configurações**;
- você **escolhe a pasta** (no pendrive ou HD) que tem os arquivos do Linux: um kernel ELF32 PowerPC
  (`xwt-linux.elf`, `zImage.xenon`, `vmlinux`...) e, se houver, o initrd (`rootfs.cpio.gz`, `initrd.img`...);
- carrega o Linux (janela de initrd de **128 MB**, lida direto do arquivo) e **salva as instruções de boot** em
  `XWTBoot/config.cfg` (pasta, kernel, initrd, modo, tempo, boot automático). No próximo boot o menu abre com
  contagem e **inicia sozinho**, sem selecionar nada; qualquer botão cancela a contagem.
- Menu: Iniciar Linux · Escolher a pasta do Linux · Modo (normal/texto/seguro/debug) · Tempo · Boot automático ·
  Informações · Reiniciar · Desligar. Controle: cima/baixo, **A** seleciona, **B** volta.
- Não lê `kboot.conf` e não usa rede. O arquivo `XWTBoot/config.cfg` é texto simples (dá para editar no PC; a
  linha `cmdline=` com `mode=custom` define uma linha de comando própria).

### Como iniciar o XWT Boot (todas levam ao mesmo programa)
1. **Direto pelo XEX, sem XeLL:** o pacote traz `xell-1f.bin` / `xell-2f.bin` ao lado do `default.xex`. O XellLaunch2
   carrega esse arquivo no lugar do XeLL — ele já é o XWT Boot.
2. **Pelo XeLL:** `xenon.elf` na raiz do pendrive; o XeLL carrega o ELF e **depois disso não participa mais**:
   o XWT Boot reinicializa tudo sozinho.
3. Por qualquer outro loader que execute ELF da libxenon (TFTP, menu do XeLL...).

O Linux continua uma coisa à parte: o XWT Boot só carrega o que estiver na pasta escolhida. Pode ser o **XWT Linux**
(Buildroot + kernel Free60, feito pelo workflow deste projeto, que segue o manual do Buildroot e do kernel Xenon do
Free60) ou outra distribuição PowerPC que você coloque em outra pasta e escolha no menu.

Se o passo "Build XWT Boot" falhar no GitHub, o pacote sai sem esses arquivos e volta ao formato antigo
(XeLL lê o `kboot.conf` da raiz, janela de 32 MB, sistema em pacotes de até 30 MB).

**Não testado em Xbox 360 real.** O XWT Boot pula a rede, o httpd e a leitura da configuração da NAND (só
inicializa o controlador da NAND, sem gravar). O Linux usa até 480 MB de RAM; um initrd enorme ocupa RAM, então
o rootfs grande continua indo em pacotes squashfs lidos do pendrive.

## Salvar dados (persistência)
Com o pendrive `X360WebTotal` montado, `/root`, `/home`, `/etc/xwt` e `/var/lib/xwt` passam a ficar em
`X360WebTotal/User/persist/` (montagem *bind*). Na primeira vez o conteúdo atual é copiado para lá.
`xwt-persist status` mostra `on N` ou `off`. Sem pendrive, nada é salvo.

## Mouse e teclado virtual no controle
- **L3** liga/desliga o **modo mouse**: analógico esquerdo move; **A** = clique esquerdo, **B** = direito,
  **X** = meio; **LB/RB** ou analógico direito rolam; D-pad continua nas setas; Start = Enter, Back = Esc.
- **R3** (ou **Y** no modo mouse) abre o **teclado virtual** em tela cheia: D-pad move, **A** digita, **B** fecha.
  Shift e Ctrl são teclas de um toque. As teclas são enviadas por um teclado virtual do kernel (uinput), então funcionam no terminal, no navegador e em apps SDL; se o uinput faltar, cai no método antigo (TIOCSTI).
- No desktop gráfico aparece uma faixa azul "Modo mouse (L3)" enquanto o modo está ligado, e o mouse aparece como seta e clica nos ícones; o teclado virtual abre sobre o terminal
  e os apps de texto. No desktop gráfico, R3 na tela **Arquivos** abre o teclado dentro do desktop (busca por nome; também dá para clicar nas teclas com o mouse do L3). No modo X11 (opcional) o teclado é o `xvkbd`.
- Nos jogos o modo mouse fica desligado.

## Wi-Fi salvo (sem editar arquivo no PC)
Configurações > Wi-Fi > **Escolher rede e digitar senha**: o Linux procura as redes, você escolhe, digita a
senha (R3 abre o teclado virtual) e ela é salva em `xwt/config/wpa_supplicant.conf` no pendrive.
Nos próximos boots o `S41wifi` reconecta sozinho. Várias redes podem ficar salvas; "Esquecer redes salvas" apaga.
Funciona só com adaptador Wi-Fi USB que tenha driver no kernel (depende do chipset; não testado).
