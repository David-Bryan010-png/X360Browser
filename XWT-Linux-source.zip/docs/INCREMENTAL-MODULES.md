# Atualizacoes incrementais do XWT Linux

## Modelo

- O build completo do core acontece uma vez para criar o kernel Xenon, os modulos de hardware, o initramfs e o USB inicial.
- Atualizacoes de aplicativos/servicos nao chamam Buildroot e nao recompilam kernel nem initramfs.
- O workflow `XWT Linux - Small Updates` empacota somente `updates/COMPONENT` em `.xwpkg` e atualiza o manifesto `latest.tsv` da release `xwt-linux-dev`.
- O cache `xwt-cross-toolchain` guarda o cross-compiler e o sysroot para componentes nativos.

## Criar um modulo novo

1. Criar `updates/NOME/opt/xwt/modules/NOME/` com os arquivos que devem ser instalados.
2. Se precisar compilar C/C++, adicionar `updates/NOME/build.sh`. Ele recebe o diretório de destino como primeiro argumento e dispõe de `CC`, `CXX`, `AR`, `RANLIB`, `STRIP`, `CROSS_COMPILE`, `SYSROOT`, `DESTDIR` e `CMAKE_TOOLCHAIN_FILE`. O script deve gravar apenas em `$DESTDIR/opt/xwt/modules/NOME/`.
3. Atualizar `XWT-Linux-source.zip` no repositório, mantendo `VERSION` e `REVISION.txt` consistentes.
4. Executar `XWT Linux - Small Updates` com `component=NOME`.
5. No Xbox, executar `xwt-update install NOME`.

O pacote é validado, baixado por HTTPS, conferido por SHA-256, aplicado em `/opt/xwt/modules/NOME` e guardado no USB para reaplicação no próximo boot. O rollback restaura tanto os arquivos quanto o pacote anterior.

## Quando precisa de build completo

Apenas mudanças no kernel, drivers, bootloader, initramfs-base, arquitetura/ABI ou bibliotecas compartilhadas que fazem parte do rootfs-base exigem nova imagem completa. Mudanças em binários e scripts de um módulo não exigem isso.

## Limites desta versão

O primeiro modulo `system` é uma ferramenta de status de sistema. Desktop, browser, áudio, Wi-Fi e novas funções serão adicionados separadamente quando tiverem código, dependências e testes próprios. O primeiro build completo e o teste físico no Xbox ainda são necessários.
