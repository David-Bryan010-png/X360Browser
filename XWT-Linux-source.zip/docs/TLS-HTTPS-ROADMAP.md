# HTTPS e navegador — roadmap

O core mínimo inclui `curl`, OpenSSL e certificados CA para permitir downloads HTTPS do atualizador. Ele ainda não inclui um navegador.

NetSurf SDL será tratado como módulo independente futuro, com seu próprio conjunto de dependências e testes. A inclusão desse módulo não deve exigir recompilação do kernel. Compatibilidade com sites atuais, JavaScript avançado, DRM, WebAssembly, YouTube e vídeo não será presumida sem testes específicos.
