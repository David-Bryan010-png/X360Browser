Coloque aqui arquivos .elf/.elf32 (homebrew) ou kernel + initrd e rode no PC:
  python3 X360WebTotal/tools/xwt-kboot.py <pasta-raiz-do-pendrive>
Eles aparecem no menu do XeLL (D-pad + A no controle). Veja BOOT-TROUBLESHOOTING-PT-BR.txt.
