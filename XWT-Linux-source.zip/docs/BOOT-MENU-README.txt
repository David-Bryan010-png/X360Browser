Para adicionar entradas ao menu do XeLL, coloque .elf/.elf32 (homebrew) ou kernel + initrd em xwt/boot/ (ou na raiz) e rode no PC:
  python3 xwt/tools/xwt-kboot.py <pasta-raiz-do-pendrive>
Elas aparecem no menu do XeLL (D-pad + A no controle) quando o modo menu estiver ativo. Veja BOOT-TROUBLESHOOTING-PT-BR.txt.
