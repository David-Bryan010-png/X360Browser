# Pesquisa: GPU Xenos (fase 7 do plano) — LONGO PRAZO, nada implementado

Isto é um roteiro de pesquisa, não uma funcionalidade. Hoje o XWT usa o framebuffer/DRM Xenos só para **mostrar imagem** (com a correção de tiles 32x32 do `patch_xenos_driver.py`). Não há aceleração 2D nem 3D.

## O que se sabe (com cautela)
- A GPU do Xbox 360 (Xenos/C1) é da família ATI com shaders unificados e eDRAM de 10 MiB. É parente da linha R500, mas **não é** um R500 de PC: formatos de comando, tiling e uso da eDRAM são próprios.
- O Mesa tem drivers para R300/R500 de PC (`r300g`); eles não rodam no Xenos sem trabalho grande de porte.
- O que existe do lado Free60 é código de console/homebrew (libxenon) e o driver de tela do kernel; documentação de registradores é incompleta.
- Não verifiquei fontes online para este roteiro; confirme tudo no código do kernel Free60 fixado e nas docs do projeto antes de planejar prazos.

## Marcos
1. **Coleta de dados no console** — rodar `xwt-gpu-probe` (Aplicativos > Diagnóstico da GPU) e anexar `xwt/logs/gpu-probe.txt`: nó DRM, modos, linhas do dmesg, regiões de I/O. Entrada para tudo abaixo.
2. **Mapa do driver atual** — ler no kernel Free60 o que o `DRM_XENOS` já faz (modesetting? fila de comandos?) e o que o patch do XWT altera.
3. **2D acelerado (blit/fill)** — só se o driver já expuser/permitir fila de comandos. Ganho: janelas e vídeo mais rápidos no X11. Sem isso, continua CPU (SDL/KDrive em software).
4. **API de 3D** — fora do alcance sem documentação de ISA/comandos; Mesa `softpipe` (fase 6) é a alternativa realista para GTK3/GL por software.
5. **Decisão** — só continuar para 3D se os marcos 1–3 mostrarem base sólida.

## Critério de pronto
Cada marco só vale com **evidência vinda de um Xbox real** (log, foto, medição). CI verde não conta.

## Segurança
`xwt-gpu-probe` só lê (`/sys`, `/proc`, `dmesg`). Nada grava NAND, KV, SMC ou firmware.
