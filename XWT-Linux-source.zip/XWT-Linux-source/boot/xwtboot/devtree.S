.section ".data"

.globl dt_blob_start
dt_blob_start:

.incbin "../dt/xenon.dtb" # relative to the build directory

.globl dt_blob_end
dt_blob_end:
