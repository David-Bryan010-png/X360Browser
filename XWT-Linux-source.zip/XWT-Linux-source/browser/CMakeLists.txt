cmake_minimum_required(VERSION 3.16)
project(x360_web_total_host_tests C)

set(CMAKE_C_STANDARD 99)
set(CMAKE_C_STANDARD_REQUIRED ON)
set(CMAKE_C_EXTENSIONS OFF)

add_library(xw_core STATIC
    src/xw_url.c
    src/xw_search.c
    src/xw_html.c
    src/xw_layout.c
    src/xw_http_protocol.c
    src/xw_dns_wire.c
    src/xw_dns_retry.c
    src/xw_config.c
    src/xw_graphics.c
    src/xw_ui.c
    src/xw_recovery.c
    src/xw_store.c
    src/xw_security.c
    src/xw_xute.c
    src/xw_xjs.c
)
target_include_directories(xw_core PUBLIC include)
if(MSVC)
    target_compile_options(xw_core PRIVATE /W4)
else()
    target_compile_options(xw_core PRIVATE -Wall -Wextra -Wpedantic)
endif()

add_executable(xw_core_tests tests/test_core.c)
target_link_libraries(xw_core_tests PRIVATE xw_core)
if(NOT MSVC)
    target_compile_options(xw_core_tests PRIVATE -Wall -Wextra -Wpedantic)
endif()

enable_testing()
add_test(NAME xw_core_tests COMMAND xw_core_tests)
