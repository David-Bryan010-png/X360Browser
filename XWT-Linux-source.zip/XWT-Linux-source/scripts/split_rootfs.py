#!/usr/bin/env python3
"""Split a Buildroot target tree into a small XeLL initramfs (stage 1) plus squashfs packs (stage 2).

XeLL loads exactly one initrd and refuses anything above 32 MiB. Everything listed in
linux/packs.rules is moved into squashfs packs (each <= --max-pack-mib) that the running
system mounts from the USB stick and overlays on top of the stage-1 directories.
"""
from __future__ import annotations

import argparse
import re
import gzip
import hashlib
import json
import os
import shutil
import stat
import subprocess
import sys
import tempfile
from pathlib import Path

DEFAULT_MAX_PACK = 28 * 1024 * 1024
XELL_INITRD_LIMIT = 30 * 1024 * 1024  # real XeLL limit is 32 MiB; keep headroom
INCOMPRESSIBLE = (".gz", ".xz", ".zst", ".bz2", ".png", ".jpg", ".ogg", ".mp3", ".zip", ".ko")
SYNTHETIC_DIRS = ("dev", "proc", "sys", "run", "tmp", "mnt", "root", "var/run")


def read_rules(path: Path) -> list[str]:
    prefixes: list[str] = []
    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.split("#", 1)[0].strip()
        if not line:
            continue
        parts = line.split()
        if len(parts) != 2 or parts[0] != "pack":
            raise ValueError(f"invalid packs.rules line: {raw!r}")
        prefix = parts[1].strip("/")
        if not prefix or ".." in prefix.split("/"):
            raise ValueError(f"invalid prefix in packs.rules: {raw!r}")
        prefixes.append(prefix)
    return prefixes


def real_prefix(target: Path, prefix: str) -> str:
    """Resolve symlinked path components (merged /usr: lib -> usr/lib) inside target."""
    cur = target.resolve()
    parts: list[str] = []
    for comp in prefix.split("/"):
        nxt = cur / comp
        if nxt.is_symlink():
            nxt = Path(os.path.realpath(nxt))
            if target.resolve() not in nxt.parents and nxt != target.resolve():
                raise ValueError(f"{prefix}: symlink escapes target")
            parts = list(nxt.relative_to(target.resolve()).parts)
        else:
            parts.append(comp)
        cur = nxt
    return "/".join(parts)


def walk(target: Path):
    for dirpath, dirnames, filenames in os.walk(target, followlinks=False):
        dirnames.sort()
        rel = Path(dirpath).relative_to(target)
        for name in sorted(dirnames + filenames):
            yield (rel / name).as_posix()


def under(path: str, prefixes: list[str]) -> bool:
    return any(path == p or path.startswith(p + "/") for p in prefixes)


# ---------------------------------------------------------------- cpio newc writer
def _hdr(ino: int, mode: int, nlink: int, size: int, name: bytes, rdev: tuple[int, int] = (0, 0)) -> bytes:
    fields = [ino, mode, 0, 0, nlink, 0, size, 0, 0, rdev[0], rdev[1], len(name) + 1, 0]
    head = b"070701" + b"".join(b"%08X" % v for v in fields)
    blob = head + name + b"\0"
    return blob + b"\0" * (-len(blob) % 4)


def build_cpio(target: Path, stage1_paths: list[str], extra_dirs: list[str]) -> bytes:
    out = bytearray()
    ino = 1
    seen: set[str] = set()

    def add(name: str, mode: int, data: bytes = b"", rdev=(0, 0), nlink: int = 1) -> None:
        nonlocal ino
        out.extend(_hdr(ino, mode, nlink, len(data), name.encode(), rdev))
        out.extend(data + b"\0" * (-len(data) % 4))
        seen.add(name)
        ino += 1

    for d in sorted(set(SYNTHETIC_DIRS) | set(extra_dirs)):
        parts = d.split("/")
        for i in range(1, len(parts) + 1):
            sub = "/".join(parts[:i])
            if sub not in seen and not (target / sub).exists():
                add(sub, stat.S_IFDIR | 0o755, nlink=2)
    add("dev/console", stat.S_IFCHR | 0o600, rdev=(5, 1))
    add("dev/null", stat.S_IFCHR | 0o666, rdev=(1, 3))
    # The kernel runs /init from an initramfs; Buildroot normally adds it as a link to sbin/init.
    if "init" not in stage1_paths and not (target / "init").exists():
        if not (target / "sbin/init").exists():
            raise ValueError("rootfs has neither /init nor /sbin/init")
        add("init", stat.S_IFLNK | 0o777, b"sbin/init")
    for rel in stage1_paths:
        if rel in seen:
            continue
        p = target / rel
        st = p.lstat()
        if stat.S_ISLNK(st.st_mode):
            add(rel, stat.S_IFLNK | 0o777, os.readlink(p).encode())
        elif stat.S_ISDIR(st.st_mode):
            add(rel, stat.S_IFDIR | (st.st_mode & 0o7777), nlink=2)
        elif stat.S_ISREG(st.st_mode):
            add(rel, stat.S_IFREG | (st.st_mode & 0o7777), p.read_bytes())
    out.extend(_hdr(0, 0, 1, 0, b"TRAILER!!!"))
    out.extend(b"\0" * (-len(out) % 512))
    return bytes(out)


# ---------------------------------------------------------------- pack planning
def estimate(path: Path) -> int:
    size = path.lstat().st_size
    return size if path.suffix.lower() in INCOMPRESSIBLE else int(size * 0.55) + 128


def plan_packs(target: Path, files: list[str], budget: int) -> list[list[str]]:
    packs: list[list[str]] = [[]]
    used = 0
    for rel in files:
        cost = estimate(target / rel)
        if cost > budget:
            raise ValueError(f"{rel} alone (~{cost} bytes) does not fit in one pack")
        if used + cost > budget and packs[-1]:
            packs.append([])
            used = 0
        packs[-1].append(rel)
        used += cost
    return packs


def make_squashfs(target: Path, rels: list[str], out: Path, mksquashfs: str) -> None:
    with tempfile.TemporaryDirectory(dir=out.parent) as tmp:
        root = Path(tmp) / "root"
        for rel in rels:
            src, dst = target / rel, root / rel
            dst.parent.mkdir(parents=True, exist_ok=True)
            if src.is_symlink():
                os.symlink(os.readlink(src), dst)
            elif src.is_dir():
                dst.mkdir(exist_ok=True)
            else:
                try:
                    os.link(src, dst)
                except OSError:
                    shutil.copy2(src, dst)
        subprocess.run([mksquashfs, str(root), str(out), "-comp", "zstd", "-Xcompression-level", "15",
                        "-b", "128K", "-no-xattrs", "-all-root", "-noappend", "-quiet"], check=True)


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()



# Arquivos que o boot precisa ANTES de montar os packs: nunca sao movidos pela regra automatica.
PROTECTED = re.compile(
    r"(^|/)(busybox|kmod|modprobe|insmod|mount|umount|losetup|blkid|sh|init|"
    r"ld-[^/]*|libc[.-][^/]*|libm[.-][^/]*|libdl[^/]*|libpthread[^/]*|librt[^/]*|libresolv[^/]*|libnss[^/]*|"
    r"libgcc_s[^/]*|libz[.][^/]*|libzstd[^/]*|liblzma[^/]*|libkmod[^/]*|libcrypto[^/]*|libssl[^/]*|"
    r"libmount[^/]*|libblkid[^/]*|libuuid[^/]*|libcap[^/]*|libutil[^/]*|libstdc[^/]*|xwt-[^/]*)$"
)
SPILL_DIRS = ("usr/bin", "usr/sbin", "usr/lib", "usr/libexec", "usr/games")
SPILL_MIN = 128 * 1024


def spill_candidates(target: Path, stage1: list[str]) -> list[tuple[int, str]]:
    """Big regular files that can safely live in a pack (overlaid over their own directory)."""
    out = []
    for rel in stage1:
        if not any(rel.startswith(d + "/") for d in SPILL_DIRS):
            continue
        if "/modules/" in rel or PROTECTED.search(rel):
            continue
        p = target / rel
        try:
            st = p.lstat()
        except OSError:
            continue
        if stat.S_ISREG(st.st_mode) and st.st_size >= SPILL_MIN:
            out.append((st.st_size, rel))
    out.sort(reverse=True)
    return out


def report_sizes(target: Path, stage1: list[str], top: int = 15) -> str:
    sizes: dict[str, int] = {}
    for rel in stage1:
        p = target / rel
        try:
            st = p.lstat()
        except OSError:
            continue
        if stat.S_ISREG(st.st_mode):
            parts = rel.split("/")
            key = "/".join(parts[:3]) if len(parts) > 2 else rel
            sizes[key] = sizes.get(key, 0) + st.st_size
    rows = sorted(sizes.items(), key=lambda kv: -kv[1])[:top]
    return "\n".join(f"  {size / 1048576:8.2f} MiB  {name}" for name, size in rows)


def check_init_chain(target: Path, stage1: list[str]) -> str:
    """Follow /init through symlinks (as the kernel does) and require an executable regular file inside stage 1."""
    have = set(stage1)
    cur = "init"
    if cur not in have and not (target / "init").exists():
        cur = "sbin/init"
    for _ in range(40):
        parts = [x for x in cur.split("/") if x]
        real: list[str] = []
        redo = None
        for i, part in enumerate(parts):
            if part == "..":
                if real:
                    real.pop()
                continue
            cand = "/".join(real + [part])
            q = target / cand
            if q.is_symlink():
                tgt = os.readlink(q)
                base = [] if tgt.startswith("/") else real
                redo = "/".join(base + [tgt.lstrip("/")] + parts[i + 1:])
                break
            real.append(part)
        if redo is not None:
            cur = redo
            continue
        rel = "/".join(real)
        q = target / rel
        if not q.is_file() or not os.access(q, os.X_OK):
            raise SystemExit(f"/init chain broken: {rel} is not an executable file in the rootfs")
        if rel not in have:
            raise SystemExit(f"/init chain broken: {rel} would NOT be in initrd.img (moved to a pack). The kernel would panic with 'Unable to mount root fs'.")
        return rel
    raise SystemExit("/init chain broken: too many symlink levels")


def split(target: Path, rules: Path, outdir: Path, max_pack: int, mksquashfs: str) -> dict:
    target = target.resolve()
    prefixes = sorted({real_prefix(target, p) for p in read_rules(rules)})
    everything = list(walk(target))
    spilled: set[str] = set()
    outdir.mkdir(parents=True, exist_ok=True)
    for old in outdir.glob("xwt-pack-*.sqfs"):
        old.unlink()

    def layout():
        moved_dirs = [p for p in everything if under(p, prefixes)]
        mf = [p for p in moved_dirs if not (target / p).is_dir() or (target / p).is_symlink()]
        mf += sorted(spilled)
        s1 = [p for p in everything if not under(p, prefixes) and p not in spilled]
        parents = sorted({str(Path(f).parent) for f in spilled})
        ov = sorted({*prefixes, *[d for d in parents if not under(d, prefixes)]}, key=lambda x: (x.count("/"), x))
        s1 += [p for p in ov if p not in s1]
        return mf, sorted(set(s1)), ov

    moved_files, stage1, overlays = layout()
    initrd = gzip.compress(build_cpio(target, stage1, overlays), compresslevel=9, mtime=0)
    # Se o stage 1 passar do limite do XeLL, move automaticamente os maiores arquivos nao criticos para packs.
    for _round in range(8):
        if len(initrd) <= XELL_INITRD_LIMIT:
            break
        over = len(initrd) - XELL_INITRD_LIMIT
        need = int(over * 1.6) + 2 * 1024 * 1024
        got = 0
        for size, rel in spill_candidates(target, stage1):
            spilled.add(rel)
            got += size
            if got >= need:
                break
        else:
            if got == 0:
                break
        print(f"AVISO: stage 1 com {len(initrd)} bytes (> {XELL_INITRD_LIMIT}); movendo {len(spilled)} arquivos grandes para packs.", file=sys.stderr)
        moved_files, stage1, overlays = layout()
        initrd = gzip.compress(build_cpio(target, stage1, overlays), compresslevel=9, mtime=0)
    if len(initrd) > XELL_INITRD_LIMIT:
        raise SystemExit(f"stage-1 initramfs is {len(initrd)} bytes, above {XELL_INITRD_LIMIT} even after moving large files.\n"
                         "Maiores itens no stage 1:\n" + report_sizes(target, stage1) +
                         "\nAdicione prefixos em linux/packs.rules.")
    prefixes = overlays
    print(f"init chain OK: /init -> {check_init_chain(target, stage1)}")
    (outdir / "rootfs.cpio.gz").write_bytes(initrd)

    packs: list[dict] = []
    if moved_files:
        budget = max_pack
        for _ in range(6):
            plan = plan_packs(target, moved_files, budget)
            for old in outdir.glob("xwt-pack-*.sqfs"):
                old.unlink()
            names = []
            for i, rels in enumerate(plan, 1):
                out = outdir / f"xwt-pack-{i:02d}.sqfs"
                make_squashfs(target, rels, out, mksquashfs)
                names.append(out)
            if all(p.stat().st_size <= max_pack for p in names):
                break
            budget = int(budget * 0.8)
        else:
            raise SystemExit("could not fit packs under the size limit")
        for p in names:
            packs.append({"name": p.name, "size": p.stat().st_size, "sha256": sha256(p)})
    (outdir / "packs.list").write_text("".join(f"{p['sha256']}  {p['name']}  {p['size']}\n" for p in packs), encoding="ascii")
    (outdir / "overlays.list").write_text("".join(f"{p}\n" for p in prefixes), encoding="ascii")
    meta = {"initrd_bytes": len(initrd), "packs": packs, "overlays": prefixes, "spilled_files": len(spilled)}
    (outdir / "packs.json").write_text(json.dumps(meta, indent=2) + "\n", encoding="utf-8")
    return meta


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--target", required=True, type=Path)
    ap.add_argument("--rules", required=True, type=Path)
    ap.add_argument("--outdir", required=True, type=Path)
    ap.add_argument("--max-pack-mib", type=float, default=DEFAULT_MAX_PACK / 1048576)
    ap.add_argument("--mksquashfs", default="mksquashfs")
    a = ap.parse_args()
    try:
        meta = split(a.target, a.rules, a.outdir, int(a.max_pack_mib * 1048576), a.mksquashfs)
    except (ValueError, OSError, subprocess.CalledProcessError) as exc:
        print(f"ERRO split_rootfs: {type(exc).__name__}: {exc}", file=sys.stderr)
        return 1
    print(json.dumps(meta, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
