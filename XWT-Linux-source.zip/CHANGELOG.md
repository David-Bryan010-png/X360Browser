# Changelog

## 0.14.0-alpha.2 — Minimal Core + Incremental Updates
- Primeira entrega reduzida para kernel Xenon, rootfs mínimo, console, USB, Ethernet/DHCP e HTTPS.
- Boot em `default.xex` -> XellLaunch2 -> XeLL Reloaded -> ELF + initramfs.
- Cria pacotes `.xwpkg` separados, manifesto por release e atualizador residente no console.
- Instalação atômica por componente, persistência USB, verificação SHA-256 e rollback que sobrevive ao reboot.
- Primeiro módulo `system` publicado junto com o core.
- Cache do cross-toolchain para que módulos C/C++ possam compilar sem executar Buildroot novamente.
- Adia desktop, browser, áudio, Wi-Fi e expansões gráficas.
- Corrige a ordem de montagem de devtmpfs/devpts e preserva instalação de módulos do kernel no rootfs.

## 0.14.0-alpha.1
- Estrutura inicial de boot XEX/ELF e atualização modular proposta.
