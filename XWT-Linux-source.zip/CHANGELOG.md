# Changelog

## 0.15.0 — Desktop + Input + Recovery Update

- Promove a fonte completa da versão 0.14.0-alpha.2 para 0.15.0, preservando o fluxo modular `.xwpkg` e o boot XEX/ELF.
- Compila e instala o desktop SDL 1.2 + SDL_ttf na imagem principal; o boot tenta a interface gráfica e retorna ao menu textual quando o framebuffer/SDL não está disponível.
- Valida `/dev/fb0` com `FBIOGET_VSCREENINFO` e `FBIOGET_FSCREENINFO`, sem inventar resoluções nem desenhar fora do modo real detectado.
- Corrige o caminho do framebuffer Xenos com alocação de tiles 32×32, buffer substituído de forma transacional, DMA de 32 bits, blit inicial e clipping de danos.
- Compila e inicia `xwt-gamepad-keys`: até quatro dispositivos `js*`, reconexão, D-pad/analógico, A/Start para confirmar e B/Back para voltar via `uinput`.
- Adiciona diagnóstico de vídeo na inicialização, grava relatório em `/run/xwt-video-report.txt` e mantém fallback textual.
- Adiciona assistente Wi-Fi USB usando `iw`, `wpa_supplicant` e DHCP; credenciais ficam no USB, fora da NAND.
- Inclui ferramentas de sistema (dialog, less, ALSA utilities) e fonte DejaVu para a interface.
- Ativa o subsistema de teclado do kernel necessário ao dispositivo `uinput`.
- Mantém rede cabeada, persistência USB, atualizador modular, verificações de integridade e bloqueio de gravação NAND.
- Atualiza scripts de verificação para cobrir desktop, entrada, rede, vídeo e regressões do empacotador.

**Limites conhecidos:** não inclui aceleração 3D completa, navegador NetSurf/XWT integrado, suporte universal a adaptadores Wi-Fi, nem áudio funcional sem driver/saída suportados. O teste físico no Xbox 360 ainda é obrigatório.

## 0.14.0-alpha.2 — Minimal Core + Incremental Updates
- Primeira entrega reduzida para kernel Xenon, rootfs mínimo, console, USB, Ethernet/DHCP e HTTPS.
- Boot em `default.xex` -> XellLaunch2 -> XeLL Reloaded -> ELF + initramfs.
- Cria pacotes `.xwpkg` separados, manifesto por release e atualizador residente no console.
- Instalação atômica por componente, persistência USB, verificação SHA-256 e rollback que sobrevive ao reboot.
- Cache do cross-toolchain para que módulos C/C++ possam compilar sem executar Buildroot novamente.
- Corrige a ordem de montagem de devtmpfs/devpts e preserva instalação de módulos do kernel no rootfs.

## Revisão corretiva do workflow — 0.14.0-alpha.2
- Corrigida a verificação prematura de `CONFIG_PPC_XENON`.
- Restaurado o wrapper ELF32 `zImage.xenon` para XeLL; removida a tentativa incorreta de empacotar `vmlinux` ELF64.
- Fortalecida a validação dos segmentos ELF, limites XeLL, CPIO, gzip e manifesto SHA-256.
