# Changelog

## 1.0.0 — Estavel (etapas 2 e 3)

- **Nova interface (base nas fotos de referencia):** papel de parede com logo XWT, icones na esquerda (Navegador, Arquivos, Jogos, Terminal, Configuracoes, Ajuda, Desligar), barra de tarefas com botao XWT, rede, USB e relogio, e janela de Configuracoes com menu lateral (Sistema, Rede, Video, Audio, Controle, Armazenamento, Atualizacoes, Logs, Sobre). Icones desenhados por codigo (sem arquivos de imagem).
- **Relatorio de boot** em X360WebTotal/logs/boot-report.txt (`xwt-doctor`).

- **Audio e video:** `xwt-audio` (USB audio, volume, teste, S35audio), `xwt-video` (saidas e modos), apps Audio/Video no desktop, ALSA amixer/speaker-test, kernel com snd-usb-audio.

- Versao 1.0.0: boot automatico, sistema em pacotes de 30 MiB, desktop, armazenamento, controle, rede.
- **Jogos:** PrBoom (Doom) incluido no sistema, launcher `xwt-game`, app "Jogos" no desktop e mapa de botoes proprio para o jogo.
- Criterio de 1.0 que ainda depende de teste no console: boot ate o desktop e Doom abrindo.

## 0.15.0 (revisao 6) — Sistema em pacotes (stage 1 + packs de 30 MiB)

- **Causa do `Failed! ... rootfs.cpio.gz`:** o XeLL recusa initrd acima de 32 MiB. O rootfs agora e dividido: initramfs pequeno (stage 1) + pacotes squashfs de ate 28 MiB (stage 2) em `X360WebTotal/Linux/packs/`.
- `scripts/split_rootfs.py`, `linux/packs.rules`, `xwt-packs` (monta e faz overlay), kernel com squashfs/zstd/overlayfs/loop.
- O empacotador valida cada pacote (tamanho, SHA-256, <= 30 MiB). Sem pacotes o sistema usa o menu de texto.

## 0.15.0 (revisao 5) — Boot automatico e revisao de bugs

- **Boot automatico:** `timeout=0` no `kboot.conf`; o XeLL entra direto em `xwt_linux_usb`, sem contagem e sem esperar o controle. O menu virou opcional (`xwt-kboot.py --mode menu`); `--mode text|safe|debug|auto` troca a entrada padrao.
- **Por que:** no XeLL o menu le o controle durante a contagem e qualquer movimento da selecao desliga o timeout (espera infinita); se o boot falha, o XeLL volta a varrer arquivos e repete mensagens.
- **Validacao:** o empacotador rejeita `kboot.conf` com CRLF (o XeLL nao remove `\r`) e sem `timeout=`.
- **Workflow:** novo passo "Report image sizes" mostra tamanho do kernel/initrd contra o limite de 32 MiB do XeLL e os maiores diretorios do rootfs.
- **Correcoes:** coldplug limitado a barramentos plugaveis (`usb:`/`hid:`); zram carregado sem parametro obsoleto; variaveis locais do desktop sem sombra de globais.


## 0.15.0 (revisao 4) — Menu de boot, armazenamento e travamento no "usb init"

- **Diagnostico:** ` * usb init` e uma mensagem do proprio XeLL, impressa antes do menu e antes de qualquer codigo do XWT. O travamento ali e do bootloader (etapa USB do XeLL), nao do kernel/desktop/driver Xenos. Novo guia `docs/BOOT-TROUBLESHOOTING-PT-BR.md` (incluido no USB) com passos ordenados, incluindo iniciar sem USB e plugar depois.
- **Menu de boot pelo controle:** `kboot.conf` agora tem 4 entradas (normal, texto, safe, debug com `initcall_debug`); D-pad + A no menu do XeLL, 20 s de tempo. O empacotador valida o limite de 255 caracteres por entrada e 16 KB do XeLL.
- **Seu proprio arquivo no menu:** `X360WebTotal/tools/xwt-kboot.py` (PC) varre `X360WebTotal/Boot/` e adiciona `.elf` ou kernel+initrd ao menu do XeLL.
- **Armazenamento:** novo `xwt-storage` (espera ate 30 s pelo pendrive, tenta FAT32/exFAT/NTFS/ext4, nao depende mais so de `sdX1`, relata `mounted/unmarked/unavailable` e grava log). Testado com arvore /proc, /sys e /dev simulada.
- **Desktop:** app "Armazenamento" lista e abre qualquer dispositivo; `A` em um `.sh` executa o script.
- **Modos de boot:** `xwt.text=1` (sem interface grafica), `xwt.safe=1` (sem zram/coldplug), `xwt.debug=1`.


## 0.15.0 (revisao 3) — Interface e sistema

- **Desktop:** barra lateral com status ao vivo (RAM com barra, IP/rota, temperatura via hwmon, tempo ligado, espaco livre no USB); cabecalho em degrade; 12 apps em grade de 3/4 colunas (novos: Video, Controle, Atualizacoes, Logs); textos longos truncados com reticencias em vez de vazar da tela.
- **Desempenho da interface:** a tela so e redesenhada quando ha entrada ou a cada 2 s (antes: ~22 quadros/s consultando rede e disco a cada quadro).
- **Pagina Sistema:** kernel, nucleos, carga, temperatura, uso de memoria com barra, modo de video e armazenamento.
- **Navegador:** o desktop passa a abrir `/opt/xwt/modules/browser/bin/xwt-browser` quando o modulo `browser` for instalado via `xwt-update`, antes de tentar NetSurf.
- **Sistema:** swap comprimido em zram (25% da RAM, ate 192 MB) via `S05zram`; fuso horario POSIX (padrao `BRT3`, configuravel em `X360WebTotal/config/timezone` no USB).

## 0.15.0 (revisao 2) — Correcoes de compilacao, driver Xenos e hardware

- **Driver Xenos:** o patcher (`xenos_patchlib.py`) gerava C invalido no `xenos.c` real (`\"` literal na mensagem de DMA e quebra de linha dentro da string de dimensoes), derrubando a compilacao do kernel. Corrigido na origem e coberto por teste de regressao; os remendos em sed/python dentro do workflow foram removidos.
- **Workflow:** erro de sintaxe Python no passo de publicacao (aspas duplas extras) corrigido; copia do proprio workflow independente do nome do arquivo; binarios, fonte e curl ausentes agora falham o build cedo; chave de cache do toolchain alinhada entre `build-xex-from-zip` e `xwt-small-updates`.
- **Kernel:** opcoes XWT movidas para `linux/xwt-kernel.fragment` (editavel sem mexer no YAML); adiciona NLS/VFAT, force feedback e LEDs do xpad, adaptadores USB Ethernet comuns, SysRq e `/proc/config.gz`.
- **Hardware:** novo coldplug `S10modules` carrega drivers de dispositivos ja conectados (USB Wi-Fi, Ethernet, audio, controles); mdev com `FEATURE_MDEV_EXEC` e carregamento de firmware; firmware apenas dos chipsets Wi-Fi USB habilitados no kernel (Ralink RT2xxx, MediaTek MT7601U/MT76x0/MT76x2, Realtek 81xx).
- **Rede:** `S40network` espera o link subir (ate 10 s) antes do DHCP, incluindo NICs USB.
- **Ferramentas:** evtest (teste de controle), pciutils, ethtool, nano e htop; menu de texto ganha Wi-Fi, teste de controle e visualizador de logs.


## 0.15.0 — Desktop + Input + Recovery Update

- Promove a fonte completa da versão 0.14.0-alpha.2 para 0.15.0, preservando o fluxo modular `.xwpkg` e o boot XEX/ELF.
- Compila e instala o desktop SDL 1.2 + SDL_ttf na imagem principal; o boot tenta a interface gráfica e retorna ao menu textual quando o framebuffer/SDL não está disponível.
- Valida `/dev/fb0` com `FBIOGET_VSCREENINFO` e `FBIOGET_FSCREENINFO`, sem inventar resoluções nem desenhar fora do modo real detectado.
- Corrige o caminho do framebuffer Xenos com alocação de tiles 32×32, buffer substituído de forma transacional, DMA de 32 bits, blit inicial e clipping de danos.
- Compila e inicia `xwt-gamepad-keys`: até quatro dispositivos `js*`, reconexão, D-pad/analógico, A/Start para confirmar e B/Back para voltar via `uinput`.
- Adiciona diagnóstico de vídeo na inicialização, grava relatório em `/run/xwt-video-report.txt` e mantém fallback textual.
- Adiciona assistente Wi-Fi USB usando `iw`, `wpa_supplicant` e DHCP; credenciais ficam no USB, fora da NAND.
- Inclui ferramentas de sistema (dialog, less, ALSA utilities) e fonte DejaVu para a interface.
- Ativa o subsistema de teclado do kernel necessário ao dispositivo `uinput`.
- Mantém rede cabeada, persistência USB, atualizador modular, verificações de integridade e bloqueio de gravação NAND.
- Atualiza scripts de verificação para cobrir desktop, entrada, rede, vídeo e regressões do empacotador.

**Limites conhecidos:** não inclui aceleração 3D completa, navegador NetSurf/XWT integrado, suporte universal a adaptadores Wi-Fi, nem áudio funcional sem driver/saída suportados. O teste físico no Xbox 360 ainda é obrigatório.

## 0.14.0-alpha.2 — Minimal Core + Incremental Updates
- Primeira entrega reduzida para kernel Xenon, rootfs mínimo, console, USB, Ethernet/DHCP e HTTPS.
- Boot em `default.xex` -> XellLaunch2 -> XeLL Reloaded -> ELF + initramfs.
- Cria pacotes `.xwpkg` separados, manifesto por release e atualizador residente no console.
- Instalação atômica por componente, persistência USB, verificação SHA-256 e rollback que sobrevive ao reboot.
- Cache do cross-toolchain para que módulos C/C++ possam compilar sem executar Buildroot novamente.
- Corrige a ordem de montagem de devtmpfs/devpts e preserva instalação de módulos do kernel no rootfs.

## Revisão corretiva do workflow — 0.14.0-alpha.2
- Corrigida a verificação prematura de `CONFIG_PPC_XENON`.
- Restaurado o wrapper ELF32 `zImage.xenon` para XeLL; removida a tentativa incorreta de empacotar `vmlinux` ELF64.
- Fortalecida a validação dos segmentos ELF, limites XeLL, CPIO, gzip e manifesto SHA-256.

## 1.0.0 (pre-release adds)
- XWT Boot: gerenciador de boot independente (ELF próprio, libxenon): menu, escolha da pasta do Linux, perfil salvo em `XWTBoot/config.cfg`, boot automático, initrd de até 128 MB; inicia por `xell-1f/2f.bin` (XEX direto) ou `xenon.elf` (via XeLL).
- Persistência (`xwt-persist`) em `X360WebTotal/User/persist`.
- L3: modo mouse com o controle; R3/Y: teclado virtual (`xwt-osk`).
- Apps (Aplicativos), jogos (LBreakout2, LTris, OpenTyrian), Doom com WAD shareware; controle com gatilhos, Guide e auto-repeat.
