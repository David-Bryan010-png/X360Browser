/*
 * XWT Linux 0.15.0 - Xbox controller to Linux keyboard bridge.
 * Supports hotplug/reconnect and up to four /dev/input/js* devices.
 * It never accesses NAND, SMC, KV, or firmware.
 */
#define _POSIX_C_SOURCE 200809L
#include <errno.h>
#include <fcntl.h>
#include <linux/input.h>
#include <linux/joystick.h>
#include <linux/uinput.h>
#include <poll.h>
#include <signal.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <sys/ioctl.h>
#include <time.h>
#include <unistd.h>

#define XWT_MAX_JOYSTICKS 4
#define XWT_AXIS_DEADZONE 17000
#define XWT_SCAN_MS 1000
#define XWT_POLL_MS 40
#define XWT_KEY_COUNT (KEY_MAX + 1)

typedef struct {
    int fd;
    char path[32];
    int16_t axes[8];
    uint8_t buttons[32];
} XwtJoystick;

static volatile sig_atomic_t running = 1;
static int uinput_fd = -1;
static uint8_t emitted[XWT_KEY_COUNT];
static XwtJoystick joysticks[XWT_MAX_JOYSTICKS];

static void on_signal(int signal_number)
{
    (void)signal_number;
    running = 0;
}

static int write_all(int fd, const void *data, size_t size)
{
    const uint8_t *cursor = (const uint8_t *)data;
    while (size > 0) {
        ssize_t written = write(fd, cursor, size);
        if (written < 0) {
            if (errno == EINTR) continue;
            return -1;
        }
        if (written == 0) return -1;
        cursor += (size_t)written;
        size -= (size_t)written;
    }
    return 0;
}

static int create_virtual_keyboard(void)
{
    static const unsigned short keys[] = {
        KEY_UP, KEY_DOWN, KEY_LEFT, KEY_RIGHT, KEY_ENTER, KEY_ESC
    };
    struct uinput_setup setup;
    size_t i;
    int fd = open("/dev/uinput", O_WRONLY | O_CLOEXEC);
    if (fd < 0) return -1;

    /* EV_SYN is provided by the input core; register the key capability only. */
    if (ioctl(fd, UI_SET_EVBIT, EV_KEY) < 0) {
        close(fd);
        return -1;
    }
    for (i = 0; i < sizeof(keys) / sizeof(keys[0]); ++i) {
        if (ioctl(fd, UI_SET_KEYBIT, keys[i]) < 0) {
            close(fd);
            return -1;
        }
    }

    memset(&setup, 0, sizeof(setup));
    (void)snprintf(setup.name, sizeof(setup.name), "XWT Xbox Controller Keyboard");
    setup.id.bustype = BUS_USB;
    setup.id.vendor = 0x045e;
    setup.id.product = 0x028e;
    setup.id.version = 1;
    if (ioctl(fd, UI_DEV_SETUP, &setup) < 0 || ioctl(fd, UI_DEV_CREATE) < 0) {
        close(fd);
        return -1;
    }
    return fd;
}

static void emit_key(unsigned short code, int down)
{
    struct input_event event;
    if (uinput_fd < 0 || code >= XWT_KEY_COUNT) return;
    memset(&event, 0, sizeof(event));
    event.type = EV_KEY;
    event.code = code;
    event.value = down ? 1 : 0;
    if (write_all(uinput_fd, &event, sizeof(event)) != 0) return;
    memset(&event, 0, sizeof(event));
    event.type = EV_SYN;
    event.code = SYN_REPORT;
    (void)write_all(uinput_fd, &event, sizeof(event));
}

static int16_t choose_axis(int16_t hat, int16_t stick)
{
    if (hat <= -XWT_AXIS_DEADZONE || hat >= XWT_AXIS_DEADZONE) return hat;
    return stick;
}

static void refresh_keys(void)
{
    uint8_t wanted[XWT_KEY_COUNT];
    size_t i;
    memset(wanted, 0, sizeof(wanted));

    for (i = 0; i < XWT_MAX_JOYSTICKS; ++i) {
        const XwtJoystick *joy = &joysticks[i];
        int16_t x, y;
        if (joy->fd < 0) continue;
        x = choose_axis(joy->axes[6], joy->axes[0]);
        y = choose_axis(joy->axes[7], joy->axes[1]);
        /* Linux xpad exposes the D-pad as ABS_HAT0X/Y (js axes 6/7).
         * The primary stick remains a fallback for devices without a hat. */
        if (y < -XWT_AXIS_DEADZONE) wanted[KEY_UP] = 1;
        if (y > XWT_AXIS_DEADZONE) wanted[KEY_DOWN] = 1;
        if (x < -XWT_AXIS_DEADZONE) wanted[KEY_LEFT] = 1;
        if (x > XWT_AXIS_DEADZONE) wanted[KEY_RIGHT] = 1;
        /* Standard xpad mapping: A/Start = confirm; B/Back = cancel. */
        if (joy->buttons[0] || joy->buttons[7]) wanted[KEY_ENTER] = 1;
        if (joy->buttons[1] || joy->buttons[6]) wanted[KEY_ESC] = 1;
    }

    for (i = 0; i < XWT_KEY_COUNT; ++i) {
        if (wanted[i] != emitted[i]) {
            emit_key((unsigned short)i, wanted[i] != 0);
            emitted[i] = wanted[i];
        }
    }
}

static void close_joystick(XwtJoystick *joy)
{
    if (joy->fd >= 0) close(joy->fd);
    joy->fd = -1;
    memset(joy->axes, 0, sizeof(joy->axes));
    memset(joy->buttons, 0, sizeof(joy->buttons));
    joy->path[0] = '\0';
    refresh_keys();
}

static void scan_joysticks(void)
{
    unsigned i;
    char path[32];
    for (i = 0; i < XWT_MAX_JOYSTICKS; ++i) {
        if (joysticks[i].fd >= 0) continue;
        (void)snprintf(path, sizeof(path), "/dev/input/js%u", i);
        joysticks[i].fd = open(path, O_RDONLY | O_NONBLOCK | O_CLOEXEC);
        if (joysticks[i].fd >= 0) {
            (void)snprintf(joysticks[i].path, sizeof(joysticks[i].path), "%s", path);
            fprintf(stderr, "xwt-gamepad-keys: conectado %s\n", path);
        }
    }
}

static void process_event(XwtJoystick *joy, struct js_event event)
{
    unsigned type = event.type & (unsigned char)~JS_EVENT_INIT;
    if (type == JS_EVENT_AXIS && event.number < 8) {
        joy->axes[event.number] = event.value;
        refresh_keys();
    } else if (type == JS_EVENT_BUTTON && event.number < 32) {
        joy->buttons[event.number] = event.value ? 1U : 0U;
        refresh_keys();
    }
}

int main(void)
{
    unsigned i;
    struct timespec last_scan = {0, 0};
    signal(SIGTERM, on_signal);
    signal(SIGINT, on_signal);
    for (i = 0; i < XWT_MAX_JOYSTICKS; ++i) joysticks[i].fd = -1;

    while (running) {
        struct pollfd fds[XWT_MAX_JOYSTICKS];
        int map[XWT_MAX_JOYSTICKS];
        nfds_t count = 0;
        struct timespec now;

        if (uinput_fd < 0) {
            uinput_fd = create_virtual_keyboard();
            if (uinput_fd < 0) {
                nanosleep(&(struct timespec){0, 500000000L}, NULL);
                continue;
            }
            fprintf(stderr, "xwt-gamepad-keys: teclado virtual ativo\n");
        }

        (void)clock_gettime(CLOCK_MONOTONIC, &now);
        if (last_scan.tv_sec == 0 ||
            (now.tv_sec - last_scan.tv_sec) * 1000L +
            (now.tv_nsec - last_scan.tv_nsec) / 1000000L >= XWT_SCAN_MS) {
            scan_joysticks();
            last_scan = now;
        }

        for (i = 0; i < XWT_MAX_JOYSTICKS; ++i) {
            if (joysticks[i].fd >= 0) {
                fds[count].fd = joysticks[i].fd;
                fds[count].events = POLLIN;
                fds[count].revents = 0;
                map[count] = (int)i;
                ++count;
            }
        }

        if (count == 0) {
            nanosleep(&(struct timespec){0, 100000000L}, NULL);
            continue;
        }

        {
            int ready = poll(fds, count, XWT_POLL_MS);
            if (ready < 0) {
                if (errno == EINTR) continue;
                nanosleep(&(struct timespec){0, 50000000L}, NULL);
                continue;
            }
            for (i = 0; i < count; ++i) {
                XwtJoystick *joy = &joysticks[map[i]];
                if (fds[i].revents & (POLLERR | POLLHUP | POLLNVAL)) {
                    fprintf(stderr, "xwt-gamepad-keys: desconectado %s\n", joy->path);
                    close_joystick(joy);
                    continue;
                }
                if (fds[i].revents & POLLIN) {
                    struct js_event event;
                    ssize_t got = read(joy->fd, &event, sizeof(event));
                    if (got == (ssize_t)sizeof(event)) process_event(joy, event);
                    else if (got == 0 || (got < 0 && errno != EAGAIN && errno != EINTR))
                        close_joystick(joy);
                }
            }
        }
    }

    for (i = 0; i < XWT_MAX_JOYSTICKS; ++i) close_joystick(&joysticks[i]);
    if (uinput_fd >= 0) {
        for (i = 0; i < XWT_KEY_COUNT; ++i) {
            if (emitted[i]) emit_key((unsigned short)i, 0);
        }
        (void)ioctl(uinput_fd, UI_DEV_DESTROY);
        close(uinput_fd);
        uinput_fd = -1;
    }
    return 0;
}
