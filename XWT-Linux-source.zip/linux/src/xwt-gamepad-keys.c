/*
 * XWT Linux 1.0.0 - Xbox controller to Linux keyboard bridge.
 * Supports hotplug/reconnect and up to four /dev/input/js* devices.
 * It never accesses NAND, SMC, KV, or firmware.
 */
#define _POSIX_C_SOURCE 200809L
#include <errno.h>
#include <fcntl.h>
#include <linux/input.h>
#include <linux/joystick.h>
#include <linux/uinput.h>
#include <poll.h>
#include <signal.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>

#define XWT_MAX_JOYSTICKS 4
#define XWT_MAX_AXES 16
#define XWT_AXIS_DEADZONE 17000
#define XWT_TRIGGER_ON 8000
#define XWT_SCAN_MS 1000
#define XWT_POLL_MS 40
#define XWT_KEY_COUNT (KEY_MAX + 1)
#define XWT_STICK_DEAD 5000
#define XWT_MOUSE_MAX_STEP 22   /* pixels per 16 ms tick at full deflection */
#define XWT_TICK_MS 16
#define BTN_L3 9
#define BTN_R3 10

typedef struct {
    int fd;
    char path[32];
    int16_t axes[XWT_MAX_AXES];
    int hat_x;
    int hat_y;
    uint8_t buttons[32];
} XwtJoystick;

static volatile sig_atomic_t running = 1;
static int uinput_fd = -1;
static uint8_t emitted[XWT_KEY_COUNT];
static int mouse_fd = -1;
static int pointer_mode;       /* L3 toggles: left stick = mouse, A/B/X = left/right/middle click */
static uint8_t mouse_btn[3];
static int l3_prev, r3_prev, y_prev;
static pid_t osk_pid;
static long wheel_ms;
static XwtJoystick joysticks[XWT_MAX_JOYSTICKS];

static void on_signal(int signal_number)
{
    (void)signal_number;
    running = 0;
}

static int write_all(int fd, const void *data, size_t size)
{
    const uint8_t *cursor = (const uint8_t *)data;
    while (size > 0) {
        ssize_t written = write(fd, cursor, size);
        if (written < 0) {
            if (errno == EINTR) continue;
            return -1;
        }
        if (written == 0) return -1;
        cursor += (size_t)written;
        size -= (size_t)written;
    }
    return 0;
}

static int create_virtual_keyboard(void)
{
    static const unsigned short keys[] = {
        KEY_UP, KEY_DOWN, KEY_LEFT, KEY_RIGHT, KEY_ENTER, KEY_ESC,
        KEY_LEFTCTRL, KEY_SPACE, KEY_RIGHTSHIFT, KEY_TAB, KEY_COMMA, KEY_DOT, KEY_Y,
        KEY_PAGEUP, KEY_PAGEDOWN, KEY_HOME, KEY_F12
    };
    struct uinput_setup setup;
    size_t i;
    int fd = open("/dev/uinput", O_WRONLY | O_CLOEXEC);
    if (fd < 0) return -1;

    /* EV_SYN is provided by the input core; register the key capability only. */
    if (ioctl(fd, UI_SET_EVBIT, EV_KEY) < 0) {
        close(fd);
        return -1;
    }
    /* EV_REP lets the console auto-repeat held directions (menus, text lists). */
    (void)ioctl(fd, UI_SET_EVBIT, EV_REP);
    for (i = 0; i < sizeof(keys) / sizeof(keys[0]); ++i) {
        if (ioctl(fd, UI_SET_KEYBIT, keys[i]) < 0) {
            close(fd);
            return -1;
        }
    }

    memset(&setup, 0, sizeof(setup));
    (void)snprintf(setup.name, sizeof(setup.name), "XWT Xbox Controller Keyboard");
    setup.id.bustype = BUS_USB;
    setup.id.vendor = 0x045e;
    setup.id.product = 0x028e;
    setup.id.version = 1;
    if (ioctl(fd, UI_DEV_SETUP, &setup) < 0 || ioctl(fd, UI_DEV_CREATE) < 0) {
        close(fd);
        return -1;
    }
    return fd;
}

static int create_virtual_mouse(void)
{
    struct uinput_setup setup;
    int fd = open("/dev/uinput", O_WRONLY | O_CLOEXEC);
    if (fd < 0) return -1;
    if (ioctl(fd, UI_SET_EVBIT, EV_KEY) < 0 || ioctl(fd, UI_SET_EVBIT, EV_REL) < 0 ||
        ioctl(fd, UI_SET_KEYBIT, BTN_LEFT) < 0 || ioctl(fd, UI_SET_KEYBIT, BTN_RIGHT) < 0 ||
        ioctl(fd, UI_SET_KEYBIT, BTN_MIDDLE) < 0 || ioctl(fd, UI_SET_RELBIT, REL_X) < 0 ||
        ioctl(fd, UI_SET_RELBIT, REL_Y) < 0 || ioctl(fd, UI_SET_RELBIT, REL_WHEEL) < 0) {
        close(fd);
        return -1;
    }
    memset(&setup, 0, sizeof(setup));
    (void)snprintf(setup.name, sizeof(setup.name), "XWT Xbox Controller Mouse");
    setup.id.bustype = BUS_USB;
    setup.id.vendor = 0x045e;
    setup.id.product = 0x028f;
    setup.id.version = 1;
    if (ioctl(fd, UI_DEV_SETUP, &setup) < 0 || ioctl(fd, UI_DEV_CREATE) < 0) {
        close(fd);
        return -1;
    }
    return fd;
}

static void mouse_event(unsigned short type, unsigned short code, int value)
{
    struct input_event event;
    if (mouse_fd < 0) return;
    memset(&event, 0, sizeof(event));
    event.type = type;
    event.code = code;
    event.value = value;
    if (write_all(mouse_fd, &event, sizeof(event)) != 0) return;
    memset(&event, 0, sizeof(event));
    event.type = EV_SYN;
    event.code = SYN_REPORT;
    (void)write_all(mouse_fd, &event, sizeof(event));
}

static void emit_key(unsigned short code, int down)
{
    struct input_event event;
    if (uinput_fd < 0 || code >= XWT_KEY_COUNT) return;
    memset(&event, 0, sizeof(event));
    event.type = EV_KEY;
    event.code = code;
    event.value = down ? 1 : 0;
    if (write_all(uinput_fd, &event, sizeof(event)) != 0) return;
    memset(&event, 0, sizeof(event));
    event.type = EV_SYN;
    event.code = SYN_REPORT;
    (void)write_all(uinput_fd, &event, sizeof(event));
}

static int16_t choose_axis(int16_t hat, int16_t stick)
{
    if (hat <= -XWT_AXIS_DEADZONE || hat >= XWT_AXIS_DEADZONE) return hat;
    return stick;
}

/* xwt-game writes "game" to /run/xwt-gamepad-mode while a game owns the screen. */
static int game_mode(void)
{
    char buf[8];
    ssize_t n;
    int fd = open("/run/xwt-gamepad-mode", O_RDONLY | O_CLOEXEC);
    if (fd < 0) return 0;
    n = read(fd, buf, sizeof(buf));
    close(fd);
    return n >= 4 && memcmp(buf, "game", 4) == 0;
}

static int gui_owns_screen(void)
{
    char buf[4];
    ssize_t n;
    int fd = open("/run/xwt-gui", O_RDONLY | O_CLOEXEC);
    if (fd < 0) return 0;
    n = read(fd, buf, sizeof(buf));
    close(fd);
    return n >= 1 && buf[0] == '1';
}

static int osk_running(void)
{
    int status;
    if (osk_pid > 0 && waitpid(osk_pid, &status, WNOHANG) != 0) osk_pid = 0;
    return osk_pid > 0;
}

/* Open the on-screen keyboard (own VT) unless the SDL desktop owns the screen or it is already open. */
static void start_osk(void)
{
    pid_t pid;
    if (gui_owns_screen()) { /* desktop has its own keyboard overlay: ask for it with F12 */
        emit_key(KEY_F12, 1);
        emit_key(KEY_F12, 0);
        return;
    }
    if (osk_running()) return;
    pid = fork();
    if (pid == 0) {
        (void)setsid();
        execl("/usr/sbin/xwt-osk", "xwt-osk", (char *)NULL);
        _exit(127);
    }
    if (pid > 0) osk_pid = pid;
}

static void write_pointer_state(void)
{
    FILE *f = fopen("/run/xwt-pointer", "w");
    if (!f) return;
    fputs(pointer_mode ? "on\n" : "off\n", f);
    fclose(f);
}

static void mouse_buttons(int left, int right, int middle)
{
    int want[3], i;
    static const unsigned short codes[3] = {BTN_LEFT, BTN_RIGHT, BTN_MIDDLE};
    want[0] = left; want[1] = right; want[2] = middle;
    for (i = 0; i < 3; ++i) {
        if (want[i] != mouse_btn[i]) {
            mouse_event(EV_KEY, codes[i], want[i]);
            mouse_btn[i] = (uint8_t)want[i];
        }
    }
}

static void refresh_keys(void)
{
    int game = game_mode();
    uint8_t wanted[XWT_KEY_COUNT];
    size_t i;
    int l3 = 0, r3 = 0, ybtn = 0, ptr, click_l = 0, click_r = 0, click_m = 0;
    memset(wanted, 0, sizeof(wanted));

    for (i = 0; i < XWT_MAX_JOYSTICKS; ++i) {
        if (joysticks[i].fd < 0) continue;
        if (joysticks[i].buttons[BTN_L3]) l3 = 1;
        if (joysticks[i].buttons[BTN_R3]) r3 = 1;
        if (joysticks[i].buttons[3]) ybtn = 1;
    }
    if (l3 && !l3_prev && !game) {            /* L3: toggle mouse + virtual keyboard mode */
        pointer_mode = !pointer_mode;
        write_pointer_state();
        fprintf(stderr, "xwt-gamepad-keys: modo mouse %s\n", pointer_mode ? "ligado" : "desligado");
    }
    if (r3 && !r3_prev && !game) start_osk(); /* R3: virtual keyboard */
    if (ybtn && !y_prev && pointer_mode && !game) start_osk();
    l3_prev = l3; r3_prev = r3; y_prev = ybtn;
    ptr = pointer_mode && !game && !osk_running();

    for (i = 0; i < XWT_MAX_JOYSTICKS; ++i) {
        const XwtJoystick *joy = &joysticks[i];
        int16_t x, y;
        if (joy->fd < 0) continue;
        if (ptr) { /* left stick belongs to the mouse: D-pad only for arrows */
            x = joy->axes[joy->hat_x];
            y = joy->axes[joy->hat_y];
        } else {
            x = choose_axis(joy->axes[joy->hat_x], joy->axes[0]);
            y = choose_axis(joy->axes[joy->hat_y], joy->axes[1]);
        }
        /* Linux xpad exposes the D-pad as ABS_HAT0X/Y (js axes 6/7).
         * The primary stick remains a fallback for devices without a hat. */
        if (y < -XWT_AXIS_DEADZONE) wanted[KEY_UP] = 1;
        if (y > XWT_AXIS_DEADZONE) wanted[KEY_DOWN] = 1;
        if (x < -XWT_AXIS_DEADZONE) wanted[KEY_LEFT] = 1;
        if (x > XWT_AXIS_DEADZONE) wanted[KEY_RIGHT] = 1;
        if (game) {
            /* Doom layout: A fire, B use, X run, Y map, LB/RB strafe, Back confirm, Start menu. */
            if (joy->buttons[0]) wanted[KEY_LEFTCTRL] = 1;
            if (joy->buttons[1]) wanted[KEY_SPACE] = 1;
            if (joy->buttons[2]) wanted[KEY_RIGHTSHIFT] = 1;
            if (joy->buttons[3]) wanted[KEY_TAB] = 1;
            if (joy->buttons[4]) wanted[KEY_COMMA] = 1;
            if (joy->buttons[5]) wanted[KEY_DOT] = 1;
            if (joy->buttons[6]) wanted[KEY_ENTER] = 1;
            if (joy->buttons[7]) wanted[KEY_ESC] = 1;
            if (joy->axes[5] > XWT_TRIGGER_ON) wanted[KEY_LEFTCTRL] = 1; /* RT = fire */
            if (joy->axes[2] > XWT_TRIGGER_ON) wanted[KEY_SPACE] = 1;    /* LT = use */
            if (joy->buttons[8]) wanted[KEY_ESC] = 1;                    /* Guide = menu */
        } else {
            /* Standard xpad mapping: A/Start = confirm; B/Back = cancel. */
            if (ptr) {
                if (joy->buttons[0]) click_l = 1;
                if (joy->buttons[1]) click_r = 1;
                if (joy->buttons[2]) click_m = 1;
                if (joy->buttons[7]) wanted[KEY_ENTER] = 1;
                if (joy->buttons[6]) wanted[KEY_ESC] = 1;
            } else {
                if (joy->buttons[0] || joy->buttons[7]) wanted[KEY_ENTER] = 1;
                if (joy->buttons[1] || joy->buttons[6]) wanted[KEY_ESC] = 1;
            }
            if ((!ptr && joy->buttons[4]) || joy->axes[2] > XWT_TRIGGER_ON) wanted[KEY_PAGEUP] = 1;
            if ((!ptr && joy->buttons[5]) || joy->axes[5] > XWT_TRIGGER_ON) wanted[KEY_PAGEDOWN] = 1;
            if (joy->buttons[8]) wanted[KEY_HOME] = 1;
        }
    }

    mouse_buttons(ptr ? click_l : 0, ptr ? click_r : 0, ptr ? click_m : 0);
    for (i = 0; i < XWT_KEY_COUNT; ++i) {
        if (wanted[i] != emitted[i]) {
            emit_key((unsigned short)i, wanted[i] != 0);
            emitted[i] = wanted[i];
        }
    }
}

static int stick_step(int16_t value)
{
    long v = value < 0 ? -(long)value : (long)value, step;
    if (v < XWT_STICK_DEAD) return 0;
    v -= XWT_STICK_DEAD;
    if (v > 32767 - XWT_STICK_DEAD) v = 32767 - XWT_STICK_DEAD;
    /* quadratic curve: fine control near the centre, fast at the edge */
    step = 1 + (v * v * (XWT_MOUSE_MAX_STEP - 1)) / ((long)(32767 - XWT_STICK_DEAD) * (32767 - XWT_STICK_DEAD));
    return value < 0 ? -(int)step : (int)step;
}

/* Called every XWT_TICK_MS while the mouse mode is on: moves the pointer and scrolls. */
static void pointer_tick(long now_ms)
{
    size_t i;
    int dx = 0, dy = 0, wheel = 0;
    if (!pointer_mode || game_mode() || osk_running()) return;
    for (i = 0; i < XWT_MAX_JOYSTICKS; ++i) {
        const XwtJoystick *joy = &joysticks[i];
        if (joy->fd < 0) continue;
        dx += stick_step(joy->axes[0]);
        dy += stick_step(joy->axes[1]);
        if (joy->buttons[4]) wheel += 1;
        if (joy->buttons[5]) wheel -= 1;
        if (joy->axes[4] <= -20000) wheel += 1;
        if (joy->axes[4] >= 20000) wheel -= 1;
    }
    if (dx) mouse_event(EV_REL, REL_X, dx);
    if (dy) mouse_event(EV_REL, REL_Y, dy);
    if (wheel && now_ms - wheel_ms >= 110) {
        mouse_event(EV_REL, REL_WHEEL, wheel > 0 ? 1 : -1);
        wheel_ms = now_ms;
    }
}

static void close_joystick(XwtJoystick *joy)
{
    if (joy->fd >= 0) close(joy->fd);
    joy->fd = -1;
    memset(joy->axes, 0, sizeof(joy->axes));
    memset(joy->buttons, 0, sizeof(joy->buttons));
    joy->path[0] = '\0';
    refresh_keys();
}

static void scan_joysticks(void)
{
    unsigned i;
    char path[32];
    for (i = 0; i < XWT_MAX_JOYSTICKS; ++i) {
        if (joysticks[i].fd >= 0) continue;
        (void)snprintf(path, sizeof(path), "/dev/input/js%u", i);
        joysticks[i].fd = open(path, O_RDONLY | O_NONBLOCK | O_CLOEXEC);
        if (joysticks[i].fd >= 0) {
            unsigned char naxes = 0;
            (void)snprintf(joysticks[i].path, sizeof(joysticks[i].path), "%s", path);
            /* Pads with 8+ axes (xpad) expose the D-pad as 6/7; others use the last two axes. */
            if (ioctl(joysticks[i].fd, JSIOCGAXES, &naxes) < 0) naxes = 8;
            if (naxes >= 8) { joysticks[i].hat_x = 6; joysticks[i].hat_y = 7; }
            else if (naxes >= 4) { joysticks[i].hat_x = naxes - 2; joysticks[i].hat_y = naxes - 1; }
            else { joysticks[i].hat_x = 0; joysticks[i].hat_y = 1; }
            fprintf(stderr, "xwt-gamepad-keys: conectado %s\n", path);
        }
    }
}

static void process_event(XwtJoystick *joy, struct js_event event)
{
    unsigned type = event.type & (unsigned char)~JS_EVENT_INIT;
    if (type == JS_EVENT_AXIS && event.number < XWT_MAX_AXES) {
        joy->axes[event.number] = event.value;
        refresh_keys();
    } else if (type == JS_EVENT_BUTTON && event.number < 32) {
        joy->buttons[event.number] = event.value ? 1U : 0U;
        refresh_keys();
    }
}

int main(void)
{
    unsigned i;
    struct timespec last_scan = {0, 0};
    signal(SIGTERM, on_signal);
    signal(SIGINT, on_signal);
    for (i = 0; i < XWT_MAX_JOYSTICKS; ++i) joysticks[i].fd = -1;

    while (running) {
        struct pollfd fds[XWT_MAX_JOYSTICKS];
        int map[XWT_MAX_JOYSTICKS];
        nfds_t count = 0;
        struct timespec now;

        if (uinput_fd < 0) {
            uinput_fd = create_virtual_keyboard();
            if (uinput_fd < 0) {
                nanosleep(&(struct timespec){0, 500000000L}, NULL);
                continue;
            }
            fprintf(stderr, "xwt-gamepad-keys: teclado virtual ativo\n");
        }
        if (mouse_fd < 0) {
            mouse_fd = create_virtual_mouse();
            if (mouse_fd >= 0) fprintf(stderr, "xwt-gamepad-keys: mouse virtual ativo (L3 liga/desliga, R3 teclado na tela)\n");
        }

        (void)clock_gettime(CLOCK_MONOTONIC, &now);
        if (last_scan.tv_sec == 0 ||
            (now.tv_sec - last_scan.tv_sec) * 1000L +
            (now.tv_nsec - last_scan.tv_nsec) / 1000000L >= XWT_SCAN_MS) {
            scan_joysticks();
            last_scan = now;
        }

        for (i = 0; i < XWT_MAX_JOYSTICKS; ++i) {
            if (joysticks[i].fd >= 0) {
                fds[count].fd = joysticks[i].fd;
                fds[count].events = POLLIN;
                fds[count].revents = 0;
                map[count] = (int)i;
                ++count;
            }
        }

        if (count == 0) {
            nanosleep(&(struct timespec){0, 100000000L}, NULL);
            continue;
        }

        {
            int ready = poll(fds, count, pointer_mode ? XWT_TICK_MS : XWT_POLL_MS);
            if (ready < 0) {
                if (errno == EINTR) continue;
                nanosleep(&(struct timespec){0, 50000000L}, NULL);
                continue;
            }
            for (i = 0; i < count; ++i) {
                XwtJoystick *joy = &joysticks[map[i]];
                if (fds[i].revents & (POLLERR | POLLHUP | POLLNVAL)) {
                    fprintf(stderr, "xwt-gamepad-keys: desconectado %s\n", joy->path);
                    close_joystick(joy);
                    continue;
                }
                if (fds[i].revents & POLLIN) {
                    struct js_event event;
                    ssize_t got = read(joy->fd, &event, sizeof(event));
                    if (got == (ssize_t)sizeof(event)) process_event(joy, event);
                    else if (got == 0 || (got < 0 && errno != EAGAIN && errno != EINTR))
                        close_joystick(joy);
                }
            }
            if (pointer_mode) {
                static long last_tick_ms;
                struct timespec tick_now;
                long ms;
                (void)clock_gettime(CLOCK_MONOTONIC, &tick_now);
                ms = tick_now.tv_sec * 1000L + tick_now.tv_nsec / 1000000L;
                if (ms - last_tick_ms >= XWT_TICK_MS) {
                    last_tick_ms = ms;
                    pointer_tick(ms);
                }
            }
        }
    }

    for (i = 0; i < XWT_MAX_JOYSTICKS; ++i) close_joystick(&joysticks[i]);
    if (mouse_fd >= 0) {
        (void)ioctl(mouse_fd, UI_DEV_DESTROY);
        close(mouse_fd);
        mouse_fd = -1;
    }
    if (uinput_fd >= 0) {
        for (i = 0; i < XWT_KEY_COUNT; ++i) {
            if (emitted[i]) emit_key((unsigned short)i, 0);
        }
        (void)ioctl(uinput_fd, UI_DEV_DESTROY);
        close(uinput_fd);
        uinput_fd = -1;
    }
    return 0;
}
