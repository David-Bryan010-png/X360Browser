/*
 * XWT Linux 1.0.0 - on-screen (virtual) keyboard for the Xbox controller.
 * Started by xwt-gamepad-keys (R3, or Y while the pointer mode is on). It runs on its own VT, so
 * the text screen of the program below it comes back untouched when you close it.
 * D-pad/arrows move, A (Enter) types the highlighted key, B (Esc) or the Fechar key closes.
 * Typed characters are injected into the tty queue (TIOCSTI) of XWT_OSK_TTY (default /dev/tty1).
 */
#define _DEFAULT_SOURCE
#include <SDL.h>
#include <SDL_ttf.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <unistd.h>

#define OSK_ROWS 5
#define OSK_MAX_COLS 16
#define FONT_PATH "/usr/share/fonts/dejavu/DejaVuSans.ttf"

typedef enum { K_CHAR, K_BACKSPACE, K_ENTER, K_TAB, K_SHIFT, K_CTRL, K_SPACE, K_UP, K_DOWN, K_LEFT, K_RIGHT, K_ESC, K_CLOSE } KeyKind;
typedef struct { const char *label; const char *shifted; KeyKind kind; int w; } OskKey;

#define C(a, b) {a, b, K_CHAR, 2}
static const OskKey row0[] = {C("`", "~"), C("1", "!"), C("2", "@"), C("3", "#"), C("4", "$"), C("5", "%"), C("6", "^"), C("7", "&"), C("8", "*"), C("9", "("), C("0", ")"), C("-", "_"), C("=", "+"), {"Apagar", "Apagar", K_BACKSPACE, 4}};
static const OskKey row1[] = {{"Tab", "Tab", K_TAB, 3}, C("q", "Q"), C("w", "W"), C("e", "E"), C("r", "R"), C("t", "T"), C("y", "Y"), C("u", "U"), C("i", "I"), C("o", "O"), C("p", "P"), C("[", "{"), C("]", "}"), C("\\", "|")};
static const OskKey row2[] = {C("a", "A"), C("s", "S"), C("d", "D"), C("f", "F"), C("g", "G"), C("h", "H"), C("j", "J"), C("k", "K"), C("l", "L"), C(";", ":"), C("'", "\""), {"Enter", "Enter", K_ENTER, 5}};
static const OskKey row3[] = {{"Shift", "Shift", K_SHIFT, 4}, C("z", "Z"), C("x", "X"), C("c", "C"), C("v", "V"), C("b", "B"), C("n", "N"), C("m", "M"), C(",", "<"), C(".", ">"), C("/", "?")};
static const OskKey row4[] = {{"Ctrl", "Ctrl", K_CTRL, 3}, {"Esc", "Esc", K_ESC, 3}, {"Espaco", "Espaco", K_SPACE, 8}, {"<", "<", K_LEFT, 2}, {"v", "v", K_DOWN, 2}, {"^", "^", K_UP, 2}, {">", ">", K_RIGHT, 2}, {"Fechar", "Fechar", K_CLOSE, 4}};
#undef C
static const OskKey *rows[OSK_ROWS] = {row0, row1, row2, row3, row4};
static const int counts[OSK_ROWS] = {(int)(sizeof row0 / sizeof row0[0]), (int)(sizeof row1 / sizeof row1[0]), (int)(sizeof row2 / sizeof row2[0]), (int)(sizeof row3 / sizeof row3[0]), (int)(sizeof row4 / sizeof row4[0])};

static int tty_fd = -1;
static int shift_on, ctrl_on, sel_row, sel_col;
static char typed[96];
static SDL_Surface *screen;
static TTF_Font *font;

static void inject(const char *bytes, size_t n)
{
    size_t i;
    if (tty_fd < 0) return;
    for (i = 0; i < n; ++i) (void)ioctl(tty_fd, TIOCSTI, &bytes[i]);
}

static void remember(char c)
{
    size_t n = strlen(typed);
    if (c == 0x7f) { if (n) typed[n - 1] = '\0'; return; }
    if (c == '\n') { typed[0] = '\0'; return; }
    if (c < 0x20) return;
    if (n + 1 >= sizeof(typed)) { memmove(typed, typed + 1, sizeof(typed) - 2); n = strlen(typed); }
    typed[n] = c; typed[n + 1] = '\0';
}

/* Returns 1 when the keyboard must close. */
static int press(const OskKey *k)
{
    char c;
    const char *txt;
    switch (k->kind) {
    case K_SHIFT: shift_on = !shift_on; return 0;
    case K_CTRL: ctrl_on = !ctrl_on; return 0;
    case K_CLOSE: return 1;
    case K_BACKSPACE: c = 0x7f; inject(&c, 1); remember(c); break;
    case K_ENTER: c = '\n'; inject(&c, 1); remember(c); break;
    case K_TAB: c = '\t'; inject(&c, 1); break;
    case K_ESC: c = 0x1b; inject(&c, 1); break;
    case K_SPACE: c = ' '; inject(&c, 1); remember(c); break;
    case K_UP: inject("\033[A", 3); break;
    case K_DOWN: inject("\033[B", 3); break;
    case K_RIGHT: inject("\033[C", 3); break;
    case K_LEFT: inject("\033[D", 3); break;
    case K_CHAR:
        txt = shift_on ? k->shifted : k->label;
        c = txt[0];
        if (ctrl_on && ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z'))) c = (char)((c | 0x20) - 'a' + 1);
        inject(&c, 1);
        if (!ctrl_on) remember(c);
        ctrl_on = 0;
        break;
    }
    if (k->kind != K_CHAR) ctrl_on = ctrl_on && k->kind == K_CTRL;
    if (shift_on && k->kind == K_CHAR) shift_on = 0;
    return 0;
}

static void fill(int x, int y, int w, int h, Uint8 r, Uint8 g, Uint8 b)
{
    SDL_Rect rc;
    rc.x = (Sint16)x; rc.y = (Sint16)y; rc.w = (Uint16)w; rc.h = (Uint16)h;
    SDL_FillRect(screen, &rc, SDL_MapRGB(screen->format, r, g, b));
}

static void text(int x, int y, const char *s, Uint8 r, Uint8 g, Uint8 b)
{
    SDL_Color col;
    SDL_Surface *img;
    SDL_Rect dst;
    if (!font || !*s) return;
    col.r = r; col.g = g; col.b = b; col.unused = 0;
    img = TTF_RenderUTF8_Blended(font, s, col);
    if (!img) return;
    dst.x = (Sint16)x; dst.y = (Sint16)y; dst.w = (Uint16)img->w; dst.h = (Uint16)img->h;
    SDL_BlitSurface(img, NULL, screen, &dst);
    SDL_FreeSurface(img);
}

static int text_w(const char *s)
{
    int w = 0, h = 0;
    if (!font || TTF_SizeUTF8(font, s, &w, &h) != 0) return 0;
    return w;
}

static void draw(void)
{
    int unit = (screen->w - 40) / 40, key_h = screen->h >= 600 ? 64 : 48;
    int top = screen->h / 2 - (OSK_ROWS * (key_h + 8)) / 2 + 20, r, c;
    fill(0, 0, screen->w, screen->h, 6, 14, 30);
    fill(20, 20, screen->w - 40, 54, 14, 24, 48);
    text(36, 32, "Teclado virtual XWT  -  A digita, B fecha, Shift/Ctrl sao teclas de 1 toque", 190, 205, 230);
    fill(20, 84, screen->w - 40, 44, 0, 0, 0);
    text(32, 92, typed[0] ? typed : "(o que voce digitar aparece aqui)", typed[0] ? 120 : 90, typed[0] ? 230 : 100, typed[0] ? 120 : 110);
    for (r = 0; r < OSK_ROWS; ++r) {
        int x = 20;
        for (c = 0; c < counts[r]; ++c) {
            const OskKey *k = &rows[r][c];
            int w = k->w * unit - 6, y = top + r * (key_h + 8), on = (r == sel_row && c == sel_col);
            int active = (k->kind == K_SHIFT && shift_on) || (k->kind == K_CTRL && ctrl_on);
            const char *label = (k->kind == K_CHAR && shift_on) ? k->shifted : k->label;
            fill(x, y, w, key_h, on ? 30 : 20, on ? 110 : 34, on ? 240 : 64);
            if (active) fill(x, y + key_h - 6, w, 6, 100, 200, 90);
            text(x + (w - text_w(label)) / 2, y + (key_h - 22) / 2, label, 240, 245, 255);
            x += k->w * unit;
        }
    }
    SDL_Flip(screen);
}

static void move(int dr, int dc)
{
    if (dr) {
        /* keep the horizontal position by key width units */
        int units = 0, c, target;
        for (c = 0; c < sel_col; ++c) units += rows[sel_row][c].w;
        units += rows[sel_row][sel_col].w / 2;
        sel_row = (sel_row + dr + OSK_ROWS) % OSK_ROWS;
        target = 0;
        for (c = 0; c < counts[sel_row]; ++c) {
            if (units < rows[sel_row][c].w) break;
            units -= rows[sel_row][c].w; target = c + 1;
        }
        sel_col = target < counts[sel_row] ? target : counts[sel_row] - 1;
    }
    if (dc) sel_col = (sel_col + dc + counts[sel_row]) % counts[sel_row];
}

int main(void)
{
    SDL_Event ev;
    int done = 0;
    const char *tty = getenv("XWT_OSK_TTY");
    tty_fd = open(tty && *tty ? tty : "/dev/tty1", O_RDWR | O_NOCTTY | O_CLOEXEC);
    (void)setenv("SDL_VIDEODRIVER", "fbcon", 0);
    (void)setenv("SDL_FBDEV", "/dev/fb0", 0);
    if (SDL_Init(SDL_INIT_VIDEO) != 0) { fprintf(stderr, "xwt-osk: %s\n", SDL_GetError()); return 1; }
    screen = SDL_SetVideoMode(0, 0, 0, SDL_SWSURFACE | SDL_FULLSCREEN);
    if (!screen) { fprintf(stderr, "xwt-osk: %s\n", SDL_GetError()); SDL_Quit(); return 1; }
    TTF_Init();
    font = TTF_OpenFont(FONT_PATH, screen->h >= 600 ? 22 : 17);
    SDL_ShowCursor(SDL_DISABLE);
    SDL_EnableKeyRepeat(SDL_DEFAULT_REPEAT_DELAY, SDL_DEFAULT_REPEAT_INTERVAL);
    sel_row = 2; sel_col = 0;
    draw();
    while (!done) {
        int dirty = 0;
        while (SDL_PollEvent(&ev)) {
            if (ev.type == SDL_QUIT) done = 1;
            else if (ev.type == SDL_KEYDOWN) {
                switch (ev.key.keysym.sym) {
                case SDLK_UP: move(-1, 0); dirty = 1; break;
                case SDLK_DOWN: move(1, 0); dirty = 1; break;
                case SDLK_LEFT: move(0, -1); dirty = 1; break;
                case SDLK_RIGHT: move(0, 1); dirty = 1; break;
                case SDLK_RETURN: case SDLK_KP_ENTER: done = press(&rows[sel_row][sel_col]); dirty = 1; break;
                case SDLK_ESCAPE: done = 1; break;
                default: break;
                }
            }
        }
        if (dirty && !done) draw();
        SDL_Delay(25);
    }
    if (font) TTF_CloseFont(font);
    TTF_Quit();
    SDL_Quit();
    if (tty_fd >= 0) close(tty_fd);
    return 0;
}
