/*
 * X360 Web Total - Xenon Desktop
 * Lightweight SDL 1.2 + SDL_ttf desktop shell for the Xbox 360 Linux port.
 * The shell is deliberately independent from the browser engine: applications
 * are launched as separate processes and may be replaced/extended later.
 * No NAND, SMC, KV, bootloader or flash access is performed here.
 * Input: Xbox controller (via xwt-gamepad-keys bridge or direct js*),
 * USB keyboard and USB mouse. Controller is the primary path.
 */
#define _DEFAULT_SOURCE
#define _POSIX_C_SOURCE 200809L

#include <SDL.h>
#include <SDL_ttf.h>

#include <fcntl.h>
#include <linux/fb.h>
#include <sys/ioctl.h>

#include <dirent.h>
#include <errno.h>
#include <ifaddrs.h>
#include <limits.h>
#include <net/if.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>
#include <arpa/inet.h>

#define APP_COUNT 8
#define FILE_LIMIT 320
#define HEADER_H 58
#define FOOTER_H 30
#define SIDEBAR_W 146
#define FONT_PATH "/usr/share/fonts/dejavu/DejaVuSans.ttf"
#define FONT_BOLD_PATH "/usr/share/fonts/dejavu/DejaVuSans-Bold.ttf"

typedef enum { PAGE_HOME = 0, PAGE_FILES, PAGE_SYSTEM } Page;

typedef struct {
    char name[256];
    off_t size;
    int is_dir;
} FileEntry;

typedef struct {
    const char *title;
    const char *subtitle;
    const char *symbol;
} AppEntry;

static const AppEntry apps[APP_COUNT] = {
    {"Navegador", "Internet e paginas web", "WEB"},
    {"Wi-Fi", "Redes sem fio USB", "WIFI"},
    {"Internet", "Diagnostico de conexao", "NET"},
    {"Arquivos", "USB, pastas e documentos", "FILES"},
    {"Sistema", "CPU, memoria e dispositivos", "SYS"},
    {"Terminal", "Shell Linux para manutencao", "TERM"},
    {"Audio", "Dispositivos e volume", "AUDIO"},
    {"Energia", "Reiniciar ou desligar", "POWER"}
};

static SDL_Surface *screen;
static TTF_Font *font_regular;
static TTF_Font *font_bold;
static int screen_w = 640;
static int screen_h = 480;
static int selected_app;
static int selected_file;
static int file_scroll;
static Page page = PAGE_HOME;
static char current_dir[PATH_MAX] = "/mnt/xwt-usb";
static FileEntry entries[FILE_LIMIT];
static size_t entry_count;
static char status_line[256] = "Inicializando sistema";

static const SDL_Color C_WHITE = {245, 247, 244, 255};
static const SDL_Color C_MUTED = {174, 183, 174, 255};
static const SDL_Color C_GREEN = {16, 124, 16, 255};
static const SDL_Color C_LIME = {107, 190, 70, 255};
static const SDL_Color C_DARK = {17, 22, 19, 255};
static const SDL_Color C_PANEL = {29, 36, 31, 255};
static const SDL_Color C_PANEL2 = {38, 47, 40, 255};
static const SDL_Color C_BORDER = {68, 83, 70, 255};

static Uint32 rgb(Uint8 r, Uint8 g, Uint8 b)
{
    return SDL_MapRGB(screen->format, r, g, b);
}

static void rect(int x, int y, int w, int h, SDL_Color color)
{
    SDL_Rect r;
    if (w <= 0 || h <= 0) return;
    r.x = (Sint16)x; r.y = (Sint16)y;
    r.w = (Uint16)w; r.h = (Uint16)h;
    SDL_FillRect(screen, &r, rgb(color.r, color.g, color.b));
}

static void outline(int x, int y, int w, int h, SDL_Color color)
{
    rect(x, y, w, 1, color);
    rect(x, y + h - 1, w, 1, color);
    rect(x, y, 1, h, color);
    rect(x + w - 1, y, 1, h, color);
}

static void draw_text_font(TTF_Font *font, int x, int y, const char *value, SDL_Color color)
{
    SDL_Surface *glyph;
    SDL_Rect dest;
    if (!font || !value || !*value) return;
    glyph = TTF_RenderUTF8_Blended(font, value, color);
    if (!glyph) return;
    dest.x = (Sint16)x;
    dest.y = (Sint16)y;
    dest.w = (Uint16)glyph->w;
    dest.h = (Uint16)glyph->h;
    SDL_BlitSurface(glyph, NULL, screen, &dest);
    SDL_FreeSurface(glyph);
}

static void draw_text(int x, int y, const char *value, SDL_Color color)
{
    draw_text_font(font_regular, x, y, value, color);
}

static void draw_bold(int x, int y, const char *value, SDL_Color color)
{
    draw_text_font(font_bold ? font_bold : font_regular, x, y, value, color);
}

static int probe_framebuffer(int *width, int *height, int *bits_per_pixel)
{
    struct fb_var_screeninfo var;
    struct fb_fix_screeninfo fix;
    int fd = open("/dev/fb0", O_RDWR | O_CLOEXEC);
    unsigned long long visible_bytes;
    unsigned long long mapped_bytes;
    if (fd < 0) return -1;
    if (ioctl(fd, FBIOGET_VSCREENINFO, &var) != 0 ||
        ioctl(fd, FBIOGET_FSCREENINFO, &fix) != 0) {
        close(fd);
        return -1;
    }
    close(fd);
    if (var.xres < 640 || var.yres < 480 || var.xres > 4096 || var.yres > 2160)
        return -1;
    if (var.bits_per_pixel != 16 && var.bits_per_pixel != 32) return -1;
    if (var.xres_virtual < var.xres || var.yres_virtual < var.yres) return -1;
    if (fix.line_length < var.xres_virtual * (var.bits_per_pixel / 8U)) return -1;
    visible_bytes = (unsigned long long)fix.line_length * var.yres;
    mapped_bytes = (unsigned long long)fix.line_length * var.yres_virtual;
    if (fix.smem_len < visible_bytes || fix.smem_len < mapped_bytes) return -1;
    *width = (int)var.xres;
    *height = (int)var.yres;
    *bits_per_pixel = (int)var.bits_per_pixel;
    return 0;
}

static int gui_init(void)
{
    int fb_width = 0, fb_height = 0, fb_bpp = 0;
    if (probe_framebuffer(&fb_width, &fb_height, &fb_bpp) != 0) {
        fprintf(stderr, "XWT Desktop: /dev/fb0 ausente ou modo framebuffer invalido.\n");
        return -1;
    }
    (void)setenv("SDL_VIDEODRIVER", "fbcon", 1);
    (void)setenv("SDL_FBDEV", "/dev/fb0", 1);
    if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_TIMER) < 0) return -1;
    if (TTF_Init() < 0) { SDL_Quit(); return -1; }
    screen_w = fb_width;
    screen_h = fb_height;
    screen = SDL_SetVideoMode(screen_w, screen_h, fb_bpp, SDL_SWSURFACE | SDL_FULLSCREEN);
    if (!screen && fb_bpp != 32)
        screen = SDL_SetVideoMode(screen_w, screen_h, 32, SDL_SWSURFACE | SDL_FULLSCREEN);
    if (!screen && fb_bpp != 16)
        screen = SDL_SetVideoMode(screen_w, screen_h, 16, SDL_SWSURFACE | SDL_FULLSCREEN);
    if (!screen) { TTF_Quit(); SDL_Quit(); return -1; }
    if (screen->w != fb_width || screen->h != fb_height) {
        fprintf(stderr, "XWT Desktop: SDL abriu %dx%d, framebuffer informado %dx%d.\n",
                screen->w, screen->h, fb_width, fb_height);
        screen = NULL;
        TTF_Quit(); SDL_Quit();
        return -1;
    }
    font_regular = TTF_OpenFont(FONT_PATH, screen_h >= 600 ? 17 : 14);
    font_bold = TTF_OpenFont(FONT_BOLD_PATH, screen_h >= 600 ? 20 : 17);
    if (!font_regular) font_regular = font_bold;
    if (!font_bold) font_bold = font_regular;
    if (!font_regular) { TTF_Quit(); SDL_Quit(); return -1; }
    SDL_ShowCursor(SDL_DISABLE);
    SDL_EnableKeyRepeat(SDL_DEFAULT_REPEAT_DELAY, SDL_DEFAULT_REPEAT_INTERVAL);
    /* Clear to black immediately so the first frame is not chuvisco or blue. */
    SDL_FillRect(screen, NULL, SDL_MapRGB(screen->format, 0, 0, 0));
    SDL_Flip(screen);
    SDL_WM_SetCaption("X360 Web Total - Xenon Desktop", "XWT");
    return 0;
}

static void gui_shutdown(void)
{
    if (font_bold && font_bold != font_regular) TTF_CloseFont(font_bold);
    if (font_regular) TTF_CloseFont(font_regular);
    font_regular = NULL;
    font_bold = NULL;
    screen = NULL;
    TTF_Quit();
    SDL_Quit();
}

static int has_default_route(void)
{
    FILE *f = fopen("/proc/net/route", "r");
    char line[256];
    if (!f) return 0;
    (void)fgets(line, sizeof(line), f);
    while (fgets(line, sizeof(line), f)) {
        char iface[64], destination[32];
        unsigned long gateway, flags;
        if (sscanf(line, "%63s %31s %lx %lx", iface, destination, &gateway, &flags) == 4 &&
            strcmp(destination, "00000000") == 0 && (flags & 1UL)) {
            fclose(f);
            return 1;
        }
    }
    fclose(f);
    return 0;
}

static void network_summary(char *out, size_t capacity)
{
    struct ifaddrs *list = NULL, *it;
    int found = 0;
    char address[INET_ADDRSTRLEN];
    if (getifaddrs(&list) == 0) {
        for (it = list; it; it = it->ifa_next) {
            struct sockaddr_in *sin;
            if (!it->ifa_addr || it->ifa_addr->sa_family != AF_INET) continue;
            if ((it->ifa_flags & IFF_LOOPBACK) || strcmp(it->ifa_name, "lo") == 0) continue;
            sin = (struct sockaddr_in *)it->ifa_addr;
            if (!inet_ntop(AF_INET, &sin->sin_addr, address, sizeof(address))) continue;
            (void)snprintf(out, capacity, "%s  %s", it->ifa_name, address);
            found = 1;
            break;
        }
        freeifaddrs(list);
    }
    if (!found) (void)snprintf(out, capacity, "Sem endereco IP");
    if (found && has_default_route()) {
        size_t n = strlen(out);
        if (n + 10 < capacity) (void)strncat(out, "  |  rota", capacity - n - 1);
    }
}

static void system_clock(char *out, size_t capacity)
{
    time_t now = time(NULL);
    struct tm value;
    if (localtime_r(&now, &value))
        (void)strftime(out, capacity, "%d/%m/%Y  %H:%M", &value);
    else
        (void)snprintf(out, capacity, "Relogio indisponivel");
}

static void draw_base(const char *title)
{
    char clock_text[64];
    char net[160];
    rect(0, 0, screen_w, screen_h, C_DARK);
    rect(0, 0, screen_w, HEADER_H, C_GREEN);
    rect(0, HEADER_H, SIDEBAR_W, screen_h - HEADER_H - FOOTER_H, C_PANEL);
    rect(0, screen_h - FOOTER_H, screen_w, FOOTER_H, C_PANEL2);
    draw_bold(18, 15, "XWT", C_WHITE);
    draw_text(68, 19, "X360 WEB TOTAL  /  XENON LINUX", C_WHITE);
    draw_bold(SIDEBAR_W + 22, 17, title, C_WHITE);
    system_clock(clock_text, sizeof(clock_text));
    draw_text(screen_w - 165, 20, clock_text, C_WHITE);
    network_summary(net, sizeof(net));
    (void)snprintf(status_line, sizeof(status_line), "%s", net);
    draw_text(14, screen_h - FOOTER_H + 8, status_line, C_MUTED);
    draw_text(screen_w - 235, screen_h - FOOTER_H + 8, "A/ENTER abrir   B/ESC voltar", C_WHITE);
}

static int app_columns(void)
{
    return screen_w >= 900 ? 3 : 2;
}

static SDL_Rect app_card(int index)
{
    int cols = app_columns();
    int area_x = SIDEBAR_W + 24;
    int area_w = screen_w - area_x - 24;
    int gap_x = 14;
    int gap_y = 12;
    int card_w = (area_w - (cols - 1) * gap_x) / cols;
    int rows = (APP_COUNT + cols - 1) / cols;
    int area_y = HEADER_H + 50;
    int area_h = screen_h - area_y - FOOTER_H - 18;
    int card_h = (area_h - (rows - 1) * gap_y) / rows;
    int col = index % cols;
    int row = index / cols;
    SDL_Rect r;
    r.x = (Sint16)(area_x + col * (card_w + gap_x));
    r.y = (Sint16)(area_y + row * (card_h + gap_y));
    r.w = (Uint16)card_w;
    r.h = (Uint16)card_h;
    return r;
}

static void draw_home(void)
{
    int i;
    char subtitle[160];
    draw_base("Desktop");
    draw_bold(18, HEADER_H + 18, "Bem-vindo ao seu Xbox Linux", C_WHITE);
    draw_text(18, HEADER_H + 42, "Um ambiente leve, modular e controlado pelo gamepad.", C_MUTED);
    draw_text(18, screen_h - FOOTER_H - 32, "SISTEMA", C_LIME);
    draw_text(18, screen_h - FOOTER_H - 10, "Linux Xenon", C_WHITE);
    for (i = 0; i < APP_COUNT; ++i) {
        SDL_Rect r = app_card(i);
        SDL_Color border = (i == selected_app) ? C_LIME : C_BORDER;
        SDL_Color fill = (i == selected_app) ? C_PANEL2 : C_PANEL;
        rect(r.x, r.y, r.w, r.h, fill);
        outline(r.x, r.y, r.w, r.h, border);
        rect(r.x, r.y, 5, r.h, (i == selected_app) ? C_LIME : C_GREEN);
        draw_bold(r.x + 16, r.y + 12, apps[i].title, C_WHITE);
        draw_text(r.x + 16, r.y + 42, apps[i].subtitle, C_MUTED);
        (void)snprintf(subtitle, sizeof(subtitle), "[%s]", apps[i].symbol);
        draw_text(r.x + (int)r.w - 70, r.y + 12, subtitle, C_LIME);
    }
    SDL_Flip(screen);
}

static int file_compare(const void *a, const void *b)
{
    const FileEntry *fa = (const FileEntry *)a;
    const FileEntry *fb = (const FileEntry *)b;
    if (fa->is_dir != fb->is_dir) return fb->is_dir - fa->is_dir;
    return strcasecmp(fa->name, fb->name);
}

static void load_files(void)
{
    DIR *dir = opendir(current_dir);
    struct dirent *item;
    entry_count = 0;
    selected_file = 0;
    file_scroll = 0;
    if (!dir) return;
    while ((item = readdir(dir)) != NULL && entry_count < FILE_LIMIT) {
        char full[PATH_MAX];
        struct stat st;
        FileEntry *entry;
        if (strcmp(item->d_name, ".") == 0 || strcmp(item->d_name, "..") == 0) continue;
        if (snprintf(full, sizeof(full), "%s/%s", current_dir, item->d_name) >= (int)sizeof(full)) continue;
        if (lstat(full, &st) != 0) continue;
        entry = &entries[entry_count++];
        (void)snprintf(entry->name, sizeof(entry->name), "%s", item->d_name);
        entry->is_dir = S_ISDIR(st.st_mode);
        entry->size = st.st_size;
    }
    closedir(dir);
    qsort(entries, entry_count, sizeof(entries[0]), file_compare);
}

static void format_size(off_t size, char *out, size_t capacity)
{
    if (size >= 1024 * 1024) (void)snprintf(out, capacity, "%.1f MB", (double)size / (1024.0 * 1024.0));
    else if (size >= 1024) (void)snprintf(out, capacity, "%.1f KB", (double)size / 1024.0);
    else (void)snprintf(out, capacity, "%lld B", (long long)size);
}

static void draw_files(void)
{
    char cwd[PATH_MAX + 16];
    size_t i;
    int y = HEADER_H + 64;
    int visible = (screen_h - y - FOOTER_H - 20) / 29;
    if (visible < 1) visible = 1;
    draw_base("Arquivos");
    (void)snprintf(cwd, sizeof(cwd), "%s", current_dir);
    draw_bold(SIDEBAR_W + 22, HEADER_H + 16, cwd, C_LIME);
    draw_text(SIDEBAR_W + 22, HEADER_H + 40, "A/ENTER abrir  |  B voltar  |  arquivos de texto no less", C_MUTED);
    if (strcmp(current_dir, "/") != 0) {
        SDL_Color c = (selected_file == 0) ? C_LIME : C_WHITE;
        rect(SIDEBAR_W + 18, y - 2, screen_w - SIDEBAR_W - 36, 26, selected_file == 0 ? C_PANEL2 : C_DARK);
        draw_bold(SIDEBAR_W + 28, y + 2, "..  [pasta anterior]", c);
        y += 29;
    }
    for (i = (size_t)file_scroll; i < entry_count && i < (size_t)(file_scroll + visible); ++i) {
        size_t logical = i + (strcmp(current_dir, "/") != 0 ? 1U : 0U);
        char size_text[32];
        char line[300];
        SDL_Color color = ((int)logical == selected_file) ? C_LIME : (entries[i].is_dir ? C_WHITE : C_MUTED);
        if ((int)logical == selected_file) rect(SIDEBAR_W + 18, y - 2, screen_w - SIDEBAR_W - 36, 26, C_PANEL2);
        format_size(entries[i].size, size_text, sizeof(size_text));
        (void)snprintf(line, sizeof(line), "%s  %s", entries[i].is_dir ? "[DIR]" : "[FILE]", entries[i].name);
        draw_text(SIDEBAR_W + 28, y + 2, line, color);
        draw_text(screen_w - 108, y + 2, entries[i].is_dir ? "" : size_text, C_MUTED);
        y += 29;
    }
    if (entry_count == 0) draw_text(SIDEBAR_W + 28, y + 8, "Pasta vazia ou sem permissao de leitura.", C_MUTED);
    SDL_Flip(screen);
}

static void draw_system(void)
{
    FILE *f;
    char line[256];
    char cpu[160] = "PowerPC Xenon";
    char mem_total[64] = "?";
    char mem_avail[64] = "?";
    char uptime[64] = "?";
    char net[160];
    if ((f = fopen("/proc/cpuinfo", "r")) != NULL) {
        while (fgets(line, sizeof(line), f)) {
            if (strncmp(line, "cpu", 3) == 0 || strncmp(line, "model", 5) == 0) {
                char *colon = strchr(line, ':');
                if (colon) { colon++; while (*colon == ' ' || *colon == '\t') colon++; (void)snprintf(cpu, sizeof(cpu), "%s", colon); cpu[strcspn(cpu, "\r\n")] = '\0'; break; }
            }
        }
        fclose(f);
    }
    if ((f = fopen("/proc/meminfo", "r")) != NULL) {
        while (fgets(line, sizeof(line), f)) {
            if (sscanf(line, "MemTotal: %63s", mem_total) == 1) continue;
            if (sscanf(line, "MemAvailable: %63s", mem_avail) == 1) continue;
        }
        fclose(f);
    }
    if ((f = fopen("/proc/uptime", "r")) != NULL) {
        double seconds = 0;
        if (fscanf(f, "%lf", &seconds) == 1) {
            unsigned long mins = (unsigned long)(seconds / 60.0);
            (void)snprintf(uptime, sizeof(uptime), "%lu h %lu min", mins / 60UL, mins % 60UL);
        }
        fclose(f);
    }
    network_summary(net, sizeof(net));
    draw_base("Sistema");
    draw_bold(SIDEBAR_W + 24, HEADER_H + 26, "Informacoes do sistema", C_WHITE);
    draw_text(SIDEBAR_W + 24, HEADER_H + 66, "Plataforma: Xbox 360 / Xenon", C_LIME);
    draw_text(SIDEBAR_W + 24, HEADER_H + 104, "Processador:", C_WHITE);
    draw_text(SIDEBAR_W + 142, HEADER_H + 104, cpu, C_LIME);
    draw_text(SIDEBAR_W + 24, HEADER_H + 136, "A contagem de CPUs e exibida conforme o kernel detecta.", C_MUTED);
    draw_text(SIDEBAR_W + 24, HEADER_H + 178, "Memoria total: (kB)", C_WHITE);
    draw_text(SIDEBAR_W + 190, HEADER_H + 178, mem_total, C_LIME);
    draw_text(SIDEBAR_W + 24, HEADER_H + 208, "Memoria disponivel: (kB)", C_WHITE);
    draw_text(SIDEBAR_W + 190, HEADER_H + 208, mem_avail, C_LIME);
    draw_text(SIDEBAR_W + 24, HEADER_H + 250, "Tempo ligado:", C_WHITE);
    draw_text(SIDEBAR_W + 190, HEADER_H + 250, uptime, C_LIME);
    draw_text(SIDEBAR_W + 24, HEADER_H + 292, "Rede:", C_WHITE);
    draw_text(SIDEBAR_W + 105, HEADER_H + 292, net, C_LIME);
    draw_text(SIDEBAR_W + 24, HEADER_H + 330, "Armazenamento persistente: USB FAT32 (sem gravacao NAND)", C_MUTED);
    draw_text(SIDEBAR_W + 24, HEADER_H + 358, "Video: Xenos DRM/framebuffer; aceleracao 3D nao garantida", C_MUTED);
    SDL_Flip(screen);
}

static int gui_reopen(void)
{
    return gui_init();
}

static void run_child(char *const argv[])
{
    pid_t pid;
    int status;
    gui_shutdown();
    pid = fork();
    if (pid == 0) {
        (void)setenv("TERM", "linux", 1);
        (void)setenv("DIALOGRC", "/etc/dialogrc", 1);
        execvp(argv[0], argv);
        perror(argv[0]);
        execl("/bin/sh", "sh", "-l", (char *)NULL);
        _exit(127);
    }
    if (pid > 0) {
        while (waitpid(pid, &status, 0) < 0 && errno == EINTR) { }
    }
    if (gui_reopen() != 0) { fprintf(stderr, "XWT Desktop: nao foi possivel restaurar o framebuffer.\n"); exit(2); }
}

static void run_shell_command(const char *command)
{
    char *const args[] = {"/bin/sh", "-c", (char *)command, NULL};
    run_child(args);
}

static void run_browser(const char *url)
{
    pid_t pid;
    int status;
    gui_shutdown();
    pid = fork();
    if (pid == 0) {
        execlp("netsurf", "netsurf", url, (char *)NULL);
        execlp("netsurf-fb", "netsurf-fb", url, (char *)NULL);
        fprintf(stderr, "Navegador nao instalado nesta compilacao.\n");
        execlp("dialog", "dialog", "--title", "Navegador", "--msgbox",
               "O navegador ainda nao foi incluido nesta imagem. A interface do desktop continua disponivel.",
               "10", "72", (char *)NULL);
        _exit(127);
    }
    if (pid > 0) while (waitpid(pid, &status, 0) < 0 && errno == EINTR) { }
    if (gui_reopen() != 0) { fprintf(stderr, "XWT Desktop: nao foi possivel restaurar o framebuffer.\n"); exit(2); }
}

static void open_selected_file(void)
{
    size_t index;
    char path[PATH_MAX];
    char resolved[PATH_MAX];
    char url[PATH_MAX + 16];
    const char *ext;
    if (strcmp(current_dir, "/") != 0 && selected_file == 0) {
        char *slash = strrchr(current_dir, '/');
        if (slash == current_dir) current_dir[1] = '\0';
        else if (slash) *slash = '\0';
        load_files();
        return;
    }
    index = (size_t)selected_file - (strcmp(current_dir, "/") != 0 ? 1U : 0U);
    if (index >= entry_count) return;
    if (snprintf(path, sizeof(path), "%s/%s", current_dir, entries[index].name) >= (int)sizeof(path)) return;
    if (!realpath(path, resolved)) return;
    if (entries[index].is_dir) {
        (void)snprintf(current_dir, sizeof(current_dir), "%s", resolved);
        load_files();
        return;
    }
    ext = strrchr(resolved, '.');
    if (ext && (strcasecmp(ext, ".html") == 0 || strcasecmp(ext, ".htm") == 0 || strcasecmp(ext, ".xhtml") == 0)) {
        if (snprintf(url, sizeof(url), "file://%s", resolved) < (int)sizeof(url)) run_browser(url);
    } else {
        char *const args[] = {"less", "--", resolved, NULL};
        run_child(args);
    }
}

static void launch_app(int app)
{
    switch (app) {
    case 0: run_browser("about:blank"); break;
    case 1: {
        char *const args[] = {"/usr/sbin/xwt-wifi", "menu", NULL};
        run_child(args);
        break;
    }
    case 2:
        run_shell_command("/usr/sbin/xwt-network check > /tmp/xwt-network-report.txt 2>&1; dialog --title 'Diagnostico de Internet' --textbox /tmp/xwt-network-report.txt 22 78");
        break;
    case 3:
        if (access("/mnt/xwt-usb/X360WebTotal", R_OK | X_OK) == 0) (void)snprintf(current_dir, sizeof(current_dir), "/mnt/xwt-usb/X360WebTotal");
        else (void)snprintf(current_dir, sizeof(current_dir), "/");
        load_files(); page = PAGE_FILES; break;
    case 4: page = PAGE_SYSTEM; break;
    case 5: {
        char *const args[] = {"/bin/sh", "-l", NULL};
        run_child(args);
        break;
    }
    case 6:
        run_shell_command("if command -v alsamixer >/dev/null 2>&1; then alsamixer; elif command -v aplay >/dev/null 2>&1; then aplay -l; else echo 'ALSA nao esta disponivel nesta imagem.'; read -r _; fi");
        break;
    case 7:
        run_shell_command("choice=$(dialog --stdout --menu 'Energia do sistema' 11 58 2 reboot 'Reiniciar Linux' poweroff 'Desligar console') || exit 0; case \"$choice\" in reboot) sync; reboot ;; poweroff) sync; poweroff ;; esac");
        break;
    default: break;
    }
}

static void handle_home_key(SDLKey key)
{
    int cols = app_columns();
    int row = selected_app / cols;
    int col = selected_app % cols;
    int rows = (APP_COUNT + cols - 1) / cols;
    if (key == SDLK_LEFT && col > 0) selected_app--;
    else if (key == SDLK_RIGHT && col < cols - 1 && selected_app + 1 < APP_COUNT) selected_app++;
    else if (key == SDLK_UP && row > 0) selected_app -= cols;
    else if (key == SDLK_DOWN && row + 1 < rows) {
        int target = selected_app + cols;
        if (target < APP_COUNT) selected_app = target;
    }
    else if (key == SDLK_RETURN || key == SDLK_KP_ENTER || key == SDLK_SPACE) launch_app(selected_app);
}

static void handle_key(SDLKey key)
{
    if (page == PAGE_HOME) {
        handle_home_key(key);
        return;
    }
    if (page == PAGE_FILES) {
        int offset = strcmp(current_dir, "/") != 0 ? 1 : 0;
        int visible = (screen_h - (HEADER_H + 64) - FOOTER_H - 20) / 29;
        int max_index = (int)entry_count + offset - 1;
        if (visible < 1) visible = 1;
        if (key == SDLK_ESCAPE || key == SDLK_BACKSPACE) { page = PAGE_HOME; return; }
        if (key == SDLK_UP && selected_file > 0) selected_file--;
        else if (key == SDLK_DOWN && selected_file < max_index) selected_file++;
        else if (key == SDLK_RETURN || key == SDLK_KP_ENTER || key == SDLK_SPACE) open_selected_file();
        if (selected_file < file_scroll) file_scroll = selected_file;
        if (selected_file >= file_scroll + visible) file_scroll = selected_file - visible + 1;
        return;
    }
    if (key == SDLK_ESCAPE || key == SDLK_BACKSPACE || key == SDLK_RETURN) page = PAGE_HOME;
}

static int point_in(SDL_Rect r, int x, int y)
{
    return x >= r.x && y >= r.y && x < r.x + r.w && y < r.y + r.h;
}

static void handle_mouse(int x, int y)
{
    int i;
    if (page != PAGE_HOME) return;
    for (i = 0; i < APP_COUNT; ++i) {
        SDL_Rect r = app_card(i);
        if (point_in(r, x, y)) {
            selected_app = i;
            launch_app(i);
            return;
        }
    }
}

int main(void)
{
    SDL_Event event;
    (void)snprintf(current_dir, sizeof(current_dir), "%s", access("/mnt/xwt-usb/X360WebTotal", R_OK | X_OK) == 0 ? "/mnt/xwt-usb/X360WebTotal" : "/");
    load_files();
    (void)setenv("SDL_VIDEODRIVER", "fbcon", 0);
    (void)setenv("SDL_FBDEV", "/dev/fb0", 0);
    if (gui_init() != 0) {
        fprintf(stderr, "XWT Desktop: SDL/framebuffer nao iniciou: %s\n", SDL_GetError());
        return 1;
    }
    (void)snprintf(status_line, sizeof(status_line), "Desktop iniciado");
    for (;;) {
        while (SDL_PollEvent(&event)) {
            if (event.type == SDL_QUIT) page = PAGE_HOME;
            else if (event.type == SDL_KEYDOWN) handle_key(event.key.keysym.sym);
            else if (event.type == SDL_MOUSEBUTTONDOWN && event.button.button == SDL_BUTTON_LEFT)
                handle_mouse(event.button.x, event.button.y);
        }
        if (page == PAGE_HOME) draw_home();
        else if (page == PAGE_FILES) draw_files();
        else draw_system();
        SDL_Delay(45);
    }
    gui_shutdown();
    return 0;
}
