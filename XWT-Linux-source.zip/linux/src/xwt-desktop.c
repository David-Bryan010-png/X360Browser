/*
 * X360 Web Total - Xenon Desktop
 * Lightweight SDL 1.2 + SDL_ttf desktop shell for the Xbox 360 Linux port.
 * The shell is deliberately independent from the browser engine: applications
 * are launched as separate processes and may be replaced/extended later.
 * No NAND, SMC, KV, bootloader or flash access is performed here.
 */
#define _DEFAULT_SOURCE
#define _POSIX_C_SOURCE 200809L

#include <SDL.h>
#include <SDL_ttf.h>

#include <fcntl.h>
#include <linux/fb.h>
#include <sys/ioctl.h>

#include <dirent.h>
#include <errno.h>
#include <ifaddrs.h>
#include <limits.h>
#include <net/if.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/stat.h>
#include <sys/statvfs.h>
#include <sys/utsname.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>
#include <arpa/inet.h>

#define APP_COUNT 15
#define FILE_LIMIT 320
#define HEADER_H 58
#define FOOTER_H 30
#define SIDEBAR_W 160
#define STATUS_REFRESH_MS 2000
#define TASKBAR_H 38
#define DESK_COUNT 8
#define SETTINGS_COUNT 10
#define XWT_VERSION_TEXT "1.0.0"
#define ASSET_DIR "/usr/share/xwt/"
#define FONT_PATH "/usr/share/fonts/dejavu/DejaVuSans.ttf"
#define FONT_BOLD_PATH "/usr/share/fonts/dejavu/DejaVuSans-Bold.ttf"

typedef enum { PAGE_HOME = 0, PAGE_FILES, PAGE_SETTINGS } Page;

typedef struct {
    char name[256];
    off_t size;
    int is_dir;
} FileEntry;

typedef struct {
    const char *title;
    const char *subtitle;
    const char *symbol;
} AppEntry;

static const AppEntry apps[APP_COUNT] = {
    {"Navegador", "Internet e web", "WEB"},
    {"Wi-Fi", "Redes sem fio USB", "WIFI"},
    {"Internet", "Diagnostico de rede", "NET"},
    {"Arquivos", "USB e documentos", "FILES"},
    {"Sistema", "CPU, memoria, temp.", "SYS"},
    {"Armazenamento", "USB, HD e cartoes", "DISK"},
    {"Controle", "Testar gamepad", "PAD"},
    {"Audio", "Dispositivos e volume", "AUDIO"},
    {"Atualizacoes", "Modulos .xwpkg", "UPD"},
    {"Logs", "Boot, video e kernel", "LOG"},
    {"Terminal", "Shell de manutencao", "TERM"},
    {"Energia", "Reiniciar ou desligar", "POWER"},
    {"Jogos", "Doom e jogos livres", "GAME"},
    {"Video", "Saida e resolucao", "VIDEO"},
    {"Aplicativos", "Musica, imagens e utilitarios", "APPS"}
};

typedef struct {
    char clock[64];
    char net[160];
    char kernel[96];
    char load[48];
    unsigned long mem_total_kb;
    unsigned long mem_avail_kb;
    unsigned long uptime_s;
    int temp_c;          /* -1 when no hwmon sensor is exposed */
    int cpus;
    unsigned long usb_free_mb;
    int usb_mounted;
    int net_up;
    char ip[48];
    char gw[48];
    char dns[48];
    char netkind[16];
} Status;

static Status status;
static int need_redraw = 1;
static int fb_info_w, fb_info_h, fb_info_bpp;

static SDL_Surface *screen;
static TTF_Font *font_regular;
static TTF_Font *font_bold;
static TTF_Font *font_big;
static TTF_Font *font_mid;
static int settings_sel;
static int screen_w = 640;
static int screen_h = 480;
static int selected_app;
static int selected_file;
static int file_scroll;
static Page page = PAGE_HOME;
static char current_dir[PATH_MAX] = "/mnt/xwt-usb";
static FileEntry entries[FILE_LIMIT];
static size_t entry_count;
static char status_line[256] = "Inicializando sistema";

static const SDL_Color C_WHITE = {245, 247, 244, 255};
static const SDL_Color C_MUTED = {174, 183, 174, 255};
static const SDL_Color C_GREEN = {16, 124, 16, 255};
static const SDL_Color C_LIME = {107, 190, 70, 255};
static const SDL_Color C_DARK = {17, 22, 19, 255};
static const SDL_Color C_PANEL = {29, 36, 31, 255};
static const SDL_Color C_PANEL2 = {38, 47, 40, 255};
static const SDL_Color C_BORDER = {68, 83, 70, 255};
static const SDL_Color C_WARN = {232, 163, 23, 255};
static const SDL_Color C_SKY = {26, 86, 170, 255};
static const SDL_Color C_BAR = {10, 20, 44, 255};
static const SDL_Color C_SEL = {24, 64, 112, 255};
static const SDL_Color C_WIN = {14, 24, 48, 255};
static const SDL_Color C_HILITE = {30, 110, 240, 255};

static Uint32 rgb(Uint8 r, Uint8 g, Uint8 b)
{
    return SDL_MapRGB(screen->format, r, g, b);
}

static void rect(int x, int y, int w, int h, SDL_Color color)
{
    SDL_Rect r;
    if (w <= 0 || h <= 0) return;
    r.x = (Sint16)x; r.y = (Sint16)y;
    r.w = (Uint16)w; r.h = (Uint16)h;
    SDL_FillRect(screen, &r, rgb(color.r, color.g, color.b));
}

static void outline(int x, int y, int w, int h, SDL_Color color)
{
    rect(x, y, w, 1, color);
    rect(x, y + h - 1, w, 1, color);
    rect(x, y, 1, h, color);
    rect(x + w - 1, y, 1, h, color);
}

static void draw_text_font(TTF_Font *font, int x, int y, const char *value, SDL_Color color)
{
    SDL_Surface *glyph;
    SDL_Rect dest;
    if (!font || !value || !*value) return;
    glyph = TTF_RenderUTF8_Blended(font, value, color);
    if (!glyph) return;
    dest.x = (Sint16)x;
    dest.y = (Sint16)y;
    dest.w = (Uint16)glyph->w;
    dest.h = (Uint16)glyph->h;
    SDL_BlitSurface(glyph, NULL, screen, &dest);
    SDL_FreeSurface(glyph);
}

static void draw_text(int x, int y, const char *value, SDL_Color color)
{
    draw_text_font(font_regular, x, y, value, color);
}

static void draw_bold(int x, int y, const char *value, SDL_Color color)
{
    draw_text_font(font_bold ? font_bold : font_regular, x, y, value, color);
}

/* ---- art assets (BMP, colour key magenta); the desktop still works without them ------------- */
typedef enum {
    A_ICON_WEB, A_ICON_FOLDER, A_ICON_GAME, A_ICON_TERM, A_ICON_GEAR, A_ICON_HELP, A_ICON_POWER, A_ICON_APPS,
    A_GL_SYSTEM, A_GL_NETWORK, A_GL_VIDEO, A_GL_AUDIO, A_GL_PAD, A_GL_STORAGE, A_GL_UPDATE, A_GL_LOG, A_GL_ABOUT,
    A_GL_GEAR_TITLE, A_XLOGO, A_BAR_LOGO, A_WIFI_ON, A_WIFI_OFF, A_DRIVE_ON, A_DRIVE_OFF, A_COUNT
} AssetId;

static const char *const asset_files[A_COUNT] = {
    "icon-web.bmp", "icon-folder.bmp", "icon-game.bmp", "icon-term.bmp", "icon-gear.bmp", "icon-help.bmp", "icon-power.bmp", "icon-apps.bmp",
    "glyph-system.bmp", "glyph-network.bmp", "glyph-video.bmp", "glyph-audio.bmp", "glyph-pad.bmp", "glyph-storage.bmp",
    "glyph-update.bmp", "glyph-log.bmp", "glyph-about.bmp", "glyph-gear-title.bmp", "xlogo.bmp", "bar-logo.bmp",
    "bar-wifi-on.bmp", "bar-wifi-off.bmp", "bar-drive-on.bmp", "bar-drive-off.bmp"
};
static SDL_Surface *assets[A_COUNT];
static SDL_Surface *wallpaper_surf;

static SDL_Surface *load_bmp_asset(const char *file, int keyed)
{
    char path[PATH_MAX];
    SDL_Surface *raw, *converted;
    (void)snprintf(path, sizeof(path), ASSET_DIR "%s", file);
    raw = SDL_LoadBMP(path);
    if (!raw) return NULL;
    if (keyed) (void)SDL_SetColorKey(raw, SDL_SRCCOLORKEY, SDL_MapRGB(raw->format, 255, 0, 255));
    converted = SDL_DisplayFormat(raw);
    SDL_FreeSurface(raw);
    return converted;
}

static void assets_load(void)
{
    char name[64];
    int i;
    for (i = 0; i < A_COUNT; ++i) assets[i] = load_bmp_asset(asset_files[i], 1);
    (void)snprintf(name, sizeof(name), "wallpaper-%dx%d.bmp", screen_w, screen_h);
    wallpaper_surf = load_bmp_asset(name, 0);
}

static void assets_free(void)
{
    int i;
    for (i = 0; i < A_COUNT; ++i) {
        if (assets[i]) SDL_FreeSurface(assets[i]);
        assets[i] = NULL;
    }
    if (wallpaper_surf) SDL_FreeSurface(wallpaper_surf);
    wallpaper_surf = NULL;
}

static void blit(SDL_Surface *image, int x, int y)
{
    SDL_Rect dest;
    if (!image) return;
    dest.x = (Sint16)x;
    dest.y = (Sint16)y;
    dest.w = (Uint16)image->w;
    dest.h = (Uint16)image->h;
    SDL_BlitSurface(image, NULL, screen, &dest);
}

static int mouse_x, mouse_y, mouse_seen;

/* Little arrow pointer, drawn only after the mouse (L3 mode or a USB mouse) was used. */
static void draw_cursor(void)
{
    int row, col;
    if (!mouse_seen) return;
    for (row = 0; row < 18; ++row) {
        int width = row < 12 ? row / 1 + 1 : 12 - (row - 12) * 2;
        if (width < 1) width = 1;
        if (width > 12) width = 12;
        for (col = 0; col < width; ++col) {
            SDL_Rect px;
            px.x = (Sint16)(mouse_x + col); px.y = (Sint16)(mouse_y + row); px.w = 1; px.h = 1;
            SDL_FillRect(screen, &px, SDL_MapRGB(screen->format, (col == 0 || col == width - 1 || row == 0) ? 0 : 255, (col == 0 || col == width - 1 || row == 0) ? 0 : 255, (col == 0 || col == width - 1 || row == 0) ? 0 : 255));
        }
    }
}

static int pointer_on;

/* /run/xwt-pointer is written by xwt-gamepad-keys when L3 toggles the controller mouse. */
static int read_pointer_state(void)
{
    char buf[4] = {0};
    FILE *f = fopen("/run/xwt-pointer", "r");
    if (!f) return 0;
    if (!fgets(buf, sizeof(buf), f)) buf[0] = 0;
    fclose(f);
    return buf[0] == 'o' && buf[1] == 'n';
}

static void draw_pointer_badge(void)
{
    SDL_Rect r;
    SDL_Color white = {255, 255, 255, 0};
    if (!pointer_on) return;
    r.x = 12; r.y = (Sint16)(screen_h - 44); r.w = 470; r.h = 32;
    SDL_FillRect(screen, &r, SDL_MapRGB(screen->format, 20, 110, 240));
    draw_text(24, screen_h - 40, "Modo mouse (L3)  A clica  B direito  R3 teclado", white);
}

static void draw_osk(void);

static void present(void)
{
    draw_osk();
    draw_pointer_badge();
    draw_cursor();
    SDL_Flip(screen);
}

static int probe_framebuffer(int *width, int *height, int *bits_per_pixel)
{
    struct fb_var_screeninfo var;
    struct fb_fix_screeninfo fix;
    int fd = open("/dev/fb0", O_RDWR | O_CLOEXEC);
    unsigned long long visible_bytes;
    unsigned long long mapped_bytes;
    if (fd < 0) return -1;
    if (ioctl(fd, FBIOGET_VSCREENINFO, &var) != 0 ||
        ioctl(fd, FBIOGET_FSCREENINFO, &fix) != 0) {
        close(fd);
        return -1;
    }
    close(fd);
    if (var.xres < 640 || var.yres < 480 || var.xres > 4096 || var.yres > 2160)
        return -1;
    if (var.bits_per_pixel != 16 && var.bits_per_pixel != 32) return -1;
    if (var.xres_virtual < var.xres || var.yres_virtual < var.yres) return -1;
    if (fix.line_length < var.xres_virtual * (var.bits_per_pixel / 8U)) return -1;
    visible_bytes = (unsigned long long)fix.line_length * var.yres;
    mapped_bytes = (unsigned long long)fix.line_length * var.yres_virtual;
    if (fix.smem_len < visible_bytes || fix.smem_len < mapped_bytes) return -1;
    *width = (int)var.xres;
    *height = (int)var.yres;
    *bits_per_pixel = (int)var.bits_per_pixel;
    fb_info_w = *width; fb_info_h = *height; fb_info_bpp = *bits_per_pixel;
    return 0;
}

static void write_gui_state(int on)
{
    FILE *f = fopen("/run/xwt-gui", "w");
    if (!f) return;
    fputs(on ? "1\n" : "0\n", f);
    fclose(f);
}

static int gui_init(void)
{
    int fb_width = 0, fb_height = 0, fb_bpp = 0;
    if (probe_framebuffer(&fb_width, &fb_height, &fb_bpp) != 0) {
        fprintf(stderr, "XWT Desktop: /dev/fb0 ausente ou modo framebuffer invalido.\n");
        return -1;
    }
    (void)setenv("SDL_VIDEODRIVER", "fbcon", 1);
    (void)setenv("SDL_FBDEV", "/dev/fb0", 1);
    (void)setenv("SDL_MOUSEDRV", "IMPS2", 0);   /* virtual mouse from the controller (L3) */
    (void)setenv("SDL_MOUSEDEV", "/dev/input/mice", 0);
    if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_TIMER) < 0) return -1;
    if (TTF_Init() < 0) { SDL_Quit(); return -1; }
    screen_w = fb_width;
    screen_h = fb_height;
    screen = SDL_SetVideoMode(screen_w, screen_h, fb_bpp, SDL_SWSURFACE | SDL_FULLSCREEN);
    if (!screen && fb_bpp != 32)
        screen = SDL_SetVideoMode(screen_w, screen_h, 32, SDL_SWSURFACE | SDL_FULLSCREEN);
    if (!screen && fb_bpp != 16)
        screen = SDL_SetVideoMode(screen_w, screen_h, 16, SDL_SWSURFACE | SDL_FULLSCREEN);
    if (!screen) { TTF_Quit(); SDL_Quit(); return -1; }
    if (screen->w != fb_width || screen->h != fb_height) {
        fprintf(stderr, "XWT Desktop: SDL abriu %dx%d, framebuffer informado %dx%d.\n",
                screen->w, screen->h, fb_width, fb_height);
        screen = NULL;
        TTF_Quit(); SDL_Quit();
        return -1;
    }
    write_gui_state(1);
    assets_load();
    font_regular = TTF_OpenFont(FONT_PATH, screen_h >= 600 ? 17 : 14);
    font_bold = TTF_OpenFont(FONT_BOLD_PATH, screen_h >= 600 ? 20 : 17);
    font_big = TTF_OpenFont(FONT_BOLD_PATH, screen_h >= 600 ? 84 : 52);
    font_mid = TTF_OpenFont(FONT_PATH, screen_h >= 600 ? 28 : 20);
    if (!font_regular) font_regular = font_bold;
    if (!font_bold) font_bold = font_regular;
    if (!font_regular) { TTF_Quit(); SDL_Quit(); return -1; }
    SDL_ShowCursor(SDL_DISABLE);
    SDL_EnableKeyRepeat(SDL_DEFAULT_REPEAT_DELAY, SDL_DEFAULT_REPEAT_INTERVAL);
    SDL_WM_SetCaption("X360 Web Total - Xenon Desktop", "XWT");
    return 0;
}

static void gui_shutdown(void)
{
    write_gui_state(0);
    if (font_bold && font_bold != font_regular) TTF_CloseFont(font_bold);
    if (font_big) TTF_CloseFont(font_big);
    if (font_mid) TTF_CloseFont(font_mid);
    font_big = NULL;
    font_mid = NULL;
    assets_free();
    if (font_regular) TTF_CloseFont(font_regular);
    font_regular = NULL;
    font_bold = NULL;
    screen = NULL;
    TTF_Quit();
    SDL_Quit();
}

static int has_default_route(void)
{
    FILE *f = fopen("/proc/net/route", "r");
    char line[256];
    if (!f) return 0;
    (void)fgets(line, sizeof(line), f);
    while (fgets(line, sizeof(line), f)) {
        char iface[64], destination[32];
        unsigned long gateway, flags;
        if (sscanf(line, "%63s %31s %lx %lx", iface, destination, &gateway, &flags) == 4 &&
            strcmp(destination, "00000000") == 0 && (flags & 1UL)) {
            fclose(f);
            return 1;
        }
    }
    fclose(f);
    return 0;
}

static void network_summary(char *out, size_t capacity)
{
    struct ifaddrs *list = NULL, *it;
    int found = 0;
    char address[INET_ADDRSTRLEN];
    if (getifaddrs(&list) == 0) {
        for (it = list; it; it = it->ifa_next) {
            struct sockaddr_in *sin;
            if (!it->ifa_addr || it->ifa_addr->sa_family != AF_INET) continue;
            if ((it->ifa_flags & IFF_LOOPBACK) || strcmp(it->ifa_name, "lo") == 0) continue;
            sin = (struct sockaddr_in *)it->ifa_addr;
            if (!inet_ntop(AF_INET, &sin->sin_addr, address, sizeof(address))) continue;
            (void)snprintf(out, capacity, "%s  %s", it->ifa_name, address);
            found = 1;
            break;
        }
        freeifaddrs(list);
    }
    if (!found) (void)snprintf(out, capacity, "Sem endereco IP");
    if (found && has_default_route()) {
        size_t n = strlen(out);
        if (n + 10 < capacity) (void)strncat(out, "  |  rota", capacity - n - 1);
    }
}

/* IP, gateway, DNS and link type for the Settings > Rede page (refreshed, never in the draw path). */
static void net_details(void)
{
    struct ifaddrs *list = NULL, *it;
    char iface[IF_NAMESIZE] = "";
    FILE *f;
    char line[256];
    status.ip[0] = status.gw[0] = status.dns[0] = '\0';
    (void)snprintf(status.netkind, sizeof(status.netkind), "-");
    if (getifaddrs(&list) == 0) {
        for (it = list; it; it = it->ifa_next) {
            struct sockaddr_in *sin;
            if (!it->ifa_addr || it->ifa_addr->sa_family != AF_INET) continue;
            if ((it->ifa_flags & IFF_LOOPBACK) || strcmp(it->ifa_name, "lo") == 0) continue;
            sin = (struct sockaddr_in *)it->ifa_addr;
            if (!inet_ntop(AF_INET, &sin->sin_addr, status.ip, sizeof(status.ip))) { status.ip[0] = '\0'; continue; }
            (void)snprintf(iface, sizeof(iface), "%s", it->ifa_name);
            break;
        }
        freeifaddrs(list);
    }
    if (iface[0]) (void)snprintf(status.netkind, sizeof(status.netkind), "%s", strncmp(iface, "wl", 2) == 0 ? "Wi-Fi" : "Ethernet");
    if ((f = fopen("/proc/net/route", "r")) != NULL) {
        (void)fgets(line, sizeof(line), f);
        while (fgets(line, sizeof(line), f)) {
            char name[64], destination[32];
            unsigned long gateway, flags;
            if (sscanf(line, "%63s %31s %lx %lx", name, destination, &gateway, &flags) == 4 &&
                strcmp(destination, "00000000") == 0 && (flags & 1UL)) {
                struct in_addr address;
                /* The kernel prints the raw big-endian field with %08X, so it round-trips on any CPU. */
                address.s_addr = (in_addr_t)gateway;
                (void)inet_ntop(AF_INET, &address, status.gw, sizeof(status.gw));
                break;
            }
        }
        fclose(f);
    }
    if ((f = fopen("/etc/resolv.conf", "r")) != NULL) {
        while (fgets(line, sizeof(line), f)) {
            char value[48];
            if (sscanf(line, "nameserver %47s", value) == 1) { (void)snprintf(status.dns, sizeof(status.dns), "%s", value); break; }
        }
        fclose(f);
    }
}

static void system_clock(char *out, size_t capacity)
{
    time_t now = time(NULL);
    struct tm value;
    if (localtime_r(&now, &value))
        (void)strftime(out, capacity, "%d/%m/%Y  %H:%M", &value);
    else
        (void)snprintf(out, capacity, "Relogio indisponivel");
}

/* Draw text that never spills outside max_w pixels (UTF-8 safe ellipsis). */
static void draw_text_clip(TTF_Font *font, int x, int y, int max_w, const char *value, SDL_Color color)
{
    char buf[300];
    char shown[310];
    int w = 0, h = 0;
    size_t n;
    if (!font || !value || max_w <= 8) return;
    (void)snprintf(buf, sizeof(buf), "%s", value);
    if (TTF_SizeUTF8(font, buf, &w, &h) == 0 && w <= max_w) {
        draw_text_font(font, x, y, buf, color);
        return;
    }
    n = strlen(buf);
    while (n > 1) {
        n--;
        while (n > 0 && ((unsigned char)buf[n] & 0xC0U) == 0x80U) n--;
        buf[n] = '\0';
        (void)snprintf(shown, sizeof(shown), "%s...", buf);
        if (TTF_SizeUTF8(font, shown, &w, &h) == 0 && w <= max_w) {
            draw_text_font(font, x, y, shown, color);
            return;
        }
    }
}

static void draw_bar(int x, int y, int w, int h, int percent, SDL_Color fill)
{
    int inner;
    if (percent < 0) percent = 0;
    if (percent > 100) percent = 100;
    rect(x, y, w, h, C_DARK);
    outline(x, y, w, h, C_BORDER);
    inner = ((w - 4) * percent) / 100;
    rect(x + 2, y + 2, inner, h - 4, fill);
}

static int read_hwmon_temp_c(void)
{
    DIR *dir = opendir("/sys/class/hwmon");
    struct dirent *item;
    int best = -1;
    if (!dir) return -1;
    while ((item = readdir(dir)) != NULL) {
        int idx;
        if (item->d_name[0] == '.') continue;
        for (idx = 1; idx <= 4; ++idx) {
            char path[PATH_MAX];
            FILE *f;
            long milli;
            if (snprintf(path, sizeof(path), "/sys/class/hwmon/%s/temp%d_input", item->d_name, idx) >= (int)sizeof(path)) continue;
            f = fopen(path, "r");
            if (!f) continue;
            if (fscanf(f, "%ld", &milli) == 1 && milli > 0 && milli < 150000L && (int)(milli / 1000L) > best)
                best = (int)(milli / 1000L);
            fclose(f);
        }
    }
    closedir(dir);
    return best;
}

static void refresh_status(void)
{
    FILE *f;
    char line[256];
    struct utsname un;
    struct statvfs vfs;
    status.mem_total_kb = status.mem_avail_kb = 0;
    if ((f = fopen("/proc/meminfo", "r")) != NULL) {
        while (fgets(line, sizeof(line), f)) {
            unsigned long value;
            if (sscanf(line, "MemTotal: %lu", &value) == 1) status.mem_total_kb = value;
            else if (sscanf(line, "MemAvailable: %lu", &value) == 1) status.mem_avail_kb = value;
        }
        fclose(f);
    }
    status.uptime_s = 0;
    if ((f = fopen("/proc/uptime", "r")) != NULL) {
        double seconds = 0;
        if (fscanf(f, "%lf", &seconds) == 1 && seconds >= 0) status.uptime_s = (unsigned long)seconds;
        fclose(f);
    }
    (void)snprintf(status.load, sizeof(status.load), "?");
    if ((f = fopen("/proc/loadavg", "r")) != NULL) {
        char a[16] = "", b[16] = "", c[16] = "";
        if (fscanf(f, "%15s %15s %15s", a, b, c) == 3) (void)snprintf(status.load, sizeof(status.load), "%s %s %s", a, b, c);
        fclose(f);
    }
    if (status.cpus == 0 && (f = fopen("/proc/cpuinfo", "r")) != NULL) {
        while (fgets(line, sizeof(line), f)) if (strncmp(line, "processor", 9) == 0) status.cpus++;
        fclose(f);
    }
    if (status.kernel[0] == '\0' && uname(&un) == 0) (void)snprintf(status.kernel, sizeof(status.kernel), "%s %s", un.sysname, un.release);
    status.temp_c = read_hwmon_temp_c();
    status.usb_mounted = 0;
    status.usb_free_mb = 0;
    if (statvfs("/mnt/xwt-usb", &vfs) == 0 && access("/mnt/xwt-usb/kboot.conf", F_OK) == 0) {
        status.usb_mounted = 1;
        status.usb_free_mb = (unsigned long)(((unsigned long long)vfs.f_bavail * vfs.f_frsize) / (1024ULL * 1024ULL));
    }
    system_clock(status.clock, sizeof(status.clock));
    network_summary(status.net, sizeof(status.net));
    status.net_up = has_default_route();
    net_details();
}

static int mem_used_percent(void)
{
    if (status.mem_total_kb == 0) return 0;
    return (int)(((status.mem_total_kb - status.mem_avail_kb) * 100UL) / status.mem_total_kb);
}

static void format_uptime(char *out, size_t capacity)
{
    unsigned long mins = status.uptime_s / 60UL;
    (void)snprintf(out, capacity, "%lu h %02lu min", mins / 60UL, mins % 60UL);
}

static void draw_base(const char *title)
{
    int y, row;
    char text[96];
    rect(0, 0, screen_w, screen_h, C_DARK);
    /* Vertical green gradient header. */
    for (y = 0; y < HEADER_H; ++y) {
        SDL_Color c;
        c.r = (Uint8)(26 - (y * 14) / HEADER_H);
        c.g = (Uint8)(86 - (y * 40) / HEADER_H);
        c.b = (Uint8)(170 - (y * 70) / HEADER_H);
        c.unused = 255;
        rect(0, y, screen_w, 1, c);
    }
    rect(0, HEADER_H - 2, screen_w, 2, C_SKY);
    rect(0, HEADER_H, SIDEBAR_W, screen_h - HEADER_H - FOOTER_H, C_PANEL);
    rect(SIDEBAR_W - 1, HEADER_H, 1, screen_h - HEADER_H - FOOTER_H, C_BORDER);
    rect(0, screen_h - FOOTER_H, screen_w, FOOTER_H, C_PANEL2);
    draw_bold(18, 15, "XWT", C_WHITE);
    draw_text(68, 19, "X360 WEB TOTAL", C_WHITE);
    draw_bold(SIDEBAR_W + 22, 17, title, C_WHITE);
    draw_text(screen_w - 165, 20, status.clock, C_WHITE);

    /* Sidebar: live system status. */
    row = HEADER_H + 12;
    draw_text(14, row, "MEMORIA", C_LIME);
    draw_bar(14, row + 22, SIDEBAR_W - 28, 12, mem_used_percent(), mem_used_percent() > 85 ? C_WARN : C_LIME);
    (void)snprintf(text, sizeof(text), "%lu / %lu MB",
                   (status.mem_total_kb - status.mem_avail_kb) / 1024UL, status.mem_total_kb / 1024UL);
    draw_text_clip(font_regular, 14, row + 38, SIDEBAR_W - 24, text, C_WHITE);
    row += 72;
    draw_text(14, row, "REDE", C_LIME);
    draw_text_clip(font_regular, 14, row + 20, SIDEBAR_W - 24, status.net, C_WHITE);
    row += 54;
    draw_text(14, row, "TEMPERATURA", C_LIME);
    if (status.temp_c >= 0) (void)snprintf(text, sizeof(text), "%d C", status.temp_c);
    else (void)snprintf(text, sizeof(text), "sem sensor");
    draw_text(14, row + 20, text, status.temp_c >= 80 ? C_WARN : C_WHITE);
    row += 54;
    draw_text(14, row, "ATIVO HA", C_LIME);
    format_uptime(text, sizeof(text));
    draw_text(14, row + 20, text, C_WHITE);
    row += 54;
    draw_text(14, row, "USB", C_LIME);
    if (status.usb_mounted) (void)snprintf(text, sizeof(text), "%lu MB livres", status.usb_free_mb);
    else (void)snprintf(text, sizeof(text), "nao montado");
    draw_text_clip(font_regular, 14, row + 20, SIDEBAR_W - 24, text, status.usb_mounted ? C_WHITE : C_MUTED);

    draw_text_clip(font_regular, 14, screen_h - FOOTER_H + 8, screen_w - 280, status.kernel, C_MUTED);
    draw_text(screen_w - 235, screen_h - FOOTER_H + 8, "A abrir   B voltar", C_WHITE);
}

/* ---- XWT desktop (icons on the left, wallpaper, taskbar) ---------------------------------- */
typedef enum { ICON_WEB, ICON_FOLDER, ICON_GAME, ICON_TERM, ICON_GEAR, ICON_HELP, ICON_POWER, ICON_APPS } IconKind;

typedef struct {
    const char *label;
    IconKind kind;
    int app; /* index in apps[]; -1 = settings window, -2 = help */
} DeskIcon;

static const DeskIcon desk[DESK_COUNT] = {
    {"Navegador", ICON_WEB, 0},
    {"Arquivos", ICON_FOLDER, 3},
    {"Jogos", ICON_GAME, 12},
    {"Aplicativos", ICON_APPS, 14},
    {"Terminal", ICON_TERM, 10},
    {"Configurações", ICON_GEAR, -1},
    {"Ajuda", ICON_HELP, -2},
    {"Desligar", ICON_POWER, 11}
};

static const AssetId icon_asset[DESK_COUNT] = {A_ICON_WEB, A_ICON_FOLDER, A_ICON_GAME, A_ICON_APPS, A_ICON_TERM, A_ICON_GEAR, A_ICON_HELP, A_ICON_POWER};

static int have_art(void) { return assets[A_ICON_WEB] != NULL; }
static int icon_size(void) { return have_art() ? 64 : (screen_h >= 600 ? 52 : 40); }
static int icon_cell_h(void) { return icon_size() + (have_art() ? 18 : 40); }

/* Icons per column; the rest continue in the next column on small screens. */
static int app_columns(void)
{
    int rows = (screen_h - TASKBAR_H - 8) / icon_cell_h();
    if (rows < 1) rows = 1;
    if (rows > DESK_COUNT) rows = DESK_COUNT;
    return rows;
}

static SDL_Rect desk_cell(int index)
{
    int rows = app_columns();
    SDL_Rect r;
    r.x = (Sint16)(12 + (index / rows) * 152);
    r.y = (Sint16)(6 + (index % rows) * icon_cell_h());
    r.w = 142;
    r.h = (Uint16)(icon_cell_h() - 4);
    return r;
}

static int text_width(TTF_Font *font, const char *value)
{
    int w = 0, h = 0;
    if (!font || !value || TTF_SizeUTF8(font, value, &w, &h) != 0) return 0;
    return w;
}

static int int_sqrt(int v)
{
    int r = 0;
    while ((r + 1) * (r + 1) <= v) r++;
    return r;
}

static void fill_circle(int cx, int cy, int radius, SDL_Color color)
{
    int dy;
    for (dy = -radius; dy <= radius; ++dy) {
        int dx = int_sqrt(radius * radius - dy * dy);
        rect(cx - dx, cy + dy, 2 * dx + 1, 1, color);
    }
}

/* Fallback vector icons, used only when the BMP art is not installed. */
static void draw_icon_vector(IconKind kind, int x, int y, int s)
{
    SDL_Color tile = C_SKY, ink = C_WHITE;
    int cx = x + s / 2, cy = y + s / 2, u = s / 8;
    if (kind == ICON_FOLDER) { tile.r = 196; tile.g = 128; tile.b = 22; }
    else if (kind == ICON_GAME) { tile.r = 16; tile.g = 124; tile.b = 16; }
    else if (kind == ICON_TERM) { tile.r = 20; tile.g = 24; tile.b = 30; }
    else if (kind == ICON_GEAR) { tile.r = 70; tile.g = 82; tile.b = 104; }
    else if (kind == ICON_HELP) { tile.r = 14; tile.g = 138; tile.b = 148; }
    else if (kind == ICON_POWER) { tile.r = 176; tile.g = 38; tile.b = 38; }
    else if (kind == ICON_APPS) { tile.r = 96; tile.g = 70; tile.b = 176; }
    rect(x, y, s, s, tile);
    outline(x, y, s, s, C_BORDER);
    switch (kind) {
    case ICON_WEB:
        fill_circle(cx, cy, 3 * u, ink);
        fill_circle(cx, cy, 3 * u - 2, tile);
        rect(cx - 3 * u, cy, 6 * u, 2, ink);
        rect(cx - 1, cy - 3 * u, 2, 6 * u, ink);
        break;
    case ICON_FOLDER:
        rect(x + u, y + 2 * u, 3 * u, u + 1, ink);
        rect(x + u, y + 3 * u, 6 * u, 4 * u, ink);
        break;
    case ICON_GAME:
        rect(x + u, y + 3 * u, 6 * u, 3 * u, ink);
        rect(x + 2 * u, y + 4 * u, 2 * u, 2, tile);
        break;
    case ICON_TERM:
        draw_bold(x + u, y + s / 2 - 12, ">_", C_LIME);
        break;
    case ICON_GEAR:
        fill_circle(cx, cy, 3 * u, ink);
        fill_circle(cx, cy, u + 1, tile);
        break;
    case ICON_HELP:
        draw_bold(cx - 6, cy - 12, "?", ink);
        break;
    case ICON_POWER:
        fill_circle(cx, cy + 1, 3 * u, ink);
        fill_circle(cx, cy + 1, 3 * u - 3, tile);
        rect(cx - u, cy - 4 * u, 2 * u, 3 * u, tile);
        rect(cx - 1, cy - 3 * u, 3, 3 * u + 3, ink);
        break;
    case ICON_APPS:
        rect(x + u, y + u, 2 * u, 2 * u, ink); rect(x + 5 * u, y + u, 2 * u, 2 * u, ink);
        rect(x + u, y + 5 * u, 2 * u, 2 * u, ink); rect(x + 5 * u, y + 5 * u, 2 * u, 2 * u, ink);
        break;
    }
}

static void draw_desk_icon(int index, int x, int y)
{
    if (assets[icon_asset[index]]) blit(assets[icon_asset[index]], x, y);
    else draw_icon_vector(desk[index].kind, x, y, icon_size());
}

static void draw_wallpaper(void)
{
    int y;
    if (wallpaper_surf) { blit(wallpaper_surf, 0, 0); return; }
    for (y = 0; y < screen_h; ++y) {
        SDL_Color c;
        c.r = (Uint8)(3 + (y * 6) / screen_h);
        c.g = (Uint8)(8 + (y * 36) / screen_h);
        c.b = (Uint8)(20 + (y * 46) / screen_h);
        c.unused = 255;
        rect(0, y, screen_w, 1, c);
    }
}

static void draw_shadow_text(int x, int y, const char *value, SDL_Color color)
{
    draw_text(x + 1, y + 1, value, C_DARK);
    draw_text(x, y, value, color);
}

/* Round "A"/"B" controller button followed by its label; returns the x after the label. */
static int draw_hint(int x, int y, char letter, SDL_Color color, const char *label)
{
    char key[2];
    key[0] = letter;
    key[1] = '\0';
    fill_circle(x + 11, y + 11, 11, color);
    draw_bold(x + 5, y + 1, key, C_WHITE);
    draw_text(x + 28, y + 2, label, C_WHITE);
    return x + 28 + text_width(font_regular, label) + 22;
}

/* Bottom bar. windowed=0: desktop (XWT logo on the left); windowed=1: A/B hints on the left. */
static void draw_taskbar(int windowed)
{
    int y = screen_h - TASKBAR_H, x, row;
    for (row = 0; row < TASKBAR_H; ++row) {
        SDL_Color c;
        c.r = (Uint8)(14 - (row * 6) / TASKBAR_H);
        c.g = (Uint8)(26 - (row * 10) / TASKBAR_H);
        c.b = (Uint8)(56 - (row * 22) / TASKBAR_H);
        c.unused = 255;
        rect(0, y + row, screen_w, 1, c);
    }
    rect(0, y, screen_w, 1, C_SKY);
    if (windowed) {
        x = draw_hint(18, y + 7, 'A', C_GREEN, "Selecionar");
        (void)draw_hint(x, y + 7, 'B', (SDL_Color){190, 40, 40, 255}, "Voltar");
    } else if (assets[A_BAR_LOGO]) {
        blit(assets[A_BAR_LOGO], 12, y + (TASKBAR_H - assets[A_BAR_LOGO]->h) / 2);
    } else {
        draw_bold(14, y + 8, "XWT", C_WHITE);
    }
    x = screen_w - 16;
    x -= 22;
    blit(assets[status.usb_mounted ? A_DRIVE_ON : A_DRIVE_OFF], x, y + 8);
    if (!assets[status.usb_mounted ? A_DRIVE_ON : A_DRIVE_OFF]) draw_text(x - 30, y + 9, "USB", status.usb_mounted ? C_WHITE : C_WARN);
    x -= 30;
    blit(assets[status.net_up ? A_WIFI_ON : A_WIFI_OFF], x, y + 8);
    if (!assets[status.net_up ? A_WIFI_ON : A_WIFI_OFF]) draw_text(x - 50, y + 9, status.net_up ? "Rede" : "Sem rede", status.net_up ? C_WHITE : C_WARN);
    x -= 8 + text_width(font_regular, status.clock) + 6;
    draw_text(x, y + 9, status.clock, C_WHITE);
    if (windowed && assets[A_BAR_LOGO]) blit(assets[A_BAR_LOGO], x - 110, y + (TASKBAR_H - assets[A_BAR_LOGO]->h) / 2);
}

static void draw_home(void)
{
    int i, x, y;
    char text[96];
    TTF_Font *big = font_big ? font_big : font_bold;
    TTF_Font *mid = font_mid ? font_mid : font_regular;
    draw_wallpaper();
    if (!wallpaper_surf) {
        x = screen_w / 2 - 20;
        y = screen_h / 2 - 90;
        draw_text_font(big, x, y, "XWT", C_WHITE);
        draw_text_font(mid, x + 6, y + (screen_h >= 600 ? 96 : 60), "L I N U X", C_LIME);
        (void)snprintf(text, sizeof(text), "v%s", XWT_VERSION_TEXT);
        draw_text(x + 6, y + (screen_h >= 600 ? 136 : 92), text, C_MUTED);
    }
    /* System info, top right (like the reference screenshots). */
    (void)snprintf(text, sizeof(text), "XWT Linux %s", XWT_VERSION_TEXT);
    draw_shadow_text(screen_w - 260, 14, text, C_WHITE);
    draw_shadow_text(screen_w - 260, 36, "Xbox 360", C_WHITE);
    (void)snprintf(text, sizeof(text), "CPU: %d Threads (PPC)", status.cpus);
    draw_shadow_text(screen_w - 260, 58, text, C_WHITE);
    (void)snprintf(text, sizeof(text), "Memória: %lu MB / %lu MB",
                   (status.mem_total_kb - status.mem_avail_kb) / 1024UL, status.mem_total_kb / 1024UL);
    draw_shadow_text(screen_w - 260, 80, text, C_WHITE);
    for (i = 0; i < DESK_COUNT; ++i) {
        SDL_Rect r = desk_cell(i);
        int s = icon_size();
        int lw = text_width(font_regular, desk[i].label);
        int shown = lw < (int)r.w - 8 ? lw : (int)r.w - 8;
        if (i == selected_app) {
            rect(r.x, r.y, r.w, r.h, C_SEL);
            outline(r.x, r.y, r.w, r.h, C_HILITE);
            outline(r.x + 1, r.y + 1, r.w - 2, r.h - 2, C_HILITE);
        }
        draw_desk_icon(i, r.x + ((int)r.w - s) / 2, r.y);
        draw_text_clip(font_regular, r.x + ((int)r.w - shown) / 2 + 1, r.y + s + 2, (int)r.w - 8, desk[i].label, C_DARK);
        draw_text_clip(font_regular, r.x + ((int)r.w - shown) / 2, r.y + s + 1, (int)r.w - 8, desk[i].label, C_WHITE);
    }
    draw_taskbar(0);
    present();
}

static int file_compare(const void *a, const void *b)
{
    const FileEntry *fa = (const FileEntry *)a;
    const FileEntry *fb = (const FileEntry *)b;
    if (fa->is_dir != fb->is_dir) return fb->is_dir - fa->is_dir;
    return strcasecmp(fa->name, fb->name);
}

static char file_filter[48];
static char file_filter_dir[PATH_MAX];

static int name_matches(const char *name, const char *filter)
{
    size_t n = strlen(filter), i, len = strlen(name);
    if (n == 0) return 1;
    for (i = 0; i + n <= len; ++i)
        if (strncasecmp(name + i, filter, n) == 0) return 1;
    return 0;
}

static void load_files(void)
{
    if (strcmp(file_filter_dir, current_dir) != 0) { file_filter[0] = '\0'; (void)snprintf(file_filter_dir, sizeof(file_filter_dir), "%s", current_dir); }
    DIR *dir = opendir(current_dir);
    struct dirent *item;
    entry_count = 0;
    selected_file = 0;
    file_scroll = 0;
    if (!dir) return;
    while ((item = readdir(dir)) != NULL && entry_count < FILE_LIMIT) {
        char full[PATH_MAX];
        struct stat st;
        FileEntry *entry;
        if (strcmp(item->d_name, ".") == 0 || strcmp(item->d_name, "..") == 0) continue;
        if (!name_matches(item->d_name, file_filter)) continue;
        if (snprintf(full, sizeof(full), "%s/%s", current_dir, item->d_name) >= (int)sizeof(full)) continue;
        if (lstat(full, &st) != 0) continue;
        entry = &entries[entry_count++];
        (void)snprintf(entry->name, sizeof(entry->name), "%s", item->d_name);
        entry->is_dir = S_ISDIR(st.st_mode);
        entry->size = st.st_size;
    }
    closedir(dir);
    qsort(entries, entry_count, sizeof(entries[0]), file_compare);
}


/* ---- on-screen keyboard inside the desktop (R3 on the pad -> F12 key; also clickable with the L3 mouse) ---- */
#define OSK_MAXK 64
enum { OK_CHAR, OK_SHIFT, OK_SPACE, OK_BACK, OK_CLEAR, OK_OK, OK_CANCEL };
typedef struct { char label[10]; char lower, upper; int kind; int row; int weight; SDL_Rect r; } OskK;
static OskK osk_keys[OSK_MAXK];
static int osk_nkeys, osk_active, osk_shift, osk_sel;
static char osk_text[48];

static void osk_add(const char *label, char lower, char upper, int kind, int row, int weight)
{
    OskK *k;
    if (osk_nkeys >= OSK_MAXK) return;
    k = &osk_keys[osk_nkeys++];
    (void)snprintf(k->label, sizeof(k->label), "%s", label);
    k->lower = lower; k->upper = upper; k->kind = kind; k->row = row; k->weight = weight;
}

static void osk_build(void)
{
    static const char *const rows[4] = {"1234567890-.", "qwertyuiop_", "asdfghjkl,/", "zxcvbnm'()+"};
    int r, i;
    osk_nkeys = 0;
    for (r = 0; r < 4; ++r) {
        for (i = 0; rows[r][i]; ++i) {
            char lab[2] = {rows[r][i], 0};
            char up = (rows[r][i] >= 'a' && rows[r][i] <= 'z') ? (char)(rows[r][i] - 32) : rows[r][i];
            osk_add(lab, rows[r][i], up, OK_CHAR, r, 1);
        }
    }
    osk_add("Shift", 0, 0, OK_SHIFT, 4, 2);
    osk_add("Espaco", ' ', ' ', OK_SPACE, 4, 4);
    osk_add("Apagar", 0, 0, OK_BACK, 4, 2);
    osk_add("Limpar", 0, 0, OK_CLEAR, 4, 2);
    osk_add("OK", 0, 0, OK_OK, 4, 2);
    osk_add("Cancelar", 0, 0, OK_CANCEL, 4, 2);
}

static void osk_layout(void)
{
    int unit = (screen_w - 40) / 14, key_h = screen_h >= 600 ? 52 : 40;
    int top = screen_h - 5 * (key_h + 6) - 14, row, i;
    for (row = 0; row < 5; ++row) {
        int total = 0, x;
        for (i = 0; i < osk_nkeys; ++i) if (osk_keys[i].row == row) total += osk_keys[i].weight;
        x = (screen_w - total * unit) / 2;
        for (i = 0; i < osk_nkeys; ++i) {
            OskK *k = &osk_keys[i];
            if (k->row != row) continue;
            k->r.x = (Sint16)x; k->r.y = (Sint16)(top + row * (key_h + 6));
            k->r.w = (Uint16)(k->weight * unit - 4); k->r.h = (Uint16)key_h;
            x += k->weight * unit;
        }
    }
}

static void osk_open(void)
{
    if (page != PAGE_FILES) return;
    osk_build();
    osk_text[0] = '\0';
    (void)snprintf(osk_text, sizeof(osk_text), "%s", file_filter);
    osk_shift = 0; osk_sel = 15; osk_active = 1; need_redraw = 1;
}

static void osk_press(int i)
{
    const OskK *k = &osk_keys[i];
    size_t n = strlen(osk_text);
    switch (k->kind) {
    case OK_CHAR: case OK_SPACE:
        if (n + 1 < sizeof(osk_text)) { osk_text[n] = osk_shift ? k->upper : k->lower; osk_text[n + 1] = '\0'; }
        osk_shift = 0; break;
    case OK_SHIFT: osk_shift = !osk_shift; break;
    case OK_BACK: if (n) osk_text[n - 1] = '\0'; break;
    case OK_CLEAR: osk_text[0] = '\0'; break;
    case OK_OK:
        (void)snprintf(file_filter, sizeof(file_filter), "%s", osk_text);
        osk_active = 0; load_files(); break;
    case OK_CANCEL: osk_active = 0; break;
    }
    need_redraw = 1;
}

static void osk_move(int dr, int dc)
{
    int i, best = osk_sel, cx, bestd = 1 << 30;
    if (dc) {
        int j = osk_sel;
        do { j = (j + dc + osk_nkeys) % osk_nkeys; } while (osk_keys[j].row != osk_keys[osk_sel].row);
        osk_sel = j; return;
    }
    cx = osk_keys[osk_sel].r.x + osk_keys[osk_sel].r.w / 2;
    {
        int want = (osk_keys[osk_sel].row + dr + 5) % 5;
        for (i = 0; i < osk_nkeys; ++i) {
            int d;
            if (osk_keys[i].row != want) continue;
            d = abs(osk_keys[i].r.x + osk_keys[i].r.w / 2 - cx);
            if (d < bestd) { bestd = d; best = i; }
        }
    }
    osk_sel = best;
}

/* Returns 1 when the key was consumed by the keyboard. */
static int osk_key(SDLKey key)
{
    if (!osk_active) return 0;
    switch (key) {
    case SDLK_UP: osk_move(-1, 0); break;
    case SDLK_DOWN: osk_move(1, 0); break;
    case SDLK_LEFT: osk_move(0, -1); break;
    case SDLK_RIGHT: osk_move(0, 1); break;
    case SDLK_RETURN: case SDLK_KP_ENTER: osk_press(osk_sel); break;
    case SDLK_ESCAPE: osk_active = 0; break;
    case SDLK_F12: osk_active = 0; break;
    case SDLK_BACKSPACE: if (osk_text[0]) osk_text[strlen(osk_text) - 1] = '\0'; break;
    default:
        if (key >= 32 && key < 127 && strlen(osk_text) + 1 < sizeof(osk_text)) { /* real USB keyboard also types */
            size_t n = strlen(osk_text); osk_text[n] = (char)key; osk_text[n + 1] = '\0';
        }
        break;
    }
    need_redraw = 1;
    return 1;
}

static int osk_click(int x, int y)
{
    int i;
    if (!osk_active) return 0;
    for (i = 0; i < osk_nkeys; ++i) {
        const SDL_Rect *r = &osk_keys[i].r;
        if (x >= r->x && x < r->x + r->w && y >= r->y && y < r->y + r->h) { osk_sel = i; osk_press(i); return 1; }
    }
    return 1; /* swallow clicks outside the keys while the keyboard is open */
}

static void draw_osk(void)
{
    int i, key_h = screen_h >= 600 ? 52 : 40, top = screen_h - 5 * (key_h + 6) - 14;
    char line[80];
    if (!osk_active) return;
    osk_layout();
    rect(0, top - 62, screen_w, screen_h - top + 62, C_DARK);
    rect(20, top - 54, screen_w - 40, 40, C_PANEL2);
    (void)snprintf(line, sizeof(line), "Buscar nome: %s_", osk_text);
    draw_bold(32, top - 48, line, C_LIME);
    for (i = 0; i < osk_nkeys; ++i) {
        const OskK *k = &osk_keys[i];
        const char *label = k->label;
        char one[2] = {0, 0};
        if (k->kind == OK_CHAR) { one[0] = osk_shift ? k->upper : k->lower; label = one; }
        rect(k->r.x, k->r.y, k->r.w, k->r.h, i == osk_sel ? C_PANEL2 : C_PANEL);
        if (i == osk_sel) rect(k->r.x, k->r.y + k->r.h - 4, k->r.w, 4, C_LIME);
        if (k->kind == OK_SHIFT && osk_shift) rect(k->r.x, k->r.y + k->r.h - 4, k->r.w, 4, C_LIME);
        draw_text(k->r.x + 8, k->r.y + (k->r.h - 22) / 2, label, i == osk_sel ? C_LIME : C_WHITE);
    }
}

static void format_size(off_t size, char *out, size_t capacity)
{
    if (size >= 1024 * 1024) (void)snprintf(out, capacity, "%.1f MB", (double)size / (1024.0 * 1024.0));
    else if (size >= 1024) (void)snprintf(out, capacity, "%.1f KB", (double)size / 1024.0);
    else (void)snprintf(out, capacity, "%lld B", (long long)size);
}

static void draw_files(void)
{
    char cwd[PATH_MAX + 16];
    size_t i;
    int y = HEADER_H + 64;
    int visible = (screen_h - y - FOOTER_H - 20) / 29;
    if (visible < 1) visible = 1;
    draw_base("Arquivos");
    (void)snprintf(cwd, sizeof(cwd), "%s", current_dir);
    draw_text_clip(font_bold ? font_bold : font_regular, SIDEBAR_W + 22, HEADER_H + 16, screen_w - SIDEBAR_W - 44, cwd, C_LIME);
    draw_text(SIDEBAR_W + 22, HEADER_H + 40, "A abre  |  B volta  |  R3 busca por nome  |  .sh executa  |  .html navegador", C_MUTED);
    if (strcmp(current_dir, "/") != 0) {
        SDL_Color c = (selected_file == 0) ? C_LIME : C_WHITE;
        rect(SIDEBAR_W + 18, y - 2, screen_w - SIDEBAR_W - 36, 26, selected_file == 0 ? C_PANEL2 : C_DARK);
        draw_bold(SIDEBAR_W + 28, y + 2, "..  [pasta anterior]", c);
        y += 29;
    }
    for (i = (size_t)file_scroll; i < entry_count && i < (size_t)(file_scroll + visible); ++i) {
        size_t logical = i + (strcmp(current_dir, "/") != 0 ? 1U : 0U);
        char size_text[32];
        char line[300];
        SDL_Color color = ((int)logical == selected_file) ? C_LIME : (entries[i].is_dir ? C_WHITE : C_MUTED);
        if ((int)logical == selected_file) rect(SIDEBAR_W + 18, y - 2, screen_w - SIDEBAR_W - 36, 26, C_PANEL2);
        format_size(entries[i].size, size_text, sizeof(size_text));
        (void)snprintf(line, sizeof(line), "%s  %s", entries[i].is_dir ? "[DIR]" : "[FILE]", entries[i].name);
        draw_text_clip(font_regular, SIDEBAR_W + 28, y + 2, screen_w - SIDEBAR_W - 160, line, color);
        draw_text(screen_w - 108, y + 2, entries[i].is_dir ? "" : size_text, C_MUTED);
        y += 29;
    }
    if (entry_count == 0) draw_text(SIDEBAR_W + 28, y + 8, "Pasta vazia ou sem permissao de leitura.", C_MUTED);
    present();
}

static const char *const settings_names[SETTINGS_COUNT] = {
    "Sistema", "Rede", "Wi-Fi", "Vídeo", "Áudio", "Controle", "Armazenamento", "Atualizações", "Logs", "Sobre"
};
static const AssetId settings_glyph[SETTINGS_COUNT] = {
    A_GL_SYSTEM, A_GL_NETWORK, A_GL_NETWORK, A_GL_VIDEO, A_GL_AUDIO, A_GL_PAD, A_GL_STORAGE, A_GL_UPDATE, A_GL_LOG, A_GL_ABOUT
};
/* Tool opened with A from each settings entry (index in apps[]; -1 = nothing). */
static const int settings_tool[SETTINGS_COUNT] = {-1, 2, 1, 13, 7, 6, 5, 8, 9, -1};

static void srow(int x, int y, int w, const char *label, const char *value, SDL_Color color)
{
    draw_text(x, y, label, C_MUTED);
    draw_text_clip(font_regular, x + 170, y, w - 170, value, color);
}

static void draw_button(int x, int y, int w, const char *label)
{
    int tw = text_width(font_regular, label);
    rect(x, y, w, 34, C_SEL);
    outline(x, y, w, 34, C_HILITE);
    draw_text(x + (w - tw) / 2, y + 7, label, C_WHITE);
}

static void draw_settings(void)
{
    int wx = screen_w >= 900 ? 70 : 16, wy = 24;
    int ww = screen_w - 2 * wx, wh = screen_h - TASKBAR_H - 48;
    int side = 214, i, x, y, w, bar = 42, ih;
    char text[160];
    int used = mem_used_percent();
    draw_wallpaper();
    rect(wx, wy, ww, wh, C_WIN);
    outline(wx, wy, ww, wh, C_SKY);
    for (i = 0; i < bar; ++i) {
        SDL_Color c = C_HILITE;
        c.r = (Uint8)(c.r - (i * 10) / bar);
        c.g = (Uint8)(c.g - (i * 60) / bar);
        c.b = (Uint8)(c.b - (i * 90) / bar);
        rect(wx + 1, wy + 1 + i, ww - 2, 1, c);
    }
    if (assets[A_GL_GEAR_TITLE]) blit(assets[A_GL_GEAR_TITLE], wx + 12, wy + 5);
    draw_bold(wx + 56, wy + 9, "Configurações", C_WHITE);
    draw_text(wx + ww - 96, wy + 9, "—   \xE2\x96\xA1   \xE2\x9C\x95", C_WHITE);
    rect(wx + side, wy + bar, 1, wh - bar, C_BORDER);
    ih = (wh - bar - 12) / SETTINGS_COUNT;
    if (ih > 40) ih = 40;
    if (ih < 24) ih = 24;
    for (i = 0; i < SETTINGS_COUNT; ++i) {
        int iy = wy + bar + 6 + i * ih;
        if (i == settings_sel) rect(wx + 1, iy, side - 1, ih - 2, C_HILITE);
        if (assets[settings_glyph[i]]) blit(assets[settings_glyph[i]], wx + 14, iy + (ih - 2 - 32) / 2);
        draw_text_clip(font_regular, wx + 56, iy + (ih - 22) / 2, side - 66, settings_names[i], C_WHITE);
    }
    if (assets[A_XLOGO]) blit(assets[A_XLOGO], wx + ww - 136, wy + wh - 130);
    x = wx + side + 28;
    y = wy + bar + 24;
    w = ww - side - 56;
    switch (settings_sel) {
    case 0: {
        char cpu[96] = "PowerPC Xenon";
        FILE *f = fopen("/proc/cpuinfo", "r");
        if (f) {
            char raw[256];
            while (fgets(raw, sizeof(raw), f)) {
                char *colon = strchr(raw, ':');
                if (colon && (strncmp(raw, "cpu", 3) == 0 || strncmp(raw, "model", 5) == 0)) {
                    colon++;
                    while (*colon == ' ' || *colon == '\t') colon++;
                    (void)snprintf(cpu, sizeof(cpu), "%s", colon);
                    cpu[strcspn(cpu, "\r\n")] = '\0';
                    break;
                }
            }
            fclose(f);
        }
        (void)snprintf(text, sizeof(text), "%s", XWT_VERSION_TEXT);
        srow(x, y, w, "Versão do XWT:", text, C_WHITE); y += 32;
        srow(x, y, w, "Kernel:", status.kernel[0] ? status.kernel : "?", C_WHITE); y += 32;
        srow(x, y, w, "Arquitetura:", "powerpc", C_WHITE); y += 32;
        srow(x, y, w, "Processador:", cpu, C_WHITE); y += 32;
        (void)snprintf(text, sizeof(text), "%d", status.cpus);
        srow(x, y, w, "Threads:", text, C_WHITE); y += 32;
        (void)snprintf(text, sizeof(text), "%lu MB", status.mem_total_kb / 1024UL);
        srow(x, y, w, "Memória Total:", text, C_WHITE); y += 32;
        (void)snprintf(text, sizeof(text), "%lu MB", status.mem_avail_kb / 1024UL);
        srow(x, y, w, "Memória Livre:", text, used > 85 ? C_WARN : C_WHITE); y += 32;
        if (status.temp_c >= 0) (void)snprintf(text, sizeof(text), "%d C", status.temp_c);
        else (void)snprintf(text, sizeof(text), "sensor não exposto");
        srow(x, y, w, "Temperatura:", text, status.temp_c >= 80 ? C_WARN : C_WHITE); y += 32;
        format_uptime(text, sizeof(text));
        srow(x, y, w, "Ativo há:", text, C_WHITE);
        break;
    }
    case 1:
        srow(x, y, w, "Status:", status.net_up ? "Conectado" : "Sem conexão", status.net_up ? C_LIME : C_WARN); y += 34;
        srow(x, y, w, "Rede:", status.netkind, C_WHITE); y += 34;
        srow(x, y, w, "IP:", status.ip[0] ? status.ip : "-", C_WHITE); y += 34;
        srow(x, y, w, "Gateway:", status.gw[0] ? status.gw : "-", C_WHITE); y += 34;
        srow(x, y, w, "DNS:", status.dns[0] ? status.dns : "-", C_WHITE); y += 52;
        draw_button(x + 60, y, 240, "Testar Conexão");
        break;
    case 2:
        draw_text_clip(font_regular, x, y, w, "Assistente Wi-Fi para adaptadores USB (status, busca e conexão).", C_WHITE); y += 52;
        draw_button(x + 60, y, 240, "Abrir Wi-Fi");
        break;
    case 3:
        (void)snprintf(text, sizeof(text), "%dx%d, %d bpp", fb_info_w, fb_info_h, fb_info_bpp);
        srow(x, y, w, "Saída:", text, C_WHITE); y += 52;
        draw_button(x + 60, y, 240, "Saídas e modos");
        break;
    case 4:
        srow(x, y, w, "Áudio:", "somente por USB (headset/placa)", C_WHITE); y += 52;
        draw_button(x + 60, y, 240, "Detectar e testar");
        break;
    case 5:
        srow(x, y, w, "Controle:", "xpad USB (sem fio: receptor)", C_WHITE); y += 52;
        draw_button(x + 60, y, 240, "Testar botões");
        break;
    case 6:
        if (status.usb_mounted) (void)snprintf(text, sizeof(text), "USB FAT32, %lu MB livres", status.usb_free_mb);
        else (void)snprintf(text, sizeof(text), "USB não montado");
        srow(x, y, w, "Pendrive:", text, status.usb_mounted ? C_LIME : C_WARN); y += 52;
        draw_button(x + 60, y, 240, "USB, HD e cartões");
        break;
    case 7:
        draw_text_clip(font_regular, x, y, w, "Módulos .xwpkg: listar, instalar e reverter.", C_WHITE); y += 52;
        draw_button(x + 60, y, 240, "Abrir atualizações");
        break;
    case 8:
        draw_text_clip(font_regular, x, y, w, "Relatório no pendrive: xwt/logs/boot-report.txt", C_MUTED); y += 52;
        draw_button(x + 60, y, 240, "Ver logs");
        break;
    default:
        draw_bold(x, y, "Projeto XWT Linux", C_WHITE); y += 36;
        draw_text_clip(font_regular, x, y, w, "Linux no Xbox 360, de um jeito diferente.", C_WHITE); y += 32;
        draw_text_clip(font_regular, x, y, w, "Roda só pelo pendrive; não grava na NAND.", C_MUTED); y += 32;
        (void)snprintf(text, sizeof(text), "Versão %s", XWT_VERSION_TEXT);
        draw_text(x, y, text, C_LIME);
        break;
    }
    draw_taskbar(1);
    present();
}

static int gui_reopen(void)
{
    need_redraw = 1;
    return gui_init();
}

static void run_child(char *const argv[])
{
    pid_t pid;
    int wstatus;
    gui_shutdown();
    pid = fork();
    if (pid == 0) {
        (void)setenv("TERM", "linux", 1);
        (void)setenv("DIALOGRC", "/etc/dialogrc", 1);
        execvp(argv[0], argv);
        perror(argv[0]);
        execl("/bin/sh", "sh", "-l", (char *)NULL);
        _exit(127);
    }
    if (pid > 0) {
        while (waitpid(pid, &wstatus, 0) < 0 && errno == EINTR) { }
    }
    if (gui_reopen() != 0) { fprintf(stderr, "XWT Desktop: nao foi possivel restaurar o framebuffer.\n"); exit(2); }
}

static void run_shell_command(const char *command)
{
    char *const args[] = {"/bin/sh", "-c", (char *)command, NULL};
    run_child(args);
}

static void run_browser(const char *url)
{
    pid_t pid;
    int wstatus;
    gui_shutdown();
    pid = fork();
    if (pid == 0) {
        /* An installed XWT browser module (xwt-update install browser) wins. */
        if (access("/opt/xwt/modules/browser/bin/xwt-browser", X_OK) == 0)
            execl("/opt/xwt/modules/browser/bin/xwt-browser", "xwt-browser", url, (char *)NULL);
        execlp("netsurf-fb", "netsurf-fb", url, (char *)NULL);
        execlp("netsurf", "netsurf", url, (char *)NULL);
        /* Text-mode fallback (links) keeps web access even if the graphical engine fails to start. */
        (void)setenv("TERM", "linux", 1);
        execlp("links", "links", url, (char *)NULL);
        fprintf(stderr, "Navegador nao instalado nesta compilacao.\n");
        execlp("dialog", "dialog", "--title", "Navegador", "--msgbox",
               "Navegador nao instalado. Use Atualizacoes para instalar o modulo browser quando estiver publicado.",
               "10", "72", (char *)NULL);
        _exit(127);
    }
    if (pid > 0) while (waitpid(pid, &wstatus, 0) < 0 && errno == EINTR) { }
    if (gui_reopen() != 0) { fprintf(stderr, "XWT Desktop: nao foi possivel restaurar o framebuffer.\n"); exit(2); }
}

static void open_selected_file(void)
{
    size_t index;
    char path[PATH_MAX];
    char resolved[PATH_MAX];
    char url[PATH_MAX + 16];
    const char *ext;
    if (strcmp(current_dir, "/") != 0 && selected_file == 0) {
        char *slash = strrchr(current_dir, '/');
        if (slash == current_dir) current_dir[1] = '\0';
        else if (slash) *slash = '\0';
        load_files();
        return;
    }
    index = (size_t)selected_file - (strcmp(current_dir, "/") != 0 ? 1U : 0U);
    if (index >= entry_count) return;
    if (snprintf(path, sizeof(path), "%s/%s", current_dir, entries[index].name) >= (int)sizeof(path)) return;
    if (!realpath(path, resolved)) return;
    if (entries[index].is_dir) {
        (void)snprintf(current_dir, sizeof(current_dir), "%s", resolved);
        load_files();
        return;
    }
    ext = strrchr(resolved, '.');
    if (ext && (strcasecmp(ext, ".html") == 0 || strcasecmp(ext, ".htm") == 0 || strcasecmp(ext, ".xhtml") == 0)) {
        if (snprintf(url, sizeof(url), "file://%s", resolved) < (int)sizeof(url)) run_browser(url);
    } else if (ext && strcasecmp(ext, ".sh") == 0) {
        /* A launches shell scripts from the USB (run via sh: FAT has no exec bit). */
        char *const args[] = {"/bin/sh", resolved, NULL};
        run_child(args);
    } else {
        char *const args[] = {"less", "--", resolved, NULL};
        run_child(args);
    }
}

/* xwt-storage menu leaves the chosen mount point in /run/xwt-storage-selected. */
static void open_storage_selection(void)
{
    char path[PATH_MAX];
    FILE *f = fopen("/run/xwt-storage-selected", "r");
    if (!f) return;
    if (fgets(path, sizeof(path), f)) {
        path[strcspn(path, "\r\n")] = '\0';
        if (path[0] == '/' && access(path, R_OK | X_OK) == 0) {
            (void)snprintf(current_dir, sizeof(current_dir), "%s", path);
            load_files();
            page = PAGE_FILES;
        }
    }
    fclose(f);
    (void)unlink("/run/xwt-storage-selected");
    need_redraw = 1;
}

static void launch_app(int app)
{
    need_redraw = 1;
    switch (app) {
    case 0:
        run_browser(access("/usr/share/xwt/home.html", R_OK) == 0
                    ? "file:///usr/share/xwt/home.html" : "about:blank");
        break;
    case 1: {
        char *const args[] = {"/usr/sbin/xwt-wifi", "menu", NULL};
        run_child(args);
        break;
    }
    case 2:
        run_shell_command("/usr/sbin/xwt-network check > /tmp/xwt-network-report.txt 2>&1; dialog --title 'Diagnostico de Internet' --textbox /tmp/xwt-network-report.txt 22 78");
        break;
    case 3:
        if (access("/mnt/xwt-usb/xwt", R_OK | X_OK) == 0) (void)snprintf(current_dir, sizeof(current_dir), "/mnt/xwt-usb/xwt");
        else (void)snprintf(current_dir, sizeof(current_dir), "/");
        load_files(); page = PAGE_FILES; break;
    case 4: page = PAGE_SETTINGS; settings_sel = 0; break;
    case 5: {
        char *const args[] = {"/usr/sbin/xwt-storage", "menu", NULL};
        run_child(args);
        open_storage_selection();
        break;
    }
    case 6:
        run_shell_command("if command -v evtest >/dev/null 2>&1; then evtest; else echo 'evtest nao esta instalado.'; read -r _; fi");
        break;
    case 7:
        run_shell_command("if [ -x /usr/sbin/xwt-audio ]; then /usr/sbin/xwt-audio menu; elif command -v alsamixer >/dev/null 2>&1; then alsamixer; elif command -v aplay >/dev/null 2>&1; then aplay -l; else echo 'ALSA nao esta disponivel nesta imagem.'; read -r _; fi");
        break;
    case 8:
        run_shell_command("choice=$(dialog --stdout --menu 'Atualizacoes XWT' 12 60 3 list 'Listar modulos' install 'Instalar/atualizar system' rollback 'Reverter system') || exit 0; clear; case \"$choice\" in list) xwt-update list ;; install) xwt-update install system ;; rollback) xwt-update rollback system ;; esac; echo; printf 'Pressione Enter...'; read -r _");
        break;
    case 9:
        run_shell_command("{ for f in /run/xwt-video-report.txt /run/xwt-update-boot.log /run/xwt-time-sync.log /run/xwt-desktop.log; do [ -s \"$f\" ] && { echo \"=== $f\"; tail -n 40 \"$f\"; }; done; echo '=== dmesg'; dmesg | tail -n 80; } > /tmp/xwt-logs.txt 2>&1; dialog --title 'Logs do sistema' --textbox /tmp/xwt-logs.txt 22 78");
        break;
    case 10: {
        char *const args[] = {"/bin/sh", "-l", NULL};
        run_child(args);
        break;
    }
    case 11:
        run_shell_command("choice=$(dialog --stdout --menu 'Energia do sistema' 11 58 2 reboot 'Reiniciar Linux' poweroff 'Desligar console') || exit 0; case \"$choice\" in reboot) sync; reboot ;; poweroff) sync; poweroff ;; esac");
        break;
    case 12: {
        char *const args[] = {"/usr/sbin/xwt-game", "menu", NULL};
        run_child(args);
        break;
    }
    case 13: {
        char *const args[] = {"/usr/sbin/xwt-video", "menu", NULL};
        run_child(args);
        break;
    }
    case 14: {
        char *const args[] = {"/usr/sbin/xwt-apps", "menu", NULL};
        run_child(args);
        break;
    }
    default: break;
    }
}

static void show_help(void)
{
    run_shell_command("dialog --title 'Ajuda XWT' --msgbox 'Setas/D-pad: mover. A: abrir. B: voltar.\n\nJogos: coloque doom.wad ou freedoom1.wad em xwt/games/doom no pendrive.\nProblemas: leia xwt/logs/boot-report.txt no PC.' 14 64");
}

static void launch_desk(int index)
{
    int app = desk[index].app;
    if (app == -1) { page = PAGE_SETTINGS; settings_sel = 0; need_redraw = 1; }
    else if (app == -2) show_help();
    else launch_app(app);
}

static void handle_home_key(SDLKey key)
{
    int rows = app_columns();
    if (key == SDLK_UP && selected_app % rows > 0) selected_app--;
    else if (key == SDLK_DOWN && selected_app % rows < rows - 1 && selected_app + 1 < DESK_COUNT) selected_app++;
    else if (key == SDLK_LEFT && selected_app - rows >= 0) selected_app -= rows;
    else if (key == SDLK_RIGHT && selected_app + rows < DESK_COUNT) selected_app += rows;
    else if (key == SDLK_RETURN || key == SDLK_KP_ENTER || key == SDLK_SPACE) launch_desk(selected_app);
    else if (key == SDLK_HOME) selected_app = 0;
    else if (key == SDLK_END) selected_app = DESK_COUNT - 1;
}

static void handle_key(SDLKey key)
{
    need_redraw = 1;
    if (osk_key(key)) return;
    if (key == SDLK_F12) { osk_open(); return; }
    if (page == PAGE_HOME) {
        handle_home_key(key);
        return;
    }
    if (page == PAGE_FILES) {
        int offset = strcmp(current_dir, "/") != 0 ? 1 : 0;
        int visible = (screen_h - (HEADER_H + 64) - FOOTER_H - 20) / 29;
        int max_index = (int)entry_count + offset - 1;
        if (visible < 1) visible = 1;
        if (key == SDLK_ESCAPE || key == SDLK_BACKSPACE) { page = PAGE_HOME; return; }
        if (key == SDLK_UP && selected_file > 0) selected_file--;
        else if (key == SDLK_DOWN && selected_file < max_index) selected_file++;
        else if (key == SDLK_RETURN || key == SDLK_KP_ENTER || key == SDLK_SPACE) open_selected_file();
        if (selected_file < file_scroll) file_scroll = selected_file;
        if (selected_file >= file_scroll + visible) file_scroll = selected_file - visible + 1;
        return;
    }
    if (key == SDLK_ESCAPE || key == SDLK_BACKSPACE) { page = PAGE_HOME; return; }
    if (key == SDLK_UP && settings_sel > 0) settings_sel--;
    else if (key == SDLK_DOWN && settings_sel < SETTINGS_COUNT - 1) settings_sel++;
    else if ((key == SDLK_RETURN || key == SDLK_KP_ENTER || key == SDLK_SPACE) && settings_tool[settings_sel] >= 0)
        launch_app(settings_tool[settings_sel]);
}

static int point_in(SDL_Rect r, int x, int y)
{
    return x >= r.x && y >= r.y && x < r.x + r.w && y < r.y + r.h;
}

static int settings_row_at(int x, int y)
{
    int wx = screen_w >= 900 ? 70 : 16, wy = 24, wh = screen_h - TASKBAR_H - 48, side = 214, bar = 42;
    int ih = (wh - bar - 12) / SETTINGS_COUNT, row;
    if (ih > 40) ih = 40;
    if (ih < 24) ih = 24;
    if (x < wx || x >= wx + side || y < wy + bar + 6) return -1;
    row = (y - (wy + bar + 6)) / ih;
    return row >= 0 && row < SETTINGS_COUNT ? row : -1;
}

static void handle_mouse(int x, int y)
{
    int i;
    if (osk_click(x, y)) return;
    if (page == PAGE_SETTINGS) {
        int row = settings_row_at(x, y);
        if (row >= 0) { settings_sel = row; need_redraw = 1; handle_key(SDLK_RETURN); }
        return;
    }
    if (page != PAGE_HOME) return;
    for (i = 0; i < DESK_COUNT; ++i) {
        SDL_Rect r = desk_cell(i);
        if (point_in(r, x, y)) {
            selected_app = i;
            launch_desk(i);
            return;
        }
    }
}

int main(void)
{
    SDL_Event event;
    (void)snprintf(current_dir, sizeof(current_dir), "%s", access("/mnt/xwt-usb/xwt", R_OK | X_OK) == 0 ? "/mnt/xwt-usb/xwt" : "/");
    load_files();
    (void)setenv("SDL_VIDEODRIVER", "fbcon", 0);
    (void)setenv("SDL_FBDEV", "/dev/fb0", 0);
    if (gui_init() != 0) {
        fprintf(stderr, "XWT Desktop: SDL/framebuffer nao iniciou: %s\n", SDL_GetError());
        return 1;
    }
    (void)snprintf(status_line, sizeof(status_line), "Desktop iniciado");
    refresh_status();
    {
        Uint32 last_status = SDL_GetTicks();
        for (;;) {
            Uint32 now;
            while (SDL_PollEvent(&event)) {
                if (event.type == SDL_QUIT) { page = PAGE_HOME; need_redraw = 1; }
                else if (event.type == SDL_KEYDOWN) handle_key(event.key.keysym.sym);
                else if (event.type == SDL_MOUSEMOTION) {
                    int i;
                    mouse_x = event.motion.x; mouse_y = event.motion.y; mouse_seen = 1;
                    if (page == PAGE_HOME) {
                        for (i = 0; i < DESK_COUNT; ++i) {
                            SDL_Rect r = desk_cell(i);
                            if (point_in(r, mouse_x, mouse_y)) selected_app = i;
                        }
                    }
                    need_redraw = 1;
                }
                else if (event.type == SDL_MOUSEBUTTONDOWN && event.button.button == SDL_BUTTON_LEFT) {
                    mouse_x = event.button.x; mouse_y = event.button.y; mouse_seen = 1;
                    handle_mouse(event.button.x, event.button.y);
                    need_redraw = 1;
                }
                else if (event.type == SDL_MOUSEBUTTONDOWN && event.button.button == SDL_BUTTON_RIGHT) {
                    handle_key(SDLK_ESCAPE);
                    need_redraw = 1;
                }
            }
            {
                int p = read_pointer_state();
                if (p != pointer_on) { pointer_on = p; if (p) mouse_seen = 1; need_redraw = 1; }
            }
            now = SDL_GetTicks();
            if (now - last_status >= STATUS_REFRESH_MS) {
                refresh_status();
                last_status = now;
                need_redraw = 1;
            }
            if (need_redraw) {
                need_redraw = 0;
                if (page == PAGE_HOME) draw_home();
                else if (page == PAGE_FILES) draw_files();
                else draw_settings();
            }
            SDL_Delay(40);
        }
    }
    gui_shutdown();
    return 0;
}
