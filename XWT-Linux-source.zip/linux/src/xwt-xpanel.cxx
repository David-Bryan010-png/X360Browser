// XWT Linux - painel FLTK para o modo X11 (fase 4 do plano). Botoes grandes, pensado para o mouse do L3.
// Abre apps X (xterm, xclock, dillo, pcmanfm se existir) e o teclado xvkbd. Nao acessa NAND/KV/SMC/firmware.
#include <FL/Fl.H>
#include <FL/Fl_Box.H>
#include <FL/Fl_Button.H>
#include <FL/Fl_Window.H>
#include <signal.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <unistd.h>

static bool have(const char *name)
{
    const char *dirs[] = {"/usr/bin/", "/usr/local/bin/", "/bin/", NULL};
    char path[256];
    for (int i = 0; dirs[i]; ++i) {
        snprintf(path, sizeof(path), "%s%s", dirs[i], name);
        if (access(path, X_OK) == 0) return true;
    }
    return false;
}

static void spawn(const char *cmd, const char *arg)
{
    pid_t pid = fork();
    if (pid == 0) {
        setsid();
        execlp(cmd, cmd, arg, (char *)NULL);
        _exit(127);
    }
}

static void on_app(Fl_Widget *, void *data)
{
    const char *cmd = (const char *)data;
    if (have(cmd)) spawn(cmd, NULL);
}

static void on_quit(Fl_Widget *, void *)
{
    /* Fechar o painel encerra a sessao X (o xwt-x volta ao desktop SDL). */
    exit(0);
}

static void reap(int) { while (waitpid(-1, NULL, WNOHANG) > 0) {} }

int main(int argc, char **argv)
{
    signal(SIGCHLD, reap);
    const int W = 440, H = 120, B = 96;
    Fl_Window *win = new Fl_Window(0, 0, W, H, "XWT X11");
    struct Item { const char *label; const char *cmd; } items[] = {
        {"Terminal", "xterm"}, {"Relogio", "xclock"}, {"Web", "dillo"}, {"Arquivos", "pcmanfm"}};
    int x = 8;
    for (unsigned i = 0; i < sizeof(items) / sizeof(items[0]); ++i) {
        Fl_Button *b = new Fl_Button(x, 8, B, 48, items[i].label);
        b->callback(on_app, (void *)items[i].cmd);
        if (!have(items[i].cmd)) b->deactivate();
        x += B + 6;
    }
    Fl_Button *kb = new Fl_Button(8, 64, 2 * B + 6, 44, "Teclado");
    kb->callback(on_app, (void *)"xvkbd");
    if (!have("xvkbd")) kb->deactivate();
    Fl_Button *quit = new Fl_Button(2 * B + 20, 64, 2 * B + 6, 44, "Voltar ao desktop");
    quit->callback(on_quit);
    win->end();
    win->show(argc, argv);
    return Fl::run();
}
