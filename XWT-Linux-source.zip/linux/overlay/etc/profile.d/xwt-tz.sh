# POSIX time zone (no tzdata needed). Override via X360WebTotal/config/timezone on the USB,
# e.g. "BRT3" (Brasilia), "AMT4" (Manaus), "UTC0".
TZ=BRT3
[ -r /mnt/xwt-usb/X360WebTotal/config/timezone ] && TZ=$(head -n 1 /mnt/xwt-usb/X360WebTotal/config/timezone)
export TZ
