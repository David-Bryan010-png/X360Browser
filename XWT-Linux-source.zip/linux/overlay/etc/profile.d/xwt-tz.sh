# POSIX time zone (no tzdata needed). Override via xwt/config/timezone on the USB,
# e.g. "BRT3" (Brasilia), "AMT4" (Manaus), "UTC0".
TZ=BRT3
[ -r /mnt/xwt-usb/xwt/config/timezone ] && TZ=$(head -n 1 /mnt/xwt-usb/xwt/config/timezone)
export TZ
