# XWT Linux 0.14.0-alpha.2 — Core mínimo

Esta versão é a primeira base de inicialização. Ela não tenta compilar todos os aplicativos: entrega um console Linux utilizável, armazenamento USB, rede Ethernet e atualização modular.

## O que entra no core
- Kernel Xenon baseado no port Free60, com framebuffer/Xenos experimental.
- BusyBox, shell, console, montagem USB FAT32 e suporte ao controle em nível de driver.
- Ethernet SIS190 com DHCP, ferramentas de rede, curl/OpenSSL e certificados CA.
- Atualizador `.xwpkg` que instala módulos em `/opt/xwt/modules` e reaplica os pacotes do USB no boot.
- Menu textual, diagnóstico e terminal.

## Módulos futuros
Desktop SDL, NetSurf, áudio ALSA, Wi-Fi USB, explorador gráfico, camadas de compatibilidade e evolução do driver Xenos serão construídos separadamente. O workflow incremental só empacota o componente alterado; não reconstrói kernel ou initramfs.

## Boot
`default.xex` inicia XellLaunch2; XeLL Reloaded lê `kboot.conf` e carrega `xwt-linux.elf` e `rootfs.cpio.gz` do USB. Nenhuma escrita na NAND é realizada.

## Limites
O primeiro Buildroot ainda compila o kernel e o rootfs mínimo uma única vez. Atualizações de módulos não repetem essa compilação. É necessária validação física no console; o driver Xenos e algumas interfaces permanecem experimentais.
