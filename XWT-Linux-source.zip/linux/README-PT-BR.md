# XWT Linux 1.0.0 — Desktop e controle

A 1.0.0 atualiza diretamente a base 0.14.0-alpha.2. Preserva a cadeia XEX/XeLL, o kernel Xenon 7.2, a montagem USB FAT32, Ethernet/DHCP, HTTPS e o atualizador `.xwpkg`.

## O que mudou na imagem
- Desktop SDL 1.2 + SDL_ttf compilado no pós-build para o framebuffer real.
- Verificação de geometria, pitch e tamanho de memória de `/dev/fb0`; nenhum modo inventado. Se o framebuffer não atende ao desktop (mínimo 640×480, 16/32 bpp), retorna ao menu textual.
- Driver Xenos corrigido para alocação alinhada 32×32, endereços DMA de 32 bits, blit inicial, clipping e sincronização de DMA coerente.
- Daemon de controles compilado e iniciado no boot; até quatro dispositivos joystick, reconexão, D-pad/analógico, A/Start confirmar, B/Back voltar.
- Diagnóstico de vídeo no boot em `/run/xwt-video-report.txt`.
- Wi-Fi USB com `iw`, `wpa_supplicant` e DHCP; configuração fica na partição USB.
- `dialog`, `less`, `alsamixer`, `aplay` e DejaVu Sans adicionados ao rootfs.

## Wi-Fi
Copie `/etc/xwt/wpa_supplicant.conf.example` para `xwt/config/wpa_supplicant.conf` no USB. Edite o SSID e a senha no computador e use o menu Wi-Fi no desktop. O adaptador precisa de um driver Linux presente no kernel.

## Controles
O daemon transforma os eventos de `xpad`/`joydev` em teclas Linux por `uinput`: D-pad ou analógico navega; A/Start confirma; B/Back volta. Controle sem fio exige receptor USB compatível. A numeração real dos botões pode variar por modelo/driver.

## Limites
O navegador é o NetSurf (front-end SDL, sem X11) com `links` em modo texto como reserva; ainda não foi testado no console. Ferramentas ALSA não garantem saída de áudio Xenon. O driver Xenos não oferece aceleração 2D/3D geral. Um framebuffer ausente ou incompatível aciona o menu textual em vez de forçar uma resolução. Nenhum script grava NAND, KV, SMC ou firmware. Teste físico permanece pendente.
