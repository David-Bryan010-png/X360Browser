#!/bin/sh
# Minimal-core post-build guard; no application cross-compilation here.
set -eu
TARGET_DIR=${1:?Buildroot target directory is required}
[ -d "$TARGET_DIR" ] || { echo "XWT: target directory missing" >&2; exit 1; }
for path in \
  "$TARGET_DIR/usr/sbin/xwt-system-menu" \
  "$TARGET_DIR/usr/sbin/xwt-system-menu-text" \
  "$TARGET_DIR/usr/sbin/xwt-update" \
  "$TARGET_DIR/usr/sbin/xwt-network" \
  "$TARGET_DIR/etc/init.d/S30storage" \
  "$TARGET_DIR/etc/init.d/S40network"; do
  [ -s "$path" ] || { echo "XWT: required core file missing: $path" >&2; exit 1; }
done
for module in xpad joydev uinput; do
  find "$TARGET_DIR/lib/modules" -type f \
    \( -name "$module.ko" -o -name "$module.ko.xz" -o -name "$module.ko.zst" \) -print -quit | grep -q . || {
      echo "XWT: kernel module missing from rootfs: $module" >&2
      exit 1
    }
done
chmod 0755 \
  "$TARGET_DIR/usr/sbin/xwt-system-menu" \
  "$TARGET_DIR/usr/sbin/xwt-system-menu-text" \
  "$TARGET_DIR/usr/sbin/xwt-update" \
  "$TARGET_DIR/usr/sbin/xwt-network" \
  "$TARGET_DIR/etc/init.d/S15gamepad" \
  "$TARGET_DIR/etc/init.d/S30storage" \
  "$TARGET_DIR/etc/init.d/S40network" \
  "$TARGET_DIR/etc/init.d/S46time"
mkdir -p "$TARGET_DIR/opt/xwt/modules" "$TARGET_DIR/mnt/xwt-usb"
