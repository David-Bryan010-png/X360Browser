#!/bin/sh
# XWT 0.15.0 post-build integration. Cross-compile applications with Buildroot's toolchain.
set -eu
TARGET_DIR=${1:?Buildroot target directory is required}
HOST_DIR=${HOST_DIR:?Buildroot HOST_DIR was not exported}
STAGING_DIR=${STAGING_DIR:?Buildroot STAGING_DIR was not exported}
PROJECT_ROOT=${PROJECT_ROOT:-$(CDPATH= cd -- "$(dirname "$0")/.." && pwd)}
[ -d "$TARGET_DIR" ] || { echo "XWT: target directory missing" >&2; exit 1; }

find_cross_gcc() {
  for compiler in "$HOST_DIR"/bin/*-gcc; do
    [ -x "$compiler" ] || continue
    printf '%s\n' "$compiler"
    return 0
  done
  echo "XWT: Buildroot cross GCC not found in $HOST_DIR/bin" >&2
  return 1
}
CROSS_GCC=$(find_cross_gcc)

# The desktop is a real SDL1 framebuffer app. Fail the build if required SDL modules are absent.
export PKG_CONFIG_SYSROOT_DIR="$STAGING_DIR"
PC_LIBDIR="$STAGING_DIR/usr/lib/pkgconfig:$STAGING_DIR/usr/share/pkgconfig"
for directory in "$STAGING_DIR"/usr/lib/*/pkgconfig; do
  [ -d "$directory" ] || continue
  PC_LIBDIR="$PC_LIBDIR:$directory"
done
export PKG_CONFIG_LIBDIR="$PC_LIBDIR"
PKG_CONFIG="$HOST_DIR/bin/pkg-config"
[ -x "$PKG_CONFIG" ] || PKG_CONFIG=$(command -v pkg-config)
SDL_FLAGS=$("$PKG_CONFIG" --cflags --libs sdl SDL_ttf) || {
  echo "XWT: SDL 1.2 / SDL_ttf development files unavailable" >&2
  exit 1
}

"$CROSS_GCC" -Os -std=c11 -Wall -Wextra -Werror \
  "$PROJECT_ROOT/linux/src/xwt-gamepad-keys.c" \
  -o "$TARGET_DIR/usr/sbin/xwt-gamepad-keys"
"$CROSS_GCC" -Os -std=c11 -Wall -Wextra \
  -ffunction-sections -fdata-sections \
  "$PROJECT_ROOT/linux/src/xwt-desktop.c" \
  -Wl,--gc-sections $SDL_FLAGS \
  -o "$TARGET_DIR/usr/sbin/xwt-desktop"

for path in \
  "$TARGET_DIR/usr/sbin/xwt-system-menu" \
  "$TARGET_DIR/usr/sbin/xwt-system-menu-text" \
  "$TARGET_DIR/usr/sbin/xwt-update" \
  "$TARGET_DIR/usr/sbin/xwt-network" \
  "$TARGET_DIR/usr/sbin/xwt-wifi" \
  "$TARGET_DIR/usr/sbin/xwt-video-check" \
  "$TARGET_DIR/usr/sbin/xwt-desktop" \
  "$TARGET_DIR/usr/sbin/xwt-gamepad-keys" \
  "$TARGET_DIR/etc/init.d/S15gamepad" \
  "$TARGET_DIR/etc/init.d/S18video" \
  "$TARGET_DIR/etc/init.d/S30storage" \
  "$TARGET_DIR/etc/init.d/S40network" \
  "$TARGET_DIR/etc/init.d/S46time"; do
  [ -s "$path" ] || { echo "XWT: required 0.15.0 file missing: $path" >&2; exit 1; }
done
for module in xpad joydev uinput; do
  find "$TARGET_DIR/lib/modules" -type f \
    \( -name "$module.ko" -o -name "$module.ko.xz" -o -name "$module.ko.zst" \) -print -quit | grep -q . || {
      echo "XWT: kernel module missing from rootfs: $module" >&2
      exit 1
    }
done
[ -s "$TARGET_DIR/usr/share/fonts/dejavu/DejaVuSans.ttf" ] || {
  echo "XWT: DejaVu Sans font was not installed" >&2; exit 1;
}
mkdir -p "$TARGET_DIR/opt/xwt/modules" "$TARGET_DIR/mnt/xwt-usb" "$TARGET_DIR/run"
chmod 0755 \
  "$TARGET_DIR/usr/sbin/xwt-system-menu" \
  "$TARGET_DIR/usr/sbin/xwt-system-menu-text" \
  "$TARGET_DIR/usr/sbin/xwt-update" \
  "$TARGET_DIR/usr/sbin/xwt-network" \
  "$TARGET_DIR/usr/sbin/xwt-wifi" \
  "$TARGET_DIR/usr/sbin/xwt-video-check" \
  "$TARGET_DIR/usr/sbin/xwt-desktop" \
  "$TARGET_DIR/usr/sbin/xwt-gamepad-keys" \
  "$TARGET_DIR/etc/init.d/S15gamepad" \
  "$TARGET_DIR/etc/init.d/S18video" \
  "$TARGET_DIR/etc/init.d/S30storage" \
  "$TARGET_DIR/etc/init.d/S40network" \
  "$TARGET_DIR/etc/init.d/S46time"
echo "XWT 0.15.0: desktop SDL, controller bridge, Wi-Fi and video diagnostics integrated."
