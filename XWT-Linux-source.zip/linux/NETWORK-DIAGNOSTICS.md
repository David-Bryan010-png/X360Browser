# Rede no XWT Linux Minimal Core

A primeira versão configura Ethernet integrada pelo driver SIS190 e DHCP via `udhcpc`.

1. Conecte o cabo Ethernet antes de iniciar o Linux.
2. O serviço S40network ativa a interface e solicita DHCP.
3. Execute `xwt-network check` para conferir interface, endereço, rota e DNS.
4. Para renovar manualmente: `xwt-network dhcp eth0` (substitua pela interface listada em `ip link`).

Wi-Fi USB será fornecido em módulo posterior; esta imagem-base não inclui `iw`, `wpa_supplicant` ou coleções de firmware.
