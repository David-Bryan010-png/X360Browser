#!/usr/bin/env python3
"""Exact, guarded source transformation for Free60's pinned Xenos DRM driver."""
from __future__ import annotations

from pathlib import Path
import re

MARKER = "XWT-0.15.0: guarded 32x32 tiled scanout"


def _replace_once(text: str, old: str, new: str, label: str) -> str:
    count = text.count(old)
    if count != 1:
        raise ValueError(f"{label}: expected exactly one match, found {count}")
    return text.replace(old, new, 1)


def _replace_regex_once(text: str, pattern: str, replacement: str, label: str) -> str:
    updated, count = re.subn(pattern, replacement, text, count=1, flags=re.MULTILINE | re.DOTALL)
    if count != 1:
        raise ValueError(f"{label}: expected exactly one match, found {count}")
    return updated


def _replace_function(text: str, start_sig: str, next_sig: str, body: str, label: str) -> str:
    # A function may have a forward declaration before its definition. Select
    # the unique occurrence whose opening brace appears before its semicolon.
    candidates: list[int] = []
    cursor = 0
    while True:
        pos = text.find(start_sig, cursor)
        if pos < 0:
            break
        after = text[pos + len(start_sig):]
        brace = after.find("{")
        semicolon = after.find(";")
        if brace >= 0 and (semicolon < 0 or brace < semicolon):
            candidates.append(pos)
        cursor = pos + len(start_sig)

    if not candidates:
        raise ValueError(f"{label}: function definition not found")
    if len(candidates) != 1:
        raise ValueError(f"{label}: multiple function definitions found")

    start = candidates[0]
    end = text.find(next_sig, start + len(start_sig))
    if end < 0:
        raise ValueError(f"{label}: end signature not found")
    return text[:start] + body.rstrip() + "\n\n" + text[end:]


def patch_driver_source(source: str) -> str:
    """Patch a known Free60 xenos.c version; refuse unknown source layouts."""
    if MARKER in source:
        return source

    if "struct xenos_fb" not in source or "static void xenos_enable(" not in source:
        raise ValueError("not the expected Free60 Xenos DRM driver")

    if "#include <linux/dma-mapping.h>" not in source:
        source = _replace_once(
            source,
            "#include <linux/aperture.h>\n",
            "#include <linux/aperture.h>\n#include <linux/dma-mapping.h>\n#include <linux/kernel.h>\n",
            "explicit DMA/alignment includes",
        )

    # xenos_enable() now performs the first full-frame blit. Declare the
    # existing helper before its first use (its implementation stays below).
    if "static void xenos_blit(struct iosys_map dst, struct iosys_map src,\n" not in source[:source.find("static void xenos_enable(")]:
        source = _replace_once(
            source,
            "static void xenos_enable(",
            "static void xenos_blit(struct iosys_map dst, struct iosys_map src,\n"
            "\t\t\t       struct drm_rect src_rect, struct drm_framebuffer *fb);\n\n"
            "static void xenos_enable(",
            "forward declaration for initial scanout blit",
        )

    enable = r'''static void xenos_enable(struct drm_simple_display_pipe *pipe,
			 struct drm_crtc_state *crtc_state,
			 struct drm_plane_state *plane_state)
{
	struct xenos_device *xenos = xenos_of_pipe(pipe);
	/* XWT-0.15.0: guarded 32x32 tiled scanout. */
	/* Blank first so HDMI does not show garbage (chuvisco) while we set up. */
	iowrite32be(0, xenos->regs + D1GRPH_ENABLE);
	ioread32be(xenos->regs + D1GRPH_ENABLE);

	if (crtc_state->planes_changed ||
	    IS_ERR_OR_NULL(xenos->real_framebuffer.vaddr)) {
		struct xenos_fb previous = xenos->real_framebuffer;
		struct xenos_fb next = { 0 };
		int width = plane_state->fb->width;
		int height = plane_state->fb->height;
		int bpp = drm_format_info_bpp(plane_state->fb->format, 0);
		int cpp = DIV_ROUND_UP(bpp, 8);
		size_t tiled_width;
		size_t tiled_height;

		/* This driver advertises XRGB8888 only; reject unexpected modes. */
		if (width <= 0 || height <= 0 || width > 4096 || height > 4096 ||
		    cpp != 4) {
			drm_err(&xenos->dev,
				"unsupported Xenos scanout format/dimensions: %dx%d cpp=%d\n",
				width, height, cpp);
			return;
		}

		/* Xenos addresses pixels in complete 32x32 tiles. */
		tiled_width = ALIGN((size_t)width, 32);
		tiled_height = ALIGN((size_t)height, 32);
		next.size = tiled_width * tiled_height * cpp;
		next.vaddr = dma_alloc_coherent(xenos->dev.dev, next.size,
						&next.dma_addr, GFP_KERNEL);
		if (!next.vaddr) {
			drm_err(&xenos->dev,
				"failed to allocate %zu-byte tiled Xenos scanout buffer\n",
				next.size);
			return;
		}

		/* Xenos surface registers are 32-bit physical/bus addresses. */
		if (upper_32_bits(next.dma_addr)) {
			drm_err(&xenos->dev,
				"Xenos DMA address exceeds its 32-bit surface register\n");
			dma_free_coherent(xenos->dev.dev, next.size, next.vaddr,
					  next.dma_addr);
			return;
		}

		/* Initialize visible pixels and the padded part of the last tile. */
		memset(next.vaddr, 0, next.size);
		{
			struct drm_shadow_plane_state *shadow_state =
				to_drm_shadow_plane_state(plane_state);
			struct iosys_map dst_map;
			struct drm_rect full_frame = {
				.x1 = 0, .y1 = 0, .x2 = width, .y2 = height,
			};

			iosys_map_set_vaddr(&dst_map, next.vaddr);
			xenos_blit(dst_map, shadow_state->data[0], full_frame,
				   plane_state->fb);
		}
		dma_wmb();

		/* Publish the replacement before releasing the previous allocation. */
		iowrite32be(0, xenos->regs + D1GRPH_ENABLE);
		xenos->real_framebuffer = next;
		iowrite32be(lower_32_bits(next.dma_addr),
			    xenos->regs + D1GRPH_PRIMARY_SURFACE_ADDRESS);
		dma_wmb();
		iowrite32be(1, xenos->regs + D1GRPH_ENABLE);
		ioread32be(xenos->regs + D1GRPH_ENABLE);

		if (previous.vaddr)
			dma_free_coherent(xenos->dev.dev, previous.size,
					  previous.vaddr, previous.dma_addr);

		drm_info(&xenos->dev,
			"XWT-0.15.0: %dx%d scanout, tiled allocation %zu bytes\n",
			width, height, next.size);
	}

	iowrite32be(1, xenos->regs + D1GRPH_ENABLE);
}
'''
    source = _replace_function(
        source,
        "static void xenos_enable(",
        "static void xenos_disable(",
        enable,
        "transactional Xenos scanout allocation",
    )

    disable = r'''static void xenos_disable(struct drm_simple_display_pipe *pipe)
{
	struct xenos_device *xenos = xenos_of_pipe(pipe);

	iowrite32be(0, xenos->regs + D1GRPH_ENABLE);
	ioread32be(xenos->regs + D1GRPH_ENABLE);

	if (xenos->real_framebuffer.vaddr)
		dma_free_coherent(xenos->dev.dev, xenos->real_framebuffer.size,
				  xenos->real_framebuffer.vaddr,
				  xenos->real_framebuffer.dma_addr);

	xenos->real_framebuffer.vaddr = NULL;
	xenos->real_framebuffer.size = 0;
	xenos->real_framebuffer.dma_addr = 0;
}
'''
    source = _replace_function(
        source,
        "static void xenos_disable(",
        "static void xenos_blit(",
        disable,
        "safe Xenos scanout release",
    )

    blit = r'''static void xenos_blit(struct iosys_map dst, struct iosys_map src,
		       struct drm_rect src_rect, struct drm_framebuffer *fb)
{
	u32 *dst32 = dst.vaddr;
	const u8 *src_base = src.vaddr;
	size_t tiled_width = ALIGN((size_t)fb->width, 32);
	int x1 = src_rect.x1 < 0 ? 0 : src_rect.x1;
	int y1 = src_rect.y1 < 0 ? 0 : src_rect.y1;
	int x2 = src_rect.x2 > fb->width ? fb->width : src_rect.x2;
	int y2 = src_rect.y2 > fb->height ? fb->height : src_rect.y2;
	int x, y;

	if (x1 >= x2 || y1 >= y2)
		return;

	/*
	 * Xenos uses the libXenon 32x32 tiled pixel layout. The stride is the
	 * padded tile width, not fb->width. Copy per pixel so partial damage
	 * rectangles cannot write outside their right edge.
	 */
	for (y = y1; y < y2; y++) {
		const u32 *src32 = (const u32 *)(src_base +
						 (size_t)y * fb->pitches[0]);

		for (x = x1; x < x2; x++) {
			size_t ndx = (size_t)(y & ~31) * tiled_width +
				     (size_t)(x & ~31) * 32 +
				     (((x & 3) + ((y & 1) << 2) +
				       ((x & 28) << 1) + ((y & 30) << 5)) ^
				      ((y & 8) << 2));

			dst32[ndx] = swab32(src32[x]);
		}
	}
}
'''
    source = _replace_function(
        source,
        "static void xenos_blit(",
        "static void xenos_update(",
        blit,
        "bounds-safe Xenos tiled blitter",
    )

    source = _replace_regex_once(
        source,
        r"^(\s*)xenos_blit\(dst, src, damage, fb\);\s*$",
        r"\1xenos_blit(dst, src, dst_clip, fb);",
        "clip damage to the active plane",
    )

    # The original used streaming-DMA synchronization for a coherent buffer.
    source = _replace_regex_once(
        source,
        r"^\s*dma_sync_single_for_device\(dev->dev,\s*"
        r"xenos->real_framebuffer\.dma_addr,\s*"
        r"xenos->real_framebuffer\.size, DMA_TO_DEVICE\);\s*$",
        "\t/* dma_alloc_coherent() requires ordering, not streaming-DMA sync. */\n\tdma_wmb();",
        "coherent DMA ordering",
    )
    update_start = source.find("static void xenos_update(")
    update_end = source.find("static const struct drm_simple_display_pipe_funcs", update_start)
    if update_start < 0 or update_end < 0:
        raise ValueError("could not isolate xenos_update() for cleanup")
    update_body = source[update_start:update_end]
    update_body = _replace_regex_once(
        update_body,
        r"^[ \t]*struct drm_device \*dev = &xenos->dev;\s*$",
        "",
        "remove obsolete update-local device pointer",
    )
    source = source[:update_start] + update_body + source[update_end:]

    # If an atomic modeset requests a larger buffer but allocation failed,
    # never copy the new plane into the still-valid, smaller previous buffer.
    source = _replace_regex_once(
        source,
        r"^([ \t]*)int idx;[ \t]*$",
        r"\1int idx;\n\1size_t required_size;",
        "track scanout buffer capacity during damage updates",
    )
    source = _replace_regex_once(
        source,
        r"^([ \t]*)if \(IS_ERR_OR_NULL\(xenos->real_framebuffer\.vaddr\)\)\s*\n\1[ \t]+return;",
        r"\1if (!fb || !fb->width || !fb->height || fb->width > 4096 ||\n"
        r"\1    fb->height > 4096 || fb->format->format != DRM_FORMAT_XRGB8888 ||\n"
        r"\1    fb->pitches[0] < fb->width * sizeof(u32))\n"
        r"\1\treturn;\n"
        r"\1required_size = ALIGN((size_t)fb->width, 32) *\n"
        r"\1\t       ALIGN((size_t)fb->height, 32) * sizeof(u32);\n"
        r"\1if (IS_ERR_OR_NULL(xenos->real_framebuffer.vaddr) ||\n"
        r"\1    required_size > xenos->real_framebuffer.size)\n"
        r"\1\treturn;",
        "reject damage updates larger than allocated scanout buffer",
    )

    # The Xenos primary-surface register is 32-bit. Negotiate this with the
    # DMA layer before the first coherent allocation, not only after it.
    source = _replace_regex_once(
        source,
        r"^([ \t]*)ret = pcim_enable_device\(pdev\);\n"
        r"\1if \(ret\)\n\1[ \t]+return ret;\n\n"
        r"\1ret = pci_request_regions\(pdev, DRIVER_NAME\);",
        r"\1ret = pcim_enable_device(pdev);\n"
        r"\1if (ret)\n\1\treturn ret;\n\n"
        r"\1ret = dma_set_mask_and_coherent(&pdev->dev, DMA_BIT_MASK(32));\n"
        r"\1if (ret) {\n"
        "\1\tdev_err(&pdev->dev, \"Xenos requires 32-bit DMA addressing\\n\");\n"
        r"\1\treturn ret;\n"
        r"\1}\n\n"
        r"\1ret = pci_request_regions(pdev, DRIVER_NAME);",
        "negotiate 32-bit Xenos DMA addressing before allocation",
    )

    dims_pattern = (
        r"(?m)^[ \t]*uint32_t fb_width = ioread32be\(xenos->regs \+ D1GRPH_X_END\);\s*\n"
        r"[ \t]*uint32_t fb_height = ioread32be\(xenos->regs \+ D1GRPH_Y_END\);\s*\n"
        r"[ \t]*uint32_t is_progressive = ioread32be\(xenos-> regs \+ AVIVO_D1MODE_DATA_FORMAT\);"
    )
    dims_replacement = (
        "\tuint32_t fb_width = ioread32be(xenos->regs + D1GRPH_X_END);\n"
        "\tuint32_t fb_height = ioread32be(xenos->regs + D1GRPH_Y_END);\n"
        "\tuint32_t is_progressive = ioread32be(xenos-> regs + AVIVO_D1MODE_DATA_FORMAT);\n\n"
        "\tif (!fb_width || !fb_height || fb_width > 4096 || fb_height > 4096) {\n"
        "\t\tdrm_err(dev, \"invalid Xenos scanout dimensions: %ux%u\\n\",\n"
        "\t\t\tfb_width, fb_height);\n"
        "\t\treturn -EINVAL;\n"
        "\t}\n"
    )
    source = _replace_regex_once(
        source, dims_pattern, dims_replacement, "Xenos mode dimension validation"
    )

    required = (
        "size_t tiled_width = ALIGN((size_t)fb->width, 32);",
        "dst32[ndx] = swab32(src32[x]);",
        "dma_wmb();",
        "lower_32_bits(next.dma_addr)",
        "upper_32_bits(next.dma_addr)",
        "dma_set_mask_and_coherent(&pdev->dev, DMA_BIT_MASK(32))",
        "xenos_blit(dst_map, shadow_state->data[0], full_frame,",
        "xenos->real_framebuffer.size = 0;",
    )
    missing = [item for item in required if item not in source]
    if missing:
        raise ValueError("postcondition(s) missing: " + ", ".join(missing))
    return source


def patch_driver_file(path: Path) -> bool:
    source = path.read_text(encoding="utf-8")
    updated = patch_driver_source(source)
    if updated == source:
        return False
    path.write_text(updated, encoding="utf-8")
    return True
