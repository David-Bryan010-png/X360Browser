#!/usr/bin/env python3
"""Split a Buildroot target tree into a small XeLL initramfs (stage 1) plus squashfs packs (stage 2).

XeLL loads exactly one initrd and refuses anything above 32 MiB. Everything listed in
linux/packs.rules is moved into squashfs packs (each <= --max-pack-mib) that the running
system mounts from the USB stick and overlays on top of the stage-1 directories.
"""
from __future__ import annotations

import argparse
import gzip
import hashlib
import json
import os
import shutil
import stat
import subprocess
import sys
import tempfile
from pathlib import Path

DEFAULT_MAX_PACK = 28 * 1024 * 1024
XELL_INITRD_LIMIT = 30 * 1024 * 1024  # real XeLL limit is 32 MiB; keep headroom
INCOMPRESSIBLE = (".gz", ".xz", ".zst", ".bz2", ".png", ".jpg", ".ogg", ".mp3", ".zip", ".ko")
SYNTHETIC_DIRS = ("dev", "proc", "sys", "run", "tmp", "mnt", "root", "var/run")


def read_rules(path: Path) -> list[str]:
    prefixes: list[str] = []
    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.split("#", 1)[0].strip()
        if not line:
            continue
        parts = line.split()
        if len(parts) != 2 or parts[0] != "pack":
            raise ValueError(f"invalid packs.rules line: {raw!r}")
        prefix = parts[1].strip("/")
        if not prefix or ".." in prefix.split("/"):
            raise ValueError(f"invalid prefix in packs.rules: {raw!r}")
        prefixes.append(prefix)
    return prefixes


def real_prefix(target: Path, prefix: str) -> str:
    """Resolve symlinked path components (merged /usr: lib -> usr/lib) inside target."""
    cur = target.resolve()
    parts: list[str] = []
    for comp in prefix.split("/"):
        nxt = cur / comp
        if nxt.is_symlink():
            nxt = Path(os.path.realpath(nxt))
            if target.resolve() not in nxt.parents and nxt != target.resolve():
                raise ValueError(f"{prefix}: symlink escapes target")
            parts = list(nxt.relative_to(target.resolve()).parts)
        else:
            parts.append(comp)
        cur = nxt
    return "/".join(parts)


def walk(target: Path):
    for dirpath, dirnames, filenames in os.walk(target, followlinks=False):
        dirnames.sort()
        rel = Path(dirpath).relative_to(target)
        for name in sorted(dirnames + filenames):
            yield (rel / name).as_posix()


def under(path: str, prefixes: list[str]) -> bool:
    return any(path == p or path.startswith(p + "/") for p in prefixes)


# ---------------------------------------------------------------- cpio newc writer
def _hdr(ino: int, mode: int, nlink: int, size: int, name: bytes, rdev: tuple[int, int] = (0, 0)) -> bytes:
    fields = [ino, mode, 0, 0, nlink, 0, size, 0, 0, rdev[0], rdev[1], len(name) + 1, 0]
    head = b"070701" + b"".join(b"%08X" % v for v in fields)
    blob = head + name + b"\0"
    return blob + b"\0" * (-len(blob) % 4)


def build_cpio(target: Path, stage1_paths: list[str], extra_dirs: list[str]) -> bytes:
    out = bytearray()
    ino = 1
    seen: set[str] = set()

    def add(name: str, mode: int, data: bytes = b"", rdev=(0, 0), nlink: int = 1) -> None:
        nonlocal ino
        out.extend(_hdr(ino, mode, nlink, len(data), name.encode(), rdev))
        out.extend(data + b"\0" * (-len(data) % 4))
        seen.add(name)
        ino += 1

    for d in sorted(set(SYNTHETIC_DIRS) | set(extra_dirs)):
        parts = d.split("/")
        for i in range(1, len(parts) + 1):
            sub = "/".join(parts[:i])
            if sub not in seen and not (target / sub).exists():
                add(sub, stat.S_IFDIR | 0o755, nlink=2)
    add("dev/console", stat.S_IFCHR | 0o600, rdev=(5, 1))
    add("dev/null", stat.S_IFCHR | 0o666, rdev=(1, 3))
    # The kernel runs /init from an initramfs; Buildroot normally adds it as a link to sbin/init.
    if "init" not in stage1_paths and not (target / "init").exists():
        if not (target / "sbin/init").exists():
            raise ValueError("rootfs has neither /init nor /sbin/init")
        add("init", stat.S_IFLNK | 0o777, b"sbin/init")
    for rel in stage1_paths:
        if rel in seen:
            continue
        p = target / rel
        st = p.lstat()
        if stat.S_ISLNK(st.st_mode):
            add(rel, stat.S_IFLNK | 0o777, os.readlink(p).encode())
        elif stat.S_ISDIR(st.st_mode):
            add(rel, stat.S_IFDIR | (st.st_mode & 0o7777), nlink=2)
        elif stat.S_ISREG(st.st_mode):
            add(rel, stat.S_IFREG | (st.st_mode & 0o7777), p.read_bytes())
    out.extend(_hdr(0, 0, 1, 0, b"TRAILER!!!"))
    out.extend(b"\0" * (-len(out) % 512))
    return bytes(out)


# ---------------------------------------------------------------- pack planning
def estimate(path: Path) -> int:
    size = path.lstat().st_size
    return size if path.suffix.lower() in INCOMPRESSIBLE else int(size * 0.55) + 128


def plan_packs(target: Path, files: list[str], budget: int) -> list[list[str]]:
    packs: list[list[str]] = [[]]
    used = 0
    for rel in files:
        cost = estimate(target / rel)
        if cost > budget:
            raise ValueError(f"{rel} alone (~{cost} bytes) does not fit in one pack")
        if used + cost > budget and packs[-1]:
            packs.append([])
            used = 0
        packs[-1].append(rel)
        used += cost
    return packs


def make_squashfs(target: Path, rels: list[str], out: Path, mksquashfs: str) -> None:
    with tempfile.TemporaryDirectory(dir=out.parent) as tmp:
        root = Path(tmp) / "root"
        for rel in rels:
            src, dst = target / rel, root / rel
            dst.parent.mkdir(parents=True, exist_ok=True)
            if src.is_symlink():
                os.symlink(os.readlink(src), dst)
            elif src.is_dir():
                dst.mkdir(exist_ok=True)
            else:
                try:
                    os.link(src, dst)
                except OSError:
                    shutil.copy2(src, dst)
        subprocess.run([mksquashfs, str(root), str(out), "-comp", "zstd", "-Xcompression-level", "15",
                        "-b", "128K", "-no-xattrs", "-all-root", "-noappend", "-quiet"], check=True)


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def split(target: Path, rules: Path, outdir: Path, max_pack: int, mksquashfs: str) -> dict:
    target = target.resolve()
    prefixes = sorted({real_prefix(target, p) for p in read_rules(rules)})
    everything = list(walk(target))
    moved = [p for p in everything if under(p, prefixes)]
    moved_files = [p for p in moved if not (target / p).is_dir() or (target / p).is_symlink()]
    stage1 = [p for p in everything if not under(p, prefixes)]
    # keep the (empty) overlay mount points in stage 1
    stage1 += [p for p in prefixes if p not in stage1]
    stage1 = sorted(set(stage1))

    outdir.mkdir(parents=True, exist_ok=True)
    for old in outdir.glob("xwt-pack-*.sqfs"):
        old.unlink()
    initrd = gzip.compress(build_cpio(target, stage1, prefixes), compresslevel=9, mtime=0)
    if len(initrd) > XELL_INITRD_LIMIT:
        raise SystemExit(f"stage-1 initramfs is {len(initrd)} bytes, above {XELL_INITRD_LIMIT}; "
                         "add more prefixes to linux/packs.rules")
    (outdir / "rootfs.cpio.gz").write_bytes(initrd)

    packs: list[dict] = []
    if moved_files:
        budget = max_pack
        for _ in range(6):
            plan = plan_packs(target, moved_files, budget)
            for old in outdir.glob("xwt-pack-*.sqfs"):
                old.unlink()
            names = []
            for i, rels in enumerate(plan, 1):
                out = outdir / f"xwt-pack-{i:02d}.sqfs"
                make_squashfs(target, rels, out, mksquashfs)
                names.append(out)
            if all(p.stat().st_size <= max_pack for p in names):
                break
            budget = int(budget * 0.8)
        else:
            raise SystemExit("could not fit packs under the size limit")
        for p in names:
            packs.append({"name": p.name, "size": p.stat().st_size, "sha256": sha256(p)})
    (outdir / "packs.list").write_text("".join(f"{p['sha256']}  {p['name']}  {p['size']}\n" for p in packs), encoding="ascii")
    (outdir / "overlays.list").write_text("".join(f"{p}\n" for p in prefixes), encoding="ascii")
    meta = {"initrd_bytes": len(initrd), "packs": packs, "overlays": prefixes}
    (outdir / "packs.json").write_text(json.dumps(meta, indent=2) + "\n", encoding="utf-8")
    return meta


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--target", required=True, type=Path)
    ap.add_argument("--rules", required=True, type=Path)
    ap.add_argument("--outdir", required=True, type=Path)
    ap.add_argument("--max-pack-mib", type=float, default=DEFAULT_MAX_PACK / 1048576)
    ap.add_argument("--mksquashfs", default="mksquashfs")
    a = ap.parse_args()
    meta = split(a.target, a.rules, a.outdir, int(a.max_pack_mib * 1048576), a.mksquashfs)
    print(json.dumps(meta, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
