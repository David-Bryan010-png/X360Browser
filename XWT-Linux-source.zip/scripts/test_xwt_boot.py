#!/usr/bin/env python3
"""XWT Boot (independent boot manager): profile logic compiled and run on the PC, libxenon patch, packaging, controller mouse."""
import os, shutil, subprocess, sys, tempfile, unittest
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
BOOT = ROOT / "boot/xwtboot"

C_TEST = r'''
#include "profile.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
static int has(const char *path, void *ctx) { return strstr((const char *)ctx, path) != NULL; }
int main(void) {
    XwtProfile p, q; char buf[1024], cmd[300];
    profile_defaults(&p);
    assert(!strcmp(p.folder, "uda:/X360WebTotal/Linux") && p.timeout == 5 && p.autoboot == 1);
    /* round trip */
    snprintf(p.folder, sizeof p.folder, "sda:/Distros/Outro"); snprintf(p.mode, sizeof p.mode, "safe"); p.timeout = 12; p.autoboot = 0;
    assert(profile_format(&p, buf, sizeof buf) > 0);
    profile_defaults(&q); assert(profile_parse(buf, &q) == 7);
    assert(!strcmp(q.folder, p.folder) && !strcmp(q.mode, "safe") && q.timeout == 12 && q.autoboot == 0);
    /* clamp, bad mode, comments, CRLF */
    profile_defaults(&q);
    profile_parse("# c\r\ntimeout=999\r\nmode=bogus\r\nautoboot=0\r\nunknown=1\r\n", &q);
    assert(q.timeout == 60 && !strcmp(q.mode, "normal") && q.autoboot == 0);
    profile_parse("timeout=0\n", &q); assert(q.timeout == 1);
    /* join */
    assert(profile_join("uda:/a/", "/k.elf", cmd, sizeof cmd) == 0 && !strcmp(cmd, "uda:/a/k.elf"));
    assert(profile_join("uda:/", "k.elf", cmd, sizeof cmd) == 0 && !strcmp(cmd, "uda:/k.elf"));
    assert(profile_join("uda:/x", "k.elf", cmd, 5) == -1);
    /* detect picks the known names; initrd optional */
    profile_defaults(&q); snprintf(q.folder, sizeof q.folder, "uda:/D");
    assert(profile_detect(&q, has, (void *)"uda:/D/zImage.xenon uda:/D/initrd.img") == 1);
    assert(!strcmp(q.kernel, "zImage.xenon") && !strcmp(q.initrd, "initrd.img"));
    assert(profile_detect(&q, has, (void *)"nothing here") == 0);
    assert(profile_detect(&q, has, (void *)"uda:/D/vmlinux") == 1 && q.initrd[0] == 0);
    /* command lines */
    profile_defaults(&q);
    assert(profile_cmdline(&q, cmd, sizeof cmd) == 0 && strstr(cmd, "maxcpus=6") && !strstr(cmd, "xwt.safe"));
    snprintf(q.mode, sizeof q.mode, "safe"); assert(profile_cmdline(&q, cmd, sizeof cmd) == 0 && strstr(cmd, "xwt.safe=1") && strstr(cmd, "maxcpus=1"));
    snprintf(q.mode, sizeof q.mode, "custom"); snprintf(q.cmdline, sizeof q.cmdline, "console=tty0 root=/dev/sda1");
    assert(profile_cmdline(&q, cmd, sizeof cmd) == 0 && !strcmp(cmd, "console=tty0 root=/dev/sda1"));
    assert(profile_cmdline(&q, cmd, 10) == -1);
    /* mode cycle */
    snprintf(q.mode, sizeof q.mode, "normal"); profile_next_mode(&q); assert(!strcmp(q.mode, "text"));
    profile_next_mode(&q); profile_next_mode(&q); profile_next_mode(&q); assert(!strcmp(q.mode, "normal"));
    { char a[64];
      snprintf(a, sizeof a, "uda:/a/b"); assert(profile_parent(a) == 0 && !strcmp(a, "uda:/a"));
      assert(profile_parent(a) == 0 && !strcmp(a, "uda:/"));
      assert(profile_parent(a) == 1);
      snprintf(a, sizeof a, "sda:/x/"); assert(profile_parent(a) == 0 && !strcmp(a, "sda:/")); }
    puts("profile ok");
    return 0;
}
'''

class BootTests(unittest.TestCase):
    def test_profile_logic_on_host(self):
        cc = shutil.which("gcc") or shutil.which("cc")
        if not cc: self.skipTest("no C compiler")
        with tempfile.TemporaryDirectory() as d:
            src = Path(d) / "t.c"; src.write_text(C_TEST); exe = Path(d) / "t"
            subprocess.run([cc, "-std=c11", "-Wall", "-Wextra", "-Werror", "-I", str(BOOT), str(src), str(BOOT / "profile.c"), "-o", str(exe)], check=True)
            r = subprocess.run([str(exe)], capture_output=True, text=True)
            self.assertEqual(r.returncode, 0, r.stderr); self.assertIn("profile ok", r.stdout)
    def test_boot_manager_is_independent_program(self):
        m = (BOOT / "main.c").read_text()
        for tok in ("init_hardware", "synchronize_timebases", "usb_init", "xenon_ata_init", "mount_all_devices", "choose_folder",
                    "save_config", "XWTBoot/config.cfg", "elf_runWithDeviceTree", "kernel_initrd_buffer", "dt_blob_start", "128 MiB"):
            self.assertIn(tok, m)
        # it must not depend on XeLL once running: no kboot.conf, no xenon.elf chain-loading, no TFTP/network
        for tok in ("kboot.conf", "tftp", "network_init", "xenon.elf"):
            self.assertNotIn(tok, m.replace("xenon.elf)", ""))
        self.assertTrue((BOOT / "dt/xenon.dtb").stat().st_size > 1000)
        mk = (BOOT / "Makefile").read_text()
        for tok in ("main.c", "devtree.S", "-lxenon"):
            self.assertIn(tok, mk)
    def test_patch_script_contract(self):
        s = (ROOT / "boot/patch_xwt_boot.py").read_text()
        for tok in ("0x94000000", "128 * 1024 * 1024", "kernel_initrd_buffer", "expected 1 match"):
            self.assertIn(tok, s)
        self.assertLessEqual(0x94000000 + 128 * 1024 * 1024, 0x9E000000)  # below the Xenos framebuffer
    @unittest.skipUnless(os.environ.get("XWT_REF_DIR"), "needs XWT_REF_DIR with a libxenon clone")
    def test_patch_applies_to_real_libxenon(self):
        ref = Path(os.environ["XWT_REF_DIR"])
        with tempfile.TemporaryDirectory() as d:
            shutil.copytree(ref / "libxenon", Path(d) / "libxenon", ignore=shutil.ignore_patterns(".git"))
            subprocess.run([sys.executable, str(ROOT / "boot/patch_xwt_boot.py"), f"{d}/libxenon"], check=True)
            self.assertIn("0x94000000", (Path(d) / "libxenon/libxenon/drivers/elf/elf.c").read_text())
    def test_workflow_and_packager(self):
        # XWT Boot is LEGACY: it is no longer built or shipped in the main flow (XeLL loads vmlinux + initrd.img directly).
        y = (ROOT / ".github/workflows/build-xex-from-zip.yml").read_text()
        for tok in ("LIBXENON_COMMIT", "XELL_RELOADED_COMMIT", "make xell-1f.bin xell-2f.bin", "free60/libxenon", "--xell"):
            self.assertIn(tok, y)
        steps = y.replace('"boot/patch_xwt_boot.py",', "")  # the source file may stay in the repo as legacy
        for tok in ("patch_xwt_boot.py", "--boot-dir", "xwt-boot-out", "xenon.elf"):
            self.assertNotIn(tok, steps)
        pk = (ROOT / "scripts/package_linux_usb.py").read_text()
        for tok in ("--xell", "xell-1f.bin", "legacy layout files"):
            self.assertIn(tok, pk)
        for tok in ("--boot-dir", "XWTBoot/config.cfg\".encode", "DEFAULT_BOOT_PROFILE"):
            self.assertNotIn(tok, pk)
    def test_controller_mouse_and_osk(self):
        g = (ROOT / "linux/src/xwt-gamepad-keys.c").read_text()
        for tok in ("BTN_L3", "create_virtual_mouse", "REL_WHEEL", "pointer_mode", "start_osk", "/run/xwt-gui", "EV_REP"):
            self.assertIn(tok, g)
        o = (ROOT / "linux/src/xwt-osk.c").read_text()
        for tok in ("TIOCSTI", "XWT_OSK_TTY", "Fechar", "K_SHIFT", "/dev/uinput", "ui_tap", "char_key", "KEY_LEFTSHIFT"):
            self.assertIn(tok, o)
        d = (ROOT / "linux/src/xwt-desktop.c").read_text()
        for tok in ("SDL_MOUSEMOTION", "draw_cursor", "SDL_MOUSEDRV", "write_gui_state", "/run/xwt-pointer", "draw_pointer_badge"):
            self.assertIn(tok, d)
        self.assertIn("xwt-osk", (ROOT / "linux/post-build.sh").read_text())
        self.assertIn("CONFIG_LEGACY_TIOCSTI=y", (ROOT / "linux/xwt-kernel.fragment").read_text())
        for tok in ("osk_open", "osk_click", "SDLK_F12", "file_filter"):
            self.assertIn(tok, d)
        self.assertIn("KEY_F12", g)
        self.assertIn("CONFIG_INPUT_MOUSEDEV=y", (ROOT / "linux/xwt-kernel.fragment").read_text())
    def test_x11_optional_stack(self):
        frag = (ROOT / "linux/x11.fragment").read_text()
        for tok in ("XORG_SERVER_MODULAR=y", "XDRIVER_XF86_INPUT_EVDEV=y", "XDRIVER_XF86_VIDEO_FBDEV=y", "BR2_PACKAGE_EUDEV=y", "BR2_PACKAGE_OPENBOX=y", "BR2_PACKAGE_XTERM=y", "BR2_PACKAGE_XVKBD=y", "BUILDROOT_CXX=y", "XKEYBOARD_CONFIG=y"):
            self.assertIn(tok, frag)
        self.assertNotIn("MATCHBOX", frag)
        self.assertNotIn("KDRIVE_EVDEV=y", frag)
        base = (ROOT / "linux/buildroot.config").read_text()
        self.assertNotIn("XORG_SERVER", base)
        x = (ROOT / "linux/overlay/usr/sbin/xwt-x").read_text()
        for tok in ("Xorg", "xvkbd", "xwt-gui", "AutoAddDevices", "Voltando ao desktop SDL"):
            self.assertIn(tok, x)
        wf = (ROOT / ".github/workflows/build-xex-from-zip.yml").read_text()
        self.assertIn("with_x11", wf)
        self.assertIn("x11.fragment", wf)
        self.assertIn("with_gtk", wf)
        gtk = (ROOT / "linux/gtk.fragment").read_text()
        for tok in ("MESA3D_GALLIUM_DRIVER_SOFTPIPE=y", "LIBGTK3_X11=y", "PCMANFM=y"):
            self.assertIn(tok, gtk)
        self.assertTrue((ROOT / "linux/src/xwt-xpanel.cxx").is_file())
        self.assertIn("xwt-xpanel", (ROOT / "linux/post-build.sh").read_text())
        self.assertIn("xwt-gpu-probe", (ROOT / "linux/post-build.sh").read_text())
        self.assertTrue((ROOT / "docs/PESQUISA-GPU-XENOS-PT-BR.md").is_file())

if __name__ == "__main__":
    unittest.main()
