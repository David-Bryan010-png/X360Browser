#!/usr/bin/env python3
"""Browser support: NetSurf SDL + links fallback are configured and wired into the desktop."""
import re
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


class BrowserTests(unittest.TestCase):
    def test_buildroot_has_netsurf_sdl_and_links(self):
        cfg = (ROOT / "linux/buildroot.config").read_text()
        frag = (ROOT / "linux/browser.fragment").read_text()
        for opt in ("BR2_PACKAGE_NETSURF=y", "BR2_PACKAGE_NETSURF_SDL=y", "BR2_PACKAGE_LINKS=y"):
            self.assertRegex(frag, r"(?m)^" + re.escape(opt) + r"$")
            self.assertNotIn(opt, cfg)  # the base system must not depend on the browser build
        for opt in ("BR2_PACKAGE_SDL=y", "BR2_PACKAGE_LIBCURL=y"):
            self.assertRegex(cfg, r"(?m)^" + re.escape(opt) + r"$")
        self.assertNotRegex(frag, r"(?m)^BR2_PACKAGE_NETSURF_GTK3=y")
        wf = (ROOT / ".github/workflows/build-xex-from-zip.yml").read_text()
        self.assertIn("with_browser", wf)
        self.assertIn("browser.fragment", wf)

    def test_desktop_tries_browsers_in_order_and_home_exists(self):
        c = (ROOT / "linux/src/xwt-desktop.c").read_text()
        i = [c.index(x) for x in ('execlp("netsurf-fb"', 'execlp("netsurf"', 'execlp("links"')]
        self.assertEqual(i, sorted(i))
        self.assertIn("file:///usr/share/xwt/home.html", c)
        home = ROOT / "linux/overlay/usr/share/xwt/home.html"
        self.assertTrue(home.is_file())
        self.assertIn('charset="utf-8"', home.read_text())

    def test_usr_share_is_packed_so_home_page_is_available(self):
        rules = (ROOT / "linux/packs.rules").read_text().split()
        self.assertIn("usr/share", rules)

    def test_no_sdl2_or_2_0_0_claims(self):
        for rel in (".github/workflows/build-core.yml", "updates/desktop/payload/manifest.json", "PRODUCT.txt", "linux/README-PT-BR.md"):
            t = (ROOT / rel).read_text()
            self.assertNotIn("SDL2", t, rel)
        self.assertNotIn("full 2.0.0", (ROOT / ".github/workflows/build-core.yml").read_text())

    def test_plan_doc_exists_and_is_honest(self):
        d = (ROOT / "docs/PLANO-DRIVER-GRAFICO-PT-BR.md").read_text()
        self.assertIn("nao foi testada no console", d.lower().replace("nenhuma fase abaixo foi testada no console", "nao foi testada no console"))
        self.assertIn("PowerPC", d)


if __name__ == "__main__":
    unittest.main()
