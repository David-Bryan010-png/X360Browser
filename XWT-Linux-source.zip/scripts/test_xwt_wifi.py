#!/usr/bin/env python3
from pathlib import Path
import unittest
ROOT=Path(__file__).resolve().parents[1]
class WifiTests(unittest.TestCase):
    def test_wifi_helper_has_status_scan_connect_menu(self):
        s=(ROOT/"linux/overlay/usr/sbin/xwt-wifi").read_text()
        for token in ("status)","scan)","connect)","menu)","iw dev","wpa_supplicant","udhcpc","/mnt/xwt-usb"):
            self.assertIn(token,s)
    def test_wifi_config_example_is_a_safe_placeholder(self):
        s=(ROOT/"linux/overlay/etc/xwt/wpa_supplicant.conf.example").read_text()
        self.assertIn('ssid="NOME_DA_REDE"',s)
        self.assertIn('psk="SENHA_DA_REDE"',s)
