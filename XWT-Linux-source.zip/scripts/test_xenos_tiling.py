#!/usr/bin/env python3
"""Exhaustive regression tests for Xenos 32x32 tiled framebuffer addressing."""
from __future__ import annotations

import unittest


def align32(value: int) -> int:
    return (value + 31) & ~31


def xenos_tile_index(width: int, x: int, y: int) -> int:
    tiled_width = align32(width)
    return (
        (y & ~31) * tiled_width
        + (x & ~31) * 32
        + (
            (
                (x & 3)
                + ((y & 1) << 2)
                + ((x & 28) << 1)
                + ((y & 30) << 5)
            ) ^ ((y & 8) << 2)
        )
    )


class XenosTilingTests(unittest.TestCase):
    def assert_surface_is_valid(self, width: int, height: int) -> None:
        capacity = align32(width) * align32(height)
        positions: set[int] = set()
        for y in range(height):
            for x in range(width):
                index = xenos_tile_index(width, x, y)
                self.assertGreaterEqual(index, 0)
                self.assertLess(index, capacity, (width, height, x, y, index, capacity))
                positions.add(index)
        self.assertEqual(len(positions), width * height)

    def test_720p_surface_fits_padded_allocation(self) -> None:
        self.assert_surface_is_valid(1280, 720)

    def test_full_hd_surface_fits_padded_allocation(self) -> None:
        self.assert_surface_is_valid(1920, 1080)

    def test_non_aligned_dimensions_fit_and_do_not_collide(self) -> None:
        self.assert_surface_is_valid(37, 35)
        self.assert_surface_is_valid(1366, 768)

    def test_720p_old_linear_allocation_was_too_small(self) -> None:
        width, height = 1280, 720
        old_capacity = width * height
        maximum = max(
            xenos_tile_index(width, x, y)
            for y in range(height)
            for x in range(width)
        )
        self.assertGreaterEqual(maximum + 1, old_capacity)
        self.assertEqual(align32(width) * align32(height), 1280 * 736)


if __name__ == "__main__":
    unittest.main(verbosity=2)
