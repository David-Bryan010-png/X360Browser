#!/usr/bin/env python3
"""Host tests for XeLL ELF32 kernel and initramfs USB packaging."""
from __future__ import annotations

import gzip
import struct
import tempfile
import unittest
import zipfile
from pathlib import Path
from unittest import mock

import package_linux_usb as pkg


def valid_ppc32_elf() -> bytes:
    """A small ELF32/PPC executable with one valid executable PT_LOAD."""
    phoff = 52
    payload_off = phoff + 32
    payload = b"CODE"
    data = bytearray(payload_off + len(payload))
    data[:7] = b"\x7fELF\x01\x02\x01"
    struct.pack_into(">HHI", data, 16, 2, 20, 1)
    struct.pack_into(">II", data, 24, 0x1000, phoff)
    struct.pack_into(">I", data, 32, 0)  # no section table needed by this fixture
    struct.pack_into(">HHH", data, 40, 52, 32, 1)
    struct.pack_into(">IIIIIIII", data, phoff, 1, payload_off, 0x1000, 0x1000,
                     len(payload), len(payload), 5, 4)
    data[payload_off:] = payload
    return bytes(data)


def newc_record(name: str, payload: bytes = b"", mode: int = 0o100644) -> bytes:
    name_bytes = name.encode("utf-8") + b"\0"
    fields = [1, mode, 0, 0, 1, 0, len(payload), 0, 0, 0, 0, len(name_bytes), 0]
    header = b"070701" + b"".join(f"{value:08x}".encode("ascii") for value in fields)
    record = header + name_bytes
    record += b"\0" * ((-len(record)) % 4)
    record += payload
    record += b"\0" * ((-len(payload)) % 4)
    return record


def valid_newc() -> bytes:
    return newc_record("init", b"#!/bin/sh\n", 0o100755) + newc_record("TRAILER!!!", b"", 0)


class LinuxPackageTests(unittest.TestCase):
    def test_kernel_header_and_program_header(self):
        pkg.validate_kernel_bytes(valid_ppc32_elf())

    def test_accepts_zero_entry_point_at_executable_load_address_zero(self):
        data = bytearray(valid_ppc32_elf())
        struct.pack_into(">I", data, 24, 0)
        struct.pack_into(">I", data, 52 + 12, 0)  # p_paddr = 0
        pkg.validate_kernel_bytes(data)

    def test_rejects_zero_entry_point_outside_executable_load_segment(self):
        data = bytearray(valid_ppc32_elf())
        struct.pack_into(">I", data, 24, 0)
        with self.assertRaisesRegex(
            ValueError,
            "entry point is not inside an executable PT_LOAD segment",
        ):
            pkg.validate_kernel_bytes(data)

    def test_rejects_elf64_even_when_powerpc64(self):
        data = bytearray(valid_ppc32_elf())
        data[4] = 2
        with self.assertRaisesRegex(ValueError, "ELF32"):
            pkg.validate_kernel_bytes(data)

    def test_rejects_kernel_file_larger_than_xell_staging_space(self):
        data = valid_ppc32_elf() + b"\0" * (pkg.XELL_ELF_MAX_MAPPED_SIZE - len(valid_ppc32_elf()))
        with self.assertRaisesRegex(ValueError, "staging space"):
            pkg.validate_kernel_bytes(data)

    def test_rejects_wrong_machine(self):
        data = bytearray(valid_ppc32_elf())
        struct.pack_into(">H", data, 18, 3)
        with self.assertRaises(ValueError):
            pkg.validate_kernel_bytes(data)

    def test_rejects_truncated_program_header_table(self):
        data = bytearray(valid_ppc32_elf())
        struct.pack_into(">I", data, 28, 0xFFFFFFF0)
        with self.assertRaisesRegex(ValueError, "program-header table"):
            pkg.validate_kernel_bytes(data)

    def test_rejects_program_segment_outside_file(self):
        data = bytearray(valid_ppc32_elf())
        struct.pack_into(">I", data, 52 + 4, 0x100000)
        with self.assertRaisesRegex(ValueError, "exceeds the file size"):
            pkg.validate_kernel_bytes(data)

    def test_rejects_segment_bigger_than_xell_loader_limit(self):
        data = bytearray(valid_ppc32_elf())
        struct.pack_into(">I", data, 52 + 12, 0)  # p_paddr
        struct.pack_into(">I", data, 52 + 20, pkg.XELL_ELF_MAX_MAPPED_SIZE)  # p_memsz
        with self.assertRaisesRegex(ValueError, "XeLL's supported limit"):
            pkg.validate_kernel_bytes(data)

    def test_rejects_no_loadable_segment(self):
        data = bytearray(valid_ppc32_elf())
        struct.pack_into(">I", data, 52, 4)  # PT_NOTE, not PT_LOAD
        with self.assertRaisesRegex(ValueError, "no loadable PT_LOAD"):
            pkg.validate_kernel_bytes(data)

    def test_rejects_non_executable_entry_segment(self):
        data = bytearray(valid_ppc32_elf())
        struct.pack_into(">I", data, 52 + 24, 4)  # PF_R, no PF_X
        with self.assertRaisesRegex(ValueError, "executable PT_LOAD"):
            pkg.validate_kernel_bytes(data)

    def test_source_version_guard_is_present(self):
        source = (Path(pkg.__file__)).read_text()
        self.assertIn('source_version != VERSION or source_revision != REVISION', source)
        self.assertIn('source/package version mismatch', source)

    def test_launcher_requires_xex2(self):
        with tempfile.TemporaryDirectory() as d:
            path = Path(d) / "bad.xex"
            path.write_bytes(b"NOTX" + b"x" * 2048)
            with self.assertRaises(ValueError):
                pkg.validate_launcher(path)

    def test_kboot_requires_magic_first_line_and_quoted_boot_entry(self):
        valid = (
            b"#KBOOTCONFIG\n"
            b"default=xwt_linux_usb\n"
            b"timeout=10\n"
            b' xwt_linux_usb="uda:/X360WebTotal/Linux/xwt-linux.elf initrd=uda:/X360WebTotal/Linux/rootfs.cpio.gz"\n'
        )
        pkg.validate_kboot(valid)
        with self.assertRaises(ValueError):
            pkg.validate_kboot(b"# comment\n" + valid)
        with self.assertRaises(ValueError):
            pkg.validate_kboot(valid.replace(b' xwt_linux_usb="', b' xwt_linux_usb='))

    def test_initrd_must_be_valid_gzip_newc_with_trailer(self):
        pkg.validate_initrd_bytes(gzip.compress(valid_newc()))
        with self.assertRaises(ValueError):
            pkg.validate_initrd_bytes(gzip.compress(b"not-cpio"))
        with self.assertRaises(ValueError):
            pkg.validate_initrd_bytes(gzip.compress(b"070701" + b"0" * 100))

    def test_initrd_rejects_path_traversal(self):
        archive = newc_record("../escape", b"no") + newc_record("TRAILER!!!", b"", 0)
        with self.assertRaisesRegex(ValueError, "unsafe cpio pathname"):
            pkg.validate_initrd_bytes(gzip.compress(archive))

    def test_package_creation_and_crc_hash_verification(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            project = root / "project"
            (project / "linux/boot").mkdir(parents=True)
            (project / "README-INSTALL-PT-BR.txt").write_text("USB boot", encoding="utf-8")
            (project / "linux/boot/kboot.conf").write_text(
                '#KBOOTCONFIG\ndefault=xwt_linux_usb\ntimeout=10\nxwt_linux_usb="uda:/X360WebTotal/Linux/xwt-linux.elf initrd=uda:/X360WebTotal/Linux/rootfs.cpio.gz"\n',
                encoding="utf-8",
            )
            (project / "VERSION").write_text("1.0.0\n", encoding="ascii")
            (project / "REVISION.txt").write_text(pkg.REVISION + "\n", encoding="ascii")
            launcher = root / "default.xex"
            launcher.write_bytes(b"XEX2" + b"L" * 2044)
            license_file = root / "XellLaunch2-LICENSE.txt"
            license_file.write_text("MIT License\nCopyright (c) 2025 Mitchell Waite\n", encoding="utf-8")
            kernel = root / "zImage.xenon"
            kernel.write_bytes(valid_ppc32_elf())
            initrd = root / "rootfs.cpio.gz"
            initrd.write_bytes(gzip.compress(valid_newc()))
            output = root / "usb.zip"
            argv = ["package_linux_usb.py", "--launcher", str(launcher), "--launcher-license", str(license_file),
                    "--kernel", str(kernel), "--initrd", str(initrd),
                    "--project", str(project), "--output", str(output)]
            with mock.patch("sys.argv", argv):
                self.assertEqual(pkg.main(), 0)
            pkg.verify_package(output)
            with zipfile.ZipFile(output) as z:
                self.assertIn("default.xex", z.namelist())
                self.assertIn("XellLaunch2-LICENSE.txt", z.namelist())
                self.assertIn("kboot.conf", z.namelist())
                self.assertIn("X360WebTotal/Linux/xwt-linux.elf", z.namelist())
                self.assertIn("X360WebTotal/Linux/rootfs.cpio.gz", z.namelist())

    def test_boot_elf_layout_moves_kboot_out_of_root(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            project = root / "project"
            (project / "linux/boot").mkdir(parents=True)
            (project / "README-INSTALL-PT-BR.txt").write_text("USB boot", encoding="utf-8")
            (project / "linux/boot/kboot.conf").write_text(
                '#KBOOTCONFIG\ndefault=xwt_linux_usb\ntimeout=0\nxwt_linux_usb="uda:/X360WebTotal/Linux/xwt-linux.elf initrd=uda:/X360WebTotal/Linux/rootfs.cpio.gz"\n',
                encoding="utf-8")
            (project / "VERSION").write_text("1.0.0\n", encoding="ascii")
            (project / "REVISION.txt").write_text(pkg.REVISION + "\n", encoding="ascii")
            (root / "default.xex").write_bytes(b"XEX2" + b"L" * 2044)
            (root / "lic.txt").write_text("MIT License\nCopyright (c) 2025 Mitchell Waite\n", encoding="utf-8")
            (root / "zImage.xenon").write_bytes(valid_ppc32_elf())
            (root / "rootfs.cpio.gz").write_bytes(gzip.compress(valid_newc()))
            boot = root / "boot"; boot.mkdir()
            (boot / "xenon.elf").write_bytes(b"\x7fELF" + b"\0" * 8192)
            out = root / "usb.zip"
            argv = ["package_linux_usb.py", "--launcher", str(root / "default.xex"), "--launcher-license", str(root / "lic.txt"),
                    "--kernel", str(root / "zImage.xenon"), "--initrd", str(root / "rootfs.cpio.gz"),
                    "--boot-dir", str(boot), "--project", str(project), "--output", str(out)]
            with mock.patch("sys.argv", argv):
                self.assertEqual(pkg.main(), 0)
            with zipfile.ZipFile(out) as z:
                names = z.namelist()
                self.assertIn("xenon.elf", names)
                self.assertNotIn("kboot.conf", names)  # a root kboot.conf would make XeLL skip xenon.elf
                self.assertIn(b"folder=uda:/X360WebTotal/Linux", z.read("XWTBoot/config.cfg"))

    def test_rejects_parent_path(self):
        with self.assertRaises(ValueError):
            pkg.safe_member("../bad")


if __name__ == "__main__":
    unittest.main(verbosity=2)
