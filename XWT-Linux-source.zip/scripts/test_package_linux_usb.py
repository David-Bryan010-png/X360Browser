#!/usr/bin/env python3
"""Host tests for Linux kernel/initramfs USB packaging."""
from __future__ import annotations
import gzip
import struct
import tempfile
import unittest
import zipfile
from pathlib import Path
from unittest import mock

import package_linux_usb as pkg


def valid_ppc32_elf() -> bytes:
    data = bytearray(52)
    data[:7] = b"\x7fELF\x01\x02\x01"
    struct.pack_into(">HHI", data, 16, 2, 20, 1)
    struct.pack_into(">I", data, 24, 0x1000)
    return bytes(data)


class LinuxPackageTests(unittest.TestCase):
    def test_kernel_header(self):
        with tempfile.TemporaryDirectory() as d:
            path = Path(d) / "kernel"
            path.write_bytes(valid_ppc32_elf())
            pkg.validate_kernel(path)

    def test_rejects_wrong_machine(self):
        data = bytearray(valid_ppc32_elf())
        struct.pack_into(">H", data, 18, 3)
        with tempfile.TemporaryDirectory() as d:
            path = Path(d) / "kernel"
            path.write_bytes(data)
            with self.assertRaises(ValueError):
                pkg.validate_kernel(path)

    def test_launcher_requires_xex2(self):
        with tempfile.TemporaryDirectory() as d:
            path = Path(d) / "bad.xex"
            path.write_bytes(b"NOTX" + b"x" * 2048)
            with self.assertRaises(ValueError):
                pkg.validate_launcher(path)

    def test_kboot_requires_magic_first_line_and_quoted_boot_entry(self):
        valid = (
            b"#KBOOTCONFIG\n"
            b"default=xwt_linux_usb\n"
            b"timeout=10\n"
            b' xwt_linux_usb="uda:/X360WebTotal/Linux/xwt-linux.elf initrd=uda:/X360WebTotal/Linux/rootfs.cpio.gz"\n'
        )
        pkg.validate_kboot(valid)
        with self.assertRaises(ValueError):
            pkg.validate_kboot(b"# comment\n" + valid)
        with self.assertRaises(ValueError):
            pkg.validate_kboot(valid.replace(b' xwt_linux_usb="', b' xwt_linux_usb='))

    def test_initrd_must_be_gzip_newc(self):
        with tempfile.TemporaryDirectory() as d:
            path = Path(d) / "initrd.gz"
            path.write_bytes(gzip.compress(b"070701" + b"0" * 100))
            pkg.validate_initrd(path)
            path.write_bytes(gzip.compress(b"not-cpio"))
            with self.assertRaises(ValueError):
                pkg.validate_initrd(path)

    def test_package_creation_and_crc_hash_verification(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            project = root / "project"
            (project / "linux/boot").mkdir(parents=True)
            (project / "README-INSTALL-PT-BR.txt").write_text("USB boot", encoding="utf-8")
            (project / "linux/boot/kboot.conf").write_text(
                '#KBOOTCONFIG\ndefault=xwt_linux_usb\ntimeout=10\nxwt_linux_usb="uda:/X360WebTotal/Linux/xwt-linux.elf initrd=uda:/X360WebTotal/Linux/rootfs.cpio.gz"\n',
                encoding="utf-8",
            )
            (project / "VERSION").write_text("0.14.0-alpha.2\n", encoding="ascii")
            (project / "REVISION.txt").write_text(pkg.REVISION + "\n", encoding="ascii")
            launcher = root / "default.xex"
            launcher.write_bytes(b"XEX2" + b"L" * 2044)
            license_file = root / "XellLaunch2-LICENSE.txt"
            license_file.write_text("MIT License\nCopyright (c) 2025 Mitchell Waite\n", encoding="utf-8")
            kernel = root / "zImage.xenon"
            kernel.write_bytes(valid_ppc32_elf())
            initrd = root / "rootfs.cpio.gz"
            initrd.write_bytes(gzip.compress(b"070701" + b"0" * 128))
            output = root / "usb.zip"
            argv = ["package_linux_usb.py", "--launcher", str(launcher), "--launcher-license", str(license_file),
                    "--kernel", str(kernel), "--initrd", str(initrd),
                    "--project", str(project), "--output", str(output)]
            with mock.patch("sys.argv", argv):
                self.assertEqual(pkg.main(), 0)
            pkg.verify_package(output)
            with zipfile.ZipFile(output) as z:
                self.assertIn("default.xex", z.namelist())
                self.assertIn("XellLaunch2-LICENSE.txt", z.namelist())
                self.assertIn("kboot.conf", z.namelist())
                self.assertIn("X360WebTotal/Linux/xwt-linux.elf", z.namelist())
                self.assertIn("X360WebTotal/Linux/rootfs.cpio.gz", z.namelist())

    def test_rejects_parent_path(self):
        with self.assertRaises(ValueError):
            pkg.safe_member("../bad")


if __name__ == "__main__":
    unittest.main(verbosity=2)
