#!/usr/bin/env python3
"""Tests for the stage-1 initramfs / stage-2 squashfs pack splitter and xwt-packs."""
from __future__ import annotations

import gzip
import os
import shutil
import subprocess
import sys
import tempfile
import textwrap
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import split_rootfs as sr  # noqa: E402
from package_linux_usb import validate_newc  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
PACKS = ROOT / "linux/overlay/usr/sbin/xwt-packs"

FAKE_MKSQUASHFS = textwrap.dedent("""\
    #!/bin/sh
    # fake: "pack" = concatenated staged files so xwt-packs tests need no squashfs-tools
    find "$1" -type f -exec cat {} + > "$2"
""")


def make_tree(root: Path, with_init: bool = True) -> None:
    (root / "bin").mkdir(parents=True)
    (root / "bin/busybox").write_bytes(b"\x7fELF" + b"b" * 100)
    os.chmod(root / "bin/busybox", 0o755)
    (root / "bin/sh").symlink_to("busybox")
    if with_init:
        (root / "sbin").mkdir()
        (root / "sbin/init").symlink_to("../bin/busybox")
    (root / "etc").mkdir()
    (root / "etc/inittab").write_text("::sysinit:/bin/true\n")
    (root / "usr/share/fonts").mkdir(parents=True)
    for i in range(6):
        (root / f"usr/share/fonts/f{i}.ttf").write_bytes(os.urandom(4000))
    (root / "usr/lib/firmware").mkdir(parents=True)
    (root / "usr/lib/firmware/blob.bin").write_bytes(b"f" * 3000)
    (root / "lib").symlink_to("usr/lib")


class SplitTests(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        self.target = self.tmp / "target"
        make_tree(self.target)
        self.rules = self.tmp / "packs.rules"
        self.rules.write_text("pack usr/share\npack lib/firmware\n")
        fake = self.tmp / "mksquashfs"
        fake.write_text(FAKE_MKSQUASHFS)
        fake.chmod(0o755)
        self.fake = str(fake)

    def test_rules_resolve_merged_usr(self):
        self.assertEqual(sr.real_prefix(self.target, "lib/firmware"), "usr/lib/firmware")

    def test_bad_rules_rejected(self):
        bad = self.tmp / "bad"
        bad.write_text("pack ../etc\n")
        with self.assertRaises(ValueError):
            sr.read_rules(bad)

    def test_split_stage1_is_valid_newc_without_heavy_files(self):
        out = self.tmp / "out"
        meta = sr.split(self.target, self.rules, out, 8000, self.fake)
        data = gzip.decompress((out / "rootfs.cpio.gz").read_bytes())
        validate_newc(data)
        self.assertIn(b"bin/busybox", data)
        self.assertIn(b"dev/console", data)
        self.assertNotIn(b"f3.ttf", data)
        self.assertNotIn(b"blob.bin", data)
        self.assertGreaterEqual(len(meta["packs"]), 2)
        self.assertIn("usr/share", meta["overlays"])

    def test_init_link_is_added(self):
        out = self.tmp / "out"
        sr.split(self.target, self.rules, out, 8000, self.fake)
        data = gzip.decompress((out / "rootfs.cpio.gz").read_bytes())
        self.assertIn(b"\0init\0" if False else b"init\0", data)
        self.assertIn(b"sbin/init", data)

    def test_missing_init_fails(self):
        shutil.rmtree(self.target)
        make_tree(self.target, with_init=False)
        with self.assertRaises(ValueError):
            sr.split(self.target, self.rules, self.tmp / "out", 8000, self.fake)

    def test_pack_list_format(self):
        out = self.tmp / "out"
        sr.split(self.target, self.rules, out, 8000, self.fake)
        lines = (out / "packs.list").read_text().splitlines()
        self.assertTrue(lines)
        for line in lines:
            sha, name, size = line.split()
            self.assertEqual(len(sha), 64)
            self.assertEqual(int(size), (out / name).stat().st_size)

    def test_oversized_file_fails(self):
        (self.target / "usr/share/huge.ttf").write_bytes(b"x" * 50000)
        with self.assertRaises(ValueError):
            sr.split(self.target, self.rules, self.tmp / "out", 8000, self.fake)

    def test_stage1_over_limit_fails(self):
        old = sr.XELL_INITRD_LIMIT
        sr.XELL_INITRD_LIMIT = 10
        try:
            with self.assertRaises(SystemExit):
                sr.split(self.target, self.rules, self.tmp / "out", 8000, self.fake)
        finally:
            sr.XELL_INITRD_LIMIT = old


class PackageVerifyTests(unittest.TestCase):
    def build_zip(self, size_field=None, sha=None):
        import hashlib, io, zipfile
        from package_linux_usb import verify_packs
        data = b"pack-data"
        line = f"{sha or hashlib.sha256(data).hexdigest()}  xwt-pack-01.sqfs  {size_field or len(data)}\n"
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w") as z:
            z.writestr("xwt/packs/xwt-pack-01.sqfs", data)
            z.writestr("xwt/packs/packs.list", line)
            z.writestr("xwt/packs/overlays.list", "usr/share\n")
        z = zipfile.ZipFile(buf)
        verify_packs(z, set(z.namelist()))

    def test_valid(self):
        self.build_zip()

    def test_bad_sha(self):
        with self.assertRaises(ValueError):
            self.build_zip(sha="0" * 64)

    def test_bad_size(self):
        with self.assertRaises(ValueError):
            self.build_zip(size_field=3)


class PacksRuntimeTests(unittest.TestCase):
    def run_packs(self, packs_dir: Path, run: Path, cmdline="", stub=None):
        bindir = self.tmp / "bin"
        bindir.mkdir(exist_ok=True)
        (bindir / "mount").write_text(stub or "#!/bin/sh\nexit 0\n")
        (bindir / "mount").chmod(0o755)
        (run).mkdir(exist_ok=True)
        cmd = self.tmp / "cmdline"
        cmd.write_text(cmdline)
        env = dict(os.environ, PATH=f"{bindir}:{os.environ['PATH']}", XWT_PACKS_DIR=str(packs_dir),
                   XWT_RUN=str(run), XWT_CMDLINE=str(cmd))
        return subprocess.run(["sh", str(PACKS), "mount"], env=env, capture_output=True, text=True)

    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        self.packs = self.tmp / "packs"
        self.packs.mkdir()
        self.run = self.tmp / "run"

    def test_missing_manifest(self):
        r = self.run_packs(self.packs, self.run)
        self.assertNotEqual(r.returncode, 0)
        self.assertIn("XWT_PACKS=missing", (self.run / "xwt-packs.env").read_text())

    def test_ok_and_bad_size(self):
        (self.packs / "xwt-pack-01.sqfs").write_bytes(b"abc")
        (self.packs / "overlays.list").write_text("")
        (self.packs / "packs.list").write_text("0" * 64 + "  xwt-pack-01.sqfs  3\n")
        r = self.run_packs(self.packs, self.run)
        self.assertEqual(r.returncode, 0, r.stderr)
        self.assertIn("XWT_PACKS=ok", (self.run / "xwt-packs.env").read_text())
        (self.packs / "packs.list").write_text("0" * 64 + "  xwt-pack-01.sqfs  99\n")
        r = self.run_packs(self.packs, self.run)
        self.assertNotEqual(r.returncode, 0)
        self.assertIn("BAD SIZE", (self.run / "xwt-packs.log").read_text())

    def test_missing_pack_file_reported(self):
        (self.packs / "overlays.list").write_text("")
        (self.packs / "packs.list").write_text("0" * 64 + "  xwt-pack-09.sqfs  3\n")
        self.run_packs(self.packs, self.run)
        self.assertIn("MISSING xwt-pack-09.sqfs", (self.run / "xwt-packs.log").read_text())
        self.assertIn("XWT_PACKS=missing", (self.run / "xwt-packs.env").read_text())


if __name__ == "__main__":
    unittest.main()
