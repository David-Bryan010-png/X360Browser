#!/usr/bin/env python3
"""Apply and verify the XWT Linux 0.15.0 Xenos driver correction."""
from __future__ import annotations

import argparse
from pathlib import Path
import sys

from xenos_patchlib import patch_driver_file


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("buildroot_output", type=Path)
    args = parser.parse_args()

    root = args.buildroot_output.resolve()
    candidates = list(root.glob("build/linux-*/drivers/gpu/drm/tiny/xenos.c"))
    if len(candidates) != 1:
        raise SystemExit(
            "Expected exactly one configured Free60 Xenos driver at "
            f"{root}/build/linux-*/drivers/gpu/drm/tiny/xenos.c; found {len(candidates)}"
        )

    path = candidates[0]
    try:
        changed = patch_driver_file(path)
    except (OSError, ValueError) as exc:
        raise SystemExit(f"Refusing to patch unexpected Xenos source: {exc}") from exc

    print(("Patched" if changed else "Already patched") + f": {path}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
