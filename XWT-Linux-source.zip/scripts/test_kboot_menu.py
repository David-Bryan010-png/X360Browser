#!/usr/bin/env python3
"""XeLL boot menu (controller selectable) and the PC helper that extends it."""
from __future__ import annotations

import importlib.util
import tempfile
import unittest
from pathlib import Path

import package_linux_usb

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("xwt_kboot", ROOT / "tools/xwt-kboot.py")
xwt_kboot = importlib.util.module_from_spec(spec)
spec.loader.exec_module(xwt_kboot)


def entries(text: str) -> dict[str, str]:
    result = {}
    for line in text.splitlines():
        if line and line[0] not in "#;" and "=" in line:
            key, value = line.split("=", 1)
            if value.startswith('"'):
                result[key] = value.strip('"')
    return result


class MenuTests(unittest.TestCase):
    def setUp(self) -> None:
        self.text = (ROOT / "linux/boot/kboot.conf").read_text()

    def test_menu_has_several_selectable_entries_within_xell_limits(self) -> None:
        found = entries(self.text)
        for label in ("xwt", "xwt_text", "xwt_safe", "xwt_debug"):
            self.assertIn(label, found)
        for label, value in found.items():
            self.assertLessEqual(len(value), 255, label)
        self.assertLess(len(self.text.encode()), 16000)
        package_linux_usb.validate_kboot(self.text.encode("ascii"))

    def test_debug_entry_shows_initcalls_and_safe_modes_are_single_cpu(self) -> None:
        found = entries(self.text)
        self.assertIn("initcall_debug", found["xwt_debug"])
        self.assertIn("maxcpus=1", found["xwt_safe"])
        self.assertIn("xwt.text=1", found["xwt_text"])

    def test_validator_rejects_oversized_and_duplicate_entries(self) -> None:
        long_entry = 'x_long="uda:/' + "a" * 300 + '"\n'
        with self.assertRaises(ValueError):
            package_linux_usb.validate_kboot((self.text + long_entry).encode())
        with self.assertRaises(ValueError):
            package_linux_usb.validate_kboot((self.text + 'xwt="uda:/x"\n').encode())


class AutoBootTests(unittest.TestCase):
    def test_shipped_config_boots_automatically_without_countdown(self) -> None:
        text = (ROOT / "linux/boot/kboot.conf").read_text()
        self.assertIn("\ntimeout=0\n", text)
        self.assertIn("\ndefault=xwt\n", text)
        self.assertNotIn("\r", text)

    def test_validator_rejects_crlf_and_missing_timeout(self) -> None:
        text = (ROOT / "linux/boot/kboot.conf").read_text()
        with self.assertRaises(ValueError):
            package_linux_usb.validate_kboot(text.replace("\n", "\r\n").encode())
        with self.assertRaises(ValueError):
            package_linux_usb.validate_kboot(text.replace("timeout=0\n", "").encode())

    def test_mode_switch_changes_only_default_and_timeout(self) -> None:
        text = (ROOT / "linux/boot/kboot.conf").read_text()
        menu = xwt_kboot.apply_mode(text, "menu")
        self.assertIn("\ntimeout=20\n", menu)
        safe = xwt_kboot.apply_mode(text, "safe")
        self.assertIn("\ndefault=xwt_safe\n", safe)
        self.assertEqual(xwt_kboot.apply_mode(menu, "auto"), text)
        package_linux_usb.validate_kboot(safe.encode())


class ToolTests(unittest.TestCase):
    def make_usb(self) -> Path:
        usb = Path(tempfile.mkdtemp())
        (usb / "kboot.conf").write_text((ROOT / "linux/boot/kboot.conf").read_text())
        boot = usb / "xwt/boot"
        boot.mkdir(parents=True)
        (boot / "My Game.elf").write_bytes(b"\x7fELF")
        (boot / "vmlinuz").write_bytes(b"k")
        (boot / "initrd.gz").write_bytes(b"i")
        return usb

    def test_scan_finds_elf_and_kernel_initrd_pair(self) -> None:
        usb = self.make_usb()
        found = dict(xwt_kboot.scan(usb))
        self.assertIn("extra_My_Game", found)
        self.assertEqual(found["extra_My_Game"], "uda:/xwt/boot/My Game.elf")
        kernel = found["extra_vmlinuz"]
        self.assertIn("initrd=uda:/xwt/boot/initrd.gz", kernel)

    def test_rewrite_is_idempotent_and_preserves_core_entries(self) -> None:
        usb = self.make_usb()
        original = (usb / "kboot.conf").read_text()
        once = xwt_kboot.rewrite(original, xwt_kboot.scan(usb))
        twice = xwt_kboot.rewrite(once, xwt_kboot.scan(usb))
        self.assertEqual(once, twice)
        self.assertIn("xwt_debug=", once)
        self.assertIn('extra_My_Game="uda:/xwt/boot/My Game.elf"', once)
        self.assertEqual(once.count(xwt_kboot.BEGIN), 1)
        package_linux_usb.validate_kboot(once.encode("ascii"))

    def test_entries_over_the_xell_limit_are_skipped(self) -> None:
        usb = Path(tempfile.mkdtemp())
        deep = usb / "xwt/boot" / ("d" * 150)
        deep.mkdir(parents=True)
        (deep / ("e" * 120 + ".elf")).write_bytes(b"x")
        self.assertEqual(xwt_kboot.scan(usb), [])


if __name__ == "__main__":
    unittest.main(verbosity=2)
