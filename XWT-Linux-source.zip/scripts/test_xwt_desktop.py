#!/usr/bin/env python3
from pathlib import Path
import unittest
ROOT=Path(__file__).resolve().parents[1]
class DesktopTests(unittest.TestCase):
    def test_desktop_is_compiled_as_part_of_rootfs(self):
        s=(ROOT/"linux/post-build.sh").read_text()
        self.assertIn("xwt-desktop.c",s)
        self.assertIn("SDL_ttf",s)
        self.assertIn("xwt-gamepad-keys.c",s)
    def test_desktop_checks_real_framebuffer_before_sdl(self):
        s=(ROOT/"linux/src/xwt-desktop.c").read_text()
        for token in ("FBIOGET_VSCREENINFO","FBIOGET_FSCREENINFO","/dev/fb0","line_length","smem_len","SDL_VIDEODRIVER", "SDL_SetVideoMode"):
            self.assertIn(token,s)
        self.assertNotIn("if (screen_w < 480) screen_w = 480",s)
        self.assertNotIn("if (screen_h < 360) screen_h = 360",s)
    def test_menu_prefers_gui_but_falls_back_to_text(self):
        s=(ROOT/"linux/overlay/usr/sbin/xwt-system-menu").read_text()
        self.assertIn("xwt-desktop",s)
        self.assertIn("xwt-system-menu-text",s)
    def test_video_diagnostic_runs_at_boot(self):
        s=(ROOT/"linux/overlay/etc/init.d/S18video").read_text()
        self.assertIn("xwt-video-check --boot",s)
    def test_desktop_redraws_only_when_needed(self):
        s=(ROOT/"linux/src/xwt-desktop.c").read_text()
        for token in ("need_redraw","STATUS_REFRESH_MS","refresh_status","draw_text_clip","read_hwmon_temp_c"):
            self.assertIn(token,s)
        # status helpers (network, clock) must not run inside the per-frame draw path
        base=s[s.index("static void draw_base("):s.index("static int app_columns(")]
        self.assertNotIn("network_summary(",base)
        self.assertNotIn("getifaddrs",base)
    def test_every_app_card_has_a_launcher(self):
        s=(ROOT/"linux/src/xwt-desktop.c").read_text()
        import re
        count=int(re.search(r"#define APP_COUNT (\d+)",s).group(1))
        for index in range(count):
            self.assertIn(f"case {index}:",s)
    def test_desktop_has_icons_taskbar_and_settings_window(self):
        s=(ROOT/"linux/src/xwt-desktop.c").read_text()
        for token in ("DeskIcon","draw_taskbar","draw_wallpaper","draw_icon","draw_settings","PAGE_SETTINGS","Configurações","Navegador","Jogos","Terminal","Desligar","Ajuda","XWT_VERSION_TEXT"):
            self.assertIn(token,s)
        for name in ("Sistema","Rede","Vídeo","Áudio","Controle","Armazenamento","Sobre"):
            self.assertIn('"%s"'%name,s)
        self.assertNotIn("PAGE_SYSTEM",s)
    def test_zram_and_timezone_are_configured(self):
        zram=(ROOT/"linux/overlay/etc/init.d/S05zram").read_text()
        for token in ("/sys/block/zram0/disksize","mkswap","swapon"):
            self.assertIn(token,zram)
        self.assertIn("TZ=",(ROOT/"linux/overlay/etc/profile.d/xwt-tz.sh").read_text())
        self.assertIn("xwt-tz.sh",(ROOT/"linux/overlay/usr/sbin/xwt-system-menu").read_text())
