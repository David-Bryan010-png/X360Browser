#!/usr/bin/env python3
from pathlib import Path
import unittest
ROOT=Path(__file__).resolve().parents[1]
class DesktopTests(unittest.TestCase):
    def test_desktop_is_compiled_as_part_of_rootfs(self):
        s=(ROOT/"linux/post-build.sh").read_text()
        self.assertIn("xwt-desktop.c",s)
        self.assertIn("SDL_ttf",s)
        self.assertIn("xwt-gamepad-keys.c",s)
    def test_desktop_checks_real_framebuffer_before_sdl(self):
        s=(ROOT/"linux/src/xwt-desktop.c").read_text()
        for token in ("FBIOGET_VSCREENINFO","FBIOGET_FSCREENINFO","/dev/fb0","line_length","smem_len","SDL_VIDEODRIVER", "SDL_SetVideoMode"):
            self.assertIn(token,s)
        self.assertNotIn("if (screen_w < 480) screen_w = 480",s)
        self.assertNotIn("if (screen_h < 360) screen_h = 360",s)
    def test_menu_prefers_gui_but_falls_back_to_text(self):
        s=(ROOT/"linux/overlay/usr/sbin/xwt-system-menu").read_text()
        self.assertIn("xwt-desktop",s)
        self.assertIn("xwt-system-menu-text",s)
    def test_video_diagnostic_runs_at_boot(self):
        s=(ROOT/"linux/overlay/etc/init.d/S18video").read_text()
        self.assertIn("xwt-video-check --boot",s)
