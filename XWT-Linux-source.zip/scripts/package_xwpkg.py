#!/usr/bin/env python3
"""Build/verify a small tar.gz-based .xwpkg module for XWT Linux minimal core."""
from __future__ import annotations
import argparse
import hashlib
import io
import re
import tarfile
from pathlib import Path, PurePosixPath

MAGIC = "format=xwt-xwpkg-v1"
PREFIX = "opt/xwt/modules/"


def safe_component(value: str) -> str:
    if not re.fullmatch(r"[a-z0-9][a-z0-9_-]{0,31}", value):
        raise ValueError(f"invalid component: {value!r}")
    return value


def safe_path(name: str, component: str) -> str:
    p = PurePosixPath(name)
    if not name or p.is_absolute() or ".." in p.parts or "\\" in name or "\x00" in name:
        raise ValueError(f"unsafe path: {name!r}")
    allowed = f"{PREFIX}{component}/"
    if not name.startswith(allowed):
        raise ValueError(f"path outside component tree: {name}")
    if any(part in ("", ".") for part in p.parts):
        raise ValueError(f"non-canonical path: {name}")
    if not re.fullmatch(r"[A-Za-z0-9._/-]+", name):
        raise ValueError(f"path contains characters unsupported by the target updater: {name!r}")
    return p.as_posix()


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def build(payload: Path, output: Path, component: str, version: str) -> dict:
    component = safe_component(component)
    if not re.fullmatch(r"[0-9A-Za-z.+_-]{1,48}", version):
        raise ValueError("invalid version")
    if not payload.is_dir():
        raise FileNotFoundError(payload)
    files = []
    total = 0
    for source in sorted(payload.rglob("*")):
        if source.is_symlink():
            raise ValueError(f"symlinks are forbidden: {source}")
        if not source.is_file():
            continue
        rel = safe_path(source.relative_to(payload).as_posix(), component)
        data = source.read_bytes()
        if not data or len(data) > 16 * 1024 * 1024:
            raise ValueError(f"invalid file size: {rel}")
        total += len(data)
        if total > 64 * 1024 * 1024:
            raise ValueError("module exceeds 64 MiB")
        files.append((rel, data, 0o755 if source.stat().st_mode & 0o111 else 0o644))
    if not files:
        raise ValueError("empty module")
    meta = "\n".join((MAGIC, "schema=1", f"component={component}", f"version={version}",
                       "architecture=powerpc64-be", "abi=glibc", "kind=module", ""))
    output.parent.mkdir(parents=True, exist_ok=True)
    with tarfile.open(output, "w:gz", compresslevel=6) as archive:
        raw = meta.encode()
        info = tarfile.TarInfo("META.txt")
        info.size = len(raw); info.mode = 0o644; info.mtime = 0
        archive.addfile(info, io.BytesIO(raw))
        for name, data, mode in files:
            info = tarfile.TarInfo("payload/" + name)
            info.size = len(data); info.mode = mode; info.mtime = 0
            archive.addfile(info, io.BytesIO(data))
    result = verify(output, expected_component=component)
    result["sha256"] = sha256(output.read_bytes())
    result["size"] = output.stat().st_size
    return result


def verify(path: Path, expected_component: str | None = None) -> dict:
    with tarfile.open(path, "r:gz") as archive:
        members = archive.getmembers()
        names = [m.name for m in members]
        if len(names) != len(set(names)) or "META.txt" not in names:
            raise ValueError("duplicate entries or missing META.txt")
        meta_data = archive.extractfile("META.txt")
        if meta_data is None:
            raise ValueError("META.txt is not a regular file")
        meta = dict(line.split("=", 1) for line in meta_data.read().decode().splitlines() if "=" in line)
        if meta.get("format") != "xwt-xwpkg-v1" or meta.get("schema") != "1" or meta.get("kind") != "module":
            raise ValueError("unsupported package metadata")
        if meta.get("architecture") != "powerpc64-be" or meta.get("abi") != "glibc":
            raise ValueError("package architecture or ABI mismatch")
        if not re.fullmatch(r"[0-9A-Za-z.+_-]{1,48}", meta.get("version", "")):
            raise ValueError("invalid package version metadata")
        component = safe_component(meta.get("component", ""))
        if expected_component and component != expected_component:
            raise ValueError("component mismatch")
        files = []
        for member in members:
            if member.name == "META.txt":
                if not member.isfile(): raise ValueError("META.txt must be a regular file")
                continue
            if not member.isfile(): raise ValueError(f"non-regular package member: {member.name}")
            name = member.name.removeprefix("payload/") if member.name.startswith("payload/") else ""
            safe_path(name, component)
            stream = archive.extractfile(member)
            if stream is None: raise ValueError(f"cannot read: {member.name}")
            data = stream.read()
            if len(data) != member.size: raise ValueError(f"size mismatch: {member.name}")
            if member.mode not in (0o644, 0o755): raise ValueError(f"invalid mode: {member.name}")
            files.append({"path": name, "size": len(data), "sha256": sha256(data), "mode": member.mode})
        if not files:
            raise ValueError("package has no files")
        return {"component": component, "version": meta.get("version", ""), "kind": "module", "files": files}


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--payload", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--component", required=True)
    parser.add_argument("--version", required=True)
    args = parser.parse_args()
    print(build(args.payload, args.output, args.component, args.version))
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
