#!/usr/bin/env python3
from __future__ import annotations

import gzip
import hashlib
import importlib.util
import stat
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(Path(__file__).resolve().parent))
import split_rootfs as sr  # noqa: E402

spec = importlib.util.spec_from_file_location("preflight", ROOT / "tools/xwt-preflight.py")
pf = importlib.util.module_from_spec(spec)
spec.loader.exec_module(pf)


def build_stick(root: Path, initrd_names=None, bad_pack=False):
    tree = root.parent / (root.name + "-tree")
    for rel in pf.NEEDED_IN_STAGE1:
        if rel == "dev/console":
            continue
        p = tree / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text("x")
    (tree / "sbin").mkdir(exist_ok=True)
    (tree / "sbin/init").symlink_to("../bin/busybox")
    names = [p.relative_to(tree).as_posix() for p in sorted(tree.rglob("*"))]
    cpio = gzip.compress(sr.build_cpio(tree, names, []))
    lin = root / "xwt"
    (lin / "packs").mkdir(parents=True)
    (root / "initrd.img").write_bytes(cpio)
    (root / "vmlinux").write_bytes(b"\x7fELF\x01\x02\x01" + b"\0" * 9 + b"\x00\x02\x00\x14" + b"\0" * 60)
    (root / "default.xex").write_bytes(b"XEX2" + b"\0" * 16)
    (root / "kboot.conf").write_text('#KBOOTCONFIG\ntimeout=0\ndefault=a\na="uda:/vmlinux initrd=uda:/initrd.img"\n')
    pack = b"squash"
    (lin / "packs/xwt-pack-01.sqfs").write_bytes(pack)
    digest = "0" * 64 if bad_pack else hashlib.sha256(pack).hexdigest()
    (lin / "packs/packs.list").write_text(f"{digest}  xwt-pack-01.sqfs  {len(pack)}\n")
    (lin / "packs/overlays.list").write_text("usr/share\n")


class PreflightTests(unittest.TestCase):
    def test_good_stick_passes(self):
        d = Path(tempfile.mkdtemp()) / "stick"
        build_stick(d)
        res = pf.check(pf.Source(d))
        self.assertEqual([r for r in res if not r[0]], [])

    def test_corrupt_pack_detected(self):
        d = Path(tempfile.mkdtemp()) / "stick"
        build_stick(d, bad_pack=True)
        bad = [r[1] for r in pf.check(pf.Source(d)) if not r[0]]
        self.assertTrue(any("xwt-pack-01" in b for b in bad))

    def test_missing_files_stop_early(self):
        d = Path(tempfile.mkdtemp())
        self.assertTrue(any(not r[0] for r in pf.check(pf.Source(d))))

    def test_oversized_initrd_detected(self):
        d = Path(tempfile.mkdtemp()) / "stick"
        build_stick(d)
        old = pf.XELL_INITRD_MAX
        pf.XELL_INITRD_MAX = 10
        try:
            self.assertTrue(any(not r[0] and "32 MiB" in r[1] for r in pf.check(pf.Source(d))))
        finally:
            pf.XELL_INITRD_MAX = old


if __name__ == "__main__":
    unittest.main()
