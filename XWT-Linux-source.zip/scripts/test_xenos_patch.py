#!/usr/bin/env python3
"""Safety tests for the guarded Xenos source transformation."""
from __future__ import annotations

import unittest

try:
    from .xenos_patchlib import MARKER, patch_driver_source
except ImportError:
    from xenos_patchlib import MARKER, patch_driver_source


FIXTURE = '''#include <linux/aperture.h>
#include <linux/iosys-map.h>
struct xenos_fb { dma_addr_t dma_addr; void *vaddr; size_t size; };
struct fake { int unused; };
static void xenos_enable(struct drm_simple_display_pipe *pipe,
                         struct drm_crtc_state *crtc_state,
                         struct drm_plane_state *plane_state)
{
    struct xenos_device *xenos = xenos_of_pipe(pipe);
    if (crtc_state->planes_changed || IS_ERR_OR_NULL(xenos->real_framebuffer.vaddr)) {
        int width = plane_state->fb->width;
        int height = plane_state->fb->height;
        int bpp = drm_format_info_bpp(plane_state->fb->format, 0);
        int cpp = DIV_ROUND_UP(bpp, 8);
        if (!IS_ERR_OR_NULL(xenos->real_framebuffer.vaddr))
            dma_free_coherent(xenos->dev.dev, xenos->real_framebuffer.size,
                              xenos->real_framebuffer.vaddr,
                              xenos->real_framebuffer.dma_addr);
        xenos->real_framebuffer.size = width * height * cpp;
        xenos->real_framebuffer.vaddr = dma_alloc_coherent(
            xenos->dev.dev, xenos->real_framebuffer.size,
            &xenos->real_framebuffer.dma_addr, 0);
        drm_info(&xenos->dev, "Using %dx%d fb\\n", width, height);
        iowrite32be(xenos->real_framebuffer.dma_addr,
                    xenos->regs + D1GRPH_PRIMARY_SURFACE_ADDRESS);
    }
    iowrite32be(1, xenos->regs + D1GRPH_ENABLE);
}
static void xenos_disable(struct drm_simple_display_pipe *pipe)
{
    struct xenos_device *xenos = xenos_of_pipe(pipe);
    iowrite32be(0, xenos->regs + D1GRPH_ENABLE);
    dma_free_coherent(xenos->dev.dev, xenos->real_framebuffer.size,
                      xenos->real_framebuffer.vaddr,
                      xenos->real_framebuffer.dma_addr);
    xenos->real_framebuffer.vaddr = NULL;
}
static void xenos_blit(struct iosys_map dst, struct iosys_map src,
                       struct drm_rect src_rect, struct drm_framebuffer *fb)
{
    for (int y = src_rect.y1; y < src_rect.y2; y++) {
        for (int x = src_rect.x1 & ~3; x < src_rect.x2; x += 4) {
            int ndx = ((((y & ~31) * fb->width) + (x & ~31) * 32) +
                       (((x & 3) + ((y & 1) << 2) +
                         ((x & 28) << 1) + ((y & 30) << 5)) ^
                        ((y & 8) << 2)));
            u32 *dst32 = dst.vaddr + ndx * 4;
            const u32 *src32 = src.vaddr + x * 4 + y * fb->pitches[0];
            *dst32++ = swab32(*src32++);
            *dst32++ = swab32(*src32++);
            *dst32++ = swab32(*src32++);
            *dst32++ = swab32(*src32++);
        }
    }
}
static void xenos_update(struct drm_simple_display_pipe *pipe,
                         struct drm_plane_state *old_state)
{
    struct xenos_device *xenos = xenos_of_pipe(pipe);
    struct drm_device *dev = &xenos->dev;
    struct drm_framebuffer *fb = state->fb;
    int idx;
    struct drm_shadow_plane_state *shadow_plane_state = state;
    struct iosys_map src = shadow_plane_state->data[0];
    if (IS_ERR_OR_NULL(xenos->real_framebuffer.vaddr))
        return;
    xenos_blit(dst, src, damage, fb);
    dma_sync_single_for_device(dev->dev, xenos->real_framebuffer.dma_addr,
                               xenos->real_framebuffer.size, DMA_TO_DEVICE);
}
static const struct drm_simple_display_pipe_funcs xenos_pipe_funcs = { 0 };
static int xenos_pci_probe(struct pci_dev *pdev,
                           const struct pci_device_id *ent)
{
    int ret;
    ret = pcim_enable_device(pdev);
    if (ret)
        return ret;

    ret = pci_request_regions(pdev, DRIVER_NAME);
    if (ret)
        return ret;
    return 0;
}
static int xenos_load(struct xenos_device *xenos)
{
    struct drm_device *dev = &xenos->dev;
    uint32_t fb_width = ioread32be(xenos->regs + D1GRPH_X_END);
    uint32_t fb_height = ioread32be(xenos->regs + D1GRPH_Y_END);
    uint32_t is_progressive = ioread32be(xenos-> regs + AVIVO_D1MODE_DATA_FORMAT);
    if (is_progressive)
        fb_height = fb_height / 2;
    return 0;
}
'''


class XenosPatchTests(unittest.TestCase):
    def test_correct_patch_contains_guardrails(self) -> None:
        patched = patch_driver_source(FIXTURE)
        self.assertIn(MARKER, patched)
        self.assertIn("ALIGN((size_t)width, 32)", patched)
        self.assertIn("ALIGN((size_t)height, 32)", patched)
        self.assertIn("if (!next.vaddr)", patched)
        self.assertIn("lower_32_bits(next.dma_addr)", patched)
        self.assertIn("upper_32_bits(next.dma_addr)", patched)
        self.assertIn("dma_set_mask_and_coherent(&pdev->dev, DMA_BIT_MASK(32))", patched)
        self.assertIn("GFP_KERNEL", patched)
        self.assertIn("xenos_blit(dst_map, shadow_state->data[0], full_frame,", patched)
        self.assertIn("struct drm_shadow_plane_state *shadow_state", patched)
        self.assertIn("dst32[ndx] = swab32(src32[x]);", patched)
        self.assertIn("dst_clip", patched)
        self.assertIn("required_size > xenos->real_framebuffer.size", patched)
        self.assertIn("DRM_FORMAT_XRGB8888", patched)
        self.assertIn("dma_wmb();", patched)
        self.assertNotIn("dma_sync_single_for_device", patched)

    def test_patch_is_idempotent(self) -> None:
        once = patch_driver_source(FIXTURE)
        self.assertEqual(patch_driver_source(once), once)

    def test_unknown_source_is_rejected(self) -> None:
        with self.assertRaises(ValueError):
            patch_driver_source("int unrelated_source;\n")


if __name__ == "__main__":
    unittest.main(verbosity=2)
