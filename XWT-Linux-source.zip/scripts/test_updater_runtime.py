#!/usr/bin/env python3
"""Host integration test for install, persistence and rollback of .xwpkg."""
from __future__ import annotations
import hashlib
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import unittest

import package_xwpkg

ROOT = Path(__file__).resolve().parents[1]
UPDATER = ROOT / "linux/overlay/usr/sbin/xwt-update"

class UpdaterRuntimeTests(unittest.TestCase):
    @unittest.skipUnless(shutil.which("curl") and shutil.which("tar") and shutil.which("sha256sum"),
                         "curl/tar/sha256sum required")
    def test_upgrade_rollback_and_replay_survive_restart(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            env = os.environ.copy()
            shell = ["/bin/sh"]
            busybox = shutil.which("busybox")
            if busybox:
                applets = root / "busybox-bin"; applets.mkdir()
                subprocess.run([busybox, "--install", "-s", str(applets)], check=True,
                               stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                env["PATH"] = str(applets) + os.pathsep + env.get("PATH", "")
                shell = [busybox, "ash"]
            assets = root / "assets"; assets.mkdir()
            usb = root / "usb"; usb.mkdir()
            modules = root / "modules"
            script = root / "xwt-update"
            source = UPDATER.read_text()
            source = source.replace("CHANNEL_URL=\"https://github.com/$REPOSITORY/releases/download/$CHANNEL_TAG/latest.tsv\"",
                                    f'CHANNEL_URL="file://{assets}/latest.tsv"')
            source = source.replace("ASSET_PREFIX=\"https://github.com/$REPOSITORY/releases/download/$CHANNEL_TAG/\"",
                                    f'ASSET_PREFIX="file://{assets}/"')
            source = source.replace("USB='/mnt/xwt-usb'", f"USB='{usb}'")
            source = source.replace("MODULES='/opt/xwt/modules'", f"MODULES='{modules}'")
            source = source.replace('grep -qs " $USB " /proc/mounts || fail \'USB XWT nao esta montado\'',
                                    ': # mount check skipped in isolated host test')
            script.write_text(source); script.chmod(0o755)

            def publish(version: str, message: str) -> None:
                payload = root / f"payload-{version}" / "opt/xwt/modules/system/bin"
                payload.mkdir(parents=True)
                tool = payload / "xwt-status"
                tool.write_text(f"#!/bin/sh\necho {message}\n")
                tool.chmod(0o755)
                package = assets / "system.xwpkg"
                package_xwpkg.build(payload.parents[4], package, "system", version)
                digest = hashlib.sha256(package.read_bytes()).hexdigest()
                (assets / "latest.tsv").write_text(
                    f"XWT-UPDATES-V1\nsystem|{version}|{digest}|file://{package}\n"
                )

            def run(*args: str) -> subprocess.CompletedProcess[str]:
                return subprocess.run([*shell, str(script), *args], text=True, env=env,
                                      stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                      check=True, timeout=30)

            publish("1.0.0", "version-one")
            run("install", "system")
            installed = modules / "system/bin/xwt-status"
            self.assertIn("version-one", installed.read_text())

            publish("2.0.0", "version-two")
            run("install", "system")
            self.assertIn("version-two", installed.read_text())
            run("rollback", "system")
            self.assertIn("version-one", installed.read_text())

            # A fresh process simulates the next boot applying the saved package.
            shutil.rmtree(modules / "system")
            run("apply")
            self.assertIn("version-one", installed.read_text())

    @unittest.skipUnless(shutil.which("curl") and shutil.which("tar") and shutil.which("sha256sum"),
                         "curl/tar/sha256sum required")
    def test_rollback_of_first_install_removes_module_and_saved_package(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            env = os.environ.copy()
            shell = ["/bin/sh"]
            busybox = shutil.which("busybox")
            if busybox:
                applets = root / "busybox-bin"; applets.mkdir()
                subprocess.run([busybox, "--install", "-s", str(applets)], check=True,
                               stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                env["PATH"] = str(applets) + os.pathsep + env.get("PATH", "")
                shell = [busybox, "ash"]
            assets = root / "assets"; assets.mkdir()
            usb = root / "usb"; usb.mkdir(); modules = root / "modules"
            script = root / "xwt-update"
            source = UPDATER.read_text()
            source = source.replace("CHANNEL_URL=\"https://github.com/$REPOSITORY/releases/download/$CHANNEL_TAG/latest.tsv\"",
                                    f'CHANNEL_URL="file://{assets}/latest.tsv"')
            source = source.replace("ASSET_PREFIX=\"https://github.com/$REPOSITORY/releases/download/$CHANNEL_TAG/\"",
                                    f'ASSET_PREFIX="file://{assets}/"')
            source = source.replace("USB='/mnt/xwt-usb'", f"USB='{usb}'")
            source = source.replace("MODULES='/opt/xwt/modules'", f"MODULES='{modules}'")
            source = source.replace('grep -qs " $USB " /proc/mounts || fail \'USB XWT nao esta montado\'',
                                    ': # mount check skipped in isolated host test')
            script.write_text(source); script.chmod(0o755)
            payload = root / "payload" / "opt/xwt/modules/system/bin"; payload.mkdir(parents=True)
            tool = payload / "xwt-status"; tool.write_text('#!/bin/sh\necho new\n'); tool.chmod(0o755)
            package = assets / "system.xwpkg"
            package_xwpkg.build(payload.parents[4], package, "system", "1.0.0")
            digest = hashlib.sha256(package.read_bytes()).hexdigest()
            (assets / "latest.tsv").write_text(f"XWT-UPDATES-V1\nsystem|1.0.0|{digest}|file://{package}\n")
            subprocess.run([*shell, str(script), "install", "system"], env=env, check=True,
                           stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=30)
            subprocess.run([*shell, str(script), "rollback", "system"], env=env, check=True,
                           stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=30)
            self.assertFalse((modules / "system").exists())
            self.assertFalse((usb / "X360WebTotal/Updates/packages/system.xwpkg").exists())

    @unittest.skipUnless(shutil.which("curl") and shutil.which("tar") and shutil.which("sha256sum"),
                         "curl/tar/sha256sum required")
    def test_runtime_rejects_package_for_another_architecture(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); env=os.environ.copy(); shell=["/bin/sh"]
            busybox=shutil.which("busybox")
            if busybox:
                applets=root/"busybox-bin"; applets.mkdir()
                subprocess.run([busybox,"--install","-s",str(applets)],check=True,
                               stdout=subprocess.PIPE,stderr=subprocess.PIPE)
                env["PATH"]=str(applets)+os.pathsep+env.get("PATH",""); shell=[busybox,"ash"]
            assets=root/"assets"; assets.mkdir(); usb=root/"usb"; usb.mkdir()
            script=root/"xwt-update"; modules=root/"modules"
            source=UPDATER.read_text()
            source=source.replace("CHANNEL_URL=\"https://github.com/$REPOSITORY/releases/download/$CHANNEL_TAG/latest.tsv\"",
                                  f'CHANNEL_URL="file://{assets}/latest.tsv"')
            source=source.replace("ASSET_PREFIX=\"https://github.com/$REPOSITORY/releases/download/$CHANNEL_TAG/\"",
                                  f'ASSET_PREFIX="file://{assets}/"')
            source=source.replace("USB='/mnt/xwt-usb'",f"USB='{usb}'")
            source=source.replace("MODULES='/opt/xwt/modules'",f"MODULES='{modules}'")
            source=source.replace("grep -qs \" $USB \" /proc/mounts || fail 'USB XWT nao esta montado'",
                                  ': # mount check skipped in isolated host test')
            script.write_text(source); script.chmod(0o755)
            payload=root/"payload"/"opt/xwt/modules/system/bin"; payload.mkdir(parents=True)
            status=payload/"xwt-status"; status.write_text("#!/bin/sh\necho invalid\n"); status.chmod(0o755)
            package=assets/"system.xwpkg"
            package_xwpkg.build(payload.parents[4],package,"system","1.0.0")
            import tarfile,io
            with tarfile.open(package,"r:gz") as src:
                members=src.getmembers()
                contents={m.name:src.extractfile(m).read() for m in members if m.isfile()}
            contents["META.txt"]=contents["META.txt"].replace(b"architecture=powerpc64-be",b"architecture=x86_64")
            with tarfile.open(package,"w:gz") as dst:
                for name,data in contents.items():
                    info=tarfile.TarInfo(name); info.size=len(data); info.mode=0o644
                    dst.addfile(info,io.BytesIO(data))
            digest=hashlib.sha256(package.read_bytes()).hexdigest()
            (assets/"latest.tsv").write_text(f"XWT-UPDATES-V1\nsystem|1.0.0|{digest}|file://{package}\n")
            result=subprocess.run([*shell,str(script),"install","system"],env=env,text=True,
                                  stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=30)
            self.assertNotEqual(result.returncode,0)
            self.assertIn("arquitetura do pacote incompatível",result.stdout)
            self.assertFalse((modules/"system").exists())

if __name__ == "__main__":
    unittest.main(verbosity=2)
