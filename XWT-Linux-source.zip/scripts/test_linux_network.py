#!/usr/bin/env python3
"""Tests for the minimal wired-network boot path."""
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
OVERLAY = ROOT / "linux/overlay"

class MinimalNetworkTests(unittest.TestCase):
    def test_wired_service_uses_dhcp_and_does_not_fake_an_address(self):
        source = (OVERLAY / "etc/init.d/S40network").read_text()
        self.assertIn("udhcpc -i", source)
        self.assertNotIn("192.168.1.99", source)
        self.assertNotIn("ip addr add", source)

    def test_network_diagnostic_uses_real_interfaces_routes_and_dns(self):
        source = (OVERLAY / "usr/sbin/xwt-network").read_text()
        for token in ("ip link", "ip -brief address", "ip route", "/etc/resolv.conf", "udhcpc"):
            self.assertIn(token, source)

    def test_kernel_module_loader_is_initialized_before_services(self):
        inittab = (OVERLAY / "etc/inittab").read_text()
        self.assertLess(inittab.index("devtmpfs devtmpfs /dev"), inittab.index("devpts devpts /dev/pts"))
        self.assertLess(inittab.index("devpts devpts /dev/pts"), inittab.index("/sbin/mdev -s"))
        self.assertLess(inittab.index("/sbin/mdev -s"), inittab.index("/etc/init.d/rcS"))
        self.assertIn("/proc/sys/kernel/hotplug", inittab)
        self.assertIn('@modprobe "$MODALIAS"', (OVERLAY / "etc/mdev.conf").read_text())

    def test_usb_boot_storage_is_mounted_and_modules_replayed(self):
        source = (OVERLAY / "etc/init.d/S30storage").read_text()
        for token in ("/dev/sd[a-z]1", "-t vfat", "kboot.conf", "X360WebTotal/Linux", "xwt-update apply"):
            self.assertIn(token, source)
        self.assertIn("/mnt/xwt-usb", source)
        self.assertNotIn("nand_write", source.lower())

    def test_no_large_optional_components_enter_base_configuration(self):
        config = (ROOT / "linux/buildroot.config").read_text()
        for token in ("BR2_PACKAGE_NETSURF=y", "BR2_PACKAGE_SDL=y", "BR2_PACKAGE_PYTHON3=y",
                      "BR2_PACKAGE_ALSA=y", "BR2_PACKAGE_WPA_SUPPLICANT=y", "BR2_PACKAGE_LINUX_FIRMWARE=y"):
            self.assertNotIn(token, config)
        self.assertIn("BR2_PACKAGE_LIBCURL_CURL=y", config)
        self.assertIn("BR2_PACKAGE_CA_CERTIFICATES=y", config)

    def test_gamepad_driver_module_support_is_loaded_when_present(self):
        source = (OVERLAY / "etc/init.d/S15gamepad").read_text()
        for module in ("xpad", "joydev", "uinput"):
            self.assertIn(f"modprobe {module}", source)

    def test_boot_menu_provides_terminal_and_module_management(self):
        menu = (OVERLAY / "usr/sbin/xwt-system-menu-text").read_text()
        for command in ("xwt-update list", "xwt-update install system", "/bin/sh -l", "reboot", "poweroff"):
            self.assertIn(command, menu)

if __name__ == "__main__":
    unittest.main(verbosity=2)
