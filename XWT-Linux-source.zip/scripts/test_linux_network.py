#!/usr/bin/env python3
"""Tests for the minimal wired-network boot path."""
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
OVERLAY = ROOT / "linux/overlay"

class MinimalNetworkTests(unittest.TestCase):
    def test_wired_service_uses_dhcp_and_does_not_fake_an_address(self):
        source = (OVERLAY / "etc/init.d/S40network").read_text()
        self.assertIn("udhcpc -i", source)
        self.assertNotIn("192.168.1.99", source)
        self.assertNotIn("ip addr add", source)

    def test_network_diagnostic_uses_real_interfaces_routes_and_dns(self):
        source = (OVERLAY / "usr/sbin/xwt-network").read_text()
        for token in ("ip link", "ip -brief address", "ip route", "/etc/resolv.conf", "udhcpc"):
            self.assertIn(token, source)

    def test_kernel_module_loader_is_initialized_before_services(self):
        inittab = (OVERLAY / "etc/inittab").read_text()
        self.assertLess(inittab.index("devtmpfs devtmpfs /dev"), inittab.index("devpts devpts /dev/pts"))
        self.assertLess(inittab.index("devpts devpts /dev/pts"), inittab.index("/sbin/mdev -s"))
        self.assertLess(inittab.index("/sbin/mdev -s"), inittab.index("/etc/init.d/rcS"))
        self.assertIn("/proc/sys/kernel/hotplug", inittab)
        self.assertIn('@modprobe -b "$MODALIAS"', (OVERLAY / "etc/mdev.conf").read_text())
        coldplug = (OVERLAY / "etc/init.d/S10modules").read_text()
        self.assertIn("/sys/devices", coldplug)
        self.assertIn("modprobe -b", coldplug)

    def test_usb_boot_storage_is_mounted_and_modules_replayed(self):
        source = (OVERLAY / "etc/init.d/S30storage").read_text()
        tool = (OVERLAY / "usr/sbin/xwt-storage").read_text()
        for token in ("xwt-storage boot", "xwt-update apply", "/mnt/xwt-usb"):
            self.assertIn(token, source)
        for token in ("vfat", "exfat", "kboot.conf", "xwt"):
            self.assertIn(token, tool)
        self.assertNotIn("nand_write", source.lower())

    def test_015_installs_only_the_selected_desktop_and_network_runtime(self):
        config = (ROOT / "linux/buildroot.config").read_text()
        for token in ("BR2_PACKAGE_SDL=y", "BR2_PACKAGE_SDL_FBCON=y", "BR2_PACKAGE_SDL_TTF=y",
                      "BR2_PACKAGE_DEJAVU=y", "BR2_PACKAGE_DIALOG=y", "BR2_PACKAGE_IW=y",
                      "BR2_PACKAGE_WPA_SUPPLICANT=y", "BR2_PACKAGE_ALSA_UTILS=y"):
            self.assertIn(token, config)
        for token in ("BR2_PACKAGE_NETSURF=y", "BR2_PACKAGE_PYTHON3=y"):
            self.assertNotIn(token, config)
        self.assertIn("BR2_PACKAGE_LIBCURL_CURL=y", config)
        self.assertIn("BR2_PACKAGE_CA_CERTIFICATES=y", config)

    def test_gamepad_driver_module_support_is_loaded_when_present(self):
        source = (OVERLAY / "etc/init.d/S15gamepad").read_text()
        for module in ("xpad", "joydev", "uinput"):
            self.assertIn(f"load_module {module}", source)

    def test_boot_menu_provides_terminal_and_module_management(self):
        menu = (OVERLAY / "usr/sbin/xwt-system-menu-text").read_text()
        for command in ("xwt-update list", "xwt-update install system", "/bin/sh -l", "reboot", "poweroff"):
            self.assertIn(command, menu)

if __name__ == "__main__":
    unittest.main(verbosity=2)


class FirmwareScopeTests(unittest.TestCase):
    def test_only_selected_wifi_firmware_is_enabled(self):
        text = (OVERLAY.parent / "buildroot.config").read_text()
        selected = [l for l in text.splitlines() if l.startswith("BR2_PACKAGE_LINUX_FIRMWARE_")]
        self.assertTrue(selected)
        allowed = ("RALINK", "MEDIATEK", "RTL_81XX")
        for line in selected:
            self.assertTrue(any(a in line for a in allowed), line)
