#!/usr/bin/env python3
"""xwt-audio / xwt-video against fake /proc and /sys trees."""
from __future__ import annotations

import os
import subprocess
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
AUDIO = ROOT / "linux/overlay/usr/sbin/xwt-audio"
VIDEO = ROOT / "linux/overlay/usr/sbin/xwt-video"


class AudioTests(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        (self.tmp / "proc/asound").mkdir(parents=True)
        (self.tmp / "run").mkdir()
        (self.tmp / "bin").mkdir()
        (self.tmp / "bin/amixer").write_text('#!/bin/sh\necho "$@" >> "$XWT_RUN/amixer.log"\n')
        (self.tmp / "bin/amixer").chmod(0o755)
        self.env = dict(os.environ, PATH=f"{self.tmp/'bin'}:{os.environ['PATH']}", XWT_PROC=str(self.tmp / "proc"),
                        XWT_RUN=str(self.tmp / "run"), XWT_ASOUND_CONF=str(self.tmp / "asound.conf"))

    def run_cmd(self, script, *a):
        return subprocess.run(["sh", str(script), *a], env=self.env, capture_output=True, text=True)

    def test_no_card(self):
        (self.tmp / "proc/asound/cards").write_text("--- no soundcards ---\n")
        r = self.run_cmd(AUDIO, "init")
        self.assertNotEqual(r.returncode, 0)
        self.assertIn("XWT_AUDIO=none", (self.tmp / "run/xwt-audio.env").read_text())

    def test_prefers_usb_card(self):
        (self.tmp / "proc/asound/cards").write_text(" 0 [Dummy ]: Dummy - Dummy\n 1 [Device ]: USB-Audio - USB Audio Device\n")
        r = self.run_cmd(AUDIO, "init")
        self.assertEqual(r.returncode, 0, r.stderr)
        self.assertIn("defaults.pcm.card 1", (self.tmp / "asound.conf").read_text())
        self.assertIn("-c 1", (self.tmp / "run/amixer.log").read_text())

    def test_volume_validation(self):
        (self.tmp / "proc/asound/cards").write_text(" 0 [Device ]: USB-Audio - USB Audio Device\n")
        self.assertNotEqual(self.run_cmd(AUDIO, "volume", "abc").returncode, 0)
        self.assertNotEqual(self.run_cmd(AUDIO, "volume", "150").returncode, 0)
        self.assertEqual(self.run_cmd(AUDIO, "volume", "50").returncode, 0)
        self.assertIn("50%", (self.tmp / "run/amixer.log").read_text())

    def test_init_script_and_kernel(self):
        s = (ROOT / "linux/overlay/etc/init.d/S35audio").read_text()
        for token in ("snd-usb-audio", "xwt-audio init", "xwt.safe=1"):
            self.assertIn(token, s)
        self.assertIn("CONFIG_SND_USB_AUDIO", (ROOT / "linux/xwt-kernel.fragment").read_text())
        self.assertIn("ALSA_UTILS_AMIXER=y", (ROOT / "linux/buildroot.config").read_text())


class VideoTests(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        fb = self.tmp / "class/graphics/fb0"
        fb.mkdir(parents=True)
        (fb / "modes").write_text("U:1280x720p-60\nU:640x480p-60\n")
        (fb / "name").write_text("xenosdrmfb\n")
        c = self.tmp / "class/drm/card0-HDMI-A-1"
        c.mkdir(parents=True)
        (c / "status").write_text("connected\n")
        self.env = dict(os.environ, XWT_SYS=str(self.tmp))

    def test_info_lists_outputs(self):
        r = subprocess.run(["sh", str(VIDEO), "info"], env=self.env, capture_output=True, text=True)
        self.assertIn("HDMI-A-1: connected", r.stdout)

    def test_set_valid_and_invalid(self):
        ok = subprocess.run(["sh", str(VIDEO), "set", "U:640x480p-60"], env=self.env, capture_output=True, text=True)
        self.assertEqual(ok.returncode, 0)
        self.assertEqual((self.tmp / "class/graphics/fb0/mode").read_text().strip(), "U:640x480p-60")
        bad = subprocess.run(["sh", str(VIDEO), "set", "U:9999x1p-1"], env=self.env, capture_output=True, text=True)
        self.assertNotEqual(bad.returncode, 0)




class PreviewTests(unittest.TestCase):
    def test_preview_reads_all_apps(self):
        import importlib.util
        spec = importlib.util.spec_from_file_location("xwt_preview", ROOT / "tools/xwt-preview.py")
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        apps = mod.load_apps(ROOT / "linux/src/xwt-desktop.c")
        titles = [a[0] for a in apps]
        self.assertIn("Jogos", titles)
        self.assertIn("Video", titles)
        for t in titles:
            self.assertIn(t, mod.ACTIONS)


class DoctorTests(unittest.TestCase):
    def test_report_is_saved_on_usb(self):
        import subprocess, tempfile
        tmp = Path(tempfile.mkdtemp())
        (tmp / "usb/X360WebTotal").mkdir(parents=True)
        (tmp / "run").mkdir()
        (tmp / "run/xwt-packs.env").write_text("XWT_PACKS=ok\n")
        (tmp / "proc").mkdir()
        (tmp / "proc/cmdline").write_text("console=tty0 xwt.text=1")
        env = dict(os.environ, XWT_USB=str(tmp / "usb"), XWT_RUN=str(tmp / "run"), XWT_PROC=str(tmp / "proc"))
        script = ROOT / "linux/overlay/usr/sbin/xwt-doctor"
        r = subprocess.run(["sh", str(script), "save"], env=env, capture_output=True, text=True)
        self.assertEqual(r.returncode, 0, r.stderr)
        text = (tmp / "usb/X360WebTotal/logs/boot-report.txt").read_text()
        self.assertIn("XWT_PACKS=ok", text)
        self.assertIn("xwt.text=1", text)
        r = subprocess.run(["sh", str(script), "save"], env=dict(env, XWT_USB=str(tmp / "none")), capture_output=True, text=True)
        self.assertNotEqual(r.returncode, 0)


if __name__ == "__main__":
    unittest.main()
