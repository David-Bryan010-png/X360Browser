import tempfile
import unittest
import tarfile
from pathlib import Path
import package_xwpkg as pkg

class XwpkgTests(unittest.TestCase):
    def test_create_and_verify(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp); payload=root/'payload'/'opt/xwt/modules/system/bin'; payload.mkdir(parents=True)
            f=payload/'xwt-status'; f.write_text('#!/bin/sh\necho ok\n'); f.chmod(0o755)
            out=root/'system.xwpkg'
            result=pkg.build(root/'payload',out,'system','0.14.0-alpha.2+test')
            self.assertEqual(result['component'],'system')
            self.assertEqual(pkg.verify(out)['files'][0]['mode'],0o755)
    def test_rejects_traversal(self):
        with self.assertRaises(ValueError): pkg.safe_path('opt/xwt/modules/system/../../etc/passwd','system')
    def test_rejects_other_component(self):
        with self.assertRaises(ValueError): pkg.safe_path('opt/xwt/modules/browser/bin/a','system')
    def test_rejects_symlink(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp); d=root/'opt/xwt/modules/system'; d.mkdir(parents=True)
            target=root/'outside'; target.write_text('no'); (d/'bad').symlink_to(target)
            with self.assertRaises(ValueError): pkg.build(root,root/'bad.xwpkg','system','1')
    def test_rejects_architecture_mismatch(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp); payload=root/'payload'/'opt/xwt/modules/system/bin'; payload.mkdir(parents=True)
            (payload/'xwt-status').write_text('#!/bin/sh\necho ok\n')
            out=root/'system.xwpkg'
            pkg.build(root/'payload',out,'system','1.0.0')
            with tarfile.open(out,'r:gz') as src:
                members=src.getmembers(); contents={m.name:src.extractfile(m).read() for m in members if m.isfile()}
            contents['META.txt']=contents['META.txt'].replace(b'architecture=powerpc64-be',b'architecture=x86_64')
            bad=root/'wrong-arch.xwpkg'
            with tarfile.open(bad,'w:gz') as dst:
                import io
                for name,data in contents.items():
                    info=tarfile.TarInfo(name); info.size=len(data); info.mode=0o644; dst.addfile(info,io.BytesIO(data))
            with self.assertRaisesRegex(ValueError,'architecture or ABI mismatch'):
                pkg.verify(bad)
    def test_rejects_tar_link(self):
        with tempfile.TemporaryDirectory() as temp:
            p=Path(temp)/'evil.xwpkg'
            with tarfile.open(p,'w:gz') as z:
                import io
                data=b'format=xwt-xwpkg-v1\nschema=1\ncomponent=system\nversion=1\nkind=module\n'
                info=tarfile.TarInfo('META.txt'); info.size=len(data); z.addfile(info,io.BytesIO(data))
                link=tarfile.TarInfo('payload/opt/xwt/modules/system/bin/link'); link.type=tarfile.SYMTYPE; link.linkname='/etc/passwd'; z.addfile(link)
            with self.assertRaises(ValueError): pkg.verify(p)

if __name__=='__main__': unittest.main()
