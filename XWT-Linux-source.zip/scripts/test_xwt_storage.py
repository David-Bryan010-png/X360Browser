#!/usr/bin/env python3
"""Run xwt-storage against a fake /proc, /sys and /dev tree with stubbed mount(8)."""
from __future__ import annotations

import os
import shutil
import subprocess
import tempfile
import textwrap
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "linux/overlay/usr/sbin/xwt-storage"

MOUNT_STUB = textwrap.dedent("""\
    #!/bin/sh
    # mount -t FS -o OPTS DEV TARGET : only vfat succeeds, content comes from $FAKE_FS/<dev name>
    fs=$2; dev=$5; target=$6
    [ "$fs" = vfat ] || exit 32
    src="$FAKE_FS/$(basename "$dev")"
    [ -d "$src" ] || exit 32
    cp -a "$src/." "$target/"
    echo "$dev $target vfat rw 0 0" >> "$XWT_PROC/mounts"
""")
UMOUNT_STUB = textwrap.dedent("""\
    #!/bin/sh
    target=$1
    grep -v " $target " "$XWT_PROC/mounts" > "$XWT_PROC/mounts.new"; mv "$XWT_PROC/mounts.new" "$XWT_PROC/mounts"
    rm -rf "$target"/* 2>/dev/null
    exit 0
""")


class StorageTests(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp = Path(tempfile.mkdtemp())
        t = self.tmp
        for d in ("proc", "sys", "dev", "run", "mnt", "bin", "fs"):
            (t / d).mkdir()
        for name, body in (("mount", MOUNT_STUB), ("umount", UMOUNT_STUB)):
            (t / "bin" / name).write_text(body)
            (t / "bin" / name).chmod(0o755)
        for noop in ("mdev", "sleep", "dmesg", "mknod", "sync", "dialog", "blkid"):
            (t / "bin" / noop).write_text("#!/bin/sh\nexit 0\n")
            (t / "bin" / noop).chmod(0o755)
        (t / "proc/mounts").write_text("")
        self.env = {
            "PATH": f"{t / 'bin'}:{os.environ['PATH']}",
            "XWT_PROC": str(t / "proc"),
            "XWT_SYSBLK": str(t / "sys"),
            "XWT_DEVDIR": str(t / "dev"),
            "XWT_RUNDIR": str(t / "run"),
            "XWT_MNTROOT": str(t / "mnt"),
            "XWT_CONSOLE": str(t / "console"),
            "XWT_STORAGE_WAIT": "0",
            "FAKE_FS": str(t / "fs"),
        }

    def tearDown(self) -> None:
        shutil.rmtree(self.tmp, ignore_errors=True)

    def add_disk(self, disk: str = "sda", removable: str = "1") -> None:
        sysd = self.tmp / "sys" / disk
        (sysd / "device").mkdir(parents=True)
        (sysd / "device/model").write_text("USB DISK 2.0   \n")
        (sysd / "removable").write_text(removable + "\n")
        (sysd / "size").write_text("7864320\n")
        (self.tmp / "dev" / disk).touch()

    def add_partition(self, part: str = "sda1", disk: str = "sda", content: dict[str, str] | None = None) -> None:
        (self.tmp / "sys" / disk / part).mkdir(parents=True, exist_ok=True)
        (self.tmp / "sys" / part).mkdir(exist_ok=True)
        (self.tmp / "sys" / part / "size").write_text("7864000\n")
        (self.tmp / "dev" / part).touch()
        fs = self.tmp / "fs" / part
        fs.mkdir(parents=True, exist_ok=True)
        for name, data in (content or {}).items():
            path = fs / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(data)
        header = "major minor  #blocks  name\n\n"
        path = self.tmp / "proc/partitions"
        existing = path.read_text() if path.exists() else header
        path.write_text(existing + (f"   8        0    7864320 {disk}\n" if f" {disk}\n" not in existing else "") + f"   8        1    7864000 {part}\n")

    def run_script(self, *args: str) -> subprocess.CompletedProcess:
        return subprocess.run(["sh", str(SCRIPT), *args], env=self.env, capture_output=True, text=True, timeout=60)

    def env_file(self) -> dict[str, str]:
        text = (self.tmp / "run/xwt-storage.env").read_text()
        return dict(line.split("=", 1) for line in text.splitlines())

    def test_finds_usb_with_xwt_marker(self) -> None:
        self.add_disk()
        self.add_partition(content={"kboot.conf": "#KBOOTCONFIG\n", "X360WebTotal/VERSION.txt": "1.0.0\n"})
        result = self.run_script("boot")
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(self.env_file()["XWT_USB_STORAGE"], "mounted")
        self.assertTrue((self.tmp / "mnt/xwt-usb/kboot.conf").is_file())

    def test_unmarked_removable_stick_is_reported_not_silently_used_for_persistence(self) -> None:
        self.add_disk()
        self.add_partition(content={"photo.jpg": "x"})
        result = self.run_script("boot")
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(self.env_file()["XWT_USB_STORAGE"], "unmarked")

    def test_no_storage_reports_unavailable_with_diagnostics(self) -> None:
        (self.tmp / "proc/partitions").write_text("major minor  #blocks  name\n\n")
        result = self.run_script("boot")
        self.assertNotEqual(result.returncode, 0)
        self.assertEqual(self.env_file()["XWT_USB_STORAGE"], "unavailable")
        self.assertIn("no usable USB storage", (self.tmp / "run/xwt-storage.log").read_text())

    def test_unsupported_filesystem_is_not_mounted(self) -> None:
        self.add_disk(disk="sdb", removable="0")
        # partition exists but the stub has no vfat content for it (e.g. the Xbox XTAF disk)
        part = self.tmp / "sys/sdb/sdb1"
        part.mkdir(parents=True)
        (self.tmp / "sys/sdb1").mkdir()
        (self.tmp / "sys/sdb1/size").write_text("100\n")
        (self.tmp / "dev/sdb1").touch()
        (self.tmp / "proc/partitions").write_text("major minor  #blocks  name\n\n   8 16 100 sdb\n   8 17 100 sdb1\n")
        result = self.run_script("mount", "sdb1")
        self.assertNotEqual(result.returncode, 0)

    def test_list_hides_whole_disk_when_partitions_exist(self) -> None:
        self.add_disk()
        self.add_partition()
        result = self.run_script("list")
        names = [line.split("|", 1)[0] for line in result.stdout.splitlines()]
        self.assertEqual(names, ["sda1"])
        self.assertIn("USB DISK 2.0", result.stdout)


class StaticChecks(unittest.TestCase):
    def test_boot_script_delegates_to_storage_tool(self) -> None:
        s30 = (ROOT / "linux/overlay/etc/init.d/S30storage").read_text()
        self.assertIn("xwt-storage boot", s30)
        self.assertIn("xwt-update apply", s30)

    def test_tool_is_in_post_build_checks(self) -> None:
        self.assertIn("xwt-storage", (ROOT / "linux/post-build.sh").read_text())


if __name__ == "__main__":
    unittest.main(verbosity=2)
