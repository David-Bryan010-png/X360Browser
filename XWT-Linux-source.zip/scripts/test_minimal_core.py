#!/usr/bin/env python3
"""Structural tests for the first bootable XWT Linux core."""
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]

class MinimalCoreTests(unittest.TestCase):
    def test_source_version_and_revision_are_015(self):
        self.assertEqual((ROOT/"VERSION").read_text().strip(), "1.0.0")
        self.assertEqual((ROOT/"REVISION.txt").read_text().strip(), "xwt-linux-1.0.0-desktop-gamepad-network-video")

    def test_xell_boot_configuration_is_real_and_points_to_usb_elf_and_initrd(self):
        lines=(ROOT/'linux/boot/kboot.conf').read_text().splitlines()
        self.assertEqual(lines[0], '#KBOOTCONFIG')
        self.assertIn('default=xwt_linux_usb', lines)
        # Automatic boot: timeout=0 never waits for (or reads) the controller on the XeLL screen.
        self.assertIn('timeout=0', lines)
        entry=next(line for line in lines if line.startswith('xwt_linux_usb='))
        self.assertIn('"uda:/X360WebTotal/Linux/xwt-linux.elf', entry)
        self.assertIn('initrd=uda:/X360WebTotal/Linux/rootfs.cpio.gz', entry)

    def test_minimal_base_has_initramfs_tls_usb_and_wired_network(self):
        config=(ROOT/'linux/buildroot.config').read_text()
        for item in ('BR2_TARGET_ROOTFS_CPIO=y','BR2_TARGET_ROOTFS_CPIO_GZIP=y',
                     'BR2_PACKAGE_LIBCURL=y','BR2_PACKAGE_LIBCURL_CURL=y',
                     'BR2_PACKAGE_OPENSSL=y','BR2_PACKAGE_CA_CERTIFICATES=y',
                     'BR2_LINUX_KERNEL=y'):
            self.assertIn(item, config)

    def test_busybox_enables_commands_required_by_first_boot_and_updater(self):
        fragment=(ROOT/'linux/busybox.fragment').read_text()
        for applet in ('CONFIG_ASH=y','CONFIG_MOUNT=y','CONFIG_UMOUNT=y','CONFIG_MDEV=y',
                       'CONFIG_UDHCPC=y','CONFIG_TAR=y','CONFIG_SHA256SUM=y','CONFIG_FIND=y',
                       'CONFIG_GREP=y','CONFIG_AWK=y','CONFIG_SED=y','CONFIG_CP=y',
                       'CONFIG_MV=y','CONFIG_RM=y','CONFIG_MKDIR=y','CONFIG_REBOOT=y',
                       'CONFIG_POWEROFF=y','CONFIG_CLEAR=y','CONFIG_SYNC=y'):
            self.assertIn(applet, fragment)

    def test_kernel_boot_options_include_initrd_gzip_framebuffer_and_usb(self):
        workflow=(ROOT/'.github/workflows/build-xex-from-zip.yml').read_text()
        for item in ('CONFIG_BLK_DEV_INITRD','CONFIG_RD_GZIP','CONFIG_DRM_XENOS',
                     'CONFIG_FRAMEBUFFER_CONSOLE','CONFIG_USB_STORAGE','CONFIG_SIS190'):
            self.assertIn(item, workflow)
        self.assertIn('BR2_LINUX_KERNEL_INSTALL_TARGET":"y"', workflow)
        self.assertIn('linux-configure', workflow)
        self.assertIn('images/zImage.xenon', workflow)
        self.assertIn('CONFIG_PPC_XENON is intentionally NOT expected', workflow)
        self.assertNotIn('KERNEL_ELF', workflow)
        self.assertNotIn('vmlinux ELF', workflow)

    def test_initial_and_incremental_workflows_are_separate(self):
        full=(ROOT/'.github/workflows/build-xex-from-zip.yml').read_text()
        small=(ROOT/'.github/workflows/xwt-small-updates.yml').read_text()
        self.assertIn('workflow_dispatch:', full)
        self.assertIn('Package ${{ inputs.component }} without rebuilding Linux', small)
        self.assertNotIn('make -C "$BUILDROOT_DIR"', small)
        self.assertIn('SOURCE-MANIFEST.sha256', small)
        self.assertIn('actions/cache/restore@v6', small)

    def test_installer_keeps_the_nand_out_of_the_update_scope(self):
        updater=(ROOT/'linux/overlay/usr/sbin/xwt-update').read_text()
        self.assertIn("MODULES='/opt/xwt/modules'", updater)
        self.assertIn("STORE=", updater)
        self.assertNotIn('/dev/mtd', updater)
        self.assertNotIn('nand_write', updater.lower())

if __name__ == '__main__':
    unittest.main(verbosity=2)
