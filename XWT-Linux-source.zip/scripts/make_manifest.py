#!/usr/bin/env python3
"""Write SOURCE-MANIFEST.sha256 (sha256sum format, paths without './', manifest and caches excluded)."""
from __future__ import annotations

import hashlib
import sys
from pathlib import Path

NAME = "SOURCE-MANIFEST.sha256"


def entries(root: Path) -> list[Path]:
    return sorted(
        (p for p in root.rglob("*")
         if p.is_file() and p.name != NAME and p.suffix != ".pyc" and "__pycache__" not in p.parts),
        key=lambda p: p.relative_to(root).as_posix().encode(),
    )


def build(root: Path) -> str:
    return "".join(f"{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.relative_to(root).as_posix()}\n" for p in entries(root))


if __name__ == "__main__":
    base = Path(sys.argv[1] if len(sys.argv) > 1 else ".").resolve()
    (base / NAME).write_text(build(base), encoding="ascii")
