#!/usr/bin/env python3
"""xwt-apps, new games and BMP asset checks."""
import os, subprocess, unittest
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]

class AppsTests(unittest.TestCase):
    def test_scripts_parse_and_usage(self):
        for n in ("xwt-apps", "xwt-game"):
            f = ROOT / "linux/overlay/usr/sbin" / n
            subprocess.run(["sh", "-n", str(f)], check=True)
            self.assertTrue(os.access(f, os.X_OK))
        r = subprocess.run(["sh", str(ROOT / "linux/overlay/usr/sbin/xwt-apps"), "bogus"], capture_output=True, text=True)
        self.assertEqual(r.returncode, 1)
    def test_buildroot_packages(self):
        c = (ROOT / "linux/buildroot.config").read_text()
        for p in ("DOOM_WAD", "LBREAKOUT2", "LTRIS", "OPENTYRIAN", "MPG123", "FBV", "FBGRAB", "UNZIP"):
            self.assertIn(f"BR2_PACKAGE_{p}=y", c)
    def test_assets_are_bmp(self):
        d = ROOT / "linux/overlay/usr/share/xwt"
        files = list(d.glob("*.bmp"))
        self.assertGreaterEqual(len(files), 30)
        for f in files:
            self.assertEqual(f.read_bytes()[:2], b"BM", f.name)
        self.assertTrue((d / "icon-apps.bmp").exists())
