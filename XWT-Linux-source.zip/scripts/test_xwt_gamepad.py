#!/usr/bin/env python3
from pathlib import Path
import shutil
import subprocess
import unittest
ROOT=Path(__file__).resolve().parents[1]
class GamepadTests(unittest.TestCase):
    def test_daemon_compiles_cleanly_on_host(self):
        cc=shutil.which("cc") or shutil.which("gcc")
        if not cc: self.skipTest("host C compiler unavailable")
        subprocess.run([cc,"-std=c11","-Wall","-Wextra","-Werror","-fsyntax-only",str(ROOT/"linux/src/xwt-gamepad-keys.c")],check=True)
    def test_hotplug_multi_controller_and_input_translation(self):
        s=(ROOT/"linux/src/xwt-gamepad-keys.c").read_text()
        for token in ("XWT_MAX_JOYSTICKS 4","/dev/input/js%u","UI_DEV_SETUP","KEY_UP","KEY_ENTER","KEY_ESC","buttons[0]","buttons[1]","buttons[6]","buttons[7]","ABS_HAT0X/Y","poll(","JS_EVENT_AXIS","JS_EVENT_BUTTON"):
            self.assertIn(token,s)
    def test_boot_service_starts_and_stops_the_bridge(self):
        s=(ROOT/"linux/overlay/etc/init.d/S15gamepad").read_text()
        for token in ("load_module xpad","load_module joydev","load_module uinput","xwt-gamepad-keys","PIDFILE","stop)"):
            self.assertIn(token,s)
