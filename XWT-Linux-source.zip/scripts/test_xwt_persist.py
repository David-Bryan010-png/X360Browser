#!/usr/bin/env python3
"""xwt-persist (bind-mount persistence on the USB stick), tested in copy mode."""
import os, subprocess, tempfile, unittest
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "linux/overlay/usr/sbin/xwt-persist"

def run(env, *args):
    e = dict(os.environ, XWT_PERSIST_DRY="1", **env)
    return subprocess.run(["sh", str(SCRIPT), *args], env=e, capture_output=True, text=True)

class PersistTests(unittest.TestCase):
    def test_seed_then_survive_reboot(self):
        with tempfile.TemporaryDirectory() as d:
            d = Path(d); usb = d / "usb"; (usb / "X360WebTotal").mkdir(parents=True)
            home = d / "home"; home.mkdir(); (home / "a.txt").write_text("v1")
            env = {"XWT_USB": str(usb), "XWT_RUN": str(d / "run"), "XWT_PERSIST_LIST": str(home), "XWT_USB_STORAGE": "mounted"}
            self.assertEqual(run(env, "start").returncode, 0)
            self.assertTrue((usb / "X360WebTotal/User/persist" / str(home).lstrip("/").replace("/", "_") / "a.txt").exists())
            (home / "b.txt").write_text("new"); run(env, "sync")
            # simulate reboot: fresh (empty) home gets the stored files back
            for f in home.iterdir(): f.unlink()
            run(env, "start")
            self.assertEqual((home / "a.txt").read_text(), "v1")
            self.assertEqual((home / "b.txt").read_text(), "new")
            self.assertTrue((d / "run/xwt-persist.state").read_text().startswith("on"))
    def test_no_usb_means_off(self):
        with tempfile.TemporaryDirectory() as d:
            env = {"XWT_USB": d + "/none", "XWT_RUN": d + "/run", "XWT_PERSIST_LIST": d + "/h", "XWT_USB_STORAGE": "mounted"}
            self.assertNotEqual(run(env, "start").returncode, 0)
            self.assertEqual((Path(d) / "run/xwt-persist.state").read_text().strip(), "off")
    def test_wired_into_storage_init(self):
        s = (ROOT / "linux/overlay/etc/init.d/S30storage").read_text()
        self.assertIn("xwt-persist start", s); self.assertIn("xwt-persist stop", s)

if __name__ == "__main__":
    unittest.main()


class WifiSaveTests(unittest.TestCase):
    def test_save_replace_and_validate(self):
        wifi = ROOT / "linux/overlay/usr/sbin/xwt-wifi"
        with tempfile.TemporaryDirectory() as d:
            env = dict(os.environ, XWT_WIFI_DIR=d)
            def save(*a): return subprocess.run(["sh", str(wifi), "save", *a], env=env, capture_output=True, text=True)
            self.assertEqual(save("Casa", "senha12345").returncode, 0)
            self.assertEqual(save("Outra", "outrasenha1").returncode, 0)
            self.assertEqual(save("Casa", "novasenha99").returncode, 0)
            conf = (Path(d) / "wpa_supplicant.conf").read_text()
            self.assertEqual(conf.count("network={"), 2)
            self.assertIn('psk="novasenha99"', conf); self.assertNotIn("senha12345", conf)
            self.assertNotEqual(save("x", "curta").returncode, 0)
            self.assertNotEqual(save('a"b', "senha12345").returncode, 0)
    def test_autoconnect_at_boot(self):
        s = (ROOT / "linux/overlay/etc/init.d/S41wifi").read_text()
        self.assertIn("autoconnect", s)
