#!/usr/bin/env python3
"""SOURCE-MANIFEST.sha256 must be well formed and every listed file must match.

The workflow already rejects unlisted files while extracting the source ZIP, so files that other
tests or tools create later (caches, temp output) are deliberately not treated as errors here.
"""
from __future__ import annotations

import hashlib
import re
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
NAME = "SOURCE-MANIFEST.sha256"


class ManifestTests(unittest.TestCase):
    def test_manifest_entries_match_files(self):
        seen = set()
        lines = (ROOT / NAME).read_text(encoding="ascii").splitlines()
        self.assertTrue(lines)
        for line in lines:
            m = re.fullmatch(r"([0-9a-f]{64})  (.+)", line)
            self.assertIsNotNone(m, line)
            digest, name = m.groups()
            self.assertFalse(name.startswith("./"), name)
            self.assertNotEqual(name, NAME)
            self.assertNotIn(name, seen)
            seen.add(name)
            self.assertEqual(hashlib.sha256((ROOT / name).read_bytes()).hexdigest(), digest, name)


if __name__ == "__main__":
    unittest.main()
