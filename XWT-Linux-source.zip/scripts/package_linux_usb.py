#!/usr/bin/env python3
"""Build and verify a XeLL-loadable X360 Web Total Linux USB package."""
from __future__ import annotations

import argparse
import gzip
import hashlib
import io
import json
import re
import struct
import zipfile
from pathlib import Path, PurePosixPath

VERSION = "0.15.0"
REVISION = "xwt-linux-0.15.0-desktop-gamepad-network-video"

# XeLL Reloaded's current libxenon ELF loader accepts ELF32, not ELF64.
# It also rejects a mapped ELF image at or above ELF_MAX_SIZE.
XELL_ELF_MAX_MAPPED_SIZE = 0x05FE0000
# kernel_prepare_initrd() refuses an initrd larger than 32 MiB.
XELL_INITRD_MAX_BYTES = 32 * 1024 * 1024
MAX_INITRD_EXPANDED_BYTES = 128 * 1024 * 1024


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def validate_kernel(path: Path) -> None:
    validate_kernel_bytes(path.read_bytes())


def validate_kernel_bytes(data: bytes) -> None:
    """Validate the ELF32 PowerPC wrapper that XeLL actually loads.

    The Free60 kernel itself is PPC64. The Linux PowerPC boot wrapper emits
    an ELF32 PowerPC executable (zImage.xenon) which contains that kernel.
    Passing the PPC64 vmlinux directly to XeLL is not supported.
    """
    if len(data) >= XELL_ELF_MAX_MAPPED_SIZE:
        raise ValueError("kernel ELF exceeds XeLL's available staging space")
    if len(data) < 52 or data[:7] != b"\x7fELF\x01\x02\x01":
        raise ValueError("XeLL kernel must be an ELF32 big-endian PowerPC image (use zImage.xenon, not vmlinux)")

    e_type, machine = struct.unpack_from(">HH", data, 16)
    version = struct.unpack_from(">I", data, 20)[0]
    entry, phoff = struct.unpack_from(">II", data, 24)
    ehsize, phentsize, phnum = struct.unpack_from(">HHH", data, 40)

    if e_type not in (2, 3) or machine != 20 or version != 1:
        raise ValueError("kernel ELF header is not executable ELF32 PowerPC big-endian")
    # ELF entry zero is valid only when an executable PT_LOAD
    # segment maps address zero. The range check below remains mandatory.
    if ehsize < 52 or phentsize != 32 or phnum < 1:
        raise ValueError("kernel ELF has an invalid ELF32 program-header layout")
    if phoff < ehsize or phoff + phentsize * phnum > len(data):
        raise ValueError("kernel ELF program-header table exceeds the file size")

    mapped_size = 0
    has_load_segment = False
    entry_is_executable = False
    for index in range(phnum):
        off = phoff + index * phentsize
        p_type, p_offset, p_vaddr, p_paddr, p_filesz, p_memsz, p_flags, p_align = struct.unpack_from(">IIIIIIII", data, off)

        # XeLL checks every program header's file range before loading.
        if p_offset + p_filesz > len(data):
            raise ValueError(f"kernel ELF program header {index} exceeds the file size")
        if p_filesz > p_memsz:
            raise ValueError(f"kernel ELF program header {index} has p_filesz greater than p_memsz")
        if p_memsz:
            mapped_size = max(mapped_size, p_paddr + p_memsz)

        # XeLL copies PT_LOAD, PT_DYNAMIC and PT_NOTE segments.
        if p_type in (1, 2, 4) and p_memsz:
            if p_type == 1:
                has_load_segment = True
                if p_flags & 1 and p_paddr <= entry < p_paddr + p_memsz:
                    entry_is_executable = True

    if not has_load_segment:
        raise ValueError("kernel ELF has no loadable PT_LOAD segment")
    if not entry_is_executable:
        raise ValueError("kernel ELF entry point is not inside an executable PT_LOAD segment")
    if mapped_size == 0 or mapped_size >= XELL_ELF_MAX_MAPPED_SIZE:
        raise ValueError(
            f"kernel ELF mapped size {mapped_size:#x} exceeds XeLL's supported limit "
            f"({XELL_ELF_MAX_MAPPED_SIZE:#x})"
        )


def validate_kboot(data: bytes) -> None:
    try:
        text = data.decode("ascii")
    except UnicodeDecodeError as exc:
        raise ValueError("kboot.conf must be plain ASCII") from exc
    lines = text.splitlines()
    if not lines or lines[0] != "#KBOOTCONFIG":
        raise ValueError("kboot.conf must start with #KBOOTCONFIG on the first line")
    entries = {}
    for line in lines[1:]:
        stripped = line.strip()
        if not stripped or stripped.startswith(("#", ";")) or "=" not in stripped:
            continue
        key, value = stripped.split("=", 1)
        if key in {"default", "timeout", "speedup", "videomode", "ip", "netmask", "gateway", "tftp_server"}:
            continue
        if not re.fullmatch(r"[A-Za-z0-9_-]+", key):
            raise ValueError(f"invalid XeLL boot-entry label: {key!r}")
        if len(value) < 2 or value[0] != '"' or value[-1] != '"':
            raise ValueError(f"XeLL boot entry {key!r} must have a quoted value")
        entries[key] = value[1:-1]
    default = next((line.split("=", 1)[1].strip() for line in lines[1:] if line.startswith("default=")), "")
    if not default or default not in entries:
        raise ValueError("kboot.conf default must name an existing quoted boot entry")
    boot = entries[default]
    required = (
        "uda:/X360WebTotal/Linux/xwt-linux.elf",
        "initrd=uda:/X360WebTotal/Linux/rootfs.cpio.gz",
    )
    if not all(token in boot for token in required):
        raise ValueError("default XeLL entry must reference the XWT Xenon kernel and initramfs on USB")
    timeout = next((line.split("=", 1)[1].strip() for line in lines[1:] if line.startswith("timeout=")), "0")
    if not timeout.isdigit() or int(timeout) < 1:
        raise ValueError("kboot.conf timeout must be a positive integer so the XeLL menu remains selectable")


def validate_launcher(path: Path) -> None:
    data = path.read_bytes()
    if len(data) < 1024 or len(data) > 64 * 1024 * 1024 or data[:4] != b"XEX2":
        raise ValueError("default.xex is not a valid-looking XEX2 launcher (expected XEX2 magic and 1 KiB..64 MiB)")


def _align4(value: int) -> int:
    return (value + 3) & ~3


def validate_newc(data: bytes) -> None:
    """Parse the complete cpio-newc stream and reject truncation/traversal."""
    offset = 0
    entries = 0
    seen_trailer = False
    while offset < len(data):
        if len(data) - offset < 110:
            if seen_trailer and not any(data[offset:]):
                break
            raise ValueError("truncated cpio newc header")
        header = data[offset:offset + 110]
        if header[:6] not in (b"070701", b"070702"):
            if seen_trailer and not any(data[offset:]):
                break
            raise ValueError("invalid cpio newc magic")
        try:
            fields = [int(header[pos:pos + 8], 16) for pos in range(6, 110, 8)]
        except ValueError as exc:
            raise ValueError("invalid hexadecimal field in cpio header") from exc
        mode, file_size, name_size = fields[1], fields[6], fields[11]
        if name_size < 1 or name_size > 4096:
            raise ValueError("invalid cpio pathname length")

        name_start = offset + 110
        name_end = name_start + name_size
        if name_end > len(data):
            raise ValueError("truncated cpio pathname")
        raw_name = data[name_start:name_end]
        if raw_name[-1:] != b"\0" or b"\0" in raw_name[:-1]:
            raise ValueError("invalid cpio pathname terminator")
        try:
            name = raw_name[:-1].decode("utf-8")
        except UnicodeDecodeError as exc:
            raise ValueError("cpio pathname is not valid UTF-8") from exc
        if not name:
            raise ValueError("empty cpio pathname")
        member = PurePosixPath(name)
        if member.is_absolute() or ".." in member.parts or "\\" in name:
            raise ValueError(f"unsafe cpio pathname: {name!r}")

        data_start = _align4(name_end)
        data_end = data_start + file_size
        if data_end > len(data):
            raise ValueError(f"truncated cpio data for {name!r}")
        if name == "TRAILER!!!":
            if file_size != 0:
                raise ValueError("cpio trailer must have zero data size")
            seen_trailer = True
            offset = _align4(data_end)
            break

        entries += 1
        offset = _align4(data_end)

    if entries == 0 or not seen_trailer:
        raise ValueError("cpio newc archive has no entries or missing TRAILER!!!")
    if any(data[offset:]):
        raise ValueError("non-zero trailing data after cpio trailer")


def validate_initrd_bytes(compressed: bytes) -> None:
    if not compressed:
        raise ValueError("initrd is empty")
    if len(compressed) > XELL_INITRD_MAX_BYTES:
        raise ValueError("compressed initrd exceeds XeLL's 32 MiB limit")
    try:
        with gzip.GzipFile(fileobj=io.BytesIO(compressed), mode="rb") as stream:
            data = stream.read(MAX_INITRD_EXPANDED_BYTES + 1)
    except (OSError, EOFError) as exc:
        raise ValueError(f"initrd gzip stream is invalid: {exc}") from exc
    if len(data) > MAX_INITRD_EXPANDED_BYTES:
        raise ValueError("expanded initrd exceeds the 128 MiB safety limit")
    validate_newc(data)


def validate_initrd(path: Path) -> None:
    validate_initrd_bytes(path.read_bytes())


def safe_member(name: str) -> None:
    p = PurePosixPath(name)
    if not name or p.is_absolute() or ".." in p.parts or "\\" in name or "\x00" in name:
        raise ValueError(f"unsafe package path: {name!r}")


def verify_package(path: Path) -> None:
    with zipfile.ZipFile(path) as z:
        names_list = z.namelist()
        if len(names_list) != len(set(names_list)):
            raise ValueError("package contains duplicate paths")
        names = set(names_list)
        required = {
            "default.xex",
            "XellLaunch2-LICENSE.txt",
            "kboot.conf",
            "X360WebTotal/Linux/xwt-linux.elf",
            "X360WebTotal/Linux/rootfs.cpio.gz",
            "X360WebTotal/VERSION.txt",
            "X360WebTotal/REVISION.txt",
            "X360WebTotal/README-INSTALL-PT-BR.txt",
            "SHA256SUMS.txt",
        }
        missing = sorted(required - names)
        if missing:
            raise ValueError("package missing: " + ", ".join(missing))
        for name in names:
            safe_member(name)
        if not z.read("default.xex").startswith(b"XEX2"):
            raise ValueError("default.xex has no XEX2 header")
        if b"MIT License" not in z.read("XellLaunch2-LICENSE.txt"):
            raise ValueError("XellLaunch2 MIT license is missing")
        validate_kboot(z.read("kboot.conf"))
        bad = z.testzip()
        if bad:
            raise ValueError(f"ZIP CRC error: {bad}")
        sums = {}
        for line in z.read("SHA256SUMS.txt").decode("ascii").splitlines():
            digest, filename = line.split("  ", 1)
            safe_member(filename)
            if filename not in names or filename in sums:
                raise ValueError(f"invalid checksum entry: {filename}")
            actual = hashlib.sha256(z.read(filename)).hexdigest()
            if actual != digest:
                raise ValueError(f"SHA-256 mismatch: {filename}")
            sums[filename] = digest
        if set(sums) != names - {"SHA256SUMS.txt"}:
            raise ValueError("SHA256SUMS.txt does not cover every package member")
        validate_kernel_bytes(z.read("X360WebTotal/Linux/xwt-linux.elf"))
        validate_initrd_bytes(z.read("X360WebTotal/Linux/rootfs.cpio.gz"))


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--launcher", required=True, type=Path, help="XellLaunch2 retail .xex launcher")
    ap.add_argument("--launcher-license", required=True, type=Path, help="MIT license for XellLaunch2")
    ap.add_argument("--kernel", required=True, type=Path, help="ELF32 PowerPC zImage.xenon wrapper")
    ap.add_argument("--initrd", required=True, type=Path)
    ap.add_argument("--project", type=Path, default=Path(__file__).resolve().parents[1])
    ap.add_argument("--output", required=True, type=Path)
    args = ap.parse_args()

    for path in (args.launcher, args.launcher_license, args.kernel, args.initrd):
        if not path.is_file() or path.stat().st_size == 0:
            raise FileNotFoundError(path)
    validate_launcher(args.launcher)
    validate_kernel(args.kernel)
    validate_initrd(args.initrd)
    if b"MIT License" not in args.launcher_license.read_bytes():
        raise ValueError("XellLaunch2 license file is not the expected MIT license")

    project = args.project.resolve()
    version_file = project / "VERSION"
    revision_file = project / "REVISION.txt"
    if not version_file.is_file() or not revision_file.is_file():
        raise FileNotFoundError("project is missing VERSION or REVISION.txt")
    source_version = version_file.read_text(encoding="ascii").strip()
    source_revision = revision_file.read_text(encoding="ascii").strip()
    if source_version != VERSION or source_revision != REVISION:
        raise ValueError(
            f"source/package version mismatch: source={source_version}/{source_revision}; "
            f"packager={VERSION}/{REVISION}"
        )
    kboot = project / "linux/boot/kboot.conf"
    readme = project / "README-INSTALL-PT-BR.txt"
    if not kboot.is_file() or not readme.is_file():
        raise FileNotFoundError("project is missing kboot.conf or installation instructions")
    kboot_data = kboot.read_bytes()
    validate_kboot(kboot_data)

    members: dict[str, bytes] = {
        "default.xex": args.launcher.read_bytes(),
        "XellLaunch2-LICENSE.txt": args.launcher_license.read_bytes(),
        "kboot.conf": kboot_data,
        "X360WebTotal/Linux/xwt-linux.elf": args.kernel.read_bytes(),
        "X360WebTotal/Linux/rootfs.cpio.gz": args.initrd.read_bytes(),
        "X360WebTotal/VERSION.txt": (VERSION + "\n").encode("ascii"),
        "X360WebTotal/REVISION.txt": (REVISION + "\n").encode("ascii"),
        "X360WebTotal/README-INSTALL-PT-BR.txt": readme.read_bytes(),
    }
    sums = "".join(f"{hashlib.sha256(data).hexdigest()}  {name}\n" for name, data in sorted(members.items()))
    members["SHA256SUMS.txt"] = sums.encode("ascii")

    args.output.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(args.output, "w") as z:
        for name, data in sorted(members.items()):
            safe_member(name)
            compress = zipfile.ZIP_STORED if name.endswith((".gz", ".elf")) else zipfile.ZIP_DEFLATED
            z.writestr(name, data, compress_type=compress, compresslevel=6 if compress == zipfile.ZIP_DEFLATED else None)
    verify_package(args.output)
    print(json.dumps({
        "version": VERSION,
        "revision": REVISION,
        "launcher": "XellLaunch2 retail XEX -> XeLL Reloaded -> ELF32 Xenon zImage wrapper + initramfs",
        "kernel_format": "ELF32 big-endian PowerPC (zImage.xenon)",
        "package": str(args.output),
        "size_bytes": args.output.stat().st_size,
        "sha256": sha256(args.output),
    }, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
