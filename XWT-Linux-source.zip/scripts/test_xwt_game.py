#!/usr/bin/env python3
"""xwt-game launcher + gamepad game-mode checks."""
from __future__ import annotations

import os
import subprocess
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
GAME = ROOT / "linux/overlay/usr/sbin/xwt-game"


class GameTests(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        (self.tmp / "games/doom").mkdir(parents=True)
        (self.tmp / "run").mkdir()
        stub = self.tmp / "prboom"
        stub.write_text('#!/bin/sh\necho "$@" > "$XWT_RUN/args"\ncat "$XWT_RUN/xwt-gamepad-mode" > "$XWT_RUN/modeduring"\necho "$SDL_VIDEODRIVER" > "$XWT_RUN/driver"\n')
        stub.chmod(0o755)
        self.env = dict(os.environ, XWT_PRBOOM=str(stub), XWT_GAMES_DIR=str(self.tmp / "games"),
                        XWT_RUN=str(self.tmp / "run"), XWT_USER_DIR=str(self.tmp / "user"), XWT_USB=str(self.tmp))

    def run_game(self, *a):
        return subprocess.run(["sh", str(GAME), *a], env=self.env, capture_output=True, text=True)

    def test_missing_wad_explains(self):
        r = self.run_game("doom")
        self.assertEqual(r.returncode, 3)
        self.assertIn("doom2.wad", r.stdout)

    def test_prefers_doom2_case_insensitive_and_sets_modes(self):
        (self.tmp / "games/doom/DOOM.WAD").write_bytes(b"x")
        (self.tmp / "games/doom/DOOM2.WAD").write_bytes(b"x")
        r = self.run_game("doom")
        self.assertEqual(r.returncode, 0, r.stderr)
        run = self.tmp / "run"
        args = (run / "args").read_text()
        self.assertIn("-iwad", args)
        self.assertIn("DOOM2.WAD", args)
        self.assertIn("-nosound", args)
        self.assertEqual((run / "modeduring").read_text().strip(), "game")
        self.assertEqual((run / "driver").read_text().strip(), "fbcon")
        self.assertEqual((run / "xwt-gamepad-mode").read_text().strip(), "menu")

    def test_gamepad_game_mode_present(self):
        s = (ROOT / "linux/src/xwt-gamepad-keys.c").read_text()
        for token in ("xwt-gamepad-mode", "KEY_LEFTCTRL", "KEY_SPACE", "game_mode"):
            self.assertIn(token, s)

    def test_desktop_lists_games(self):
        s = (ROOT / "linux/src/xwt-desktop.c").read_text()
        self.assertIn('"Jogos"', s)
        self.assertIn("/usr/sbin/xwt-game", s)

    def test_buildroot_has_prboom(self):
        self.assertIn("BR2_PACKAGE_PRBOOM=y", (ROOT / "linux/buildroot.config").read_text())
        self.assertIn("pack usr/games", (ROOT / "linux/packs.rules").read_text())


if __name__ == "__main__":
    unittest.main()
