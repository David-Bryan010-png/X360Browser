X360 WEB TOTAL 0.2.0 - GUIA DE INSTALACAO
Criador: DVDBRN

O QUE E
O X360 Web Total e um ambiente independente para Xbox 360. Ele e carregado como xenon.elf pelo XeLL Reloaded. A interface, o controle, a rede e o navegador passam a ser administrados pelo proprio programa depois que XeLL transfere a execucao.

ARQUIVOS NA RAIZ DO USB FAT32
- XellLaunch2.xex: iniciador externo que encaminha a inicializacao para XeLL Reloaded.
- xenon.elf: payload PowerPC do sistema X360 Web Total.
- X360WebTotal/: configuracao de referencia, dados, cache e logs.
- SHA256SUMS.txt: hashes para verificar os arquivos do pacote.

INICIALIZACAO
1. Use um Xbox 360 com ambiente homebrew e XeLL Reloaded compatível (normalmente RGH/JTAG).
2. Formate o dispositivo USB em FAT32.
3. Extraia todos os arquivos do ZIP para a raiz do USB. Nao renomeie xenon.elf.
4. No ambiente homebrew, execute XellLaunch2.xex.
5. Aguarde o XeLL carregar xenon.elf. O X360 Web Total inicializa sua interface e tenta abrir a pagina inicial quando a rede estiver disponivel.

CONTROLES
Tela inicial: D-pad escolhe tecla, A insere, X apaga, START navega.
Pagina: UP/DOWN rola, LEFT/RIGHT seleciona link, A abre, X volta, START atualiza, B retorna ao inicio.
BACK encerra o ambiente.

LIMITES DA VERSAO 0.2.0
- HTTP/1.x experimental e DNS A por UDP.
- HTML textual limitado, links, URLs relativas, redirecionamentos e historico.
- HTTPS/TLS, CSS, JavaScript, imagens decodificadas, audio, video e YouTube moderno ainda nao estao implementados.
- A compatibilidade depende da rede, do XeLL, do hardware e do site visitado.

IMPORTANTE
Este pacote carrega um ELF pelo XeLL. Nao e um XEX de dashboard e nao substitui o kernel do Xbox 360, Aurora ou a NAND. O XellLaunch2.xex e o iniciador; xenon.elf e o sistema executado depois da transferencia.

CONFIGURACAO
Edite X360WebTotal/config/browser.ini antes de usar o USB. A chave homepage aceita apenas uma URL HTTP valida nesta versao. Exemplo: homepage=http://neverssl.com/ . Se o arquivo estiver ausente ou invalido, o sistema usa http://neverssl.com/ como padrao.
A compilacao CI e os testes de PC nao garantem funcionamento em console fisico. Teste primeiro em uma configuracao RGH/JTAG conhecida e mantenha uma forma de retorno ao seu dashboard.
