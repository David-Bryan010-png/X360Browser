# Changelog — X360 Web Total

## 0.2.0 — reconstrução do ambiente LibXenon

- Substituído o uso de `dns_gethostbyname()` (indisponível na configuração lwIP NO_SYS do build usado no CI) por cliente DNS A/IN próprio sobre UDP, não bloqueante e com fallback de resolvedor.
- Parser DNS agora valida ID, flags, pergunta, classe/tipo, limites de pacote, registros e cadeia CNAME antes de aceitar um endereço IPv4.
- Corrigido o resolvedor de links `?query`, que antes perdia o último segmento do caminho base.
- Melhorado o enquadramento de respostas HTTP: tamanho exato de Content-Length e finalização/trailers chunked estritos.
- Melhorado o parser HTML para `>` dentro de atributos entre aspas e texto fora de blocos reconhecidos.
- Adicionado carregador limitado de configuração INI para a página inicial HTTP.
- Reforçado o empacotador USB: paths Windows/POSIX perigosos, caminhos repetidos, colisões sem distinção de maiúsculas, symlinks, arquivos muito grandes e ELF com segmentos/entry point inválidos são rejeitados.
- Corrigido o job MSVC do workflow para inicializar o ambiente do compilador e usar Ninja em vez de exigir Visual Studio 2022.
- Corrigido o fluxo de build Xbox para deixar de depender do DNS opcional `LWIP_DNS` da configuração LibXenon.

## Limites mantidos

A versão 0.2.0 continua sendo um ambiente LibXenon experimental com navegador HTTP textual limitado. Não implementa TLS/HTTPS, CSS, JavaScript/ECMAScript, rasterização de imagens, áudio ou vídeo. O alvo de execução continua `xenon.elf` carregado pelo XeLL; não é um XEX de dashboard.
