#ifndef XW_CONFIG_H
#define XW_CONFIG_H

#include <stddef.h>

#include "xw_url.h"

#ifdef __cplusplus
extern "C" {
#endif

#define XW_CONFIG_MAX_BYTES 4096u

typedef struct {
    char homepage[XW_URL_INPUT_MAX + 1];
} XwConfig;

void xw_config_defaults(XwConfig *config);
/* Parses a bounded INI file. Unknown keys are ignored for forward compatibility. */
int xw_config_parse(const char *data, size_t length, XwConfig *config,
                    char *error, size_t error_capacity);

#ifdef __cplusplus
}
#endif
#endif
