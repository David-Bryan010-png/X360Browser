#include "xw_dns_client.h"
#include "xw_dns_wire.h"

#include <string.h>

#include <lwip/err.h>
#include <lwip/ip_addr.h>
#include <lwip/pbuf.h>
#include <lwip/udp.h>

#define XW_DNS_PORT 53u
#define XW_DNS_TIMEOUT_FRAMES 180u

static struct udp_pcb *dns_pcb;
static unsigned char query[XW_DNS_PACKET_MAX];
static unsigned char response[XW_DNS_PACKET_MAX];
static size_t query_length;
static uint16_t transaction_id = 0x4b21u;
static unsigned frames_waited;
static unsigned server_index;
static int dns_state; /* 0 idle, 1 pending, 2 success, -1 failed */
static unsigned char resolved_ipv4[4];
static char active_hostname[254];

static void close_dns_socket(void)
{
    if (dns_pcb != NULL) {
        udp_recv(dns_pcb, NULL, NULL);
        udp_remove(dns_pcb);
        dns_pcb = NULL;
    }
}

void xw_dns_cancel(void)
{
    close_dns_socket();
    dns_state = 0;
    frames_waited = 0;
    query_length = 0;
}

static void dns_server_address(unsigned index, ip_addr_t *server)
{
    IP4_ADDR(server, index == 0u ? 1 : 8, index == 0u ? 1 : 8,
             index == 0u ? 1 : 8, index == 0u ? 1 : 8);
}

static int send_query(unsigned index)
{
    ip_addr_t server;
    struct pbuf *packet;
    err_t error;
    dns_server_address(index, &server);
    packet = pbuf_alloc(PBUF_TRANSPORT, (u16_t)query_length, PBUF_RAM);
    if (packet == NULL) return -1;
    if (pbuf_take(packet, query, (u16_t)query_length) != ERR_OK) {
        pbuf_free(packet);
        return -1;
    }
    error = udp_sendto(dns_pcb, packet, &server, XW_DNS_PORT);
    pbuf_free(packet);
    return error == ERR_OK ? 0 : -1;
}

static void on_dns_packet(void *arg, struct udp_pcb *pcb, struct pbuf *packet,
                          ip_addr_t *source, u16_t source_port)
{
    int parsed;
    ip_addr_t expected_source;
    (void)arg;
    (void)pcb;
    if (packet == NULL) return;
    dns_server_address(server_index, &expected_source);
    if (source == NULL || source_port != XW_DNS_PORT ||
        !ip_addr_cmp(source, &expected_source) || packet->tot_len > XW_DNS_PACKET_MAX) {
        pbuf_free(packet);
        return;
    }
    if (pbuf_copy_partial(packet, response, packet->tot_len, 0) != packet->tot_len) {
        pbuf_free(packet);
        return;
    }
    parsed = xw_dns_parse_a_response(response, packet->tot_len, transaction_id,
                                     active_hostname, resolved_ipv4);
    pbuf_free(packet);
    if (parsed == 1) {
        close_dns_socket();
        dns_state = 2;
    } else if (parsed < 0) {
        /* Ignore unrelated or malformed datagrams; timeout triggers retry/failure. */
    }
}

int xw_dns_start(const char *hostname)
{
    size_t hostname_length;
    xw_dns_cancel();
    if (hostname == NULL) { dns_state = -1; return -1; }
    hostname_length = strlen(hostname);
    if (hostname_length == 0u || hostname_length >= sizeof(active_hostname)) {
        dns_state = -1;
        return -1;
    }
    memcpy(active_hostname, hostname, hostname_length + 1u);
    ++transaction_id;
    if (transaction_id == 0) ++transaction_id;
    if (xw_dns_build_query(hostname, transaction_id, query, sizeof(query), &query_length) != 0) {
        dns_state = -1;
        return -1;
    }
    dns_pcb = udp_new();
    if (dns_pcb == NULL) {
        dns_state = -1;
        return -1;
    }
    udp_recv(dns_pcb, on_dns_packet, NULL);
    server_index = 0;
    dns_state = 1;
    if (send_query(server_index) != 0) {
        close_dns_socket();
        dns_state = -1;
        return -1;
    }
    return 0;
}

int xw_dns_poll(ip_addr_t *address)
{
    if (dns_state == 2) {
        if (address == NULL) return -1;
        IP4_ADDR(address, resolved_ipv4[0], resolved_ipv4[1], resolved_ipv4[2], resolved_ipv4[3]);
        dns_state = 0;
        return 1;
    }
    if (dns_state != 1) return dns_state;
    if (++frames_waited < XW_DNS_TIMEOUT_FRAMES) return 0;
    frames_waited = 0;
    if (server_index == 0u) {
        server_index = 1u;
        if (send_query(server_index) == 0) return 0;
    }
    close_dns_socket();
    dns_state = -1;
    return -1;
}
