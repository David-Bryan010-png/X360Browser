#include "xw_config.h"

#include <ctype.h>
#include <stdio.h>
#include <string.h>

static int config_error(char *error, size_t capacity, const char *message)
{
    if (error != NULL && capacity != 0u) (void)snprintf(error, capacity, "%s", message);
    return -1;
}

static int key_equals(const char *text, size_t length, const char *expected)
{
    size_t i;
    if (strlen(expected) != length) return 0;
    for (i = 0; i < length; ++i)
        if (tolower((unsigned char)text[i]) != tolower((unsigned char)expected[i])) return 0;
    return 1;
}

static void trim_bounds(const char *data, size_t *begin, size_t *end)
{
    while (*begin < *end && isspace((unsigned char)data[*begin])) ++*begin;
    while (*end > *begin && isspace((unsigned char)data[*end - 1u])) --*end;
}

void xw_config_defaults(XwConfig *config)
{
    if (config == NULL) return;
    (void)snprintf(config->homepage, sizeof(config->homepage), "%s", "http://neverssl.com/");
}

int xw_config_parse(const char *data, size_t length, XwConfig *config,
                    char *error, size_t error_capacity)
{
    XwConfig candidate;
    size_t position = 0;
    int homepage_seen = 0;
    if (data == NULL || config == NULL) return config_error(error, error_capacity, "argumento de configuracao nulo");
    if (length > XW_CONFIG_MAX_BYTES) return config_error(error, error_capacity, "arquivo INI excede 4096 bytes");
    candidate = *config;

    while (position < length) {
        size_t line_start = position, line_end, begin, end, equals;
        while (position < length && data[position] != '\n') ++position;
        line_end = position;
        if (position < length) ++position;
        begin = line_start;
        end = line_end;
        trim_bounds(data, &begin, &end);
        if (begin == end || data[begin] == '#' || data[begin] == ';') continue;
        for (equals = begin; equals < end && data[equals] != '='; ++equals) { }
        if (equals == end) return config_error(error, error_capacity, "linha INI sem '='");
        {
            size_t key_begin = begin, key_end = equals;
            size_t value_begin = equals + 1u, value_end = end;
            trim_bounds(data, &key_begin, &key_end);
            trim_bounds(data, &value_begin, &value_end);
            if (key_begin == key_end) return config_error(error, error_capacity, "chave INI vazia");
            if (key_equals(data + key_begin, key_end - key_begin, "homepage")) {
                XwUrl parsed;
                char url_error[96];
                size_t value_length = value_end - value_begin;
                char value[XW_URL_INPUT_MAX + 1];
                if (homepage_seen) return config_error(error, error_capacity, "homepage duplicada no INI");
                if (value_length == 0u || value_length >= sizeof(value))
                    return config_error(error, error_capacity, "homepage vazia ou longa demais");
                if (memchr(data + value_begin, '\0', value_length) != NULL)
                    return config_error(error, error_capacity, "homepage contem byte NUL");
                memcpy(value, data + value_begin, value_length);
                value[value_length] = '\0';
                if (xw_url_parse(value, &parsed, url_error, sizeof(url_error)) != 0 || parsed.tls)
                    return config_error(error, error_capacity, "homepage precisa ser uma URL HTTP valida nesta versao");
                (void)snprintf(candidate.homepage, sizeof(candidate.homepage), "%s", value);
                homepage_seen = 1;
            }
        }
    }
    *config = candidate;
    if (error != NULL && error_capacity != 0u) error[0] = '\0';
    return 0;
}
