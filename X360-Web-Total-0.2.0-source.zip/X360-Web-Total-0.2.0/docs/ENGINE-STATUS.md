# X360 Web Total 0.2.0 — estado técnico

## Executado pelo console

O artefato de sistema é `xenon.elf` (ELF32 big-endian PowerPC/LibXenon), carregado por XeLL Reloaded. `XellLaunch2.xex` é o programa de entrada separado. O pipeline valida o formato do ELF e o hash conhecido do iniciador antes de montar o ZIP FAT32.

## Funcionalidades implementadas no código

- Shell LibXenon independente com leitura de controle, tela inicial, tela de carregamento, página e erro.
- Inicialização USB/armazenamento e polling de rede no loop principal.
- DNS A/IN do projeto em UDP, pacote máximo 512 bytes, consultas não bloqueantes e segundo resolvedor em contingência.
- HTTP/1.x por TCP raw lwIP, request HTTP/1.0, limites de buffer, Content-Length, resposta delimitada pelo fechamento TCP e Transfer-Encoding chunked.
- Verificação estrita do status HTTP, cabeçalhos, Content-Length conflitante/overflow, chunk framing e Content-Encoding.
- Parser HTML limitado, sem execução de script, com títulos, blocos, âncoras, itens de lista, separadores e texto alternativo de imagem.
- Layout textual com quebra de palavras longas, navegação por links e resolução de URLs relativas, absolutas, protocol-relative, query-only e fragment-only.
- Carregador INI limitado a 4096 bytes: lê `X360WebTotal/config/browser.ini`, valida e aplica a chave `homepage`; qualquer configuração inválida preserva os defaults.
- Redirecionamentos 301/302/303/307/308, limitados a cinco saltos; histórico com 16 endereços, voltar, refresh e scroll.
- Pacote USB com CRC ZIP e SHA-256 verificados.

## Limites conhecidos

- HTTP sem TLS: HTTPS é rejeitado com mensagem explícita.
- Não existe CSS, JavaScript/ECMAScript, DOM interativo, Canvas, WebGL, WebAssembly, workers ou iframes.
- Imagens são representadas por texto alternativo e origem; não há descodificador/rasterizador de imagem nesta versão.
- Não há decodificação de áudio/vídeo, HTMLMediaElement completo, HLS/DASH ou reprodução YouTube atual.
- DNS A usa 1.1.1.1 e 8.8.8.8 fixos como resolvedores; redes que bloqueiam DNS externo podem impedir nomes de domínio. IPv6 não está implementado.
- HTML, resposta HTTP e layout são limitados em memória; páginas grandes são rejeitadas ou truncadas pelo parser.
- Somente `homepage` é lida dinamicamente do INI. Endereços DNS, limites de memória, quantidade de histórico, limites de redirecionamento e recursos ativados continuam definidos no código.

## Testes

O CMake executa testes host para URLs, resolução de links, HTML, layout, HTTP, DNS-wire/CNAME e configuração. O script Python testa ELF, caminhos de pacote, colisões de nomes e o ciclo completo de empacotamento com entradas sintéticas. O CI ainda precisa compilar o ELF com a toolchain LibXenon fixada e gerar/validar o pacote com o XellLaunch2 oficial. Nenhuma compilação CI substitui teste em console físico.
