# X360 Web Total 0.2.0 — fluxo de inicialização

## Arquitetura

```text
Aurora / XeXMenu / ambiente homebrew existente
                   |
                   | executa XellLaunch2.xex
                   v
             XellLaunch2
                   |
                   | transfere para XeLL Reloaded
                   v
              XeLL Reloaded
                   |
                   | procura xenon.elf em FAT compatível
                   v
             xenon.elf (PowerPC)
                   |
                   v
    X360 Web Total: interface + sistema + web
```

## Separação de responsabilidades

- `XellLaunch2.xex` é um iniciador externo, de terceiro, validado por SHA-256 no pipeline. Ele não contém o navegador e não é renomeado como se fosse o aplicativo.
- XeLL Reloaded é o carregador de ELF e entrega o controle ao payload.
- `xenon.elf` é compilado pelo projeto com LibXenon para Xbox 360. Ele inicializa vídeo/console, USB, armazenamento, a rede lwIP e a interface do X360 Web Total.
- Depois da transferência, o X360 Web Total executa seu loop próprio de entrada, rede, HTTP, parse e layout. Não depende do Aurora para desenhar páginas.

## Requisitos e ressalvas

- Xbox 360 compatível com o ambiente XeLL Reloaded (tipicamente RGH/JTAG) e carregamento de ELF PowerPC.
- USB FAT32 que o XeLL consiga ler, com `xenon.elf` na raiz.
- O arquivo `XellLaunch2.xex` deve permanecer na raiz para ser executado manualmente pelo ambiente homebrew.
- Este processo não altera NAND, não substitui o kernel retail e não garante boot direto pelo botão Power. O primeiro salto ainda parte do ambiente homebrew que executa o XEX.
- Uma vez carregado o ELF, o ambiente próprio não é uma janela nem uma aba de outro navegador.

## Inicialização rápida da 0.2.0

- O programa inicia o vídeo e a interface LibXenon, realiza polling USB, prepara armazenamento e lê a chave `homepage` do arquivo `X360WebTotal/config/browser.ini` (se o FAT estiver montado).
- Inicializa a rede por LibXenon. O DHCP pode aguardar a janela de timeout do stack; esse tempo depende do link/roteador.
- Se a rede fica disponível, o navegador tenta abrir automaticamente a homepage compilada. Sem rede, mostra a tela inicial.
- DNS é implementado pelo próprio projeto com UDP, porque o build `NO_SYS` do LibXenon usado no CI não habilita `LWIP_DNS`.

## Recuperação

Se o ELF não carregar, confira o FAT32 e o nome exato `xenon.elf`, tente outra porta/dispositivo USB e confirme suporte ao XeLL Reloaded. Se a tela do X360 Web Total abrir mas a rede falhar, confirme cabo Ethernet, DHCP/roteador e disponibilidade de DNS externo. O pacote não grava nem altera NAND.
