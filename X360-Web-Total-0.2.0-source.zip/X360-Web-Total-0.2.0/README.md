# X360 Web Total 0.2.0

**Sistema independente para Xbox 360 · DVDBRN**

O X360 Web Total é um ambiente próprio executado no Xbox 360 por meio de XeLL Reloaded e LibXenon. O processo de entrada é:

1. O usuário inicia `XellLaunch2.xex` pelo ambiente homebrew disponível (por exemplo, Aurora).
2. O XellLaunch2 transfere o controle para XeLL Reloaded.
3. XeLL procura `xenon.elf` no dispositivo FAT compatível.
4. XeLL carrega o ELF PowerPC do X360 Web Total.
5. A partir daí, o X360 Web Total inicializa sua própria interface, controle, armazenamento, rede e navegador.

O aplicativo não é um tema do Aurora nem uma página aberta em outro browser. Depois da transferência para o ELF, a interface e a lógica do ambiente são do próprio X360 Web Total. O kernel original do console não é substituído e este pacote não modifica a NAND.

## Novidades da 0.2.0

- Resolução DNS própria por UDP, compatível com o lwIP `NO_SYS` usado pelo LibXenon; não depende de `LWIP_DNS` estar habilitado.
- Dois resolvedores DNS de contingência: `1.1.1.1` e `8.8.8.8`, com espera não bloqueante.
- Navegação HTTP por TCP com limites explícitos de memória.
- Links HTML selecionáveis pelo controle, URLs relativas e rejeição de esquemas ativos como `javascript:`.
- Redirecionamentos HTTP 301, 302, 303, 307 e 308 com limite de cinco saltos.
- Histórico de sessão com até 16 endereços, voltar página, rolagem e atualização.
- Leitura do arquivo `X360WebTotal/config/browser.ini` após montar FAT; a chave `homepage` define a página inicial e URLs HTTPS ou inválidas são recusadas.
- Parser HTTP mais rigoroso: status HTTP validado, tamanho de corpo, `Content-Length` duplicado/ambíguo, `Transfer-Encoding`, chunked, e rejeição de conteúdo gzip que não pode ser decodificado.
- Layout que divide palavras longas em vez de descartá-las.
- Validação estrutural de ELF32 PowerPC (incluindo segmentos carregáveis e endereço de entrada executável), hash fixo do XellLaunch2, caminhos portáveis, rejeição de entradas duplicadas/symlinks, CRC e SHA-256 de todos os arquivos no ZIP FAT32.
- O sistema abre automaticamente a página inicial quando a rede é inicializada.

## Compatibilidade real desta versão

| Recurso | Estado |
|---|---|
| Inicialização XeLL → `xenon.elf` | Implementada no fluxo de boot; depende do XeLL/console |
| Interface própria e controle | Implementados |
| HTTP/1.x sobre TCP | Experimental, implementado |
| DNS A por UDP | Implementado no cliente do projeto |
| HTML textual limitado | Implementado |
| Links e URLs relativas | Implementados |
| Redirecionamentos HTTP | Até cinco saltos |
| Histórico e rolagem | Implementados |
| HTTPS/TLS | Não implementado |
| CSS | Não implementado |
| JavaScript/DOM ativo | Não implementado |
| Decodificação de imagens | Não implementada |
| Áudio/vídeo/YouTube moderno | Não implementado |
| Canvas/WebGL/WebAssembly/jogos web modernos | Não implementados |

Esta é uma reconstrução funcional inicial do ambiente e do navegador HTTP, não um navegador moderno completo. Sites que exigem HTTPS, JavaScript ou CSS podem não funcionar ou não ser exibidos corretamente.

## Compilação

### Testes locais (PC)

```sh
cmake -S browser -B build-host -DCMAKE_BUILD_TYPE=Release
cmake --build build-host --parallel 2
ctest --test-dir build-host --output-on-failure
python3 scripts/test_package_usb.py
```

### ELF Xbox 360 (LibXenon)

```sh
cd browser
make clean all DEVKITXENON=/caminho/para/devkitxenon
```

O arquivo gerado é `browser/xenon.elf`, um ELF32 big-endian PowerPC destinado ao XeLL. Não é um XEX de dashboard.

### Pacote FAT32

Baixe o XellLaunch2 2.2.0 oficial e confirme o SHA-256 fixado em `scripts/package_usb.py`. Depois:

```sh
python3 scripts/package_usb.py \
  --elf browser/xenon.elf \
  --xell XellLaunch2.xex \
  --project . \
  --output X360-Web-Total-USB.zip
```

O workflow GitHub Actions executa testes de host, cross-compila o ELF com a imagem LibXenon fixada, verifica o resultado e publica o pacote USB como artefato.

## Sobre o tamanho

O tamanho correto do ELF é consequência do código, bibliotecas realmente usadas e recursos incluídos. A compilação usa otimização `-Os` e remoção de seções não utilizadas. Não são adicionados bytes vazios ou dados falsos para atingir 8–9 MB: isso aumentaria o arquivo sem adicionar funções e desperdiçaria armazenamento e memória. A versão 0.2.0 mantém os arquivos de boot e dados separados e verificáveis.

## Controle

- Tela inicial: D-pad seleciona teclas, `A` insere, `X` apaga, `START` abre.
- Página: `UP/DOWN` rola, `LEFT/RIGHT` seleciona links, `A` abre, `X` volta, `START` atualiza, `B` retorna ao início.
- `BACK` encerra o ambiente.

## Segurança e limites

- As respostas HTTP têm limite fixo de memória e validação de enquadramento.
- O DNS usa pacotes A/IN limitados a 512 bytes e não bloqueia o loop principal.
- Links `javascript:`, `data:`, `mailto:` e esquemas não HTTP(S) não são executados.
- O XellLaunch2 oficial é baixado e verificado por SHA-256 no CI; o binário não é modificado.
- Compilação CI não substitui teste físico em Xbox 360 RGH/JTAG com XeLL Reloaded compatível.
