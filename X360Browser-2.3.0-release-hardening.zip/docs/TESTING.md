# X360Browser 2.3.0-release-hardening — tests

## Host tests

The integrity checker catches missing fixtures/runners and mismatched version/build metadata before the longer tests start. The GitHub Actions workflow also searches for the actual project root when the repository contains a nested source folder. If the runner alone is missing but its fixture and C tests are present, the workflow bootstraps a temporary copy; commit the tracked runner from the ZIP to keep the repository complete.

Run the integrity check first, then execute the host regression suite:

```sh
python3 tests/validate_project_integrity.py
python3 tests/run_host_tests.py
```

The suite compiles C17 modules with `-Wall -Wextra -Wshadow -Wconversion -Werror` and exercises:

- HTTP fixture/network/resource discovery, bounded media-download logic and image caching.
- Dispatcher selection and legacy VisualLite layout regression.
- XenonWeb DOM parsing, entity decoding, CSS rules, selectors, pseudo-classes and bounded-input handling.
- XenonScript inline parsing/evaluation, shared global variables, basic expressions and conditionals, DOM text/attribute mutation, telemetry, and controlled rejection of unsupported loops.
- XenonWeb visual layout, inline script mutations before painting, focused `onclick` dispatch on fragment anchors, frame-cache invalidation and scrolling.

The portable core can additionally be tested with:

```sh
cmake -S . -B build -DX360BROWSER_BUILD_TESTS=ON -DCMAKE_BUILD_TYPE=Release
cmake --build build --parallel 2
ctest --test-dir build --output-on-failure
```

## Not covered by host tests

These checks do not validate the Xbox Xenon CPU/GPU, PowerPC ABI, xSDK, real memory pressure, controller behavior on device, console TLS bundle, visual output at native resolution, or XEX startup. Full ECMAScript, Canvas/WebGL, modern games and in-page video are not implemented and cannot be considered tested. Cross-build and physical console smoke tests remain required.


## External XenonScript integration (introduced in 2.2.0; retained in 2.3.0)

The local HTTP fixture serves `site.js` with a JavaScript MIME type. The native network test asserts that the small synchronous script is fetched and inserted at its original script position, then parses the resulting page through XenonWeb and confirms XenonScript changes `#external` from its placeholder text to `External script loaded`. The fixture also includes an `async` script (left untouched), a script over 4 KiB (not materialized), and a separate script endpoint with `text/plain` (rejected as executable JavaScript). These cases protect the ordering, byte-budget and MIME checks.
