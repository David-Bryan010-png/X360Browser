# Roadmap to a stable 1.0.0

Historical roadmap for the 1.0.0-preview milestone. The current development milestone is `2.3.0-release-hardening`; its engine work is documented in `XENONWEB-ENGINE.md`. Suggested completion gates:

1. **Build gate:** run the ZIP workflow with the exact source archive, fix any PowerPC/xSDK errors, preserve build logs and package the XEX plus certificates/licences.
2. **Hardware gate:** boot on an Xbox 360 RGH/JTAG; verify text, link focus, scrolling, DNS/HTTPS, cache writes, memory usage, and return from the external player.
3. **Engine gate:** replace `netsurf_backend_stub.c` with a real port that compiles and links NetSurf and its dependencies for PowerPC, and bridge fetch/scheduler, DOM, CSS layout, images and painting to the xSDK GPU. The current stub is not an engine.
4. **Script gate:** add an execution engine with a bounded runtime, a working DOM/event loop, timers and basic ES compatibility. Merely evaluating inline scripts is not enough for games.
5. **Canvas/game gate:** implement Canvas 2D, keyboard/gamepad events, requestAnimationFrame, timing and per-frame repaint; consider WebGL/WebAssembly only if memory and runtime feasibility is demonstrated.
6. **Media gate:** add actual audio/video demux/decode/presentation, audio output, seeking, buffering and adaptive streaming. Current direct-file/HLS VOD downloads are a file handoff, not in-page playback.
7. **YouTube gate:** test the official watch/embed page with its current scripts and streaming requirements. Do not claim support until it plays from the ordinary URL on hardware.
8. **Release gate:** complete a documented test matrix, confirm licences, checksums and reproducible artifacts, and publish only after no critical crash/security defects remain.

The Xbox 360 is a constrained PowerPC/512 MiB platform. Chromium/WebKit is not a drop-in dependency. NetSurf is a more plausible lightweight base, but its port, JavaScript coverage, modern Canvas features and codec support still need real implementation and hardware testing.
