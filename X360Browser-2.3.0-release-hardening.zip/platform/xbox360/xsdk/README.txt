X360Browser 2.3.0-release-hardening — XenonWeb + XenonScript

Experimental Xbox 360 RGH/JTAG homebrew browser. This development build contains a project-owned DOM/CSS/layout engine and a bounded interpreter for a small subset of inline script syntax. XenonScript is not a full JavaScript/ECMAScript runtime.

NativePlus/libcurl handles network transport and TLS support; VisualLite is a legacy rendering fallback. No real NetSurf engine is linked. External JavaScript is fetched only for at most two small synchronous scripts (4 KiB each) with a recognized JS MIME type and is still interpreted by the bounded XenonScript subset. The result is evaluated after DOM construction, not with full parser-blocking semantics. Async/defer/module/SRI are skipped; oversized payloads and wrong MIME types are rejected. Full modern HTML/CSS/JavaScript, Canvas/WebGL/WebAssembly, modern web games, in-page video/YouTube playback and complete forms are not supported.

Copy cacert.pem beside X360Browser.xex for TLS verification. The PowerPC/XEX build and console behaviour must be tested on actual hardware; this source package is not evidence of a completed console build.
