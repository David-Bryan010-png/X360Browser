#!/usr/bin/env python3
"""Fail fast when the packaged source tree and workflow drift apart."""
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
required = [
    "VERSION", "CMakeLists.txt", "README.md", "CHANGELOG.md",
    "tests/run_host_tests.py", "tests/web_engine_fixture_server.py",
    "tests/test_web_engine_native.c", "tests/test_web_engine_dispatch.c",
    "tests/test_visual_layout.c", "tests/test_xenonweb.c",
    "tests/test_xenonweb_layout.c", "tests/test_xenonscript.c",
    "include/x360browser/version.hpp",
    "engine/xenonweb/xw_dom.c", "engine/xenonweb/xw_css.c",
    "engine/xenonweb/xw_script.c", "engine/xenonweb/xw_layout.c",
    "platform/xbox360/xsdk/main.c", "platform/xbox360/xsdk/web_engine.c",
    "platform/xbox360/xsdk/CMakeLists.txt", "tools/build_xbox_shell.sh",
    ".github/workflows/build-xbox-engine.yml",
]
missing = [rel for rel in required if not (ROOT / rel).is_file() or (ROOT / rel).stat().st_size == 0]
if missing:
    print("FAIL: source archive is incomplete:", file=sys.stderr)
    for rel in missing:
        print(f"  - {rel}", file=sys.stderr)
    raise SystemExit(2)
version = (ROOT / "VERSION").read_text().strip()
if not version.startswith("2.3.0-"):
    raise SystemExit(f"FAIL: VERSION must identify 2.3.0 release, found {version!r}")
cmake = (ROOT / "CMakeLists.txt").read_text()
platform_cmake = (ROOT / "platform/xbox360/xsdk/CMakeLists.txt").read_text()
workflow = (ROOT / ".github/workflows/build-xbox-engine.yml").read_text()
build = (ROOT / "tools/build_xbox_shell.sh").read_text()
if "project(X360Browser VERSION 2.3.0" not in cmake:
    raise SystemExit("FAIL: portable CMake project version does not match VERSION")
version_header = (ROOT / "include/x360browser/version.hpp").read_text()
for definition in (
    "#define X360BROWSER_VERSION_MAJOR 2",
    "#define X360BROWSER_VERSION_MINOR 3",
    "#define X360BROWSER_VERSION_PATCH 0",
    '#define X360BROWSER_VERSION_STRING "2.3.0-release-hardening"',
):
    if definition not in version_header:
        raise SystemExit(f"FAIL: version header is stale: {definition}")
if "project(X360Browser VERSION 2.3.0" not in platform_cmake or "X360Browser 2.3.0 Release Hardening" not in platform_cmake:
    raise SystemExit("FAIL: Xbox CMake metadata is not updated to 2.3.0")
if "Build X360Browser 2.3.0 Release Hardening" not in workflow:
    raise SystemExit("FAIL: workflow title does not match the release version")
if "Locate project root (also supports a nested ZIP directory)" not in workflow:
    raise SystemExit("FAIL: workflow lacks robust project-root discovery")
if "Restore host test runner if only the runner file was omitted" not in workflow or "PYTHON_FALLBACK" not in workflow:
    raise SystemExit("FAIL: workflow lacks the missing-runner recovery path")
if "X360Browser-2.3.0-release-hardening-xbox" not in workflow:
    raise SystemExit("FAIL: workflow Xbox artifact name does not match the release version")
if "X360Browser 2.3.0-release-hardening" not in build:
    raise SystemExit("FAIL: build script status banner does not match the release version")
print(f"PASS: package integrity; {len(required)} required files present; version={version}")
