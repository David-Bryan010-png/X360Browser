# X360Browser 2.3.0-release-hardening — motor próprio XenonWeb

**Navegador homebrew experimental para Xbox 360 RGH/JTAG.** Esta entrega evolui o XenonWeb — motor de HTML/DOM, CSS e layout escrito para o próprio projeto — e adiciona o XenonScript, um interpretador pequeno e limitado para scripts inline. O projeto não usa NetSurf nem outro motor de navegador como renderizador principal.

> **Estado real:** código-fonte de desenvolvimento. Os testes de host passaram no ambiente desta entrega, mas este ZIP **não é um `.xex` validado**. A compilação PowerPC/xSDK e testes num Xbox 360 físico continuam pendentes. Não é compatível com toda a web moderna.

## O que existe nesta versão

- **XenonWeb DOM:** árvore HTML com limites explícitos de nós, atributos, profundidade e memória; entidades HTML comuns, atributos, tags void e conteúdo raw de `script`/`style`.
- **CSS próprio:** seletores de tag, classe, ID, descendente e filho direto; seletores de atributo; `:first-child`, `:last-child`, `:nth-child(n)`, `:checked`, `:disabled`, `:required`, `:selected`, `:link` e `:not()` simples; propriedades visuais básicas.
- **Layout visual próprio:** converte DOM/estilos em quadros usados pelo renderer do Xbox; inclui texto, links focáveis, estilos básicos, placeholders e caixas visuais para elementos não suportados. VisualLite permanece apenas como fallback.
- **XenonScript experimental:** interpreta um subconjunto de scripts inline e, agora, até dois scripts externos síncronos pequenos (4 KiB cada, MIME JavaScript reconhecido), com variáveis simples, expressões aritméticas/lógicas básicas, `if/else`, `document.getElementById`, `querySelector` simples, mudanças em `textContent`/atributos, `document.title`, `console.log` e `alert` de demonstração.
- **Interação limitada:** `onclick` inline em links pode rodar scripts suportados; mutações invalidam e recompõem o quadro visual sem reexecutar todos os scripts do documento.
- **Guardas contra entradas problemáticas:** limites de fonte, tokens, profundidade e instruções; sintaxe não suportada falha de forma controlada em vez de iniciar loops ilimitados.
- **Transporte e mídia de suporte:** NativePlus/libcurl e TLS para rede; cache/decodificação raster com limites; download/handoff experimental de alguns recursos de mídia é separado do motor de páginas.
- **Testes repetíveis:** `tests/run_host_tests.py` compila os módulos C com avisos estritos (`-Werror`) e testa DOM/CSS, script, layout, dispatch, rede e recursos com fixtures locais.

## O que ainda NÃO é compatível

- **XenonScript não é JavaScript completo.** Não implementa ECMAScript, parser/especificação completos, funções, loops gerais, closures, módulos, promises, timers, event loop, fetch/XHR, APIs web nem compatibilidade com frameworks. Scripts `async`, `defer`, `module`, `nomodule` e com `integrity` não são executados; o suporte externo é apenas experimental.
- **HTML/CSS continuam parciais:** folhas CSS externas pequenas são incorporadas de modo limitado, mas ainda não há layout completo de linhas/inline, flexbox/grid reais, posicionamento avançado, cascata/especificidade completa, formulários funcionais ou comportamento real de iframe.
- **Canvas/WebGL/WebAssembly/WebSockets/service workers:** não implementados.
- **Vídeo embutido, YouTube e jogos web modernos:** não garantidos e não implementados de ponta a ponta. Esses recursos exigem JavaScript real, APIs, canvas/WebGL, codecs e um pipeline de mídia ausentes.
- **NetSurf:** `netsurf_backend_stub.c` continua sendo um stub. Não é utilizado como motor principal.
- **XEX e hardware:** compilação PowerPC/xSDK e execução num Xbox 360 físico não foram validadas nesta entrega.

## Arquitetura própria

| Módulo | Função |
|---|---|
| `engine/xenonweb/xw_dom.c` | Parser HTML e árvore DOM limitada |
| `engine/xenonweb/xw_css.c` | Parser de CSS e seletor/estilos suportados |
| `engine/xenonweb/xw_script.c` | Interpretador XenonScript limitado e orçamento de instruções |
| `engine/xenonweb/xw_layout.c` | Estilos e DOM para quadros visuais, links e dispatch de `onclick` |
| `platform/xbox360/xsdk/visual_renderer.c` | Renderização dos quadros no alvo Xbox 360 |
| `platform/xbox360/xsdk/web_engine.c` | Transporte HTTP/TLS, descoberta de conteúdo e recursos; não é o motor de layout |
| `platform/xbox360/xsdk/visual_layout.c` | Fallback VisualLite legado |

Dependências de terceiros continuam em tarefas específicas como transporte, criptografia e decodificação raster. Elas não substituem o motor de HTML/CSS/script do projeto. Veja [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md), [`docs/XENONWEB-ENGINE.md`](docs/XENONWEB-ENGINE.md) e [`docs/XENONSCRIPT.md`](docs/XENONSCRIPT.md).

## Testar no computador

Requisitos: compilador C17, Python 3, CMake/C++ e `pkg-config` com libcurl para os testes de rede.

```sh
python3 tests/validate_project_integrity.py
python3 tests/run_host_tests.py
cmake -S . -B build -DX360BROWSER_BUILD_TESTS=ON -DCMAKE_BUILD_TYPE=Release
cmake --build build --parallel 2
ctest --test-dir build --output-on-failure
```

## Criar um XEX

O workflow está em [`.github/workflows/build-xbox-engine.yml`](.github/workflows/build-xbox-engine.yml) e o script de build em `tools/build_xbox_shell.sh`. Eles exigem toolchain/dependências xSDK para PowerPC. No GitHub, abra **Actions**, escolha **Build X360Browser 2.3.0 Release Hardening** e use **Run workflow**; baixe `X360Browser-2.3.0-release-hardening-xbox` somente se o job de cross-build passar. A existência dos arquivos de build não significa que um XEX tenha sido gerado; considere o executável pronto somente depois de workflow bem-sucedido e teste de arranque no console.

## Próximos marcos técnicos

1. Compilar com a toolchain PowerPC/xSDK e corrigir eventuais problemas específicos de ABI/memória.
2. Testar foco, âncoras, scripts e mutações no console real.
3. Ampliar XenonScript por partes testadas — sem fingir que um subset é ECMAScript completo.
4. Adicionar recálculo mais amplo de estilo/layout, formulário e eventos de DOM; criar testes de conformidade.
5. Implementar rasterização, decodificação e pipeline de mídia de forma incremental, dentro dos limites do hardware.

Ver [`docs/STATUS.md`](docs/STATUS.md) e [`docs/COMPATIBILITY-2.3.0-release-hardening.md`](docs/COMPATIBILITY-2.3.0-release-hardening.md) para a matriz atual.
