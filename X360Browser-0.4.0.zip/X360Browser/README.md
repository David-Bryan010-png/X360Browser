# X360Browser 0.4.0 — Web Engine Alpha

**X360Browser agora tem uma primeira engine nativa experimental para Xbox 360.** O shell `.xex` passou a usar libcurl (HTTP/HTTPS), Mbed TLS (TLS 1.2), um parser HTML leve e a renderização de texto da xSDK.

## O que esta etapa faz

- Faz requisições HTTP e HTTPS reais usando libcurl compilado para Xbox 360.
- Valida certificados HTTPS usando `cacert.pem`, que deve permanecer ao lado do `.xex`.
- Segue redirecionamentos, limita downloads HTML a 512 KiB e usa timeout de requisição.
- Extrai título da página, texto legível, quebras de blocos comuns e links `<a href>`.
- Permite digitar endereços com o teclado virtual do Xbox, abrir links e voltar no histórico.
- Executa a transferência de rede numa thread separada para manter a tela de carregamento ativa.
- Mantém a compilação do `.xex` automatizada por GitHub Actions, sem exigir compilador no celular.

## Limites reais da engine alpha

Esta versão **não é ainda um navegador moderno completo**. Não implementa layout CSS, execução JavaScript/DOM, imagens, SVG, áudio, vídeo, iframes, fontes web ou compatibilidade com aplicações SPA. A apresentação HTML é textual; as páginas complexas não ficarão iguais a um navegador de PC. O objetivo do salto 0.4.0 é conectar o Xbox à rede, buscar documentos reais, interpretar HTML básico e permitir navegação por links.

## Controles no Xbox 360

- **D-pad cima/baixo:** rolar texto ou selecionar links.
- **LB/RB:** subir ou descer uma tela.
- **A:** abrir teclado de endereço ou abrir link selecionado.
- **X:** alternar entre página e lista de links.
- **Y:** recarregar a URL atual.
- **B:** voltar no histórico.
- **Start:** abrir `https://example.com/`.
- **Back:** sair.

## Gerar o `.xex` usando apenas o celular + GitHub

1. Envie `X360Browser-0.4.0.zip` para a raiz do repositório GitHub.
2. Crie ou substitua `.github/workflows/build-xbox-engine.yml` pelo arquivo `build-xbox-engine.yml` fornecido junto deste pacote.
3. Abra **Actions → Build X360Browser Web Engine → Run workflow**.
4. Quando terminar em verde, baixe o artefato `X360Browser-0.4.0-web-engine`.

O artefato deve conter `X360Browser.xex`, `cacert.pem`, `README.txt` e os avisos de licença das bibliotecas. **Não remova `cacert.pem`**: ele é necessário para verificar certificados HTTPS. O relógio do console precisa estar correto. O `.xex` deve ser iniciado num ambiente que permita homebrew.

## Ferramentas e licenças de terceiros

- xSDK: <https://github.com/xenosworks/xsdk>
- libcurl/curl-xenon: <https://github.com/xenosworks/curl-xenon>
- Mbed TLS: <https://github.com/xenosworks/mbedtls-xenon>
- NetSurf (possível engine HTML/CSS futura): <https://www.netsurf-browser.org/>

O workflow baixa os projetos de terceiros e compila-os para `powerpc-xsdk-elf`. Os arquivos `LICENSE-*` são incluídos no artefato para manter os avisos correspondentes.
