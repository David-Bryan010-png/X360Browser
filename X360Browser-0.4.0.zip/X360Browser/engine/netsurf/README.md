# NetSurf — integração futura

NetSurf não faz parte do binário 0.4.0. Esta versão usa uma engine HTML textual pequena para dar o primeiro salto: fazer requisições reais, extrair texto e navegar por links no Xbox 360.

NetSurf continua sendo a opção planejada para substituir o parser textual por HTML/CSS layout real. A integração exige portar/configurar suas bibliotecas C (parserutils, hubbub, libcss, libdom, libnsutils, decodificadores de imagem e dependências), adaptar fetch/network ao ambiente xSDK, ligar o frontend ao rasterizador e testar RAM/tempo no hardware. A existência desta pasta não significa que NetSurf já esteja compilado.

Referências:
- https://www.netsurf-browser.org/
- https://github.com/netsurf-browser/netsurf
