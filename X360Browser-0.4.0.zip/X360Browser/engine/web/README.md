# Web engine alpha (0.4.0)

A engine nativa de Xbox é formada por `platform/xbox360/xsdk/web_engine.c/.h` nesta primeira versão para minimizar a superfície de portabilidade.

## Pipeline atual

1. Valida e normaliza o endereço HTTP/HTTPS na interface.
2. Usa `libcurl` para DNS, sockets, redirects, timeout e transporte HTTP.
3. Usa `mbedtls-xenon` para TLS 1.2, com verificação do certificado e hostname.
4. Limita o HTML recebido a 512 KiB.
5. Tokeniza marcações HTML comuns, ignora conteúdo de `script`/`style`, decodifica entidades frequentes e extrai título e texto.
6. Extrai até 64 links por página e resolve URLs absolutas, relativas à raiz e relativas ao diretório.
7. Desenha texto no framebuffer 720p através de `xsdk_text_draw` e permite scroll/link navigation com o controle.

## Limitações intencionais do primeiro marco

Isto é um renderer HTML textual, não um motor compatível com os padrões modernos. Não existe cascata/layout CSS, DOM mutável, JavaScript, imagens, fontes web, mídia, iframe ou layout box model. Sites com muito JavaScript terão conteúdo incompleto. A integração futura de NetSurf continua sendo a rota para HTML/CSS muito mais completo; essa porta exige adaptar e compilar o conjunto de bibliotecas do NetSurf para xSDK.
