#include "x360browser/profile_store.hpp"
#include "x360browser/url.hpp"

#include <cstdio>
#include <fstream>
#include <limits>
#include <sstream>
#include <string>
#include <utility>

namespace x360browser {
namespace {

std::string encode_field(const std::string& value) {
    static constexpr char hex[] = "0123456789ABCDEF";
    std::string out;
    out.reserve(value.size());
    for (unsigned char ch : value) {
        if ((ch >= 'A' && ch <= 'Z') || (ch >= 'a' && ch <= 'z') ||
            (ch >= '0' && ch <= '9') || ch == '-' || ch == '_' || ch == '.' || ch == '~') {
            out.push_back(static_cast<char>(ch));
        } else {
            out.push_back('%');
            out.push_back(hex[ch >> 4]);
            out.push_back(hex[ch & 0x0F]);
        }
    }
    return out;
}

int hex_value(char ch) {
    if (ch >= '0' && ch <= '9') return ch - '0';
    if (ch >= 'A' && ch <= 'F') return ch - 'A' + 10;
    if (ch >= 'a' && ch <= 'f') return ch - 'a' + 10;
    return -1;
}

bool decode_field(const std::string& value, std::string& out) {
    out.clear();
    out.reserve(value.size());
    for (std::size_t i = 0; i < value.size(); ++i) {
        if (value[i] != '%') { out.push_back(value[i]); continue; }
        if (i + 2 >= value.size()) return false;
        const int hi = hex_value(value[i + 1]);
        const int lo = hex_value(value[i + 2]);
        if (hi < 0 || lo < 0) return false;
        out.push_back(static_cast<char>((hi << 4) | lo));
        i += 2;
    }
    return true;
}

std::vector<std::string> split_tabs(const std::string& line) {
    std::vector<std::string> fields;
    std::size_t start = 0;
    while (true) {
        const std::size_t end = line.find('\t', start);
        fields.push_back(line.substr(start, end == std::string::npos ? std::string::npos : end - start));
        if (end == std::string::npos) break;
        start = end + 1;
    }
    return fields;
}

bool parse_size(const std::string& value, std::size_t& out) {
    if (value.empty()) return false;
    std::size_t result = 0;
    for (unsigned char ch : value) {
        if (ch < '0' || ch > '9') return false;
        const std::size_t digit = static_cast<std::size_t>(ch - '0');
        if (result > (std::numeric_limits<std::size_t>::max() - digit) / 10) return false;
        result = result * 10 + digit;
    }
    out = result;
    return true;
}

bool fail(std::string* error, const std::string& message) {
    if (error) *error = message;
    return false;
}

} // namespace

bool ProfileStore::save(const std::string& path, const ProfileData& profile, std::string* error) {
    std::string validation_error;
    if (!validate_settings(profile.settings, &validation_error)) return fail(error, validation_error);
    if (path.empty()) return fail(error, "Caminho do perfil vazio.");
    const std::string temporary = path + ".tmp";
    {
        std::ofstream file(temporary.c_str(), std::ios::binary | std::ios::trunc);
        if (!file) return fail(error, "Não foi possível criar o arquivo temporário do perfil.");
        file << "X360BROWSER_PROFILE\t2\n";
        file << "S\thomepage\t" << encode_field(profile.settings.homepage) << '\n';
        file << "S\tsearch_prefix\t" << encode_field(profile.settings.search_prefix) << '\n';
        file << "S\thistory_limit\t" << profile.settings.history_limit << '\n';
        file << "S\ttheme\t" << theme_name(profile.settings.theme) << '\n';
        file << "S\tconfirm_external_schemes\t" << (profile.settings.confirm_external_schemes ? 1 : 0) << '\n';
        const std::size_t max_history = profile.settings.history_limit;
        const std::size_t start = profile.history.size() > max_history ? profile.history.size() - max_history : 0;
        const std::size_t count = profile.history.size() - start;
        std::size_t position = profile.history_position >= start ? profile.history_position - start : 0;
        if (count == 0) position = 0;
        else if (position >= count) position = count - 1;
        file << "P\t" << position << '\n';
        const std::size_t max_bookmarks = profile.bookmarks.size() > 5000 ? 5000 : profile.bookmarks.size();
        for (std::size_t i = 0; i < max_bookmarks; ++i) {
            const Bookmark& bookmark = profile.bookmarks[i];
            if (is_http_url(bookmark.url))
                file << "B\t" << encode_field(bookmark.title) << '\t' << encode_field(bookmark.url) << '\n';
        }
        for (std::size_t i = start; i < profile.history.size(); ++i) {
            if (is_http_url(profile.history[i])) file << "H\t" << encode_field(profile.history[i]) << '\n';
        }
        file.flush();
        if (!file) {
            file.close();
            std::remove(temporary.c_str());
            return fail(error, "Falha ao gravar o perfil.");
        }
    }
    // POSIX rename replaces atomically. On platforms that refuse replacing an
    // existing file, stage the old profile as a backup and restore it on failure.
    if (std::rename(temporary.c_str(), path.c_str()) != 0) {
        const std::string backup = path + ".bak";
        std::remove(backup.c_str());
        const bool had_previous = std::rename(path.c_str(), backup.c_str()) == 0;
        if (std::rename(temporary.c_str(), path.c_str()) != 0) {
            if (had_previous) std::rename(backup.c_str(), path.c_str());
            std::remove(temporary.c_str());
            return fail(error, "Não foi possível finalizar a gravação do perfil.");
        }
        if (had_previous) std::remove(backup.c_str());
    }
    if (error) error->clear();
    return true;
}

bool ProfileStore::load(const std::string& path, ProfileData& profile, std::string* error) {
    std::ifstream file(path.c_str(), std::ios::binary);
    if (!file) return fail(error, "Perfil não encontrado ou sem permissão de leitura.");
    std::string line;
    if (!std::getline(file, line) || line != "X360BROWSER_PROFILE\t2")
        return fail(error, "Formato de perfil inválido ou versão não suportada.");

    ProfileData candidate;
    bool seen_homepage = false, seen_search = false, seen_history_limit = false, seen_theme = false;
    std::size_t lines = 0;
    while (std::getline(file, line)) {
        if (++lines > 20000) return fail(error, "O perfil excede o limite de registros.");
        if (line.size() > 16384) return fail(error, "Uma linha do perfil excede o tamanho permitido.");
        const auto fields = split_tabs(line);
        if (fields.empty()) continue;
        if (fields[0] == "S" && fields.size() == 3) {
            std::string value;
            if (fields[1] == "theme") {
                if (!parse_theme(fields[2], candidate.settings.theme)) return fail(error, "Tema inválido no perfil.");
                seen_theme = true;
                continue;
            }
            if (fields[1] == "history_limit") {
                std::size_t n = 0;
                if (!parse_size(fields[2], n)) return fail(error, "Limite de histórico inválido no perfil.");
                candidate.settings.history_limit = n;
                seen_history_limit = true;
                continue;
            }
            if (fields[1] == "confirm_external_schemes") {
                if (fields[2] != "0" && fields[2] != "1") return fail(error, "Opção de esquema externo inválida.");
                candidate.settings.confirm_external_schemes = fields[2] == "1";
                continue;
            }
            if (!decode_field(fields[2], value)) return fail(error, "Campo codificado inválido no perfil.");
            if (fields[1] == "homepage") { candidate.settings.homepage = value; seen_homepage = true; }
            else if (fields[1] == "search_prefix") { candidate.settings.search_prefix = value; seen_search = true; }
        } else if (fields[0] == "B" && fields.size() == 3) {
            std::string title, url;
            if (!decode_field(fields[1], title) || !decode_field(fields[2], url)) return fail(error, "Favorito corrompido no perfil.");
            if (!is_http_url(url)) return fail(error, "Favorito com URL inválida no perfil.");
            candidate.bookmarks.push_back({title, url});
            if (candidate.bookmarks.size() > 5000) return fail(error, "O perfil contém favoritos demais.");
        } else if (fields[0] == "H" && fields.size() == 2) {
            std::string url;
            if (!decode_field(fields[1], url) || !is_http_url(url)) return fail(error, "Histórico inválido no perfil.");
            candidate.history.push_back(url);
            if (candidate.history.size() > 10000) return fail(error, "O histórico do perfil é grande demais.");
        } else if (fields[0] == "P" && fields.size() == 2) {
            if (!parse_size(fields[1], candidate.history_position)) return fail(error, "Posição do histórico inválida.");
        } else {
            return fail(error, "Registro desconhecido ou malformado no perfil.");
        }
    }
    if (!seen_homepage || !seen_search || !seen_history_limit || !seen_theme)
        return fail(error, "O perfil não contém todas as configurações obrigatórias.");
    std::string validation_error;
    if (!validate_settings(candidate.settings, &validation_error)) return fail(error, validation_error);
    if (candidate.history.empty()) candidate.history_position = 0;
    else if (candidate.history_position >= candidate.history.size()) candidate.history_position = candidate.history.size() - 1;
    profile = std::move(candidate);
    if (error) error->clear();
    return true;
}

} // namespace x360browser
