#include "x360browser/browser_session.hpp"

#include <utility>

namespace x360browser {

BrowserSession::BrowserSession() : settings_(), state_(settings_.history_limit) {}

BrowserSession::BrowserSession(const BrowserSettings& settings)
    : settings_(settings), state_(settings.history_limit) {
    std::string ignored;
    if (!validate_settings(settings_, &ignored)) {
        settings_ = BrowserSettings{};
        state_.set_history_limit(settings_.history_limit);
    }
}

NavigationResult BrowserSession::navigate(const std::string& input) {
    const NormalizedInput normalized = normalize_input(input, settings_.search_prefix);
    if (!normalized) return {false, false, {}, normalized.error};
    state_.navigate(normalized.url);
    return {true, normalized.is_search, normalized.url, {}};
}

bool BrowserSession::home() {
    const NormalizedInput normalized = normalize_input(settings_.homepage, settings_.search_prefix);
    if (!normalized || normalized.is_search) return false;
    state_.navigate(normalized.url);
    return true;
}

bool BrowserSession::back() { return state_.back(); }
bool BrowserSession::forward() { return state_.forward(); }

bool BrowserSession::add_current_bookmark(const std::string& title, std::string* error) {
    if (state_.current_url().empty()) {
        if (error) *error = "Não existe página atual para favoritar.";
        return false;
    }
    return bookmarks_.add(state_.current_url(), title, error);
}

bool BrowserSession::open_bookmark(std::size_t index) {
    if (index >= bookmarks_.items().size()) return false;
    state_.navigate(bookmarks_.items()[index].url);
    return true;
}

bool BrowserSession::remove_bookmark(std::size_t index) {
    if (index >= bookmarks_.items().size()) return false;
    const std::string url = bookmarks_.items()[index].url;
    return bookmarks_.remove(url);
}

bool BrowserSession::set_homepage(const std::string& input, std::string* error) {
    const NormalizedInput normalized = normalize_input(input, settings_.search_prefix);
    if (!normalized || normalized.is_search || !is_http_url(normalized.url)) {
        if (error) *error = normalized.error.empty() ? "A página inicial deve ser um endereço, não uma pesquisa." : normalized.error;
        return false;
    }
    settings_.homepage = normalized.url;
    if (error) error->clear();
    return true;
}

bool BrowserSession::set_theme(Theme theme) {
    settings_.theme = theme;
    return true;
}

void BrowserSession::clear_history() noexcept { state_.clear_history(); }

bool BrowserSession::save_profile(const std::string& path, std::string* error) const {
    ProfileData profile;
    profile.settings = settings_;
    profile.bookmarks = bookmarks_.items();
    profile.history = state_.history();
    profile.history_position = state_.history_position();
    return ProfileStore::save(path, profile, error);
}

bool BrowserSession::load_profile(const std::string& path, std::string* error) {
    ProfileData profile;
    if (!ProfileStore::load(path, profile, error)) return false;
    settings_ = profile.settings;
    bookmarks_.replace(std::move(profile.bookmarks));
    state_ = BrowserState(settings_.history_limit);
    state_.restore_history(profile.history, profile.history_position);
    if (error) error->clear();
    return true;
}

const BrowserSettings& BrowserSession::settings() const noexcept { return settings_; }
const BrowserState& BrowserSession::state() const noexcept { return state_; }
BrowserState& BrowserSession::state() noexcept { return state_; }
const BookmarkStore& BrowserSession::bookmarks() const noexcept { return bookmarks_; }

} // namespace x360browser
