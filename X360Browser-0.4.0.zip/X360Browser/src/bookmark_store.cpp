#include "x360browser/bookmark_store.hpp"
#include "x360browser/url.hpp"

#include <algorithm>
#include <utility>

namespace x360browser {

bool BookmarkStore::add(const std::string& raw_url, const std::string& raw_title, std::string* error) {
    const NormalizedInput normalized = normalize_input(raw_url);
    if (!normalized || normalized.is_search || !is_http_url(normalized.url)) {
        if (error) *error = "Só é possível salvar um endereço HTTP/HTTPS válido como favorito.";
        return false;
    }
    const std::string url = normalized.url;
    const std::string title = raw_title.empty() ? url : raw_title;
    const auto found = std::find_if(items_.begin(), items_.end(), [&](const Bookmark& item) {
        return item.url == url;
    });
    if (found != items_.end()) {
        found->title = title;
        if (error) error->clear();
        return true;
    }
    items_.push_back({title, url});
    if (error) error->clear();
    return true;
}

bool BookmarkStore::remove(const std::string& url) {
    const auto old_size = items_.size();
    items_.erase(std::remove_if(items_.begin(), items_.end(), [&](const Bookmark& item) {
        return item.url == url;
    }), items_.end());
    return items_.size() != old_size;
}

bool BookmarkStore::contains(const std::string& url) const noexcept {
    return std::any_of(items_.begin(), items_.end(), [&](const Bookmark& item) { return item.url == url; });
}

const std::vector<Bookmark>& BookmarkStore::items() const noexcept { return items_; }
void BookmarkStore::clear() noexcept { items_.clear(); }
void BookmarkStore::replace(std::vector<Bookmark> bookmarks) {
    items_.clear();
    for (const Bookmark& bookmark : bookmarks) add(bookmark.url, bookmark.title, nullptr);
}

} // namespace x360browser
