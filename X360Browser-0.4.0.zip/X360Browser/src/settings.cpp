#include "x360browser/settings.hpp"
#include "x360browser/url.hpp"

namespace x360browser {

const char* theme_name(Theme theme) noexcept {
    switch (theme) {
        case Theme::Dark: return "dark";
        case Theme::Light: return "light";
        case Theme::HighContrast: return "high-contrast";
    }
    return "dark";
}

bool parse_theme(const std::string& name, Theme& theme) noexcept {
    if (name == "dark") { theme = Theme::Dark; return true; }
    if (name == "light") { theme = Theme::Light; return true; }
    if (name == "high-contrast") { theme = Theme::HighContrast; return true; }
    return false;
}

bool validate_settings(const BrowserSettings& settings, std::string* error) {
    const NormalizedInput homepage = normalize_input(settings.homepage, settings.search_prefix);
    if (!homepage || homepage.is_search || !is_http_url(homepage.url)) {
        if (error) *error = "A página inicial precisa ser um endereço HTTP/HTTPS válido.";
        return false;
    }
    if (!is_http_url(settings.search_prefix + "x")) {
        if (error) *error = "O endereço do mecanismo de pesquisa é inválido.";
        return false;
    }
    if (settings.history_limit == 0 || settings.history_limit > 10000) {
        if (error) *error = "O limite do histórico deve ficar entre 1 e 10000.";
        return false;
    }
    if (error) error->clear();
    return true;
}

} // namespace x360browser
