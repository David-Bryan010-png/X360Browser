#include "x360browser/browser_state.hpp"

#include <algorithm>
#include <utility>

namespace x360browser {

BrowserState::BrowserState(std::size_t history_limit)
    : history_limit_(history_limit == 0 ? 1 : history_limit) {}

void BrowserState::navigate(const std::string& url) {
    if (url.empty()) return;
    if (has_page_ && history_[position_] == url) return;

    if (has_page_ && position_ + 1 < history_.size()) {
        history_.erase(history_.begin() + static_cast<std::ptrdiff_t>(position_ + 1), history_.end());
    }
    history_.push_back(url);
    if (history_.size() > history_limit_) history_.erase(history_.begin());
    position_ = history_.size() - 1;
    has_page_ = true;
}

bool BrowserState::back() {
    if (!can_back()) return false;
    --position_;
    return true;
}

bool BrowserState::forward() {
    if (!can_forward()) return false;
    ++position_;
    return true;
}

void BrowserState::clear_history() noexcept {
    history_.clear();
    position_ = 0;
    has_page_ = false;
}

void BrowserState::set_history_limit(std::size_t limit) {
    history_limit_ = limit == 0 ? 1 : limit;
    if (history_.size() > history_limit_) {
        const std::size_t remove_count = history_.size() - history_limit_;
        history_.erase(history_.begin(), history_.begin() + static_cast<std::ptrdiff_t>(remove_count));
        if (has_page_) position_ = position_ >= remove_count ? position_ - remove_count : 0;
    }
    if (history_.empty()) { has_page_ = false; position_ = 0; }
    else {
        has_page_ = true;
        if (position_ >= history_.size()) position_ = history_.size() - 1;
    }
}

void BrowserState::restore_history(const std::vector<std::string>& history, std::size_t position) {
    history_.clear();
    for (const auto& url : history) {
        if (url.empty()) continue;
        if (!history_.empty() && history_.back() == url) continue;
        history_.push_back(url);
    }
    if (history_.size() > history_limit_) {
        const std::size_t excess = history_.size() - history_limit_;
        history_.erase(history_.begin(), history_.begin() + static_cast<std::ptrdiff_t>(excess));
        position = position >= excess ? position - excess : 0;
    }
    if (history_.empty()) {
        has_page_ = false;
        position_ = 0;
    } else {
        has_page_ = true;
        position_ = std::min(position, history_.size() - 1);
    }
}

const std::string& BrowserState::current_url() const noexcept {
    static const std::string empty;
    return has_page_ ? history_[position_] : empty;
}

bool BrowserState::can_back() const noexcept { return has_page_ && position_ > 0; }
bool BrowserState::can_forward() const noexcept { return has_page_ && position_ + 1 < history_.size(); }
const std::vector<std::string>& BrowserState::history() const noexcept { return history_; }
std::size_t BrowserState::history_position() const noexcept { return has_page_ ? position_ : 0; }
std::size_t BrowserState::history_limit() const noexcept { return history_limit_; }

} // namespace x360browser
