#include "x360browser/bookmark_store.hpp"
#include "x360browser/browser_session.hpp"
#include "x360browser/browser_state.hpp"
#include "x360browser/profile_store.hpp"
#include "x360browser/settings.hpp"
#include "x360browser/url.hpp"

#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <fstream>
#include <string>
#include <vector>

namespace {
int failures = 0;
int checks = 0;
void check(bool condition, const char* name) {
    ++checks;
    if (!condition) { std::cerr << "FAIL: " << name << '\n'; ++failures; }
    else std::cout << "PASS: " << name << '\n';
}
}

int main() {
    using x360browser::normalize_input;

    auto r = normalize_input("  https://example.com/page  ");
    check(static_cast<bool>(r) && r.url == "https://example.com/page" && !r.is_search, "trims a valid HTTPS URL");
    r = normalize_input("HTTPS://EXAMPLE.COM/Path");
    check(static_cast<bool>(r) && r.url == "https://example.com/Path", "normalizes scheme and hostname case");
    r = normalize_input("example.com/path?x=1#part");
    check(static_cast<bool>(r) && r.url == "https://example.com/path?x=1#part" && !r.is_search, "opens bare domain with path, query and fragment");
    r = normalize_input("localhost:3000");
    check(static_cast<bool>(r) && r.url == "https://localhost:3000", "accepts localhost with a valid port");
    r = normalize_input("localhost:3000/path");
    check(static_cast<bool>(r) && r.url == "https://localhost:3000/path", "accepts localhost port and path");
    r = normalize_input("192.168.1.12:8080/status");
    check(static_cast<bool>(r) && r.url == "https://192.168.1.12:8080/status", "accepts an IPv4 address and port");
    r = normalize_input("[2001:db8::1]:8443/index");
    check(static_cast<bool>(r) && r.url == "https://[2001:db8::1]:8443/index", "accepts bracketed IPv6 literal");
    r = normalize_input("https://[2001:::1]/");
    check(!static_cast<bool>(r), "rejects malformed IPv6 literals");
    r = normalize_input("como funciona o xbox 360");
    check(static_cast<bool>(r) && r.is_search && r.url == "https://www.google.com/search?q=como%20funciona%20o%20xbox%20360", "converts text into a Google search");
    r = normalize_input("café & pão");
    check(static_cast<bool>(r) && r.is_search && r.url.find("caf%C3%A9%20%26%20p%C3%A3o") != std::string::npos, "percent-encodes UTF-8 query text");
    r = normalize_input("segurança", "https://search.example/find?query=");
    check(static_cast<bool>(r) && r.url == "https://search.example/find?query=seguran%C3%A7a", "supports a configurable search provider prefix");
    r = normalize_input("javascript:alert(1)");
    check(!static_cast<bool>(r), "blocks javascript scheme");
    r = normalize_input("file:///etc/passwd");
    check(!static_cast<bool>(r), "blocks file scheme");
    r = normalize_input("ftp://example.com");
    check(!static_cast<bool>(r), "blocks FTP scheme");
    r = normalize_input("https://user:pass@example.com");
    check(!static_cast<bool>(r), "blocks embedded URL credentials");
    r = normalize_input("https://example.com:65536");
    check(!static_cast<bool>(r), "rejects ports above 65535");
    r = normalize_input("https://example..com");
    check(!static_cast<bool>(r), "rejects empty hostname labels");
    r = normalize_input("https://-example.com");
    check(!static_cast<bool>(r), "rejects hostname labels beginning with a hyphen");
    r = normalize_input("   ");
    check(!static_cast<bool>(r), "rejects empty input");
    r = normalize_input("http://");
    check(!static_cast<bool>(r), "rejects incomplete HTTP URL");
    r = normalize_input("anything", "javascript:");
    check(!static_cast<bool>(r), "rejects an invalid search-provider configuration");
    check(x360browser::is_http_url("http://example.com") && x360browser::is_http_url("https://example.com"), "recognizes HTTP and HTTPS URLs");
    check(!x360browser::is_http_url("javascript:alert(1)"), "is_http_url rejects non-web schemes");

    x360browser::BrowserState state(3);
    check(!state.back() && !state.forward(), "empty history has no navigation");
    state.navigate("https://a.example");
    state.navigate("https://b.example");
    state.navigate("https://c.example");
    check(state.can_back() && state.current_url() == "https://c.example", "tracks current page");
    check(state.back() && state.current_url() == "https://b.example", "goes back");
    check(state.forward() && state.current_url() == "https://c.example", "goes forward");
    state.back();
    state.navigate("https://d.example");
    check(!state.can_forward() && state.current_url() == "https://d.example", "new navigation clears forward history");
    state.navigate("https://e.example");
    check(state.history().size() == 3 && state.history().front() == "https://b.example", "limits history and discards oldest item");
    state.set_history_limit(2);
    check(state.history().size() == 2 && state.current_url() == "https://e.example", "shrinking history limit keeps current page");
    state.restore_history({"https://one.example", "https://two.example", "https://three.example"}, 1);
    check(state.current_url() == "https://two.example" && state.can_forward(), "restores current position within history");
    state.clear_history();
    check(state.history().empty() && state.current_url().empty(), "clears all navigation state");

    x360browser::BookmarkStore bookmarks;
    std::string error;
    check(!bookmarks.add("javascript:alert(1)", "bad", &error), "refuses unsafe bookmark schemes");
    check(bookmarks.add("https://example.com", "Example", &error), "adds a bookmark");
    check(bookmarks.contains("https://example.com"), "finds a saved bookmark");
    check(bookmarks.add("https://example.com", "Renamed", &error) && bookmarks.items().size() == 1 && bookmarks.items()[0].title == "Renamed", "updates a duplicate bookmark instead of duplicating it");
    check(bookmarks.remove("https://example.com") && !bookmarks.contains("https://example.com"), "removes a bookmark");

    x360browser::BrowserSession browser;
    auto nav = browser.navigate("xbox 360 browser");
    check(nav.accepted && nav.is_search && browser.state().current_url() == nav.url, "session accepts search and records it");
    check(browser.add_current_bookmark("Pesquisa"), "session favorites current navigation");
    check(browser.set_homepage("example.org", &error) && browser.settings().homepage == "https://example.org", "sets a normalized homepage");
    check(!browser.set_homepage("I want a homepage", &error), "does not accept a search as homepage");
    check(browser.set_theme(x360browser::Theme::HighContrast), "changes UI theme setting");
    browser.navigate("https://second.example");
    browser.back();
    check(browser.state().can_forward(), "session supports browser back/forward model");

    const std::string profile_path = "x360browser_test_profile.dat";
    check(browser.save_profile(profile_path, &error), "saves profile to disk");
    x360browser::BrowserSession loaded;
    check(loaded.load_profile(profile_path, &error), "loads saved profile");
    check(loaded.settings().homepage == "https://example.org" && loaded.settings().theme == x360browser::Theme::HighContrast, "restores settings");
    check(loaded.bookmarks().items().size() == 1 && loaded.bookmarks().items()[0].title == "Pesquisa", "restores bookmarks");
    check(loaded.state().current_url() == browser.state().current_url() && loaded.state().can_forward(), "restores history and its current position");

    const std::string bad_path = "x360browser_test_bad_profile.dat";
    {
        std::ofstream bad(bad_path.c_str(), std::ios::binary | std::ios::trunc);
        bad << "not a profile\n";
    }
    x360browser::ProfileData untouched;
    check(!x360browser::ProfileStore::load(bad_path, untouched, &error), "rejects corrupt profile header");
    std::remove(profile_path.c_str());
    std::remove(bad_path.c_str());

    if (failures) {
        std::cerr << failures << " of " << checks << " tests failed.\n";
        return EXIT_FAILURE;
    }
    std::cout << "All " << checks << " tests passed.\n";
    return EXIT_SUCCESS;
}
