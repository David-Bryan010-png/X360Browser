# Third-party component notices

The Xbox web-engine build downloads and statically links third-party components. Their sources and original license notices remain authoritative:

- **xSDK** — MIT license: https://github.com/xenosworks/xsdk/blob/main/LICENSE
- **curl / libcurl (curl-xenon)** — curl license: https://github.com/xenosworks/curl-xenon/blob/xenon/COPYING
- **Mbed TLS (mbedtls-xenon)** — Apache-2.0 OR GPL-2.0-or-later, as stated by upstream: https://github.com/xenosworks/mbedtls-xenon/blob/xenon/LICENSE
- **Mozilla CA certificate bundle** — the bundle is supplied by the Mbed TLS port; see its bundled notice and upstream certificate-bundle notice.

The build artifact includes the relevant xSDK, curl and Mbed TLS license files. The certificate bundle is runtime data and must remain beside `X360Browser.xex` for HTTPS certificate validation.
