# Changelog

## 0.4.0 — Web Engine Alpha

- Adicionada transferência HTTP/HTTPS real via libcurl portado para xSDK.
- Adicionado TLS 1.2 por Mbed TLS, com validação de certificado via `cacert.pem`.
- Adicionado parser HTML leve: título, texto, quebras de linha de elementos de bloco e extração de links.
- Adicionado teclado virtual Xbox para a barra de endereço, navegação por links, scroll e histórico simples.
- A rede funciona numa thread separada, com timeout de 25 segundos e limite de HTML de 512 KiB.
- O workflow gera um artefato que inclui `.xex`, certificados raiz e avisos de licença.
- Limite documentado: CSS, JavaScript, imagens, vídeo e engine NetSurf ainda não foram integrados.

## 0.3.0

- Adicionado shell nativo experimental para Xbox 360 e caminho de build via GitHub Actions.

## 0.2.0

- Fortalecido o núcleo C++ com URLs, histórico, favoritos, configurações e persistência.
