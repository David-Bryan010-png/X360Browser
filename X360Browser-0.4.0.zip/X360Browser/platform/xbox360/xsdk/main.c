#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <pthread.h>

#include "xsdk/gpu.h"
#include "xsdk/kernel.h"
#include "xsdk/log.h"
#include "xsdk/net.h"
#include "xsdk/present.h"
#include "xsdk/splash.h"
#include "xsdk/text.h"
#include "xsdk/xam.h"
#include "web_engine.h"

enum {
    SPLASH_MS = 900,
    BUFFERS = 2,
    SWAP_INTERVAL = 1,
    BEGIN_TIMEOUT_MS = 5000,
    CLEAR_ARGB = 0xFF101827,
    COLOR_WHITE = 0xFFFFFFFF,
    COLOR_MUTED = 0xFFB9C6D8,
    COLOR_BLUE = 0xFF70B7FF,
    COLOR_GOLD = 0xFFFFD166,
    COLOR_GREEN = 0xFF79D49A,
    COLOR_RED = 0xFFFF8585,
    VISIBLE_LINES = 20,
    PAGE_LINE_BYTES = 108,
    HISTORY_COUNT = 12
};

static const char DEFAULT_URL[] = "https://example.com/";

static WebEnginePage g_page;
static char g_current_url[WEB_ENGINE_URL_CAP] = "https://example.com/";
static char g_status[224] = "Starting browser engine...";
static pthread_mutex_t g_state_lock = PTHREAD_MUTEX_INITIALIZER;
static pthread_t g_fetch_thread;
static bool g_fetch_thread_valid;
static bool g_fetch_running;
static bool g_fetch_finished;
static bool g_page_loaded;
static bool g_engine_ready;
static bool g_show_links;
static size_t g_scroll_line;
static size_t g_selected_link;
static char g_history[HISTORY_COUNT][WEB_ENGINE_URL_CAP];
static size_t g_history_count;

static XAM_OVERLAPPED g_keyboard_overlapped;
static uint16_t g_keyboard_text[WEB_ENGINE_URL_CAP];
static uint16_t g_keyboard_default[WEB_ENGINE_URL_CAP];
static bool g_keyboard_active;

struct FetchTask {
    char url[WEB_ENGINE_URL_CAP];
};

static void copy_text(char *destination, size_t capacity, const char *source)
{
    if (capacity == 0U)
        return;
    if (source == NULL)
        source = "";
    (void)snprintf(destination, capacity, "%s", source);
}

static bool normalize_address(const char *input, char *output, size_t capacity)
{
    const char *start = input;
    size_t length;
    if (input == NULL || capacity < 9U)
        return false;
    while (*start != '\0' && (*start == ' ' || *start == '\t' || *start == '\r' || *start == '\n'))
        ++start;
    length = strlen(start);
    while (length > 0U && (start[length - 1U] == ' ' || start[length - 1U] == '\t' ||
                           start[length - 1U] == '\r' || start[length - 1U] == '\n'))
        --length;
    if (length == 0U || length >= capacity)
        return false;
    if (strstr(start, "://") == NULL) {
        if (length + 8U >= capacity)
            return false;
        (void)snprintf(output, capacity, "https://%.*s", (int)length, start);
    } else {
        (void)snprintf(output, capacity, "%.*s", (int)length, start);
    }
    if (strncasecmp(output, "http://", 7U) != 0 && strncasecmp(output, "https://", 8U) != 0)
        return false;
    return true;
}

static void history_push(const char *url)
{
    if (url == NULL || url[0] == '\0')
        return;
    if (g_history_count > 0U && strcmp(g_history[g_history_count - 1U], url) == 0)
        return;
    if (g_history_count == HISTORY_COUNT) {
        memmove(&g_history[0], &g_history[1], (HISTORY_COUNT - 1U) * sizeof(g_history[0]));
        --g_history_count;
    }
    copy_text(g_history[g_history_count], sizeof(g_history[g_history_count]), url);
    ++g_history_count;
}

static void *fetch_worker(void *argument)
{
    struct FetchTask *task = (struct FetchTask *)argument;
    WebEnginePage *downloaded = (WebEnginePage *)calloc(1U, sizeof(*downloaded));
    char error[192] = { 0 };
    int result = 0;

    if (downloaded != NULL)
        result = web_engine_fetch(task->url, downloaded, error, sizeof(error));
    else
        copy_text(error, sizeof(error), "Not enough memory for a web page");

    pthread_mutex_lock(&g_state_lock);
    if (result != 0 && downloaded != NULL) {
        g_page = *downloaded;
        g_page_loaded = true;
        if (error[0] != '\0')
            (void)snprintf(g_status, sizeof(g_status), "%s | %lu chars, %lu links",
                           error, (unsigned long)g_page.text_length,
                           (unsigned long)g_page.link_count);
        else
            (void)snprintf(g_status, sizeof(g_status), "HTTP %ld | %lu chars, %lu links",
                           g_page.http_status, (unsigned long)g_page.text_length,
                           (unsigned long)g_page.link_count);
        g_selected_link = 0U;
        g_scroll_line = 0U;
        g_show_links = false;
    } else {
        (void)snprintf(g_status, sizeof(g_status), "LOAD FAILED: %.170s",
                       error[0] != '\0' ? error : "unknown network error");
    }
    g_fetch_running = false;
    g_fetch_finished = true;
    pthread_mutex_unlock(&g_state_lock);

    free(downloaded);
    free(task);
    return NULL;
}

static void poll_fetch_thread(void)
{
    bool finished;
    pthread_mutex_lock(&g_state_lock);
    finished = g_fetch_finished;
    pthread_mutex_unlock(&g_state_lock);
    if (finished && g_fetch_thread_valid) {
        (void)pthread_join(g_fetch_thread, NULL);
        g_fetch_thread_valid = false;
        pthread_mutex_lock(&g_state_lock);
        g_fetch_finished = false;
        pthread_mutex_unlock(&g_state_lock);
    }
}

static void start_navigation(const char *address, bool remember_current)
{
    char normalized[WEB_ENGINE_URL_CAP];
    struct FetchTask *task;
    int thread_result;

    if (!g_engine_ready) {
        pthread_mutex_lock(&g_state_lock);
        copy_text(g_status, sizeof(g_status), "Network engine is unavailable: libcurl failed to initialize.");
        pthread_mutex_unlock(&g_state_lock);
        return;
    }
    if (!normalize_address(address, normalized, sizeof(normalized))) {
        pthread_mutex_lock(&g_state_lock);
        copy_text(g_status, sizeof(g_status), "Invalid URL. Use http:// or https://.");
        pthread_mutex_unlock(&g_state_lock);
        return;
    }

    pthread_mutex_lock(&g_state_lock);
    if (g_fetch_running) {
        copy_text(g_status, sizeof(g_status), "A page is already loading. Please wait.");
        pthread_mutex_unlock(&g_state_lock);
        return;
    }
    if (remember_current && g_page_loaded)
        history_push(g_current_url);
    copy_text(g_current_url, sizeof(g_current_url), normalized);
    memset(&g_page, 0, sizeof(g_page));
    g_page_loaded = false;
    (void)snprintf(g_status, sizeof(g_status), "Connecting to %.160s", normalized);
    g_fetch_running = true;
    g_fetch_finished = false;
    g_show_links = false;
    g_scroll_line = 0U;
    pthread_mutex_unlock(&g_state_lock);

    task = (struct FetchTask *)calloc(1U, sizeof(*task));
    if (task == NULL) {
        pthread_mutex_lock(&g_state_lock);
        g_fetch_running = false;
        copy_text(g_status, sizeof(g_status), "Not enough memory to start the request.");
        pthread_mutex_unlock(&g_state_lock);
        return;
    }
    copy_text(task->url, sizeof(task->url), normalized);
    thread_result = pthread_create(&g_fetch_thread, NULL, fetch_worker, task);
    if (thread_result != 0) {
        free(task);
        pthread_mutex_lock(&g_state_lock);
        g_fetch_running = false;
        (void)snprintf(g_status, sizeof(g_status), "Could not start network worker (%d).", thread_result);
        pthread_mutex_unlock(&g_state_lock);
        return;
    }
    g_fetch_thread_valid = true;
    xsdk_log_write("X360Browser: fetching %.160s", normalized);
}

static void keyboard_submit(void)
{
    char address[WEB_ENGINE_URL_CAP];
    size_t i;
    size_t out = 0U;
    for (i = 0U; i < WEB_ENGINE_URL_CAP - 1U && g_keyboard_text[i] != 0U; ++i) {
        uint16_t code = g_keyboard_text[i];
        if (code < 0x80U && code >= 0x20U)
            address[out++] = (char)code;
        else if (code == ' ')
            address[out++] = ' ';
        else
            address[out++] = '?';
    }
    address[out] = '\0';
    if (out > 0U)
        start_navigation(address, true);
    else {
        pthread_mutex_lock(&g_state_lock);
        copy_text(g_status, sizeof(g_status), "Address entry cancelled.");
        pthread_mutex_unlock(&g_state_lock);
    }
}

static void begin_address_keyboard(void)
{
    uint32_t user_index = XSDK_XAM_USER_NONE;
    char gamertag[XSDK_XAM_GAMERTAG_BYTES] = { 0 };
    uint32_t result;
    size_t i;
    char initial[WEB_ENGINE_URL_CAP];
    static const uint16_t title[] = { 'G','o',' ','t','o',' ','w','e','b',' ','a','d','d','r','e','s','s',0 };
    static const uint16_t description[] = { 'T','y','p','e',' ','a','n',' ','H','T','T','P',' ','o','r',' ','H','T','T','P','S',' ','U','R','L',0 };

    if (g_keyboard_active)
        return;
    pthread_mutex_lock(&g_state_lock);
    copy_text(initial, sizeof(initial), g_current_url);
    pthread_mutex_unlock(&g_state_lock);
    memset(g_keyboard_text, 0, sizeof(g_keyboard_text));
    memset(g_keyboard_default, 0, sizeof(g_keyboard_default));
    for (i = 0U; i < strlen(initial) && i < WEB_ENGINE_URL_CAP - 1U; ++i)
        g_keyboard_default[i] = (uint16_t)(unsigned char)initial[i];
    (void)xsdk_xam_signed_in_user(&user_index, gamertag);
    xsdk_xam_prepare(&g_keyboard_overlapped);
    result = xsdk_xam_keyboard(user_index, title, description, g_keyboard_default,
                               g_keyboard_text, WEB_ENGINE_URL_CAP, &g_keyboard_overlapped);
    result = xsdk_xam_returned(&g_keyboard_overlapped, result);
    if (result == ERROR_IO_PENDING) {
        g_keyboard_active = true;
    } else if (result == ERROR_SUCCESS) {
        keyboard_submit();
    } else {
        pthread_mutex_lock(&g_state_lock);
        (void)snprintf(g_status, sizeof(g_status), "Address keyboard failed: 0x%08X", (unsigned)result);
        pthread_mutex_unlock(&g_state_lock);
    }
}

static void poll_address_keyboard(void)
{
    uint32_t result;
    if (!g_keyboard_active)
        return;
    result = xsdk_xam_wait(&g_keyboard_overlapped, 0U, NULL);
    if (result == ERROR_IO_INCOMPLETE)
        return;
    g_keyboard_active = false;
    if (result == ERROR_SUCCESS)
        keyboard_submit();
    else {
        pthread_mutex_lock(&g_state_lock);
        copy_text(g_status, sizeof(g_status), "Address entry cancelled or unavailable.");
        pthread_mutex_unlock(&g_state_lock);
    }
}

static size_t visual_line_count(const char *text)
{
    size_t lines = 1U;
    size_t column = 0U;
    size_t i;
    if (text == NULL || text[0] == '\0')
        return 1U;
    for (i = 0U; text[i] != '\0'; ++i) {
        if (text[i] == '\n') {
            ++lines;
            column = 0U;
        } else if (++column >= PAGE_LINE_BYTES) {
            ++lines;
            column = 0U;
        }
    }
    return lines;
}

static void draw_scrolled_page_text(const char *text, size_t scroll)
{
    char line[PAGE_LINE_BYTES + 1U];
    size_t line_length = 0U;
    size_t line_number = 0U;
    size_t visible_line = 0U;
    size_t i;
    const int32_t y_start = 202;
    if (text == NULL)
        return;
    for (i = 0U;; ++i) {
        char c = text[i];
        bool end_line = c == '\0' || c == '\n' || line_length >= PAGE_LINE_BYTES;
        if (end_line) {
            line[line_length] = '\0';
            if (line_number >= scroll && visible_line < VISIBLE_LINES) {
                xsdk_text_draw(58, y_start + (int32_t)(visible_line * 20U), 1U, COLOR_WHITE, line);
                ++visible_line;
            }
            ++line_number;
            line_length = 0U;
            if (c == '\0')
                break;
            if (c == '\n')
                continue;
            --i;
            continue;
        }
        line[line_length++] = c;
    }
}

static void draw_link_list(const WebEnginePage *page, size_t first, size_t selected)
{
    size_t i;
    size_t end = first + VISIBLE_LINES;
    char line[WEB_ENGINE_LINK_LABEL_CAP + 24U];
    if (end > page->link_count)
        end = page->link_count;
    if (page->link_count == 0U) {
        xsdk_text_draw(64, 218, 1U, COLOR_MUTED, "No links were found in this page.");
        return;
    }
    for (i = first; i < end; ++i) {
        const WebEngineLink *link = &page->links[i];
        (void)snprintf(line, sizeof(line), "%c %02lu. %.104s",
                       i == selected ? '>' : ' ', (unsigned long)(i + 1U), link->label);
        xsdk_text_draw(60, 202 + (int32_t)((i - first) * 20U), 1U,
                       i == selected ? COLOR_GOLD : COLOR_WHITE, line);
    }
    xsdk_text_draw(64, 610, 1U, COLOR_MUTED, "A: OPEN LINK   X: RETURN TO PAGE   UP/DOWN: CHOOSE LINK");
}

static void draw_screen(uint32_t width, uint32_t height)
{
    uint32_t address = 0U;
    NTSTATUS present_status = xsdk_present_begin(&address, BEGIN_TIMEOUT_MS);
    char url_line[176];
    char title_line[176];
    char status_line[232];
    bool loading;
    bool loaded;
    bool show_links;
    uint32_t status_color;
    size_t scroll;
    size_t selected;
    size_t line_count;
    WebEnginePage *page = &g_page;

    if (!NT_SUCCESS(present_status)) {
        xsdk_log_write("X360Browser: present begin failed: 0x%08X", (unsigned)present_status);
        return;
    }
    xsdk_gpu_set_target(width, height);

    pthread_mutex_lock(&g_state_lock);
    loading = g_fetch_running;
    loaded = g_page_loaded;
    show_links = g_show_links;
    scroll = g_scroll_line;
    selected = g_selected_link;
    (void)snprintf(url_line, sizeof(url_line), "URL  %.160s", g_current_url);
    (void)snprintf(title_line, sizeof(title_line), "%.164s", loaded ? page->title : "X360Browser Web Engine");
    (void)snprintf(status_line, sizeof(status_line), "%.220s", g_status);
    status_color = loading ? COLOR_GOLD : COLOR_GREEN;
    if (!g_engine_ready || strncmp(status_line, "LOAD FAILED", 11U) == 0 ||
        strncmp(status_line, "HTTP 4", 6U) == 0 || strncmp(status_line, "HTTP 5", 6U) == 0)
        status_color = COLOR_RED;

    xsdk_text_draw(58, 25, 2U, COLOR_WHITE, "X360 BROWSER");
    xsdk_text_draw(58, 70, 1U, COLOR_BLUE, "ENGINE ALPHA 0.4  |  HTTP/HTTPS + HTML TEXT + LINKS");
    xsdk_text_draw(58, 95, 1U, COLOR_MUTED, url_line);
    xsdk_text_draw(58, 120, 1U, status_color, status_line);
    xsdk_text_draw(58, 151, 1U, COLOR_GOLD, title_line);

    if (loading) {
        xsdk_text_draw(64, 236, 2U, COLOR_WHITE, "Loading page...");
        xsdk_text_draw(64, 282, 1U, COLOR_MUTED, "Network worker is fetching HTML and checking HTTPS certificates.");
        xsdk_text_draw(64, 312, 1U, COLOR_MUTED, "The request has a 25-second maximum timeout.");
    } else if (!loaded) {
        xsdk_text_draw(64, 215, 2U, COLOR_WHITE, "Welcome to X360Browser");
        xsdk_text_draw(64, 258, 1U, COLOR_MUTED, "The first native web engine is now connected to the Xbox shell.");
        xsdk_text_draw(64, 285, 1U, COLOR_MUTED, "START: open example.com");
        xsdk_text_draw(64, 310, 1U, COLOR_MUTED, "A: enter a website with the Xbox on-screen keyboard");
        xsdk_text_draw(64, 335, 1U, COLOR_MUTED, "This alpha renders readable HTML text and extracts links.");
        xsdk_text_draw(64, 360, 1U, COLOR_MUTED, "CSS layout, JavaScript, images and video are not integrated yet.");
    } else if (show_links) {
        xsdk_text_draw(58, 181, 1U, COLOR_BLUE, "PAGE LINKS");
        draw_link_list(page, selected >= VISIBLE_LINES ? selected - VISIBLE_LINES + 1U : 0U, selected);
    } else {
        xsdk_text_draw(58, 181, 1U, COLOR_BLUE, "PAGE CONTENT");
        draw_scrolled_page_text(page->text, scroll);
        line_count = visual_line_count(page->text);
        (void)snprintf(status_line, sizeof(status_line), "Line %lu / %lu     Links: %lu",
                       (unsigned long)(scroll + 1U), (unsigned long)line_count,
                       (unsigned long)page->link_count);
        xsdk_text_draw(58, 610, 1U, COLOR_MUTED, status_line);
    }

    xsdk_text_draw(58, 650, 1U, COLOR_WHITE,
                   "A: ADDRESS/OPEN LINK   X: LINKS/PAGE   Y: RELOAD   B: BACK   START: HOME   BACK: EXIT");
    pthread_mutex_unlock(&g_state_lock);
    xsdk_gpu_resolve(address, width, height, CLEAR_ARGB);
    xsdk_present_end();
}

static void change_scroll(int direction)
{
    size_t total;
    pthread_mutex_lock(&g_state_lock);
    if (!g_page_loaded || g_show_links) {
        if (g_show_links && g_page.link_count > 0U) {
            if (direction < 0 && g_selected_link > 0U)
                --g_selected_link;
            else if (direction > 0 && g_selected_link + 1U < g_page.link_count)
                ++g_selected_link;
        }
        pthread_mutex_unlock(&g_state_lock);
        return;
    }
    total = visual_line_count(g_page.text);
    if (direction < 0) {
        if (g_scroll_line > 0U)
            --g_scroll_line;
    } else if (g_scroll_line + VISIBLE_LINES < total) {
        ++g_scroll_line;
    }
    pthread_mutex_unlock(&g_state_lock);
}

static void activate_selected_link(void)
{
    char url[WEB_ENGINE_LINK_URL_CAP];
    bool have_link = false;
    pthread_mutex_lock(&g_state_lock);
    if (g_show_links && g_selected_link < g_page.link_count) {
        copy_text(url, sizeof(url), g_page.links[g_selected_link].url);
        have_link = true;
    }
    pthread_mutex_unlock(&g_state_lock);
    if (have_link)
        start_navigation(url, true);
    else
        begin_address_keyboard();
}

static void go_back(void)
{
    char previous[WEB_ENGINE_URL_CAP];
    bool have_previous = false;
    pthread_mutex_lock(&g_state_lock);
    if (g_history_count > 0U) {
        --g_history_count;
        copy_text(previous, sizeof(previous), g_history[g_history_count]);
        have_previous = true;
    }
    pthread_mutex_unlock(&g_state_lock);
    if (have_previous)
        start_navigation(previous, false);
    else
        start_navigation(DEFAULT_URL, false);
}

static void run_loop(uint32_t width, uint32_t height)
{
    uint16_t previous_buttons = 0U;
    for (;;) {
        INPUT_STATE input = { 0 };
        bool xam_open;
        uint16_t buttons;
        poll_fetch_thread();
        poll_address_keyboard();
        xam_open = xsdk_system_ui_open();
        (void)XamInputGetState(0U, 0U, &input);
        buttons = input.gamepad.buttons;

        if (!xam_open && (buttons & INPUT_GAMEPAD_BACK) != 0U &&
            (previous_buttons & INPUT_GAMEPAD_BACK) == 0U)
            break;

        if (!xam_open && !g_keyboard_active) {
            if ((buttons & INPUT_GAMEPAD_DPAD_UP) != 0U &&
                (previous_buttons & INPUT_GAMEPAD_DPAD_UP) == 0U)
                change_scroll(-1);
            if ((buttons & INPUT_GAMEPAD_DPAD_DOWN) != 0U &&
                (previous_buttons & INPUT_GAMEPAD_DPAD_DOWN) == 0U)
                change_scroll(1);
            if ((buttons & INPUT_GAMEPAD_LEFT_SHOULDER) != 0U &&
                (previous_buttons & INPUT_GAMEPAD_LEFT_SHOULDER) == 0U) {
                pthread_mutex_lock(&g_state_lock);
                g_scroll_line = g_scroll_line > VISIBLE_LINES ? g_scroll_line - VISIBLE_LINES : 0U;
                pthread_mutex_unlock(&g_state_lock);
            }
            if ((buttons & INPUT_GAMEPAD_RIGHT_SHOULDER) != 0U &&
                (previous_buttons & INPUT_GAMEPAD_RIGHT_SHOULDER) == 0U) {
                pthread_mutex_lock(&g_state_lock);
                if (g_page_loaded) {
                    size_t lines = visual_line_count(g_page.text);
                    if (g_scroll_line + VISIBLE_LINES < lines) {
                        g_scroll_line += VISIBLE_LINES;
                        if (g_scroll_line + VISIBLE_LINES > lines)
                            g_scroll_line = lines > VISIBLE_LINES ? lines - VISIBLE_LINES : 0U;
                    }
                }
                pthread_mutex_unlock(&g_state_lock);
            }
            if ((buttons & INPUT_GAMEPAD_A) != 0U && (previous_buttons & INPUT_GAMEPAD_A) == 0U) {
                bool show_links;
                pthread_mutex_lock(&g_state_lock);
                show_links = g_show_links;
                pthread_mutex_unlock(&g_state_lock);
                if (show_links)
                    activate_selected_link();
                else
                    begin_address_keyboard();
            }
            if ((buttons & INPUT_GAMEPAD_X) != 0U && (previous_buttons & INPUT_GAMEPAD_X) == 0U) {
                pthread_mutex_lock(&g_state_lock);
                g_show_links = !g_show_links && g_page_loaded;
                pthread_mutex_unlock(&g_state_lock);
            }
            if ((buttons & INPUT_GAMEPAD_Y) != 0U && (previous_buttons & INPUT_GAMEPAD_Y) == 0U) {
                char current[WEB_ENGINE_URL_CAP];
                pthread_mutex_lock(&g_state_lock);
                copy_text(current, sizeof(current), g_current_url);
                pthread_mutex_unlock(&g_state_lock);
                start_navigation(current, false);
            }
            if ((buttons & INPUT_GAMEPAD_B) != 0U && (previous_buttons & INPUT_GAMEPAD_B) == 0U)
                go_back();
            if ((buttons & INPUT_GAMEPAD_START) != 0U && (previous_buttons & INPUT_GAMEPAD_START) == 0U)
                start_navigation(DEFAULT_URL, true);
        }

        previous_buttons = buttons;
        draw_screen(width, height);
    }
}

int main(void)
{
    NTSTATUS status;
    uint32_t width = 0U;
    uint32_t height = 0U;

    xsdk_log_write("X360Browser 0.4.0: native web engine starting.");
    g_engine_ready = web_engine_init() != 0;
    if (!g_engine_ready) {
        copy_text(g_status, sizeof(g_status), "libcurl initialization failed.");
        xsdk_log_write("X360Browser: curl_global_init failed.");
    } else {
        pthread_mutex_lock(&g_state_lock);
        copy_text(g_status, sizeof(g_status), "Engine ready. Fetching example.com...");
        pthread_mutex_unlock(&g_state_lock);
    }

    (void)xsdk_splash_show(SPLASH_MS);
    status = xsdk_gpu_open();
    if (!NT_SUCCESS(status)) {
        xsdk_log_write("X360Browser: xsdk_gpu_open failed: 0x%08X", (unsigned)status);
        if (g_engine_ready) web_engine_shutdown();
        return 1;
    }
    status = xsdk_present_open(XSDK_DISPLAY_720P, BUFFERS, SWAP_INTERVAL, &width, &height);
    if (!NT_SUCCESS(status)) {
        xsdk_log_write("X360Browser: xsdk_present_open failed: 0x%08X", (unsigned)status);
        (void)xsdk_gpu_close();
        if (g_engine_ready) web_engine_shutdown();
        return 1;
    }
    status = xsdk_text_open();
    if (!NT_SUCCESS(status)) {
        xsdk_log_write("X360Browser: xsdk_text_open failed: 0x%08X", (unsigned)status);
        xsdk_present_close();
        (void)xsdk_gpu_close();
        if (g_engine_ready) web_engine_shutdown();
        return 1;
    }

    xsdk_log_write("X360Browser: display is %ux%u", (unsigned)width, (unsigned)height);
    if (g_engine_ready) {
        /* The first navigation starts after the drawing loop is ready. */
        start_navigation(DEFAULT_URL, false);
    }
    run_loop(width, height);
    poll_fetch_thread();
    if (g_fetch_thread_valid) {
        (void)pthread_join(g_fetch_thread, NULL);
        g_fetch_thread_valid = false;
    }
    if (g_engine_ready) web_engine_shutdown();
    xsdk_text_close();
    xsdk_present_close();
    status = xsdk_gpu_close();
    if (!NT_SUCCESS(status))
        xsdk_log_write("X360Browser: xsdk_gpu_close failed: 0x%08X", (unsigned)status);
    xsdk_log_write("X360Browser: web engine exited.");
    return 0;
}
