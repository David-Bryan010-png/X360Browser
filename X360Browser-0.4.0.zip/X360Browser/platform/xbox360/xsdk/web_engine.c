#include "web_engine.h"

#include <curl/curl.h>
#include <ctype.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>

#define WEB_ENGINE_MAX_HTML (512U * 1024U)
#define HTML_ATTR_CAP 512U

typedef struct {
    char *data;
    size_t length;
    size_t capacity;
    int too_large;
} HtmlBuffer;

static size_t receive_html(char *incoming, size_t unit_size, size_t count, void *user_data)
{
    HtmlBuffer *buffer = (HtmlBuffer *)user_data;
    size_t bytes;
    size_t required;
    size_t next_capacity;
    char *next;

    if (unit_size != 0U && count > SIZE_MAX / unit_size)
        return 0U;
    bytes = unit_size * count;
    if (bytes == 0U)
        return 0U;
    if (bytes > WEB_ENGINE_MAX_HTML - buffer->length) {
        buffer->too_large = 1;
        return 0U;
    }

    required = buffer->length + bytes + 1U;
    if (required > buffer->capacity) {
        next_capacity = buffer->capacity == 0U ? 8192U : buffer->capacity;
        while (next_capacity < required) {
            if (next_capacity > WEB_ENGINE_MAX_HTML / 2U) {
                next_capacity = WEB_ENGINE_MAX_HTML + 1U;
                break;
            }
            next_capacity *= 2U;
        }
        if (next_capacity > WEB_ENGINE_MAX_HTML + 1U)
            next_capacity = WEB_ENGINE_MAX_HTML + 1U;
        next = (char *)realloc(buffer->data, next_capacity);
        if (next == NULL)
            return 0U;
        buffer->data = next;
        buffer->capacity = next_capacity;
    }

    memcpy(buffer->data + buffer->length, incoming, bytes);
    buffer->length += bytes;
    buffer->data[buffer->length] = '\0';
    return bytes;
}

static int ascii_equal_nocase(char left, char right)
{
    return tolower((unsigned char)left) == tolower((unsigned char)right);
}

static int starts_nocase(const char *text, const char *prefix)
{
    while (*prefix != '\0') {
        if (*text == '\0' || !ascii_equal_nocase(*text, *prefix))
            return 0;
        ++text;
        ++prefix;
    }
    return 1;
}

static const char *find_nocase(const char *text, const char *needle)
{
    const char *candidate;
    if (text == NULL || needle == NULL || *needle == '\0')
        return NULL;
    for (candidate = text; *candidate != '\0'; ++candidate) {
        if (starts_nocase(candidate, needle))
            return candidate;
    }
    return NULL;
}

static void set_error(char *error, size_t capacity, const char *message)
{
    if (error == NULL || capacity == 0U)
        return;
    (void)snprintf(error, capacity, "%s", message != NULL ? message : "Unknown error");
}

static void append_utf8(char *destination, size_t capacity, size_t *length, unsigned int codepoint)
{
    char encoded[4];
    size_t count = 0U;

    if (capacity == 0U || *length >= capacity - 1U)
        return;
    if (codepoint == 0U || (codepoint < 0x20U && codepoint != '\n' && codepoint != '\t'))
        codepoint = '?';
    if (codepoint <= 0x7FU) {
        encoded[count++] = (char)codepoint;
    } else if (codepoint <= 0x7FFU) {
        encoded[count++] = (char)(0xC0U | (codepoint >> 6U));
        encoded[count++] = (char)(0x80U | (codepoint & 0x3FU));
    } else if (codepoint <= 0xFFFFU) {
        encoded[count++] = (char)(0xE0U | (codepoint >> 12U));
        encoded[count++] = (char)(0x80U | ((codepoint >> 6U) & 0x3FU));
        encoded[count++] = (char)(0x80U | (codepoint & 0x3FU));
    } else if (codepoint <= 0x10FFFFU) {
        encoded[count++] = (char)(0xF0U | (codepoint >> 18U));
        encoded[count++] = (char)(0x80U | ((codepoint >> 12U) & 0x3FU));
        encoded[count++] = (char)(0x80U | ((codepoint >> 6U) & 0x3FU));
        encoded[count++] = (char)(0x80U | (codepoint & 0x3FU));
    }
    if (*length + count >= capacity)
        return;
    memcpy(destination + *length, encoded, count);
    *length += count;
    destination[*length] = '\0';
}

static unsigned int decode_entity(const char *entity, size_t length)
{
    size_t i;
    unsigned int value = 0U;
    unsigned int base = 10U;

    if (length == 0U)
        return 0U;
    if (entity[0] == '#') {
        i = 1U;
        if (i < length && (entity[i] == 'x' || entity[i] == 'X')) {
            base = 16U;
            ++i;
        }
        if (i == length)
            return 0U;
        for (; i < length; ++i) {
            unsigned int digit;
            unsigned char c = (unsigned char)entity[i];
            if (c >= '0' && c <= '9')
                digit = (unsigned int)(c - '0');
            else if (base == 16U && c >= 'a' && c <= 'f')
                digit = (unsigned int)(c - 'a' + 10);
            else if (base == 16U && c >= 'A' && c <= 'F')
                digit = (unsigned int)(c - 'A' + 10);
            else
                return 0U;
            if (digit >= base || value > (0x10FFFFU - digit) / base)
                return 0U;
            value = value * base + digit;
        }
        return value <= 0x10FFFFU ? value : 0U;
    }
    if (length == 3U && memcmp(entity, "amp", 3U) == 0) return '&';
    if (length == 2U && memcmp(entity, "lt", 2U) == 0) return '<';
    if (length == 2U && memcmp(entity, "gt", 2U) == 0) return '>';
    if (length == 4U && memcmp(entity, "quot", 4U) == 0) return '"';
    if (length == 4U && memcmp(entity, "apos", 4U) == 0) return '\'';
    if (length == 4U && memcmp(entity, "nbsp", 4U) == 0) return ' ';
    if (length == 5U && memcmp(entity, "mdash", 5U) == 0) return 0x2014U;
    if (length == 5U && memcmp(entity, "ndash", 5U) == 0) return 0x2013U;
    if (length == 6U && memcmp(entity, "hellip", 6U) == 0) return 0x2026U;
    if (length == 4U && memcmp(entity, "copy", 4U) == 0) return 0x00A9U;
    return 0U;
}

static void append_normalized(char *destination, size_t capacity, size_t *length,
                              unsigned int codepoint, int keep_newline)
{
    if (codepoint == '\r')
        return;
    if (codepoint == '\n' && keep_newline) {
        if (*length > 0U && destination[*length - 1U] != '\n' && *length < capacity - 1U) {
            destination[(*length)++] = '\n';
            destination[*length] = '\0';
        }
        return;
    }
    if (codepoint == '\t' || codepoint == '\n' || codepoint == ' ')
        codepoint = ' ';
    if (codepoint == ' ') {
        if (*length == 0U || destination[*length - 1U] == ' ' || destination[*length - 1U] == '\n')
            return;
    }
    append_utf8(destination, capacity, length, codepoint);
}

static void append_decoded_text(WebEnginePage *page, const char *text, size_t bytes,
                                int in_title, int active_link)
{
    size_t i = 0U;
    while (i < bytes) {
        unsigned int codepoint = (unsigned char)text[i];
        if (text[i] == '&') {
            size_t end = i + 1U;
            while (end < bytes && end - i <= 12U && text[end] != ';' &&
                   text[end] != '<' && !isspace((unsigned char)text[end]))
                ++end;
            if (end < bytes && text[end] == ';' && end > i + 1U) {
                unsigned int decoded = decode_entity(text + i + 1U, end - i - 1U);
                if (decoded != 0U) {
                    codepoint = decoded;
                    i = end + 1U;
                } else {
                    ++i;
                }
            } else {
                ++i;
            }
        } else if ((codepoint & 0xE0U) == 0xC0U && i + 1U < bytes &&
                   (((unsigned char)text[i + 1U]) & 0xC0U) == 0x80U) {
            codepoint = ((codepoint & 0x1FU) << 6U) | (((unsigned char)text[i + 1U]) & 0x3FU);
            i += 2U;
        } else if ((codepoint & 0xF0U) == 0xE0U && i + 2U < bytes &&
                   (((unsigned char)text[i + 1U]) & 0xC0U) == 0x80U &&
                   (((unsigned char)text[i + 2U]) & 0xC0U) == 0x80U) {
            codepoint = ((codepoint & 0x0FU) << 12U) |
                        ((((unsigned char)text[i + 1U]) & 0x3FU) << 6U) |
                        (((unsigned char)text[i + 2U]) & 0x3FU);
            i += 3U;
        } else if ((codepoint & 0xF8U) == 0xF0U && i + 3U < bytes &&
                   (((unsigned char)text[i + 1U]) & 0xC0U) == 0x80U &&
                   (((unsigned char)text[i + 2U]) & 0xC0U) == 0x80U &&
                   (((unsigned char)text[i + 3U]) & 0xC0U) == 0x80U) {
            codepoint = ((codepoint & 0x07U) << 18U) |
                        ((((unsigned char)text[i + 1U]) & 0x3FU) << 12U) |
                        ((((unsigned char)text[i + 2U]) & 0x3FU) << 6U) |
                        (((unsigned char)text[i + 3U]) & 0x3FU);
            i += 4U;
        } else {
            ++i;
        }

        if (in_title) {
            size_t title_length = strlen(page->title);
            append_normalized(page->title, sizeof(page->title), &title_length, codepoint, 0);
        } else {
            append_normalized(page->text, sizeof(page->text), &page->text_length, codepoint, 0);
            if (active_link >= 0 && (size_t)active_link < page->link_count) {
                WebEngineLink *link = &page->links[(size_t)active_link];
                size_t label_length = strlen(link->label);
                append_normalized(link->label, sizeof(link->label), &label_length, codepoint, 0);
            }
        }
    }
}

static void append_line_break(WebEnginePage *page)
{
    if (page->text_length == 0U)
        return;
    if (page->text[page->text_length - 1U] != '\n' && page->text_length < sizeof(page->text) - 1U) {
        page->text[page->text_length++] = '\n';
        page->text[page->text_length] = '\0';
    }
}

static int is_block_tag(const char *name)
{
    static const char *const block_tags[] = {
        "address", "article", "aside", "blockquote", "br", "dd", "div", "dl", "dt",
        "fieldset", "figcaption", "figure", "footer", "form", "h1", "h2", "h3", "h4",
        "h5", "h6", "header", "hr", "li", "main", "nav", "ol", "p", "pre", "section",
        "table", "tr", "ul"
    };
    size_t i;
    for (i = 0U; i < sizeof(block_tags) / sizeof(block_tags[0]); ++i) {
        if (strcmp(name, block_tags[i]) == 0)
            return 1;
    }
    return 0;
}

static int copy_attribute(const char *tag, size_t length, const char *wanted,
                          char *out, size_t out_capacity)
{
    size_t i = 0U;
    size_t wanted_length = strlen(wanted);
    while (i < length && !isspace((unsigned char)tag[i]) && tag[i] != '/')
        ++i;
    while (i < length) {
        size_t name_start;
        size_t name_length;
        size_t value_start;
        size_t value_length;
        char quote = '\0';
        while (i < length && (isspace((unsigned char)tag[i]) || tag[i] == '/'))
            ++i;
        name_start = i;
        while (i < length && !isspace((unsigned char)tag[i]) && tag[i] != '=' && tag[i] != '/')
            ++i;
        name_length = i - name_start;
        if (name_length == 0U) {
            if (i < length) ++i;
            continue;
        }
        while (i < length && isspace((unsigned char)tag[i])) ++i;
        if (i >= length || tag[i] != '=')
            continue;
        ++i;
        while (i < length && isspace((unsigned char)tag[i])) ++i;
        if (i < length && (tag[i] == '\'' || tag[i] == '"')) {
            quote = tag[i++];
            value_start = i;
            while (i < length && tag[i] != quote) ++i;
            value_length = i - value_start;
            if (i < length) ++i;
        } else {
            value_start = i;
            while (i < length && !isspace((unsigned char)tag[i]) && tag[i] != '>') ++i;
            value_length = i - value_start;
        }
        if (name_length == wanted_length &&
            strncasecmp(tag + name_start, wanted, wanted_length) == 0) {
            size_t copy_length = value_length < out_capacity - 1U ? value_length : out_capacity - 1U;
            memcpy(out, tag + value_start, copy_length);
            out[copy_length] = '\0';
            return 1;
        }
    }
    out[0] = '\0';
    return 0;
}

static void resolve_link_url(const char *base, const char *href,
                             char *out, size_t out_capacity)
{
    const char *scheme_end;
    const char *host_end;
    const char *last_slash;
    size_t origin_length;
    size_t base_directory_length;
    size_t scheme_length;

    if (out_capacity == 0U)
        return;
    out[0] = '\0';
    if (href == NULL || href[0] == '\0' || href[0] == '#')
        return;
    if (starts_nocase(href, "javascript:") || starts_nocase(href, "mailto:") ||
        starts_nocase(href, "data:"))
        return;
    if (starts_nocase(href, "http://") || starts_nocase(href, "https://")) {
        (void)snprintf(out, out_capacity, "%s", href);
        return;
    }
    scheme_end = strstr(base, "://");
    if (scheme_end == NULL) {
        (void)snprintf(out, out_capacity, "%s", href);
        return;
    }
    scheme_length = (size_t)(scheme_end - base);
    if (starts_nocase(href, "//")) {
        (void)snprintf(out, out_capacity, "%.*s:%s", (int)scheme_length, base, href);
        return;
    }
    host_end = strchr(scheme_end + 3, '/');
    origin_length = host_end == NULL ? strlen(base) : (size_t)(host_end - base);
    if (href[0] == '/') {
        (void)snprintf(out, out_capacity, "%.*s%s", (int)origin_length, base, href);
        return;
    }
    last_slash = strrchr(base, '/');
    if (last_slash == NULL || last_slash < scheme_end + 3) {
        base_directory_length = strlen(base);
        (void)snprintf(out, out_capacity, "%.*s/%s", (int)base_directory_length, base, href);
    } else {
        base_directory_length = (size_t)(last_slash - base + 1);
        (void)snprintf(out, out_capacity, "%.*s%s", (int)base_directory_length, base, href);
    }
}

static void parse_html(const char *html, size_t html_length, const char *base_url,
                       WebEnginePage *page)
{
    size_t i = 0U;
    int in_title = 0;
    int active_link = -1;

    while (i < html_length && page->text_length < sizeof(page->text) - 8U) {
        if (html[i] != '<') {
            size_t start = i;
            while (i < html_length && html[i] != '<') ++i;
            append_decoded_text(page, html + start, i - start, in_title, active_link);
            continue;
        }
        if (i + 3U < html_length && memcmp(html + i, "<!--", 4U) == 0) {
            const char *end_comment = strstr(html + i + 4U, "-->");
            if (end_comment == NULL) break;
            i = (size_t)(end_comment - html) + 3U;
            continue;
        }
        {
            size_t tag_start = i + 1U;
            size_t tag_end = tag_start;
            size_t name_start;
            size_t name_end;
            size_t name_length;
            int closing = 0;
            char name[32];
            char href[HTML_ATTR_CAP];
            char *tag_copy;
            size_t tag_length;
            while (tag_end < html_length && html[tag_end] != '>' && tag_end - tag_start < 2048U)
                ++tag_end;
            if (tag_end >= html_length || html[tag_end] != '>') {
                ++i;
                continue;
            }
            tag_length = tag_end - tag_start;
            tag_copy = (char *)malloc(tag_length + 1U);
            if (tag_copy == NULL) break;
            memcpy(tag_copy, html + tag_start, tag_length);
            tag_copy[tag_length] = '\0';
            name_start = 0U;
            while (name_start < tag_length && isspace((unsigned char)tag_copy[name_start])) ++name_start;
            if (name_start < tag_length && tag_copy[name_start] == '/') {
                closing = 1;
                ++name_start;
            }
            while (name_start < tag_length && (tag_copy[name_start] == '!' || tag_copy[name_start] == '?'))
                ++name_start;
            name_end = name_start;
            while (name_end < tag_length && (isalnum((unsigned char)tag_copy[name_end]) ||
                   tag_copy[name_end] == '-')) ++name_end;
            name_length = name_end - name_start;
            if (name_length >= sizeof(name)) name_length = sizeof(name) - 1U;
            memcpy(name, tag_copy + name_start, name_length);
            name[name_length] = '\0';
            {
                size_t n;
                for (n = 0U; name[n] != '\0'; ++n) name[n] = (char)tolower((unsigned char)name[n]);
            }

            if (!closing && (strcmp(name, "script") == 0 || strcmp(name, "style") == 0)) {
                char close_tag[40];
                const char *close_position;
                (void)snprintf(close_tag, sizeof(close_tag), "</%s", name);
                close_position = find_nocase(html + tag_end + 1U, close_tag);
                free(tag_copy);
                if (close_position == NULL) break;
                i = (size_t)(close_position - html);
                continue;
            }
            if (strcmp(name, "title") == 0) {
                in_title = closing ? 0 : 1;
            } else if (strcmp(name, "a") == 0) {
                if (closing) {
                    active_link = -1;
                } else if (page->link_count < WEB_ENGINE_LINK_COUNT &&
                           copy_attribute(tag_copy, tag_length, "href", href, sizeof(href))) {
                    WebEngineLink *link = &page->links[page->link_count];
                    resolve_link_url(base_url, href, link->url, sizeof(link->url));
                    if (link->url[0] != '\0') {
                        link->label[0] = '\0';
                        active_link = (int)page->link_count;
                        ++page->link_count;
                    }
                }
            }
            if (is_block_tag(name)) append_line_break(page);
            free(tag_copy);
            i = tag_end + 1U;
        }
    }

    while (page->text_length > 0U &&
           (page->text[page->text_length - 1U] == ' ' || page->text[page->text_length - 1U] == '\n')) {
        page->text[--page->text_length] = '\0';
    }
    if (page->title[0] == '\0')
        (void)snprintf(page->title, sizeof(page->title), "Web page");
    {
        size_t j;
        for (j = 0U; j < page->link_count; ++j) {
            if (page->links[j].label[0] == '\0')
                (void)snprintf(page->links[j].label, sizeof(page->links[j].label), "Link %u", (unsigned)(j + 1U));
        }
    }
}

int web_engine_init(void)
{
    return curl_global_init(CURL_GLOBAL_DEFAULT) == CURLE_OK ? 1 : 0;
}

void web_engine_shutdown(void)
{
    curl_global_cleanup();
}

int web_engine_fetch(const char *url, WebEnginePage *page, char *error, size_t error_capacity)
{
    CURL *curl;
    CURLcode result;
    HtmlBuffer html;
    long response_code = 0L;
    char curl_error[CURL_ERROR_SIZE];
    char *effective_url = NULL;

    if (page == NULL || url == NULL || url[0] == '\0') {
        set_error(error, error_capacity, "No URL provided");
        return 0;
    }
    memset(page, 0, sizeof(*page));
    memset(&html, 0, sizeof(html));
    memset(curl_error, 0, sizeof(curl_error));

    curl = curl_easy_init();
    if (curl == NULL) {
        set_error(error, error_capacity, "libcurl could not initialize");
        return 0;
    }

    (void)curl_easy_setopt(curl, CURLOPT_URL, url);
    (void)curl_easy_setopt(curl, CURLOPT_USERAGENT, "X360Browser/0.4.0 (Xbox 360; homebrew)");
    (void)curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, receive_html);
    (void)curl_easy_setopt(curl, CURLOPT_WRITEDATA, &html);
    (void)curl_easy_setopt(curl, CURLOPT_ERRORBUFFER, curl_error);
    (void)curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1L);
    (void)curl_easy_setopt(curl, CURLOPT_MAXREDIRS, 8L);
    (void)curl_easy_setopt(curl, CURLOPT_CONNECTTIMEOUT, 15L);
    (void)curl_easy_setopt(curl, CURLOPT_TIMEOUT, 25L);
    (void)curl_easy_setopt(curl, CURLOPT_LOW_SPEED_LIMIT, 1L);
    (void)curl_easy_setopt(curl, CURLOPT_LOW_SPEED_TIME, 10L);
    (void)curl_easy_setopt(curl, CURLOPT_ACCEPT_ENCODING, "identity");
    (void)curl_easy_setopt(curl, CURLOPT_CAINFO, "cacert.pem");
    (void)curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 1L);
    (void)curl_easy_setopt(curl, CURLOPT_SSL_VERIFYHOST, 2L);
    (void)curl_easy_setopt(curl, CURLOPT_PROTOCOLS_STR, "http,https");
    (void)curl_easy_setopt(curl, CURLOPT_REDIR_PROTOCOLS_STR, "http,https");

    result = curl_easy_perform(curl);
    (void)curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &response_code);
    (void)curl_easy_getinfo(curl, CURLINFO_EFFECTIVE_URL, &effective_url);
    page->http_status = response_code;
    page->html_bytes = html.length;

    if (result != CURLE_OK) {
        if (html.too_large)
            set_error(error, error_capacity, "Page exceeded the 512 KiB HTML download limit");
        else if (curl_error[0] != '\0')
            set_error(error, error_capacity, curl_error);
        else
            set_error(error, error_capacity, curl_easy_strerror(result));
        curl_easy_cleanup(curl);
        free(html.data);
        return 0;
    }
    if (html.data == NULL || html.length == 0U) {
        set_error(error, error_capacity, "The server returned an empty page");
        curl_easy_cleanup(curl);
        free(html.data);
        return 0;
    }

    parse_html(html.data, html.length, effective_url != NULL ? effective_url : url, page);
    if (page->text_length == 0U)
        (void)snprintf(page->text, sizeof(page->text), "The page loaded, but this basic renderer found no visible text.\nHTML: %lu bytes.",
                       (unsigned long)html.length);
    curl_easy_cleanup(curl);
    free(html.data);

    if (response_code >= 400L) {
        if (error != NULL && error_capacity > 0U)
            (void)snprintf(error, error_capacity, "HTTP %ld", response_code);
    } else if (error != NULL && error_capacity > 0U) {
        error[0] = '\0';
    }
    return 1;
}
