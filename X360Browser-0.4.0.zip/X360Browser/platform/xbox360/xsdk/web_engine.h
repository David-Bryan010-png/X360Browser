#ifndef X360BROWSER_WEB_ENGINE_H
#define X360BROWSER_WEB_ENGINE_H

#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

#define WEB_ENGINE_URL_CAP 512
#define WEB_ENGINE_TITLE_CAP 160
#define WEB_ENGINE_TEXT_CAP 32768
#define WEB_ENGINE_LINK_COUNT 64
#define WEB_ENGINE_LINK_URL_CAP 512
#define WEB_ENGINE_LINK_LABEL_CAP 112

typedef struct {
    char url[WEB_ENGINE_LINK_URL_CAP];
    char label[WEB_ENGINE_LINK_LABEL_CAP];
} WebEngineLink;

typedef struct {
    char title[WEB_ENGINE_TITLE_CAP];
    char text[WEB_ENGINE_TEXT_CAP];
    size_t text_length;
    WebEngineLink links[WEB_ENGINE_LINK_COUNT];
    size_t link_count;
    size_t html_bytes;
    long http_status;
} WebEnginePage;

int web_engine_init(void);
void web_engine_shutdown(void);
int web_engine_fetch(const char *url, WebEnginePage *page, char *error, size_t error_capacity);

#ifdef __cplusplus
}
#endif

#endif
