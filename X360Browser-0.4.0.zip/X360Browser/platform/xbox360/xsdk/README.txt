X360Browser 0.4.0 — Web Engine Alpha

Package files:
  X360Browser.xex  - Xbox 360 native executable
  cacert.pem       - trusted root certificate bundle required for HTTPS
  README.txt       - this file

Keep cacert.pem in the SAME directory as X360Browser.xex. The app uses it to
verify HTTPS certificates. The console's date/time should be correct.

Controls:
  D-pad Up/Down  - scroll the current page or select a link
  Left shoulder  - scroll up one screen
  Right shoulder - scroll down one screen
  A              - open the address keyboard, or open selected link in Links view
  X              - show page links / return to page
  Y              - reload current URL
  B              - go back in browser history
  Start          - open https://example.com/
  Back           - exit the app

What this alpha does:
  - downloads HTML over HTTP and HTTPS using libcurl
  - verifies HTTPS using TLS 1.2 and the supplied CA bundle
  - follows redirects with a bounded timeout and a 512 KiB download limit
  - extracts a page title, readable text, basic block breaks and anchor links
  - lets the user enter an address using the Xbox on-screen keyboard
  - follows extracted links and maintains a small back history

Not yet implemented:
  - CSS layout, JavaScript/DOM execution, images, SVG, audio or video
  - a full standards-compliant HTML rendering engine such as NetSurf
  - modern single-page applications or complex sites

This is the first network-enabled engine milestone, not a modern browser yet.
