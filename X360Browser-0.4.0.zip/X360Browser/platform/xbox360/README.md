# Xbox 360 platform

`xsdk/` contém o shell nativo e a engine web alpha destinados ao console.

- `main.c`: interface 720p, controle, teclado virtual, histórico e thread de navegação.
- `web_engine.c/.h`: download HTTP/HTTPS através de libcurl, TLS via Mbed TLS e extração de texto/título/links HTML.
- `CMakeLists.txt`: integra os projetos `mbedtls-xenon` e `curl-xenon` ao build PowerPC e usa `xsdk_add_xex()`.
- `../../tools/build_xbox_shell.sh`: constrói o toolchain, xSDK, bibliotecas de rede e o `.xex`.

A engine ainda não implementa CSS, JavaScript ou imagens. Veja `docs/STATUS.md` para os limites exatos.
