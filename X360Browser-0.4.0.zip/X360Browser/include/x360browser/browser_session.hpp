#pragma once

#include "x360browser/bookmark_store.hpp"
#include "x360browser/browser_state.hpp"
#include "x360browser/profile_store.hpp"
#include "x360browser/settings.hpp"
#include "x360browser/url.hpp"

#include <cstddef>
#include <string>

namespace x360browser {

struct NavigationResult {
    bool accepted = false;
    bool is_search = false;
    std::string url;
    std::string error;
};

// Platform-independent application logic. It does not fetch or render web pages.
class BrowserSession {
public:
    BrowserSession();
    explicit BrowserSession(const BrowserSettings& settings);

    NavigationResult navigate(const std::string& input);
    bool home();
    bool back();
    bool forward();
    bool add_current_bookmark(const std::string& title = {}, std::string* error = nullptr);
    bool open_bookmark(std::size_t index);
    bool remove_bookmark(std::size_t index);
    bool set_homepage(const std::string& input, std::string* error = nullptr);
    bool set_theme(Theme theme);
    void clear_history() noexcept;

    bool save_profile(const std::string& path, std::string* error = nullptr) const;
    bool load_profile(const std::string& path, std::string* error = nullptr);

    const BrowserSettings& settings() const noexcept;
    const BrowserState& state() const noexcept;
    BrowserState& state() noexcept;
    const BookmarkStore& bookmarks() const noexcept;

private:
    BrowserSettings settings_;
    BrowserState state_;
    BookmarkStore bookmarks_;
};

} // namespace x360browser
