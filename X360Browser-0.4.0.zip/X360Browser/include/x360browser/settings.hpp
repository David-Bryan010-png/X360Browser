#pragma once

#include <cstddef>
#include <string>

namespace x360browser {

enum class Theme { Dark, Light, HighContrast };

struct BrowserSettings {
    std::string homepage = "https://www.google.com/";
    std::string search_prefix = "https://www.google.com/search?q=";
    std::size_t history_limit = 100;
    Theme theme = Theme::Dark;
    bool confirm_external_schemes = true;
};

const char* theme_name(Theme theme) noexcept;
bool parse_theme(const std::string& name, Theme& theme) noexcept;
bool validate_settings(const BrowserSettings& settings, std::string* error = nullptr);

} // namespace x360browser
