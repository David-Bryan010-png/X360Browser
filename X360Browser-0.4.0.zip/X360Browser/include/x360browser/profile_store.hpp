#pragma once

#include "x360browser/bookmark_store.hpp"
#include "x360browser/settings.hpp"

#include <cstddef>
#include <string>
#include <vector>

namespace x360browser {

struct ProfileData {
    BrowserSettings settings;
    std::vector<Bookmark> bookmarks;
    std::vector<std::string> history;
    std::size_t history_position = 0;
};

// Small dependency-free profile format. Writes are staged to a temporary file
// before replacing the destination to reduce the chance of a corrupt profile.
class ProfileStore {
public:
    static bool save(const std::string& path, const ProfileData& profile, std::string* error = nullptr);
    static bool load(const std::string& path, ProfileData& profile, std::string* error = nullptr);
};

} // namespace x360browser
