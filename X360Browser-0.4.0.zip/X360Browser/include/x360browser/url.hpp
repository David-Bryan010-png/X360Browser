#pragma once

#include <string>

namespace x360browser {

struct NormalizedInput {
    std::string url;
    bool is_search = false;
    std::string error;

    explicit operator bool() const noexcept { return error.empty() && !url.empty(); }
};

// Convert user input to an HTTP(S) address or a search URL.
// search_prefix should end immediately before the encoded search query.
NormalizedInput normalize_input(
    const std::string& input,
    const std::string& search_prefix = "https://www.google.com/search?q=");

// True only for syntactically acceptable HTTP/HTTPS URLs. This is not a DNS or TLS check.
bool is_http_url(const std::string& url);

// Percent-encode UTF-8 bytes for use in a URL query component.
std::string percent_encode_query(const std::string& value);

} // namespace x360browser
