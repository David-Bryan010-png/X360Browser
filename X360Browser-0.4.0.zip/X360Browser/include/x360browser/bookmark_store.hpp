#pragma once

#include <string>
#include <vector>

namespace x360browser {

struct Bookmark {
    std::string title;
    std::string url;
};

class BookmarkStore {
public:
    bool add(const std::string& url, const std::string& title = {}, std::string* error = nullptr);
    bool remove(const std::string& url);
    bool contains(const std::string& url) const noexcept;
    const std::vector<Bookmark>& items() const noexcept;
    void clear() noexcept;
    void replace(std::vector<Bookmark> bookmarks);

private:
    std::vector<Bookmark> items_;
};

} // namespace x360browser
