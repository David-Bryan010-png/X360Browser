#pragma once

#include <cstddef>
#include <string>
#include <vector>

namespace x360browser {

class BrowserState {
public:
    explicit BrowserState(std::size_t history_limit = 100);

    // Record a successful navigation. Navigating after going back clears forward entries.
    void navigate(const std::string& url);
    bool back();
    bool forward();
    void clear_history() noexcept;
    void set_history_limit(std::size_t limit);
    void restore_history(const std::vector<std::string>& history, std::size_t position);

    const std::string& current_url() const noexcept;
    bool can_back() const noexcept;
    bool can_forward() const noexcept;
    const std::vector<std::string>& history() const noexcept;
    std::size_t history_position() const noexcept;
    std::size_t history_limit() const noexcept;

private:
    std::size_t history_limit_;
    std::vector<std::string> history_;
    std::size_t position_ = 0;
    bool has_page_ = false;
};

} // namespace x360browser
