# Interface prevista

Alvo de design: televisão 1280×720, texto legível à distância e foco grande o bastante para o gamepad.

## Elementos

- barra de endereço/pesquisa com botão para pesquisar;
- voltar, avançar, atualizar e parar;
- indicador de carregamento e mensagem de erro compreensível;
- área de página entregue pelo motor web;
- página inicial com Google, favoritos e histórico;
- menu de configurações (página inicial, tema, limpar histórico);
- teclado virtual navegável pelo gamepad e suporte opcional a teclado USB.

## Mapeamento sugerido

- Direcional/analógico: mover foco ou cursor;
- A: selecionar/ativar link;
- B: voltar/cancelar teclado virtual;
- X: abrir barra de endereço;
- Y: alternar favoritos;
- LB/RB: voltar/avançar;
- Start: abrir menu;
- Back: abrir/fechar painel de atalhos.

Este mapeamento é uma proposta de UX, não há código de entrada do Xbox nesta versão.
