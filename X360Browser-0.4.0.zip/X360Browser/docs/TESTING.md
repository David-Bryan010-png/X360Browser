# Testes da versão 0.2.0

## Executar

```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build --config Release
ctest --test-dir build --output-on-failure
```

## Cobertura atual

- URLs HTTP/HTTPS, normalização e hostname;
- domínios, caminhos, query, fragmento, portas, IPv4 e IPv6 entre colchetes;
- pesquisa UTF-8, mecanismo configurável e esquemas rejeitados;
- histórico, limite, voltar/avançar, restauração e limpeza;
- favoritos, atualizações e rejeição de URLs inseguras;
- configuração da página inicial e do tema;
- gravação/leitura de perfis, restauração de estado e rejeição de arquivo corrompido.

## Resultado local registrado

48 verificações do núcleo passaram no ambiente de desenvolvimento. Isso **não** cobre renderização web, rede, TLS, interface gráfica nem execução em Xbox 360.
