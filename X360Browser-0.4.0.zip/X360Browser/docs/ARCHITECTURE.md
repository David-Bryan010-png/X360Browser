# Arquitetura do X360 Browser 0.2.0

## Camadas

- `url`: converte a entrada em URL HTTP/HTTPS ou URL de pesquisa e rejeita esquemas não suportados.
- `BrowserState`: histórico, posição corrente, voltar/avançar e limite de entradas.
- `BookmarkStore`: favoritos com URLs validadas.
- `BrowserSettings`: página inicial, prefixo de busca, tema e limite de histórico.
- `ProfileStore`: arquivo de perfil versão 2, incluindo configurações, favoritos e histórico.
- `BrowserSession`: coordena as operações do núcleo sem saber como a tela ou rede são implementadas.
- `PageEngine`: contrato para carregar, cancelar, atualizar, rolar e obter a superfície renderizada. Nenhum adaptador concreto está incluído ainda.
- `platform/xbox360`: futura implementação do ciclo de vida `.xex`, vídeo, gamepad, armazenamento e rede do console.
- `ui`: futura interface de 1280×720 com barra de endereços, botões e área de página.

## Fluxo de navegação esperado

1. A UI recolhe texto do teclado virtual ou teclado USB.
2. `BrowserSession::navigate` converte o texto para endereço ou pesquisa.
3. A UI envia o URL aceito ao adaptador `PageEngine`.
4. O motor resolve host, faz a requisição, valida TLS, segue redirects e renderiza a página.
5. Callbacks reportam progresso/erro; a UI atualiza barra de status e superfície de pixels.
6. O perfil grava preferências e histórico no armazenamento escolhido.

O fluxo 3–5 ainda precisa de uma implementação real. O núcleo atual não tenta simular o resultado de uma página.

## Persistência

O perfil é um arquivo de texto versionado (`X360BROWSER_PROFILE`, versão 2). Os campos usam codificação percentual para impedir que quebras de linha e tabulações dentro de títulos/URLs quebrem a estrutura. Ao ler, o código valida configurações, limites, registros e URLs antes de substituir o estado atual.

A implementação atual usa streams de arquivos C++ padrão. O adaptador Xbox poderá mapear um caminho dentro do dispositivo USB/HD e, se a biblioteca padrão do toolchain não suportar essas operações, implementar um backend de armazenamento próprio.

## Segurança e limites

- A barra de endereço só aceita HTTP(S); esquemas `file:`, `javascript:`, FTP e semelhantes não são executados.
- URLs com usuário/senha na autoridade são rejeitadas.
- Validação sintática não confirma DNS, certificado TLS ou disponibilidade de um site.
- O motor futuro precisará separar conteúdo não confiável, atualizar certificados e impor limites de memória e tempo.
