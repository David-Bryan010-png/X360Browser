# Estado do X360Browser 0.4.0

## Verificado

- O núcleo C++ do projeto compila em host Linux e suas verificações automatizadas passam.
- O shell nativo Xbox baseado no xSDK foi compilado por GitHub Actions e o usuário confirmou que o `.xex` abriu no Xbox 360.
- `web_engine.c` compila no host com `-Wall -Wextra -Wconversion -Wshadow -Werror` contra os headers de libcurl disponíveis.
- Parser HTML executado em teste host: título, texto, entidades e URLs de links foram extraídos corretamente para uma página sintética.

## Implementado no código 0.4.0; precisa validar no console

- libcurl sobre sockets/DNS do xSDK e TLS 1.2 via `mbedtls-xenon`.
- Bundle de certificados `cacert.pem` empacotado ao lado do `.xex`.
- HTML text renderer, título, elementos de bloco, lista de links, teclado de endereço, scroll e histórico.
- Downloads com limite de 512 KiB e timeout de 25 segundos, em worker thread.

## Ainda não confirmado

- O workflow inteiro da engine alpha ainda precisa completar a compilação PowerPC com essas dependências, gerar o novo `.xex` e passar pelo teste de rede no Xbox físico.
- DNS/internet no console, verificação de certificados e teclado virtual precisam ser testados no hardware.

## Não implementado

- Layout CSS, DOM completo, JavaScript, imagens, SVG, áudio, vídeo e sites SPA.
- NetSurf ou outro motor HTML/CSS completo.
- Garantia de compatibilidade com sites modernos.

O termo “engine alpha” neste documento significa apenas a primeira pipeline de download e renderização textual HTML; não deve ser confundido com um browser moderno.
