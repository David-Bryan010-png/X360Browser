# Build do X360Browser 0.4.0 para Xbox 360

O build usa `xenosworks/xsdk` para criar um XEX PowerPC para um console homebrew compatível. O workflow GitHub Actions compila o toolchain e as bibliotecas no runner Linux; nenhum compilador precisa ser instalado no Android.

## GitHub Actions

1. Envie o arquivo `X360Browser-0.4.0.zip` para a raiz do repositório.
2. Crie `.github/workflows/build-xbox-engine.yml` usando o arquivo de workflow separado entregue com este pacote.
3. Abra Actions → Build X360Browser Web Engine → Run workflow.
4. Baixe `X360Browser-0.4.0-web-engine` quando a execução terminar verde.

O pacote deve incluir estes arquivos que precisam permanecer juntos:

- `X360Browser.xex`
- `cacert.pem` — obrigatório para a verificação TLS/HTTPS
- `README.txt`
- avisos de licença de xSDK, libcurl e Mbed TLS

## Instalação

Copie o `.xex` e `cacert.pem` para a mesma pasta num dispositivo de armazenamento acessível ao dashboard de homebrew. O console precisa conseguir executar XEX não assinado, e sua data/hora deve estar correta para validar certificados.

## Limites conhecidos

A engine 0.4.0 é um renderer textual: HTTP/HTTPS, texto HTML e links. CSS, JavaScript e imagens não estão integrados. Não anuncie navegação moderna até que esses subsistemas sejam adicionados e testados.
