# Changelog — X360 Web Total

## 0.11.0 — XUTE Compatibility Engine
- Adicionado X360 Universal Translation Engine (XUTE) ao fluxo real de carregamento HTML, com transformação in-place e limitada por tamanho.
- Mapeados elementos HTML5 selecionados para equivalentes suportados pelo parser semântico.
- Criada análise de CSS em blocos `<style>` e atributos inline, com contagem de regras, declarações, propriedades reconhecidas e `@`-rules.
- Adicionada detecção de scripts/handlers, imagens, vídeo, áudio, canvas, SVG e iframes.
- Criados helpers de conversão CSS para cores hex/nome e comprimentos em px.
- Adicionado XJST Scalar MicroVM, uma gramática isolada para expressões numéricas e booleanas internas; scripts de sites continuam desativados.
- Relatório XUTE incorporado à tela de diagnóstico.
- Adicionado suporte a `<base href>` na resolução de links e exibição do conteúdo `<noscript>`.
- Adicionados testes de alias HTML5, análise CSS, detecção de recursos, cores, dimensões e expressões seguras.
- Mantidos fail-closed para HTTPS e os limites honestos: ainda não há CSS cascade/layout, JavaScript de páginas, download/decodificação de imagens nem mídia HTML5.

## 0.10.0 — HTML Engine v2 / layout / MIME
- Substituído o parser HTML anterior por um leitor semântico limitado e com profundidade de pilha controlada.
- Entidades HTML nomeadas comuns (ndash, mdash, hellip, copyright, euro e aspas curvas) e referências numéricas são convertidas para UTF-8.
- Adicionados blocos para citações, linhas de tabela, controles de formulário, quebras e texto pré-formatado.
- Fechamento implícito básico para parágrafos, itens de lista e linhas de tabela reduz a corrupção por HTML omitido/malformado.
- Conteúdo ativo ou não renderizável (script, style, SVG, canvas, template, iframe, object e embed) não é executado nem interpretado como texto da página.
- Layout passa a contar caracteres UTF-8 e nunca corta um caractere multibyte no meio; <pre> conserva espaços, tabs e quebras de linha.
- Cliente HTTP aceita páginas de até 512 KiB, expõe Content-Type e diferencia HTML/XHTML, texto puro e MIME não suportado.
- Texto puro é mostrado como texto pré-formatado; imagens e arquivos binários não são mais analisados como se fossem HTML.
- Corrigida seleção gráfica de links longos: várias linhas e a anotação da URL contam como um único link.
- Ampliada a cobertura de testes de parser, UTF-8, tabelas, formulários, citações e elementos ativos.
- Permanecem sem implementação: CSS de layout, JavaScript, DOM dinâmico, carregamento de imagens raster, formulários interativos, TLS/HTTPS e mídia HTML5.

# Changelog — X360 Web Total

## 0.9.0 — Bing-inspired native browser UI
- Refeito o renderer nativo da Home: hierarquia visual de navegador, cabeçalho, barra de endereço, aba atual e campo de pesquisa central.
- Novo wallpaper vetorial local desenhado em C (céu, nuvens, sol e camadas de montanhas), sem baixar imagens e sem alocar texturas extras.
- Cartões de acesso rápido mostram apenas ações realmente mapeadas: START pesquisa, B histórico e Y preferências; rede/IP aparecem como estado informativo.
- Teclado QWERTY do controle foi integrado visualmente à nova Home, com seleção atual destacada.
- Página de documento ganhou cabeçalho de título/status mais claro e área de leitura consistente com a barra do navegador.
- Melhorias verificadas em resolução host 1280x720; o renderer escala para os modos de vídeo suportados pelo framebuffer.
- A página HTML de configuração continua sendo uma prévia auxiliar; a interface que aparece no console é desenhada pelo renderer C/Xenos.
- Nenhuma afirmação de CSS/JS completo, HTTPS/TLS, imagens raster ou HTML5 vídeo foi adicionada.


## 0.8.0 — Moonlight H.264 / Opus / Xenos media backend
- Incluído importador reproduzível, fixado ao commit upstream Xenonlight `ef26bf4dccd1f3a2ec02b712b30395763e920309`.
- Preserva `video.c`, `gpu.c`, `audio.c`, headers, hardware-thread shim e hwpthread, com a licença e avisos de shader.
- Adicionados alvos `make -C browser video-backend` e `make video-backend-info`; o ELF padrão permanece sem FFmpeg/Moonlight até a integração das dependências.
- Adicionado áudio Opus estéreo para sessões Moonlight, com saída para o DMA de áudio LibXenon.
- Documentada a diferença entre streaming H.264/Opus Moonlight e reprodução HTML5/MP4/WebM/HLS/DASH.

# Changelog — X360 Web Total

## 0.7.0 — Browser Shell / DNS / Search / Reboot
- Substituida a espera DNS por tempo real do timebase PowerPC: retries de 2,5 s e fallback entre dois servidores.
- Adicionada pesquisa por texto na barra, URL encoding e mecanismo Wiby para web classica.
- Interface redesenhada como navegador: barra de voltar/avancar/recarregar/inicio, abas, pesquisa, atalhos e area de conteudo.
- Adicionado historico para avancar com RB e voltar com LB/X.
- Adicionado reinicio do console com confirmacao explicita via xenon_smc_power_reboot().
- Atualizado User-Agent e Accept-Language pt-BR.
- Mantidos limites explicitos: sem motor JavaScript/CSS completo, imagens raster, audio/video e TLS.

# Changelog — X360 Web Total

## 0.6.0 — Revision Expanded 1
- Histórico de navegação persistente no USB, limitado pela configuração 8/16/24.
- Favoritos persistentes no USB, com tela para abrir/remover e limite de 12 URLs.
- Novo formato de listas versionado com CRC32, validação estrita de URL e arquivo backup `.bak`.
- Novo menu nativo com Favoritos e Diagnóstico, mantendo acesso às opções de rede/controle.
- Histórico acessível diretamente pela tecla B na Home, com abertura e remoção de entradas.
- Política HTTPS consolidada em módulo próprio e fail-closed; não há downgrade para HTTP.
- Testes adicionais de persistência, recuperação e política de segurança.
- Documentação atualizada sobre limites do motor e pré-requisitos reais de TLS.

## 0.6.0 — Boot Diagnostics & Fast Start
- Inicialização USB mais curta com polling contínuo.
- Diagnóstico explícito: `BOOT OK` não significa NAND verificada.
- Atualização no console permanece bloqueada sem HTTPS e verificação autenticada.

## 0.5.0 — Interface gráfica e recuperação USB
- Primeira interface gráfica nativa em C e framebuffer Xenos.
- Recuperação dos arquivos de configuração no USB com CRC32 e snapshots.
