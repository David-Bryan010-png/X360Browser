#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
UPSTREAM_URL="https://github.com/roderick-neuhoff/Xenonlight.git"
UPSTREAM_COMMIT="ef26bf4dccd1f3a2ec02b712b30395763e920309"
WORK="${XW_VIDEO_WORK_DIR:-${RUNNER_TEMP:-/tmp}/xwt-xenonlight-upstream}"
DEST="$ROOT/browser/video/moonlight"
FORCE="${1:-}"

command -v git >/dev/null 2>&1 || { echo "git e necessario para buscar o backend H.264." >&2; exit 2; }
mkdir -p "$(dirname "$WORK")"
if [[ -d "$WORK/.git" ]]; then
  git -C "$WORK" fetch --depth 1 origin "$UPSTREAM_COMMIT"
else
  rm -rf "$WORK"
  git clone --filter=blob:none --no-checkout "$UPSTREAM_URL" "$WORK"
  git -C "$WORK" fetch --depth 1 origin "$UPSTREAM_COMMIT"
fi
git -C "$WORK" checkout --detach "$UPSTREAM_COMMIT"
ACTUAL="$(git -C "$WORK" rev-parse HEAD)"
[[ "$ACTUAL" == "$UPSTREAM_COMMIT" ]] || { echo "Commit upstream inesperado: $ACTUAL" >&2; exit 3; }

FILES=(
  src/video.c src/video.h src/gpu.c src/gpu.h src/hw.c src/hw.h src/audio.c src/audio.h
  hwpthread/hwpthread.c hwpthread/include/pthread.h LICENSE
)
for file in "${FILES[@]}"; do
  [[ -s "$WORK/$file" ]] || { echo "Arquivo upstream ausente: $file" >&2; exit 4; }
done

mkdir -p "$DEST"
if [[ "$FORCE" == "--force" ]]; then
  rm -f "$DEST/video.c" "$DEST/video.h" "$DEST/gpu.c" "$DEST/gpu.h" \
        "$DEST/hw.c" "$DEST/hw.h" "$DEST/audio.c" "$DEST/audio.h" \
        "$DEST/LICENSE"
  rm -rf "$DEST/hwpthread"
fi

# Preserve reviewed local hardening changes unless --force was explicitly passed.
copy_if_missing() {
  local src="$1" dst="$2"
  if [[ ! -s "$dst" ]]; then cp "$src" "$dst"; fi
}
copy_if_missing "$WORK/src/video.c" "$DEST/video.c"
copy_if_missing "$WORK/src/video.h" "$DEST/video.h"
copy_if_missing "$WORK/src/gpu.c" "$DEST/gpu.c"
copy_if_missing "$WORK/src/gpu.h" "$DEST/gpu.h"
copy_if_missing "$WORK/src/hw.c" "$DEST/hw.c"
copy_if_missing "$WORK/src/hw.h" "$DEST/hw.h"
copy_if_missing "$WORK/src/audio.c" "$DEST/audio.c"
copy_if_missing "$WORK/src/audio.h" "$DEST/audio.h"
mkdir -p "$DEST/hwpthread/include"
copy_if_missing "$WORK/hwpthread/hwpthread.c" "$DEST/hwpthread/hwpthread.c"
copy_if_missing "$WORK/hwpthread/include/pthread.h" "$DEST/hwpthread/include/pthread.h"
copy_if_missing "$WORK/LICENSE" "$DEST/LICENSE"

if [[ ! -s "$DEST/UPSTREAM-REVISION.txt" ]]; then
  printf '%s\n' \
    "Repository: roderick-neuhoff/Xenonlight" \
    "Upstream commit: $UPSTREAM_COMMIT" \
    "Imported files: src/video.c, src/video.h, src/gpu.c, src/gpu.h, src/hw.c, src/hw.h, src/audio.c, src/audio.h, hwpthread/hwpthread.c, hwpthread/include/pthread.h" \
    "License: GNU GPL v3.0; see LICENSE." > "$DEST/UPSTREAM-REVISION.txt"
fi
cat > "$DEST/IMPORT-NOTICE.txt" <<NOTICE
This backend is based on Xenonlight, by roderick-neuhoff.
Source: https://github.com/roderick-neuhoff/Xenonlight
Pinned upstream commit: $UPSTREAM_COMMIT
The source is distributed under GNU GPL v3.0. Preserve LICENSE and attribution.
The precompiled GPU shader arrays are credited in gpu.c to Ced2911's
MPlayer libvo/vo_xenon.c port (GPLv2+).
NOTICE

echo "Backend Moonlight H.264/Xenos pronto em: $DEST"
echo "Fontes H.264/GPU/Opus importadas; veja README-INTEGRATION-PT-BR.md para dependencias."
echo "O modulo nao e um player HTML5 e nao foi ligado ao ELF principal."
