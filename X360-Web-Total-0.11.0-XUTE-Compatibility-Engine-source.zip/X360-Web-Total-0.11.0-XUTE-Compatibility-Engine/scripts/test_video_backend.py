#!/usr/bin/env python3
"""Regression checks for the optional Moonlight/Xenos H.264 backend."""
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
MODULE = ROOT / "browser/video/moonlight"


class VideoBackendImportTests(unittest.TestCase):
    def test_pinned_upstream_and_required_sources(self):
        script = (ROOT / "scripts/fetch_moonlight_video_backend.sh").read_text(encoding="utf-8")
        self.assertIn("roderick-neuhoff/Xenonlight.git", script)
        self.assertIn("ef26bf4dccd1f3a2ec02b712b30395763e920309", script)
        for item in (
            "src/video.c", "src/gpu.c", "src/video.h", "src/gpu.h",
            "src/hw.c", "src/hw.h", "src/audio.c", "src/audio.h",
            "hwpthread/hwpthread.c", "hwpthread/include/pthread.h", "LICENSE",
        ):
            self.assertIn(item, script)

    def test_decoder_and_xenos_renderer_sources_are_present(self):
        required = (
            "video.c", "gpu.c", "video.h", "gpu.h", "hw.c", "hw.h", "audio.c", "audio.h", "LICENSE",
            "UPSTREAM-REVISION.txt", "IMPORT-NOTICE.txt", "MODIFICATIONS.md",
            "AUDIO-MODIFICATIONS.md", "README-INTEGRATION-PT-BR.md",
        )
        for name in required:
            self.assertTrue((MODULE / name).is_file(), name)
        video = (MODULE / "video.c").read_text(encoding="utf-8")
        gpu = (MODULE / "gpu.c").read_text(encoding="utf-8")
        self.assertIn("avcodec_find_decoder(AV_CODEC_ID_H264)", video)
        self.assertIn("avcodec_send_packet", video)
        self.assertIn("video_submit(PDECODE_UNIT du)", video)
        self.assertIn("gpu_present", video)
        self.assertIn("Xe_DrawPrimitive", gpu)
        self.assertIn("Xe_ResolveInto", gpu)
        self.assertIn("RENDERER_CPU_HWCOLOR", video)
        audio = (MODULE / "audio.c").read_text(encoding="utf-8")
        self.assertIn("opus_multistream_decode", audio)
        self.assertIn("xenon_sound_submit", audio)
        self.assertIn("channelCount != 2", audio)
        self.assertIn("audio_has_surround", audio)
        hwpthread = MODULE / "hwpthread/hwpthread.c"
        hwpthread_header = MODULE / "hwpthread/include/pthread.h"
        self.assertTrue(hwpthread.is_file())
        self.assertTrue(hwpthread_header.is_file())
        self.assertIn('#include "include/pthread.h"', hwpthread.read_text(encoding="utf-8"))

    def test_backend_not_in_default_elf_sources(self):
        makefile = (ROOT / "browser/Makefile").read_text(encoding="utf-8")
        sources_line = next(line for line in makefile.splitlines() if line.startswith("SOURCES :="))
        self.assertNotIn("video/moonlight", sources_line)
        self.assertIn("video-backend:", makefile)
        self.assertIn("video-backend-info:", makefile)

    def test_docs_do_not_claim_html_video_support(self):
        doc = (ROOT / "docs/VIDEO-H264-MOONLIGHT.md").read_text(encoding="utf-8").lower()
        self.assertIn("não um player universal", doc)
        self.assertIn("não demultiplexa mp4", doc)
        self.assertIn("não implementa html audio", doc)
        self.assertIn("sincronização a/v para páginas web", doc)
        self.assertIn("gpl v3.0", doc)

    def test_video_module_is_not_claimed_in_usb_package(self):
        package = (ROOT / "scripts/package_usb.py").read_text(encoding="utf-8")
        self.assertIn('VERSION = "0.11.0"', package)
        self.assertIn('REVISION = "xute-html5-compat-microvm"', package)
        self.assertNotIn('"HTML5 video enabled"', package)


if __name__ == "__main__":
    unittest.main()
