X360 WEB TOTAL 0.11.0 — XUTE COMPATIBILITY ENGINE
Criador/referência: DVDBRN
Plataforma: Xbox 360 RGH/JTAG

INSTALACAO
1. Extraia o pacote USB na raiz de um dispositivo FAT32.
2. Preserve xenon.elf, XellLaunch2.xex e a pasta X360WebTotal.
3. Inicie pelo caminho XeLLLaunch2.xex -> XeLL Reloaded -> xenon.elf.
4. A configuracao, historico e favoritos ficam na pasta X360WebTotal do USB.

NOVIDADES 0.11.0
- XUTE: camada de compatibilidade HTML5 com conversao limitada de elementos semanticos.
- Analise de CSS em style blocks e atributos inline.
- Diagnostico de JavaScript, handlers, imagens, canvas, SVG, iframes e midia.
- XJST Scalar MicroVM: avaliador restrito para expressoes numericas e booleanas internas.
- Relatorio XUTE na tela de diagnostico.

LIMITES IMPORTANTES
Esta versao ainda NAO e um navegador moderno completo. HTTPS/TLS esta bloqueado; portanto, YouTube e a maioria dos sites atuais HTTPS nao abrem. JavaScript de paginas nao e executado. CSS e analisado, mas nao aplicado como cascade/layout; Flexbox e Grid nao sao renderizados. Imagens sao placeholders e audio/video HTML5 nao sao reproduzidos. O backend Moonlight e independente e nao equivale a suporte HTML5.

SEGURANCA
- Nenhum downgrade automatico de HTTPS para HTTP.
- Scripts externos nao sao executados.
- O programa nao le nem grava NAND, KV, firmware, flash ou bootloader.
- Reinicio do console, quando selecionado, exige confirmacao.

CONTROLES
Home: START navegar/pesquisar, Y preferencias, B historico, BACK sair.
Pagina: D-pad rolar/selecionar links, A abrir, LB/X voltar, RB avancar, START recarregar, B inicio.
Favoritos/historico: D-pad selecionar, A abrir, X remover, B voltar.

DIAGNOSTICO
Abra Preferencias -> Diagnostico para consultar USB, rede, IP, historico, favoritos, TLS, NAND e resumo XUTE.

A compilacao host nao confirma funcionamento no console. O ELF deve ser compilado com LibXenon e testado em Xbox 360 real.
