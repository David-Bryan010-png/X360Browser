# X360 Web Total 0.11.0 — XUTE Compatibility Engine

Navegador homebrew independente para Xbox 360 RGH/JTAG, escrito em C e compilado com LibXenon. Identidade do projeto: **DVDBRN**.

## Objetivo da versão

A versão 0.11.0 introduz o **X360 Universal Translation Engine (XUTE)** como uma camada nativa entre o HTML recebido e o parser do navegador. O XUTE faz uma passagem HTML5 limitada e sem expansão de memória, converte alguns elementos semânticos para equivalentes reconhecidos pelo parser e produz um relatório de compatibilidade por página.

A arquitetura também inclui o **XJST Scalar MicroVM**, um avaliador restrito de expressões numéricas/booleanas para uso interno confiável. Ele não executa JavaScript recebido de sites, não implementa DOM, eventos, rede, timers, módulos ou APIs do navegador.

## O que foi adicionado em 0.11.0

- XUTE integrado diretamente ao carregamento de HTML, antes do parser nativo.
- Suporte a `<base href>` para resolver links relativos e conteúdo `<noscript>` visível quando scripts estão desativados.
- Conversão limitada de `hgroup`, `dialog`, `search`, `menu`, `menuitem`, `picture`, `output`, `progress`, `meter`, `slot`, `mark`, `time`, `data`, `bdi` e `bdo` para elementos equivalentes aceitos pelo parser.
- Análise de `<style>` e de atributos `style`: contagem de regras, declarações, propriedades conhecidas e regras `@`.
- Diagnóstico de scripts, handlers inline, imagens, vídeo, áudio, canvas, SVG e iframes.
- Conversores básicos de cor CSS (nomes comuns e hex) e comprimentos `px` para a futura camada visual.
- XJST Scalar MicroVM com orçamento de tokens/profundidade e gramática restrita: números, booleanos, parênteses, operadores aritméticos, comparação e lógica.
- Relatório XUTE exibido na tela de diagnóstico e novos testes host.
- User-Agent atualizado para `X360WebTotal/0.11.0`.

## Matriz real de compatibilidade

| Tecnologia | Estado nesta versão |
|---|---|
| HTTP/1.x sobre lwIP | Implementado de forma experimental |
| DNS A/IN, polling e redirecionamentos limitados | Implementado |
| HTML semântico limitado | Nativo |
| Elementos HTML5 mapeados pelo XUTE | Traduzidos para o parser atual |
| CSS: análise sintática/diagnóstico | Emulado; não aplica cascade nem layout |
| CSS Flexbox/Grid/media queries | Não renderizados |
| JavaScript de páginas | Não executado |
| XJST scalar expressions | Subconjunto isolado para código interno confiável |
| Imagens raster | Detectadas; não baixadas nem decodificadas |
| SVG/Canvas/WebGL/WebAssembly | Não suportados |
| `<video>`/`<audio>` HTML | Não reproduzidos |
| HTTPS/TLS | Bloqueado até integração e validação criptográfica |
| YouTube e aplicações web modernas | Não compatíveis integralmente nesta versão |

**Importante:** o XUTE não transforma automaticamente qualquer site moderno em uma página funcional. Ele melhora a compatibilidade do HTML recebido, mas sites atuais normalmente dependem de HTTPS, JavaScript, CSS avançado, imagens, APIs e mídia. Essas camadas ainda não estão implementadas. Não existe downgrade silencioso de HTTPS para HTTP.

## Arquitetura

```text
URL / Navegação
      |
      v
HTTP/1.x + DNS (lwIP) ---- HTTPS: bloqueado com segurança
      |
      v
XUTE — X360 Universal Translation Engine
  |       |          |             |
  |       |          |             +-- Detecção de mídia e conteúdo não suportado
  |       |          +---------------- CSS analyzer / cores / dimensões px
  |       +--------------------------- HTML5 semantic alias translator
  +----------------------------------- Relatório de capacidades
      |
      v
HTML Semantic Parser -> Layout textual UTF-8 -> UI nativa / renderer Xenos

XJST Scalar MicroVM (isolada; não executa scripts dos sites)
```

## Segurança e limites de memória

- HTTPS permanece fail-closed: o navegador recusa a URL se não houver TLS com certificado, hostname, cadeia, relógio e entropia validados.
- Scripts e handlers de página não são executados.
- XUTE modifica o HTML in-place; não cria uma segunda cópia de 512 KiB.
- O cliente HTTP continua com limite de 512 KiB de corpo e `Content-Encoding: identity`.
- A árvore HTML, blocos e linhas visuais continuam limitados para evitar consumo descontrolado.
- A aplicação não acessa NAND, KV, flash, firmware ou bootloader.
- O backend Moonlight H.264/Opus continua opcional e independente; não é um player de páginas web.

## Testes host

```sh
cmake -S browser -B build-host -DCMAKE_BUILD_TYPE=Release -DCMAKE_C_FLAGS='-Wall -Wextra -Wpedantic -Werror'
cmake --build build-host --parallel 2
ctest --test-dir build-host --output-on-failure
python3 scripts/test_package_usb.py
python3 scripts/test_nand_boundary.py
python3 scripts/test_video_backend.py
```

## Compilação Xbox 360

```sh
cd browser
make clean all DEVKITXENON=/caminho/para/devkitxenon
```

Saída esperada: `browser/xenon.elf` (ELF32 big-endian PowerPC). O build host não substitui o cross-build LibXenon. O workflow de GitHub Actions executa validação e empacotamento quando o toolchain e os assets fixados estão disponíveis.

## Estado de validação

Os testes host desta revisão verificam os módulos C portáveis, o tradutor XUTE, o micro-VM restrito, HTML, URL, DNS, HTTP framing, layout, storage, recuperação e renderer em memória. A compilação LibXenon, o boot XeLL e a renderização Xenos em console físico precisam ser confirmados pelo workflow e por teste no Xbox 360.

## Referências internas

- `docs/ENGINE-STATUS.md` — matriz de recursos e estado real.
- `docs/TLS-HTTPS-ROADMAP.md` — pré-requisitos para HTTPS.
- `docs/VIDEO-H264-MOONLIGHT.md` — distinção entre Moonlight e vídeo HTML5.
- `docs/BOOT-FLOW.md` — fluxo XeLL → ELF.
