# X360 Web Total 0.11.0 — estado do motor XUTE

## XUTE 0.11.0

- Passagem HTML5 limitada integrada antes do parser semântico.
- `<base href>` é armazenado no documento e usado para resolver links relativos; conteúdo `<noscript>` fica visível porque scripts de página não são executados.
- Aliases in-place para hgroup, dialog, search, menu, menuitem, picture, output, progress, meter, slot, mark, time, data, bdi e bdo.
- Analisador CSS limitado para blocos `<style>` e atributos `style`; conta regras, declarações, propriedades reconhecidas e `@`-rules.
- Diagnóstico de script, handlers inline, imagem, vídeo, áudio, canvas, SVG e iframe.
- Conversores utilitários CSS de cor hexadecimal/nome e comprimento px.
- XJST Scalar MicroVM interpreta apenas expressões numéricas/booleanas de gramática restrita, limitada a 256 bytes, 128 tokens e profundidade 32.
- A transformação é in-place e não amplia o corpo recebido.

## O que o XUTE NÃO faz

- Não implementa árvore DOM genérica nem CSS cascade.
- Não aplica Flexbox, Grid, media queries, seletores ou posicionamento CSS ao renderer.
- Não executa JavaScript de páginas, handlers, frameworks, timers, fetch, promises, módulos ou APIs DOM.
- A microVM XJST é isolada e não é ECMAScript; não deve executar conteúdo externo.
- Não baixa nem decodifica imagens raster.
- Não executa SVG, Canvas, WebGL ou WebAssembly.
- Não reproduz áudio/vídeo de `<audio>`/`<video>`, MP4, WebM, HLS ou DASH.

## HTML e layout

- Parser semântico limitado: títulos, parágrafos, divisões, seções, artigos, navegação, listas, links, imagens como placeholders, citações, tabelas, pré-formatado e controles de formulário informativos.
- Entidades nomeadas comuns e referências numéricas são convertidas para UTF-8.
- Conteúdo de script, style, SVG, canvas, template, noscript, iframe, object e embed não é executado.
- Limites fixos de profundidade, blocos, texto por bloco e linhas visuais.
- Layout quebra palavras sem dividir sequências UTF-8; `<pre>` conserva espaços e linhas.

## Rede e segurança

- HTTP/1.x experimental por TCP raw lwIP; DNS A/IN por UDP com retries e polling.
- Redirecionamentos limitados a cinco saltos.
- Corpo HTTP máximo de 512 KiB; `Content-Encoding: identity`; gzip/deflate não são descomprimidos.
- HTTPS/TLS é recusado sem downgrade até existir transporte TLS validado, CSPRNG comprovado, relógio confiável, SNI, CA bundle, validação de cadeia/hostname e testes.
- A ausência de TLS bloqueia YouTube e a maioria dos sites atuais servidos apenas por HTTPS.

## Mídia

- Imagens de HTML são detectadas, mas continuam como placeholders; não existe scheduler de sub-recursos nem decoder raster integrado.
- O backend Moonlight contém código H.264/Opus/Xenos opcional para sessões Moonlight; não demultiplexa arquivos de páginas e não está integrado a `<video>`/`<audio>`.

## UI e dados locais

- UI nativa em C; apresentação gráfica usa backbuffer ARGB e conversão para tiles Xenos.
- Home, preferências, editor, loading, documento, favoritos, histórico, diagnóstico e confirmação de reinício.
- Favoritos/histórico e snapshots de configuração ficam no USB; sem API de NAND/flash.

## Verificação

- Testes host C cobrem XUTE, XJST, parser HTML, UTF-8, URL, HTTP framing, DNS, layout, storage, recuperação, segurança e renderização em memória.
- Testes host não compilam `main.c` contra o SDK LibXenon nem validam registradores/framebuffer no Xbox.
- Cross-build PowerPC, ELF, boot XeLL, controles, rede e teste físico continuam condicionados ao workflow/toolchain e ao console real.
