# Publicacao e atualizacao segura

O unico workflow ativo e `.github/workflows/build-x360-web-total.yml`. Ele detecta o proprio caminho por `GITHUB_WORKFLOW_REF`, compila e testa o projeto, prepara o pacote USB, gera o arquivo-fonte, manifesto e hashes SHA-256, envia artefatos e publica um pre-release no GitHub quando executado na branch principal.

## Estado do atualizador no console

A versao 0.11.0 nao baixa nem instala atualizacoes automaticamente no Xbox 360. O cliente de rede usa HTTP/lwIP e ainda nao tem TLS/HTTPS integrado. SHA-256 recebido por HTTP nao autentica a origem: um intermediario poderia substituir tanto o pacote quanto o hash. Por isso o manifesto publicado e informativo, nao um mecanismo de atualizacao confiavel no console.

Uma futura atualizacao automatica exigira, no minimo: TLS com validacao de certificado e hostname; manifesto assinado digitalmente com chave publica incorporada; verificacao de versao, tamanho e hash; download para uma pasta temporaria no USB; preservacao do payload anterior; substituicao atomica ou por launcher; e rollback. Nenhuma etapa pode escrever na NAND.

O botao Reiniciar o console usa a chamada de reinicializacao da SMC disponibilizada pela LibXenon, somente depois de uma confirmacao no navegador. Ele nao altera firmware da SMC nem acessa NAND.
