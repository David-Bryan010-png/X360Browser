# Fluxo de inicialização — X360 Web Total 0.11.0

Dashboard homebrew (por exemplo Aurora)
  → XellLaunch2.xex
  → XeLL Reloaded
  → busca e carrega xenon.elf do USB FAT32
  → inicializa Xenos/LibXenon, USB, armazenamento e lwIP
  → abre interface gráfica nativa e browser

`XellLaunch2.xex` é somente o launcher. `xenon.elf` é o executável do X360 Web Total.

O app salva `browser.ini` e pontos de recuperação em `X360WebTotal/` no USB. Não acessa nem grava a NAND.


## Interface 0.7.0
A tela nativa do navegador so aparece depois que XeLL transfere o controle ao `xenon.elf` e a inicializacao do framebuffer Xenos funciona. A tela textual de XeLL e anterior ao aplicativo e nao e a interface do navegador. Se o ELF iniciar mas o framebuffer nao for reconhecido, a versao usa o fallback de console textual.


## Modulo de video opcional 0.8.0
O pipeline Moonlight H.264/Xenos e um subsistema separado e nao participa da sequencia de boot principal. A importacao das fontes nao muda o arquivo `xenon.elf` ate que as dependencias sejam integradas e o alvo seja ativado deliberadamente.
