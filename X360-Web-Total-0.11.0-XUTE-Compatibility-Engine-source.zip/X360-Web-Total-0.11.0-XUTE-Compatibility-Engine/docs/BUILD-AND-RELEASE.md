# Build e release — X360 Web Total 0.11.0

O unico workflow ativo e `.github/workflows/build-x360-web-total.yml`. Ele detecta a fonte ou extrai um ZIP de fonte validado, executa CMake/CTest e testes Python, compila o ELF PowerPC pelo container LibXenon, valida ELF e XellLaunch2, monta o pacote USB, gera fonte/manifesto/SHA-256, armazena artefatos e publica um pre-release automaticamente na branch principal.

O workflow descobre seu proprio caminho usando `GITHUB_WORKFLOW_REF`; nao depende do nome do arquivo de workflow.

O resultado e `xenon.elf` (ELF32 big-endian PowerPC para XeLL), `XellLaunch2.xex` e configuracao/dados no USB. Isso nao produz um XEX de dashboard. Teste fisico no console permanece necessario.
