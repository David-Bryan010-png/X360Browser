# X360Browser 4.3.0

Navegador homebrew experimental para Xbox 360 RGH/JTAG. O código combina transporte HTTPS via libcurl/Mbed TLS com o motor próprio XenonWeb (DOM/CSS/layout), XenonScript (subconjunto JavaScript) e XenonMedia.

## Versão 4.3.0

A 4.3.0 corrige uma falha no workflow de compilação automática: o ZIP validado podia ser armazenado em uma subpasta do artefato, mas o job seguinte procurava apenas na raiz. Agora o ZIP de fonte e o checksum são publicados separados do log, localizados recursivamente, conferidos por SHA-256 e extraídos somente após validação de caminhos e versão. Também foi corrigido o título da interface que ainda mostrava a versão 3.3 e adicionado um teste de regressão para a estrutura dos artefatos. A análise adicional também inicializa explicitamente o buffer da caixa de endereço, limpa ponteiros temporários de estatísticas/código no parser global sem perder variáveis entre eventos da mesma página e protege parsers CSS contra valores nulos. A correção de renderização crítica da 4.2.0 permanece: o shader usa a localização correta de `TEXCOORD0` e não desativa o renderizador por esse contrato incompatível. A 4.1.0 reforçou a validação de URLs; a 4.0.0 ampliou capacidades limitadas de DOM/CSS/layout/script, negociação de compressão HTTP, cache de imagens e resolução experimental de certos links do YouTube para MP4. Esses recursos não fazem do projeto um Chromium nem garantem reprodução nativa de vídeo ou compatibilidade com jogos modernos.

**Isto ainda não é Chromium nem um navegador moderno completo.** Muitos sites atuais podem falhar. Jogos do Poki que exigem ECMAScript moderno, Canvas/WebGL, WebAssembly, timers e APIs avançadas continuam fora da compatibilidade garantida. Ver [`docs/COMPATIBILITY-4.3.0.md`](docs/COMPATIBILITY-4.3.0.md).

## Build

Use `.github/workflows/build-xex-from-zip.yml` ou `platform/xbox360/xsdk/CMakeLists.txt` com a toolchain Xbox 360/XSDK e as dependências Mbed TLS/libcurl compatíveis. A verificação host via CMake não substitui compilação PowerPC nem teste real no console.
