X360Browser 4.3.0

This is the Xbox 360 xSDK target. The main HTML/DOM/CSS/layout implementation is XenonWeb; bounded script execution is XenonScript; supported image/elementary media decoding lives in XenonMedia.

Raster decoding is exclusively first-party XenonMedia. No stb_image integration or third-party raster decoder fallback is linked in this version; unsupported profiles fail closed.

External audio/video player launch is DISABLED by default. Native compressed video/audio playback is not complete; do not assume MP4/H.264/AAC, YouTube, DRM or modern web games will work. The package includes X360Browser-video-config.txt (disabled by default) and X360Browser-bookmarks.txt.

The HTTP/HTTPS port still uses libcurl, Mbed TLS, a CA bundle and the xSDK/toolchain. These dependencies are disclosed in THIRD_PARTY_NOTICES.md; cryptography is not home-grown.

Host tests are not proof of a successful PowerPC build or physical-console operation. Follow docs/XBOX_BUILD.md for toolchain setup, then test on a console. Version 3.5.0 has not been cross-compiled or smoke-tested on hardware as part of its host validation.

If the screen still falls back to text, copy this XEX package in full and check the adjacent X360Browser.log. The 4.3.0 build corrects the GLSL texture-coordinate input location that previously made xSDK reject the visual renderer layout.
