#!/usr/bin/env python3
"""Regression test for the xSDK GLSL input-location/vertex-fetch contract."""
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
shader = (ROOT / "platform/xbox360/xsdk/page.vert").read_text(encoding="utf-8")
renderer = (ROOT / "platform/xbox360/xsdk/visual_renderer.c").read_text(encoding="utf-8")
cmake = (ROOT / "platform/xbox360/xsdk/CMakeLists.txt").read_text(encoding="utf-8")
build_script = (ROOT / "tools/build_xbox_shell.sh").read_text(encoding="utf-8")

checks = {
    "vertex position is location 0": re.search(r"layout\s*\(\s*location\s*=\s*0\s*\)\s*in\s+vec2\s+a_position", shader),
    "texture coordinates use xSDK location 2 (TEXCOORD0), not location 1 (COLOR)": re.search(r"layout\s*\(\s*location\s*=\s*2\s*\)\s*in\s+vec2\s+a_texcoord", shader),
    "vertex shader exports texture coordinates at stage location 0": re.search(r"layout\s*\(\s*location\s*=\s*0\s*\)\s*out\s+vec2\s+v_texcoord", shader),
    "pixel shader receives matching interpolation location 0": re.search(r"layout\s*\(\s*location\s*=\s*0\s*\)\s*in\s+vec2\s+v_texcoord", (ROOT / "platform/xbox360/xsdk/page.frag").read_text(encoding="utf-8")),
    "vertex layout binds POSITION0 as float2 at offset 0": re.search(r"\.usage\s*=\s*XSDK_USAGE_POSITION,\s*\.usage_index\s*=\s*0U,\s*\.format\s*=\s*XSDK_VERTEX_FLOAT2,\s*\n\s*\.stream\s*=\s*0U,\s*\.offset_bytes\s*=\s*0U", renderer),
    "vertex layout binds TEXCOORD0 as float2 at offset 8": re.search(r"\.usage\s*=\s*XSDK_USAGE_TEXCOORD,\s*\.usage_index\s*=\s*0U,\s*\.format\s*=\s*XSDK_VERTEX_FLOAT2,\s*\n\s*\.stream\s*=\s*0U,\s*\.offset_bytes\s*=\s*8U", renderer),
    "interleaved vertex stride remains 16 bytes": re.search(r"PAGE_VERTEX_STRIDE\s*=\s*16", renderer),
    "layout-failure diagnostic is actionable": "vertex layout rejected (expected POSITION0 + TEXCOORD0; check page.vert locations)" in renderer,
    "video configuration is copied beside XEX": '"${CMAKE_CURRENT_BINARY_DIR}/X360Browser-video-config.txt"' in cmake,
    "empty favorites database is created beside XEX": 'file(WRITE "${CMAKE_CURRENT_BINARY_DIR}/X360Browser-bookmarks.txt" "")' in cmake,
    "redundant pre-download cache removal is gone": '(void)remove(path);\n    memset(&sink, 0, sizeof(sink));' not in (ROOT / "platform/xbox360/xsdk/web_engine.c").read_text(encoding="utf-8"),
    "build script identifies version 4.3.0": "X360Browser 4.3.0:" in build_script,
}
failed = [name for name, result in checks.items() if not result]
for name, result in checks.items():
    print(f"{'PASS' if result else 'FAIL'}: {name}")
if failed:
    print(f"FAIL: {len(failed)} shader/runtime contract checks failed", file=sys.stderr)
    raise SystemExit(1)
print(f"PASS: all {len(checks)} Xbox shader/runtime contract checks")
