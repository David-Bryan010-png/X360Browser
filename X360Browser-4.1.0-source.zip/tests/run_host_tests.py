#!/usr/bin/env python3
"""Build and run the XenonWeb transport and dispatcher tests against a local HTTP fixture."""
from __future__ import annotations

import importlib.util
import os
import shlex
import subprocess
import tempfile
import threading
import time
from http.server import HTTPServer
from pathlib import Path

ROOT = Path(os.environ.get("X360BROWSER_PROJECT_DIR", Path(__file__).resolve().parents[1])).resolve()
ENGINE = ROOT / "platform/xbox360/xsdk/web_engine.c"
DISPATCH = ROOT / "platform/xbox360/xsdk/web_engine_dispatch.c"


def run(command: list[str], *, cwd: Path = ROOT, env: dict[str, str] | None = None) -> None:
    print("+", shlex.join(command), flush=True)
    subprocess.run(command, cwd=cwd, env=env, check=True)


def main() -> int:
    spec = importlib.util.spec_from_file_location("web_fixture", ROOT / "tests/web_engine_fixture_server.py")
    if spec is None or spec.loader is None:
        raise RuntimeError("Could not load test fixture server")
    fixture = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(fixture)

    env = os.environ.copy()
    env["NO_PROXY"] = "127.0.0.1,localhost"
    env["no_proxy"] = env["NO_PROXY"]
    env.pop("HTTP_PROXY", None)
    env.pop("http_proxy", None)
    env.pop("ALL_PROXY", None)
    env.pop("all_proxy", None)

    cflags = shlex.split(subprocess.check_output(["pkg-config", "--cflags", "libcurl"], text=True))
    libs = shlex.split(subprocess.check_output(["pkg-config", "--libs", "libcurl"], text=True))
    compiler = shlex.split(env.get("CC", "cc"))
    flags = ["-std=c17", "-O2", "-Wall", "-Wextra", "-Wshadow", "-Wconversion", "-Werror"]

    with tempfile.TemporaryDirectory(prefix="x360browser-host-tests-") as temporary:
        temp = Path(temporary)
        native_test = temp / "test_web_engine_native"
        dispatch_test = temp / "test_web_engine_dispatch"
        visual_test = temp / "test_visual_layout_legacy"
        xenon_dom_test = temp / "test_xenonweb_dom_css"
        xenon_layout_test = temp / "test_xenonweb_layout"
        xenon_script_test = temp / "test_xenonscript"
        xenon_media_test = temp / "test_xenonmedia"
        youtube_test = temp / "test_youtube_compatibility"
        run(compiler + flags + [
            "-I", str(ROOT / "platform/xbox360/xsdk"),
            str(ROOT / "tests/test_visual_layout.c"),
            str(ROOT / "platform/xbox360/xsdk/visual_layout.c"),
            "-o", str(visual_test)
        ])
        run(compiler + flags + [
            "-I", str(ROOT / "engine/xenonweb"),
            str(ROOT / "tests/test_xenonweb.c"),
            str(ROOT / "engine/xenonweb/xw_dom.c"),
            str(ROOT / "engine/xenonweb/xw_css.c"),
            "-o", str(xenon_dom_test)
        ])
        run(compiler + flags + [
            "-I", str(ROOT / "platform/xbox360/xsdk"),
            "-I", str(ROOT / "engine/xenonweb"),
            str(ROOT / "tests/test_xenonweb_layout.c"),
            str(ROOT / "engine/xenonweb/xw_dom.c"),
            str(ROOT / "engine/xenonweb/xw_css.c"),
            str(ROOT / "engine/xenonweb/xw_script.c"),
            str(ROOT / "engine/xenonweb/xw_layout.c"),
            str(ROOT / "platform/xbox360/xsdk/visual_layout.c"),
            "-o", str(xenon_layout_test)
        ])
        run(compiler + flags + [
            "-I", str(ROOT / "engine/xenonweb"),
            str(ROOT / "tests/test_xenonscript.c"),
            str(ROOT / "engine/xenonweb/xw_dom.c"),
            str(ROOT / "engine/xenonweb/xw_css.c"),
            str(ROOT / "engine/xenonweb/xw_script.c"),
            "-o", str(xenon_script_test)
        ])
        run(compiler + flags + [
            "-I", str(ROOT / "engine/xenonmedia"),
            str(ROOT / "tests/test_xenonmedia.c"),
            str(ROOT / "engine/xenonmedia/xm_media.c"),
            str(ROOT / "engine/xenonmedia/xm_playback.c"),
            "-o", str(xenon_media_test)
        ])
        run(compiler + flags + cflags + [
            "-I", str(ROOT / "engine/xenonweb"),
            str(ROOT / "tests/test_web_engine_native.c"), str(ENGINE),
            str(ROOT / "engine/xenonweb/xw_dom.c"), str(ROOT / "engine/xenonweb/xw_css.c"),
            str(ROOT / "engine/xenonweb/xw_script.c"),
            "-o", str(native_test)
        ] + libs)
        run(compiler + flags + cflags + [
            str(ROOT / "tests/test_web_engine_dispatch.c"), str(ENGINE), str(DISPATCH),
            "-o", str(dispatch_test)
        ] + libs)
        # Exercise the production URL classifier without making any live API request.
        run(compiler + flags + cflags + [
            "-DX360BROWSER_TESTING", "-ffunction-sections", "-fdata-sections",
            "-I", str(ROOT / "platform/xbox360/xsdk"),
            str(ROOT / "tests/test_youtube_compatibility.c"), str(ENGINE),
            "-Wl,--gc-sections", "-o", str(youtube_test)
        ] + libs)

        server = HTTPServer(("127.0.0.1", 18765), fixture.Handler)
        server_thread = threading.Thread(target=server.serve_forever, daemon=True)
        server_thread.start()
        try:
            # Give the listener a small, deterministic opportunity to start.
            for _ in range(50):
                try:
                    import urllib.request
                    with urllib.request.urlopen("http://127.0.0.1:18765/page.html", timeout=0.2) as response:
                        if response.status == 200:
                            break
                except Exception:
                    time.sleep(0.02)
            run([str(native_test)], cwd=temp, env=env)
            run([str(dispatch_test)], cwd=temp, env=env)
            run([str(youtube_test)], cwd=temp, env=env)
            run([str(visual_test)], cwd=temp, env=env)
            run([str(xenon_dom_test)], cwd=temp, env=env)
            run([str(xenon_layout_test)], cwd=temp, env=env)
            run([str(xenon_script_test)], cwd=temp, env=env)
            run([str(xenon_media_test)], cwd=temp, env=env)
        finally:
            server.shutdown()
            server.server_close()
            server_thread.join(timeout=1.0)

    print("PASS: all X360Browser XenonWeb + XenonScript + XenonMedia host tests", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
