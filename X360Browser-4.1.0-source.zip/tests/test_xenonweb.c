#include "../engine/xenonweb/xw_dom.h"
#include "../engine/xenonweb/xw_css.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static int failures;
static void check(int condition, const char *name)
{
    if (condition) printf("PASS: %s\n", name);
    else { printf("FAIL: %s\n", name); ++failures; }
}

int main(void)
{
    static const char html[] =
        "<!doctype html><html><head><title>Demo &amp; test</title>"
        "<style>body { color: #222222; } .card { background: #abc; padding: 12px; }"
        "#headline { color: red; font-size: 24px; } main .card a { font-weight: bold; }"
        "#selector-probe > p:first-child { color: orange; }"
        "#selector-probe > p.keep:last-child { background: #abc; }"
        "input[type=\"submit\"] { font-weight: bold; }"
        "p:not(.keep) { margin-bottom: 13px; }"
        "#advanced { margin: 1px 2px 3px 4px; padding: 5px 7px 9px 11px; border-width: 2px; border-color: rgb(5, 10, 15);"
        " line-height: 1.5; text-transform: uppercase; text-decoration: underline line-through; }"
        "input:enabled { color: rgba(5, 10, 15, 0.5); } p:nth-child(odd) { font-style: italic; }"
        "#empty:empty { background-color: rebeccapurple; }"
        "#important-probe { color: red !important; } .important-probe { color: blue !important; }"
        "#important-inline { color: red !important; }"
        "#padding-cascade { padding: 4px !important; padding-left: 11px; }"
        "#padding-cascade-side { padding: 4px; padding-left: 11px !important; }"
        "#responsive { color: #111111; } @media screen and (max-width: 700px) { #responsive { color: orange; } }"
        "@media screen and (min-width: 1000px) { #responsive { background-color: teal; } }"
        ".flex-probe { display: flex; flex-direction: row; flex-wrap: wrap; gap: 18px; justify-content: space-between; }"
        "#type-mix p:first-of-type { color: purple; } #type-mix p:nth-of-type(2) { color: orange; }"
        ".grid-probe { display:grid; grid-template-columns:repeat(2, 1fr); gap:12px; }"
        "#width-probe { width:50%; min-width:80px; max-width:240px; }"
        "#center-probe { width:300px; max-width:300px; margin:0 auto; }</style>"
        "<script>if (a < b) { x = '<tag>'; }</script></head>"
        "<body><main><div id='hero' class='card active' style='text-align:center;color:blue'>"
        "<h1 id='headline'>A &lt; B</h1><p class='copy'>First &nbsp; paragraph</p>"
        "<a href='/play'>Start game</a><img src='hero.png' alt='Hero'></div>"
        "<section id='selector-probe'><p id='first-child'>First</p><p id='last-child' class='keep'>Last</p></section>"
        "<input id='submit' type='submit' value='Go'><div id='advanced'>styled</div>"
        "<p id='odd-probe'>Odd child</p><div id='empty'></div>"
        "<div id='important-probe' class='important-probe' style='color:blue'>important</div>"
        "<div id='important-inline' style='color:blue!important'>inline important</div>"
        "<div id='padding-cascade'>padding important</div><div id='padding-cascade-side'>padding side important</div>"
        "<div id='responsive'>responsive</div><div id='type-mix'><p id='type-one'>one</p><span>middle</span><p id='type-two'>two</p></div>"
        "<div id='flex-probe' class='flex-probe'><div>first flex item</div><div>second flex item</div></div>"
        "<div id='grid-probe' class='grid-probe'><div>grid one</div><div>grid two</div></div>"
        "<div id='width-probe'>width constrained</div><div id='center-probe'>centered box</div>"
        "</main></body></html>";
    XwDocument *doc = (XwDocument *)calloc(1U, sizeof(*doc));
    XwStylesheet *sheet = (XwStylesheet *)calloc(1U, sizeof(*sheet));
    XwComputedStyle body_style, hero_style, heading_style, link_style;
    XwComputedStyle first_style, last_style, submit_style, advanced_style, empty_style, enabled_style, odd_style;
    XwComputedStyle important_style, type_one_style, type_two_style, flex_style, grid_style, width_style;
    uint16_t body, hero, heading, link, script, first_child, last_child, submit, advanced, empty, odd_probe;
    int ok;
    if (doc == NULL || sheet == NULL) return 2;
    ok = xw_dom_parse(doc, html, sizeof(html) - 1U);
    check(ok, "DOM parses nested HTML within fixed memory budget");
    check(xw_dom_find_by_id(doc, "hero") != XW_DOM_NONE, "DOM id lookup finds elements");
    hero = xw_dom_find_by_id(doc, "hero");
    check(xw_dom_has_class(doc, hero, "card") && xw_dom_has_class(doc, hero, "active"),
          "DOM class lookup supports multiple class tokens");
    check(strcmp(xw_dom_attribute(doc, hero, "style"), "text-align:center;color:blue") == 0,
          "DOM preserves inline attributes and case-insensitive attribute access");
    heading = xw_dom_find_by_id(doc, "headline");
    check(heading != XW_DOM_NONE && strcmp(xw_dom_attribute(doc, heading, "id"), "headline") == 0,
          "DOM stores common attributes");
    check(strcmp(xw_dom_string(doc, doc->nodes[doc->nodes[heading].first_child].value_offset), "A < B") == 0,
          "HTML named entities are decoded in text nodes");
    script = XW_DOM_NONE;
    for (size_t i = 0U; i < doc->node_count; ++i) {
        if (doc->nodes[i].type == XW_NODE_ELEMENT &&
            strcmp(xw_dom_string(doc, doc->nodes[i].name_offset), "script") == 0) script = (uint16_t)i;
    }
    check(script != XW_DOM_NONE && doc->nodes[script].first_child != XW_DOM_NONE &&
          strstr(xw_dom_string(doc, doc->nodes[doc->nodes[script].first_child].value_offset), "<tag>") != NULL,
          "script raw text does not get tokenized as HTML markup");
    xw_css_init(sheet);
    xw_css_collect_document_styles(sheet, doc);
    check(sheet->rule_count >= 4U, "CSS parser discovers embedded stylesheet rules");
    body = XW_DOM_NONE;
    link = XW_DOM_NONE;
    for (size_t i = 0U; i < doc->node_count; ++i) {
        const char *tag = xw_dom_string(doc, doc->nodes[i].name_offset);
        if (doc->nodes[i].type == XW_NODE_ELEMENT && strcmp(tag, "body") == 0) body = (uint16_t)i;
        if (doc->nodes[i].type == XW_NODE_ELEMENT && strcmp(tag, "a") == 0) link = (uint16_t)i;
    }
    xw_css_compute(sheet, doc, body, NULL, &body_style);
    xw_css_compute(sheet, doc, hero, &body_style, &hero_style);
    xw_css_compute(sheet, doc, heading, &hero_style, &heading_style);
    xw_css_compute(sheet, doc, link, &hero_style, &link_style);
    check(body_style.color == 0xFF222222U, "CSS type selector applies color");
    check(hero_style.background_color == 0xFFAABBCCU && hero_style.padding == 12,
          "CSS class selector applies background and padding");
    check(hero_style.align == XW_ALIGN_CENTER && hero_style.color == 0xFF0000FFU,
          "inline CSS overrides stylesheet values at higher specificity");
    check(heading_style.color == 0xFFFF0000U && heading_style.font_size_px == 24,
          "CSS id selector overrides inherited text style");
    check(link_style.bold == 1, "CSS descendant selector matches nested links");
    first_child = xw_dom_find_by_id(doc, "first-child");
    last_child = xw_dom_find_by_id(doc, "last-child");
    submit = xw_dom_find_by_id(doc, "submit");
    xw_css_compute(sheet, doc, first_child, &body_style, &first_style);
    xw_css_compute(sheet, doc, last_child, &body_style, &last_style);
    xw_css_compute(sheet, doc, submit, &body_style, &submit_style);
    check(first_child != XW_DOM_NONE && first_style.color == 0xFFFFA500U,
          "CSS direct-child combinator and first-child pseudo-class match");
    check(last_child != XW_DOM_NONE && last_style.background_color == 0xFFAABBCCU,
          "CSS last-child pseudo-class and class compound selector match");
    check(submit != XW_DOM_NONE && submit_style.bold == 1,
          "CSS attribute selector matches input type");
    advanced = xw_dom_find_by_id(doc, "advanced");
    xw_css_compute(sheet, doc, advanced, &body_style, &advanced_style);
    check(advanced != XW_DOM_NONE && advanced_style.margin_top == 1 && advanced_style.margin_right == 2 &&
          advanced_style.margin_bottom == 3 && advanced_style.margin_left == 4,
          "CSS four-value margin shorthand resolves into individual sides");
    check(advanced_style.padding_top == 5 && advanced_style.padding_right == 7 &&
          advanced_style.padding_bottom == 9 && advanced_style.padding_left == 11,
          "CSS padding shorthand preserves each of the four box-model sides");
    {
        uint16_t padding_important = xw_dom_find_by_id(doc, "padding-cascade");
        uint16_t padding_side_important = xw_dom_find_by_id(doc, "padding-cascade-side");
        XwComputedStyle padding_a, padding_b;
        xw_css_compute(sheet, doc, padding_important, &body_style, &padding_a);
        xw_css_compute(sheet, doc, padding_side_important, &body_style, &padding_b);
        check(padding_a.padding_left == 4 && padding_a.padding_top == 4 &&
              padding_b.padding_left == 11 && padding_b.padding_top == 4,
              "CSS !important is preserved correctly across shorthand and individual padding declarations");
    }
    check(advanced_style.border_width == 2 && advanced_style.border_color == 0xFF050A0FU &&
          advanced_style.has_border_color,
          "CSS border color supports rgb() values");
    check(advanced_style.line_height_px == 24 && advanced_style.text_transform == 1 &&
          advanced_style.text_decoration == 3,
          "CSS line-height, text-transform and decoration are computed");
    empty = xw_dom_find_by_id(doc, "empty");
    xw_css_compute(sheet, doc, empty, &body_style, &empty_style);
    odd_probe = xw_dom_find_by_id(doc, "odd-probe");
    xw_css_compute(sheet, doc, submit, &body_style, &enabled_style);
    check(enabled_style.color == 0x80050A0FU,
          "CSS rgba() color preserves a bounded alpha channel");
    check(empty_style.background_color == 0xFF663399U && empty_style.has_background,
          ":empty and rebeccapurple are supported by the stylesheet subset");
    xw_css_compute(sheet, doc, odd_probe, &body_style, &odd_style);
    check(odd_probe != XW_DOM_NONE && odd_style.italic == 1,
          ":nth-child(odd) selects odd-positioned children and applies font-style");
    {
        uint16_t important_node = xw_dom_find_by_id(doc, "important-probe");
        uint16_t important_inline = xw_dom_find_by_id(doc, "important-inline");
        XwComputedStyle important_inline_style;
        uint16_t type_one = xw_dom_find_by_id(doc, "type-one");
        uint16_t type_two = xw_dom_find_by_id(doc, "type-two");
        uint16_t flex_node = xw_dom_find_by_id(doc, "flex-probe");
        xw_css_compute(sheet, doc, important_node, &body_style, &important_style);
        xw_css_compute(sheet, doc, type_one, &body_style, &type_one_style);
        xw_css_compute(sheet, doc, type_two, &body_style, &type_two_style);
        xw_css_compute(sheet, doc, important_inline, &body_style, &important_inline_style);
        check(important_node != XW_DOM_NONE && important_style.color == 0xFFFF0000U,
              "CSS !important beats normal inline style and same-priority rules respect specificity");
        check(important_inline != XW_DOM_NONE && important_inline_style.color == 0xFF0000FFU,
              "inline !important overrides stylesheet !important in the same cascade layer");
        check(type_one != XW_DOM_NONE && type_one_style.color == 0xFF800080U &&
              type_two != XW_DOM_NONE && type_two_style.color == 0xFFFFA500U,
              "first-of-type and nth-of-type work across mixed sibling tags");
        xw_css_compute(sheet, doc, flex_node, &body_style, &flex_style);
        check(flex_node != XW_DOM_NONE && flex_style.display_flex && flex_style.flex_wrap && flex_style.gap_px == 18,
              "CSS computes the bounded flex container and gap properties");
        {
            uint16_t grid_node = xw_dom_find_by_id(doc, "grid-probe");
            uint16_t width_node = xw_dom_find_by_id(doc, "width-probe");
            xw_css_compute(sheet, doc, grid_node, &body_style, &grid_style);
            xw_css_compute(sheet, doc, width_node, &body_style, &width_style);
            check(grid_node != XW_DOM_NONE && grid_style.display_grid && grid_style.grid_columns == 2 && grid_style.gap_px == 12,
                  "CSS Grid reads bounded equal-column repeat() templates and gap");
            check(width_node != XW_DOM_NONE && width_style.width_percent == 50 &&
                  width_style.min_width_px == 80 && width_style.max_width_px == 240,
                  "CSS width percentages and min/max-width resolve to bounded computed style");
            {
                uint16_t centered = xw_dom_find_by_id(doc, "center-probe");
                XwComputedStyle centered_style;
                xw_css_compute(sheet, doc, centered, &body_style, &centered_style);
                check(centered != XW_DOM_NONE && centered_style.margin_left_auto && centered_style.margin_right_auto,
                      "CSS margin:auto flags survive shorthand parsing");
            }
        }
    }
    {
        XwStylesheet narrow, wide;
        uint16_t responsive = xw_dom_find_by_id(doc, "responsive");
        XwComputedStyle narrow_style, wide_style;
        static const char media_css[] = "#responsive{color:#111111;} @media screen and (max-width: 700px) { #responsive{color:orange;} } @media (min-width: 1000px) and (orientation: landscape) { #responsive{background-color:teal;} }";
        xw_css_init(&narrow); xw_css_init(&wide);
        (void)xw_css_parse_for_viewport(&narrow, media_css, sizeof(media_css) - 1U, 640, 360);
        (void)xw_css_parse_for_viewport(&wide, media_css, sizeof(media_css) - 1U, 1152, 384);
        xw_css_compute(&narrow, doc, responsive, &body_style, &narrow_style);
        xw_css_compute(&wide, doc, responsive, &body_style, &wide_style);
        check(narrow_style.color == 0xFFFFA500U,
              "viewport-aware @media max-width applies the responsive rule");
        check(wide_style.color == 0xFF111111U && wide_style.has_background && wide_style.background_color == 0xFF008080U,
              "viewport-aware @media min-width and orientation applies only matching rules");
    }
    {
        XwStylesheet variables;
        XwComputedStyle variable_style, missing_style;
        static const char variable_css[] =
            ":root { --brand: #123456; --space: var(--space-fallback, 7px); } "
            "#advanced { color: var(--brand); padding: var(--space) 3px; background-color: var(--missing, #fedcba); } "
            "#empty { color: var(--missing); }";
        xw_css_init(&variables);
        (void)xw_css_parse(&variables, variable_css, sizeof(variable_css) - 1U);
        xw_css_compute(&variables, doc, advanced, &body_style, &variable_style);
        xw_css_compute(&variables, doc, empty, &body_style, &missing_style);
        check(variables.custom_property_count == 2U && variable_style.color == 0xFF123456U,
              "CSS :root custom properties resolve through var() in computed styles");
        check(variable_style.padding_top == 7 && variable_style.padding_right == 3 &&
              variable_style.background_color == 0xFFFEDCBAU,
              "CSS var() supports nested fallback and use inside shorthand values");
        check(missing_style.color == body_style.color,
              "unresolved CSS var() without fallback invalidates only that declaration");
    }
    check(xw_css_query_selector(doc, "main > #advanced, #missing") == advanced,
          "querySelector helper resolves direct-child and selector-list queries");
    {
        XwStylesheet cross_sheet;
        XwComputedStyle cross_style;
        uint16_t cross_target;
        static const char multi_style_html[] =
            "<html><head><style>#cross { color: var(--late-color); }</style>"
            "<style>:root { --late-color: #4a7bc8; }</style></head>"
            "<body><p id='cross'>variables across style elements</p></body></html>";
        check(xw_dom_parse(doc, multi_style_html, sizeof(multi_style_html) - 1U),
              "DOM accepts a document with multiple inline style elements");
        xw_css_init(&cross_sheet);
        xw_css_collect_document_styles(&cross_sheet, doc);
        cross_target = xw_dom_find_by_id(doc, "cross");
        xw_css_compute(&cross_sheet, doc, cross_target, &body_style, &cross_style);
        check(cross_sheet.custom_property_count == 1U && cross_style.color == 0xFF4A7BC8U,
              "CSS root variables resolve across style tags even when declared later");
    }
    {
        XwStylesheet malformed;
        static const char unterminated_comment[] = {'/', '*', 'n', 'o', ' ', 't', 'e', 'r', 'm'};
        xw_css_init(&malformed);
        (void)xw_css_parse(&malformed, unterminated_comment, sizeof(unterminated_comment));
        check(malformed.truncated == 1, "CSS comment scanner stays within a non-NUL-terminated input buffer");
    }
    {
        XwDomStats stats;
        xw_dom_get_stats(doc, sizeof(html) - 1U, &stats);
        check(stats.node_count == doc->node_count && stats.string_bytes <= XW_DOM_STRING_POOL_SIZE,
              "DOM telemetry reports bounded allocations");
    }
    {
        static const char recovery_html[] = "<html><body><p id='p1'>one<p id='p2'>two"
            "<script>if (a < b) { x = '&amp;'; }</script>"
            "<textarea id='ta'>A &amp; B <strong>literal</strong></textarea></body></html>";
        uint16_t p1, p2, textarea, script_node;
        char text[128];
        check(xw_dom_parse(doc, recovery_html, sizeof(recovery_html) - 1U),
              "DOM accepts common omitted end tags without exceeding bounded storage");
        p1 = xw_dom_find_by_id(doc, "p1"); p2 = xw_dom_find_by_id(doc, "p2");
        check(p1 != XW_DOM_NONE && p2 != XW_DOM_NONE && doc->nodes[p1].parent == doc->nodes[p2].parent,
              "HTML parser implicitly closes repeated paragraph elements");
        textarea = xw_dom_find_by_id(doc, "ta");
        (void)xw_dom_text_content(doc, textarea, text, sizeof(text));
        check(strcmp(text, "A & B <strong>literal</strong>") == 0,
              "textarea uses RCDATA behavior instead of parsing embedded tags");
        script_node = XW_DOM_NONE;
        for (size_t i = 0U; i < doc->node_count; ++i)
            if (doc->nodes[i].type == XW_NODE_ELEMENT &&
                strcmp(xw_dom_string(doc, doc->nodes[i].name_offset), "script") == 0) script_node = (uint16_t)i;
        check(script_node != XW_DOM_NONE && strstr(xw_dom_string(doc, doc->nodes[doc->nodes[script_node].first_child].value_offset), "&amp;") != NULL,
              "script raw text preserves HTML-looking operators and entity spellings");
    }
    free(sheet); free(doc);
    if (failures) { printf("%d XENONWEB test(s) failed\n", failures); return 1; }
    printf("All XenonWeb DOM/CSS host tests passed\n");
    return 0;
}
