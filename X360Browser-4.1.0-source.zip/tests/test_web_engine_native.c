#include "../platform/xbox360/xsdk/web_engine.h"
#include "../engine/xenonweb/xw_dom.h"
#include "../engine/xenonweb/xw_script.h"
#include "../engine/xenonweb/xw_css.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>

static int fail(const char *message)
{
    fprintf(stderr, "FAIL: %s\n", message);
    return 1;
}

int main(void)
{
    WebEnginePage *page = (WebEnginePage *)calloc(1U, sizeof(*page));
    XwDocument *document = (XwDocument *)calloc(1U, sizeof(*document));
    char error[192] = {0};
    int result;
    if (page == NULL || document == NULL) {
        free(page);
        free(document);
        return fail("page/DOM allocation");
    }
    if (!web_engine_native_init()) {
        free(page);
        return fail("libcurl init");
    }

    result = web_engine_native_fetch("http://127.0.0.1:18765/page.html", page,
                                     error, sizeof(error));
    if (!result) {
        fprintf(stderr, "fetch error: %s\n", error);
        web_engine_native_shutdown();
        free(page);
        return 1;
    }
    if (strcmp(page->title, "X360Browser Test") != 0)
        return fail("title extraction");
    if (strcmp(page->page_url, "http://127.0.0.1:18765/page.html") != 0)
        return fail("effective page URL retained for visual relative-link mapping");
    if (strcmp(page->description, "Fixture page for XenonWeb native transport") != 0)
        return fail("meta description");


    {
        size_t i;
        int found_relative = 0;
        int found_fragment = 0;
        int found_video = 0;
        int found_audio = 0;
        int found_hls = 0;
        int found_embed_navigation = 0;
        for (i = 0U; i < page->link_count; ++i) {
            if (strcmp(page->links[i].url, "http://127.0.0.1:18765/next") == 0)
                found_relative = 1;
            if (strcmp(page->links[i].url, "http://127.0.0.1:18765/page.html#local-target") == 0)
                found_fragment = 1;
            if (strcmp(page->links[i].url, "http://127.0.0.1:18765/clip.mp4") == 0 &&
                page->links[i].is_video != 0)
                found_video = 1;
            if (strcmp(page->links[i].url, "http://127.0.0.1:18765/audio.mp3") == 0 &&
                page->links[i].is_audio != 0)
                found_audio = 1;
            if (strstr(page->links[i].url, "playlist.m3u8") != NULL && page->links[i].is_video != 0)
                found_hls = 1;
            if (strcmp(page->links[i].url, "http://127.0.0.1:18765/embed") == 0 &&
                page->links[i].is_video == 0 && page->links[i].is_audio == 0)
                found_embed_navigation = 1;
        }
        if (!found_relative)
            return fail("relative link resolution");
        if (!found_fragment)
            return fail("fragment-only anchors remain selectable for in-page action dispatch");
        if (!found_video)
            return fail("direct HTML video source is selectable");
        if (!found_audio)
            return fail("HTML audio source is selectable as a playable audio item");
        if (!found_hls)
            return fail("HLS VOD manifest is selectable as a video resource");
        if (!found_embed_navigation)
            return fail("unsupported iframe URL remains reachable through regular navigation");
    }
    if (page->image_count < 8U)
        return fail("image/source discovery count includes PNG/JPEG/GIF/BMP fixture links");
    {
        size_t i;
        int found_main = 0;
        int found_srcset = 0;
        int found_css = 0;
        int found_cached_png = 0;
        int found_cached_jpeg = 0;
        int found_cached_gif = 0;
        int found_cached_bmp = 0;
        int found_lazy_src = 0;
        int found_original_src = 0;
        int found_lazy_srcset = 0;
        for (i = 0U; i < page->image_count; ++i) {
            if (strcmp(page->images[i].url, "http://127.0.0.1:18765/assets/picture.png") == 0) {
                found_main = 1;
                if (page->images[i].cache_path[0] != '\0') {
                    unsigned char signature[8] = {0};
                    FILE *png = fopen(page->images[i].cache_path, "rb");
                    if (png != NULL) {
                        size_t got = fread(signature, 1U, sizeof(signature), png);
                        (void)fclose(png);
                        if (got == sizeof(signature) && signature[0] == 137U && signature[1] == 'P' &&
                            signature[2] == 'N' && signature[3] == 'G') found_cached_png = 1;
                    }
                }
            }
            if (strcmp(page->images[i].url, "http://127.0.0.1:18765/assets/picture-small.png") == 0)
                found_srcset = 1;
            if (strcmp(page->images[i].url, "http://127.0.0.1:18765/assets/lazy-image.png") == 0)
                found_lazy_src = 1;
            if (strcmp(page->images[i].url, "http://127.0.0.1:18765/assets/original-image.png") == 0)
                found_original_src = 1;
            if (strcmp(page->images[i].url, "http://127.0.0.1:18765/assets/lazy-small.png") == 0)
                found_lazy_srcset = 1;
            if (strcmp(page->images[i].url, "http://127.0.0.1:18765/assets/picture.jpg") == 0 && page->images[i].cache_path[0] != '\0') {
                FILE *f = fopen(page->images[i].cache_path, "rb"); unsigned char sig[3] = {0};
                if (f != NULL) {
                    size_t got = fread(sig, 1U, sizeof(sig), f);
                    (void)fclose(f);
                    if (got == sizeof(sig) && sig[0] == 0xFFU && sig[1] == 0xD8U && sig[2] == 0xFFU)
                        found_cached_jpeg = 1;
                }
            }
            if (strcmp(page->images[i].url, "http://127.0.0.1:18765/assets/picture.gif") == 0 && page->images[i].cache_path[0] != '\0') {
                FILE *f = fopen(page->images[i].cache_path, "rb"); char sig[6] = {0};
                if (f != NULL) {
                    size_t got = fread(sig, 1U, sizeof(sig), f);
                    (void)fclose(f);
                    if (got == sizeof(sig) && memcmp(sig, "GIF8", 4U) == 0) found_cached_gif = 1;
                }
            }
            if (strcmp(page->images[i].url, "http://127.0.0.1:18765/assets/picture.bmp") == 0 && page->images[i].cache_path[0] != '\0') {
                FILE *f = fopen(page->images[i].cache_path, "rb"); char sig[2] = {0};
                if (f != NULL) {
                    size_t got = fread(sig, 1U, sizeof(sig), f);
                    (void)fclose(f);
                    if (got == sizeof(sig) && sig[0] == 'B' && sig[1] == 'M') found_cached_bmp = 1;
                }
            }
            if (strcmp(page->images[i].url, "http://127.0.0.1:18765/assets/background.webp") == 0 ||
                strcmp(page->images[i].url, "http://127.0.0.1:18765/assets/inline.png") == 0)
                found_css = 1;
        }
        if (!found_main || !found_srcset || !found_css)
            return fail("img, srcset and CSS url(...) discovery");
        if (!found_lazy_src || !found_original_src || !found_lazy_srcset)
            return fail("common lazy-loading data-src and data-srcset attributes are discovered");
        if (!found_cached_png || !found_cached_jpeg || !found_cached_gif || !found_cached_bmp)
            return fail("bounded PNG/JPEG/GIF/BMP image download and signature verification");
    }
    if (page->media_count < 4U)
        return fail("stylesheet/script/video/audio/embed extraction");
    if (page->stylesheet_count != 1U || page->script_count != 4U || page->form_count != 1U || page->heading_count != 1U) {
        fprintf(stderr, "counters: styles=%lu scripts=%lu forms=%lu headings=%lu media=%lu\n", (unsigned long)page->stylesheet_count, (unsigned long)page->script_count, (unsigned long)page->form_count, (unsigned long)page->heading_count, (unsigned long)page->media_count);
        return fail("page capability counters");
    }
    if (strstr(page->text, "[Image: Sample photo]") == NULL)
        return fail("image alt placeholder");
    if (strstr(page->source_html, "<script>document.getElementById('external').textContent = 'External script loaded';</script>") == NULL)
        return fail("bounded external JavaScript is fetched and inlined at its original script position");
    if (strstr(page->source_html, "<script async src=\"/async.js\"></script>") == NULL)
        return fail("async script is left untouched rather than executed with incorrect ordering semantics");
    if (strstr(page->source_html, "external stylesheet: http://127.0.0.1:18765/site.css") == NULL ||
        strstr(page->source_html, ".remote-style { color: rgb(12, 34, 56); text-transform: uppercase; }") == NULL)
        return fail("small external text/css stylesheet is fetched and boundedly materialized");
    if (strstr(page->source_html, "<script src=\"/large.js\"></script>") == NULL)
        return fail("oversized external script is not materialized into the document");
    if (!xw_dom_parse(document, page->source_html, page->source_html_length))
        return fail("XenonWeb parses the fetched page with external scripts/stylesheets materialized");
    {
        XwStylesheet stylesheet;
        XwComputedStyle base, computed;
        uint16_t remote = XW_DOM_NONE;
        size_t index;
        memset(&base, 0, sizeof(base));
        base.color = 0xFF202124U; base.font_size_px = 16; base.width_px = -1;
        xw_css_init(&stylesheet);
        xw_css_collect_document_styles(&stylesheet, document);
        for (index = 0U; index < document->node_count; ++index) {
            if (document->nodes[index].type == XW_NODE_ELEMENT &&
                strcmp(xw_dom_attribute(document, (uint16_t)index, "class") != NULL ?
                    xw_dom_attribute(document, (uint16_t)index, "class") : "", "remote-style") == 0) {
                remote = (uint16_t)index; break;
            }
        }
        if (remote == XW_DOM_NONE) return fail("external stylesheet target fixture exists");
        xw_css_compute(&stylesheet, document, remote, &base, &computed);
        if (computed.color != 0xFF0C2238U || computed.text_transform != 1)
            return fail("fetched external CSS reaches XenonWeb's computed style system");
    }
    {
        XwScriptStats script_stats;
        const uint16_t external_node = xw_dom_find_by_id(document, "external");
        char external_text[128] = {0};
        if (!xw_script_run_document(document, XW_SCRIPT_MAX_STATEMENTS, &script_stats))
            return fail("XenonScript executes the bounded external script fixture");
        (void)xw_dom_text_content(document, external_node, external_text, sizeof(external_text));
        if (strcmp(external_text, "External script loaded") != 0)
            return fail("external script mutates a real DOM node through XenonScript");
    }

    {
        size_t i;
        for (i = 0U; i < page->image_count; ++i) {
            if (page->images[i].cache_path[0] != '\0') (void)remove(page->images[i].cache_path);
        }
    }

    /* Regression for the former 512 KiB transport / roughly 48 KiB visual
     * source limits: verify a >612 KiB document survives transport and retention. */
    result = web_engine_native_fetch("http://127.0.0.1:18765/large-html.html", page,
                                     error, sizeof(error));
    if (!result) {
        fprintf(stderr, "large HTML fetch error: %s\n", error);
        return fail("HTML document larger than 612 KiB downloads successfully");
    }
    if (page->html_bytes <= 612U * 1024U)
        return fail("large HTML fixture is actually larger than the old download limit");
    if (page->source_html_truncated != 0)
        return fail("large HTML document fits within retained visual-source capacity");
    if (page->source_html_length != page->html_bytes)
        return fail("complete large HTML source is retained for visual rendering");
    if (strstr(page->source_html, "HTML-END-MARKER") == NULL)
        return fail("HTML past the old 612 KiB boundary reaches the renderer");

    result = web_engine_native_fetch("http://127.0.0.1:18765/large-css-page.html", page,
                                     error, sizeof(error));
    if (!result) {
        fprintf(stderr, "large CSS fixture fetch error: %s\n", error);
        return fail("large stylesheet page loads");
    }
    if (strstr(page->source_html, ".large-css-tail { color: #123456; }") == NULL)
        return fail("external stylesheet larger than 4 KiB is appended for the page renderer");

    result = web_engine_native_fetch("http://127.0.0.1:18765/mime-page.html", page,
                                     error, sizeof(error));
    if (!result) return fail("fetch MIME guard fixture page");
    if (strstr(page->source_html, "<script src=\"/wrong-mime.js\"></script>") == NULL)
        return fail("script response with a non-JavaScript MIME type is not inlined");
    if (strstr(page->source_html, "MUST NOT RUN") != NULL)
        return fail("non-JavaScript MIME payload is not materialized as executable script");

    result = web_engine_native_fetch("http://127.0.0.1:18765/wrong-css-page.html", page,
                                     error, sizeof(error));
    if (!result) return fail("fetch CSS MIME guard fixture page");
    if (strstr(page->source_html, "external stylesheet:") != NULL ||
        strstr(page->source_html, ".not-css { color: red; }") != NULL)
        return fail("non-CSS MIME payload is not injected into the document stylesheet cascade");

    memset(page, 0, sizeof(*page));
    result = web_engine_native_fetch("http://127.0.0.1:18765/big.bin", page,
                                     error, sizeof(error));
    if (!result || !page->is_direct_resource || strstr(page->text, "video/mp4") == NULL)
        return fail("direct media is detected and body is not parsed as HTML");

    {
        const char *download_path = "x360browser-test-video.bin";
        FILE *download;
        char payload[64] = { 0 };
        size_t got;
        (void)remove(download_path);
        if (!web_engine_download_video("http://127.0.0.1:18765/clip.mp4", download_path,
                                       error, sizeof(error))) {
            fprintf(stderr, "video download error: %s\n", error);
            return fail("bounded direct video download");
        }
        download = fopen(download_path, "rb");
        if (download == NULL) return fail("downloaded video file exists");
        got = fread(payload, 1U, sizeof(payload) - 1U, download);
        (void)fclose(download);
        (void)remove(download_path);
        if (got != strlen("FAKE-MP4-V1.0") || memcmp(payload, "FAKE-MP4-V1.0", got) != 0)
            return fail("downloaded video bytes match fixture");

        (void)remove(download_path);
        if (web_engine_download_video("http://127.0.0.1:18765/html-looks-like-video.mp4", download_path,
                                      error, sizeof(error)))
            return fail("HTML response must not be accepted as a video file");
        download = fopen(download_path, "rb");
        if (download != NULL) { (void)fclose(download); return fail("failed video download leaves no partial file"); }
        if (errno != ENOENT)
            return fail("failed video file cleanup status");

        (void)remove(download_path);
        if (!web_engine_download_media("http://127.0.0.1:18765/audio.mp3", download_path,
                                       "audio", error, sizeof(error))) {
            fprintf(stderr, "audio download error: %s\n", error);
            return fail("bounded direct audio download");
        }
        download = fopen(download_path, "rb");
        if (download == NULL) return fail("downloaded audio file exists");
        memset(payload, 0, sizeof(payload));
        got = fread(payload, 1U, sizeof(payload) - 1U, download);
        (void)fclose(download);
        (void)remove(download_path);
        if (got != strlen("ID3FAKE-AUDIO-FIXTURE") || memcmp(payload, "ID3FAKE-AUDIO-FIXTURE", got) != 0)
            return fail("downloaded audio bytes match fixture");

        if (web_engine_download_media("http://127.0.0.1:18765/html-looks-like-audio.mp3", download_path,
                                      "audio", error, sizeof(error)))
            return fail("HTML response must not be accepted as an audio file");
        download = fopen(download_path, "rb");
        if (download != NULL) { (void)fclose(download); return fail("failed audio download leaves no partial file"); }
        if (errno != ENOENT) return fail("failed audio file cleanup status");

        (void)remove(download_path);
        if (!web_engine_download_video("http://127.0.0.1:18765/master.m3u8", download_path,
                                       error, sizeof(error))) {
            fprintf(stderr, "HLS VOD error: %s\n", error);
            return fail("unencrypted HLS VOD master playlist download");
        }
        download = fopen(download_path, "rb");
        if (download == NULL) return fail("HLS VOD output file exists");
        memset(payload, 0, sizeof(payload));
        got = fread(payload, 1U, sizeof(payload) - 1U, download);
        (void)fclose(download);
        (void)remove(download_path);
        if (got != strlen("LOW-SEGMENT-1LOW-SEGMENT-2") ||
            memcmp(payload, "LOW-SEGMENT-1LOW-SEGMENT-2", got) != 0)
            return fail("HLS master selects lowest-bandwidth VOD and concatenates segments in order");

        (void)remove(download_path);
        if (web_engine_download_video("http://127.0.0.1:18765/live.m3u8", download_path,
                                      error, sizeof(error)))
            return fail("live HLS should be rejected instead of downloading forever");
        download = fopen(download_path, "rb");
        if (download != NULL) { (void)fclose(download); return fail("rejected live HLS leaves no output file"); }
        if (errno != ENOENT) return fail("live HLS cleanup status");

        (void)remove(download_path);
        if (web_engine_download_video("http://127.0.0.1:18765/encrypted.m3u8", download_path,
                                      error, sizeof(error)))
            return fail("AES-128 encrypted HLS should fail closed");
        download = fopen(download_path, "rb");
        if (download != NULL) { (void)fclose(download); return fail("rejected encrypted HLS leaves no output file"); }
        if (errno != ENOENT) return fail("encrypted HLS cleanup status");
    }

    web_engine_native_shutdown();
    free(document);
    free(page);
    puts("PASS: metadata/base URL, XenonScript integration, audio/video link discovery and bounded downloads, HLS VOD restrictions, raster cache and resource safety");
    return 0;
}
