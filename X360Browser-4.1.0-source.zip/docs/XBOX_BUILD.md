# X360Browser 4.0.0 — validação da fonte e build Xbox opcional

O workflow `.github/workflows/build-xex-from-zip.yml` procura uma árvore com `platform/xbox360/xsdk/main.c` e `VERSION=4.0.0`, ou extrai `X360Browser-4.0.0-source.zip`. O pacote de fonte contém alterações reais no motor XenonWeb, no transportador web, no renderizador e no caminho experimental de resolução de mídia do YouTube — não apenas o YAML.

## Validação inicial (sem gerar XEX)

1. Envie `X360Browser-4.0.0-source.zip` para a raiz do repositório ou faça commit de todos os arquivos extraídos.
2. Abra **Actions → X360Browser 4.0.0 Engine Refresh — validation (XEX opt-in)** e execute com `build_xex=false`.
3. Confira os testes e o artefato de validação.

## Compilação cruzada opcional

Só habilite `build_xex=true` depois da validação da fonte e com as dependências PowerPC/xSDK disponíveis. Build host não garante que o XEX iniciará no console. A versão 4.0.0 ainda exige teste no Xbox 360 RGH real.
