# X360Browser 4.0.0 — mídia e limites de reprodução

## O que a versão realmente acrescenta

XenonMedia continua oferecendo decodificadores limitados para BMP, QOI, PPM, alguns perfis de PNG/GIF/JPEG, WAV PCM/IMA ADPCM e parsers de AVI/MP4/MP3/AAC/TS/HLS, além de primitivas de sessão e WebVTT. O download de mídia continua limitado e não é, por si só, um player integrado. These components are not yet an integrated in-browser media playback pipeline.

A 4.0.0 reconhece links do YouTube em formatos comuns (`watch`, `youtu.be`, `shorts`, `embed`, `live`) e tenta consultar instâncias públicas do Invidious para encontrar um stream MP4 muxado até 480p. A escolha do stream tem limites de tamanho/tempo, validação TLS e restrição ao domínio `googlevideo.com`; redirecionamentos da URL resolvida aceitam apenas HTTPS. É uma rota experimental baseada em serviço de terceiros, por isso pode falhar por indisponibilidade, restrição geográfica, vídeo privado/live, política da instância ou falta de stream MP4 compatível.

## YouTube não é reprodução interna

O player HTML5 do YouTube não é executado dentro do X360Browser. Se houver um player externo compatível configurado explicitamente em `X360Browser-video-config.txt`, o navegador pode resolver e baixar o vídeo compatível para fazer o handoff. O player vem por conta do usuário e fica desativado por padrão. Isso não é um pipeline de reprodução nativo, não garante áudio/vídeo sincronizados e não suporta todos os vídeos.

A API pública consultada é documentada por instâncias Invidious, mas as instâncias são serviço de terceiros e sua disponibilidade muda. Não são usadas chaves privadas nem tentativa de contornar DRM; vídeos DRM/privados não são reivindicados como suportados.

## Poki e jogos web

Não é declarada compatibilidade geral com Poki. XenonScript continua sendo um subconjunto JavaScript limitado, sem ECMAScript completo, event loop/Promises/módulos completos, Canvas 2D/WebGL, WebAssembly ou workers. Muitos jogos atuais não iniciam ou falham no primeiro recurso que exige essas APIs. Aumentar os limites do parser permite páginas maiores, mas não substitui essas APIs.

## Primitivas internas e lacunas

Os decodificadores e parsers de XenonMedia são testados isoladamente, mas o Xbox não tem nesta versão o pipeline completo de saída de áudio PCM, apresentação de quadros com relógio sincronizado, demux MP4 completo, codecs modernos H.264/AAC/VP9/AV1, HLS adaptativo/live, sobreposição (subtitle overlay) de legendas sincronizadas nem um `HTMLMediaElement` compatível com páginas modernas.

O arquivo de exemplo mantém o player externo desativado. Um retorno de sucesso do launch externo não é prova de reprodução correta. O build PowerPC/XSDK e o teste em hardware ainda são necessários.
