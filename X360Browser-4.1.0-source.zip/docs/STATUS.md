# X360Browser 4.1.0 — estado da implementação

## Implementado nesta atualização de fonte

- Metadados 4.1.0 e documentação alinhada à fonte atual.
- Limites fixos maiores para DOM, atributos, pool de strings, CSS, variáveis CSS, script, layout e registros visuais; permanecem limitados para reduzir risco de esgotamento de memória.
- Negociação de compressão HTTP para HTML/CSS/JavaScript conforme suporte da build libcurl.
- Até quatro scripts externos pequenos, com orçamento total de 32 KiB, validação MIME/TLS e timeouts limitados.
- Fallback de criação de textura tiled para linear e invalidação de cache raster ao detectar alteração do arquivo.
- Resolução experimental de links YouTube para stream MP4 muxado até 480p por instâncias públicas Invidious, com análise de JSON limitada, restrições do host e redirects HTTPS para o stream selecionado.
- Testes host de reconhecimento de URL YouTube e da seleção de stream, incluindo hostname falso, codecs não suportados e decodificação de `\u0026` nos parâmetros de URL.

## Parcial ou indisponível

- XenonScript não é ECMAScript completo; não há motor equivalente ao V8.
- Iframes não renderizam conteúdo em contextos aninhados completos.
- Canvas/WebGL/WebAssembly/workers e várias APIs modernas não estão presentes; não se promete que jogos do Poki funcionem.
- A resolução YouTube é experimental e não produz reprodução interna; precisa de instância pública acessível e player externo configurado.
- O caminho completo de mídia nativa — decodificação dos codecs modernos, saída de áudio e sincronização audiovisual — permanece incompleto.
- A compilação PowerPC/XSDK e o teste em Xbox 360 físico são portões de validação separados.

Consulte `COMPATIBILITY-4.0.0.md` e `MEDIA-PLAYBACK.md` para a matriz de suporte.


4.1.0: validação de portas e escapes percentuais fortalecida; veja `COMPATIBILITY-4.1.0.md`.
