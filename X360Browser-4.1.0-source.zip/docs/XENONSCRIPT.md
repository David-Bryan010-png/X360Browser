# XenonScript — bounded first-party script interpreter

XenonScript is a small project-native interpreter intended to make basic pages interactive under strict CPU/memory limits. It is not Chromium's V8, JavaScriptCore, QuickJS, or a standards-complete ECMAScript runtime.

## Supported subset

- Bounded tokens, variables, numbers, strings, booleans, basic expressions and comparisons.
- `if/else` and a limited `for` loop with instruction/iteration ceilings; unsupported unbounded constructs fail closed.
- Selected `document` APIs: `getElementById`, `querySelector`, `createElement`, `createTextNode`; element scoped `querySelector`, `matches`, `closest`, `appendChild`, `removeChild`, `remove`.
- `textContent`, text-node `nodeValue`, `setAttribute`/`getAttribute`/`hasAttribute`/`removeAttribute`, bounded `style` proxy and `classList` token operations.
- Common node relations and limited form properties backed by attributes.
- Inline click-handler dispatch for supported anchors, plus a constrained path for tiny external synchronous scripts.

## Not implemented as full browser APIs

No complete ECMAScript semantics, arrays/objects/prototypes, promises, modules, `async/await`, event loop/timers, full `addEventListener` event propagation, `fetch`/XHR APIs, storage, workers, Canvas/WebGL bindings, WebAssembly or modern framework compatibility. External scripts have strict byte/MIME/count rules and skip `async`, `defer`, module and integrity-bearing tags. Keep tests targeted and do not run untrusted modern scripts expecting browser behavior.
