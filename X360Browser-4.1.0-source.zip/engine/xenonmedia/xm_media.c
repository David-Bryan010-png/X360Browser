#include "xm_media.h"
#include <ctype.h>
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static uint16_t rd16le(const uint8_t *p) { return (uint16_t)((uint16_t)p[0] | ((uint16_t)p[1] << 8U)); }
static uint32_t rd32le(const uint8_t *p) { return (uint32_t)p[0] | ((uint32_t)p[1] << 8U) | ((uint32_t)p[2] << 16U) | ((uint32_t)p[3] << 24U); }
static uint32_t rd32be(const uint8_t *p) { return ((uint32_t)p[0] << 24U) | ((uint32_t)p[1] << 16U) | ((uint32_t)p[2] << 8U) | (uint32_t)p[3]; }
static uint64_t rd64be(const uint8_t *p) { return ((uint64_t)rd32be(p) << 32U) | rd32be(p + 4U); }
static int tag_eq(const uint8_t *p, const char *s) { return p != NULL && s != NULL && memcmp(p, s, 4U) == 0; }
static int contains_nocase(const char *s, const char *needle) {
    size_t n;
    if (s == NULL || needle == NULL) return 0;
    n = strlen(needle);
    if (n == 0U) return 1;
    for (; *s != '\0'; ++s) {
        size_t i;
        for (i = 0U; i < n && s[i] != '\0' && tolower((unsigned char)s[i]) == tolower((unsigned char)needle[i]); ++i) {}
        if (i == n) return 1;
    }
    return 0;
}
static int url_ext_eq(const char *url, const char *ext) {
    size_t u, e, path_end, path_start = 0U, i;
    if (url == NULL || ext == NULL) return 0;
    u = strlen(url); e = strlen(ext); path_end = u;
    for (i = 0U; i < u; ++i) {
        if (url[i] == '?' || url[i] == '#') { path_end = i; break; }
        if (url[i] == '/') path_start = i + 1U;
    }
    if (path_end < path_start || path_end - path_start < e) return 0;
    for (i = 0U; i < e; ++i)
        if (tolower((unsigned char)url[path_end - e + i]) != tolower((unsigned char)ext[i])) return 0;
    return 1;
}

const char *xm_container_name(XmContainer c) {
    switch (c) {
    case XM_CONTAINER_WAVE: return "WAVE"; case XM_CONTAINER_AVI: return "AVI";
    case XM_CONTAINER_ISO_BMFF: return "ISO-BMFF/MP4"; case XM_CONTAINER_MPEG_TS: return "MPEG-TS";
    case XM_CONTAINER_MATROSKA: return "Matroska/WebM"; case XM_CONTAINER_MP3: return "MP3";
    case XM_CONTAINER_AAC_ADTS: return "AAC/ADTS"; case XM_CONTAINER_OGG: return "Ogg";
    case XM_CONTAINER_FLAC: return "FLAC"; case XM_CONTAINER_HLS: return "HLS";
    case XM_CONTAINER_MPEG_DASH: return "MPEG-DASH"; case XM_CONTAINER_WEBVTT: return "WebVTT";
    case XM_CONTAINER_BMP: return "BMP"; case XM_CONTAINER_PNG: return "PNG";
    case XM_CONTAINER_JPEG: return "JPEG"; case XM_CONTAINER_GIF: return "GIF";
    case XM_CONTAINER_QOI: return "QOI"; case XM_CONTAINER_PPM: return "PPM";
    default: return "unknown";
    }
}
const char *xm_codec_name(XmCodec c) {
    switch (c) {
    case XM_CODEC_PCM_U8: return "PCM unsigned 8-bit"; case XM_CODEC_PCM_S16LE: return "PCM signed 16-bit LE";
    case XM_CODEC_IMA_ADPCM: return "Microsoft IMA ADPCM";
    case XM_CODEC_MP3: return "MPEG Layer III"; case XM_CODEC_AAC: return "AAC"; case XM_CODEC_AVC: return "H.264/AVC";
    case XM_CODEC_HEVC: return "H.265/HEVC"; case XM_CODEC_AV1: return "AV1"; case XM_CODEC_VP8: return "VP8";
    case XM_CODEC_VP9: return "VP9"; case XM_CODEC_VORBIS: return "Vorbis"; case XM_CODEC_OPUS: return "Opus";
    case XM_CODEC_FLAC: return "FLAC"; case XM_CODEC_MJPEG: return "Motion JPEG"; case XM_CODEC_RAW_RGB: return "raw RGB";
    default: return "unknown";
    }
}

int xm_media_probe(const uint8_t *b, size_t n, const char *url, const char *mime, XmMediaInfo *out) {
    XmMediaInfo x;
    memset(&x, 0, sizeof(x));
    x.kind = XM_KIND_UNKNOWN; x.container = XM_CONTAINER_UNKNOWN; x.audio_codec = XM_CODEC_UNKNOWN; x.video_codec = XM_CODEC_UNKNOWN;
    if (b != NULL && n >= 2U && (b[0]=='P' && (b[1]=='3' || b[1]=='6'))) { x.container=XM_CONTAINER_PPM; x.kind=XM_KIND_IMAGE; x.supported_for_native_decode=1U; }
    else if (b != NULL && n >= 7U && memcmp(b, "#EXTM3U", 7U) == 0) { x.container=XM_CONTAINER_HLS; x.kind=XM_KIND_PLAYLIST; }
    else if (b != NULL && n >= 6U && memcmp(b, "WEBVTT", 6U) == 0) { x.container=XM_CONTAINER_WEBVTT; x.kind=XM_KIND_SUBTITLE; }
    else if (b != NULL && n >= 12U) {
        if (memcmp(b, "RIFF", 4U) == 0 && memcmp(b + 8U, "WAVE", 4U) == 0) {
            XmWavInfo wav;
            x.container=XM_CONTAINER_WAVE; x.kind=XM_KIND_AUDIO; x.has_audio=1;
            if (xm_media_parse_wav(b,n,&wav)) {
                if (wav.format_tag==0x0011U) x.audio_codec=XM_CODEC_IMA_ADPCM;
                else if (wav.bits_per_sample==8U) x.audio_codec=XM_CODEC_PCM_U8;
                else x.audio_codec=XM_CODEC_PCM_S16LE;
                x.supported_for_native_decode=1U;
                x.sample_rate=wav.sample_rate; x.channels=wav.channels; x.bits_per_sample=wav.bits_per_sample;
                x.duration_ms=wav.duration_ms; x.data_offset=wav.data_offset; x.data_bytes=wav.data_bytes; x.complete=1U;
            }
        }
        else if (memcmp(b, "RIFF", 4U) == 0 && memcmp(b + 8U, "AVI ", 4U) == 0) { x.container=XM_CONTAINER_AVI; x.kind=XM_KIND_VIDEO; x.has_video=1; }
        else if (memcmp(b + 4U, "ftyp", 4U) == 0) { x.container=XM_CONTAINER_ISO_BMFF; x.kind=XM_KIND_VIDEO; }
        else if (memcmp(b, "\x1A\x45\xDF\xA3", 4U) == 0) { x.container=XM_CONTAINER_MATROSKA; x.kind=XM_KIND_VIDEO; }
        else if (memcmp(b, "OggS", 4U) == 0) { x.container=XM_CONTAINER_OGG; x.kind=XM_KIND_AUDIO; }
        else if (memcmp(b, "fLaC", 4U) == 0) { x.container=XM_CONTAINER_FLAC; x.kind=XM_KIND_AUDIO; x.audio_codec=XM_CODEC_FLAC; x.has_audio=1; }
        else if (memcmp(b, "qoif", 4U) == 0) { x.container=XM_CONTAINER_QOI; x.kind=XM_KIND_IMAGE; x.supported_for_native_decode=1U; }
        else if (memcmp(b, "BM", 2U) == 0) { x.container=XM_CONTAINER_BMP; x.kind=XM_KIND_IMAGE; x.supported_for_native_decode=1; }
        else if (memcmp(b, "\x89PNG\r\n\x1A\n", 8U) == 0) { x.container=XM_CONTAINER_PNG; x.kind=XM_KIND_IMAGE; x.supported_for_native_decode=1U; }
        else if (memcmp(b, "GIF87a", 6U) == 0 || memcmp(b, "GIF89a", 6U) == 0) { x.container=XM_CONTAINER_GIF; x.kind=XM_KIND_IMAGE; x.supported_for_native_decode=1U; }
        else if (b[0]==0xFFU && b[1]==0xD8U && b[2]==0xFFU) { x.container=XM_CONTAINER_JPEG; x.kind=XM_KIND_IMAGE; x.supported_for_native_decode=1U; }
        else if (b[0]=='P' && b[1]>='3' && b[1]<='6' && n > 2U && isspace((unsigned char)b[2])) { x.container=XM_CONTAINER_PPM; x.kind=XM_KIND_IMAGE; x.supported_for_native_decode=1U; }
        else if (n >= 188U && b[0]==0x47U && (n < 376U || b[188U]==0x47U) && (n < 564U || b[376U]==0x47U)) { x.container=XM_CONTAINER_MPEG_TS; x.kind=XM_KIND_VIDEO; }
        else if (memcmp(b, "ID3", 3U)==0 || (b[0]==0xFFU && (b[1]&0xE0U)==0xE0U)) { x.container=XM_CONTAINER_MP3; x.kind=XM_KIND_AUDIO; x.audio_codec=XM_CODEC_MP3; x.has_audio=1; }
        else if (b[0]==0xFFU && (b[1]&0xF6U)==0xF0U) { x.container=XM_CONTAINER_AAC_ADTS; x.kind=XM_KIND_AUDIO; x.audio_codec=XM_CODEC_AAC; x.has_audio=1; }
    } else if (b != NULL && n >= 4U) {
        if (memcmp(b,"qoif",4U)==0) { x.container=XM_CONTAINER_QOI; x.kind=XM_KIND_IMAGE; }
        else if (memcmp(b,"OggS",4U)==0) { x.container=XM_CONTAINER_OGG; x.kind=XM_KIND_AUDIO; }
        else if (memcmp(b,"fLaC",4U)==0) { x.container=XM_CONTAINER_FLAC; x.kind=XM_KIND_AUDIO; x.audio_codec=XM_CODEC_FLAC; x.has_audio=1; }
        else if (memcmp(b,"\x1A\x45\xDF\xA3",4U)==0) { x.container=XM_CONTAINER_MATROSKA; x.kind=XM_KIND_VIDEO; }
    }
    if (x.container == XM_CONTAINER_UNKNOWN && mime != NULL) {
        if (contains_nocase(mime,"application/vnd.apple.mpegurl") || contains_nocase(mime,"application/x-mpegurl") || contains_nocase(mime,"audio/mpegurl")) { x.container=XM_CONTAINER_HLS; x.kind=XM_KIND_PLAYLIST; }
        else if (contains_nocase(mime,"application/dash+xml")) { x.container=XM_CONTAINER_MPEG_DASH; x.kind=XM_KIND_PLAYLIST; }
        else if (contains_nocase(mime,"text/vtt")) { x.container=XM_CONTAINER_WEBVTT; x.kind=XM_KIND_SUBTITLE; }
        else if (contains_nocase(mime,"video/mp4") || contains_nocase(mime,"audio/mp4") || contains_nocase(mime,"application/mp4")) { x.container=XM_CONTAINER_ISO_BMFF; x.kind=contains_nocase(mime,"audio/")?XM_KIND_AUDIO:XM_KIND_VIDEO; }
        else if (contains_nocase(mime,"audio/wav") || contains_nocase(mime,"audio/wave") || contains_nocase(mime,"audio/x-wav")) { x.container=XM_CONTAINER_WAVE; x.kind=XM_KIND_AUDIO; x.has_audio=1; }
        else if (contains_nocase(mime,"audio/mpeg")) { x.container=XM_CONTAINER_MP3; x.kind=XM_KIND_AUDIO; x.audio_codec=XM_CODEC_MP3; x.has_audio=1; }
        else if (contains_nocase(mime,"audio/aac") || contains_nocase(mime,"audio/aacp")) { x.container=XM_CONTAINER_AAC_ADTS; x.kind=XM_KIND_AUDIO; x.audio_codec=XM_CODEC_AAC; x.has_audio=1; }
        else if (contains_nocase(mime,"image/bmp")) { x.container=XM_CONTAINER_BMP; x.kind=XM_KIND_IMAGE; x.supported_for_native_decode=1; }
        else if (contains_nocase(mime,"image/png")) { x.container=XM_CONTAINER_PNG; x.kind=XM_KIND_IMAGE; x.supported_for_native_decode=1U; }
        else if (contains_nocase(mime,"image/qoi") || contains_nocase(mime,"image/x-qoi")) { x.container=XM_CONTAINER_QOI; x.kind=XM_KIND_IMAGE; x.supported_for_native_decode=1U; }
        else if (contains_nocase(mime,"image/x-portable-pixmap")) { x.container=XM_CONTAINER_PPM; x.kind=XM_KIND_IMAGE; x.supported_for_native_decode=1U; }
        else if (contains_nocase(mime,"image/jpeg")) { x.container=XM_CONTAINER_JPEG; x.kind=XM_KIND_IMAGE; x.supported_for_native_decode=1U; }
        else if (contains_nocase(mime,"image/gif")) { x.container=XM_CONTAINER_GIF; x.kind=XM_KIND_IMAGE; x.supported_for_native_decode=1U; }
    }
    if (x.container == XM_CONTAINER_UNKNOWN && url != NULL) {
        if (url_ext_eq(url,".wav")) { x.container=XM_CONTAINER_WAVE; x.kind=XM_KIND_AUDIO; x.audio_codec=XM_CODEC_PCM_S16LE; x.has_audio=1; x.supported_for_native_decode=1; }
        else if (url_ext_eq(url,".avi")) { x.container=XM_CONTAINER_AVI; x.kind=XM_KIND_VIDEO; x.has_video=1; }
        else if (url_ext_eq(url,".mp4") || url_ext_eq(url,".m4v") || url_ext_eq(url,".m4a") || url_ext_eq(url,".mov")) { x.container=XM_CONTAINER_ISO_BMFF; x.kind=url_ext_eq(url,".m4a")?XM_KIND_AUDIO:XM_KIND_VIDEO; }
        else if (url_ext_eq(url,".ts") || url_ext_eq(url,".m2ts")) { x.container=XM_CONTAINER_MPEG_TS; x.kind=XM_KIND_VIDEO; }
        else if (url_ext_eq(url,".mkv") || url_ext_eq(url,".webm")) { x.container=XM_CONTAINER_MATROSKA; x.kind=XM_KIND_VIDEO; }
        else if (url_ext_eq(url,".mp3")) { x.container=XM_CONTAINER_MP3; x.kind=XM_KIND_AUDIO; x.audio_codec=XM_CODEC_MP3; x.has_audio=1; }
        else if (url_ext_eq(url,".aac")) { x.container=XM_CONTAINER_AAC_ADTS; x.kind=XM_KIND_AUDIO; x.audio_codec=XM_CODEC_AAC; x.has_audio=1; }
        else if (url_ext_eq(url,".ogg") || url_ext_eq(url,".oga")) { x.container=XM_CONTAINER_OGG; x.kind=XM_KIND_AUDIO; }
        else if (url_ext_eq(url,".flac")) { x.container=XM_CONTAINER_FLAC; x.kind=XM_KIND_AUDIO; x.audio_codec=XM_CODEC_FLAC; x.has_audio=1; }
        else if (url_ext_eq(url,".m3u8")) { x.container=XM_CONTAINER_HLS; x.kind=XM_KIND_PLAYLIST; }
        else if (url_ext_eq(url,".mpd")) { x.container=XM_CONTAINER_MPEG_DASH; x.kind=XM_KIND_PLAYLIST; }
        else if (url_ext_eq(url,".vtt")) { x.container=XM_CONTAINER_WEBVTT; x.kind=XM_KIND_SUBTITLE; }
        else if (url_ext_eq(url,".bmp")) { x.container=XM_CONTAINER_BMP; x.kind=XM_KIND_IMAGE; x.supported_for_native_decode=1; }
        else if (url_ext_eq(url,".png")) { x.container=XM_CONTAINER_PNG; x.kind=XM_KIND_IMAGE; x.supported_for_native_decode=1U; }
        else if (url_ext_eq(url,".jpg") || url_ext_eq(url,".jpeg")) { x.container=XM_CONTAINER_JPEG; x.kind=XM_KIND_IMAGE; x.supported_for_native_decode=1U; }
        else if (url_ext_eq(url,".gif")) { x.container=XM_CONTAINER_GIF; x.kind=XM_KIND_IMAGE; x.supported_for_native_decode=1U; }
        else if (url_ext_eq(url,".qoi")) { x.container=XM_CONTAINER_QOI; x.kind=XM_KIND_IMAGE; x.supported_for_native_decode=1U; }
        else if (url_ext_eq(url,".ppm")) { x.container=XM_CONTAINER_PPM; x.kind=XM_KIND_IMAGE; x.supported_for_native_decode=1U; }
    }
    if (x.container == XM_CONTAINER_AVI && b != NULL && n >= 12U) {
        XmAviInfo avi;
        if (xm_media_parse_avi(b, n, &avi)) {
            x.width = avi.width; x.height = avi.height; x.frame_rate_num = avi.frame_rate_num;
            x.frame_rate_den = avi.frame_rate_den; x.duration_ms = avi.duration_ms;
            x.supported_for_native_decode = avi.native_raw_video;
            if (avi.native_raw_video) x.video_codec = XM_CODEC_RAW_RGB;
            x.complete = 1U;
        }
    }
    if (x.container == XM_CONTAINER_UNKNOWN) return 0;
    if (out != NULL) *out = x;
    return 1;
}

/* ISO-BMFF box traversal: only known containers are descended into. */
typedef struct { XmMediaInfo *info; uint32_t boxes; uint32_t time_scale; } Mp4Scan;
static int is_box_container(const uint8_t *t) {
    static const char *const tags[] = {"moov","trak","mdia","minf","stbl","edts","dinf","mvex","moof","traf","mfra","udta","meta","ilst"};
    size_t i; for (i=0U;i<sizeof(tags)/sizeof(tags[0]);++i) if (memcmp(t,tags[i],4U)==0) return 1; return 0;
}
static int mp4_walk(const uint8_t *b, size_t start, size_t end, unsigned depth, Mp4Scan *scan) {
    size_t off = start;
    if (depth > XM_MAX_NESTING || start > end || end > SIZE_MAX) return 0;
    while (off < end) {
        uint64_t box_size; size_t header=8U, payload, box_end; const uint8_t *type;
        if (end-off < 8U || ++scan->boxes > XM_MAX_BOXES) return 0;
        box_size = rd32be(b+off); type=b+off+4U;
        if (box_size == 1U) { if (end-off < 16U) return 0; box_size=rd64be(b+off+8U); header=16U; }
        else if (box_size == 0U) box_size=(uint64_t)(end-off);
        if (box_size < header || box_size > (uint64_t)(end-off) || box_size > (uint64_t)SIZE_MAX) return 0;
        box_end=off+(size_t)box_size; payload=off+header;
        if (tag_eq(type,"mvhd")) {
            uint8_t version; uint32_t ts; uint64_t dur;
            if (box_end-payload < 20U) return 0;
            version=b[payload];
            if (version==0U) { ts=rd32be(b+payload+12U); dur=rd32be(b+payload+16U); }
            else if (version==1U) { if (box_end-payload < 32U) return 0; ts=rd32be(b+payload+20U); dur=rd64be(b+payload+24U); }
            else return 0;
            if (ts != 0U) { scan->time_scale=ts; if (dur != UINT64_MAX) scan->info->duration_ms=(dur/ts)*1000U+((dur%ts)*1000U)/ts; }
        } else if (tag_eq(type,"hdlr")) {
            if (box_end-payload < 12U) return 0;
            if (memcmp(b+payload+8U,"vide",4U)==0) { scan->info->has_video=1; scan->info->kind=XM_KIND_VIDEO; }
            if (memcmp(b+payload+8U,"soun",4U)==0) { scan->info->has_audio=1; if (!scan->info->has_video) scan->info->kind=XM_KIND_AUDIO; }
        } else if (tag_eq(type,"stsd")) {
            size_t entry;
            if (box_end-payload < 8U) return 0;
            entry=payload+8U;
            if (entry+8U<=box_end) {
                const uint8_t *fourcc=b+entry+4U;
                if (tag_eq(fourcc,"avc1") || tag_eq(fourcc,"avc3")) scan->info->video_codec=XM_CODEC_AVC;
                else if (tag_eq(fourcc,"hvc1") || tag_eq(fourcc,"hev1")) scan->info->video_codec=XM_CODEC_HEVC;
                else if (tag_eq(fourcc,"av01")) scan->info->video_codec=XM_CODEC_AV1;
                else if (tag_eq(fourcc,"vp09")) scan->info->video_codec=XM_CODEC_VP9;
                else if (tag_eq(fourcc,"vp08")) scan->info->video_codec=XM_CODEC_VP8;
                else if (tag_eq(fourcc,"mp4a")) scan->info->audio_codec=XM_CODEC_AAC;
                else if (tag_eq(fourcc,"Opus")) scan->info->audio_codec=XM_CODEC_OPUS;
                else if (tag_eq(fourcc,"fLaC")) scan->info->audio_codec=XM_CODEC_FLAC;
                else if (tag_eq(fourcc,"mp4v")) scan->info->video_codec=XM_CODEC_MJPEG;
            }
        } else if (is_box_container(type)) {
            size_t child_start=payload;
            if (tag_eq(type,"meta")) { if (box_end-child_start<4U) return 0; child_start+=4U; }
            if (child_start<box_end && !mp4_walk(b,child_start,box_end,depth+1U,scan)) return 0;
        }
        off=box_end;
    }
    return off==end;
}
int xm_media_parse_mp4(const uint8_t *b, size_t n, XmMediaInfo *info) {
    XmMediaInfo tmp; Mp4Scan scan; size_t off=0U; int ftyp=0;
    if (b==NULL || info==NULL || n<8U) return 0;
    memset(&tmp,0,sizeof(tmp)); tmp.container=XM_CONTAINER_ISO_BMFF; tmp.kind=XM_KIND_VIDEO;
    memset(&scan,0,sizeof(scan)); scan.info=&tmp;
    /* First pass confirms ftyp, and strict top-level box framing. */
    while (off<n) {
        uint64_t size; size_t header=8U;
        if (n-off<8U) return 0;
        size=rd32be(b+off);
        if (size==1U) { if(n-off<16U)return 0; size=rd64be(b+off+8U); header=16U; }
        else if(size==0U) size=(uint64_t)(n-off);
        if(size<header || size>(uint64_t)(n-off) || size>(uint64_t)SIZE_MAX) return 0;
        if (tag_eq(b+off+4U,"ftyp")) ftyp=1;
        off+=(size_t)size;
    }
    if (!ftyp || !mp4_walk(b,0U,n,0U,&scan)) return 0;
    tmp.complete=1U;
    if (tmp.has_video) tmp.kind=XM_KIND_VIDEO; else if (tmp.has_audio) tmp.kind=XM_KIND_AUDIO;
    *info=tmp; return 1;
}

int xm_media_parse_wav(const uint8_t *b, size_t n, XmWavInfo *out) {
    XmWavInfo x; size_t off, riff_end; int have_fmt=0, have_data=0;
    memset(&x,0,sizeof(x));
    if (b==NULL || out==NULL || n<12U || memcmp(b,"RIFF",4U)!=0 || memcmp(b+8U,"WAVE",4U)!=0) return 0;
    { uint32_t riff_size=rd32le(b+4U); if ((uint64_t)riff_size+8U>(uint64_t)n || riff_size<4U) return 0; riff_end=(size_t)riff_size+8U; }
    off=12U;
    while(off+8U<=riff_end) {
        uint32_t chunk=rd32le(b+off+4U); size_t data_off=off+8U; uint64_t next64=(uint64_t)data_off+(uint64_t)chunk+((chunk&1U)?1U:0U);
        if ((uint64_t)data_off+(uint64_t)chunk>(uint64_t)riff_end || next64>(uint64_t)riff_end) return 0;
        if(memcmp(b+off,"fmt ",4U)==0) {
            if(chunk<16U) return 0;
            x.format_tag=rd16le(b+data_off); x.channels=rd16le(b+data_off+2U); x.sample_rate=rd32le(b+data_off+4U);
            x.block_align=rd16le(b+data_off+12U); x.bits_per_sample=rd16le(b+data_off+14U);
            if (x.format_tag==0x0011U) {
                if (chunk<20U || rd16le(b+data_off+16U)<2U) return 0;
                x.samples_per_block=rd16le(b+data_off+18U);
            }
            have_fmt=1;
        } else if(memcmp(b+off,"data",4U)==0) { x.data_offset=(uint64_t)data_off; x.data_bytes=chunk; have_data=1; }
        off=(size_t)next64;
    }
    if(!have_fmt || !have_data || (x.channels!=1U && x.channels!=2U) || x.sample_rate<8000U || x.sample_rate>192000U || x.block_align==0U) return 0;
    if (x.format_tag==1U) {
        if ((x.bits_per_sample!=8U && x.bits_per_sample!=16U) ||
            x.block_align!=(uint16_t)(x.channels*(x.bits_per_sample/8U)) || x.data_bytes%x.block_align!=0U) return 0;
        x.total_samples=x.data_bytes/x.block_align;
    } else if (x.format_tag==0x0011U) {
        uint32_t header_bytes=(uint32_t)x.channels*4U;
        uint32_t payload_bytes;
        uint32_t expected_samples;
        if (x.bits_per_sample!=4U || (uint32_t)x.block_align<=header_bytes ||
            ((uint32_t)x.block_align-header_bytes)%(4U*(uint32_t)x.channels)!=0U ||
            x.data_bytes%x.block_align!=0U) return 0;
        payload_bytes=(uint32_t)x.block_align-header_bytes;
        expected_samples=1U+((payload_bytes/(uint32_t)x.channels)/4U)*8U;
        if (x.samples_per_block!=expected_samples || x.samples_per_block<2U) return 0;
        x.total_samples=(x.data_bytes/x.block_align)*(uint64_t)x.samples_per_block;
    } else return 0;
    /* total_samples is per-channel sample frames, not interleaved scalar samples. */
    x.duration_ms=(x.total_samples*1000U)/x.sample_rate;
    *out=x; return 1;
}

static const int ima_step_table[89] = {
    7,8,9,10,11,12,13,14,16,17,19,21,23,25,28,31,34,37,41,45,50,55,60,66,73,80,88,97,107,118,
    130,143,157,173,190,209,230,253,279,307,337,371,408,449,494,544,598,658,724,796,876,963,1060,
    1166,1282,1411,1552,1707,1878,2066,2272,2499,2749,3024,3327,3660,4026,4428,4871,5358,5894,
    6484,7132,7845,8630,9493,10442,11487,12635,13899,15289,16818,18500,20350,22385,24623,27086,
    29794,32767
};
static const int ima_index_table[16] = {-1,-1,-1,-1,2,4,6,8,-1,-1,-1,-1,2,4,6,8};

static int16_t ima_decode_nibble(int nibble, int *predictor, int *index)
{
    int step=ima_step_table[*index];
    int diff=step>>3;
    if ((nibble&1)!=0) diff += step>>2;
    if ((nibble&2)!=0) diff += step>>1;
    if ((nibble&4)!=0) diff += step;
    if ((nibble&8)!=0) *predictor -= diff; else *predictor += diff;
    if (*predictor > 32767) *predictor=32767;
    if (*predictor < -32768) *predictor=-32768;
    *index += ima_index_table[nibble&15];
    if (*index < 0) *index=0;
    if (*index > 88) *index=88;
    return (int16_t)*predictor;
}

int xm_media_decode_wav_pcm16(const uint8_t *b,size_t n,int16_t *out,size_t cap,size_t *written,XmWavInfo *info) {
    XmWavInfo w; size_t scalar_count,i; const uint8_t *data;
    if(written!=NULL)*written=0U;
    if(out==NULL || !xm_media_parse_wav(b,n,&w)) return 0;
    if(w.total_samples>(uint64_t)(SIZE_MAX/(size_t)w.channels)) return 0;
    scalar_count=(size_t)w.total_samples*(size_t)w.channels;
    if(scalar_count>cap) return 0;
    data=b+(size_t)w.data_offset;
    if (w.format_tag==1U) {
        if(w.bits_per_sample==8U) for(i=0U;i<scalar_count;++i) out[i]=(int16_t)(((int)data[i]-128)*256);
        else for(i=0U;i<scalar_count;++i) { uint16_t u=(uint16_t)((uint16_t)data[i*2U]|((uint16_t)data[i*2U+1U]<<8U)); int32_t signed_value=u>=0x8000U?(int32_t)u-65536:(int32_t)u; out[i]=(int16_t)signed_value; }
    } else if (w.format_tag==0x0011U) {
        size_t block_off=0U;
        while (block_off<(size_t)w.data_bytes) {
            const uint8_t *block=data+block_off;
            int predictor[2]={0,0}, index[2]={0,0};
            size_t sample_pos[2]={1U,1U};
            size_t ch, cursor=(size_t)w.channels*4U;
            size_t frame_base=(block_off/(size_t)w.block_align)*(size_t)w.samples_per_block;
            for(ch=0U;ch<(size_t)w.channels;++ch) {
                uint16_t pred=(uint16_t)((uint16_t)block[ch*4U]|((uint16_t)block[ch*4U+1U]<<8U));
                predictor[ch]=pred>=0x8000U?(int)pred-65536:(int)pred;
                index[ch]=(int)block[ch*4U+2U];
                if(index[ch]>88 || block[ch*4U+3U]!=0U) return 0;
                out[frame_base*(size_t)w.channels+ch]=(int16_t)predictor[ch];
            }
            while(cursor<(size_t)w.block_align) {
                for(ch=0U;ch<(size_t)w.channels;++ch) {
                    size_t k;
                    if(cursor+4U>(size_t)w.block_align) return 0;
                    for(k=0U;k<4U;++k) {
                        unsigned byte=block[cursor+k];
                        int16_t smp;
                        if(sample_pos[ch] >= (size_t)w.samples_per_block) return 0;
                        smp=ima_decode_nibble((int)(byte&15U),&predictor[ch],&index[ch]);
                        out[(frame_base+sample_pos[ch])*(size_t)w.channels+ch]=smp; ++sample_pos[ch];
                        if(sample_pos[ch] >= (size_t)w.samples_per_block) return 0;
                        smp=ima_decode_nibble((int)((byte>>4U)&15U),&predictor[ch],&index[ch]);
                        out[(frame_base+sample_pos[ch])*(size_t)w.channels+ch]=smp; ++sample_pos[ch];
                    }
                    cursor+=4U;
                }
            }
            for(ch=0U;ch<(size_t)w.channels;++ch)
                if(sample_pos[ch]!=(size_t)w.samples_per_block) return 0;
            block_off+=(size_t)w.block_align;
        }
    } else return 0;
    if(written!=NULL)*written=scalar_count;
    if(info!=NULL)*info=w;
    return 1;
}

int xm_media_decode_bmp_rgba(const uint8_t *b, size_t n, uint8_t *out, size_t cap, XmImageInfo *info) {
    uint32_t dib, width_u, compression, pixel_off, colors_used;
    int32_t width, height;
    uint16_t planes, bpp;
    uint64_t stride, needed, pixels, palette_start;
    uint32_t palette_count = 0U, y, x;
    int top_down;
    XmImageInfo tmp;
    if (b == NULL || out == NULL || n < 54U || b[0] != 'B' || b[1] != 'M') return 0;
    pixel_off = rd32le(b + 10U);
    dib = rd32le(b + 14U);
    if (dib < 40U || (uint64_t)14U + dib > (uint64_t)n || pixel_off < 14U + dib) return 0;
    {
        uint32_t declared = rd32le(b + 2U);
        if (declared != 0U && (declared > (uint32_t)n || declared < pixel_off)) return 0;
    }
    width = (int32_t)rd32le(b + 18U);
    height = (int32_t)rd32le(b + 22U);
    planes = rd16le(b + 26U);
    bpp = rd16le(b + 28U);
    compression = rd32le(b + 30U);
    colors_used = rd32le(b + 46U);
    if (width <= 0 || height == 0 || height == INT32_MIN || planes != 1U ||
        (bpp != 1U && bpp != 4U && bpp != 8U && bpp != 24U && bpp != 32U) || compression != 0U) return 0;
    top_down = height < 0;
    width_u = (uint32_t)width;
    tmp.width = width_u;
    tmp.height = (uint32_t)(top_down ? -height : height);
    tmp.channels = 4U;
    pixels = (uint64_t)tmp.width * (uint64_t)tmp.height;
    if (tmp.width > XM_MAX_DIMENSION || tmp.height > XM_MAX_DIMENSION || pixels > XM_MAX_PIXELS ||
        pixels > SIZE_MAX / 4U || pixels * 4U > cap) return 0;

    if (bpp <= 8U) {
        uint32_t max_palette = UINT32_C(1) << bpp;
        palette_count = colors_used == 0U ? max_palette : colors_used;
        palette_start = UINT64_C(14) + dib;
        if (palette_count == 0U || palette_count > max_palette ||
            palette_start + (uint64_t)palette_count * 4U > pixel_off ||
            palette_start + (uint64_t)palette_count * 4U > n) return 0;
    }
    stride = (((uint64_t)tmp.width * (uint64_t)bpp + 31U) / 32U) * 4U;
    needed = (uint64_t)pixel_off + stride * (uint64_t)tmp.height;
    if (pixel_off > (uint32_t)n || needed > (uint64_t)n) return 0;
    for (y = 0U; y < tmp.height; ++y) {
        uint32_t sy = top_down ? y : (tmp.height - 1U - y);
        const uint8_t *row = b + pixel_off + (size_t)((uint64_t)sy * stride);
        for (x = 0U; x < tmp.width; ++x) {
            size_t dst = ((size_t)y * tmp.width + x) * 4U;
            if (bpp <= 8U) {
                uint32_t index;
                const uint8_t *entry;
                if (bpp == 8U) index = row[x];
                else if (bpp == 4U) index = ((uint32_t)row[x >> 1U] >> ((x & 1U) == 0U ? 4U : 0U)) & 0x0FU;
                else index = ((uint32_t)row[x >> 3U] >> (7U - (x & 7U))) & 1U;
                if (index >= palette_count) return 0;
                entry = b + (size_t)palette_start + (size_t)index * 4U;
                out[dst] = entry[2]; out[dst + 1U] = entry[1]; out[dst + 2U] = entry[0]; out[dst + 3U] = 255U;
            } else {
                size_t src = (size_t)x * (size_t)(bpp / 8U);
                out[dst] = row[src + 2U]; out[dst + 1U] = row[src + 1U]; out[dst + 2U] = row[src]; out[dst + 3U] = 255U;
            }
        }
    }
    if (info != NULL) *info = tmp;
    return 1;
}

static uint8_t qoi_hash(const uint8_t p[4]) { return (uint8_t)(((unsigned)p[0]*3U+(unsigned)p[1]*5U+(unsigned)p[2]*7U+(unsigned)p[3]*11U)%64U); }
int xm_media_decode_qoi_rgba(const uint8_t *b,size_t n,uint8_t *out,size_t cap,XmImageInfo *info) {
    uint32_t width,height; uint8_t channels; uint8_t index[64][4]={{0}}; uint8_t px[4]={0,0,0,255}; size_t pos=14U; uint64_t count,run=0U; uint64_t i; XmImageInfo tmp;
    if(b==NULL||out==NULL||n<22U||memcmp(b,"qoif",4U)!=0)return 0;
    width=rd32be(b+4U);height=rd32be(b+8U);channels=b[12U];
    if(width==0U||height==0U||width>XM_MAX_DIMENSION||height>XM_MAX_DIMENSION||(channels!=3U&&channels!=4U)||b[13U]>1U)return 0;
    count=(uint64_t)width*height;if(count>XM_MAX_PIXELS||count>SIZE_MAX/4U||count*4U>cap)return 0;
    for(i=0U;i<count;++i){
        if(run>0U) --run;
        else {
            uint8_t op; if(pos>=n-8U)return 0; op=b[pos++];
            if(op==0xFEU){if(pos+3U>n-8U)return 0;px[0]=b[pos++];px[1]=b[pos++];px[2]=b[pos++];}
            else if(op==0xFFU){if(pos+4U>n-8U)return 0;px[0]=b[pos++];px[1]=b[pos++];px[2]=b[pos++];px[3]=b[pos++];}
            else if((op&0xC0U)==0x00U){memcpy(px,index[op&0x3FU],4U);}
            else if((op&0xC0U)==0x40U){px[0]=(uint8_t)(px[0]+((op>>4U&3U)-2));px[1]=(uint8_t)(px[1]+((op>>2U&3U)-2));px[2]=(uint8_t)(px[2]+((op&3U)-2));}
            else if((op&0xC0U)==0x80U){uint8_t op2;int dg=(int)(op&0x3FU)-32;int dr_dg,db_dg;if(pos>=n-8U)return 0;op2=b[pos++];dr_dg=(int)(op2>>4U)-8;db_dg=(int)(op2&0x0FU)-8;px[0]=(uint8_t)((int)px[0]+dg+dr_dg);px[1]=(uint8_t)((int)px[1]+dg);px[2]=(uint8_t)((int)px[2]+dg+db_dg);}
            else {run=(uint64_t)(op&0x3FU);}
            memcpy(index[qoi_hash(px)],px,4U);
        }
        memcpy(out+(size_t)i*4U,px,4U);
    }
    if(memcmp(b+n-8U,"\0\0\0\0\0\0\0\1",8U)!=0)return 0;
    tmp.width=width;tmp.height=height;tmp.channels=channels;if(info!=NULL)*info=tmp;return 1;
}

/* Minimal first-party AVI structure walker. Only uncompressed BI_RGB 24/32-bit
 * frames are eligible for native raster extraction; other codecs remain inspectable. */
static int avi_chunk_bounds(const uint8_t *b, size_t end, size_t off,
                            size_t *data_off, size_t *chunk_end, uint32_t *chunk_size) {
    uint32_t sz;
    uint64_t next;
    if (off > end || end - off < 8U) return 0;
    sz = rd32le(b + off + 4U);
    next = (uint64_t)off + 8U + (uint64_t)sz + (uint64_t)(sz & 1U);
    if (next > (uint64_t)end || next > (uint64_t)SIZE_MAX) return 0;
    if (data_off != NULL) *data_off = off + 8U;
    if (chunk_end != NULL) *chunk_end = (size_t)next;
    if (chunk_size != NULL) *chunk_size = sz;
    return 1;
}

static int avi_read_stream(const uint8_t *b, size_t start, size_t end, uint32_t stream_index,
                           XmAviInfo *x) {
    size_t off = start;
    char stream_type[5] = {0};
    uint32_t scale = 0U, rate = 0U, length = 0U;
    int32_t bitmap_w = 0, bitmap_h = 0;
    uint32_t compression = 0U;
    uint16_t planes = 0U, bpp = 0U;
    int got_header = 0, got_format = 0;
    while (off < end) {
        size_t data, next;
        uint32_t sz;
        if (!avi_chunk_bounds(b, end, off, &data, &next, &sz)) return 0;
        if (memcmp(b + off, "strh", 4U) == 0) {
            if (sz < 56U) return 0;
            memcpy(stream_type, b + data, 4U);
            scale = rd32le(b + data + 20U);
            rate = rd32le(b + data + 24U);
            length = rd32le(b + data + 32U);
            got_header = 1;
        } else if (memcmp(b + off, "strf", 4U) == 0) {
            if (sz < 40U) return 0;
            bitmap_w = (int32_t)rd32le(b + data + 4U);
            bitmap_h = (int32_t)rd32le(b + data + 8U);
            planes = rd16le(b + data + 12U);
            bpp = rd16le(b + data + 14U);
            compression = rd32le(b + data + 16U);
            got_format = 1;
        }
        off = next;
    }
    if (got_header && memcmp(stream_type, "vids", 4U) == 0) {
        int32_t signed_h;
        if (!got_format || bitmap_w <= 0 || bitmap_w > (int32_t)XM_MAX_DIMENSION || bitmap_h == 0 || bitmap_h == INT32_MIN) return 0;
        signed_h = bitmap_h;
        x->width = (uint32_t)bitmap_w;
        x->top_down = (uint8_t)(signed_h < 0);
        x->height = (uint32_t)(signed_h < 0 ? -signed_h : signed_h);
        if (x->height > XM_MAX_DIMENSION) return 0;
        x->video_stream_index = stream_index;
        x->bits_per_pixel = bpp;
        x->compression = compression;
        x->native_raw_video = (uint8_t)(planes == 1U && compression == 0U && (bpp == 24U || bpp == 32U));
        x->frame_count = length;
        x->frame_rate_num = rate;
        x->frame_rate_den = scale == 0U ? 1U : scale;
        if (rate != 0U && scale != 0U) {
            x->duration_ms = ((uint64_t)length * (uint64_t)scale * 1000U) / (uint64_t)rate;
        }
    }
    return 1;
}

static int avi_parse_hdrl(const uint8_t *b, size_t start, size_t end, XmAviInfo *x) {
    size_t off = start;
    uint32_t stream_index = 0U;
    while (off < end) {
        size_t data, next;
        uint32_t sz;
        if (!avi_chunk_bounds(b, end, off, &data, &next, &sz)) return 0;
        if (memcmp(b + off, "avih", 4U) == 0) {
            if (sz < 40U) return 0;
            if (x->frame_rate_num == 0U) {
                uint32_t usec = rd32le(b + data);
                if (usec != 0U) { x->frame_rate_num = 1000000U; x->frame_rate_den = usec; }
            }
            x->frame_count = rd32le(b + data + 16U);
            if (x->width == 0U) x->width = rd32le(b + data + 32U);
            if (x->height == 0U) x->height = rd32le(b + data + 36U);
        } else if (memcmp(b + off, "LIST", 4U) == 0 && sz >= 4U && memcmp(b + data, "strl", 4U) == 0) {
            if (!avi_read_stream(b, data + 4U, data + sz, stream_index, x)) return 0;
            ++stream_index;
        }
        off = next;
    }
    return 1;
}

#define XM_DEFLATE_MAX_NODES 640U
#define XM_PNG_MAX_COMPRESSED (16U * 1024U * 1024U)
typedef struct {
    const uint8_t *data;
    size_t length;
    size_t bit_position;
} XmDeflateBits;
typedef struct {
    int16_t child[XM_DEFLATE_MAX_NODES][2];
    int16_t symbol[XM_DEFLATE_MAX_NODES];
    uint16_t nodes;
} XmDeflateTree;

static int xm_deflate_get_bits(XmDeflateBits *bits, unsigned count, uint32_t *value) {
    uint32_t out = 0U;
    unsigned i;
    if (bits == NULL || value == NULL || count > 24U || bits->bit_position > bits->length * 8U ||
        (size_t)count > bits->length * 8U - bits->bit_position) return 0;
    for (i = 0U; i < count; ++i) {
        size_t p = bits->bit_position++;
        out |= (((uint32_t)bits->data[p >> 3U] >> (unsigned)(p & 7U)) & UINT32_C(1)) << i;
    }
    *value = out;
    return 1;
}
static void xm_deflate_tree_init(XmDeflateTree *tree) {
    unsigned i;
    tree->nodes = 1U;
    for (i=0U;i<XM_DEFLATE_MAX_NODES;++i) {
        tree->child[i][0]=-1; tree->child[i][1]=-1; tree->symbol[i]=-1;
    }
}
static int xm_deflate_tree_build(XmDeflateTree *tree, const uint8_t *lengths, unsigned count) {
    unsigned counts[16]={0U}, next_code[16]={0U}, sym, bits;
    uint32_t code=0U;
    if(tree==NULL||lengths==NULL||count==0U||count>288U)return 0;
    xm_deflate_tree_init(tree);
    for(sym=0U;sym<count;++sym){if(lengths[sym]>15U)return 0;if(lengths[sym]!=0U)++counts[lengths[sym]];}
    for (bits = 1U; bits <= 15U; ++bits) {
        code = (code + counts[bits - 1U]) << 1U;
        /* A completely filled tree may yield 2^bits for the next empty length. */
        if (counts[bits] != 0U && code >= (1U << bits)) return 0;
        next_code[bits] = code;
    }
    for(sym=0U;sym<count;++sym){
        unsigned len=lengths[sym],node=0U,i;
        uint32_t c;
        if(len==0U)continue;
        c=next_code[len]++;
        for(i=0U;i<len;++i){
            unsigned direction=(unsigned)((c>>(len-1U-i))&1U);
            int16_t next=tree->child[node][direction];
            if(i+1U==len){
                if(next>=0||tree->symbol[node]>=0||tree->nodes>=XM_DEFLATE_MAX_NODES)return 0;
                next=(int16_t)tree->nodes++;
                tree->child[node][direction]=next;
                tree->symbol[(unsigned)next]=(int16_t)sym;
            } else {
                if(next<0){if(tree->nodes>=XM_DEFLATE_MAX_NODES)return 0;next=(int16_t)tree->nodes++;tree->child[node][direction]=next;}
                if(tree->symbol[(unsigned)next]>=0)return 0;
            }
            node=(unsigned)next;
        }
    }
    return 1;
}
static int xm_deflate_decode_symbol(XmDeflateBits *bits, const XmDeflateTree *tree, unsigned *symbol) {
    unsigned node=0U,depth;
    for(depth=0U;depth<15U;++depth){uint32_t bit;int16_t next;if(!xm_deflate_get_bits(bits,1U,&bit))return 0;next=tree->child[node][bit];if(next<0)return 0;node=(unsigned)next;if(tree->symbol[node]>=0){*symbol=(unsigned)tree->symbol[node];return 1;}}
    return 0;
}
static int xm_deflate_fixed_trees(XmDeflateTree *lit, XmDeflateTree *dist) {
    uint8_t ll[288],dd[32];unsigned i;
    for (i = 0U; i <= 143U; ++i) ll[i] = 8U;
    for (i = 144U; i <= 255U; ++i) ll[i] = 9U;
    for (i = 256U; i <= 279U; ++i) ll[i] = 7U;
    for (i = 280U; i < 288U; ++i) ll[i] = 8U;
    for (i = 0U; i < 32U; ++i) dd[i] = 5U;
    return xm_deflate_tree_build(lit,ll,288U)&&xm_deflate_tree_build(dist,dd,32U);
}
static int xm_deflate_dynamic_trees(XmDeflateBits *bits, XmDeflateTree *lit, XmDeflateTree *dist) {
    static const uint8_t order[19]={16U,17U,18U,0U,8U,7U,9U,6U,10U,5U,11U,4U,12U,3U,13U,2U,14U,1U,15U};
    uint32_t v;unsigned hlit,hdist,hclen,i,total,pos=0U,sym;uint8_t clen[19]={0U},lens[320]={0U};XmDeflateTree ctree;
    if (!xm_deflate_get_bits(bits, 5U, &v)) return 0;
    hlit = (unsigned)v + 257U;
    if (!xm_deflate_get_bits(bits, 5U, &v)) return 0;
    hdist = (unsigned)v + 1U;
    if (!xm_deflate_get_bits(bits, 4U, &v)) return 0;
    hclen = (unsigned)v + 4U;
    if(hlit>286U||hdist>32U||hclen>19U)return 0;
    for(i=0U;i<hclen;++i){if(!xm_deflate_get_bits(bits,3U,&v))return 0;clen[order[i]]=(uint8_t)v;}
    if(!xm_deflate_tree_build(&ctree,clen,19U))return 0;
    total=hlit+hdist;
    while(pos<total){
        if(!xm_deflate_decode_symbol(bits,&ctree,&sym))return 0;
        if(sym<=15U)lens[pos++]=(uint8_t)sym;
        else if(sym==16U){unsigned repeat;if(pos==0U||!xm_deflate_get_bits(bits,2U,&v))return 0;repeat=(unsigned)v+3U;if(repeat>total-pos)return 0;while(repeat--)lens[pos]=lens[pos-1U],++pos;}
        else if(sym==17U||sym==18U){unsigned repeat;if(!xm_deflate_get_bits(bits,sym==17U?3U:7U,&v))return 0;repeat=(unsigned)v+(sym==17U?3U:11U);if(repeat>total-pos)return 0;while(repeat--)lens[pos++]=0U;}
        else return 0;
    }
    if(lens[256U]==0U)return 0;
    return xm_deflate_tree_build(lit,lens,hlit)&&xm_deflate_tree_build(dist,lens+hlit,hdist);
}
static int xm_inflate_zlib_bounded(const uint8_t *input,size_t input_len,uint8_t *output,size_t expected) {
    static const uint16_t length_base[29]={3,4,5,6,7,8,9,10,11,13,15,17,19,23,27,31,35,43,51,59,67,83,99,115,131,163,195,227,258};
    static const uint8_t length_extra[29]={0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0};
    static const uint16_t dist_base[30]={1,2,3,4,5,7,9,13,17,25,33,49,65,97,129,193,257,385,513,769,1025,1537,2049,3073,4097,6145,8193,12289,16385,24577};
    static const uint8_t dist_extra[30]={0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13};
    XmDeflateBits bits;size_t outpos=0U;int final=0;uint32_t check;
    if(input==NULL||output==NULL||input_len<6U)return 0;
    if((input[0]&15U)!=8U||(input[0]>>4U)>7U||(((uint32_t)input[0]*256U+input[1])%31U)!=0U||(input[1]&32U)!=0U)return 0;
    bits.data=input+2U;bits.length=input_len-6U;bits.bit_position=0U;
    while(!final){uint32_t v,type;if(!xm_deflate_get_bits(&bits,1U,&v))return 0;final=(int)v;if(!xm_deflate_get_bits(&bits,2U,&type))return 0;
        if(type==0U){uint32_t len,nlen;bits.bit_position=(bits.bit_position+7U)&~(size_t)7U;if(!xm_deflate_get_bits(&bits,16U,&len)||!xm_deflate_get_bits(&bits,16U,&nlen)||((len^0xFFFFU)&0xFFFFU)!=(nlen&0xFFFFU)||len>expected-outpos)return 0;while(len--){if(!xm_deflate_get_bits(&bits,8U,&v))return 0;output[outpos++]=(uint8_t)v;}}
        else if(type==1U||type==2U){XmDeflateTree lit,dist;int trees=type==1U?xm_deflate_fixed_trees(&lit,&dist):xm_deflate_dynamic_trees(&bits,&lit,&dist);if(!trees)return 0;
            for(;;){unsigned sym;if(!xm_deflate_decode_symbol(&bits,&lit,&sym))return 0;if(sym<256U){if(outpos>=expected)return 0;output[outpos++]=(uint8_t)sym;}
                else if(sym==256U)break;else {unsigned li,di,extra_len,extra_dist;uint32_t add=0U,distance=0U;size_t run,j;
                    if (sym < 257U || sym > 285U) return 0;
                    li = sym - 257U;
                    extra_len = length_extra[li];
                    if (!xm_deflate_get_bits(&bits, extra_len, &add)) return 0;
                    run = (size_t)length_base[li] + (size_t)add;
                    if (!xm_deflate_decode_symbol(&bits, &dist, &di) || di >= 30U) return 0;
                    extra_dist = dist_extra[di];
                    if (!xm_deflate_get_bits(&bits, extra_dist, &add)) return 0;
                    distance = (uint32_t)dist_base[di] + add;
                    if(distance==0U||(size_t)distance>outpos||run>expected-outpos)return 0;
                    for(j=0U;j<run;++j){output[outpos]=output[outpos-(size_t)distance];++outpos;}
                }}
        } else return 0;
    }
    if(outpos!=expected)return 0;
    {uint32_t a=1U,b=0U;size_t i;for(i=0U;i<expected;++i){a=(a+output[i])%65521U;b=(b+a)%65521U;}check=(b<<16U)|a;}
    return check==rd32be(input+input_len-4U);
}
static uint32_t xm_png_crc32(const uint8_t *data,size_t n) {
    uint32_t crc=0xFFFFFFFFU;size_t i;unsigned bit;
    for(i=0U;i<n;++i){crc^=data[i];for(bit=0U;bit<8U;++bit)crc=(crc&1U)?(crc>>1U)^0xEDB88320U:crc>>1U;}
    return crc^0xFFFFFFFFU;
}
static uint8_t xm_paeth(uint8_t a,uint8_t b,uint8_t c) {
    int p=(int)a+(int)b-(int)c,pa=abs(p-(int)a),pb=abs(p-(int)b),pc=abs(p-(int)c);
    return pa<=pb&&pa<=pc?a:(pb<=pc?b:c);
}
int xm_media_decode_png_rgba(const uint8_t *b,size_t n,uint8_t *rgba,size_t cap,XmImageInfo *info) {
    size_t off=8U,idat_len=0U,idat_cap=0U,raw_len,row_bytes,pixels,i,y;uint8_t *idat=NULL,*raw=NULL;uint32_t width=0U,height=0U;uint8_t depth=0U,color=0U,channels=0U;uint8_t palette[768];size_t palette_len=0U;uint8_t alpha[256];size_t alpha_len=0U;int seen_ihdr=0,seen_idat=0,idat_closed=0,seen_iend=0;XmImageInfo outinfo;
    static const uint8_t pngsig[8]={137U,80U,78U,71U,13U,10U,26U,10U};
    memset(alpha,255,sizeof(alpha));
    if(b==NULL||rgba==NULL||n<8U||memcmp(b,pngsig,8U)!=0)return 0;
    while(off<n){uint32_t len,crc;const uint8_t *type,*data;size_t chunk_end;
        if (n - off < 12U) return 0;
        len = rd32be(b + off);
        if ((uint64_t)len + 12U > (uint64_t)(n - off)) goto fail;
        type = b + off + 4U;
        data = b + off + 8U;
        chunk_end = off + 12U + (size_t)len;
        crc = rd32be(data + len);
        if(xm_png_crc32(type,(size_t)len+4U)!=crc)goto fail;
        if(memcmp(type,"IHDR",4U)==0){if(seen_ihdr||off!=8U||len!=13U)goto fail;width=rd32be(data);height=rd32be(data+4U);depth=data[8];color=data[9];if(data[10]!=0U||data[11]!=0U||data[12]!=0U||width==0U||height==0U||width>XM_MAX_DIMENSION||height>XM_MAX_DIMENSION||depth!=8U)goto fail;if(color==0U)channels=1U;else if(color==2U)channels=3U;else if(color==3U)channels=1U;else if(color==4U)channels=2U;else if(color==6U)channels=4U;else goto fail;seen_ihdr=1;}
        else if(!seen_ihdr)goto fail;
        else if(memcmp(type,"PLTE",4U)==0){if(len==0U||len>768U||len%3U!=0U||seen_idat)goto fail;memcpy(palette,data,len);palette_len=len;}
        else if(memcmp(type,"tRNS",4U)==0){if(color!=3U||len>256U||seen_idat)goto fail;memcpy(alpha,data,len);alpha_len=len;}
        else if(memcmp(type,"IDAT",4U)==0){if(idat_closed||len>XM_PNG_MAX_COMPRESSED-idat_len)goto fail;if(len!=0U){if(idat_len+(size_t)len>idat_cap){size_t newcap=idat_cap==0U?4096U:idat_cap;uint8_t *grown;while(newcap<idat_len+(size_t)len){if(newcap>XM_PNG_MAX_COMPRESSED/2U){newcap=XM_PNG_MAX_COMPRESSED;break;}newcap*=2U;}grown=(uint8_t *)realloc(idat,newcap);if(grown==NULL)goto fail;idat=grown;idat_cap=newcap;}memcpy(idat+idat_len,data,len);idat_len+=(size_t)len;}seen_idat=1;}
        else if(memcmp(type,"IEND",4U)==0){if(len!=0U||!seen_idat||chunk_end!=n)goto fail;seen_iend=1;off=chunk_end;break;}
        else {if(seen_idat)idat_closed=1;if((type[0]&0x20U)==0U)goto fail;}
        if(seen_idat&&memcmp(type,"IDAT",4U)!=0)idat_closed=1;
        off=chunk_end;
    }
    if(!seen_ihdr||!seen_iend||width==0U||height==0U||(color==3U&&(palette_len==0U||alpha_len>palette_len/3U)))goto fail;
    pixels=(size_t)width*(size_t)height;if((uint64_t)width*height>XM_MAX_PIXELS||pixels>SIZE_MAX/4U||pixels*4U>cap)goto fail;
    if (pixels > SIZE_MAX / (size_t)channels) goto fail;
    row_bytes = pixels / (size_t)height * (size_t)channels;
    if (row_bytes > SIZE_MAX - (size_t)height) goto fail;
    raw_len = (row_bytes + 1U) * (size_t)height;
    if (raw_len < row_bytes) goto fail;
    raw=(uint8_t *)malloc(raw_len);if(raw==NULL)goto fail;if(!xm_inflate_zlib_bounded(idat,idat_len,raw,raw_len))goto fail;
    /* Compact rows in place, then reverse PNG filters using the prior decoded row. */
    for(y=0U;y<(size_t)height;++y){size_t src=y*(row_bytes+1U)+1U,dst=y*row_bytes;uint8_t filter=raw[y*(row_bytes+1U)];size_t x;memmove(raw+dst,raw+src,row_bytes);for(x=0U;x<row_bytes;++x){uint8_t left=x>=channels?raw[dst+x-channels]:0U;uint8_t up=y>0U?raw[dst-row_bytes+x]:0U;uint8_t ul=(y>0U&&x>=channels)?raw[dst-row_bytes+x-channels]:0U;uint8_t pred=0U;if(filter==1U)pred=left;else if(filter==2U)pred=up;else if(filter==3U)pred=(uint8_t)(((unsigned)left+(unsigned)up)/2U);else if(filter==4U)pred=xm_paeth(left,up,ul);else if(filter!=0U)goto fail;raw[dst+x]=(uint8_t)(raw[dst+x]+pred);}}
    for(i=0U;i<pixels;++i){uint8_t r,g,bl,a=255U;const uint8_t *src=raw+i*(size_t)channels;if(color==0U){r=g=bl=src[0];}else if(color==2U){r=src[0];g=src[1];bl=src[2];}else if(color==3U){size_t idx=src[0];if(idx>=palette_len/3U)goto fail;r=palette[idx*3U];g=palette[idx*3U+1U];bl=palette[idx*3U+2U];a=idx<alpha_len?alpha[idx]:255U;}else if(color==4U){r=g=bl=src[0];a=src[1];}else {r=src[0];g=src[1];bl=src[2];a=src[3];}rgba[i*4U]=r;rgba[i*4U+1U]=g;rgba[i*4U+2U]=bl;rgba[i*4U+3U]=a;}
    outinfo.width=width;outinfo.height=height;outinfo.channels=4U;if(info!=NULL)*info=outinfo;free(idat);free(raw);return 1;
fail:
    free(idat);free(raw);return 0;
}

int xm_media_parse_avi(const uint8_t *b, size_t n, XmAviInfo *out) {
    XmAviInfo x;
    size_t root_end, off;
    uint32_t riff_size;
    if (b == NULL || out == NULL || n < 12U || memcmp(b, "RIFF", 4U) != 0 || memcmp(b + 8U, "AVI ", 4U) != 0) return 0;
    riff_size = rd32le(b + 4U);
    if (riff_size < 4U || (uint64_t)riff_size + 8U > (uint64_t)n) return 0;
    root_end = (size_t)riff_size + 8U;
    memset(&x, 0, sizeof(x));
    x.video_stream_index = UINT32_MAX;
    off = 12U;
    while (off < root_end) {
        size_t data, next;
        uint32_t sz;
        if (!avi_chunk_bounds(b, root_end, off, &data, &next, &sz)) return 0;
        if (memcmp(b + off, "LIST", 4U) == 0 && sz >= 4U) {
            if (memcmp(b + data, "hdrl", 4U) == 0) {
                if (!avi_parse_hdrl(b, data + 4U, data + sz, &x)) return 0;
            } else if (memcmp(b + data, "movi", 4U) == 0) {
                x.movi_offset = data + 4U;
                x.movi_end = data + sz;
            }
        }
        off = next;
    }
    if (x.width == 0U || x.height == 0U || x.movi_offset == 0U || x.movi_end <= x.movi_offset || x.frame_rate_den == 0U) return 0;
    if (x.video_stream_index == UINT32_MAX) return 0;
    if (x.native_raw_video) {
        uint64_t stride = (((uint64_t)x.width * x.bits_per_pixel + 31U) / 32U) * 4U;
        uint64_t frame_bytes = stride * x.height;
        if (stride > UINT32_MAX || frame_bytes > UINT32_MAX) x.native_raw_video = 0U;
        else x.frame_bytes = (uint32_t)frame_bytes;
    }
    if (x.duration_ms == 0U && x.frame_rate_num != 0U && x.frame_rate_den != 0U && x.frame_count != 0U)
        x.duration_ms = ((uint64_t)x.frame_count * (uint64_t)x.frame_rate_den * 1000U) / x.frame_rate_num;
    *out = x;
    return 1;
}

int xm_media_avi_decode_next_frame(const uint8_t *b, size_t n, const XmAviInfo *x,
                                   size_t *cursor, uint8_t *rgba, size_t cap,
                                   XmImageInfo *frame_info) {
    size_t off, data, next;
    uint32_t sz;
    char stream0, stream1;
    uint64_t pixels, stride, need;
    uint32_t y, col;
    if (b == NULL || x == NULL || cursor == NULL || rgba == NULL || !x->native_raw_video ||
        x->width == 0U || x->height == 0U || x->video_stream_index > 99U || x->movi_end > n || x->movi_offset > x->movi_end) return -1;
    pixels = (uint64_t)x->width * x->height;
    if (pixels > XM_MAX_PIXELS || pixels > SIZE_MAX / 4U || pixels * 4U > cap) return -1;
    stride = (((uint64_t)x->width * x->bits_per_pixel + 31U) / 32U) * 4U;
    need = stride * x->height;
    if (need > UINT32_MAX) return -1;
    stream0 = (char)('0' + (x->video_stream_index / 10U));
    stream1 = (char)('0' + (x->video_stream_index % 10U));
    off = (*cursor == 0U) ? x->movi_offset : *cursor;
    if (off < x->movi_offset || off > x->movi_end) return -1;
    while (off < x->movi_end) {
        if (!avi_chunk_bounds(b, x->movi_end, off, &data, &next, &sz)) return -1;
        if (memcmp(b + off, "LIST", 4U) == 0 && sz >= 4U) {
            off = next;
            continue;
        }
        if (b[off] == (uint8_t)stream0 && b[off + 1U] == (uint8_t)stream1 &&
            ((b[off + 2U] == 'd' && (b[off + 3U] == 'b' || b[off + 3U] == 'c')))) {
            uint64_t required = need;
            if ((uint64_t)sz < required) return -1;
            for (y = 0U; y < x->height; ++y) {
                uint32_t sy = x->top_down ? y : (x->height - 1U - y);
                const uint8_t *row = b + data + (size_t)((uint64_t)sy * stride);
                for (col = 0U; col < x->width; ++col) {
                    size_t dst = ((size_t)y * x->width + col) * 4U;
                    size_t src = (size_t)col * (x->bits_per_pixel / 8U);
                    rgba[dst] = row[src + 2U]; rgba[dst + 1U] = row[src + 1U]; rgba[dst + 2U] = row[src];
                    rgba[dst + 3U] = x->bits_per_pixel == 32U ? row[src + 3U] : 255U;
                }
            }
            *cursor = next;
            if (frame_info != NULL) { frame_info->width=x->width; frame_info->height=x->height; frame_info->channels=4U; }
            return 1;
        }
        off = next;
    }
    *cursor = x->movi_end;
    return 0;
}

static int ppm_next_token(const uint8_t *b, size_t n, size_t *pos, char *dst, size_t dst_cap) {
    size_t start, len;
    while (*pos < n) {
        if (isspace((unsigned char)b[*pos])) { ++*pos; continue; }
        if (b[*pos] == '#') { while (*pos < n && b[*pos] != '\n' && b[*pos] != '\r') ++*pos; continue; }
        break;
    }
    if (*pos >= n || dst_cap < 2U) return 0;
    start = *pos;
    while (*pos < n && !isspace((unsigned char)b[*pos]) && b[*pos] != '#') ++*pos;
    len = *pos - start;
    if (len == 0U || len >= dst_cap) return 0;
    memcpy(dst, b + start, len); dst[len] = '\0';
    return 1;
}

static int ppm_parse_uint(const char *s, uint32_t *out) {
    uint64_t v = 0U;
    size_t i;
    if (s == NULL || out == NULL || *s == '\0') return 0;
    for (i = 0U; s[i] != '\0'; ++i) {
        if (s[i] < '0' || s[i] > '9') return 0;
        v = v * 10U + (uint64_t)(s[i] - '0');
        if (v > UINT32_MAX) return 0;
    }
    *out = (uint32_t)v;
    return 1;
}

int xm_media_decode_ppm_rgba(const uint8_t *b, size_t n, uint8_t *rgba, size_t cap, XmImageInfo *info) {
    XmImageInfo image;
    size_t pos = 0U, pixels, i;
    uint32_t width, height, maxval;
    char token[32];
    int binary;
    if (b == NULL || rgba == NULL || n < 3U || b[0] != 'P' || (b[1] != '3' && b[1] != '6')) return 0;
    binary = b[1] == '6';
    pos = 2U;
    if (!ppm_next_token(b, n, &pos, token, sizeof(token)) || !ppm_parse_uint(token, &width) ||
        !ppm_next_token(b, n, &pos, token, sizeof(token)) || !ppm_parse_uint(token, &height) ||
        !ppm_next_token(b, n, &pos, token, sizeof(token)) || !ppm_parse_uint(token, &maxval)) return 0;
    if (width == 0U || height == 0U || width > XM_MAX_DIMENSION || height > XM_MAX_DIMENSION || maxval == 0U || maxval > 255U) return 0;
    if ((uint64_t)width * height > XM_MAX_PIXELS || (uint64_t)width * height > SIZE_MAX / 4U || (uint64_t)width * height * 4U > cap) return 0;
    pixels = (size_t)width * height;
    if (binary) {
        if (pos >= n || !isspace((unsigned char)b[pos])) return 0;
        if (b[pos] == '\r' && pos + 1U < n && b[pos + 1U] == '\n') pos += 2U; else ++pos;
        if (pixels > SIZE_MAX / 3U || pos > n || n - pos < pixels * 3U) return 0;
        for (i = 0U; i < pixels; ++i) {
            uint32_t r=b[pos+i*3U], g=b[pos+i*3U+1U], bl=b[pos+i*3U+2U];
            if (r > maxval || g > maxval || bl > maxval) return 0;
            rgba[i*4U]=(uint8_t)((r*255U + maxval/2U)/maxval);
            rgba[i*4U+1U]=(uint8_t)((g*255U + maxval/2U)/maxval);
            rgba[i*4U+2U]=(uint8_t)((bl*255U + maxval/2U)/maxval); rgba[i*4U+3U]=255U;
        }
    } else {
        for (i = 0U; i < pixels; ++i) {
            uint32_t v[3]; size_t c;
            for (c=0U;c<3U;++c) {
                if (!ppm_next_token(b,n,&pos,token,sizeof(token)) || !ppm_parse_uint(token,&v[c]) || v[c]>maxval) return 0;
            }
            rgba[i*4U]=(uint8_t)((v[0]*255U+maxval/2U)/maxval); rgba[i*4U+1U]=(uint8_t)((v[1]*255U+maxval/2U)/maxval);
            rgba[i*4U+2U]=(uint8_t)((v[2]*255U+maxval/2U)/maxval); rgba[i*4U+3U]=255U;
        }
    }
    image.width=width; image.height=height; image.channels=4U; if (info != NULL) *info=image; return 1;
}

#define XM_GIF_MAX_COMPRESSED (4U * 1024U * 1024U)
static int xm_gif_read_code(const uint8_t *data, size_t length, size_t *bit_pos, unsigned width, unsigned *code) {
    unsigned i, value = 0U;
    if (*bit_pos > length * 8U || (size_t)width > length * 8U - *bit_pos) return 0;
    for (i = 0U; i < width; ++i) {
        size_t pos = (*bit_pos)++;
        value |= (unsigned)(((unsigned)data[pos >> 3U] >> (unsigned)(pos & 7U)) & 1U) << i;
    }
    *code = value; return 1;
}
static int xm_gif_lzw_decode(const uint8_t *data, size_t length, unsigned min_code_size,
                             uint8_t *pixels, size_t expected) {
    uint16_t prefix[4096]; uint8_t suffix[4096], stack[4096];
    size_t bit_pos = 0U, output = 0U; unsigned clear, end, available, code_size, old = UINT_MAX, first = 0U;
    if (min_code_size < 2U || min_code_size > 8U) return 0;
    clear = 1U << min_code_size; end = clear + 1U; available = clear + 2U; code_size = min_code_size + 1U;
    for (;;) {
        unsigned code, in_code, stack_n = 0U;
        if (!xm_gif_read_code(data, length, &bit_pos, code_size, &code)) return 0;
        if (code == clear) { available = clear + 2U; code_size = min_code_size + 1U; old = UINT_MAX; continue; }
        if (code == end) break;
        if (old == UINT_MAX) {
            if (code >= clear || output >= expected) return 0;
            pixels[output++] = (uint8_t)code; first = code; old = code; continue;
        }
        in_code = code;
        if (code == available) { stack[stack_n++] = (uint8_t)first; code = old; }
        else if (code > available) return 0;
        while (code >= clear) {
            if (code >= available || stack_n >= sizeof(stack)) return 0;
            stack[stack_n++] = suffix[code]; code = prefix[code];
        }
        if (code >= clear || stack_n >= sizeof(stack)) return 0;
        first = code; stack[stack_n++] = (uint8_t)code;
        while (stack_n > 0U) { if (output >= expected) return 0; pixels[output++] = stack[--stack_n]; }
        if (available < 4096U) {
            prefix[available] = (uint16_t)old; suffix[available] = (uint8_t)first; ++available;
            if (available == (1U << code_size) && code_size < 12U) ++code_size;
        }
        old = in_code;
    }
    return output == expected;
}
int xm_media_decode_gif_rgba(const uint8_t *b, size_t n, uint8_t *rgba, size_t cap, XmImageInfo *info) {
    uint32_t screen_w, screen_h, frame_w, frame_h, left, top;
    size_t off = 13U, pixels, table_len = 0U, compressed_len = 0U, compressed_cap = 0U, i;
    uint8_t global_table[768], local_table[768], *compressed = NULL, *indices = NULL;
    const uint8_t *palette = NULL; size_t palette_len = 0U;
    uint8_t transparent_index = 0U; int transparent = 0, interlaced = 0;
    XmImageInfo image;
    if (b == NULL || rgba == NULL || n < 13U ||
        (memcmp(b, "GIF87a", 6U) != 0 && memcmp(b, "GIF89a", 6U) != 0)) return 0;
    screen_w = rd16le(b + 6U); screen_h = rd16le(b + 8U);
    if (screen_w == 0U || screen_h == 0U || screen_w > XM_MAX_DIMENSION || screen_h > XM_MAX_DIMENSION) return 0;
    if ((uint64_t)screen_w * screen_h > XM_MAX_PIXELS || (uint64_t)screen_w * screen_h * 4U > cap) return 0;
    if ((b[10U] & 0x80U) != 0U) {
        table_len = (size_t)3U << ((b[10U] & 7U) + 1U);
        if (table_len > sizeof(global_table) || off > n || n - off < table_len) return 0;
        memcpy(global_table, b + off, table_len); off += table_len; palette = global_table; palette_len = table_len;
    }
    for (;;) {
        uint8_t tag;
        if (off >= n) return 0;
        tag = b[off++];
        if (tag == 0x3BU) return 0;
        if (tag == 0x21U) {
            uint8_t label;
            if (off >= n) return 0;
            label = b[off++];
            if (label == 0xF9U) {
                uint8_t block_size;
                if (off >= n) return 0;
                block_size = b[off++];
                if ((size_t)block_size > n - off || off + (size_t)block_size >= n) return 0;
                if (block_size == 4U) { transparent = (b[off] & 1U) != 0U; transparent_index = b[off + 3U]; }
                off += (size_t)block_size;
                if (b[off++] != 0U) return 0;
            } else {
                while (1) { uint8_t size; if (off >= n) return 0; size = b[off++]; if (size == 0U) break; if ((size_t)size > n - off) return 0; off += size; }
            }
        } else if (tag == 0x2CU) {
            uint8_t packed, min_code_size;
            if (n - off < 9U) return 0;
            left = rd16le(b + off); top = rd16le(b + off + 2U); frame_w = rd16le(b + off + 4U); frame_h = rd16le(b + off + 6U); packed = b[off + 8U]; off += 9U;
            if (frame_w == 0U || frame_h == 0U || (uint64_t)left + frame_w > screen_w || (uint64_t)top + frame_h > screen_h ||
                (uint64_t)frame_w * frame_h > XM_MAX_PIXELS || (uint64_t)frame_w * frame_h > SIZE_MAX) return 0;
            interlaced = (packed & 0x40U) != 0U;
            if ((packed & 0x80U) != 0U) {
                table_len = (size_t)3U << ((packed & 7U) + 1U);
                if (table_len > sizeof(local_table) || n - off < table_len) return 0;
                memcpy(local_table, b + off, table_len); off += table_len; palette = local_table; palette_len = table_len;
            }
            if (palette == NULL || palette_len < 3U || off >= n) return 0;
            min_code_size = b[off++];
            while (1) {
                uint8_t block_size;
                if (off >= n) goto gif_fail;
                block_size = b[off++]; if (block_size == 0U) break;
                if ((size_t)block_size > n - off || (size_t)block_size > XM_GIF_MAX_COMPRESSED - compressed_len) goto gif_fail;
                if (compressed_len + (size_t)block_size > compressed_cap) {
                    size_t new_cap = compressed_cap == 0U ? 1024U : compressed_cap; 
                    uint8_t *next_buffer;
                    while (new_cap < compressed_len + (size_t)block_size) new_cap = new_cap > XM_GIF_MAX_COMPRESSED/2U ? XM_GIF_MAX_COMPRESSED : new_cap * 2U;
                    next_buffer = (uint8_t *)realloc(compressed, new_cap); if (next_buffer == NULL) goto gif_fail;
                    compressed = next_buffer; compressed_cap = new_cap;
                }
                memcpy(compressed + compressed_len, b + off, block_size); compressed_len += block_size; off += block_size;
            }
            pixels = (size_t)frame_w * frame_h; indices = (uint8_t *)malloc(pixels); if (indices == NULL) goto gif_fail;
            if (!xm_gif_lzw_decode(compressed, compressed_len, min_code_size, indices, pixels)) goto gif_fail;
            memset(rgba, 0, (size_t)screen_w * screen_h * 4U);
            if (!interlaced) {
                for (i = 0U; i < pixels; ++i) {
                    size_t dx = (size_t)left + i % frame_w, dy = (size_t)top + i / frame_w, dst = (dy * screen_w + dx) * 4U;
                    size_t idx = indices[i]; if (idx * 3U + 2U >= palette_len) goto gif_fail;
                    rgba[dst] = palette[idx*3U]; rgba[dst+1U] = palette[idx*3U+1U]; rgba[dst+2U] = palette[idx*3U+2U];
                    rgba[dst+3U] = (uint8_t)(transparent && idx == transparent_index ? 0U : 255U);
                }
            } else {
                static const unsigned starts[4]={0U,4U,2U,1U}, steps[4]={8U,8U,4U,2U};
                size_t src=0U; unsigned pass;
                for(pass=0U;pass<4U;++pass) { uint32_t row; for(row=starts[pass];row<frame_h;row+=steps[pass]) { uint32_t col; for(col=0U;col<frame_w;++col) { size_t idx=indices[src++],dst=((size_t)(top+row)*screen_w+left+col)*4U; if(idx*3U+2U>=palette_len)goto gif_fail; rgba[dst]=palette[idx*3U];rgba[dst+1U]=palette[idx*3U+1U];rgba[dst+2U]=palette[idx*3U+2U];rgba[dst+3U]=(uint8_t)(transparent&&idx==transparent_index?0U:255U); } } }
            }
            image.width=screen_w; image.height=screen_h; image.channels=4U; if(info!=NULL)*info=image;
            free(compressed); free(indices); return 1;
        } else return 0;
    }
gif_fail:
    free(compressed); free(indices); return 0;
}

typedef struct {
    XmDeflateTree tree;
    uint8_t values[256];
    uint16_t count;
    uint8_t valid;
} XmJpegHuffman;
typedef struct {
    uint8_t id, h, v, quant_id, dc_id, ac_id;
    int32_t dc_predictor;
    uint32_t plane_width, plane_height;
    uint8_t *plane;
} XmJpegComponent;
typedef struct {
    uint16_t quant[4][64];
    uint8_t quant_valid[4];
    XmJpegHuffman huffman[2][4];
    XmJpegComponent component[3];
    uint32_t width, height;
    uint8_t component_count, max_h, max_v, have_frame, rgb_transform;
    uint16_t restart_interval;
} XmJpegState;
typedef struct {
    const uint8_t *data;
    size_t length, position;
    uint32_t accumulator;
    unsigned bit_count;
} XmJpegBits;
static const uint8_t xm_jpeg_zigzag[64]={0,1,8,16,9,2,3,10,17,24,32,25,18,11,4,5,12,19,26,33,40,48,41,34,27,20,13,6,7,14,21,28,35,42,49,56,57,50,43,36,29,22,15,23,30,37,44,51,58,59,52,45,38,31,39,46,53,60,61,54,47,55,62,63};
static const double xm_jpeg_idct_matrix[8][8]={
 {0.353553390593274,0.490392640201615,0.461939766255643,0.415734806151273,0.353553390593274,0.277785116509801,0.191341716182545,0.097545161008064},
 {0.353553390593274,0.415734806151273,0.191341716182545,-0.097545161008064,-0.353553390593274,-0.490392640201615,-0.461939766255643,-0.277785116509801},
 {0.353553390593274,0.277785116509801,-0.191341716182545,-0.490392640201615,-0.353553390593274,0.097545161008064,0.461939766255643,0.415734806151273},
 {0.353553390593274,0.097545161008064,-0.461939766255643,-0.277785116509801,0.353553390593274,0.415734806151273,-0.191341716182545,-0.490392640201615},
 {0.353553390593274,-0.097545161008064,-0.461939766255643,0.277785116509801,0.353553390593274,-0.415734806151273,-0.191341716182545,0.490392640201615},
 {0.353553390593274,-0.277785116509801,-0.191341716182545,0.490392640201615,-0.353553390593274,-0.097545161008064,0.461939766255643,-0.415734806151273},
 {0.353553390593274,-0.415734806151273,0.191341716182545,0.097545161008064,-0.353553390593274,0.490392640201615,-0.461939766255643,0.277785116509801},
 {0.353553390593274,-0.490392640201615,0.461939766255643,-0.415734806151273,0.353553390593273,-0.277785116509801,0.191341716182545,-0.097545161008064}
};
static uint16_t xm_jpeg_be16(const uint8_t *p) { return (uint16_t)(((uint16_t)p[0] << 8U) | p[1]); }
static int xm_jpeg_entropy_byte(XmJpegBits *bits, uint8_t *out) {
    uint8_t byte;
    if (bits->position >= bits->length) return 0;
    byte = bits->data[bits->position++];
    if (byte == 0xFFU) {
        if (bits->position >= bits->length || bits->data[bits->position++] != 0U) return 0;
        byte = 0xFFU;
    }
    *out = byte;
    return 1;
}
static int xm_jpeg_get_bits(XmJpegBits *bits, unsigned count, uint32_t *out) {
    uint32_t mask;
    if (count > 16U || out == NULL) return 0;
    while (bits->bit_count < count) {
        uint8_t byte;
        if (!xm_jpeg_entropy_byte(bits, &byte)) return 0;
        bits->accumulator = (bits->accumulator << 8U) | byte;
        bits->bit_count += 8U;
    }
    mask = count == 0U ? 0U : ((UINT32_C(1) << count) - 1U);
    *out = (bits->accumulator >> (bits->bit_count - count)) & mask;
    bits->bit_count -= count;
    if (bits->bit_count == 0U) bits->accumulator = 0U;
    else bits->accumulator &= (UINT32_C(1) << bits->bit_count) - 1U;
    return 1;
}
static int xm_jpeg_huffman_symbol(XmJpegBits *bits, const XmJpegHuffman *table, unsigned *value) {
    unsigned node=0U,depth;
    if (table == NULL || !table->valid) return 0;
    for (depth=0U; depth<16U; ++depth) {
        uint32_t bit; int16_t next;
        if (!xm_jpeg_get_bits(bits,1U,&bit)) return 0;
        next = table->tree.child[node][bit];
        if (next < 0) return 0;
        node=(unsigned)next;
        if (table->tree.symbol[node]>=0) {
            unsigned idx=(unsigned)table->tree.symbol[node];
            if (idx>=table->count) return 0;
            *value=table->values[idx]; return 1;
        }
    }
    return 0;
}
static int xm_jpeg_read_amplitude(XmJpegBits *bits, unsigned size, int32_t *value) {
    uint32_t raw;
    if (size == 0U) { *value=0; return 1; }
    if (size > 16U || !xm_jpeg_get_bits(bits,size,&raw)) return 0;
    if (raw < (UINT32_C(1) << (size-1U))) *value=(int32_t)raw-(int32_t)((UINT32_C(1)<<size)-1U);
    else *value=(int32_t)raw;
    return 1;
}
static int xm_jpeg_huffman_tree_build(XmDeflateTree *tree, const uint8_t *lengths, unsigned count) {
    unsigned counts[17] = {0U};
    unsigned next_code[17] = {0U};
    unsigned sym, bits;
    uint32_t code = 0U;
    if (tree == NULL || lengths == NULL || count == 0U || count > 256U) return 0;
    xm_deflate_tree_init(tree);
    for (sym = 0U; sym < count; ++sym) {
        if (lengths[sym] > 16U) return 0;
        if (lengths[sym] != 0U) ++counts[lengths[sym]];
    }
    for (bits = 1U; bits <= 16U; ++bits) {
        code = (code + counts[bits - 1U]) << 1U;
        if (code + counts[bits] > (UINT32_C(1) << bits)) return 0;
        next_code[bits] = (unsigned)code;
    }
    for (sym = 0U; sym < count; ++sym) {
        unsigned len = lengths[sym], node = 0U, i;
        uint32_t assigned;
        if (len == 0U) continue;
        assigned = next_code[len]++;
        for (i = 0U; i < len; ++i) {
            unsigned direction = (unsigned)((assigned >> (len - 1U - i)) & 1U);
            int16_t next = tree->child[node][direction];
            if (i + 1U == len) {
                if (next >= 0 || tree->symbol[node] >= 0 || tree->nodes >= XM_DEFLATE_MAX_NODES) return 0;
                next = (int16_t)tree->nodes++;
                tree->child[node][direction] = next;
                tree->symbol[(unsigned)next] = (int16_t)sym;
            } else {
                if (next < 0) {
                    if (tree->nodes >= XM_DEFLATE_MAX_NODES) return 0;
                    next = (int16_t)tree->nodes++;
                    tree->child[node][direction] = next;
                }
                if (tree->symbol[(unsigned)next] >= 0) return 0;
            }
            node = (unsigned)next;
        }
    }
    return 1;
}

static int xm_jpeg_read_huffman_table(XmJpegState *state, const uint8_t *p, size_t len) {
    size_t off=0U; unsigned tc,th,i; XmJpegHuffman *table;
    while (off<len) {
        uint8_t spec; uint32_t total_check=0U;
        if (len-off<17U) return 0;
        spec=p[off++]; tc=spec>>4U; th=spec&15U;
        if (tc>1U || th>3U) return 0;
        for(i=0U;i<16U;++i){total_check+=p[off+i];}
        off+=16U; if(total_check==0U||total_check>256U||total_check>len-off)return 0;
        table=&state->huffman[tc][th]; table->count=(uint16_t)total_check;
        for(i=0U;i<(unsigned)total_check;++i){table->values[i]=p[off+i];}
        /* Build a symbol-indexed length vector in the order specified by DHT counts. */
        { uint8_t lens[288]={0U}; unsigned cursor=0U,cl;
          for(cl=1U;cl<=16U;++cl) for(i=0U;i<p[off-16U+cl-1U];++i) { if(cursor>=total_check)return 0; lens[cursor++]=(uint8_t)cl; }
          if(cursor!=total_check || !xm_jpeg_huffman_tree_build(&table->tree,lens,(unsigned)total_check)) return 0;
        }
        table->valid=1U; off+=(size_t)total_check;
    }
    return 1;
}
static int xm_jpeg_read_quant_tables(XmJpegState *state,const uint8_t *p,size_t len) {
    size_t off=0U;while(off<len){uint8_t spec;unsigned precision,id,i;if(off>=len)return 0;spec=p[off++];precision=spec>>4U;id=spec&15U;if(precision!=0U||id>3U||len-off<64U)return 0;for(i=0U;i<64U;++i){uint8_t v=p[off+i];if(v==0U)return 0;state->quant[id][xm_jpeg_zigzag[i]]=v;}state->quant_valid[id]=1U;off+=64U;}return 1;
}
static int xm_jpeg_receive_block(XmJpegState *state, XmJpegBits *bits, XmJpegComponent *comp,
                                 int32_t coeff[64]) {
    unsigned symbol,k=1U;int32_t amplitude;XmJpegHuffman *dc=&state->huffman[0][comp->dc_id],*ac=&state->huffman[1][comp->ac_id];
    memset(coeff,0,64U*sizeof(coeff[0]));
    if(!xm_jpeg_huffman_symbol(bits,dc,&symbol)||symbol>11U||!xm_jpeg_read_amplitude(bits,symbol,&amplitude))return 0;
    comp->dc_predictor+=amplitude;coeff[0]=comp->dc_predictor*(int32_t)state->quant[comp->quant_id][0];
    while(k<64U){unsigned run,size;if(!xm_jpeg_huffman_symbol(bits,ac,&symbol))return 0;run=symbol>>4U;size=symbol&15U;
        if(size==0U){if(run==0U)break;if(run!=15U||k+16U>64U)return 0;k+=16U;continue;}
        if(size>10U||k+run>=64U||!xm_jpeg_read_amplitude(bits,size,&amplitude)) return 0;
        k+=run;
        coeff[xm_jpeg_zigzag[k]]=amplitude*(int32_t)state->quant[comp->quant_id][xm_jpeg_zigzag[k]];
        ++k;
    }
    return 1;
}
static uint8_t xm_jpeg_clamp_byte(double v) {
    int value;
    if(v<=0.0) return 0U;
    if(v>=255.0) return 255U;
    value=(int)(v+0.5);
    if(value<0) value=0;
    if(value>255) value=255;
    return (uint8_t)value;
}
static void xm_jpeg_idct(const int32_t coeff[64],uint8_t out[64]) {
    double temp[8][8];unsigned v,x,u,y;
    for(v=0U;v<8U;++v)for(x=0U;x<8U;++x){double sum=0.0;for(u=0U;u<8U;++u)sum+=(double)coeff[v*8U+u]*xm_jpeg_idct_matrix[x][u];temp[v][x]=sum;}
    for(y=0U;y<8U;++y)for(x=0U;x<8U;++x){double sum=0.0;for(v=0U;v<8U;++v)sum+=temp[v][x]*xm_jpeg_idct_matrix[y][v];out[y*8U+x]=xm_jpeg_clamp_byte(sum+128.0);}
}
static int xm_jpeg_decode_block(XmJpegState *state,XmJpegBits *bits,XmJpegComponent *comp,
                                uint32_t bx,uint32_t by) {
    int32_t coeff[64];uint8_t samples[64];unsigned y,x;size_t off;
    if(!xm_jpeg_receive_block(state,bits,comp,coeff)) return 0;
    xm_jpeg_idct(coeff,samples);
    off=(size_t)by*8U*(size_t)comp->plane_width+(size_t)bx*8U;
    if(off+(size_t)7U*(size_t)comp->plane_width+8U>(size_t)comp->plane_width*comp->plane_height)return 0;
    for(y=0U;y<8U;++y)for(x=0U;x<8U;++x)comp->plane[off+(size_t)y*comp->plane_width+x]=samples[y*8U+x];
    return 1;
}
static int xm_jpeg_expect_restart(XmJpegBits *bits,unsigned expected) {
    size_t pos=bits->position;
    bits->accumulator=0U;bits->bit_count=0U;
    if(pos>=bits->length||bits->data[pos++]!=0xFFU)return 0;
    while(pos<bits->length&&bits->data[pos]==0xFFU)++pos;
    if(pos>=bits->length||bits->data[pos]!=(uint8_t)(0xD0U+(expected&7U)))return 0;
    bits->position=pos+1U;return 1;
}
static int xm_jpeg_decode_scan(XmJpegState *state,const uint8_t *b,size_t n,size_t start,uint8_t *rgba,size_t cap,XmImageInfo *info) {
    XmJpegBits bits;uint32_t max_h=state->max_h,max_v=state->max_v,mcus_x,mcus_y,mx,my;uint64_t pixel_count;unsigned i;uint32_t mcu_index=0U,restart_id=0U;
    pixel_count=(uint64_t)state->width*state->height;if(pixel_count>XM_MAX_PIXELS||pixel_count*4U>cap||pixel_count>SIZE_MAX/4U)return 0;
    mcus_x=(state->width+max_h*8U-1U)/(max_h*8U);mcus_y=(state->height+max_v*8U-1U)/(max_v*8U);
    for(i=0U;i<state->component_count;++i){XmJpegComponent *c=&state->component[i];c->plane_width=mcus_x*c->h*8U;c->plane_height=mcus_y*c->v*8U;if((uint64_t)c->plane_width*c->plane_height>XM_MAX_PIXELS)return 0;c->plane=(uint8_t *)malloc((size_t)c->plane_width*c->plane_height);if(c->plane==NULL)return 0;c->dc_predictor=0;}
    bits.data=b;bits.length=n;bits.position=start;bits.accumulator=0U;bits.bit_count=0U;
    for(my=0U;my<mcus_y;++my)for(mx=0U;mx<mcus_x;++mx){
        unsigned ci,by,bx;
        for(ci=0U;ci<state->component_count;++ci){XmJpegComponent *c=&state->component[ci];for(by=0U;by<c->v;++by)for(bx=0U;bx<c->h;++bx){if(!xm_jpeg_decode_block(state,&bits,c,mx*c->h+bx,my*c->v+by))goto fail;}}
        ++mcu_index;
        if(state->restart_interval!=0U&&mcu_index%state->restart_interval==0U&&(my+1U<mcus_y||mx+1U<mcus_x)){if(!xm_jpeg_expect_restart(&bits,restart_id++))goto fail;for(i=0U;i<state->component_count;++i)state->component[i].dc_predictor=0;}
    }
    for(my=0U;my<state->height;++my)for(mx=0U;mx<state->width;++mx){size_t dst=((size_t)my*state->width+mx)*4U;uint8_t samples[3]={0U,128U,128U};
        for(i=0U;i<state->component_count;++i){XmJpegComponent *c=&state->component[i];uint32_t sx=(mx*c->h)/max_h,sy=(my*c->v)/max_v;if(sx>=c->plane_width||sy>=c->plane_height)goto fail;samples[i]=c->plane[(size_t)sy*c->plane_width+sx];}
        if(state->component_count==1U){rgba[dst]=samples[0];rgba[dst+1U]=samples[0];rgba[dst+2U]=samples[0];}
        else if(state->rgb_transform){rgba[dst]=samples[0];rgba[dst+1U]=samples[1];rgba[dst+2U]=samples[2];}
        else {int yv=samples[0],cb=(int)samples[1]-128,cr=(int)samples[2]-128;rgba[dst]=xm_jpeg_clamp_byte((double)yv+(91881.0*(double)cr)/65536.0);rgba[dst+1U]=xm_jpeg_clamp_byte((double)yv-(22554.0*(double)cb+46802.0*(double)cr)/65536.0);rgba[dst+2U]=xm_jpeg_clamp_byte((double)yv+(116130.0*(double)cb)/65536.0);}
        rgba[dst+3U]=255U;
    }
    /* Require EOI after the entropy-coded scan; do not accept a truncated entropy stream. */
    {size_t pos=bits.position;int found=0;while(pos+1U<n){if(b[pos]==0xFFU&&b[pos+1U]==0xD9U){found=1;break;}++pos;}if(!found)goto fail;}
    if(info!=NULL){info->width=state->width;info->height=state->height;info->channels=4U;}
    for(i=0U;i<state->component_count;++i){free(state->component[i].plane);state->component[i].plane=NULL;}
    return 1;
fail:
    for(i=0U;i<state->component_count;++i){free(state->component[i].plane);state->component[i].plane=NULL;}
    return 0;
}
int xm_media_decode_jpeg_rgba(const uint8_t *b,size_t n,uint8_t *rgba,size_t cap,XmImageInfo *info) {
    XmJpegState *state;size_t pos=2U;int result=0;
    if(b==NULL||rgba==NULL||n<4U||b[0]!=0xFFU||b[1]!=0xD8U)return 0;
    state=(XmJpegState *)calloc(1U,sizeof(*state));if(state==NULL)return 0;
    while(pos<n){uint8_t marker;uint16_t segment_len;const uint8_t *p;size_t payload_len,segment_end;
        if(b[pos++]!=0xFFU) goto done;
        while(pos<n&&b[pos]==0xFFU) ++pos;
        if(pos>=n) goto done;
        marker=b[pos++];
        if(marker==0xD9U)goto done;
        if(marker==0xD8U||marker==0x01U||(marker>=0xD0U&&marker<=0xD7U))continue;
        if(n-pos<2U) goto done;
        segment_len=xm_jpeg_be16(b+pos);
        if(segment_len<2U||(size_t)segment_len>n-pos) goto done;
        p=b+pos+2U;
        payload_len=(size_t)segment_len-2U;
        segment_end=pos+(size_t)segment_len;
        pos=segment_end;
        if(marker==0xDBU){if(!xm_jpeg_read_quant_tables(state,p,payload_len))goto done;}
        else if(marker==0xC4U){if(!xm_jpeg_read_huffman_table(state,p,payload_len))goto done;}
        else if(marker==0xDDU){if(payload_len!=2U)goto done;state->restart_interval=xm_jpeg_be16(p);}
        else if(marker==0xEEU&&payload_len>=12U&&memcmp(p,"Adobe",5U)==0){if(p[11U]==0U)state->rgb_transform=1U;else if(p[11U]>1U)goto done;}
        else if(marker==0xC0U){unsigned i;uint8_t precision,ncomp;if(state->have_frame||payload_len<6U)goto done;precision=p[0];state->height=xm_jpeg_be16(p+1U);state->width=xm_jpeg_be16(p+3U);ncomp=p[5U];if(precision!=8U||(ncomp!=1U&&ncomp!=3U)||payload_len!=(size_t)6U+(size_t)ncomp*3U||state->width==0U||state->height==0U||state->width>XM_MAX_DIMENSION||state->height>XM_MAX_DIMENSION||(uint64_t)state->width*state->height>XM_MAX_PIXELS)goto done;state->component_count=ncomp;state->max_h=state->max_v=1U;for(i=0U;i<ncomp;++i){XmJpegComponent *c=&state->component[i];uint8_t hv;c->id=p[6U+i*3U];hv=p[7U+i*3U];c->h=hv>>4U;c->v=hv&15U;c->quant_id=p[8U+i*3U];if(c->h==0U||c->h>4U||c->v==0U||c->v>4U||c->quant_id>3U)goto done;if(c->h>state->max_h)state->max_h=c->h;if(c->v>state->max_v)state->max_v=c->v;for(unsigned j=0U;j<i;++j)if(state->component[j].id==c->id)goto done;}if(ncomp==3U&&((unsigned)state->component[0].h*state->component[0].v+(unsigned)state->component[1].h*state->component[1].v+(unsigned)state->component[2].h*state->component[2].v)>10U)goto done;state->have_frame=1U;}
        else if(marker==0xDAU){uint8_t ns;unsigned i;if(!state->have_frame||payload_len<4U)goto done;ns=p[0];if(ns!=state->component_count||payload_len!=(size_t)1U+(size_t)ns*2U+3U)goto done;for(i=0U;i<ns;++i){uint8_t id=p[1U+i*2U],tables=p[2U+i*2U];unsigned ci;for(ci=0U;ci<state->component_count&&state->component[ci].id!=id;++ci){}if(ci==state->component_count)goto done;state->component[ci].dc_id=tables>>4U;state->component[ci].ac_id=tables&15U;if(state->component[ci].dc_id>3U||state->component[ci].ac_id>3U||!state->quant_valid[state->component[ci].quant_id]||!state->huffman[0][state->component[ci].dc_id].valid||!state->huffman[1][state->component[ci].ac_id].valid)goto done;}
            if(p[1U+ns*2U]!=0U||p[2U+ns*2U]!=63U||p[3U+ns*2U]!=0U) goto done;
            result=xm_jpeg_decode_scan(state,b,n,pos,rgba,cap,info);
            goto done;
        }
        /* Unknown critical frame/scan coding markers are rejected; metadata APP/COM is skipped. */
        else if((marker>=0xC0U&&marker<=0xCFU&&marker!=0xC4U&&marker!=0xC8U&&marker!=0xCCU)||marker==0xCCU)goto done;
    }
done:
    free(state);return result;
}

int xm_media_parse_mp3_header(const uint8_t *b,size_t n,XmMpegAudioFrameInfo *out) {
    static const uint16_t br_v1_l1[]={0,32,64,96,128,160,192,224,256,288,320,352,384,416,448};
    static const uint16_t br_v1_l2[]={0,32,48,56,64,80,96,112,128,160,192,224,256,320,384};
    static const uint16_t br_v1_l3[]={0,32,40,48,56,64,80,96,112,128,160,192,224,256,320};
    static const uint16_t br_v2_l1[]={0,32,48,56,64,80,96,112,128,144,160,176,192,224,256};
    static const uint16_t br_v2_l23[]={0,8,16,24,32,40,48,56,64,80,96,112,128,144,160};
    static const uint32_t rates[]={44100U,48000U,32000U};
    XmMpegAudioFrameInfo x; uint32_t h,version_bits,layer_bits,br_index,rate_index,padding,rate,br,scale;
    if(b==NULL||out==NULL||n<4U||b[0]!=0xFFU||(b[1]&0xE0U)!=0xE0U)return 0;
    h=rd32be(b);version_bits=(h>>19U)&3U;layer_bits=(h>>17U)&3U;br_index=(h>>12U)&15U;rate_index=(h>>10U)&3U;padding=(h>>9U)&1U;
    if(version_bits==1U||layer_bits==0U||br_index==0U||br_index==15U||rate_index==3U)return 0;
    x.mpeg_version=version_bits==3U?1U:(version_bits==2U?2U:25U);x.layer=(uint8_t)(4U-layer_bits);x.has_crc=(uint8_t)(((h>>16U)&1U)==0U);
    rate=rates[rate_index];if(version_bits==2U)rate/=2U;else if(version_bits==0U)rate/=4U;x.sample_rate=rate;
    if(version_bits==3U) br=x.layer==1U?br_v1_l1[br_index]:(x.layer==2U?br_v1_l2[br_index]:br_v1_l3[br_index]);
    else br=x.layer==1U?br_v2_l1[br_index]:br_v2_l23[br_index];
    x.bitrate_kbps=br;x.channels=((h>>6U)&3U)==3U?1U:2U;
    if(x.layer==1U){scale=12U;x.frame_bytes=(12U*br*1000U/rate+padding)*4U;x.samples_per_frame=384U;}
    else if(x.layer==3U && version_bits!=3U){x.frame_bytes=72U*br*1000U/rate+padding;x.samples_per_frame=576U;}
    else {x.frame_bytes=144U*br*1000U/rate+padding;x.samples_per_frame=1152U;}
    (void)scale;
    if(x.frame_bytes<4U||x.frame_bytes>4096U)return 0;
    *out=x;return 1;
}
int xm_media_parse_adts_header(const uint8_t *b,size_t n,XmAdtsInfo *out) {
    static const uint32_t rates[]={96000U,88200U,64000U,48000U,44100U,32000U,24000U,22050U,16000U,12000U,11025U,8000U,7350U};
    XmAdtsInfo x;uint8_t idx;uint32_t length;uint16_t ch;
    if(b==NULL||out==NULL||n<7U||b[0]!=0xFFU||(b[1]&0xF6U)!=0xF0U)return 0;
    idx=(uint8_t)((b[2]>>2U)&15U);if(idx>=sizeof(rates)/sizeof(rates[0]))return 0;
    length=((uint32_t)(b[3]&3U)<<11U)|((uint32_t)b[4]<<3U)|((uint32_t)b[5]>>5U);
    ch=(uint16_t)(((uint16_t)(b[2]&1U)<<2U)|((uint16_t)b[3]>>6U));
    if(length<7U||length>8191U||ch==0U||ch>7U)return 0;
    x.sample_rate=rates[idx];x.frame_bytes=length;x.channels=ch;x.profile=(uint8_t)((b[2]>>6U)&3U);x.samples_per_frame_index=0U;*out=x;return 1;
}
int xm_media_parse_ts_packet(const uint8_t *b,size_t n,XmTsPacketInfo *out) {
    XmTsPacketInfo x;size_t offset=4U;uint8_t afc;
    if(b==NULL||out==NULL||n<188U||b[0]!=0x47U||(b[1]&0x80U)!=0U)return 0;
    memset(&x,0,sizeof(x));x.payload_unit_start=(uint8_t)((b[1]>>6U)&1U);x.pid=(uint16_t)(((uint16_t)(b[1]&0x1FU)<<8U)|b[2]);afc=(uint8_t)((b[3]>>4U)&3U);
    if (afc == 0U) return 0;
    x.adaptation_field_control = afc;
    x.has_payload = (uint8_t)((afc & 1U) != 0U);
    x.has_adaptation = (uint8_t)((afc & 2U) != 0U);
    x.continuity_counter = (uint8_t)(b[3] & 15U);
    if(x.has_adaptation){uint8_t alen=b[offset];if((size_t)alen>183U||offset+1U+(size_t)alen>188U)return 0;if(alen>0U)x.discontinuity=(uint8_t)((b[offset+1U]&0x80U)!=0U);offset+=1U+(size_t)alen;}
    if(x.has_payload){if(offset>=188U)return 0;x.payload_offset=offset;}else x.payload_offset=188U;
    *out=x;return 1;
}

static uint64_t parse_duration_ms(const char *s, size_t n, int *ok) {
    size_t i = 0U;
    uint64_t seconds = 0U, millis = 0U;
    unsigned int frac_digits = 0U;
    int dot = 0, digit = 0;
    *ok = 0;
    while (i < n && isspace((unsigned char)s[i])) ++i;
    for (; i < n; ++i) {
        unsigned char c = (unsigned char)s[i];
        if (c == '.' && !dot) { dot = 1; continue; }
        if (c < '0' || c > '9') break;
        digit = 1;
        if (!dot) {
            if (seconds > 86400U / 10U) return 0U;
            seconds = seconds * 10U + (uint64_t)(c - '0');
            if (seconds > 86400U) return 0U;
        } else if (frac_digits < 3U) {
            millis = millis * 10U + (uint64_t)(c - '0');
            ++frac_digits;
        }
    }
    while (frac_digits < 3U) { millis *= 10U; ++frac_digits; }
    if (!digit) return 0U;
    *ok = 1;
    return seconds * 1000U + millis;
}
static int span_contains_nocase(const char *s, size_t n, const char *needle) {
    size_t i, j, m;
    if (s == NULL || needle == NULL) return 0;
    m = strlen(needle);
    if (m == 0U) return 1;
    if (m > n) return 0;
    for (i = 0U; i <= n - m; ++i) {
        for (j = 0U; j < m && tolower((unsigned char)s[i + j]) == tolower((unsigned char)needle[j]); ++j) {}
        if (j == m) return 1;
    }
    return 0;
}
int xm_media_parse_hls(const char *text,size_t n,XmHlsInfo *out) {
    XmHlsInfo x; size_t pos=0U; int saw_header=0; uint64_t duration_ms=0U; int expect_variant=0;
    if(text==NULL||out==NULL||n==0U||n>XM_MAX_HLS_BYTES)return 0;
    memset(&x,0,sizeof(x));
    while(pos<n){size_t start=pos,end;while(pos<n&&text[pos]!='\n')++pos;end=pos;if(pos<n)++pos;while(end>start&&(text[end-1U]=='\r'||isspace((unsigned char)text[end-1U])))--end;while(start<end&&isspace((unsigned char)text[start]))++start;if(start==end)continue;
        if(!saw_header){if(end-start<7U||memcmp(text+start,"#EXTM3U",7U)!=0)return 0;saw_header=1;continue;}
        if(text[start]=='#'){
            if(end-start>=22U&&memcmp(text+start,"#EXT-X-TARGETDURATION:",22U)==0){char tmp[24];size_t k=end-start-22U;if(k>=sizeof(tmp))return 0;memcpy(tmp,text+start+22U,k);tmp[k]='\0';x.target_duration_s=(uint32_t)strtoul(tmp,NULL,10);}
            else if(end-start>=22U&&memcmp(text+start,"#EXT-X-MEDIA-SEQUENCE:",22U)==0){char tmp[24];size_t k=end-start-22U;if(k>=sizeof(tmp))return 0;memcpy(tmp,text+start+22U,k);tmp[k]='\0';x.media_sequence=(uint32_t)strtoul(tmp,NULL,10);}
            else if(end-start>=8U&&memcmp(text+start,"#EXTINF:",8U)==0){int ok=0;uint64_t v=parse_duration_ms(text+start+8U,end-start-8U,&ok);if(!ok||duration_ms>UINT64_MAX-v)return 0;duration_ms+=v;}
            else if(end-start>=18U&&memcmp(text+start,"#EXT-X-STREAM-INF:",18U)==0){x.is_master=1U;expect_variant=1;}
            else if(end-start>=14U&&memcmp(text+start,"#EXT-X-ENDLIST",14U)==0)x.has_endlist=1U;
            else if(end-start>=11U&&memcmp(text+start,"#EXT-X-KEY:",11U)==0&&span_contains_nocase(text+start,end-start,"METHOD=")){if(!span_contains_nocase(text+start,end-start,"METHOD=NONE"))x.encrypted=1U;}
            else if(end-start>=17U&&memcmp(text+start,"#EXT-X-BYTERANGE:",17U)==0)x.has_byterange=1U;
            else if(end-start>=11U&&memcmp(text+start,"#EXT-X-MAP:",11U)==0)x.has_map=1U;
        } else {
            if(expect_variant){if(x.variant_count<UINT32_MAX)++x.variant_count;expect_variant=0;}
            else {if(x.segment_count>=XM_MAX_HLS_SEGMENTS){x.malformed=1U;return 0;}++x.segment_count;}
        }
    }
    if(!saw_header){return 0;}if(expect_variant)x.malformed=1U;
    x.duration_ms=duration_ms;
    x.is_live=(uint8_t)(!x.has_endlist&&!x.is_master);
    x.malformed=(uint8_t)(x.malformed || (x.segment_count == 0U && x.variant_count == 0U));
    *out=x;return x.malformed==0U;
}


#define XM_MAX_WEBVTT_BYTES (256U * 1024U)
#define XM_MAX_WEBVTT_CUES 4096U

static size_t vtt_next_line(const char *text, size_t length, size_t pos, size_t *line_start, size_t *line_end)
{
    size_t start=pos, end;
    end=start;
    while (end<length && text[end]!='\r' && text[end]!='\n') ++end;
    *line_start=start; *line_end=end;
    if (end>=length) return length;
    if (text[end]=='\r' && end+1U<length && text[end+1U]=='\n') return end+2U;
    return end+1U;
}

static int vtt_line_blank(const char *text, size_t start, size_t end)
{
    while (start<end && isspace((unsigned char)text[start])) ++start;
    return start==end;
}

static int vtt_parse_timestamp(const char *text, size_t length, uint64_t *out_ms)
{
    uint64_t first=0U, second=0U, third=0U, millis=0U;
    size_t i, colon1=SIZE_MAX, colon2=SIZE_MAX, dot=SIZE_MAX;
    if (text==NULL || out_ms==NULL || length==0U || length>32U) return 0;
    while (length>0U && isspace((unsigned char)text[0])) { ++text; --length; }
    while (length>0U && isspace((unsigned char)text[length-1U])) --length;
    for (i=0U;i<length;++i) {
        if(text[i]==':' && colon1==SIZE_MAX) colon1=i;
        else if(text[i]==':' && colon2==SIZE_MAX) colon2=i;
        else if(text[i]=='.' && dot==SIZE_MAX) dot=i;
        else if(text[i]<'0'||text[i]>'9') return 0;
    }
    if (dot==SIZE_MAX || dot+4U!=length || colon1==SIZE_MAX || colon1>=dot) return 0;
    if (colon2!=SIZE_MAX && colon2>=dot) return 0;
    for(i=0U;i<dot;++i) {
        uint64_t *target;
        if (i<colon1) target=&first;
        else if (colon2==SIZE_MAX || i<colon2) { if (i==colon1) continue; target=&second; }
        else { if (i==colon2) continue; target=&third; }
        {
            uint64_t digit=(uint64_t)(text[i]-'0');
            if (*target > (UINT64_MAX-digit)/10U) return 0;
            *target=*target*10U+digit;
        }
    }
    for(i=dot+1U;i<length;++i) millis=millis*10U+(uint64_t)(text[i]-'0');
    if (colon2==SIZE_MAX) {
        /* mm:ss.mmm */
        if (second>59U || first > (UINT64_MAX/1000U-second)/60U) return 0;
        *out_ms=(first*60U+second)*1000U+millis;
    } else {
        /* hh:mm:ss.mmm */
        uint64_t tail;
        if (second>59U || third>59U) return 0;
        tail=second*60000U+third*1000U+millis;
        if (first > (UINT64_MAX-tail)/3600000U) return 0;
        *out_ms=first*3600000U+tail;
    }
    return 1;
}

static int vtt_find_arrow(const char *text, size_t start, size_t end, size_t *arrow)
{
    size_t i;
    if (end<start+3U) return 0;
    for(i=start;i+2U<end;++i) if(text[i]=='-'&&text[i+1U]=='-'&&text[i+2U]=='>') { *arrow=i; return 1; }
    return 0;
}

static int vtt_parse_timestamp_line(const char *text, size_t start, size_t end,
                                    uint64_t *start_ms, uint64_t *end_ms)
{
    size_t arrow,left_end,right_start,right_end;
    while(start<end&&isspace((unsigned char)text[start]))++start;
    while(end>start&&isspace((unsigned char)text[end-1U]))--end;
    if(!vtt_find_arrow(text,start,end,&arrow))return 0;
    left_end=arrow;
    while(left_end>start&&isspace((unsigned char)text[left_end-1U]))--left_end;
    right_start=arrow+3U;
    while(right_start<end&&isspace((unsigned char)text[right_start]))++right_start;
    right_end=right_start;
    while(right_end<end&&!isspace((unsigned char)text[right_end]))++right_end;
    if(!vtt_parse_timestamp(text+start,left_end-start,start_ms) ||
       !vtt_parse_timestamp(text+right_start,right_end-right_start,end_ms) || *end_ms<=*start_ms) return 0;
    return 1;
}

static int vtt_ascii_ncasecmp(const char *a, const char *b, size_t n)
{
    size_t i;
    for(i=0U;i<n;++i) {
        int ca=tolower((unsigned char)a[i]), cb=tolower((unsigned char)b[i]);
        if(ca!=cb)return ca-cb;
        if(ca==0)return 0;
    }
    return 0;
}

static int vtt_line_starts(const char *text, size_t start, size_t end, const char *keyword)
{
    size_t n=strlen(keyword);
    if(end-start<n || vtt_ascii_ncasecmp(text+start,keyword,n)!=0)return 0;
    return end-start==n || isspace((unsigned char)text[start+n]);
}

static int xm_media_webvtt_scan(const char *text, size_t length, size_t cue_index,
                                int active_mode, uint64_t timestamp_ms, XmWebVttCue *out)
{
    size_t pos=0U, line_start=0U, line_end=0U, next, header_start, header_end;
    size_t cue_count=0U;
    if(text==NULL||out==NULL||length==0U||length>XM_MAX_WEBVTT_BYTES||
       (!active_mode && cue_index>=XM_MAX_WEBVTT_CUES))return -1;
    memset(out,0,sizeof(*out));
    if(length>=3U&&(unsigned char)text[0]==0xEFU&&(unsigned char)text[1]==0xBBU&&(unsigned char)text[2]==0xBFU)pos=3U;
    next=vtt_next_line(text,length,pos,&header_start,&header_end);
    if(header_end-header_start<6U||memcmp(text+header_start,"WEBVTT",6U)!=0||
       (header_end>header_start+6U&&!isspace((unsigned char)text[header_start+6U])))return -1;
    pos=next;
    while(pos<length) {
        size_t timestamp_start, timestamp_end, text_start, text_end, arrow;
        uint64_t start_ms,end_ms;
        next=vtt_next_line(text,length,pos,&line_start,&line_end);
        if(vtt_line_blank(text,line_start,line_end)){pos=next;continue;}
        if(vtt_line_starts(text,line_start,line_end,"NOTE")||
           vtt_line_starts(text,line_start,line_end,"STYLE")||
           vtt_line_starts(text,line_start,line_end,"REGION")) {
            pos=next;
            while(pos<length) { next=vtt_next_line(text,length,pos,&line_start,&line_end); if(vtt_line_blank(text,line_start,line_end)){pos=next;break;} pos=next; }
            continue;
        }
        timestamp_start=line_start; timestamp_end=line_end;
        if(!vtt_find_arrow(text,timestamp_start,timestamp_end,&arrow)) {
            /* Optional cue identifier precedes the timestamp line. */
            pos=next;
            if(pos>=length)break;
            next=vtt_next_line(text,length,pos,&timestamp_start,&timestamp_end);
            if(!vtt_find_arrow(text,timestamp_start,timestamp_end,&arrow)) {
                pos=next;
                while(pos<length) { next=vtt_next_line(text,length,pos,&line_start,&line_end); if(vtt_line_blank(text,line_start,line_end)){pos=next;break;} pos=next; }
                continue;
            }
        }
        if(!vtt_parse_timestamp_line(text,timestamp_start,timestamp_end,&start_ms,&end_ms)) {
            pos=next;
            while(pos<length) { next=vtt_next_line(text,length,pos,&line_start,&line_end); if(vtt_line_blank(text,line_start,line_end)){pos=next;break;} pos=next; }
            continue;
        }
        text_start=next; text_end=text_start;
        pos=next;
        while(pos<length) {
            next=vtt_next_line(text,length,pos,&line_start,&line_end);
            if(vtt_line_blank(text,line_start,line_end)){pos=next;break;}
            text_end=line_end; pos=next;
        }
        if(cue_count>=XM_MAX_WEBVTT_CUES)return -1;
        if ((!active_mode && cue_count==cue_index) ||
            (active_mode && timestamp_ms>=start_ms && timestamp_ms<end_ms)) {
            out->start_ms=start_ms;out->end_ms=end_ms;out->text_offset=text_start;
            out->text_length=text_end>=text_start?text_end-text_start:0U;return 1;
        }
        ++cue_count;
    }
    return 0;
}

int xm_media_webvtt_get_cue(const char *text, size_t length, size_t cue_index, XmWebVttCue *out)
{
    return xm_media_webvtt_scan(text,length,cue_index,0,0U,out);
}

int xm_media_webvtt_find_active_cue(const char *text, size_t length, uint64_t timestamp_ms, XmWebVttCue *out)
{
    return xm_media_webvtt_scan(text,length,0U,1,timestamp_ms,out);
}

int xm_media_decode_image_rgba(const uint8_t *b, size_t n, uint8_t *rgba,
                               size_t capacity, XmImageInfo *info)
{
    if (b == NULL || rgba == NULL || info == NULL || n < 2U || capacity < 4U)
        return 0;
    /* Prefer signatures and validated inner structure, never filename suffixes. */
    if (n >= 2U && b[0] == (uint8_t)'B' && b[1] == (uint8_t)'M')
        return xm_media_decode_bmp_rgba(b, n, rgba, capacity, info);
    if (n >= 4U && memcmp(b, "qoif", 4U) == 0)
        return xm_media_decode_qoi_rgba(b, n, rgba, capacity, info);
    if (n >= 2U && b[0] == (uint8_t)'P' && (b[1] == (uint8_t)'3' || b[1] == (uint8_t)'6'))
        return xm_media_decode_ppm_rgba(b, n, rgba, capacity, info);
    if (n >= 8U && memcmp(b, "\x89PNG\r\n\x1a\n", 8U) == 0)
        return xm_media_decode_png_rgba(b, n, rgba, capacity, info);
    if (n >= 6U && (memcmp(b, "GIF87a", 6U) == 0 || memcmp(b, "GIF89a", 6U) == 0))
        return xm_media_decode_gif_rgba(b, n, rgba, capacity, info);
    if (n >= 3U && b[0] == 0xFFU && b[1] == 0xD8U && b[2] == 0xFFU)
        return xm_media_decode_jpeg_rgba(b, n, rgba, capacity, info);
    return 0;
}
