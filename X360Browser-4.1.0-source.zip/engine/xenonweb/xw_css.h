#ifndef XW_CSS_H
#define XW_CSS_H

#include "xw_dom.h"
#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#define XW_CSS_MAX_RULES 768U
#define XW_CSS_SELECTOR_CAP 128U
#define XW_CSS_MAX_CUSTOM_PROPERTIES 64U
#define XW_CSS_CUSTOM_NAME_CAP 64U
#define XW_CSS_CUSTOM_VALUE_CAP 128U

typedef enum {
    XW_ALIGN_LEFT = 0,
    XW_ALIGN_CENTER = 1,
    XW_ALIGN_RIGHT = 2
} XwTextAlign;

typedef struct {
    uint32_t color;
    uint32_t background_color;
    int has_background;
    int display_none;
    int display_inline;
    int display_flex;
    int display_grid;
    int grid_columns; /* bounded CSS Grid approximation: 1-4 equal tracks */
    int flex_direction; /* 0: row, 1: column */
    int gap_px;
    int justify_content; /* 0: start, 1: center, 2: end, 3: space-between */
    int flex_wrap;
    int font_size_px;
    int bold;
    int align;
    int margin_top;
    int margin_bottom;
    int padding; /* compatibility summary: max side padding */
    int padding_top;
    int padding_right;
    int padding_bottom;
    int padding_left;
    int border_width;
    int width_px; /* -1 = auto; pixel width otherwise */
    int width_percent; /* -1 = not specified; otherwise bounded 0-100% */
    int min_width_px;
    int max_width_px; /* -1 = not specified */
    int margin_left;
    int margin_right;
    int margin_left_auto;
    int margin_right_auto;
    int line_height_px;
    int italic;
    int text_decoration; /* bit 0: underline, bit 1: line-through */
    int text_transform;  /* 0: none, 1: uppercase, 2: lowercase */
    uint32_t border_color;
    int has_border_color;
} XwComputedStyle;

typedef struct {
    char selector[XW_CSS_SELECTOR_CAP];
    XwComputedStyle values;
    uint32_t declarations;
    uint32_t important_declarations;
    unsigned int specificity;
    unsigned int source_order;
} XwCssRule;

typedef struct {
    char name[XW_CSS_CUSTOM_NAME_CAP];
    char value[XW_CSS_CUSTOM_VALUE_CAP];
} XwCssCustomProperty;

typedef struct {
    XwCssRule rules[XW_CSS_MAX_RULES];
    size_t rule_count;
    XwCssCustomProperty custom_properties[XW_CSS_MAX_CUSTOM_PROPERTIES];
    size_t custom_property_count;
    unsigned int next_source_order;
    int truncated;
} XwStylesheet;

void xw_css_init(XwStylesheet *sheet);
int xw_css_parse(XwStylesheet *sheet, const char *css, size_t length);
/* Viewport-aware entry points support a bounded subset of responsive @media queries. */
int xw_css_parse_for_viewport(XwStylesheet *sheet, const char *css, size_t length,
                              int viewport_width, int viewport_height);
void xw_css_collect_document_styles(XwStylesheet *sheet, const XwDocument *document);
void xw_css_collect_document_styles_for_viewport(XwStylesheet *sheet, const XwDocument *document,
                                                  int viewport_width, int viewport_height);
void xw_css_compute(const XwStylesheet *sheet, const XwDocument *document,
                    uint16_t node_index, const XwComputedStyle *parent,
                    XwComputedStyle *computed);
/* First matching element for a supported compound/descendant selector list. */
uint16_t xw_css_query_selector(const XwDocument *document, const char *selector);
uint16_t xw_css_query_selector_within(const XwDocument *document, uint16_t root_index,
                                      const char *selector);
int xw_css_matches_selector(const XwDocument *document, uint16_t node_index,
                            const char *selector);

#ifdef __cplusplus
}
#endif
#endif
