#include "xw_css.h"

#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include <strings.h>

#define PROP_COLOR          (1UL << 0U)
#define PROP_BACKGROUND     (1UL << 1U)
#define PROP_DISPLAY        (1UL << 2U)
#define PROP_FONT_SIZE      (1UL << 3U)
#define PROP_WEIGHT         (1UL << 4U)
#define PROP_ALIGN          (1UL << 5U)
#define PROP_MARGIN_TOP     (1UL << 6U)
#define PROP_MARGIN_BOT     (1UL << 7U)
#define PROP_PADDING        (1UL << 8U)
#define PROP_BORDER         (1UL << 9U)
#define PROP_WIDTH          (1UL << 10U)
#define PROP_MARGIN_LEFT    (1UL << 11U)
#define PROP_MARGIN_RIGHT   (1UL << 12U)
#define PROP_LINE_HEIGHT    (1UL << 13U)
#define PROP_FONT_STYLE     (1UL << 14U)
#define PROP_TEXT_DECORATION (1UL << 15U)
#define PROP_TEXT_TRANSFORM (1UL << 16U)
#define PROP_BORDER_COLOR   (1UL << 17U)
#define PROP_FLEX_DIRECTION (1UL << 18U)
#define PROP_GAP            (1UL << 19U)
#define PROP_JUSTIFY        (1UL << 20U)
#define PROP_FLEX_WRAP      (1UL << 21U)
#define PROP_GRID_COLUMNS   (1UL << 22U)
#define PROP_MIN_WIDTH      (1UL << 23U)
#define PROP_MAX_WIDTH      (1UL << 24U)
#define PROP_PADDING_TOP    (1UL << 25U)
#define PROP_PADDING_RIGHT  (1UL << 26U)
#define PROP_PADDING_BOTTOM (1UL << 27U)
#define PROP_PADDING_LEFT   (1UL << 28U)
#define PROP_PADDING_SIDES (PROP_PADDING_TOP | PROP_PADDING_RIGHT | PROP_PADDING_BOTTOM | PROP_PADDING_LEFT)
#define PROP_MARGIN (PROP_MARGIN_TOP | PROP_MARGIN_BOT | PROP_MARGIN_LEFT | PROP_MARGIN_RIGHT)
#define PROP_ALL ((1UL << 29U) - 1UL)

static void trim(char *text)
{
    size_t n;
    size_t start = 0U;
    while (text[start] != '\0' && isspace((unsigned char)text[start])) ++start;
    if (start > 0U) memmove(text, text + start, strlen(text + start) + 1U);
    n = strlen(text);
    while (n > 0U && isspace((unsigned char)text[n - 1U])) text[--n] = '\0';
}

static int parse_number_px(const char *value, int fallback)
{
    char *end = NULL;
    long number;
    while (isspace((unsigned char)*value)) ++value;
    number = strtol(value, &end, 10);
    if (end == value) return fallback;
    if (number < 0L) number = 0L;
    if (number > 512L) number = 512L;
    return (int)number;
}

static uint32_t parse_color(const char *value, uint32_t fallback)
{
    char token[64];
    size_t n = 0U;
    unsigned long parsed;
    int red, green, blue;
    double alpha = 1.0;
    while (isspace((unsigned char)*value)) ++value;
    while (*value != '\0' && *value != ';' && n + 1U < sizeof(token)) token[n++] = *value++;
    token[n] = '\0';
    while (n > 0U && isspace((unsigned char)token[n - 1U])) token[--n] = '\0';
    if (strncasecmp(token, "rgb(", 4U) == 0 && sscanf(token, "rgb(%d , %d , %d)", &red, &green, &blue) == 3) {
        if (red < 0) red = 0;
        if (red > 255) red = 255;
        if (green < 0) green = 0;
        if (green > 255) green = 255;
        if (blue < 0) blue = 0;
        if (blue > 255) blue = 255;
        return 0xFF000000U | ((uint32_t)red << 16U) | ((uint32_t)green << 8U) | (uint32_t)blue;
    }
    if (strncasecmp(token, "rgba(", 5U) == 0 && sscanf(token, "rgba(%d , %d , %d , %lf)", &red, &green, &blue, &alpha) == 4) {
        unsigned int a;
        if (red < 0) red = 0;
        if (red > 255) red = 255;
        if (green < 0) green = 0;
        if (green > 255) green = 255;
        if (blue < 0) blue = 0;
        if (blue > 255) blue = 255;
        if (alpha < 0.0) alpha = 0.0;
        if (alpha > 1.0) alpha = 1.0;
        a = (unsigned int)(alpha * 255.0 + 0.5);
        return ((uint32_t)a << 24U) | ((uint32_t)red << 16U) | ((uint32_t)green << 8U) | (uint32_t)blue;
    }
    if (token[0] == '#') {
        if (n == 4U) {
            unsigned long r = strtoul((char[]){token[1], '\0'}, NULL, 16) & 15UL;
            unsigned long g = strtoul((char[]){token[2], '\0'}, NULL, 16) & 15UL;
            unsigned long b = strtoul((char[]){token[3], '\0'}, NULL, 16) & 15UL;
            return 0xFF000000UL | ((uint32_t)(r * 17UL) << 16U) |
                   ((uint32_t)(g * 17UL) << 8U) | (uint32_t)(b * 17UL);
        }
        if (n == 7U && sscanf(token + 1U, "%lx", &parsed) == 1)
            return 0xFF000000U | ((uint32_t)parsed & 0x00FFFFFFU);
    }
    if (strcasecmp(token, "black") == 0) return 0xFF000000U;
    if (strcasecmp(token, "white") == 0) return 0xFFFFFFFFU;
    if (strcasecmp(token, "red") == 0) return 0xFFFF0000U;
    if (strcasecmp(token, "green") == 0) return 0xFF008000U;
    if (strcasecmp(token, "blue") == 0) return 0xFF0000FFU;
    if (strcasecmp(token, "navy") == 0) return 0xFF000080U;
    if (strcasecmp(token, "gray") == 0 || strcasecmp(token, "grey") == 0) return 0xFF808080U;
    if (strcasecmp(token, "yellow") == 0) return 0xFFFFFF00U;
    if (strcasecmp(token, "orange") == 0) return 0xFFFFA500U;
    if (strcasecmp(token, "purple") == 0) return 0xFF800080U;
    if (strcasecmp(token, "teal") == 0) return 0xFF008080U;
    if (strcasecmp(token, "pink") == 0) return 0xFFFFC0CBU;
    if (strcasecmp(token, "cyan") == 0 || strcasecmp(token, "aqua") == 0) return 0xFF00FFFFU;
    if (strcasecmp(token, "magenta") == 0 || strcasecmp(token, "fuchsia") == 0) return 0xFFFF00FFU;
    if (strcasecmp(token, "silver") == 0) return 0xFFC0C0C0U;
    if (strcasecmp(token, "lime") == 0) return 0xFF00FF00U;
    if (strcasecmp(token, "maroon") == 0) return 0xFF800000U;
    if (strcasecmp(token, "olive") == 0) return 0xFF808000U;
    if (strcasecmp(token, "brown") == 0) return 0xFFA52A2AU;
    if (strcasecmp(token, "indigo") == 0) return 0xFF4B0082U;
    if (strcasecmp(token, "violet") == 0) return 0xFFEE82EEU;
    if (strcasecmp(token, "lightgray") == 0 || strcasecmp(token, "lightgrey") == 0) return 0xFFD3D3D3U;
    if (strcasecmp(token, "darkgray") == 0 || strcasecmp(token, "darkgrey") == 0) return 0xFFA9A9A9U;
    if (strcasecmp(token, "rebeccapurple") == 0) return 0xFF663399U;
    if (strcasecmp(token, "cornflowerblue") == 0) return 0xFF6495EDU;
    if (strcasecmp(token, "transparent") == 0) return 0x00000000U;
    return fallback;
}

static unsigned int selector_specificity(const char *selector)
{
    unsigned int specificity = 0U;
    const char *p = selector;
    while (*p != '\0') {
        if (*p == '#') specificity += 100U;
        else if (*p == '.') specificity += 10U;
        else if (isalpha((unsigned char)*p) && (p == selector ||
                 !(isalnum((unsigned char)p[-1]) || p[-1] == '-' || p[-1] == '_' || p[-1] == '.')))
            specificity += 1U;
        ++p;
    }
    return specificity;
}

static void parse_box_shorthand(const char *value, int *top, int *right, int *bottom, int *left)
{
    int parts[4] = {0, 0, 0, 0};
    size_t count = 0U;
    const char *p = value;
    while (*p != '\0' && count < 4U) {
        char token[32];
        size_t n = 0U;
        while (isspace((unsigned char)*p)) ++p;
        while (*p != '\0' && !isspace((unsigned char)*p) && n + 1U < sizeof(token)) token[n++] = *p++;
        if (n == 0U) break;
        token[n] = '\0';
        parts[count++] = parse_number_px(token, 0);
        while (*p != '\0' && !isspace((unsigned char)*p)) ++p;
    }
    if (count == 0U) return;
    if (count == 1U) { *top = *right = *bottom = *left = parts[0]; }
    else if (count == 2U) { *top = *bottom = parts[0]; *right = *left = parts[1]; }
    else if (count == 3U) { *top = parts[0]; *right = *left = parts[1]; *bottom = parts[2]; }
    else { *top = parts[0]; *right = parts[1]; *bottom = parts[2]; *left = parts[3]; }
}

static void parse_margin_shorthand(const char *value, int *top, int *right, int *bottom, int *left,
                                  int *right_auto, int *left_auto)
{
    int parts[4] = {0, 0, 0, 0};
    int automatic[4] = {0, 0, 0, 0};
    size_t count = 0U;
    const char *p = value;
    while (*p != '\0' && count < 4U) {
        char token[32];
        size_t n = 0U;
        while (isspace((unsigned char)*p)) ++p;
        while (*p != '\0' && !isspace((unsigned char)*p) && n + 1U < sizeof(token)) token[n++] = *p++;
        if (n == 0U) break;
        token[n] = '\0';
        automatic[count] = strcasecmp(token, "auto") == 0;
        parts[count] = automatic[count] ? 0 : parse_number_px(token, 0);
        ++count;
        while (*p != '\0' && !isspace((unsigned char)*p)) ++p;
    }
    if (count == 0U) return;
    if (count == 1U) {
        *top = *bottom = parts[0];
        *right = *left = parts[0];
        *right_auto = *left_auto = automatic[0];
    } else if (count == 2U) {
        *top = *bottom = parts[0];
        *right = *left = parts[1];
        *right_auto = *left_auto = automatic[1];
    } else if (count == 3U) {
        *top = parts[0]; *right = parts[1]; *left = parts[1]; *bottom = parts[2];
        *right_auto = *left_auto = automatic[1];
    } else {
        *top = parts[0]; *right = parts[1]; *bottom = parts[2]; *left = parts[3];
        *right_auto = automatic[1]; *left_auto = automatic[3];
    }
}

static uint32_t property_mask_for_name(const char *name)
{
    if (strcasecmp(name, "color") == 0) return PROP_COLOR;
    if (strcasecmp(name, "background") == 0 || strcasecmp(name, "background-color") == 0) return PROP_BACKGROUND;
    if (strcasecmp(name, "display") == 0) return PROP_DISPLAY;
    if (strcasecmp(name, "grid-template-columns") == 0) return PROP_GRID_COLUMNS;
    if (strcasecmp(name, "font-size") == 0) return PROP_FONT_SIZE;
    if (strcasecmp(name, "font-weight") == 0) return PROP_WEIGHT;
    if (strcasecmp(name, "text-align") == 0) return PROP_ALIGN;
    if (strcasecmp(name, "margin-top") == 0) return PROP_MARGIN_TOP;
    if (strcasecmp(name, "margin-bottom") == 0) return PROP_MARGIN_BOT;
    if (strcasecmp(name, "padding") == 0) return PROP_PADDING | PROP_PADDING_SIDES;
    if (strcasecmp(name, "padding-top") == 0) return PROP_PADDING_TOP;
    if (strcasecmp(name, "padding-right") == 0) return PROP_PADDING_RIGHT;
    if (strcasecmp(name, "padding-bottom") == 0) return PROP_PADDING_BOTTOM;
    if (strcasecmp(name, "padding-left") == 0) return PROP_PADDING_LEFT;
    if (strcasecmp(name, "border-width") == 0) return PROP_BORDER;
    if (strcasecmp(name, "border") == 0) return PROP_BORDER | PROP_BORDER_COLOR;
    if (strcasecmp(name, "width") == 0) return PROP_WIDTH;
    if (strcasecmp(name, "min-width") == 0) return PROP_MIN_WIDTH;
    if (strcasecmp(name, "max-width") == 0) return PROP_MAX_WIDTH;
    if (strcasecmp(name, "margin-left") == 0) return PROP_MARGIN_LEFT;
    if (strcasecmp(name, "margin-right") == 0) return PROP_MARGIN_RIGHT;
    if (strcasecmp(name, "line-height") == 0) return PROP_LINE_HEIGHT;
    if (strcasecmp(name, "font-style") == 0) return PROP_FONT_STYLE;
    if (strcasecmp(name, "text-decoration") == 0) return PROP_TEXT_DECORATION;
    if (strcasecmp(name, "text-transform") == 0) return PROP_TEXT_TRANSFORM;
    if (strcasecmp(name, "border-color") == 0) return PROP_BORDER_COLOR;
    if (strcasecmp(name, "flex-direction") == 0) return PROP_FLEX_DIRECTION;
    if (strcasecmp(name, "gap") == 0 || strcasecmp(name, "column-gap") == 0 || strcasecmp(name, "row-gap") == 0) return PROP_GAP;
    if (strcasecmp(name, "justify-content") == 0) return PROP_JUSTIFY;
    if (strcasecmp(name, "flex-wrap") == 0) return PROP_FLEX_WRAP;
    if (strcasecmp(name, "margin") == 0) return PROP_MARGIN;
    return 0U;
}

static void apply_values(XwComputedStyle *target, const XwComputedStyle *value, uint32_t mask);

static const char *css_find_custom_property(const XwStylesheet *sheet, const char *name)
{
    size_t i;
    if (sheet == NULL || name == NULL) return NULL;
    for (i = 0U; i < sheet->custom_property_count; ++i)
        if (strcmp(sheet->custom_properties[i].name, name) == 0)
            return sheet->custom_properties[i].value;
    return NULL;
}

static int css_resolve_vars(const XwStylesheet *sheet, const char *source,
                            char *output, size_t capacity, unsigned depth)
{
    size_t i = 0U, out = 0U, n;
    if (source == NULL || output == NULL || capacity == 0U || depth > 8U) return 0;
    n = strlen(source);
    while (i < n) {
        if (i + 4U <= n && strncasecmp(source + i, "var(", 4U) == 0) {
            size_t j = i + 4U, comma = SIZE_MAX, close = SIZE_MAX;
            unsigned nested = 0U;
            char name[XW_CSS_CUSTOM_NAME_CAP];
            char fallback_buf[256];
            char value_buf[256];
            size_t name_len, value_len;
            const char *replacement_value;
            while (j < n) {
                if (source[j] == '(') ++nested;
                else if (source[j] == ')') {
                    if (nested == 0U) { close = j; break; }
                    --nested;
                } else if (source[j] == ',' && nested == 0U && comma == SIZE_MAX) comma = j;
                ++j;
            }
            if (close == SIZE_MAX) return 0;
            name_len = (comma == SIZE_MAX ? close : comma) - (i + 4U);
            if (name_len >= sizeof(name)) return 0;
            memcpy(name, source + i + 4U, name_len); name[name_len] = '\0'; trim(name);
            if (name[0] != '-' || name[1] != '-') return 0;
            replacement_value = css_find_custom_property(sheet, name);
            if (replacement_value == NULL) {
                if (comma == SIZE_MAX) return 0; /* invalid at computed-value time without fallback */
                replacement_value = source + comma + 1U;
                value_len = close - comma - 1U;
                if (value_len >= sizeof(fallback_buf)) return 0;
                memcpy(fallback_buf, replacement_value, value_len); fallback_buf[value_len] = '\0';
                replacement_value = fallback_buf;
            }
            if (!css_resolve_vars(sheet, replacement_value, value_buf, sizeof(value_buf), depth + 1U)) return 0;
            value_len = strlen(value_buf);
            if (value_len > capacity - out - 1U) return 0;
            memcpy(output + out, value_buf, value_len); out += value_len;
            i = close + 1U;
            continue;
        }
        if (out + 1U >= capacity) return 0;
        output[out++] = source[i++];
    }
    output[out] = '\0';
    return 1;
}

static int parse_declarations(const XwStylesheet *sheet, const char *source, size_t length,
                              XwComputedStyle *values, uint32_t *mask,
                              uint32_t *important_mask)
{
    size_t p = 0U;
    *mask = 0U;
    if (important_mask != NULL) *important_mask = 0U;
    while (p < length) {
        size_t name_start, name_end, value_start, value_end;
        char name[32];
        char value[96];
        size_t copy;
        int is_important = 0;
        XwComputedStyle prior_values;
        uint32_t prior_important;
        uint32_t declaration_properties;
        while (p < length && (isspace((unsigned char)source[p]) || source[p] == ';')) ++p;
        if (p >= length) break;
        name_start = p;
        while (p < length && source[p] != ':' && source[p] != ';') ++p;
        if (p >= length || source[p] != ':') {
            while (p < length && source[p] != ';') ++p;
            continue;
        }
        name_end = p++;
        while (name_start < name_end && isspace((unsigned char)source[name_start])) ++name_start;
        while (name_end > name_start && isspace((unsigned char)source[name_end - 1U])) --name_end;
        value_start = p;
        while (p < length && source[p] != ';') ++p;
        value_end = p;
        while (value_start < value_end && isspace((unsigned char)source[value_start])) ++value_start;
        while (value_end > value_start && isspace((unsigned char)source[value_end - 1U])) --value_end;
        if (value_end >= value_start + 10U && strncasecmp(source + value_end - 10U, "!important", 10U) == 0) {
            value_end -= 10U;
            is_important = 1;
            while (value_end > value_start && isspace((unsigned char)source[value_end - 1U])) --value_end;
        }
        copy = name_end - name_start;
        if (copy == 0U || copy >= sizeof(name)) continue;
        memcpy(name, source + name_start, copy); name[copy] = '\0';
        copy = value_end - value_start;
        if (copy >= sizeof(value)) copy = sizeof(value) - 1U;
        memcpy(value, source + value_start, copy); value[copy] = '\0';
        {
            size_t vi; int contains_var = 0;
            for (vi = 0U; value[vi] != '\0'; ++vi) {
                if (vi + 4U <= strlen(value) && strncasecmp(value + vi, "var(", 4U) == 0) { contains_var = 1; break; }
            }
            if (contains_var) {
                char resolved[96];
                if (!css_resolve_vars(sheet, value, resolved, sizeof(resolved), 0U)) continue;
                (void)snprintf(value, sizeof(value), "%s", resolved);
            }
        }
        prior_values = *values;
        prior_important = important_mask != NULL ? *important_mask : 0U;
        declaration_properties = property_mask_for_name(name);
        if (strcasecmp(name, "color") == 0) {
            values->color = parse_color(value, values->color); *mask |= PROP_COLOR;
        } else if (strcasecmp(name, "background") == 0 || strcasecmp(name, "background-color") == 0) {
            values->background_color = parse_color(value, values->background_color);
            values->has_background = 1; *mask |= PROP_BACKGROUND;
        } else if (strcasecmp(name, "display") == 0) {
            values->display_none = strcasecmp(value, "none") == 0;
            values->display_inline = strcasecmp(value, "inline") == 0 || strcasecmp(value, "inline-block") == 0;
            values->display_flex = strcasecmp(value, "flex") == 0 || strcasecmp(value, "inline-flex") == 0;
            values->display_grid = strcasecmp(value, "grid") == 0 || strcasecmp(value, "inline-grid") == 0;
            *mask |= PROP_DISPLAY;
        } else if (strcasecmp(name, "font-size") == 0) {
            values->font_size_px = parse_number_px(value, values->font_size_px); *mask |= PROP_FONT_SIZE;
        } else if (strcasecmp(name, "font-weight") == 0) {
            values->bold = strcasecmp(value, "bold") == 0 || strcasecmp(value, "bolder") == 0 || atoi(value) >= 600;
            *mask |= PROP_WEIGHT;
        } else if (strcasecmp(name, "text-align") == 0) {
            if (strcasecmp(value, "center") == 0) values->align = XW_ALIGN_CENTER;
            else if (strcasecmp(value, "right") == 0 || strcasecmp(value, "end") == 0) values->align = XW_ALIGN_RIGHT;
            else values->align = XW_ALIGN_LEFT;
            *mask |= PROP_ALIGN;
        } else if (strcasecmp(name, "margin-top") == 0) {
            values->margin_top = parse_number_px(value, values->margin_top); *mask |= PROP_MARGIN_TOP;
        } else if (strcasecmp(name, "margin-bottom") == 0) {
            values->margin_bottom = parse_number_px(value, values->margin_bottom); *mask |= PROP_MARGIN_BOT;
        } else if (strcasecmp(name, "margin-left") == 0) {
            values->margin_left_auto = strcasecmp(value, "auto") == 0;
            values->margin_left = values->margin_left_auto ? 0 : parse_number_px(value, values->margin_left);
            *mask |= PROP_MARGIN_LEFT;
        } else if (strcasecmp(name, "margin-right") == 0) {
            values->margin_right_auto = strcasecmp(value, "auto") == 0;
            values->margin_right = values->margin_right_auto ? 0 : parse_number_px(value, values->margin_right);
            *mask |= PROP_MARGIN_RIGHT;
        } else if (strcasecmp(name, "margin") == 0) {
            parse_margin_shorthand(value, &values->margin_top, &values->margin_right,
                                   &values->margin_bottom, &values->margin_left,
                                   &values->margin_right_auto, &values->margin_left_auto);
            *mask |= PROP_MARGIN;
        } else if (strcasecmp(name, "padding") == 0) {
            parse_box_shorthand(value, &values->padding_top, &values->padding_right,
                                &values->padding_bottom, &values->padding_left);
            values->padding = values->padding_top;
            if (values->padding_right > values->padding) values->padding = values->padding_right;
            if (values->padding_bottom > values->padding) values->padding = values->padding_bottom;
            if (values->padding_left > values->padding) values->padding = values->padding_left;
            *mask |= PROP_PADDING | PROP_PADDING_SIDES;
        } else if (strcasecmp(name, "padding-top") == 0) {
            values->padding_top = parse_number_px(value, values->padding_top); *mask |= PROP_PADDING_TOP;
        } else if (strcasecmp(name, "padding-right") == 0) {
            values->padding_right = parse_number_px(value, values->padding_right); *mask |= PROP_PADDING_RIGHT;
        } else if (strcasecmp(name, "padding-bottom") == 0) {
            values->padding_bottom = parse_number_px(value, values->padding_bottom); *mask |= PROP_PADDING_BOTTOM;
        } else if (strcasecmp(name, "padding-left") == 0) {
            values->padding_left = parse_number_px(value, values->padding_left); *mask |= PROP_PADDING_LEFT;
        } else if (strcasecmp(name, "border-width") == 0) {
            values->border_width = parse_number_px(value, values->border_width); *mask |= PROP_BORDER;
        } else if (strcasecmp(name, "border-color") == 0) {
            values->border_color = parse_color(value, values->border_color);
            values->has_border_color = 1; *mask |= PROP_BORDER_COLOR;
        } else if (strcasecmp(name, "border") == 0) {
            char border_value[96];
            char *part;
            (void)snprintf(border_value, sizeof(border_value), "%s", value);
            part = strtok(border_value, " 	");
            while (part != NULL) {
                if (isdigit((unsigned char)part[0])) {
                    values->border_width = parse_number_px(part, values->border_width); *mask |= PROP_BORDER;
                } else if (strcasecmp(part, "solid") != 0 && strcasecmp(part, "dashed") != 0 &&
                           strcasecmp(part, "dotted") != 0 && strcasecmp(part, "none") != 0) {
                    values->border_color = parse_color(part, values->border_color);
                    values->has_border_color = 1; *mask |= PROP_BORDER_COLOR;
                }
                part = strtok(NULL, " 	");
            }
        } else if (strcasecmp(name, "width") == 0) {
            if (strchr(value, '%') != NULL) {
                int percent = parse_number_px(value, 100);
                if (percent > 100) percent = 100;
                values->width_px = -1;
                values->width_percent = percent;
            } else {
                values->width_px = strcasecmp(value, "auto") == 0 ? -1 : parse_number_px(value, values->width_px);
                values->width_percent = -1;
            }
            *mask |= PROP_WIDTH;
        } else if (strcasecmp(name, "min-width") == 0) {
            values->min_width_px = parse_number_px(value, values->min_width_px); *mask |= PROP_MIN_WIDTH;
        } else if (strcasecmp(name, "max-width") == 0) {
            values->max_width_px = strcasecmp(value, "none") == 0 ? -1 : parse_number_px(value, values->max_width_px); *mask |= PROP_MAX_WIDTH;
        } else if (strcasecmp(name, "line-height") == 0) {
            char *end = NULL;
            double number = strtod(value, &end);
            if (end != value && number > 0.0) {
                if (strstr(value, "px") != NULL) values->line_height_px = parse_number_px(value, values->line_height_px);
                else if (strchr(value, '%') != NULL) values->line_height_px = (int)(16.0 * number / 100.0);
                else if (number < 4.0) values->line_height_px = (int)(16.0 * number);
                else values->line_height_px = (int)number;
                if (values->line_height_px < 10) values->line_height_px = 10;
                if (values->line_height_px > 72) values->line_height_px = 72;
                *mask |= PROP_LINE_HEIGHT;
            }
        } else if (strcasecmp(name, "font-style") == 0) {
            values->italic = strcasecmp(value, "italic") == 0 || strcasecmp(value, "oblique") == 0;
            *mask |= PROP_FONT_STYLE;
        } else if (strcasecmp(name, "text-decoration") == 0) {
            values->text_decoration = 0;
            if (strstr(value, "underline") != NULL) values->text_decoration |= 1;
            if (strstr(value, "line-through") != NULL) values->text_decoration |= 2;
            *mask |= PROP_TEXT_DECORATION;
        } else if (strcasecmp(name, "text-transform") == 0) {
            values->text_transform = strcasecmp(value, "uppercase") == 0 ? 1 :
                strcasecmp(value, "lowercase") == 0 ? 2 : 0;
            *mask |= PROP_TEXT_TRANSFORM;
        } else if (strcasecmp(name, "flex-direction") == 0) {
            values->flex_direction = strcasecmp(value, "column") == 0 || strcasecmp(value, "column-reverse") == 0 ? 1 : 0;
            *mask |= PROP_FLEX_DIRECTION;
        } else if (strcasecmp(name, "gap") == 0 || strcasecmp(name, "column-gap") == 0 || strcasecmp(name, "row-gap") == 0) {
            values->gap_px = parse_number_px(value, values->gap_px);
            *mask |= PROP_GAP;
        } else if (strcasecmp(name, "justify-content") == 0) {
            if (strcasecmp(value, "center") == 0) values->justify_content = 1;
            else if (strcasecmp(value, "flex-end") == 0 || strcasecmp(value, "end") == 0) values->justify_content = 2;
            else if (strcasecmp(value, "space-between") == 0) values->justify_content = 3;
            else values->justify_content = 0;
            *mask |= PROP_JUSTIFY;
        } else if (strcasecmp(name, "flex-wrap") == 0) {
            values->flex_wrap = strcasecmp(value, "wrap") == 0 || strcasecmp(value, "wrap-reverse") == 0;
            *mask |= PROP_FLEX_WRAP;
        } else if (strcasecmp(name, "grid-template-columns") == 0) {
            const char *cursor = value;
            int columns = 0;
            if (strncasecmp(cursor, "repeat(", 7U) == 0) {
                char *end = NULL;
                long requested = strtol(cursor + 7U, &end, 10);
                if (end != cursor + 7U && requested > 0L) columns = requested > 4L ? 4 : (int)requested;
            } else {
                int in_token = 0;
                while (*cursor != '\0') {
                    if (isspace((unsigned char)*cursor) || *cursor == ',') in_token = 0;
                    else if (!in_token) { ++columns; in_token = 1; }
                    ++cursor;
                }
                if (columns > 4) columns = 4;
            }
            if (columns < 1) columns = 1;
            values->grid_columns = columns;
            *mask |= PROP_GRID_COLUMNS;
        }
        if (important_mask != NULL) {
            if (is_important) {
                *important_mask |= declaration_properties;
            } else {
                unsigned int prop;
                /* A later normal declaration cannot replace any side/property already marked important
                 * in this declaration block. Restore those fields individually, preserving other sides. */
                for (prop = 0U; prop < 29U; ++prop) {
                    uint32_t bit = (uint32_t)(1UL << prop);
                    if ((declaration_properties & bit) != 0U && (prior_important & bit) != 0U)
                        apply_values(values, &prior_values, bit);
                }
            }
        }
    }
    return *mask != 0U;
}

void xw_css_init(XwStylesheet *sheet)
{
    if (sheet == NULL) return;
    memset(sheet, 0, sizeof(*sheet));
}

static size_t css_matching_brace(const char *css, size_t length, size_t open)
{
    size_t p = open + 1U;
    unsigned int depth = 1U;
    char quote = '\0';
    while (p < length) {
        if (quote != '\0') {
            if (css[p] == '\\' && p + 1U < length) { p += 2U; continue; }
            if (css[p] == quote) quote = '\0';
            ++p;
            continue;
        }
        if (p + 1U < length && css[p] == '/' && css[p + 1U] == '*') {
            p += 2U;
            while (p + 1U < length && !(css[p] == '*' && css[p + 1U] == '/')) ++p;
            if (p + 1U >= length) return SIZE_MAX;
            p += 2U;
            continue;
        }
        if (css[p] == '\'' || css[p] == '"') { quote = css[p++]; continue; }
        if (css[p] == '{') {
            ++depth;
            if (depth > 8U) return SIZE_MAX;
        } else if (css[p] == '}') {
            if (--depth == 0U) return p;
        }
        ++p;
    }
    return SIZE_MAX;
}

static int parse_media_feature(const char *source, size_t length, int width, int height)
{
    char expression[96];
    char *colon;
    char value[32];
    long wanted;
    char *end = NULL;
    size_t n = length;
    if (n >= sizeof(expression)) return 0;
    memcpy(expression, source, n); expression[n] = '\0'; trim(expression);
    if (expression[0] == '(') {
        n = strlen(expression);
        if (n >= 2U && expression[n - 1U] == ')') { expression[n - 1U] = '\0'; memmove(expression, expression + 1U, n - 1U); }
    }
    trim(expression);
    colon = strchr(expression, ':');
    if (colon == NULL) return 0;
    *colon++ = '\0'; trim(expression); trim(colon);
    if (strlen(colon) >= sizeof(value)) return 0;
    memcpy(value, colon, strlen(colon) + 1U);
    if (strcasecmp(expression, "orientation") == 0) {
        if (strcasecmp(value, "landscape") == 0) return width >= height;
        if (strcasecmp(value, "portrait") == 0) return height > width;
        return 0;
    }
    if (strstr(expression, "width") == NULL && strstr(expression, "height") == NULL) return 0;
    wanted = strtol(value, &end, 10);
    if (end == value || wanted < 0L) return 0;
    if (strstr(value, "px") == NULL && *end != '\0') return 0;
    if (strstr(expression, "min-width") != NULL) return (long)width >= wanted;
    if (strstr(expression, "max-width") != NULL) return (long)width <= wanted;
    if (strstr(expression, "min-height") != NULL) return (long)height >= wanted;
    if (strstr(expression, "max-height") != NULL) return (long)height <= wanted;
    return 0;
}

static int media_query_one_matches(const char *query_source, size_t length, int width, int height)
{
    char query[256];
    size_t n = length;
    int negate = 0;
    int matched = 1;
    size_t p = 0U;
    if (n >= sizeof(query)) return 0;
    memcpy(query, query_source, n); query[n] = '\0'; trim(query);
    if (strncasecmp(query, "not ", 4U) == 0) { negate = 1; memmove(query, query + 4U, strlen(query + 4U) + 1U); trim(query); }
    if (strncasecmp(query, "only ", 5U) == 0) { memmove(query, query + 5U, strlen(query + 5U) + 1U); trim(query); }
    while (query[p] != '\0' && query[p] != '(' && !isspace((unsigned char)query[p])) ++p;
    if (p > 0U) {
        char media_type[24];
        size_t media_length = p < sizeof(media_type) ? p : sizeof(media_type) - 1U;
        memcpy(media_type, query, media_length); media_type[media_length] = '\0';
        if (strcasecmp(media_type, "all") != 0 && strcasecmp(media_type, "screen") != 0) matched = 0;
    }
    p = 0U;
    while (matched && query[p] != '\0') {
        if (query[p] == '(') {
            size_t start = ++p;
            while (query[p] != '\0' && query[p] != ')') ++p;
            if (query[p] == '\0' || !parse_media_feature(query + start - 1U, p - start + 2U, width, height)) matched = 0;
            if (query[p] == ')') ++p;
        } else {
            if (strncasecmp(query + p, "and", 3U) == 0 &&
                (p == 0U || isspace((unsigned char)query[p - 1U])) &&
                (query[p + 3U] == '\0' || isspace((unsigned char)query[p + 3U]))) p += 3U;
            else ++p;
        }
    }
    return negate ? !matched : matched;
}

static int media_query_matches(const char *query, size_t length, int width, int height)
{
    size_t p = 0U;
    size_t start = 0U;
    char quote = '\0';
    while (p <= length) {
        if (p < length && quote != '\0') {
            if (query[p] == quote) quote = '\0';
        } else if (p < length && (query[p] == '\'' || query[p] == '"')) quote = query[p];
        if (p == length || (query[p] == ',' && quote == '\0')) {
            if (media_query_one_matches(query + start, p - start, width, height)) return 1;
            start = p + 1U;
        }
        ++p;
    }
    return 0;
}

static int css_selector_has_root(const char *selector)
{
    char copy[XW_CSS_SELECTOR_CAP];
    char *part;
    if (strlen(selector) >= sizeof(copy)) return 0;
    (void)snprintf(copy, sizeof(copy), "%s", selector);
    part = strtok(copy, ",");
    while (part != NULL) {
        trim(part);
        if (strcasecmp(part, ":root") == 0 || strcasecmp(part, "html") == 0) return 1;
        part = strtok(NULL, ",");
    }
    return 0;
}

static void css_store_custom_property(XwStylesheet *sheet, const char *name, const char *value)
{
    size_t i, name_len, value_len;
    if (sheet == NULL || name == NULL || value == NULL || name[0] != '-' || name[1] != '-') return;
    name_len = strlen(name); value_len = strlen(value);
    if (name_len < 3U || name_len >= XW_CSS_CUSTOM_NAME_CAP || value_len >= XW_CSS_CUSTOM_VALUE_CAP) return;
    for (i = 0U; i < sheet->custom_property_count; ++i) {
        if (strcmp(sheet->custom_properties[i].name, name) == 0) {
            (void)snprintf(sheet->custom_properties[i].value, sizeof(sheet->custom_properties[i].value), "%s", value);
            return;
        }
    }
    if (sheet->custom_property_count >= XW_CSS_MAX_CUSTOM_PROPERTIES) { sheet->truncated = 1; return; }
    (void)snprintf(sheet->custom_properties[sheet->custom_property_count].name,
                   sizeof(sheet->custom_properties[sheet->custom_property_count].name), "%s", name);
    (void)snprintf(sheet->custom_properties[sheet->custom_property_count].value,
                   sizeof(sheet->custom_properties[sheet->custom_property_count].value), "%s", value);
    ++sheet->custom_property_count;
}

static void css_extract_custom_declarations(XwStylesheet *sheet, const char *body, size_t length)
{
    size_t p = 0U;
    while (p < length) {
        size_t name_start, name_end, value_start, value_end;
        char name[XW_CSS_CUSTOM_NAME_CAP];
        char value[XW_CSS_CUSTOM_VALUE_CAP];
        size_t copy;
        while (p < length && (isspace((unsigned char)body[p]) || body[p] == ';')) ++p;
        if (p >= length) break;
        if (p + 1U < length && body[p] == '/' && body[p + 1U] == '*') {
            p += 2U;
            while (p + 1U < length && !(body[p] == '*' && body[p + 1U] == '/')) ++p;
            if (p + 1U >= length) return;
            p += 2U; continue;
        }
        name_start = p;
        while (p < length && body[p] != ':' && body[p] != ';' && body[p] != '}') ++p;
        if (p >= length || body[p] != ':') { while (p < length && body[p] != ';') ++p; continue; }
        name_end = p++;
        while (name_start < name_end && isspace((unsigned char)body[name_start])) ++name_start;
        while (name_end > name_start && isspace((unsigned char)body[name_end - 1U])) --name_end;
        value_start = p;
        {
            char quote = '\0'; unsigned paren = 0U;
            while (p < length) {
                char c = body[p];
                if (quote != '\0') { if (c == quote && (p == 0U || body[p - 1U] != '\\')) quote = '\0'; }
                else if (c == '\'' || c == '"') quote = c;
                else if (c == '(') ++paren;
                else if (c == ')' && paren > 0U) --paren;
                else if (c == ';' && paren == 0U) break;
                else if (c == '}' && paren == 0U) break;
                ++p;
            }
        }
        value_end = p;
        while (value_start < value_end && isspace((unsigned char)body[value_start])) ++value_start;
        while (value_end > value_start && isspace((unsigned char)body[value_end - 1U])) --value_end;
        if (name_end > name_start && body[name_start] == '-' && name_start + 1U < name_end && body[name_start + 1U] == '-') {
            copy = name_end - name_start;
            if (copy < sizeof(name)) {
                memcpy(name, body + name_start, copy); name[copy] = '\0';
                copy = value_end - value_start;
                if (copy < sizeof(value)) {
                    memcpy(value, body + value_start, copy); value[copy] = '\0';
                    trim(name); trim(value); css_store_custom_property(sheet, name, value);
                }
            }
        }
        if (p < length && body[p] == ';') ++p;
    }
}

static void css_collect_root_custom_properties(XwStylesheet *sheet, const char *css, size_t length)
{
    size_t p = 0U;
    if (sheet == NULL || css == NULL) return;
    while (p < length) {
        const char *open;
        size_t open_index, selector_start, selector_end, close_index, copy;
        char selector[XW_CSS_SELECTOR_CAP];
        while (p < length && isspace((unsigned char)css[p])) ++p;
        if (p + 1U < length && css[p] == '/' && css[p + 1U] == '*') {
            p += 2U; while (p + 1U < length && !(css[p] == '*' && css[p + 1U] == '/')) ++p;
            if (p + 1U >= length) return;
            p += 2U;
            continue;
        }
        open = (const char *)memchr(css + p, '{', length - p);
        if (open == NULL) return;
        open_index = (size_t)(open - css); selector_start = p; selector_end = open_index;
        close_index = css_matching_brace(css, length, open_index);
        if (close_index == SIZE_MAX) { sheet->truncated = 1; return; }
        while (selector_start < selector_end && isspace((unsigned char)css[selector_start])) ++selector_start;
        while (selector_end > selector_start && isspace((unsigned char)css[selector_end - 1U])) --selector_end;
        copy = selector_end - selector_start;
        if (copy < sizeof(selector)) {
            memcpy(selector, css + selector_start, copy); selector[copy] = '\0'; trim(selector);
            if (selector[0] != '@' && css_selector_has_root(selector))
                css_extract_custom_declarations(sheet, css + open_index + 1U, close_index - open_index - 1U);
        }
        p = close_index + 1U;
    }
}

static int css_parse_impl(XwStylesheet *sheet, const char *css, size_t length,
                          int viewport_width, int viewport_height, unsigned int depth)
{
    size_t p = 0U;
    int parsed_any = 0;
    if (depth > 4U) { sheet->truncated = 1; return 0; }
    while (p < length && sheet->rule_count < XW_CSS_MAX_RULES) {
        size_t selector_start, selector_end, body_start, body_end, copy;
        char selector[XW_CSS_SELECTOR_CAP];
        const char *open;
        size_t open_index;
        size_t close_index;
        XwCssRule rule;
        while (p < length && isspace((unsigned char)css[p])) ++p;
        if (p + 1U < length && css[p] == '/' && css[p + 1U] == '*') {
            size_t end = p + 2U;
            while (end + 1U < length && !(css[end] == '*' && css[end + 1U] == '/')) ++end;
            if (end + 1U >= length) { sheet->truncated = 1; break; }
            p = end + 2U;
            continue;
        }
        open = memchr(css + p, '{', length - p);
        if (open == NULL) break;
        open_index = (size_t)(open - css);
        selector_start = p;
        selector_end = open_index;
        close_index = css_matching_brace(css, length, open_index);
        if (close_index == SIZE_MAX) { sheet->truncated = 1; break; }
        body_start = open_index + 1U;
        body_end = close_index;
        p = close_index + 1U;
        while (selector_start < selector_end && isspace((unsigned char)css[selector_start])) ++selector_start;
        while (selector_end > selector_start && isspace((unsigned char)css[selector_end - 1U])) --selector_end;
        copy = selector_end - selector_start;
        if (copy == 0U) continue;
        if (copy >= sizeof(selector)) { sheet->truncated = 1; continue; }
        memcpy(selector, css + selector_start, copy); selector[copy] = '\0'; trim(selector);
        if (strncasecmp(selector, "@media", 6U) == 0 &&
            (selector[6] == '\0' || isspace((unsigned char)selector[6]))) {
            const char *query = selector + 6U;
            while (isspace((unsigned char)*query)) ++query;
            if (media_query_matches(query, strlen(query), viewport_width, viewport_height))
                parsed_any |= css_parse_impl(sheet, css + body_start, body_end - body_start,
                                             viewport_width, viewport_height, depth + 1U);
            continue;
        }
        /* Unsupported grouped at-rules are skipped as complete balanced blocks. */
        if (selector[0] == '@') continue;
        /* Comma-separated selector groups become independent cascade rules. */
        {
            char *comma = selector;
            int in_square = 0;
            int in_paren = 0;
            char *group_start = selector;
            char *scan = selector;
            do {
                char c = *scan;
                if (c == '[') ++in_square;
                else if (c == ']' && in_square > 0) --in_square;
                else if (c == '(') ++in_paren;
                else if (c == ')' && in_paren > 0) --in_paren;
                if ((c == ',' && in_square == 0 && in_paren == 0) || c == '\0') {
                    char one[XW_CSS_SELECTOR_CAP];
                    size_t n = (size_t)(scan - group_start);
                    memset(&rule, 0, sizeof(rule));
                    if (n >= sizeof(one)) n = sizeof(one) - 1U;
                    memcpy(one, group_start, n); one[n] = '\0'; trim(one);
                    if (one[0] != '\0' && sheet->rule_count < XW_CSS_MAX_RULES) {
                        uint32_t parsed_mask = 0U;
                        snprintf(rule.selector, sizeof(rule.selector), "%s", one);
                        rule.specificity = selector_specificity(one);
                        rule.source_order = sheet->next_source_order++;
                        (void)parse_declarations(sheet, css + body_start, body_end - body_start,
                                                 &rule.values, &parsed_mask, &rule.important_declarations);
                        rule.declarations = parsed_mask;
                        if (rule.declarations != 0U) {
                            sheet->rules[sheet->rule_count++] = rule;
                            parsed_any = 1;
                        }
                    }
                    if (c == '\0') break;
                    group_start = scan + 1;
                }
                ++scan;
            } while (1);
            (void)comma;
        }
    }
    if (p < length && sheet->rule_count >= XW_CSS_MAX_RULES) sheet->truncated = 1;
    return parsed_any;
}

int xw_css_parse_for_viewport(XwStylesheet *sheet, const char *css, size_t length,
                              int viewport_width, int viewport_height)
{
    if (sheet == NULL || css == NULL) return 0;
    if (viewport_width < 1) viewport_width = 1;
    if (viewport_height < 1) viewport_height = 1;
    if (viewport_width > 8192) viewport_width = 8192;
    if (viewport_height > 8192) viewport_height = 8192;
    if (length > 262144U) { sheet->truncated = 1; return 0; }
    css_collect_root_custom_properties(sheet, css, length);
    return css_parse_impl(sheet, css, length, viewport_width, viewport_height, 0U);
}

int xw_css_parse(XwStylesheet *sheet, const char *css, size_t length)
{
    return xw_css_parse_for_viewport(sheet, css, length, 1152, 384);
}

static int is_element_child_of(const XwDocument *document, uint16_t node_index,
                               int require_first, int require_last, long nth_child)
{
    const XwDomNode *node;
    uint16_t parent;
    uint16_t cursor;
    long element_position = 0L;
    int found = 0;
    if (node_index >= document->node_count) return 0;
    node = &document->nodes[node_index];
    parent = node->parent;
    if (parent == XW_DOM_NONE || parent >= document->node_count) return 0;
    cursor = document->nodes[parent].first_child;
    while (cursor != XW_DOM_NONE) {
        if (document->nodes[cursor].type == XW_NODE_ELEMENT) {
            ++element_position;
            if (cursor == node_index) {
                found = 1;
                if (require_first && element_position != 1L) return 0;
                if (nth_child > 0L && element_position != nth_child) return 0;
                if (nth_child == -1L && (element_position % 2L) == 0L) return 0;
                if (nth_child == -2L && (element_position % 2L) != 0L) return 0;
            } else if (found && require_last) {
                return 0;
            }
        }
        cursor = document->nodes[cursor].next_sibling;
    }
    if (!found) return 0;
    if (require_last) {
        cursor = node->next_sibling;
        while (cursor != XW_DOM_NONE) {
            if (document->nodes[cursor].type == XW_NODE_ELEMENT) return 0;
            cursor = document->nodes[cursor].next_sibling;
        }
    }
    return 1;
}

static int is_element_of_type_child(const XwDocument *document, uint16_t node_index,
                                    int require_first, int require_last, long nth_child)
{
    const XwDomNode *node;
    const char *node_tag;
    uint16_t parent;
    uint16_t cursor;
    long position = 0L;
    int found = 0;
    if (node_index >= document->node_count) return 0;
    node = &document->nodes[node_index];
    if (node->type != XW_NODE_ELEMENT) return 0;
    node_tag = xw_dom_string(document, node->name_offset);
    parent = node->parent;
    if (parent == XW_DOM_NONE || parent >= document->node_count) return 0;
    cursor = document->nodes[parent].first_child;
    while (cursor != XW_DOM_NONE) {
        const XwDomNode *candidate = &document->nodes[cursor];
        if (candidate->type == XW_NODE_ELEMENT &&
            strcasecmp(xw_dom_string(document, candidate->name_offset), node_tag) == 0) {
            ++position;
            if (cursor == node_index) {
                found = 1;
                if (require_first && position != 1L) return 0;
                if (nth_child > 0L && position != nth_child) return 0;
                if (nth_child == -1L && (position % 2L) == 0L) return 0;
                if (nth_child == -2L && (position % 2L) != 0L) return 0;
            } else if (found && require_last) return 0;
        }
        cursor = candidate->next_sibling;
    }
    if (!found) return 0;
    if (require_last) {
        cursor = node->next_sibling;
        while (cursor != XW_DOM_NONE) {
            const XwDomNode *candidate = &document->nodes[cursor];
            if (candidate->type == XW_NODE_ELEMENT &&
                strcasecmp(xw_dom_string(document, candidate->name_offset), node_tag) == 0) return 0;
            cursor = candidate->next_sibling;
        }
    }
    return 1;
}

static int attribute_selector_match(const XwDocument *document, uint16_t node_index,
                                    const char *source, size_t length)
{
    char expression[XW_CSS_SELECTOR_CAP];
    char name[64];
    char wanted[64];
    const char *actual;
    size_t eq = SIZE_MAX;
    size_t i;
    size_t name_length;
    size_t wanted_length;
    char operation = '=';
    if (length == 0U || length >= sizeof(expression)) return 0;
    memcpy(expression, source, length);
    expression[length] = '\0';
    trim(expression);
    for (i = 0U; expression[i] != '\0'; ++i) {
        if (expression[i] == '=' || ((expression[i] == '^' || expression[i] == '$' ||
            expression[i] == '*' || expression[i] == '~' || expression[i] == '|') && expression[i + 1U] == '=')) {
            eq = i;
            if (expression[i] != '=') operation = expression[i];
            break;
        }
    }
    if (eq == SIZE_MAX) {
        if (strlen(expression) >= sizeof(name)) return 0;
        memcpy(name, expression, strlen(expression) + 1U);
        actual = xw_dom_attribute(document, node_index, name);
        return actual != NULL;
    }
    name_length = eq;
    if (operation != '=') ++eq;
    while (name_length > 0U && isspace((unsigned char)expression[name_length - 1U])) --name_length;
    if (name_length == 0U || name_length >= sizeof(name)) return 0;
    memcpy(name, expression, name_length); name[name_length] = '\0';
    ++eq; /* skip '=' */
    while (expression[eq] != '\0' && isspace((unsigned char)expression[eq])) ++eq;
    wanted_length = strlen(expression + eq);
    if (wanted_length >= sizeof(wanted)) wanted_length = sizeof(wanted) - 1U;
    if (wanted_length >= 2U && ((expression[eq] == '\'' && expression[eq + wanted_length - 1U] == '\'') ||
                                (expression[eq] == '"' && expression[eq + wanted_length - 1U] == '"'))) {
        ++eq; wanted_length -= 2U;
    }
    memcpy(wanted, expression + eq, wanted_length); wanted[wanted_length] = '\0';
    actual = xw_dom_attribute(document, node_index, name);
    if (actual == NULL) return 0;
    if (operation == '=') return strcmp(actual, wanted) == 0;
    if (operation == '^') return strncmp(actual, wanted, wanted_length) == 0;
    if (operation == '$') {
        size_t actual_length = strlen(actual);
        return actual_length >= wanted_length && strcmp(actual + actual_length - wanted_length, wanted) == 0;
    }
    if (operation == '*') return strstr(actual, wanted) != NULL;
    if (operation == '~') {
        const char *cursor = actual;
        while (*cursor != '\0') {
            const char *start;
            while (isspace((unsigned char)*cursor)) ++cursor;
            start = cursor;
            while (*cursor != '\0' && !isspace((unsigned char)*cursor)) ++cursor;
            if ((size_t)(cursor - start) == wanted_length && strncmp(start, wanted, wanted_length) == 0) return 1;
        }
        return 0;
    }
    if (operation == '|')
        return strncmp(actual, wanted, wanted_length) == 0 &&
               (actual[wanted_length] == '\0' || actual[wanted_length] == '-');
    return 0;
}

static int simple_selector_match_depth(const XwDocument *document, uint16_t node_index,
                                       const char *token, size_t length, unsigned depth)
{
    size_t i = 0U;
    size_t type_start = 0U;
    int type_seen = 0;
    if (node_index >= document->node_count || length == 0U || depth > 8U ||
        document->nodes[node_index].type != XW_NODE_ELEMENT) return 0;
    if (length == 1U && token[0] == '*') return 1;
    while (i < length && token[i] != '.' && token[i] != '#' && token[i] != '[' && token[i] != ':') ++i;
    if (i > type_start) {
        char type_name[XW_CSS_SELECTOR_CAP];
        if (i >= sizeof(type_name)) return 0;
        memcpy(type_name, token, i); type_name[i] = '\0';
        if (strcmp(type_name, "*") != 0 &&
            strcasecmp(xw_dom_string(document, document->nodes[node_index].name_offset), type_name) != 0) return 0;
        type_seen = 1;
    }
    while (i < length) {
        char marker = token[i++];
        size_t start = i;
        size_t n;
        char name[XW_CSS_SELECTOR_CAP];
        if (marker == '.' || marker == '#') {
            while (i < length && token[i] != '.' && token[i] != '#' && token[i] != '[' && token[i] != ':') ++i;
            n = i - start;
            if (n == 0U || n >= sizeof(name)) return 0;
            memcpy(name, token + start, n); name[n] = '\0';
            if (marker == '#') {
                const char *id = xw_dom_attribute(document, node_index, "id");
                if (id == NULL || strcmp(id, name) != 0) return 0;
            } else if (!xw_dom_has_class(document, node_index, name)) return 0;
        } else if (marker == '[') {
            size_t close = i;
            char quote = '\0';
            while (close < length) {
                if (quote != '\0') { if (token[close] == quote) quote = '\0'; }
                else if (token[close] == '\'' || token[close] == '"') quote = token[close];
                else if (token[close] == ']') break;
                ++close;
            }
            if (close >= length || !attribute_selector_match(document, node_index, token + start, close - start)) return 0;
            i = close + 1U;
        } else if (marker == ':') {
            char pseudo[32];
            size_t pseudo_start = i;
            size_t pseudo_length;
            size_t arg_start = SIZE_MAX;
            size_t arg_length = 0U;
            while (i < length && token[i] != ':' && token[i] != '.' && token[i] != '#' && token[i] != '[' && token[i] != '(') ++i;
            pseudo_length = i - pseudo_start;
            if (pseudo_length == 0U || pseudo_length >= sizeof(pseudo)) return 0;
            memcpy(pseudo, token + pseudo_start, pseudo_length); pseudo[pseudo_length] = '\0';
            if (i < length && token[i] == '(') {
                arg_start = ++i;
                while (i < length && token[i] != ')') ++i;
                if (i >= length) return 0;
                arg_length = i - arg_start;
                ++i;
            }
            if (strcasecmp(pseudo, "first-child") == 0) {
                if (!is_element_child_of(document, node_index, 1, 0, 0L)) return 0;
            } else if (strcasecmp(pseudo, "last-child") == 0) {
                if (!is_element_child_of(document, node_index, 0, 1, 0L)) return 0;
            } else if (strcasecmp(pseudo, "nth-child") == 0 || strcasecmp(pseudo, "nth-of-type") == 0) {
                char number[16]; char *end = NULL; long nth_value;
                int of_type = strcasecmp(pseudo, "nth-of-type") == 0;
                if (arg_start == SIZE_MAX || arg_length == 0U || arg_length >= sizeof(number)) return 0;
                memcpy(number, token + arg_start, arg_length); number[arg_length] = '\0';
                if (strcasecmp(number, "odd") == 0) nth_value = -1L;
                else if (strcasecmp(number, "even") == 0) nth_value = -2L;
                else nth_value = strtol(number, &end, 10);
                if ((nth_value == 0L && (end == number || *end != '\0')) ||
                    (nth_value < 0L && nth_value != -1L && nth_value != -2L) ||
                    !(of_type ? is_element_of_type_child(document, node_index, 0, 0, nth_value) :
                                is_element_child_of(document, node_index, 0, 0, nth_value))) return 0;
            } else if (strcasecmp(pseudo, "first-of-type") == 0) {
                if (!is_element_of_type_child(document, node_index, 1, 0, 0L)) return 0;
            } else if (strcasecmp(pseudo, "last-of-type") == 0) {
                if (!is_element_of_type_child(document, node_index, 0, 1, 0L)) return 0;
            } else if (strcasecmp(pseudo, "checked") == 0 || strcasecmp(pseudo, "disabled") == 0 ||
                       strcasecmp(pseudo, "required") == 0 || strcasecmp(pseudo, "selected") == 0) {
                const char *attribute = strcasecmp(pseudo, "checked") == 0 ? "checked" :
                    strcasecmp(pseudo, "disabled") == 0 ? "disabled" :
                    strcasecmp(pseudo, "required") == 0 ? "required" : "selected";
                if (xw_dom_attribute(document, node_index, attribute) == NULL) return 0;
            } else if (strcasecmp(pseudo, "not") == 0) {
                if (arg_start == SIZE_MAX || arg_length == 0U ||
                    simple_selector_match_depth(document, node_index, token + arg_start, arg_length, depth + 1U)) return 0;
            } else if (strcasecmp(pseudo, "link") == 0) {
                if (strcasecmp(xw_dom_string(document, document->nodes[node_index].name_offset), "a") != 0 ||
                    xw_dom_attribute(document, node_index, "href") == NULL) return 0;
            } else if (strcasecmp(pseudo, "enabled") == 0) {
                if (xw_dom_attribute(document, node_index, "disabled") != NULL) return 0;
            } else if (strcasecmp(pseudo, "empty") == 0) {
                if (document->nodes[node_index].first_child != XW_DOM_NONE) return 0;
            } else if (strcasecmp(pseudo, "root") == 0) {
                uint16_t parent = document->nodes[node_index].parent;
                if (parent == XW_DOM_NONE || parent >= document->node_count ||
                    document->nodes[parent].type != XW_NODE_DOCUMENT) return 0;
            } else return 0;
        } else return 0;
    }
    return type_seen || token[0] == '.' || token[0] == '#' || token[0] == '[' || token[0] == ':';
}

static int simple_selector_match(const XwDocument *document, uint16_t node_index,
                                 const char *token, size_t length)
{
    return simple_selector_match_depth(document, node_index, token, length, 0U);
}

static int selector_match(const XwDocument *document, uint16_t node_index, const char *selector)
{
    size_t starts[16];
    size_t ends[16];
    unsigned char child_combinator[16];
    size_t count = 0U;
    size_t p = 0U;
    size_t length;
    uint16_t current;
    int next_is_child = 0;
    if (selector == NULL) return 0;
    length = strlen(selector);
    memset(child_combinator, 0, sizeof(child_combinator));
    while (p < length) {
        while (p < length && isspace((unsigned char)selector[p])) ++p;
        if (p >= length) break;
        if (selector[p] == '>') {
            if (count == 0U || next_is_child) return 0;
            next_is_child = 1;
            ++p;
            continue;
        }
        {
            size_t start = p;
            char quote = '\0';
            while (p < length) {
                char c = selector[p];
                if (quote != '\0') { if (c == quote) quote = '\0'; }
                else if (c == '\'' || c == '"') quote = c;
                else if (c == '>' || isspace((unsigned char)c)) break;
                ++p;
            }
            if (p == start || count >= sizeof(starts) / sizeof(starts[0])) return 0;
            starts[count] = start;
            ends[count] = p;
            child_combinator[count] = (unsigned char)(count > 0U && next_is_child ? 1U : 0U);
            ++count;
            next_is_child = 0;
        }
    }
    if (count == 0U || next_is_child) return 0;
    if (!simple_selector_match(document, node_index, selector + starts[count - 1U], ends[count - 1U] - starts[count - 1U])) return 0;
    current = document->nodes[node_index].parent;
    if (count == 1U) return 1;
    {
        size_t token = count - 1U;
        while (token > 0U) {
            --token;
            if (child_combinator[token + 1U]) {
                if (current == XW_DOM_NONE ||
                    !simple_selector_match(document, current, selector + starts[token], ends[token] - starts[token])) return 0;
                current = document->nodes[current].parent;
            } else {
                while (current != XW_DOM_NONE &&
                       !simple_selector_match(document, current, selector + starts[token], ends[token] - starts[token]))
                    current = document->nodes[current].parent;
                if (current == XW_DOM_NONE) return 0;
                current = document->nodes[current].parent;
            }
        }
    }
    return 1;
}

static int is_block_tag(const char *tag)
{
    static const char *const block[] = {
        "address", "article", "aside", "blockquote", "body", "div", "dl", "dt", "dd",
        "fieldset", "figcaption", "figure", "footer", "form", "h1", "h2", "h3", "h4",
        "h5", "h6", "header", "hr", "li", "main", "nav", "ol", "p", "pre",
        "section", "table", "tr", "ul"
    };
    size_t i;
    for (i = 0U; i < sizeof(block) / sizeof(block[0]); ++i) if (strcasecmp(tag, block[i]) == 0) return 1;
    return 0;
}

static void apply_values(XwComputedStyle *target, const XwComputedStyle *value, uint32_t mask)
{
    if (mask & PROP_COLOR) target->color = value->color;
    if (mask & PROP_BACKGROUND) { target->background_color = value->background_color; target->has_background = value->has_background; }
    if (mask & PROP_DISPLAY) {
        target->display_none = value->display_none;
        target->display_inline = value->display_inline;
        target->display_flex = value->display_flex;
        target->display_grid = value->display_grid;
    }
    if (mask & PROP_FONT_SIZE) target->font_size_px = value->font_size_px;
    if (mask & PROP_WEIGHT) target->bold = value->bold;
    if (mask & PROP_ALIGN) target->align = value->align;
    if (mask & PROP_MARGIN_TOP) target->margin_top = value->margin_top;
    if (mask & PROP_MARGIN_BOT) target->margin_bottom = value->margin_bottom;
    if (mask & PROP_PADDING) target->padding = value->padding;
    if (mask & PROP_PADDING_TOP) target->padding_top = value->padding_top;
    if (mask & PROP_PADDING_RIGHT) target->padding_right = value->padding_right;
    if (mask & PROP_PADDING_BOTTOM) target->padding_bottom = value->padding_bottom;
    if (mask & PROP_PADDING_LEFT) target->padding_left = value->padding_left;
    if (mask & PROP_BORDER) target->border_width = value->border_width;
    if (mask & PROP_WIDTH) { target->width_px = value->width_px; target->width_percent = value->width_percent; }
    if (mask & PROP_MIN_WIDTH) target->min_width_px = value->min_width_px;
    if (mask & PROP_MAX_WIDTH) target->max_width_px = value->max_width_px;
    if (mask & PROP_MARGIN_LEFT) {
        target->margin_left = value->margin_left;
        target->margin_left_auto = value->margin_left_auto;
    }
    if (mask & PROP_MARGIN_RIGHT) {
        target->margin_right = value->margin_right;
        target->margin_right_auto = value->margin_right_auto;
    }
    if (mask & PROP_LINE_HEIGHT) target->line_height_px = value->line_height_px;
    if (mask & PROP_FONT_STYLE) target->italic = value->italic;
    if (mask & PROP_TEXT_DECORATION) target->text_decoration = value->text_decoration;
    if (mask & PROP_TEXT_TRANSFORM) target->text_transform = value->text_transform;
    if (mask & PROP_BORDER_COLOR) { target->border_color = value->border_color; target->has_border_color = value->has_border_color; }
    if (mask & PROP_FLEX_DIRECTION) target->flex_direction = value->flex_direction;
    if (mask & PROP_GAP) target->gap_px = value->gap_px;
    if (mask & PROP_JUSTIFY) target->justify_content = value->justify_content;
    if (mask & PROP_FLEX_WRAP) target->flex_wrap = value->flex_wrap;
    if (mask & PROP_GRID_COLUMNS) target->grid_columns = value->grid_columns;
}

void xw_css_collect_document_styles_for_viewport(XwStylesheet *sheet, const XwDocument *document,
                                                  int viewport_width, int viewport_height)
{
    size_t i;
    if (sheet == NULL || document == NULL) return;
    /* Collect root variables from every inline stylesheet before parsing declarations,
       so a variable may be declared in a later <style> element and used earlier. */
    for (i = 0U; i < document->node_count; ++i) {
        const XwDomNode *node = &document->nodes[i];
        if (node->type == XW_NODE_ELEMENT && strcasecmp(xw_dom_string(document, node->name_offset), "style") == 0) {
            uint16_t child = node->first_child;
            while (child != XW_DOM_NONE) {
                if (document->nodes[child].type == XW_NODE_TEXT) {
                    const char *text = xw_dom_string(document, document->nodes[child].value_offset);
                    css_collect_root_custom_properties(sheet, text, strlen(text));
                }
                child = document->nodes[child].next_sibling;
            }
        }
    }
    for (i = 0U; i < document->node_count; ++i) {
        const XwDomNode *node = &document->nodes[i];
        if (node->type == XW_NODE_ELEMENT && strcasecmp(xw_dom_string(document, node->name_offset), "style") == 0) {
            uint16_t child = node->first_child;
            while (child != XW_DOM_NONE) {
                if (document->nodes[child].type == XW_NODE_TEXT) {
                    const char *text = xw_dom_string(document, document->nodes[child].value_offset);
                    (void)css_parse_impl(sheet, text, strlen(text), viewport_width, viewport_height, 0U);
                }
                child = document->nodes[child].next_sibling;
            }
        }
    }
}

void xw_css_collect_document_styles(XwStylesheet *sheet, const XwDocument *document)
{
    xw_css_collect_document_styles_for_viewport(sheet, document, 1152, 384);
}

void xw_css_compute(const XwStylesheet *sheet, const XwDocument *document,
                    uint16_t node_index, const XwComputedStyle *parent,
                    XwComputedStyle *computed)
{
    const char *tag;
    unsigned int property_specificity[29] = {0U};
    unsigned int property_order[29] = {0U};
    unsigned char property_important[29] = {0U};
    size_t i;
    if (document == NULL || computed == NULL || node_index >= document->node_count) return;
    memset(computed, 0, sizeof(*computed));
    computed->color = parent != NULL ? parent->color : 0xFF202124U;
    computed->background_color = 0x00000000U;
    computed->font_size_px = parent != NULL ? parent->font_size_px : 16;
    computed->align = parent != NULL ? parent->align : XW_ALIGN_LEFT;
    computed->line_height_px = parent != NULL ? parent->line_height_px : 0;
    computed->text_decoration = parent != NULL ? parent->text_decoration : 0;
    computed->text_transform = parent != NULL ? parent->text_transform : 0;
    computed->width_px = -1;
    computed->width_percent = -1;
    computed->max_width_px = -1;
    computed->border_color = 0xFFB8C1CCU;
    tag = xw_dom_string(document, document->nodes[node_index].name_offset);
    if (document->nodes[node_index].type == XW_NODE_ELEMENT) {
        computed->display_inline = !is_block_tag(tag);
        if (strcasecmp(tag, "script") == 0 || strcasecmp(tag, "style") == 0 ||
            strcasecmp(tag, "head") == 0 || strcasecmp(tag, "meta") == 0 ||
            strcasecmp(tag, "link") == 0 || strcasecmp(tag, "title") == 0) computed->display_none = 1;
        if (tag[0] == 'h' && tag[1] >= '1' && tag[1] <= '6' && tag[2] == '\0') {
            computed->bold = 1;
            computed->font_size_px = 32 - (tag[1] - '1') * 3;
        } else if (strcasecmp(tag, "strong") == 0 || strcasecmp(tag, "b") == 0) computed->bold = 1;
        if (strcasecmp(tag, "a") == 0) computed->color = 0xFF1A73E8U;
        if (strcasecmp(tag, "p") == 0 || tag[0] == 'h') { computed->margin_top = 8; computed->margin_bottom = 8; }
        if (strcasecmp(tag, "br") == 0) computed->display_inline = 1;
    }

    if (sheet != NULL) {
        for (i = 0U; i < sheet->rule_count; ++i) {
            const XwCssRule *rule = &sheet->rules[i];
            unsigned int prop;
            if (!selector_match(document, node_index, rule->selector)) continue;
            for (prop = 0U; prop < 29U; ++prop) {
                uint32_t bit = (uint32_t)(1UL << prop);
                unsigned char important = (rule->important_declarations & bit) != 0U ? 1U : 0U;
                if ((rule->declarations & bit) != 0U &&
                    ((important > property_important[prop]) ||
                     (important == property_important[prop] &&
                      (rule->specificity > property_specificity[prop] ||
                       (rule->specificity == property_specificity[prop] && rule->source_order >= property_order[prop]))))) {
                    property_important[prop] = important;
                    property_specificity[prop] = rule->specificity;
                    property_order[prop] = rule->source_order;
                    apply_values(computed, &rule->values, bit);
                }
            }
        }
    }
    {
        const char *inline_style = xw_dom_attribute(document, node_index, "style");
        if (inline_style != NULL) {
            XwComputedStyle inline_values;
            uint32_t mask = 0U;
            uint32_t inline_important = 0U;
            memset(&inline_values, 0, sizeof(inline_values));
            inline_values.color = computed->color;
            inline_values.background_color = computed->background_color;
            inline_values.font_size_px = computed->font_size_px;
            inline_values.width_px = computed->width_px;
            inline_values.width_percent = computed->width_percent;
            inline_values.padding = computed->padding;
            inline_values.padding_top = computed->padding_top;
            inline_values.padding_right = computed->padding_right;
            inline_values.padding_bottom = computed->padding_bottom;
            inline_values.padding_left = computed->padding_left;
            inline_values.min_width_px = computed->min_width_px;
            inline_values.max_width_px = computed->max_width_px;
            inline_values.margin_top = computed->margin_top;
            inline_values.margin_bottom = computed->margin_bottom;
            inline_values.margin_left = computed->margin_left;
            inline_values.margin_right = computed->margin_right;
            inline_values.margin_left_auto = computed->margin_left_auto;
            inline_values.margin_right_auto = computed->margin_right_auto;
            inline_values.line_height_px = computed->line_height_px;
            inline_values.italic = computed->italic;
            inline_values.text_decoration = computed->text_decoration;
            inline_values.text_transform = computed->text_transform;
            inline_values.border_width = computed->border_width;
            inline_values.border_color = computed->border_color;
            inline_values.has_border_color = computed->has_border_color;
            (void)parse_declarations(sheet, inline_style, strlen(inline_style), &inline_values, &mask, &inline_important);
            {
                unsigned int prop;
                for (prop = 0U; prop < 29U; ++prop) {
                    uint32_t bit = (uint32_t)(1UL << prop);
                    int important = (inline_important & bit) != 0U;
                    if ((mask & bit) != 0U && (important || property_important[prop] == 0U)) {
                        apply_values(computed, &inline_values, bit);
                        property_important[prop] = (unsigned char)important;
                        property_specificity[prop] = UINT_MAX;
                        property_order[prop] = UINT_MAX;
                    }
                }
            }
        }
    }
    if (computed->font_size_px < 8) computed->font_size_px = 8;
    if (computed->font_size_px > 48) computed->font_size_px = 48;
    if (computed->padding_top > 64) computed->padding_top = 64;
    if (computed->padding_right > 64) computed->padding_right = 64;
    if (computed->padding_bottom > 64) computed->padding_bottom = 64;
    if (computed->padding_left > 64) computed->padding_left = 64;
    computed->padding = computed->padding_top;
    if (computed->padding_right > computed->padding) computed->padding = computed->padding_right;
    if (computed->padding_bottom > computed->padding) computed->padding = computed->padding_bottom;
    if (computed->padding_left > computed->padding) computed->padding = computed->padding_left;
    if (computed->margin_left > 256) computed->margin_left = 256;
    if (computed->margin_right > 256) computed->margin_right = 256;
    if (computed->line_height_px > 72) computed->line_height_px = 72;
}

static int node_is_within(const XwDocument *document, uint16_t node_index, uint16_t root_index)
{
    uint16_t cursor;
    size_t depth = 0U;
    if (document == NULL || node_index >= document->node_count || root_index >= document->node_count) return 0;
    cursor = document->nodes[node_index].parent;
    while (cursor != XW_DOM_NONE && depth++ < XW_DOM_MAX_DEPTH) {
        if (cursor == root_index) return 1;
        if (cursor >= document->node_count) return 0;
        cursor = document->nodes[cursor].parent;
    }
    return 0;
}

static uint16_t query_selector_impl(const XwDocument *document, uint16_t root_index,
                                    const char *selector, int scoped)
{
    char group[XW_CSS_SELECTOR_CAP];
    const char *start;
    const char *cursor;
    if (document == NULL || selector == NULL || (scoped && root_index >= document->node_count)) return XW_DOM_NONE;
    start = selector;
    for (cursor = selector;; ++cursor) {
        if (*cursor == '\'' || *cursor == '"') {
            char quote = *cursor;
            ++cursor;
            while (*cursor != '\0' && *cursor != quote) ++cursor;
            if (*cursor == '\0') break;
            continue;
        }
        if (*cursor == ',' || *cursor == '\0') {
            size_t length = (size_t)(cursor - start);
            size_t i;
            if (length >= sizeof(group)) length = sizeof(group) - 1U;
            memcpy(group, start, length); group[length] = '\0'; trim(group);
            if (group[0] != '\0') {
                for (i = 0U; i < document->node_count; ++i) {
                    const uint16_t candidate = (uint16_t)i;
                    if (document->nodes[i].type != XW_NODE_ELEMENT) continue;
                    if (scoped && !node_is_within(document, candidate, root_index)) continue;
                    if (!scoped && !xw_dom_is_connected(document, candidate)) continue;
                    if (selector_match(document, candidate, group)) return candidate;
                }
            }
            if (*cursor == '\0') break;
            start = cursor + 1;
        }
    }
    return XW_DOM_NONE;
}

uint16_t xw_css_query_selector(const XwDocument *document, const char *selector)
{
    return query_selector_impl(document, XW_DOM_NONE, selector, 0);
}

uint16_t xw_css_query_selector_within(const XwDocument *document, uint16_t root_index,
                                      const char *selector)
{
    return query_selector_impl(document, root_index, selector, 1);
}

int xw_css_matches_selector(const XwDocument *document, uint16_t node_index,
                            const char *selector)
{
    return document != NULL && node_index < document->node_count &&
           document->nodes[node_index].type == XW_NODE_ELEMENT &&
           selector != NULL && selector_match(document, node_index, selector);
}
