#ifndef XW_LAYOUT_H
#define XW_LAYOUT_H
#include "../../platform/xbox360/xsdk/visual_layout.h"
int xw_layout_page(const WebEnginePage *page, size_t scroll_pixels, WebVisualFrame *frame);
/* Dispatch an anchor's inline onclick handler; navigation_consumed is set for # links. */
int xw_layout_dispatch_link(const WebEnginePage *page, size_t page_link_index,
                            int *navigation_consumed);
#endif
