#ifndef X360BROWSER_VISUAL_RENDERER_H
#define X360BROWSER_VISUAL_RENDERER_H

#include <stddef.h>
#include <stdint.h>
#include "web_engine.h"

int web_visual_renderer_init(void);
size_t web_visual_renderer_draw(const WebEnginePage *page, size_t scroll_pixels, uint32_t screen_width, uint32_t screen_height);
/* Move focus among visible-page anchors; returns 1 if any link was selected.
 * content_y is the link's vertical position in unscrolled page coordinates. */
int web_visual_renderer_move_link_focus(int direction, size_t *page_link_index, size_t *content_y);
int web_visual_renderer_get_focused_link(size_t *page_link_index, size_t *content_y);
/* Dispatch the focused link handler and invalidate the uploaded surface after DOM changes. */
int web_visual_renderer_dispatch_link(const WebEnginePage *page, size_t page_link_index,
                                      int *navigation_consumed);
void web_visual_renderer_shutdown(void);

#endif
