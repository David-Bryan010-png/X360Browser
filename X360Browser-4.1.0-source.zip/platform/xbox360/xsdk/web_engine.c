#include "web_engine.h"

#include <curl/curl.h>
#include <ctype.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>

#define WEB_ENGINE_MAX_HTML (4U * 1024U * 1024U)
#define WEB_ENGINE_MAX_VIDEO (512U * 1024U * 1024U)
#define WEB_ENGINE_MAX_IMAGE (1024U * 1024U)
#define WEB_ENGINE_RASTER_MAX_ATTEMPTS 6U
#define WEB_ENGINE_MAX_HLS_MANIFEST (128U * 1024U)
#define WEB_ENGINE_MAX_HLS_SEGMENTS 256U
#define HTML_ATTR_CAP 2048U

static int starts_nocase(const char *text, const char *prefix);
static int contains_nocase(const char *text, const char *needle);
static int url_has_suffix(const char *url, const char *suffix);

typedef struct {
    FILE *file;
    size_t bytes;
    int too_large;
} VideoFileSink;

static size_t receive_video_file(char *incoming, size_t unit_size, size_t count, void *user_data)
{
    VideoFileSink *sink = (VideoFileSink *)user_data;
    size_t bytes;
    size_t written;
    if (unit_size != 0U && count > SIZE_MAX / unit_size)
        return 0U;
    bytes = unit_size * count;
    if (sink->bytes > WEB_ENGINE_MAX_VIDEO || bytes > WEB_ENGINE_MAX_VIDEO - sink->bytes) {
        sink->too_large = 1;
        return 0U;
    }
    written = fwrite(incoming, 1U, bytes, sink->file);
    sink->bytes += written;
    return written;
}

typedef struct {
    FILE *file;
    size_t bytes;
    int too_large;
    int rejected;
    char content_type[WEB_ENGINE_CONTENT_TYPE_CAP];
} RasterSink;

static int supported_raster_mime(const char *mime)
{
    return mime != NULL &&
        (starts_nocase(mime, "image/qoi") || starts_nocase(mime, "image/x-qoi") ||
         starts_nocase(mime, "image/png") || starts_nocase(mime, "image/jpeg") ||
         starts_nocase(mime, "image/jpg") || starts_nocase(mime, "image/gif") ||
         starts_nocase(mime, "image/bmp") || starts_nocase(mime, "image/x-ms-bmp") ||
         starts_nocase(mime, "image/x-portable-anymap") ||
         starts_nocase(mime, "image/x-portable-pixmap"));
}

static size_t receive_raster_header(char *incoming, size_t unit_size, size_t count, void *user_data)
{
    RasterSink *sink = (RasterSink *)user_data;
    size_t bytes;
    const char *value;
    size_t length;
    if (unit_size != 0U && count > SIZE_MAX / unit_size) return 0U;
    bytes = unit_size * count;
    if (bytes == 0U) return 0U;
    if (bytes >= 5U && strncasecmp(incoming, "HTTP/", 5U) == 0) {
        sink->content_type[0] = '\0';
        sink->rejected = 0;
        return bytes;
    }
    if (bytes < 13U || strncasecmp(incoming, "Content-Type:", 13U) != 0) return bytes;
    value = incoming + 13U;
    while ((size_t)(value - incoming) < bytes && (*value == ' ' || *value == '\t')) ++value;
    length = bytes - (size_t)(value - incoming);
    while (length > 0U && (value[length - 1U] == '\r' || value[length - 1U] == '\n' ||
                           value[length - 1U] == ' ' || value[length - 1U] == '\t')) --length;
    if (length >= sizeof(sink->content_type)) length = sizeof(sink->content_type) - 1U;
    memcpy(sink->content_type, value, length);
    sink->content_type[length] = '\0';
    sink->rejected = !supported_raster_mime(sink->content_type);
    return bytes;
}

static size_t receive_raster(char *incoming, size_t unit_size, size_t count, void *user_data)
{
    RasterSink *sink = (RasterSink *)user_data;
    size_t bytes;
    size_t written;
    if (unit_size != 0U && count > SIZE_MAX / unit_size) return 0U;
    bytes = unit_size * count;
    if (bytes == 0U) return 0U;
    if (sink->rejected || !supported_raster_mime(sink->content_type)) {
        sink->rejected = 1;
        return 0U;
    }
    if (sink->bytes > WEB_ENGINE_MAX_IMAGE || bytes > WEB_ENGINE_MAX_IMAGE - sink->bytes) {
        sink->too_large = 1;
        return 0U;
    }
    written = fwrite(incoming, 1U, bytes, sink->file);
    sink->bytes += written;
    return written;
}

static int file_has_supported_raster_signature(const char *path)
{
    unsigned char header[16] = {0};
    FILE *file;
    size_t got;
    int valid = 0;
    file = fopen(path, "rb");
    if (file == NULL) return 0;
    got = fread(header, 1U, sizeof(header), file);
    (void)fclose(file);
    if (got >= 4U && memcmp(header, "qoif", 4U) == 0) valid = 1;
    if (got >= 8U && header[0] == 137U && header[1] == 80U && header[2] == 78U && header[3] == 71U &&
        header[4] == 13U && header[5] == 10U && header[6] == 26U && header[7] == 10U) valid = 1;
    if (got >= 3U && header[0] == 0xFFU && header[1] == 0xD8U && header[2] == 0xFFU) valid = 1;
    if (got >= 6U && (memcmp(header, "GIF87a", 6U) == 0 || memcmp(header, "GIF89a", 6U) == 0)) valid = 1;
    if (got >= 2U && header[0] == 'B' && header[1] == 'M') valid = 1;
    if (got >= 2U && header[0] == 'P' && (header[1] == '3' || header[1] == '6')) valid = 1;
    return valid;
}

static int image_is_unsupported_raster(const char *url)
{
    static const char *const suffixes[] = {".webp", ".svg", ".ico", ".avif", ".jxl", ".tif", ".tiff"};
    size_t i;
    for (i = 0U; i < sizeof(suffixes) / sizeof(suffixes[0]); ++i)
        if (url_has_suffix(url, suffixes[i])) return 1;
    return 0;
}

static int image_is_metadata_candidate(const WebEngineImage *image)
{
    return contains_nocase(image->alt, "site icon") ||
           contains_nocase(image->alt, "social preview") ||
           contains_nocase(image->alt, "responsive image") ||
           contains_nocase(image->alt, "lazy image") ||
           contains_nocase(image->alt, "css background") ||
           contains_nocase(image->alt, "logo") ||
           contains_nocase(image->alt, "avatar") ||
           contains_nocase(image->alt, "tracking") ||
           contains_nocase(image->alt, "pixel");
}

static int download_raster_image(WebEngineImage *image, size_t image_index)
{
    CURL *curl;
    CURLcode result;
    RasterSink sink;
    char path[WEB_ENGINE_IMAGE_CACHE_PATH_CAP];
    uint32_t url_hash = 2166136261U;
    const char *url_cursor;
    long status_code = 0L;
    int valid;
    if (image == NULL || image->url[0] == '\0' ||
        (!starts_nocase(image->url, "http://") && !starts_nocase(image->url, "https://")) ||
        image_is_unsupported_raster(image->url) || image_is_metadata_candidate(image)) return 0;
    (void)image_index;
    for (url_cursor = image->url; *url_cursor != '\0'; ++url_cursor) {
        url_hash ^= (unsigned char)*url_cursor;
        url_hash *= 16777619U;
    }
    if (snprintf(path, sizeof(path), "X360Browser-cache-%08lX.img", (unsigned long)url_hash) < 0) return 0;
    (void)remove(path);
    memset(&sink, 0, sizeof(sink));
    sink.file = fopen(path, "wb");
    if (sink.file == NULL) return 0;
    curl = curl_easy_init();
    if (curl == NULL) {
        (void)fclose(sink.file);
        (void)remove(path);
        return 0;
    }
    (void)curl_easy_setopt(curl, CURLOPT_URL, image->url);
    (void)curl_easy_setopt(curl, CURLOPT_USERAGENT, "Mozilla/5.0 (Xbox 360; X360Browser/4.0.0) AppleWebKit/537.36 Safari/537.36");
    (void)curl_easy_setopt(curl, CURLOPT_NOSIGNAL, 1L);
    (void)curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, receive_raster);
    (void)curl_easy_setopt(curl, CURLOPT_WRITEDATA, &sink);
    (void)curl_easy_setopt(curl, CURLOPT_HEADERFUNCTION, receive_raster_header);
    (void)curl_easy_setopt(curl, CURLOPT_HEADERDATA, &sink);
    (void)curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1L);
    (void)curl_easy_setopt(curl, CURLOPT_MAXREDIRS, 4L);
    (void)curl_easy_setopt(curl, CURLOPT_CONNECTTIMEOUT, 4L);
    (void)curl_easy_setopt(curl, CURLOPT_TIMEOUT, 8L);
    (void)curl_easy_setopt(curl, CURLOPT_LOW_SPEED_LIMIT, 1L);
    (void)curl_easy_setopt(curl, CURLOPT_LOW_SPEED_TIME, 4L);
    (void)curl_easy_setopt(curl, CURLOPT_ACCEPT_ENCODING, "");
    (void)curl_easy_setopt(curl, CURLOPT_CAINFO, "cacert.pem");
    (void)curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 1L);
    (void)curl_easy_setopt(curl, CURLOPT_SSL_VERIFYHOST, 2L);
    (void)curl_easy_setopt(curl, CURLOPT_PROTOCOLS_STR, "http,https");
    (void)curl_easy_setopt(curl, CURLOPT_REDIR_PROTOCOLS_STR, "http,https");
    result = curl_easy_perform(curl);
    (void)curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &status_code);
    curl_easy_cleanup(curl);
    valid = result == CURLE_OK && status_code >= 200L && status_code < 300L &&
            !sink.too_large && !sink.rejected && sink.bytes >= 8U &&
            supported_raster_mime(sink.content_type);
    if (fclose(sink.file) != 0) valid = 0;
    if (valid) valid = file_has_supported_raster_signature(path);
    if (!valid) {
        (void)remove(path);
        return 0;
    }
    (void)snprintf(image->cache_path, sizeof(image->cache_path), "%s", path);
    return 1;
}

/* Fetch a few small raster images. Vector/modern formats remain honest placeholders. */
static void prefetch_raster_images(WebEnginePage *page)
{
    size_t index;
    size_t attempts = 0U;
    for (index = 0U; index < page->image_count && attempts < WEB_ENGINE_RASTER_MAX_ATTEMPTS; ++index) {
        WebEngineImage *image = &page->images[index];
        if (image->cache_path[0] != '\0' || image->url[0] == '\0' || image_is_metadata_candidate(image) ||
            image_is_unsupported_raster(image->url)) continue;
        ++attempts;
        (void)download_raster_image(image, index);
    }
}

typedef struct {
    char *data;
    size_t length;
    size_t capacity;
    int too_large;
    int direct_resource;
    char content_type[WEB_ENGINE_CONTENT_TYPE_CAP];
} HtmlBuffer;

static size_t receive_html(char *incoming, size_t unit_size, size_t count, void *user_data)
{
    HtmlBuffer *buffer = (HtmlBuffer *)user_data;
    size_t bytes;
    size_t required;
    size_t next_capacity;
    char *next;

    if (unit_size != 0U && count > SIZE_MAX / unit_size)
        return 0U;
    bytes = unit_size * count;
    if (bytes == 0U)
        return 0U;
    /* Do not waste console RAM downloading image/video payloads into the HTML buffer. */
    if (buffer->direct_resource)
        return 0U;
    if (bytes > WEB_ENGINE_MAX_HTML - buffer->length) {
        buffer->too_large = 1;
        return 0U;
    }

    required = buffer->length + bytes + 1U;
    if (required > buffer->capacity) {
        next_capacity = buffer->capacity == 0U ? 8192U : buffer->capacity;
        while (next_capacity < required) {
            if (next_capacity > WEB_ENGINE_MAX_HTML / 2U) {
                next_capacity = WEB_ENGINE_MAX_HTML + 1U;
                break;
            }
            next_capacity *= 2U;
        }
        if (next_capacity > WEB_ENGINE_MAX_HTML + 1U)
            next_capacity = WEB_ENGINE_MAX_HTML + 1U;
        next = (char *)realloc(buffer->data, next_capacity);
        if (next == NULL)
            return 0U;
        buffer->data = next;
        buffer->capacity = next_capacity;
    }

    memcpy(buffer->data + buffer->length, incoming, bytes);
    buffer->length += bytes;
    buffer->data[buffer->length] = '\0';
    return bytes;
}

static size_t receive_header(char *incoming, size_t unit_size, size_t count, void *user_data)
{
    HtmlBuffer *buffer = (HtmlBuffer *)user_data;
    size_t bytes;
    const char *value;
    size_t length;
    if (unit_size != 0U && count > SIZE_MAX / unit_size)
        return 0U;
    bytes = unit_size * count;
    if (bytes == 0U)
        return 0U;
    if (bytes < 13U || strncasecmp(incoming, "Content-Type:", 13U) != 0)
        return bytes;
    value = incoming + 13U;
    while ((size_t)(value - incoming) < bytes && (*value == ' ' || *value == '\t'))
        ++value;
    length = bytes - (size_t)(value - incoming);
    while (length > 0U && (value[length - 1U] == '\r' || value[length - 1U] == '\n' ||
                           value[length - 1U] == ' ' || value[length - 1U] == '\t'))
        --length;
    if (length >= sizeof(buffer->content_type))
        length = sizeof(buffer->content_type) - 1U;
    memcpy(buffer->content_type, value, length);
    buffer->content_type[length] = '\0';
    /* Redirects can change MIME type; do not carry an earlier response's flag forward. */
    buffer->direct_resource = buffer->content_type[0] != '\0' &&
        strncasecmp(buffer->content_type, "text/html", 9U) != 0 &&
        strncasecmp(buffer->content_type, "application/xhtml+xml", 21U) != 0 &&
        strncasecmp(buffer->content_type, "text/plain", 10U) != 0;
    return bytes;
}

static int ascii_equal_nocase(char left, char right)
{
    return tolower((unsigned char)left) == tolower((unsigned char)right);
}

static int starts_nocase(const char *text, const char *prefix)
{
    while (*prefix != '\0') {
        if (*text == '\0' || !ascii_equal_nocase(*text, *prefix))
            return 0;
        ++text;
        ++prefix;
    }
    return 1;
}

static const char *find_nocase(const char *text, const char *needle)
{
    const char *candidate;
    if (text == NULL || needle == NULL || *needle == '\0')
        return NULL;
    for (candidate = text; *candidate != '\0'; ++candidate) {
        if (starts_nocase(candidate, needle))
            return candidate;
    }
    return NULL;
}

static void set_error(char *error, size_t capacity, const char *message)
{
    if (error == NULL || capacity == 0U)
        return;
    (void)snprintf(error, capacity, "%s", message != NULL ? message : "Unknown error");
}

static void append_utf8(char *destination, size_t capacity, size_t *length, unsigned int codepoint)
{
    char encoded[4];
    size_t count = 0U;

    if (capacity == 0U || *length >= capacity - 1U)
        return;
    if (codepoint == 0U || (codepoint < 0x20U && codepoint != '\n' && codepoint != '\t'))
        codepoint = '?';
    if (codepoint <= 0x7FU) {
        encoded[count++] = (char)codepoint;
    } else if (codepoint <= 0x7FFU) {
        encoded[count++] = (char)(0xC0U | (codepoint >> 6U));
        encoded[count++] = (char)(0x80U | (codepoint & 0x3FU));
    } else if (codepoint <= 0xFFFFU) {
        encoded[count++] = (char)(0xE0U | (codepoint >> 12U));
        encoded[count++] = (char)(0x80U | ((codepoint >> 6U) & 0x3FU));
        encoded[count++] = (char)(0x80U | (codepoint & 0x3FU));
    } else if (codepoint <= 0x10FFFFU) {
        encoded[count++] = (char)(0xF0U | (codepoint >> 18U));
        encoded[count++] = (char)(0x80U | ((codepoint >> 12U) & 0x3FU));
        encoded[count++] = (char)(0x80U | ((codepoint >> 6U) & 0x3FU));
        encoded[count++] = (char)(0x80U | (codepoint & 0x3FU));
    }
    if (*length + count >= capacity)
        return;
    memcpy(destination + *length, encoded, count);
    *length += count;
    destination[*length] = '\0';
}

static unsigned int decode_entity(const char *entity, size_t length)
{
    size_t i;
    unsigned int value = 0U;
    unsigned int base = 10U;

    if (length == 0U)
        return 0U;
    if (entity[0] == '#') {
        i = 1U;
        if (i < length && (entity[i] == 'x' || entity[i] == 'X')) {
            base = 16U;
            ++i;
        }
        if (i == length)
            return 0U;
        for (; i < length; ++i) {
            unsigned int digit;
            unsigned char c = (unsigned char)entity[i];
            if (c >= '0' && c <= '9')
                digit = (unsigned int)(c - '0');
            else if (base == 16U && c >= 'a' && c <= 'f')
                digit = (unsigned int)(c - 'a' + 10);
            else if (base == 16U && c >= 'A' && c <= 'F')
                digit = (unsigned int)(c - 'A' + 10);
            else
                return 0U;
            if (digit >= base || value > (0x10FFFFU - digit) / base)
                return 0U;
            value = value * base + digit;
        }
        return value <= 0x10FFFFU ? value : 0U;
    }
    if (length == 3U && memcmp(entity, "amp", 3U) == 0) return '&';
    if (length == 2U && memcmp(entity, "lt", 2U) == 0) return '<';
    if (length == 2U && memcmp(entity, "gt", 2U) == 0) return '>';
    if (length == 4U && memcmp(entity, "quot", 4U) == 0) return '"';
    if (length == 4U && memcmp(entity, "apos", 4U) == 0) return '\'';
    if (length == 4U && memcmp(entity, "nbsp", 4U) == 0) return ' ';
    if (length == 5U && memcmp(entity, "mdash", 5U) == 0) return 0x2014U;
    if (length == 5U && memcmp(entity, "ndash", 5U) == 0) return 0x2013U;
    if (length == 6U && memcmp(entity, "hellip", 6U) == 0) return 0x2026U;
    if (length == 4U && memcmp(entity, "copy", 4U) == 0) return 0x00A9U;
    return 0U;
}

static void append_normalized(char *destination, size_t capacity, size_t *length,
                              unsigned int codepoint, int keep_newline)
{
    if (codepoint == '\r')
        return;
    if (codepoint == '\n' && keep_newline) {
        if (*length > 0U && destination[*length - 1U] != '\n' && *length < capacity - 1U) {
            destination[(*length)++] = '\n';
            destination[*length] = '\0';
        }
        return;
    }
    if (codepoint == '\t' || codepoint == '\n' || codepoint == ' ')
        codepoint = ' ';
    if (codepoint == ' ') {
        if (*length == 0U || destination[*length - 1U] == ' ' || destination[*length - 1U] == '\n')
            return;
    }
    append_utf8(destination, capacity, length, codepoint);
}

static void append_decoded_text(WebEnginePage *page, const char *text, size_t bytes,
                                int in_title, int active_link)
{
    size_t i = 0U;
    while (i < bytes) {
        unsigned int codepoint = (unsigned char)text[i];
        if (text[i] == '&') {
            size_t end = i + 1U;
            while (end < bytes && end - i <= 12U && text[end] != ';' &&
                   text[end] != '<' && !isspace((unsigned char)text[end]))
                ++end;
            if (end < bytes && text[end] == ';' && end > i + 1U) {
                unsigned int decoded = decode_entity(text + i + 1U, end - i - 1U);
                if (decoded != 0U) {
                    codepoint = decoded;
                    i = end + 1U;
                } else {
                    ++i;
                }
            } else {
                ++i;
            }
        } else if ((codepoint & 0xE0U) == 0xC0U && i + 1U < bytes &&
                   (((unsigned char)text[i + 1U]) & 0xC0U) == 0x80U) {
            codepoint = ((codepoint & 0x1FU) << 6U) | (((unsigned char)text[i + 1U]) & 0x3FU);
            i += 2U;
        } else if ((codepoint & 0xF0U) == 0xE0U && i + 2U < bytes &&
                   (((unsigned char)text[i + 1U]) & 0xC0U) == 0x80U &&
                   (((unsigned char)text[i + 2U]) & 0xC0U) == 0x80U) {
            codepoint = ((codepoint & 0x0FU) << 12U) |
                        ((((unsigned char)text[i + 1U]) & 0x3FU) << 6U) |
                        (((unsigned char)text[i + 2U]) & 0x3FU);
            i += 3U;
        } else if ((codepoint & 0xF8U) == 0xF0U && i + 3U < bytes &&
                   (((unsigned char)text[i + 1U]) & 0xC0U) == 0x80U &&
                   (((unsigned char)text[i + 2U]) & 0xC0U) == 0x80U &&
                   (((unsigned char)text[i + 3U]) & 0xC0U) == 0x80U) {
            codepoint = ((codepoint & 0x07U) << 18U) |
                        ((((unsigned char)text[i + 1U]) & 0x3FU) << 12U) |
                        ((((unsigned char)text[i + 2U]) & 0x3FU) << 6U) |
                        (((unsigned char)text[i + 3U]) & 0x3FU);
            i += 4U;
        } else {
            ++i;
        }

        if (in_title) {
            size_t title_length = strlen(page->title);
            append_normalized(page->title, sizeof(page->title), &title_length, codepoint, 0);
        } else {
            append_normalized(page->text, sizeof(page->text), &page->text_length, codepoint, 0);
            if (active_link >= 0 && (size_t)active_link < page->link_count) {
                WebEngineLink *link = &page->links[(size_t)active_link];
                size_t label_length = strlen(link->label);
                append_normalized(link->label, sizeof(link->label), &label_length, codepoint, 0);
            }
        }
    }
}

static void append_line_break(WebEnginePage *page)
{
    if (page->text_length == 0U)
        return;
    if (page->text[page->text_length - 1U] != '\n' && page->text_length < sizeof(page->text) - 1U) {
        page->text[page->text_length++] = '\n';
        page->text[page->text_length] = '\0';
    }
}

static int is_block_tag(const char *name)
{
    static const char *const block_tags[] = {
        "address", "article", "aside", "blockquote", "br", "dd", "div", "dl", "dt",
        "fieldset", "figcaption", "figure", "footer", "form", "h1", "h2", "h3", "h4",
        "h5", "h6", "header", "hr", "li", "main", "nav", "ol", "p", "pre", "section",
        "table", "tr", "ul"
    };
    size_t i;
    for (i = 0U; i < sizeof(block_tags) / sizeof(block_tags[0]); ++i) {
        if (strcmp(name, block_tags[i]) == 0)
            return 1;
    }
    return 0;
}

static void decode_attribute_entities(char *value, size_t capacity)
{
    size_t read_pos = 0U;
    size_t write_pos = 0U;
    size_t length;
    if (value == NULL || capacity == 0U) return;
    length = strlen(value);
    while (read_pos < length && write_pos + 1U < capacity) {
        if (value[read_pos] == '&') {
            size_t end = read_pos + 1U;
            while (end < length && end - read_pos <= 12U && value[end] != ';' &&
                   value[end] != '<' && !isspace((unsigned char)value[end])) ++end;
            if (end < length && value[end] == ';' && end > read_pos + 1U) {
                unsigned int cp = decode_entity(value + read_pos + 1U, end - read_pos - 1U);
                if (cp != 0U) {
                    char encoded[4];
                    size_t n = 0U;
                    if (cp <= 0x7FU) encoded[n++] = (char)cp;
                    else if (cp <= 0x7FFU) { encoded[n++] = (char)(0xC0U | (cp >> 6U)); encoded[n++] = (char)(0x80U | (cp & 0x3FU)); }
                    else if (cp <= 0xFFFFU) { encoded[n++] = (char)(0xE0U | (cp >> 12U)); encoded[n++] = (char)(0x80U | ((cp >> 6U) & 0x3FU)); encoded[n++] = (char)(0x80U | (cp & 0x3FU)); }
                    else { encoded[n++] = (char)(0xF0U | (cp >> 18U)); encoded[n++] = (char)(0x80U | ((cp >> 12U) & 0x3FU)); encoded[n++] = (char)(0x80U | ((cp >> 6U) & 0x3FU)); encoded[n++] = (char)(0x80U | (cp & 0x3FU)); }
                    if (write_pos + n >= capacity) break;
                    memmove(value + write_pos + n, value + end + 1U, length - end);
                    memcpy(value + write_pos, encoded, n);
                    length = length - (end + 1U - read_pos) + (write_pos - read_pos) + n;
                    write_pos += n;
                    read_pos = write_pos;
                    continue;
                }
            }
        }
        value[write_pos++] = value[read_pos++];
    }
    value[write_pos] = '\0';
}

static int copy_attribute(const char *tag, size_t length, const char *wanted,
                          char *out, size_t out_capacity)
{
    size_t i = 0U;
    size_t wanted_length = strlen(wanted);
    while (i < length && !isspace((unsigned char)tag[i]) && tag[i] != '/')
        ++i;
    while (i < length) {
        size_t name_start;
        size_t name_length;
        size_t value_start;
        size_t value_length;
        char quote = '\0';
        while (i < length && (isspace((unsigned char)tag[i]) || tag[i] == '/'))
            ++i;
        name_start = i;
        while (i < length && !isspace((unsigned char)tag[i]) && tag[i] != '=' && tag[i] != '/')
            ++i;
        name_length = i - name_start;
        if (name_length == 0U) {
            if (i < length) ++i;
            continue;
        }
        while (i < length && isspace((unsigned char)tag[i])) ++i;
        if (i >= length || tag[i] != '=')
            continue;
        ++i;
        while (i < length && isspace((unsigned char)tag[i])) ++i;
        if (i < length && (tag[i] == '\'' || tag[i] == '"')) {
            quote = tag[i++];
            value_start = i;
            while (i < length && tag[i] != quote) ++i;
            value_length = i - value_start;
            if (i < length) ++i;
        } else {
            value_start = i;
            while (i < length && !isspace((unsigned char)tag[i]) && tag[i] != '>') ++i;
            value_length = i - value_start;
        }
        if (name_length == wanted_length &&
            strncasecmp(tag + name_start, wanted, wanted_length) == 0) {
            size_t copy_length = value_length < out_capacity - 1U ? value_length : out_capacity - 1U;
            memcpy(out, tag + value_start, copy_length);
            out[copy_length] = '\0';
            decode_attribute_entities(out, out_capacity);
            return 1;
        }
    }
    out[0] = '\0';
    return 0;
}

static void resolve_link_url(const char *base, const char *href,
                             char *out, size_t out_capacity)
{
    const char *scheme_end;
    const char *host_end;
    const char *last_slash;
    size_t origin_length;
    size_t base_directory_length;
    size_t scheme_length;

    if (out_capacity == 0U)
        return;
    out[0] = '\0';
    if (href == NULL || href[0] == '\0' || href[0] == '#')
        return;
    if (starts_nocase(href, "javascript:") || starts_nocase(href, "mailto:") ||
        starts_nocase(href, "data:"))
        return;
    if (starts_nocase(href, "http://") || starts_nocase(href, "https://")) {
        (void)snprintf(out, out_capacity, "%s", href);
        return;
    }
    scheme_end = strstr(base, "://");
    if (scheme_end == NULL) {
        (void)snprintf(out, out_capacity, "%s", href);
        return;
    }
    scheme_length = (size_t)(scheme_end - base);
    if (starts_nocase(href, "//")) {
        (void)snprintf(out, out_capacity, "%.*s:%s", (int)scheme_length, base, href);
        return;
    }
    host_end = strchr(scheme_end + 3, '/');
    origin_length = host_end == NULL ? strlen(base) : (size_t)(host_end - base);
    if (href[0] == '/') {
        (void)snprintf(out, out_capacity, "%.*s%s", (int)origin_length, base, href);
        return;
    }
    last_slash = strrchr(base, '/');
    if (last_slash == NULL || last_slash < scheme_end + 3) {
        base_directory_length = strlen(base);
        (void)snprintf(out, out_capacity, "%.*s/%s", (int)base_directory_length, base, href);
    } else {
        base_directory_length = (size_t)(last_slash - base + 1);
        (void)snprintf(out, out_capacity, "%.*s%s", (int)base_directory_length, base, href);
    }
}

/* Fragment-only anchors remain local links so the visual renderer can dispatch
 * inline handlers before the browser considers navigation. Resource resolvers
 * intentionally continue to ignore fragment-only URLs. */
static void resolve_anchor_url(const char *base, const char *href,
                               char *out, size_t out_capacity)
{
    const char *fragment;
    size_t base_length;
    size_t href_length;

    if (out_capacity == 0U)
        return;
    out[0] = '\0';
    if (base == NULL || href == NULL || href[0] == '\0')
        return;
    if (href[0] != '#') {
        resolve_link_url(base, href, out, out_capacity);
        return;
    }
    fragment = strchr(base, '#');
    base_length = fragment != NULL ? (size_t)(fragment - base) : strlen(base);
    href_length = strlen(href);
    if (base_length >= out_capacity)
        base_length = out_capacity - 1U;
    memcpy(out, base, base_length);
    out[base_length] = '\0';
    if (href_length > out_capacity - base_length - 1U)
        href_length = out_capacity - base_length - 1U;
    memcpy(out + base_length, href, href_length);
    out[base_length + href_length] = '\0';
}

static int contains_nocase(const char *text, const char *needle)
{
    return text != NULL && needle != NULL && find_nocase(text, needle) != NULL;
}

static int url_has_suffix(const char *url, const char *suffix)
{
    const char *query;
    const char *fragment;
    const char *end;
    size_t url_length;
    size_t suffix_length;
    if (url == NULL || suffix == NULL)
        return 0;
    query = strchr(url, '?');
    fragment = strchr(url, '#');
    end = url + strlen(url);
    if (query != NULL && query < end) end = query;
    if (fragment != NULL && fragment < end) end = fragment;
    url_length = (size_t)(end - url);
    suffix_length = strlen(suffix);
    return url_length >= suffix_length &&
           strncasecmp(end - suffix_length, suffix, suffix_length) == 0;
}

static unsigned int parse_dimension(const char *value)
{
    unsigned long parsed;
    char *end = NULL;
    if (value == NULL || value[0] == '\0')
        return 0U;
    parsed = strtoul(value, &end, 10);
    if (end == value || (*end != '\0' && *end != 'p' && *end != '%') || parsed > 8192UL)
        return 0U;
    return (unsigned int)parsed;
}

static void add_page_image(WebEnginePage *page, const char *base_url,
                           const char *raw_url, const char *alt,
                           unsigned int width, unsigned int height)
{
    char resolved[WEB_ENGINE_RESOURCE_URL_CAP];
    size_t i;
    if (raw_url == NULL || raw_url[0] == '\0' || page->image_count >= WEB_ENGINE_IMAGE_COUNT)
        return;
    resolve_link_url(base_url, raw_url, resolved, sizeof(resolved));
    if (resolved[0] == '\0')
        return;
    for (i = 0U; i < page->image_count; ++i) {
        if (strcmp(page->images[i].url, resolved) == 0)
            return;
    }
    {
        WebEngineImage *image = &page->images[page->image_count++];
        (void)snprintf(image->url, sizeof(image->url), "%s", resolved);
        (void)snprintf(image->alt, sizeof(image->alt), "%s",
                       alt != NULL && alt[0] != '\0' ? alt : "Image without alt text");
        image->width = width;
        image->height = height;
    }
}

static void add_embedded_navigation_link(WebEnginePage *page, const char *base_url,
                                         const char *raw_url)
{
    char resolved[WEB_ENGINE_LINK_URL_CAP];
    size_t i;
    WebEngineLink *link;
    if (page == NULL || raw_url == NULL || raw_url[0] == '\0' ||
        page->link_count >= WEB_ENGINE_LINK_COUNT) return;
    resolve_link_url(base_url, raw_url, resolved, sizeof(resolved));
    if (resolved[0] == '\0') return;
    for (i = 0U; i < page->link_count; ++i) {
        if (strcmp(page->links[i].url, resolved) == 0) return;
    }
    link = &page->links[page->link_count++];
    (void)snprintf(link->url, sizeof(link->url), "%s", resolved);
    (void)snprintf(link->label, sizeof(link->label), "Embedded content: %.76s", resolved);
    link->is_video = 0;
    link->is_audio = 0;
}

static void add_page_media(WebEnginePage *page, const char *base_url,
                           const char *raw_url, const char *kind,
                           const char *mime_type)
{
    char resolved[WEB_ENGINE_RESOURCE_URL_CAP];
    size_t i;
    if (raw_url == NULL || raw_url[0] == '\0' || page->media_count >= WEB_ENGINE_MEDIA_COUNT)
        return;
    resolve_link_url(base_url, raw_url, resolved, sizeof(resolved));
    if (resolved[0] == '\0')
        return;
    for (i = 0U; i < page->media_count; ++i) {
        if (strcmp(page->media[i].url, resolved) == 0)
            return;
    }
    {
        WebEngineMedia *media = &page->media[page->media_count++];
        (void)snprintf(media->url, sizeof(media->url), "%s", resolved);
        (void)snprintf(media->kind, sizeof(media->kind), "%s",
                       kind != NULL && kind[0] != '\0' ? kind : "media");
        (void)snprintf(media->mime_type, sizeof(media->mime_type), "%s",
                       mime_type != NULL && mime_type[0] != '\0' ? mime_type : "unknown/type");
    }
}

static int is_dash_url_or_type(const char *url, const char *mime_type)
{
    return (url != NULL && url_has_suffix(url, ".mpd")) ||
           (mime_type != NULL && contains_nocase(mime_type, "dash+xml"));
}

static int is_manifest_url_or_type(const char *url, const char *mime_type)
{
    return (url != NULL && (url_has_suffix(url, ".m3u8") || url_has_suffix(url, ".mpd"))) ||
           (mime_type != NULL && (contains_nocase(mime_type, "mpegurl") || contains_nocase(mime_type, "dash+xml")));
}

static void add_media_link(WebEnginePage *page, const char *base_url,
                           const char *raw_url, const char *label,
                           const char *mime_type, const char *kind)
{
    char resolved[WEB_ENGINE_LINK_URL_CAP];
    size_t i;
    int audio = kind != NULL && strcmp(kind, "audio") == 0;
    const char *prefix = audio ? "AUDIO" : "VIDEO";
    if (raw_url == NULL || raw_url[0] == '\0' || page->link_count >= WEB_ENGINE_LINK_COUNT ||
        is_dash_url_or_type(raw_url, mime_type)) return;
    resolve_link_url(base_url, raw_url, resolved, sizeof(resolved));
    if (resolved[0] == '\0' || is_dash_url_or_type(resolved, mime_type)) return;
    for (i = 0U; i < page->link_count; ++i) {
        if (strcmp(page->links[i].url, resolved) == 0) {
            /* A URL can be discovered through both a media container and a source.
             * Preserve the strongest known media kind instead of duplicating it. */
            if (audio) page->links[i].is_audio = 1;
            else page->links[i].is_video = 1;
            return;
        }
    }
    (void)snprintf(page->links[page->link_count].url, sizeof(page->links[page->link_count].url), "%s", resolved);
    (void)snprintf(page->links[page->link_count].label, sizeof(page->links[page->link_count].label), "%s: %.94s", prefix,
                   label != NULL && label[0] != '\0' ? label : resolved);
    page->links[page->link_count].is_video = audio ? 0 : 1;
    page->links[page->link_count].is_audio = audio ? 1 : 0;
    ++page->link_count;
}

static void add_video_link(WebEnginePage *page, const char *base_url,
                           const char *raw_url, const char *label, const char *mime_type)
{
    add_media_link(page, base_url, raw_url, label, mime_type, "video");
}

static void add_audio_link(WebEnginePage *page, const char *base_url,
                           const char *raw_url, const char *label, const char *mime_type)
{
    add_media_link(page, base_url, raw_url, label, mime_type, "audio");
}

static const char *guess_media_kind(const char *url, const char *mime_type)
{
    if (mime_type != NULL) {
        if (starts_nocase(mime_type, "video/")) return "video";
        if (starts_nocase(mime_type, "audio/")) return "audio";
        if (starts_nocase(mime_type, "image/")) return "image";
    }
    if (url != NULL && (url_has_suffix(url, ".mp4") || url_has_suffix(url, ".m4v") ||
        url_has_suffix(url, ".webm") || url_has_suffix(url, ".ogv") ||
        url_has_suffix(url, ".mov") || url_has_suffix(url, ".avi") ||
        url_has_suffix(url, ".mkv") || url_has_suffix(url, ".wmv") ||
        url_has_suffix(url, ".mpg") || url_has_suffix(url, ".mpeg") ||
        url_has_suffix(url, ".3gp") || url_has_suffix(url, ".3g2") ||
        url_has_suffix(url, ".m2ts") || url_has_suffix(url, ".mts") ||
        url_has_suffix(url, ".flv") || url_has_suffix(url, ".f4v") ||
        url_has_suffix(url, ".mxf") || url_has_suffix(url, ".ts") ||
        url_has_suffix(url, ".m3u8") || url_has_suffix(url, ".mpd"))) return "video";
    if (url != NULL && (url_has_suffix(url, ".mp3") || url_has_suffix(url, ".m4a") ||
        url_has_suffix(url, ".m4b") || url_has_suffix(url, ".aac") || url_has_suffix(url, ".ogg") ||
        url_has_suffix(url, ".oga") || url_has_suffix(url, ".opus") ||
        url_has_suffix(url, ".wav") || url_has_suffix(url, ".flac") ||
        url_has_suffix(url, ".aif") || url_has_suffix(url, ".aiff") ||
        url_has_suffix(url, ".wma") || url_has_suffix(url, ".amr") ||
        url_has_suffix(url, ".caf") || url_has_suffix(url, ".ac3") ||
        url_has_suffix(url, ".dts") || url_has_suffix(url, ".ape") ||
        url_has_suffix(url, ".au"))) return "audio";
    if (url != NULL && (url_has_suffix(url, ".png") || url_has_suffix(url, ".jpg") ||
        url_has_suffix(url, ".jpeg") || url_has_suffix(url, ".gif") ||
        url_has_suffix(url, ".webp") || url_has_suffix(url, ".bmp") ||
        url_has_suffix(url, ".svg") || url_has_suffix(url, ".avif"))) return "image";
    return NULL;
}

static void extract_srcset(WebEnginePage *page, const char *base_url,
                           const char *srcset, const char *label)
{
    const char *cursor = srcset;
    if (cursor == NULL)
        return;
    while (*cursor != '\0' && page->image_count < WEB_ENGINE_IMAGE_COUNT) {
        const char *candidate_start;
        const char *candidate_end;
        char candidate[HTML_ATTR_CAP];
        size_t length;
        while (*cursor == ',' || isspace((unsigned char)*cursor))
            ++cursor;
        if (*cursor == '\0')
            break;
        candidate_start = cursor;
        while (*cursor != '\0' && *cursor != ',' && !isspace((unsigned char)*cursor))
            ++cursor;
        candidate_end = cursor;
        length = (size_t)(candidate_end - candidate_start);
        if (length == 0U)
            continue;
        if (length >= sizeof(candidate))
            length = sizeof(candidate) - 1U;
        memcpy(candidate, candidate_start, length);
        candidate[length] = '\0';
        if (!starts_nocase(candidate, "data:"))
            add_page_image(page, base_url, candidate, label, 0U, 0U);
        while (*cursor != '\0' && *cursor != ',')
            ++cursor;
        if (*cursor == ',')
            ++cursor;
    }
}

static void extract_css_urls(WebEnginePage *page, const char *base_url, const char *css)
{
    const char *cursor = css;
    while (cursor != NULL && *cursor != '\0' && page->image_count < WEB_ENGINE_IMAGE_COUNT) {
        const char *start = find_nocase(cursor, "url(");
        const char *end;
        char raw[HTML_ATTR_CAP];
        const char *kind;
        size_t length;
        if (start == NULL)
            break;
        start += 4;
        while (*start != '\0' && isspace((unsigned char)*start))
            ++start;
        if (*start == '\'' || *start == '"') {
            char quote = *start++;
            end = strchr(start, quote);
            if (end == NULL)
                break;
        } else {
            end = strchr(start, ')');
            if (end == NULL)
                break;
            while (end > start && isspace((unsigned char)end[-1]))
                --end;
        }
        length = (size_t)(end - start);
        if (length == 0U) {
            cursor = end + 1;
            continue;
        }
        if (length >= sizeof(raw))
            length = sizeof(raw) - 1U;
        memcpy(raw, start, length);
        raw[length] = '\0';
        kind = guess_media_kind(raw, NULL);
        if (kind != NULL && strcmp(kind, "image") == 0 && !starts_nocase(raw, "data:"))
            add_page_image(page, base_url, raw, "CSS background image", 0U, 0U);
        cursor = end;
        while (*cursor != '\0' && *cursor != ')')
            ++cursor;
        if (*cursor == ')')
            ++cursor;
    }
}

static void append_image_alt(WebEnginePage *page, const char *alt, int active_link)
{
    static const char prefix[] = "[Image: ";
    static const char suffix[] = "]";
    size_t length;
    if (alt == NULL || alt[0] == '\0')
        return;
    append_decoded_text(page, prefix, sizeof(prefix) - 1U, 0, active_link);
    append_decoded_text(page, alt, strlen(alt), 0, active_link);
    append_decoded_text(page, suffix, sizeof(suffix) - 1U, 0, active_link);
    length = page->text_length;
    append_normalized(page->text, sizeof(page->text), &length, ' ', 0);
    page->text_length = length;
}

static void parse_html(const char *html, size_t html_length, const char *base_url,
                       WebEnginePage *page)
{
    size_t i = 0U;
    size_t visual_capacity = (sizeof(page->source_html) - 1U) * 3U / 4U;
    size_t copy_length = html_length < visual_capacity ? html_length : visual_capacity;
    memcpy(page->source_html, html, copy_length);
    page->source_html[copy_length] = '\0';
    page->source_html_length = copy_length;
    page->source_html_truncated = copy_length < html_length;
    int in_title = 0;
    int active_link = -1;
    int in_video = 0;
    int in_audio = 0;

    while (i < html_length && page->text_length < sizeof(page->text) - 8U) {
        if (html[i] != '<') {
            size_t start = i;
            while (i < html_length && html[i] != '<') ++i;
            append_decoded_text(page, html + start, i - start, in_title, active_link);
            continue;
        }
        if (i + 3U < html_length && memcmp(html + i, "<!--", 4U) == 0) {
            const char *end_comment = strstr(html + i + 4U, "-->");
            if (end_comment == NULL) break;
            i = (size_t)(end_comment - html) + 3U;
            continue;
        }
        {
            size_t tag_start = i + 1U;
            size_t tag_end = tag_start;
            size_t name_start;
            size_t name_end;
            size_t name_length;
            int closing = 0;
            char name[32];
            char href[HTML_ATTR_CAP];
            char *tag_copy;
            size_t tag_length;
            while (tag_end < html_length && html[tag_end] != '>' && tag_end - tag_start < 2048U)
                ++tag_end;
            if (tag_end >= html_length || html[tag_end] != '>') {
                ++i;
                continue;
            }
            tag_length = tag_end - tag_start;
            tag_copy = (char *)malloc(tag_length + 1U);
            if (tag_copy == NULL) break;
            memcpy(tag_copy, html + tag_start, tag_length);
            tag_copy[tag_length] = '\0';
            name_start = 0U;
            while (name_start < tag_length && isspace((unsigned char)tag_copy[name_start])) ++name_start;
            if (name_start < tag_length && tag_copy[name_start] == '/') {
                closing = 1;
                ++name_start;
            }
            while (name_start < tag_length && (tag_copy[name_start] == '!' || tag_copy[name_start] == '?'))
                ++name_start;
            name_end = name_start;
            while (name_end < tag_length && (isalnum((unsigned char)tag_copy[name_end]) ||
                   tag_copy[name_end] == '-')) ++name_end;
            name_length = name_end - name_start;
            if (name_length >= sizeof(name)) name_length = sizeof(name) - 1U;
            memcpy(name, tag_copy + name_start, name_length);
            name[name_length] = '\0';
            {
                size_t n;
                for (n = 0U; name[n] != '\0'; ++n) name[n] = (char)tolower((unsigned char)name[n]);
            }

            if (!closing) {
                char inline_style[HTML_ATTR_CAP];
                if (copy_attribute(tag_copy, tag_length, "style", inline_style, sizeof(inline_style)))
                    extract_css_urls(page, base_url, inline_style);
            }
            if (!closing && (strcmp(name, "script") == 0 || strcmp(name, "style") == 0)) {
                char close_tag[40];
                const char *close_position;
                if (strcmp(name, "script") == 0) {
                    char script_src[HTML_ATTR_CAP];
                    ++page->script_count;
                    (void)copy_attribute(tag_copy, tag_length, "src", script_src, sizeof(script_src));
                    if (script_src[0] != '\0')
                        add_page_media(page, base_url, script_src, "script", "application/javascript");
                }
                (void)snprintf(close_tag, sizeof(close_tag), "</%s", name);
                close_position = find_nocase(html + tag_end + 1U, close_tag);
                if (close_position != NULL && strcmp(name, "style") == 0) {
                    size_t css_length = (size_t)(close_position - (html + tag_end + 1U));
                    char *css_text = (char *)malloc(css_length + 1U);
                    if (css_text != NULL) {
                        memcpy(css_text, html + tag_end + 1U, css_length);
                        css_text[css_length] = '\0';
                        extract_css_urls(page, base_url, css_text);
                        free(css_text);
                    }
                }
                free(tag_copy);
                if (close_position == NULL) break;
                i = (size_t)(close_position - html);
                continue;
            }
            if (strcmp(name, "video") == 0) {
                if (closing) {
                    in_video = 0;
                } else {
                    char src[HTML_ATTR_CAP];
                    char type[WEB_ENGINE_RESOURCE_TYPE_CAP];
                    char poster[HTML_ATTR_CAP];
                    in_video = 1;
                    (void)copy_attribute(tag_copy, tag_length, "src", src, sizeof(src));
                    (void)copy_attribute(tag_copy, tag_length, "type", type, sizeof(type));
                    (void)copy_attribute(tag_copy, tag_length, "poster", poster, sizeof(poster));
                    if (src[0] != '\0') {
                        add_page_media(page, base_url, src, "video", type);
                        add_video_link(page, base_url, src, "HTML video source", type);
                    }
                    if (poster[0] != '\0')
                        add_page_image(page, base_url, poster, "Video poster", 0U, 0U);
                }
            } else if (strcmp(name, "audio") == 0) {
                if (closing) {
                    in_audio = 0;
                } else {
                    char src[HTML_ATTR_CAP];
                    char type[WEB_ENGINE_RESOURCE_TYPE_CAP];
                    in_audio = 1;
                    (void)copy_attribute(tag_copy, tag_length, "src", src, sizeof(src));
                    (void)copy_attribute(tag_copy, tag_length, "type", type, sizeof(type));
                    if (src[0] != '\0') {
                        add_page_media(page, base_url, src, "audio", type);
                        add_audio_link(page, base_url, src, "HTML audio source", type);
                    }
                }
            } else if (!closing && strcmp(name, "img") == 0) {
                char src[HTML_ATTR_CAP];
                char alt[WEB_ENGINE_RESOURCE_LABEL_CAP];
                char width[32];
                char height[32];
                (void)copy_attribute(tag_copy, tag_length, "src", src, sizeof(src));
                char srcset[HTML_ATTR_CAP];
                if (src[0] == '\0')
                    (void)copy_attribute(tag_copy, tag_length, "data-src", src, sizeof(src));
                if (src[0] == '\0')
                    (void)copy_attribute(tag_copy, tag_length, "data-lazy-src", src, sizeof(src));
                if (src[0] == '\0')
                    (void)copy_attribute(tag_copy, tag_length, "data-original", src, sizeof(src));
                if (src[0] == '\0')
                    (void)copy_attribute(tag_copy, tag_length, "data-original-src", src, sizeof(src));
                if (src[0] == '\0')
                    (void)copy_attribute(tag_copy, tag_length, "data-src-large", src, sizeof(src));
                (void)copy_attribute(tag_copy, tag_length, "alt", alt, sizeof(alt));
                (void)copy_attribute(tag_copy, tag_length, "width", width, sizeof(width));
                (void)copy_attribute(tag_copy, tag_length, "height", height, sizeof(height));
                (void)copy_attribute(tag_copy, tag_length, "srcset", srcset, sizeof(srcset));
                if (src[0] == '\0' && srcset[0] != '\0') {
                    /* A responsive image may only specify srcset; keep the first viable candidate. */
                    const char *end = srcset;
                    size_t n;
                    while (*end != '\0' && *end != ',' && !isspace((unsigned char)*end)) ++end;
                    n = (size_t)(end - srcset);
                    if (n >= sizeof(src)) n = sizeof(src) - 1U;
                    memcpy(src, srcset, n);
                    src[n] = '\0';
                }
                add_page_image(page, base_url, src, alt, parse_dimension(width), parse_dimension(height));
                extract_srcset(page, base_url, srcset, "Responsive image candidate");
                {
                    char data_srcset[HTML_ATTR_CAP];
                    (void)copy_attribute(tag_copy, tag_length, "data-srcset", data_srcset, sizeof(data_srcset));
                    extract_srcset(page, base_url, data_srcset, "Lazy image candidate");
                    if (data_srcset[0] == '\0') {
                        (void)copy_attribute(tag_copy, tag_length, "data-lazy-srcset", data_srcset, sizeof(data_srcset));
                        extract_srcset(page, base_url, data_srcset, "Lazy responsive image candidate");
                    }
                }
                append_image_alt(page, alt, active_link);
            } else if (!closing && strcmp(name, "source") == 0) {
                char src[HTML_ATTR_CAP];
                char type[WEB_ENGINE_RESOURCE_TYPE_CAP];
                const char *kind;
                char srcset[HTML_ATTR_CAP];
                (void)copy_attribute(tag_copy, tag_length, "src", src, sizeof(src));
                (void)copy_attribute(tag_copy, tag_length, "srcset", srcset, sizeof(srcset));
                (void)copy_attribute(tag_copy, tag_length, "type", type, sizeof(type));
                kind = guess_media_kind(src, type);
                extract_srcset(page, base_url, srcset, "Responsive picture source");
                if (in_video || (kind != NULL && strcmp(kind, "video") == 0)) {
                    add_page_media(page, base_url, src, "video", type);
                    add_video_link(page, base_url, src, "HTML video source", type);
                }
                else if (in_audio || (kind != NULL && strcmp(kind, "audio") == 0)) {
                    add_page_media(page, base_url, src, "audio", type);
                    add_audio_link(page, base_url, src, "HTML audio source", type);
                }
                else if (kind != NULL && strcmp(kind, "image") == 0)
                    add_page_image(page, base_url, src, "Responsive image source", 0U, 0U);
            } else if (!closing && strcmp(name, "iframe") == 0) {
                char src[HTML_ATTR_CAP];
                (void)copy_attribute(tag_copy, tag_length, "src", src, sizeof(src));
                if (src[0] != '\0') {
                    ++page->iframe_count;
                    add_page_media(page, base_url, src, "embed", "text/html");
                    /* No nested browsing context yet: expose its URL as a normal,
                     * controller-focusable navigation target instead of a dead box. */
                    add_embedded_navigation_link(page, base_url, src);
                }
            } else if (!closing && strcmp(name, "form") == 0) {
                ++page->form_count;
            } else if (!closing && (strcmp(name, "h1") == 0 || strcmp(name, "h2") == 0 ||
                                   strcmp(name, "h3") == 0 || strcmp(name, "h4") == 0 ||
                                   strcmp(name, "h5") == 0 || strcmp(name, "h6") == 0)) {
                ++page->heading_count;
            } else if (!closing && strcmp(name, "link") == 0) {
                char rel[64];
                char link_href[HTML_ATTR_CAP];
                char mime[WEB_ENGINE_RESOURCE_TYPE_CAP];
                (void)copy_attribute(tag_copy, tag_length, "rel", rel, sizeof(rel));
                (void)copy_attribute(tag_copy, tag_length, "href", link_href, sizeof(link_href));
                (void)copy_attribute(tag_copy, tag_length, "type", mime, sizeof(mime));
                if (contains_nocase(rel, "stylesheet")) {
                    ++page->stylesheet_count;
                    add_page_media(page, base_url, link_href, "stylesheet",
                                   mime[0] != '\0' ? mime : "text/css");
                }
                if (contains_nocase(rel, "icon") || contains_nocase(rel, "apple-touch-icon"))
                    add_page_image(page, base_url, link_href, "Site icon", 0U, 0U);
            } else if (!closing && strcmp(name, "meta") == 0) {
                char meta_name[64];
                char property[64];
                char content[HTML_ATTR_CAP];
                (void)copy_attribute(tag_copy, tag_length, "name", meta_name, sizeof(meta_name));
                (void)copy_attribute(tag_copy, tag_length, "property", property, sizeof(property));
                (void)copy_attribute(tag_copy, tag_length, "content", content, sizeof(content));
                if (starts_nocase(meta_name, "description") && page->description[0] == '\0')
                    (void)snprintf(page->description, sizeof(page->description), "%.255s", content);
                if (starts_nocase(property, "og:image") || starts_nocase(meta_name, "twitter:image"))
                    add_page_image(page, base_url, content, "Social preview image", 0U, 0U);
                if (starts_nocase(property, "og:video") || starts_nocase(meta_name, "twitter:player"))
                    add_page_media(page, base_url, content, "video", "unknown/video");
            }
            if (strcmp(name, "title") == 0) {
                in_title = closing ? 0 : 1;
            } else if (strcmp(name, "a") == 0) {
                if (closing) {
                    active_link = -1;
                } else if (page->link_count < WEB_ENGINE_LINK_COUNT &&
                           copy_attribute(tag_copy, tag_length, "href", href, sizeof(href))) {
                    WebEngineLink *link = &page->links[page->link_count];
                    resolve_anchor_url(base_url, href, link->url, sizeof(link->url));
                    if (link->url[0] != '\0') {
                        link->label[0] = '\0';
                        link->is_video = 0;
                        active_link = (int)page->link_count;
                        ++page->link_count;
                    }
                }
            }
            if (is_block_tag(name)) append_line_break(page);
            free(tag_copy);
            i = tag_end + 1U;
        }
    }

    while (page->text_length > 0U &&
           (page->text[page->text_length - 1U] == ' ' || page->text[page->text_length - 1U] == '\n')) {
        page->text[--page->text_length] = '\0';
    }
    if (page->title[0] == '\0')
        (void)snprintf(page->title, sizeof(page->title), "Web page");
    {
        size_t j;
        for (j = 0U; j < page->link_count; ++j) {
            if (page->links[j].label[0] == '\0')
                (void)snprintf(page->links[j].label, sizeof(page->links[j].label), "Link %u", (unsigned)(j + 1U));
        }
    }
}


#define WEB_ENGINE_CSS_DOWNLOAD_CAP 98304U
#define WEB_ENGINE_CSS_MAX_SHEETS 12U
#define WEB_ENGINE_SCRIPT_DOWNLOAD_CAP 16384U
#define WEB_ENGINE_SCRIPT_MAX_EXTERNAL 4U
#define WEB_ENGINE_SCRIPT_TOTAL_CAP 32768U

typedef struct {
    char data[WEB_ENGINE_SCRIPT_DOWNLOAD_CAP + 1U];
    size_t length;
    int too_large;
    char content_type[WEB_ENGINE_CONTENT_TYPE_CAP];
} ScriptDownload;

static size_t receive_script(char *incoming, size_t unit_size, size_t count, void *user_data)
{
    ScriptDownload *script = (ScriptDownload *)user_data;
    size_t bytes;
    if (unit_size != 0U && count > SIZE_MAX / unit_size) return 0U;
    bytes = unit_size * count;
    if (bytes > WEB_ENGINE_SCRIPT_DOWNLOAD_CAP - script->length) {
        script->too_large = 1;
        return 0U;
    }
    memcpy(script->data + script->length, incoming, bytes);
    script->length += bytes;
    script->data[script->length] = '\0';
    return bytes;
}

static size_t receive_script_header(char *incoming, size_t unit_size, size_t count, void *user_data)
{
    ScriptDownload *script = (ScriptDownload *)user_data;
    size_t bytes;
    const char *value;
    size_t length;
    if (unit_size != 0U && count > SIZE_MAX / unit_size) return 0U;
    bytes = unit_size * count;
    if (bytes == 0U) return 0U;
    if (bytes >= 5U && strncasecmp(incoming, "HTTP/", 5U) == 0) {
        script->content_type[0] = '\0';
        return bytes;
    }
    if (bytes < 13U || strncasecmp(incoming, "Content-Type:", 13U) != 0) return bytes;
    value = incoming + 13U;
    while ((size_t)(value - incoming) < bytes && (*value == ' ' || *value == '\t')) ++value;
    length = bytes - (size_t)(value - incoming);
    while (length > 0U && (value[length - 1U] == '\r' || value[length - 1U] == '\n' ||
                           value[length - 1U] == ' ' || value[length - 1U] == '\t')) --length;
    if (length >= sizeof(script->content_type)) length = sizeof(script->content_type) - 1U;
    memcpy(script->content_type, value, length);
    script->content_type[length] = '\0';
    return bytes;
}

static int script_content_type_allowed(const char *content_type)
{
    char normalized[WEB_ENGINE_CONTENT_TYPE_CAP];
    size_t length = 0U;
    if (content_type == NULL) return 0;
    while (content_type[length] != '\0' && content_type[length] != ';' &&
           !isspace((unsigned char)content_type[length]) && length + 1U < sizeof(normalized)) {
        normalized[length] = content_type[length];
        ++length;
    }
    normalized[length] = '\0';
    return strcasecmp(normalized, "application/javascript") == 0 ||
           strcasecmp(normalized, "text/javascript") == 0 ||
           strcasecmp(normalized, "application/ecmascript") == 0 ||
           strcasecmp(normalized, "text/ecmascript") == 0 ||
           strcasecmp(normalized, "application/x-javascript") == 0;
}

/* Detect boolean HTML attributes without assuming every attribute has a value. */
static int tag_has_attribute(const char *tag, size_t length, const char *wanted)
{
    size_t i = 0U;
    size_t wanted_length = strlen(wanted);
    while (i < length && !isspace((unsigned char)tag[i]) && tag[i] != '/') ++i;
    while (i < length) {
        size_t name_start;
        size_t name_length;
        while (i < length && (isspace((unsigned char)tag[i]) || tag[i] == '/')) ++i;
        name_start = i;
        while (i < length && !isspace((unsigned char)tag[i]) && tag[i] != '=' && tag[i] != '/' && tag[i] != '>') ++i;
        name_length = i - name_start;
        if (name_length == 0U) {
            if (i < length) ++i;
            continue;
        }
        if (name_length == wanted_length && strncasecmp(tag + name_start, wanted, wanted_length) == 0)
            return 1;
        while (i < length && isspace((unsigned char)tag[i])) ++i;
        if (i < length && tag[i] == '=') {
            char quote;
            ++i;
            while (i < length && isspace((unsigned char)tag[i])) ++i;
            quote = i < length && (tag[i] == '\'' || tag[i] == '"') ? tag[i++] : '\0';
            if (quote != '\0') {
                while (i < length && tag[i] != quote) ++i;
                if (i < length) ++i;
            } else {
                while (i < length && !isspace((unsigned char)tag[i]) && tag[i] != '>') ++i;
            }
        }
    }
    return 0;
}

static int script_type_is_supported(const char *type)
{
    char normalized[64];
    size_t length;
    if (type == NULL || type[0] == '\0') return 1;
    length = strlen(type);
    if (length >= sizeof(normalized)) return 0;
    memcpy(normalized, type, length + 1U);
    {
        char *semicolon = strchr(normalized, ';');
        size_t i;
        if (semicolon != NULL) *semicolon = '\0';
        for (i = strlen(normalized); i > 0U && isspace((unsigned char)normalized[i - 1U]); --i)
            normalized[i - 1U] = '\0';
    }
    return strcasecmp(normalized, "text/javascript") == 0 ||
           strcasecmp(normalized, "application/javascript") == 0 ||
           strcasecmp(normalized, "text/ecmascript") == 0 ||
           strcasecmp(normalized, "application/ecmascript") == 0 ||
           strcasecmp(normalized, "application/x-javascript") == 0;
}

static int fetch_small_external_script(const char *url, const char *page_url,
                                       ScriptDownload *script)
{
    CURL *curl;
    CURLcode result;
    long status_code = 0L;
    char curl_error[CURL_ERROR_SIZE] = {0};
    char *effective_url = NULL;
    if (url == NULL || script == NULL || url[0] == '\0') return 0;
    memset(script, 0, sizeof(*script));
    curl = curl_easy_init();
    if (curl == NULL) return 0;
    (void)curl_easy_setopt(curl, CURLOPT_URL, url);
    (void)curl_easy_setopt(curl, CURLOPT_USERAGENT, "Mozilla/5.0 (Xbox 360; X360Browser/4.0.0) AppleWebKit/537.36 Safari/537.36");
    (void)curl_easy_setopt(curl, CURLOPT_ERRORBUFFER, curl_error);
    (void)curl_easy_setopt(curl, CURLOPT_NOSIGNAL, 1L);
    (void)curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, receive_script);
    (void)curl_easy_setopt(curl, CURLOPT_WRITEDATA, script);
    (void)curl_easy_setopt(curl, CURLOPT_HEADERFUNCTION, receive_script_header);
    (void)curl_easy_setopt(curl, CURLOPT_HEADERDATA, script);
    (void)curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1L);
    (void)curl_easy_setopt(curl, CURLOPT_MAXREDIRS, 3L);
    (void)curl_easy_setopt(curl, CURLOPT_CONNECTTIMEOUT, 3L);
    (void)curl_easy_setopt(curl, CURLOPT_TIMEOUT, 7L);
    (void)curl_easy_setopt(curl, CURLOPT_LOW_SPEED_LIMIT, 1L);
    (void)curl_easy_setopt(curl, CURLOPT_LOW_SPEED_TIME, 3L);
    (void)curl_easy_setopt(curl, CURLOPT_ACCEPT_ENCODING, "");
    (void)curl_easy_setopt(curl, CURLOPT_CAINFO, "cacert.pem");
    (void)curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 1L);
    (void)curl_easy_setopt(curl, CURLOPT_SSL_VERIFYHOST, 2L);
    (void)curl_easy_setopt(curl, CURLOPT_PROTOCOLS_STR, "http,https");
    (void)curl_easy_setopt(curl, CURLOPT_REDIR_PROTOCOLS_STR, "http,https");
    result = curl_easy_perform(curl);
    (void)curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &status_code);
    (void)curl_easy_getinfo(curl, CURLINFO_EFFECTIVE_URL, &effective_url);
    if (result == CURLE_OK && status_code >= 200L && status_code < 300L &&
        script->length > 0U && !script->too_large &&
        script_content_type_allowed(script->content_type) &&
        !(starts_nocase(page_url, "https://") && effective_url != NULL && starts_nocase(effective_url, "http://")) &&
        memchr(script->data, '\0', script->length) == NULL &&
        find_nocase(script->data, "</script") == NULL) {
        curl_easy_cleanup(curl);
        return 1;
    }
    curl_easy_cleanup(curl);
    return 0;
}

/* Fetch only small, synchronous external scripts and inline them at their original positions.
 * The XenonScript runtime remains sandboxed and only understands a bounded language subset. */
static void materialize_external_scripts(WebEnginePage *page)
{
    size_t original_length;
    char *original;
    char *rewritten;
    size_t input_scan = 0U;
    size_t copy_cursor = 0U;
    size_t output_length = 0U;
    size_t attempted_count = 0U;
    size_t total_script_bytes = 0U;
    int changed = 0;
    if (page == NULL) return;
    original_length = page->source_html_length;
    if (original_length == 0U || original_length >= sizeof(page->source_html)) return;
    original = (char *)malloc(original_length + 1U);
    rewritten = (char *)malloc(sizeof(page->source_html));
    if (original == NULL || rewritten == NULL) {
        free(original);
        free(rewritten);
        return;
    }
    memcpy(original, page->source_html, original_length + 1U);
    while (input_scan < original_length && attempted_count < WEB_ENGINE_SCRIPT_MAX_EXTERNAL &&
           total_script_bytes < WEB_ENGINE_SCRIPT_TOTAL_CAP) {
        const char *opening = find_nocase(original + input_scan, "<script");
        const char *tag_end;
        const char *closing;
        const char *closing_end;
        size_t opening_offset;
        size_t tag_length;
        size_t element_end;
        char quote = '\0';
        char src[WEB_ENGINE_RESOURCE_URL_CAP];
        char type[64];
        char resolved[WEB_ENGINE_RESOURCE_URL_CAP];
        int eligible = 0;
        ScriptDownload downloaded;
        if (opening == NULL) break;
        opening_offset = (size_t)(opening - original);
        if (opening_offset + 7U >= original_length ||
            !(isspace((unsigned char)original[opening_offset + 7U]) || original[opening_offset + 7U] == '>')) {
            input_scan = opening_offset + 1U;
            continue;
        }
        tag_end = opening + 7;
        while ((size_t)(tag_end - original) < original_length && *tag_end != '\0') {
            if (quote != '\0') {
                if (*tag_end == quote) quote = '\0';
            } else if (*tag_end == '\'' || *tag_end == '"') {
                quote = *tag_end;
            } else if (*tag_end == '>') {
                break;
            }
            ++tag_end;
        }
        if (*tag_end != '>') break;
        closing = find_nocase(tag_end + 1, "</script");
        if (closing == NULL) break;
        closing_end = strchr(closing, '>');
        if (closing_end == NULL) break;
        element_end = (size_t)(closing_end - original) + 1U;
        tag_length = (size_t)(tag_end - opening - 1);
        src[0] = '\0'; type[0] = '\0'; resolved[0] = '\0';
        (void)copy_attribute(opening + 1, tag_length, "src", src, sizeof(src));
        (void)copy_attribute(opening + 1, tag_length, "type", type, sizeof(type));
        eligible = src[0] != '\0' && script_type_is_supported(type) &&
                   !tag_has_attribute(opening + 1, tag_length, "async") &&
                   !tag_has_attribute(opening + 1, tag_length, "defer") &&
                   !tag_has_attribute(opening + 1, tag_length, "integrity") &&
                   !tag_has_attribute(opening + 1, tag_length, "nomodule");
        if (eligible) {
            resolve_link_url(page->page_url, src, resolved, sizeof(resolved));
            eligible = resolved[0] != '\0' &&
                       !(starts_nocase(page->page_url, "https://") && starts_nocase(resolved, "http://"));
        }
        if (eligible) ++attempted_count;
        if (eligible && fetch_small_external_script(resolved, page->page_url, &downloaded) &&
            downloaded.length <= WEB_ENGINE_SCRIPT_TOTAL_CAP - total_script_bytes) {
            const size_t prefix_length = opening_offset - copy_cursor;
            const size_t wrapper_length = sizeof("<script></script>") - 1U;
            const size_t needed = prefix_length + wrapper_length + downloaded.length;
            if (needed <= sizeof(page->source_html) - 1U - output_length) {
                memcpy(rewritten + output_length, original + copy_cursor, prefix_length);
                output_length += prefix_length;
                memcpy(rewritten + output_length, "<script>", sizeof("<script>") - 1U);
                output_length += sizeof("<script>") - 1U;
                memcpy(rewritten + output_length, downloaded.data, downloaded.length);
                output_length += downloaded.length;
                memcpy(rewritten + output_length, "</script>", sizeof("</script>") - 1U);
                output_length += sizeof("</script>") - 1U;
                copy_cursor = element_end;
                total_script_bytes += downloaded.length;
                changed = 1;
            }
        }
        input_scan = element_end;
    }
    if (changed) {
        const size_t tail_length = original_length - copy_cursor;
        if (tail_length <= sizeof(page->source_html) - 1U - output_length) {
            memcpy(rewritten + output_length, original + copy_cursor, tail_length);
            output_length += tail_length;
            rewritten[output_length] = '\0';
            memcpy(page->source_html, rewritten, output_length + 1U);
            page->source_html_length = output_length;
        }
    }
    free(rewritten);
    free(original);
}

typedef struct {
    char data[WEB_ENGINE_CSS_DOWNLOAD_CAP + 1U];
    size_t length;
    int too_large;
    char content_type[WEB_ENGINE_CONTENT_TYPE_CAP];
} CssDownload;

static size_t receive_css(char *incoming, size_t unit_size, size_t count, void *user_data)
{
    CssDownload *css = (CssDownload *)user_data;
    size_t bytes;
    if (unit_size != 0U && count > SIZE_MAX / unit_size) return 0U;
    bytes = unit_size * count;
    if (bytes > WEB_ENGINE_CSS_DOWNLOAD_CAP - css->length) {
        css->too_large = 1;
        return 0U;
    }
    memcpy(css->data + css->length, incoming, bytes);
    css->length += bytes;
    css->data[css->length] = '\0';
    return bytes;
}

static size_t receive_css_header(char *incoming, size_t unit_size, size_t count, void *user_data)
{
    CssDownload *css = (CssDownload *)user_data;
    size_t bytes;
    const char *value;
    size_t length;
    if (unit_size != 0U && count > SIZE_MAX / unit_size) return 0U;
    bytes = unit_size * count;
    if (bytes == 0U) return 0U;
    if (bytes >= 5U && strncasecmp(incoming, "HTTP/", 5U) == 0) {
        css->content_type[0] = '\0';
        return bytes;
    }
    if (bytes < 13U || strncasecmp(incoming, "Content-Type:", 13U) != 0) return bytes;
    value = incoming + 13U;
    while ((size_t)(value - incoming) < bytes && (*value == ' ' || *value == '\t')) ++value;
    length = bytes - (size_t)(value - incoming);
    while (length > 0U && (value[length - 1U] == '\r' || value[length - 1U] == '\n' ||
                           value[length - 1U] == ' ' || value[length - 1U] == '\t')) --length;
    if (length >= sizeof(css->content_type)) length = sizeof(css->content_type) - 1U;
    memcpy(css->content_type, value, length);
    css->content_type[length] = '\0';
    return bytes;
}

static int css_content_type_allowed(const char *content_type)
{
    char normalized[WEB_ENGINE_CONTENT_TYPE_CAP];
    size_t length = 0U;
    if (content_type == NULL || content_type[0] == '\0') return 0;
    while (content_type[length] != '\0' && content_type[length] != ';' &&
           !isspace((unsigned char)content_type[length]) && length + 1U < sizeof(normalized)) {
        normalized[length] = content_type[length];
        ++length;
    }
    normalized[length] = '\0';
    return strcasecmp(normalized, "text/css") == 0;
}

/* Fetch only a few small external stylesheets, with the same strict TLS and time bounds as the document request. */
static void append_external_stylesheets(WebEnginePage *page)
{
    size_t index;
    size_t fetched = 0U;
    for (index = 0U; index < page->media_count && fetched < WEB_ENGINE_CSS_MAX_SHEETS; ++index) {
        const WebEngineMedia *media = &page->media[index];
        CURL *curl;
        CURLcode result;
        long status_code = 0L;
        CssDownload css;
        size_t remaining;
        int written;
        if (strcmp(media->kind, "stylesheet") != 0 || media->url[0] == '\0') continue;
        /* Do not fetch active page styles through a plaintext downgrade. */
        if (starts_nocase(page->page_url, "https://") && starts_nocase(media->url, "http://")) continue;
        memset(&css, 0, sizeof(css));
        curl = curl_easy_init();
        if (curl == NULL) continue;
        (void)curl_easy_setopt(curl, CURLOPT_URL, media->url);
        (void)curl_easy_setopt(curl, CURLOPT_USERAGENT, "Mozilla/5.0 (Xbox 360; X360Browser/4.0.0) AppleWebKit/537.36 Safari/537.36");
        (void)curl_easy_setopt(curl, CURLOPT_NOSIGNAL, 1L);
        (void)curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, receive_css);
        (void)curl_easy_setopt(curl, CURLOPT_WRITEDATA, &css);
        (void)curl_easy_setopt(curl, CURLOPT_HEADERFUNCTION, receive_css_header);
        (void)curl_easy_setopt(curl, CURLOPT_HEADERDATA, &css);
        (void)curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1L);
        (void)curl_easy_setopt(curl, CURLOPT_MAXREDIRS, 4L);
        (void)curl_easy_setopt(curl, CURLOPT_CONNECTTIMEOUT, 4L);
        (void)curl_easy_setopt(curl, CURLOPT_TIMEOUT, 9L);
        (void)curl_easy_setopt(curl, CURLOPT_LOW_SPEED_LIMIT, 1L);
        (void)curl_easy_setopt(curl, CURLOPT_LOW_SPEED_TIME, 4L);
        (void)curl_easy_setopt(curl, CURLOPT_ACCEPT_ENCODING, "");
        (void)curl_easy_setopt(curl, CURLOPT_CAINFO, "cacert.pem");
        (void)curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 1L);
        (void)curl_easy_setopt(curl, CURLOPT_SSL_VERIFYHOST, 2L);
        (void)curl_easy_setopt(curl, CURLOPT_PROTOCOLS_STR, "http,https");
        (void)curl_easy_setopt(curl, CURLOPT_REDIR_PROTOCOLS_STR, "http,https");
        result = curl_easy_perform(curl);
        (void)curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &status_code);
        curl_easy_cleanup(curl);
        ++fetched;
        if (result != CURLE_OK || status_code < 200L || status_code >= 300L ||
            css.length == 0U || css.too_large || !css_content_type_allowed(css.content_type) ||
            memchr(css.data, '\0', css.length) != NULL || find_nocase(css.data, "</style") != NULL) continue;
        remaining = sizeof(page->source_html) - page->source_html_length;
        if (remaining < 20U) break;
        written = snprintf(page->source_html + page->source_html_length, remaining,
                           "\n<style>/* external stylesheet: %.380s */\n%.*s\n</style>\n",
                           media->url, (int)css.length, css.data);
        if (written < 0 || (size_t)written >= remaining) break;
        page->source_html_length += (size_t)written;
    }
}

int web_engine_native_init(void)
{
    return curl_global_init(CURL_GLOBAL_DEFAULT) == CURLE_OK ? 1 : 0;
}

void web_engine_native_shutdown(void)
{
    curl_global_cleanup();
}

int web_engine_native_fetch(const char *url, WebEnginePage *page, char *error, size_t error_capacity)
{
    CURL *curl;
    CURLcode result;
    HtmlBuffer html;
    long response_code = 0L;
    char curl_error[CURL_ERROR_SIZE];
    char *effective_url = NULL;
    char *response_content_type = NULL;

    if (page == NULL || url == NULL || url[0] == '\0') {
        set_error(error, error_capacity, "No URL provided");
        return 0;
    }
    memset(page, 0, sizeof(*page));
    memset(&html, 0, sizeof(html));
    memset(curl_error, 0, sizeof(curl_error));

    curl = curl_easy_init();
    if (curl == NULL) {
        set_error(error, error_capacity, "libcurl could not initialize");
        return 0;
    }

    (void)curl_easy_setopt(curl, CURLOPT_URL, url);
    (void)curl_easy_setopt(curl, CURLOPT_USERAGENT, "Mozilla/5.0 (Xbox 360; X360Browser/4.0.0) AppleWebKit/537.36 Safari/537.36");
    (void)curl_easy_setopt(curl, CURLOPT_COOKIEFILE, "X360Browser-cookies.txt");
    (void)curl_easy_setopt(curl, CURLOPT_COOKIEJAR, "X360Browser-cookies.txt");
    (void)curl_easy_setopt(curl, CURLOPT_NOSIGNAL, 1L);
    (void)curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, receive_html);
    (void)curl_easy_setopt(curl, CURLOPT_WRITEDATA, &html);
    (void)curl_easy_setopt(curl, CURLOPT_HEADERFUNCTION, receive_header);
    (void)curl_easy_setopt(curl, CURLOPT_HEADERDATA, &html);
    (void)curl_easy_setopt(curl, CURLOPT_ERRORBUFFER, curl_error);
    (void)curl_easy_setopt(curl, CURLOPT_BUFFERSIZE, 16384L);
    (void)curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1L);
    (void)curl_easy_setopt(curl, CURLOPT_MAXREDIRS, 8L);
    (void)curl_easy_setopt(curl, CURLOPT_CONNECTTIMEOUT, 15L);
    (void)curl_easy_setopt(curl, CURLOPT_TIMEOUT, 40L);
    (void)curl_easy_setopt(curl, CURLOPT_LOW_SPEED_LIMIT, 1L);
    (void)curl_easy_setopt(curl, CURLOPT_LOW_SPEED_TIME, 10L);
    (void)curl_easy_setopt(curl, CURLOPT_ACCEPT_ENCODING, "");
    (void)curl_easy_setopt(curl, CURLOPT_CAINFO, "cacert.pem");
    (void)curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 1L);
    (void)curl_easy_setopt(curl, CURLOPT_SSL_VERIFYHOST, 2L);
    (void)curl_easy_setopt(curl, CURLOPT_PROTOCOLS_STR, "http,https");
    (void)curl_easy_setopt(curl, CURLOPT_REDIR_PROTOCOLS_STR, "http,https");

    result = curl_easy_perform(curl);
    (void)curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &response_code);
    (void)curl_easy_getinfo(curl, CURLINFO_EFFECTIVE_URL, &effective_url);
    (void)curl_easy_getinfo(curl, CURLINFO_CONTENT_TYPE, &response_content_type);
    page->http_status = response_code;
    page->html_bytes = html.length;
    if (response_content_type != NULL)
        (void)snprintf(page->content_type, sizeof(page->content_type), "%s", response_content_type);
    else if (html.content_type[0] != '\0')
        (void)snprintf(page->content_type, sizeof(page->content_type), "%s", html.content_type);

    if (result != CURLE_OK && (html.direct_resource ||
        (response_content_type != NULL &&
         !starts_nocase(response_content_type, "text/html") &&
         !starts_nocase(response_content_type, "application/xhtml+xml") &&
         !starts_nocase(response_content_type, "text/plain")))) {
        const char *mime = response_content_type != NULL ? response_content_type : html.content_type;
        const char *kind = guess_media_kind(effective_url != NULL ? effective_url : url, mime);
        page->is_direct_resource = 1;
        (void)snprintf(page->title, sizeof(page->title), "%s",
                       kind != NULL && strcmp(kind, "video") == 0 ? "Video resource" :
                       kind != NULL && strcmp(kind, "audio") == 0 ? "Audio resource" :
                       kind != NULL && strcmp(kind, "image") == 0 ? "Image resource" :
                       "Direct web resource");
        (void)snprintf(page->text, sizeof(page->text),
                       "Resource detected: %s\n\nX360Browser stopped the body download after identifying a non-HTML content type, saving memory and bandwidth.\n\nThis build does not yet include a full image decoder or audio/video playback pipeline.\n\nHTTP status: %ld",
                       mime != NULL ? mime : "unknown/type", response_code);
        page->text_length = strlen(page->text);
        curl_easy_cleanup(curl);
        free(html.data);
        if (error != NULL && error_capacity > 0U) error[0] = '\0';
        return 1;
    }

    if (result != CURLE_OK) {
        if (html.too_large)
            set_error(error, error_capacity, "Page exceeded the 4 MiB HTML download limit");
        else if (curl_error[0] != '\0')
            set_error(error, error_capacity, curl_error);
        else
            set_error(error, error_capacity, curl_easy_strerror(result));
        curl_easy_cleanup(curl);
        free(html.data);
        return 0;
    }
    if (response_content_type != NULL &&
        !starts_nocase(response_content_type, "text/html") &&
        !starts_nocase(response_content_type, "application/xhtml+xml") &&
        !starts_nocase(response_content_type, "text/plain")) {
        const char *kind = guess_media_kind(effective_url != NULL ? effective_url : url,
                                            response_content_type);
        page->is_direct_resource = 1;
        (void)snprintf(page->title, sizeof(page->title), "%s",
                       kind != NULL && strcmp(kind, "video") == 0 ? "Video resource" :
                       kind != NULL && strcmp(kind, "audio") == 0 ? "Audio resource" :
                       kind != NULL && strcmp(kind, "image") == 0 ? "Image resource" :
                       "Direct web resource");
        (void)snprintf(page->text, sizeof(page->text),
                       "Resource detected: %s\n\nX360Browser correctly identified the response type, but this build does not yet include a full image decoder or audio/video playback pipeline.\n\nThe resource was not interpreted as HTML.\n\nHTTP status: %ld\nDownloaded bytes: %lu",
                       response_content_type, response_code, (unsigned long)html.length);
        page->text_length = strlen(page->text);
        curl_easy_cleanup(curl);
        free(html.data);
        if (error != NULL && error_capacity > 0U) error[0] = '\0';
        return 1;
    }
    if (html.data == NULL || html.length == 0U) {
        set_error(error, error_capacity, "The server returned an empty page");
        curl_easy_cleanup(curl);
        free(html.data);
        return 0;
    }

    if (starts_nocase(response_content_type != NULL ? response_content_type : "", "text/plain")) {
        size_t copy_length = html.length < sizeof(page->text) - 1U ? html.length : sizeof(page->text) - 1U;
        memcpy(page->text, html.data, copy_length);
        page->text[copy_length] = '\0';
        page->text_length = copy_length;
        (void)snprintf(page->title, sizeof(page->title), "Plain text");
    } else {
        (void)snprintf(page->page_url, sizeof(page->page_url), "%s",
                       effective_url != NULL && effective_url[0] != '\0' ? effective_url : url);
        parse_html(html.data, html.length, effective_url != NULL ? effective_url : url, page);
        materialize_external_scripts(page);
        append_external_stylesheets(page);
        prefetch_raster_images(page);
    }
    if (page->text_length == 0U)
        (void)snprintf(page->text, sizeof(page->text), "The page loaded, but this basic renderer found no visible text.\nHTML: %lu bytes.",
                       (unsigned long)html.length);
    curl_easy_cleanup(curl);
    free(html.data);

    if (response_code >= 400L) {
        if (error != NULL && error_capacity > 0U)
            (void)snprintf(error, error_capacity, "HTTP %ld", response_code);
    } else if (error != NULL && error_capacity > 0U) {
        error[0] = '\0';
    }
    return 1;
}

typedef struct {
    char *data;
    size_t length;
    size_t capacity;
    int too_large;
} HlsTextBuffer;

static size_t receive_hls_text(char *incoming, size_t unit_size, size_t count, void *user_data)
{
    HlsTextBuffer *buffer = (HlsTextBuffer *)user_data;
    size_t bytes;
    if (unit_size != 0U && count > SIZE_MAX / unit_size) return 0U;
    bytes = unit_size * count;
    if (bytes > buffer->capacity - buffer->length) {
        buffer->too_large = 1;
        return 0U;
    }
    memcpy(buffer->data + buffer->length, incoming, bytes);
    buffer->length += bytes;
    buffer->data[buffer->length] = '\0';
    return bytes;
}

static int fetch_hls_manifest(const char *url, HlsTextBuffer *buffer, char *error, size_t error_capacity)
{
    CURL *curl;
    CURLcode result;
    long response_code = 0L;
    char curl_error[CURL_ERROR_SIZE] = { 0 };
    memset(buffer->data, 0, buffer->capacity + 1U);
    buffer->length = 0U;
    buffer->too_large = 0;
    curl = curl_easy_init();
    if (curl == NULL) { set_error(error, error_capacity, "Cannot initialize HLS playlist request"); return 0; }
    (void)curl_easy_setopt(curl, CURLOPT_URL, url);
    (void)curl_easy_setopt(curl, CURLOPT_USERAGENT, "X360Browser/4.0.0 Xbox 360 homebrew");
    (void)curl_easy_setopt(curl, CURLOPT_NOSIGNAL, 1L);
    (void)curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, receive_hls_text);
    (void)curl_easy_setopt(curl, CURLOPT_WRITEDATA, buffer);
    (void)curl_easy_setopt(curl, CURLOPT_ERRORBUFFER, curl_error);
    (void)curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1L);
    (void)curl_easy_setopt(curl, CURLOPT_MAXREDIRS, 8L);
    (void)curl_easy_setopt(curl, CURLOPT_CONNECTTIMEOUT, 12L);
    (void)curl_easy_setopt(curl, CURLOPT_TIMEOUT, 30L);
    (void)curl_easy_setopt(curl, CURLOPT_LOW_SPEED_LIMIT, 1L);
    (void)curl_easy_setopt(curl, CURLOPT_LOW_SPEED_TIME, 10L);
    (void)curl_easy_setopt(curl, CURLOPT_ACCEPT_ENCODING, "identity");
    (void)curl_easy_setopt(curl, CURLOPT_COOKIEFILE, "X360Browser-cookies.txt");
    (void)curl_easy_setopt(curl, CURLOPT_COOKIEJAR, "X360Browser-cookies.txt");
    (void)curl_easy_setopt(curl, CURLOPT_CAINFO, "cacert.pem");
    (void)curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 1L);
    (void)curl_easy_setopt(curl, CURLOPT_SSL_VERIFYHOST, 2L);
    (void)curl_easy_setopt(curl, CURLOPT_PROTOCOLS_STR, "http,https");
    (void)curl_easy_setopt(curl, CURLOPT_REDIR_PROTOCOLS_STR, "http,https");
    result = curl_easy_perform(curl);
    (void)curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &response_code);
    curl_easy_cleanup(curl);
    if (buffer->too_large) { set_error(error, error_capacity, "HLS manifest exceeds 128 KiB"); return 0; }
    if (result != CURLE_OK || response_code < 200L || response_code >= 300L) {
        if (response_code < 200L || response_code >= 300L) {
            if (error != NULL && error_capacity > 0U) (void)snprintf(error, error_capacity, "HLS server returned HTTP %ld", response_code);
        } else set_error(error, error_capacity, curl_error[0] != '\0' ? curl_error : curl_easy_strerror(result));
        return 0;
    }
    if (buffer->length < 7U || memcmp(buffer->data, "#EXTM3U", 7U) != 0) {
        set_error(error, error_capacity, "URL did not return a valid HLS playlist");
        return 0;
    }
    return 1;
}

static void clean_manifest_line(char *line)
{
    size_t length = strlen(line);
    size_t start = 0U;
    while (start < length && (line[start] == ' ' || line[start] == '\t')) ++start;
    while (length > start && (line[length - 1U] == '\r' || line[length - 1U] == '\n' ||
                              line[length - 1U] == ' ' || line[length - 1U] == '\t')) --length;
    if (start > 0U) memmove(line, line + start, length - start);
    line[length - start] = '\0';
}

static int resolve_hls_uri(const char *base_url, const char *uri, char *out, size_t out_capacity)
{
    char clean_base[WEB_ENGINE_URL_CAP];
    const char *end;
    size_t n;
    if (base_url == NULL || uri == NULL || uri[0] == '\0' || out_capacity == 0U) return 0;
    end = strpbrk(base_url, "?#");
    n = end == NULL ? strlen(base_url) : (size_t)(end - base_url);
    if (n >= sizeof(clean_base)) n = sizeof(clean_base) - 1U;
    memcpy(clean_base, base_url, n);
    clean_base[n] = '\0';
    resolve_link_url(clean_base, uri, out, out_capacity);
    return out[0] != '\0' && (starts_nocase(out, "http://") || starts_nocase(out, "https://"));
}

static unsigned long long hls_bandwidth(const char *line)
{
    const char *p = find_nocase(line, "BANDWIDTH=");
    char *end = NULL;
    unsigned long long value;
    if (p == NULL) return ULLONG_MAX;
    p += strlen("BANDWIDTH=");
    value = strtoull(p, &end, 10);
    return end == p ? ULLONG_MAX : value;
}

static int download_video_segment(const char *url, FILE *file, VideoFileSink *sink,
                                  char *error, size_t error_capacity)
{
    CURL *curl;
    CURLcode result;
    long response_code = 0L;
    char curl_error[CURL_ERROR_SIZE] = { 0 };
    size_t before = sink->bytes;
    curl = curl_easy_init();
    if (curl == NULL) { set_error(error, error_capacity, "Cannot initialize media segment request"); return 0; }
    (void)curl_easy_setopt(curl, CURLOPT_URL, url);
    (void)curl_easy_setopt(curl, CURLOPT_USERAGENT, "X360Browser/4.0.0 Xbox 360 homebrew");
    (void)curl_easy_setopt(curl, CURLOPT_NOSIGNAL, 1L);
    (void)curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, receive_video_file);
    (void)curl_easy_setopt(curl, CURLOPT_WRITEDATA, sink);
    (void)curl_easy_setopt(curl, CURLOPT_ERRORBUFFER, curl_error);
    (void)curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1L);
    (void)curl_easy_setopt(curl, CURLOPT_MAXREDIRS, 8L);
    (void)curl_easy_setopt(curl, CURLOPT_CONNECTTIMEOUT, 12L);
    (void)curl_easy_setopt(curl, CURLOPT_TIMEOUT, 45L);
    (void)curl_easy_setopt(curl, CURLOPT_LOW_SPEED_LIMIT, 1L);
    (void)curl_easy_setopt(curl, CURLOPT_LOW_SPEED_TIME, 10L);
    (void)curl_easy_setopt(curl, CURLOPT_ACCEPT_ENCODING, "identity");
    (void)curl_easy_setopt(curl, CURLOPT_COOKIEFILE, "X360Browser-cookies.txt");
    (void)curl_easy_setopt(curl, CURLOPT_COOKIEJAR, "X360Browser-cookies.txt");
    (void)curl_easy_setopt(curl, CURLOPT_CAINFO, "cacert.pem");
    (void)curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 1L);
    (void)curl_easy_setopt(curl, CURLOPT_SSL_VERIFYHOST, 2L);
    (void)curl_easy_setopt(curl, CURLOPT_PROTOCOLS_STR, "http,https");
    (void)curl_easy_setopt(curl, CURLOPT_REDIR_PROTOCOLS_STR, "http,https");
    result = curl_easy_perform(curl);
    (void)curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &response_code);
    curl_easy_cleanup(curl);
    if (result != CURLE_OK || response_code < 200L || response_code >= 300L || sink->bytes <= before) {
        if (sink->too_large) set_error(error, error_capacity, "HLS media exceeds the 512 MiB limit");
        else if (response_code < 200L || response_code >= 300L) {
            if (error != NULL && error_capacity > 0U) (void)snprintf(error, error_capacity, "Media segment returned HTTP %ld", response_code);
        } else set_error(error, error_capacity, curl_error[0] != '\0' ? curl_error : "Empty or failed HLS media segment");
        return 0;
    }
    (void)file;
    return 1;
}

static int download_hls_vod(const char *url, const char *destination,
                            char *error, size_t error_capacity, unsigned depth)
{
    HlsTextBuffer manifest;
    char line[WEB_ENGINE_URL_CAP * 2U];
    char best_variant[WEB_ENGINE_URL_CAP] = { 0 };
    unsigned long long best_bandwidth = ULLONG_MAX;
    unsigned long long pending_bandwidth = ULLONG_MAX;
    int master = 0;
    int pending_variant = 0;
    int has_endlist = 0;
    int has_encryption = 0;
    int has_byterange = 0;
    unsigned segment_count = 0U;
    size_t cap = WEB_ENGINE_MAX_HLS_MANIFEST;
    size_t cursor = 0U;
    FILE *file = NULL;
    VideoFileSink sink;
    int ok = 0;
    if (depth > 2U) { set_error(error, error_capacity, "HLS master playlist nesting is too deep"); return 0; }
    manifest.data = (char *)calloc(cap + 1U, 1U);
    if (manifest.data == NULL) { set_error(error, error_capacity, "Not enough memory for HLS playlist"); return 0; }
    manifest.capacity = cap;
    manifest.length = 0U;
    manifest.too_large = 0;
    if (!fetch_hls_manifest(url, &manifest, error, error_capacity)) goto cleanup;

    /* Pre-scan the manifest. We deliberately reject live and encrypted HLS rather than
     * writing a corrupt file or silently bypassing content protection. */
    cursor = 0U;
    while (cursor < manifest.length) {
        size_t line_start = cursor;
        size_t line_length;
        while (cursor < manifest.length && manifest.data[cursor] != '\n') ++cursor;
        line_length = cursor - line_start;
        if (cursor < manifest.length) ++cursor;
        if (line_length >= sizeof(line)) line_length = sizeof(line) - 1U;
        memcpy(line, manifest.data + line_start, line_length);
        line[line_length] = '\0';
        clean_manifest_line(line);
        if (line[0] == '\0') continue;
        if (starts_nocase(line, "#EXT-X-STREAM-INF:")) {
            master = 1;
            pending_variant = 1;
            pending_bandwidth = hls_bandwidth(line);
            continue;
        }
        if (line[0] == '#') {
            if (starts_nocase(line, "#EXT-X-ENDLIST")) has_endlist = 1;
            if (starts_nocase(line, "#EXT-X-KEY:") && !contains_nocase(line, "METHOD=NONE")) has_encryption = 1;
            if (starts_nocase(line, "#EXT-X-BYTERANGE:")) has_byterange = 1;
            continue;
        }
        if (pending_variant) {
            if (pending_bandwidth < best_bandwidth || best_variant[0] == '\0') {
                if (resolve_hls_uri(url, line, best_variant, sizeof(best_variant))) best_bandwidth = pending_bandwidth;
            }
            pending_variant = 0;
            continue;
        }
        if (!master) {
            ++segment_count;
            if (segment_count > WEB_ENGINE_MAX_HLS_SEGMENTS) {
                set_error(error, error_capacity, "HLS playlist has more than 256 segments");
                goto cleanup;
            }
        }
    }

    if (master) {
        if (best_variant[0] == '\0') { set_error(error, error_capacity, "HLS master playlist contains no usable variant"); goto cleanup; }
        free(manifest.data);
        manifest.data = NULL;
        return download_hls_vod(best_variant, destination, error, error_capacity, depth + 1U);
    }
    if (!has_endlist) { set_error(error, error_capacity, "Live HLS is not supported; use a finished VOD playlist"); goto cleanup; }
    if (has_encryption) { set_error(error, error_capacity, "Encrypted HLS is not supported; media protection was not bypassed"); goto cleanup; }
    if (has_byterange) { set_error(error, error_capacity, "HLS byte-range playlists are not supported yet"); goto cleanup; }
    if (segment_count == 0U) { set_error(error, error_capacity, "HLS playlist contains no media segments"); goto cleanup; }
    file = fopen(destination, "wb");
    if (file == NULL) { set_error(error, error_capacity, "Cannot create the HLS output file"); goto cleanup; }
    memset(&sink, 0, sizeof(sink));
    sink.file = file;
    cursor = 0U;
    while (cursor < manifest.length) {
        size_t line_start = cursor;
        size_t line_length;
        char absolute_url[WEB_ENGINE_URL_CAP];
        while (cursor < manifest.length && manifest.data[cursor] != '\n') ++cursor;
        line_length = cursor - line_start;
        if (cursor < manifest.length) ++cursor;
        if (line_length >= sizeof(line)) line_length = sizeof(line) - 1U;
        memcpy(line, manifest.data + line_start, line_length);
        line[line_length] = '\0';
        clean_manifest_line(line);
        if (line[0] == '\0') continue;
        if (starts_nocase(line, "#EXT-X-MAP:")) {
            const char *uri = find_nocase(line, "URI=\"");
            char raw_uri[WEB_ENGINE_URL_CAP];
            size_t n = 0U;
            if (uri == NULL) { set_error(error, error_capacity, "HLS initialization map has no URI"); goto cleanup; }
            uri += 5;
            while (uri[n] != '\0' && uri[n] != '"' && n + 1U < sizeof(raw_uri)) ++n;
            if (uri[n] != '"') { set_error(error, error_capacity, "HLS initialization URI is too long"); goto cleanup; }
            memcpy(raw_uri, uri, n); raw_uri[n] = '\0';
            if (!resolve_hls_uri(url, raw_uri, absolute_url, sizeof(absolute_url)) ||
                !download_video_segment(absolute_url, file, &sink, error, error_capacity)) goto cleanup;
            continue;
        }
        if (line[0] == '#') continue;
        if (!resolve_hls_uri(url, line, absolute_url, sizeof(absolute_url))) {
            set_error(error, error_capacity, "Invalid relative URL in HLS playlist");
            goto cleanup;
        }
        if (!download_video_segment(absolute_url, file, &sink, error, error_capacity)) goto cleanup;
    }
    if (fclose(file) != 0) { file = NULL; set_error(error, error_capacity, "Could not finalize HLS output file"); goto cleanup; }
    file = NULL;
    if (sink.bytes == 0U) { set_error(error, error_capacity, "HLS playlist produced an empty media file"); goto cleanup; }
    if (error != NULL && error_capacity > 0U) error[0] = '\0';
    ok = 1;
cleanup:
    if (file != NULL) (void)fclose(file);
    if (!ok) (void)remove(destination);
    free(manifest.data);
    return ok;
}

/*
 * Optional YouTube compatibility path for consoles without a modern browser media stack.
 * It asks public Invidious API instances for an already-muxed MP4 at <=480p, then uses the
 * existing bounded downloader / configured external player. This is intentionally a fallback:
 * public instances may be unavailable, rate-limited, or unable to resolve a particular video.
 */
#define WEB_ENGINE_YOUTUBE_JSON_CAP (256U * 1024U)
#define WEB_ENGINE_YOUTUBE_ID_CAP 12U

static int youtube_id_char(char ch)
{
    return (ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z') ||
           (ch >= '0' && ch <= '9') || ch == '_' || ch == '-';
}

static int youtube_copy_id(const char *start, size_t length, char id[WEB_ENGINE_YOUTUBE_ID_CAP])
{
    size_t i;
    if (start == NULL || id == NULL || length != 11U) return 0;
    for (i = 0U; i < length; ++i) if (!youtube_id_char(start[i])) return 0;
    memcpy(id, start, length);
    id[length] = '\0';
    return 1;
}

/* Parse a DNS authority port without silently accepting :garbage, empty ports,
 * overflowing values, credentials or an unbracketed IPv6 literal. If require_tls_port
 * is set, only the default HTTPS port is accepted (used for selected media hosts). */
static int youtube_strip_valid_port(char *host, int require_tls_port)
{
    char *colon;
    const char *port;
    unsigned int value = 0U;
    if (host == NULL || host[0] == '\0') return 0;
    colon = strrchr(host, ':');
    if (colon == NULL) return 1;
    if (strchr(host, ':') != colon) return 0;
    port = colon + 1;
    if (*port == '\0') return 0;
    while (*port != '\0') {
        if (*port < '0' || *port > '9') return 0;
        value = value * 10U + (unsigned int)(*port - '0');
        if (value > 65535U) return 0;
        ++port;
    }
    if (value == 0U || (require_tls_port && value != 443U)) return 0;
    *colon = '\0';
    return host[0] != '\0';
}

static int youtube_id_from_url(const char *url, char id[WEB_ENGINE_YOUTUBE_ID_CAP])
{
    const char *scheme, *authority, *authority_end, *path, *path_end;
    char host[96];
    size_t host_length;
    const char *candidate = NULL;
    if (url == NULL || id == NULL) return 0;
    scheme = strstr(url, "://");
    if (scheme == NULL || (!starts_nocase(url, "https://") && !starts_nocase(url, "http://"))) return 0;
    authority = scheme + 3;
    authority_end = strpbrk(authority, "/?#");
    if (authority_end == NULL) authority_end = url + strlen(url);
    if (authority_end <= authority || memchr(authority, '@', (size_t)(authority_end - authority)) != NULL) return 0;
    host_length = (size_t)(authority_end - authority);
    if (host_length >= sizeof(host)) return 0;
    memcpy(host, authority, host_length); host[host_length] = '\0';
    /* Only accept a syntactically valid optional port; never strip malformed suffixes. */
    {
        size_t i;
        if (!youtube_strip_valid_port(host, 0)) return 0;
        for (i = 0U; host[i] != '\0'; ++i) host[i] = (char)tolower((unsigned char)host[i]);
        if (starts_nocase(host, "www.")) memmove(host, host + 4, strlen(host + 4) + 1U);
        if (starts_nocase(host, "m.")) memmove(host, host + 2, strlen(host + 2) + 1U);
    }
    path = authority_end;
    if (path >= url + strlen(url)) return 0;
    path_end = strpbrk(path, "?#");
    if (path_end == NULL) path_end = url + strlen(url);
    if (strcmp(host, "youtu.be") == 0) {
        const char *start = path;
        if (*start == '/') ++start;
        candidate = start;
        while (candidate < path_end && *candidate != '/') ++candidate;
        return youtube_copy_id(start, (size_t)(candidate - start), id);
    }
    if (strcmp(host, "youtube.com") != 0 && strcmp(host, "youtube-nocookie.com") != 0 &&
        strcmp(host, "music.youtube.com") != 0 && strcmp(host, "gaming.youtube.com") != 0) return 0;
    if (strncmp(path, "/watch?", 7U) == 0) {
        const char *query = strchr(path, '?');
        const char *url_end = url + strlen(url);
        const char *query_end;
        if (query == NULL) return 0;
        ++query;
        query_end = memchr(query, '#', (size_t)(url_end - query));
        if (query_end == NULL) query_end = url_end;
        while (query < query_end) {
            const char *key = query;
            const char *eq = memchr(query, '=', (size_t)(query_end - query));
            const char *amp = memchr(query, '&', (size_t)(query_end - query));
            const char *value_end;
            if (amp == NULL) amp = query_end;
            if (eq != NULL && eq < amp && (size_t)(eq - key) == 1U && key[0] == 'v') {
                value_end = amp;
                return youtube_copy_id(eq + 1, (size_t)(value_end - (eq + 1)), id);
            }
            if (amp >= query_end) break;
            query = amp + 1;
        }
        return 0;
    }
    {
        static const char *const prefixes[] = {"/shorts/", "/embed/", "/live/"};
        size_t i;
        for (i = 0U; i < sizeof(prefixes) / sizeof(prefixes[0]); ++i) {
            const size_t n = strlen(prefixes[i]);
            if ((size_t)(path_end - path) > n && strncmp(path, prefixes[i], n) == 0) {
                const char *start = path + n;
                const char *finish = start;
                while (finish < path_end && *finish != '/') ++finish;
                return youtube_copy_id(start, (size_t)(finish - start), id);
            }
        }
    }
    return 0;
}

int web_engine_is_youtube_url(const char *url)
{
    char id[WEB_ENGINE_YOUTUBE_ID_CAP];
    return youtube_id_from_url(url, id);
}

typedef struct {
    char *data;
    size_t length;
    size_t capacity;
    int too_large;
} YoutubeJsonSink;

static size_t receive_youtube_json(char *incoming, size_t unit_size, size_t count, void *user_data)
{
    YoutubeJsonSink *sink = (YoutubeJsonSink *)user_data;
    size_t bytes;
    if (unit_size != 0U && count > SIZE_MAX / unit_size) return 0U;
    bytes = unit_size * count;
    if (bytes > sink->capacity - sink->length) { sink->too_large = 1; return 0U; }
    memcpy(sink->data + sink->length, incoming, bytes);
    sink->length += bytes;
    sink->data[sink->length] = '\0';
    return bytes;
}

static const char *youtube_json_ws(const char *p, const char *end)
{
    while (p < end && isspace((unsigned char)*p)) ++p;
    return p;
}

static int youtube_json_string(const char **cursor, const char *end, char *out, size_t capacity)
{
    const char *p = *cursor;
    size_t used = 0U;
    if (p >= end || *p != '"') return 0;
    ++p;
    while (p < end && *p != '"') {
        unsigned char ch = (unsigned char)*p++;
        if (ch == '\\') {
            unsigned char esc;
            if (p >= end) return 0;
            esc = (unsigned char)*p++;
            switch (esc) {
                case '"': ch = '"'; break;
                case '\\': ch = '\\'; break;
                case '/': ch = '/'; break;
                case 'b': ch = '\b'; break;
                case 'f': ch = '\f'; break;
                case 'n': ch = '\n'; break;
                case 'r': ch = '\r'; break;
                case 't': ch = '\t'; break;
                case 'u': {
                    unsigned int code = 0U;
                    unsigned int i;
                    for (i = 0U; i < 4U; ++i) {
                        unsigned char h;
                        if (p >= end) return 0;
                        h = (unsigned char)*p++;
                        code <<= 4U;
                        if (h >= '0' && h <= '9') code |= (unsigned int)(h - '0');
                        else if (h >= 'a' && h <= 'f') code |= (unsigned int)(h - 'a' + 10U);
                        else if (h >= 'A' && h <= 'F') code |= (unsigned int)(h - 'A' + 10U);
                        else return 0;
                    }
                    /* Stream URLs are ASCII; decode JSON's common escaped URL punctuation. */
                    if (code <= 0x7FU) ch = (unsigned char)code;
                    else ch = '?';
                    break;
                }
                default: return 0;
            }
        }
        if (out != NULL) {
            if (capacity == 0U || used + 1U >= capacity) return 0;
            out[used] = (char)ch;
        }
        ++used;
    }
    if (p >= end || *p != '"') return 0;
    ++p;
    if (out != NULL && capacity > 0U) out[used] = '\0';
    *cursor = p;
    return 1;
}

static const char *youtube_json_skip_value(const char *p, const char *end)
{
    p = youtube_json_ws(p, end);
    if (p >= end) return end;
    if (*p == '"') {
        ++p;
        while (p < end) {
            if (*p == '\\') { p += (p + 1 < end) ? 2 : 1; continue; }
            if (*p++ == '"') break;
        }
        return p;
    }
    if (*p == '{' || *p == '[') {
        char stack[64]; size_t depth = 0U; int quoted = 0;
        while (p < end) {
            char ch = *p++;
            if (quoted) {
                if (ch == '\\' && p < end) { ++p; continue; }
                if (ch == '"') quoted = 0;
                continue;
            }
            if (ch == '"') { quoted = 1; continue; }
            if (ch == '{' || ch == '[') {
                if (depth >= sizeof(stack)) return end;
                stack[depth++] = ch;
            } else if (ch == '}' || ch == ']') {
                if (depth == 0U) return end;
                --depth;
                if (depth == 0U) return p;
            }
        }
        return end;
    }
    while (p < end && *p != ',' && *p != '}' && *p != ']' && !isspace((unsigned char)*p)) ++p;
    return p;
}

static int youtube_json_member(const char *object, const char *end, const char *wanted,
                               const char **value_start, const char **value_end)
{
    const char *p = object;
    if (p < end && *p == '{') ++p;
    while (p < end) {
        char key[96];
        p = youtube_json_ws(p, end);
        if (p < end && (*p == ',')) { ++p; continue; }
        if (p >= end || *p == '}') break;
        if (!youtube_json_string(&p, end, key, sizeof(key))) return 0;
        p = youtube_json_ws(p, end);
        if (p >= end || *p++ != ':') return 0;
        p = youtube_json_ws(p, end);
        const char *vs = p;
        const char *ve = youtube_json_skip_value(p, end);
        if (strcmp(key, wanted) == 0) {
            if (value_start != NULL) *value_start = vs;
            if (value_end != NULL) *value_end = ve;
            return 1;
        }
        if (ve <= p) return 0;
        p = ve;
    }
    return 0;
}

static int youtube_json_member_string(const char *object, const char *end,
                                      const char *wanted, char *out, size_t capacity)
{
    const char *vs = NULL, *ve = NULL;
    if (!youtube_json_member(object, end, wanted, &vs, &ve) || vs == NULL || ve == NULL || vs >= ve) return 0;
    if (*vs != '"') return 0;
    return youtube_json_string(&vs, ve, out, capacity);
}

static int youtube_stream_trusted(const char *url)
{
    const char *authority, *end;
    char host[128]; size_t length, i;
    if (url == NULL || !starts_nocase(url, "https://")) return 0;
    authority = url + 8;
    end = strpbrk(authority, "/?#");
    if (end == NULL) end = url + strlen(url);
    length = (size_t)(end - authority);
    if (length == 0U || length >= sizeof(host) || memchr(authority, '@', length) != NULL) return 0;
    memcpy(host, authority, length); host[length] = '\0';
    if (!youtube_strip_valid_port(host, 1)) return 0;
    for (i = 0U; host[i] != '\0'; ++i) host[i] = (char)tolower((unsigned char)host[i]);
    length = strlen(host);
    return (length >= sizeof(".googlevideo.com") - 1U &&
            strcmp(host + length - (sizeof(".googlevideo.com") - 1U), ".googlevideo.com") == 0) ||
           strcmp(host, "googlevideo.com") == 0;
}

static int youtube_quality_height(const char *quality, const char *resolution)
{
    const char *p = quality;
    int value = 0;
    if (p != NULL && p[0] != '\0') {
        while (*p >= '0' && *p <= '9') { value = value * 10 + (*p++ - '0'); if (value > 10000) return 0; }
        if (*p == 'p' && p[1] == '\0') return value;
    }
    if (resolution != NULL) {
        const char *x = strchr(resolution, 'x');
        if (x != NULL) { p = x + 1; value = 0; while (*p >= '0' && *p <= '9') { value=value*10+(*p++-'0'); if(value>10000)return 0; } if (value>0) return value; }
    }
    return 0;
}

static int youtube_pick_stream(const char *json, size_t json_length,
                               char *stream_url, size_t stream_capacity)
{
    const char *begin, *end, *array = NULL, *array_end = NULL;
    const char *p;
    int best_height = 0;
    int saw_array_end = 0;
    char best_url[WEB_ENGINE_RESOURCE_URL_CAP] = {0};
    if (json == NULL || stream_url == NULL || stream_capacity == 0U || json_length == 0U) return 0;
    begin = json;
    end = json + json_length;
    begin = youtube_json_ws(begin, end);
    while (end > begin && isspace((unsigned char)end[-1])) --end;
    /* Do not accept a stream parsed from a truncated/non-object response. */
    if (begin >= end || *begin != '{' || end[-1] != '}') return 0;
    if (!youtube_json_member(begin, end, "formatStreams", &array, &array_end) ||
        array == NULL || array_end == NULL || array >= array_end || *array != '[' || array_end[-1] != ']') return 0;
    p = array + 1;
    while (p < array_end) {
        const char *object_end;
        char url[WEB_ENGINE_RESOURCE_URL_CAP] = {0};
        char type[256] = {0};
        char container[32] = {0};
        char quality[32] = {0};
        char resolution[32] = {0};
        int height;
        p = youtube_json_ws(p, array_end);
        if (p < array_end && (*p == ',')) { ++p; continue; }
        if (p < array_end && *p == ']') { saw_array_end = 1; break; }
        if (p >= array_end) break;
        object_end = youtube_json_skip_value(p, array_end);
        if (*p == '{' && object_end > p && object_end <= array_end && object_end[-1] == '}') {
            if (youtube_json_member_string(p, object_end, "url", url, sizeof(url)) &&
                youtube_json_member_string(p, object_end, "type", type, sizeof(type)) &&
                youtube_json_member_string(p, object_end, "container", container, sizeof(container)) &&
                (youtube_json_member_string(p, object_end, "qualityLabel", quality, sizeof(quality)) ||
                 youtube_json_member_string(p, object_end, "resolution", resolution, sizeof(resolution))) &&
                strcasecmp(container, "mp4") == 0 && starts_nocase(type, "video/mp4") &&
                !contains_nocase(type, "av01") && !contains_nocase(type, "vp09") &&
                !contains_nocase(type, "vp9") && youtube_stream_trusted(url)) {
                height = youtube_quality_height(quality, resolution);
                if (height > best_height && height <= 480) {
                    (void)snprintf(best_url, sizeof(best_url), "%s", url);
                    best_height = height;
                }
            }
        }
        if (object_end <= p) break;
        p = object_end;
    }
    if (!saw_array_end || best_height == 0 || strlen(best_url) >= stream_capacity) return 0;
    (void)snprintf(stream_url, stream_capacity, "%s", best_url);
    return 1;
}

/* Validate the actual downloaded bytes instead of trusting only Content-Type.
 * YouTube's selected stream is required to be MP4; reject an HTML/error body or a
 * mismatched redirect before an external player receives the file. */
static int youtube_download_has_mp4_signature(const char *path)
{
    unsigned char header[16] = {0};
    FILE *file;
    long file_size;
    size_t got;
    uint32_t box_size;
    int valid = 0;
    if (path == NULL || path[0] == '\0') return 0;
    file = fopen(path, "rb");
    if (file == NULL) return 0;
    if (fseek(file, 0L, SEEK_END) != 0 || (file_size = ftell(file)) < 12L ||
        fseek(file, 0L, SEEK_SET) != 0) {
        (void)fclose(file);
        return 0;
    }
    got = fread(header, 1U, sizeof(header), file);
    (void)fclose(file);
    if (got < 12U || memcmp(header + 4U, "ftyp", 4U) != 0) return 0;
    box_size = ((uint32_t)header[0] << 24U) | ((uint32_t)header[1] << 16U) |
               ((uint32_t)header[2] << 8U) | (uint32_t)header[3];
    if (box_size >= 8U && (uint64_t)box_size <= (uint64_t)(unsigned long)file_size)
        valid = 1;
    else if (box_size == 1U && got >= 16U) {
        uint64_t extended_size = ((uint64_t)header[8] << 56U) | ((uint64_t)header[9] << 48U) |
            ((uint64_t)header[10] << 40U) | ((uint64_t)header[11] << 32U) |
            ((uint64_t)header[12] << 24U) | ((uint64_t)header[13] << 16U) |
            ((uint64_t)header[14] << 8U) | (uint64_t)header[15];
        if (extended_size >= 16U && extended_size <= (uint64_t)(unsigned long)file_size)
            valid = 1;
    }
    return valid;
}

#ifdef X360BROWSER_TESTING
int web_engine_test_youtube_pick_stream(const char *json, size_t json_length,
                                        char *stream_url, size_t stream_capacity)
{
    return youtube_pick_stream(json, json_length, stream_url, stream_capacity);
}

int web_engine_test_youtube_file_is_mp4(const char *path)
{
    return youtube_download_has_mp4_signature(path);
}
#endif

static int youtube_resolve_stream(const char *watch_url, char *stream_url, size_t stream_capacity,
                                  char *error, size_t error_capacity)
{
    static const char *const instances[] = {
        "inv.nadeko.net", "invidious.nerdvpn.de", "yt.chocolatemoo53.com", "invidious.tiekoetter.com"
    };
    char id[WEB_ENGINE_YOUTUBE_ID_CAP] = {0};
    char api_url[WEB_ENGINE_URL_CAP];
    char curl_error[CURL_ERROR_SIZE];
    char *json;
    size_t i;
    int success = 0;
    if (!youtube_id_from_url(watch_url, id)) {
        set_error(error, error_capacity, "Unsupported YouTube URL. Use a watch, short, embed, live, or youtu.be link.");
        return 0;
    }
    json = (char *)malloc(WEB_ENGINE_YOUTUBE_JSON_CAP + 1U);
    if (json == NULL) { set_error(error, error_capacity, "Not enough RAM to resolve YouTube playback."); return 0; }
    for (i = 0U; i < sizeof(instances) / sizeof(instances[0]); ++i) {
        YoutubeJsonSink sink;
        CURL *curl;
        CURLcode result;
        long status_code = 0L;
        (void)snprintf(api_url, sizeof(api_url), "https://%s/api/v1/videos/%s?fields=videoId,formatStreams", instances[i], id);
        memset(&sink, 0, sizeof(sink)); sink.data = json; sink.capacity = WEB_ENGINE_YOUTUBE_JSON_CAP; json[0] = '\0';
        curl = curl_easy_init();
        if (curl == NULL) continue;
        curl_error[0] = '\0';
        (void)curl_easy_setopt(curl, CURLOPT_URL, api_url);
        (void)curl_easy_setopt(curl, CURLOPT_USERAGENT, "X360Browser/4.0.0 (Xbox 360; bounded media resolver)");
        (void)curl_easy_setopt(curl, CURLOPT_ERRORBUFFER, curl_error);
        (void)curl_easy_setopt(curl, CURLOPT_NOSIGNAL, 1L);
        (void)curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, receive_youtube_json);
        (void)curl_easy_setopt(curl, CURLOPT_WRITEDATA, &sink);
        (void)curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1L);
        (void)curl_easy_setopt(curl, CURLOPT_MAXREDIRS, 2L);
        (void)curl_easy_setopt(curl, CURLOPT_CONNECTTIMEOUT, 3L);
        (void)curl_easy_setopt(curl, CURLOPT_TIMEOUT, 7L);
        (void)curl_easy_setopt(curl, CURLOPT_LOW_SPEED_LIMIT, 1L);
        (void)curl_easy_setopt(curl, CURLOPT_LOW_SPEED_TIME, 3L);
        (void)curl_easy_setopt(curl, CURLOPT_ACCEPT_ENCODING, "");
        (void)curl_easy_setopt(curl, CURLOPT_CAINFO, "cacert.pem");
        (void)curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 1L);
        (void)curl_easy_setopt(curl, CURLOPT_SSL_VERIFYHOST, 2L);
        (void)curl_easy_setopt(curl, CURLOPT_PROTOCOLS_STR, "https");
        (void)curl_easy_setopt(curl, CURLOPT_REDIR_PROTOCOLS_STR, "https");
        result = curl_easy_perform(curl);
        (void)curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &status_code);
        curl_easy_cleanup(curl);
        if (result == CURLE_OK && status_code >= 200L && status_code < 300L &&
            !sink.too_large && sink.length > 0U && sink.length <= WEB_ENGINE_YOUTUBE_JSON_CAP &&
            youtube_pick_stream(json, sink.length, stream_url, stream_capacity)) {
            success = 1;
            break;
        }
    }
    free(json);
    if (!success) {
        set_error(error, error_capacity,
                  "YouTube stream not resolved: public Invidious APIs may be down or this video has no compatible MP4 up to 480p.");
        return 0;
    }
    if (error != NULL && error_capacity > 0U) error[0] = '\0';
    return 1;
}

int web_engine_download_media(const char *url, const char *destination, const char *media_kind,
                              char *error, size_t error_capacity)
{
    CURL *curl;
    CURLcode result;
    FILE *file;
    VideoFileSink sink;
    long response_code = 0L;
    char curl_error[CURL_ERROR_SIZE] = { 0 };
    char *content_type = NULL;
    int close_result;
    int is_html;
    int is_manifest;
    int is_audio = media_kind != NULL && strcasecmp(media_kind, "audio") == 0;
    int is_youtube_resolved = 0;
    int is_allowed_media_type;
    const char *kind_name = is_audio ? "audio" : "video";
    const char *download_url = url;
    char youtube_stream_url[WEB_ENGINE_RESOURCE_URL_CAP];

    if (url == NULL || destination == NULL || url[0] == '\0' || destination[0] == '\0') {
        set_error(error, error_capacity, "No media URL or destination provided");
        return 0;
    }
    if (!starts_nocase(url, "http://") && !starts_nocase(url, "https://")) {
        set_error(error, error_capacity, "Only HTTP/HTTPS media URLs are supported");
        return 0;
    }
    if (!is_audio && web_engine_is_youtube_url(url)) {
        if (!youtube_resolve_stream(url, youtube_stream_url, sizeof(youtube_stream_url), error, error_capacity))
            return 0;
        download_url = youtube_stream_url;
        is_youtube_resolved = 1;
    }
    if (url_has_suffix(download_url, ".m3u8"))
        return download_hls_vod(download_url, destination, error, error_capacity, 0U);
    if (url_has_suffix(download_url, ".mpd")) {
        set_error(error, error_capacity, "MPEG-DASH is not supported in this build");
        return 0;
    }
    file = fopen(destination, "wb");
    if (file == NULL) {
        set_error(error, error_capacity, "Cannot create the media file on console storage");
        return 0;
    }
    memset(&sink, 0, sizeof(sink));
    sink.file = file;
    curl = curl_easy_init();
    if (curl == NULL) {
        (void)fclose(file);
        (void)remove(destination);
        set_error(error, error_capacity, "libcurl could not initialize the media transfer");
        return 0;
    }
    (void)curl_easy_setopt(curl, CURLOPT_URL, download_url);
    (void)curl_easy_setopt(curl, CURLOPT_USERAGENT, "X360Browser/4.0.0 Xbox 360 homebrew");
    (void)curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, receive_video_file);
    (void)curl_easy_setopt(curl, CURLOPT_WRITEDATA, &sink);
    (void)curl_easy_setopt(curl, CURLOPT_ERRORBUFFER, curl_error);
    (void)curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1L);
    (void)curl_easy_setopt(curl, CURLOPT_MAXREDIRS, 8L);
    (void)curl_easy_setopt(curl, CURLOPT_CONNECTTIMEOUT, 15L);
    (void)curl_easy_setopt(curl, CURLOPT_TIMEOUT, 180L);
    (void)curl_easy_setopt(curl, CURLOPT_LOW_SPEED_LIMIT, 1L);
    (void)curl_easy_setopt(curl, CURLOPT_LOW_SPEED_TIME, 20L);
    (void)curl_easy_setopt(curl, CURLOPT_ACCEPT_ENCODING, "identity");
    (void)curl_easy_setopt(curl, CURLOPT_COOKIEFILE, "X360Browser-cookies.txt");
    (void)curl_easy_setopt(curl, CURLOPT_COOKIEJAR, "X360Browser-cookies.txt");
    (void)curl_easy_setopt(curl, CURLOPT_CAINFO, "cacert.pem");
    (void)curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 1L);
    (void)curl_easy_setopt(curl, CURLOPT_SSL_VERIFYHOST, 2L);
    (void)curl_easy_setopt(curl, CURLOPT_PROTOCOLS_STR, "http,https");
    /* A resolver-selected Google Video URL may redirect only to HTTPS. */
    (void)curl_easy_setopt(curl, CURLOPT_REDIR_PROTOCOLS_STR, is_youtube_resolved ? "https" : "http,https");

    result = curl_easy_perform(curl);
    (void)curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &response_code);
    (void)curl_easy_getinfo(curl, CURLINFO_CONTENT_TYPE, &content_type);
    is_html = content_type != NULL &&
        (starts_nocase(content_type, "text/") || starts_nocase(content_type, "application/xhtml+xml"));
    is_manifest = is_manifest_url_or_type(download_url, content_type) != 0;
    if (content_type == NULL || content_type[0] == '\0') {
        is_allowed_media_type = 1;
    } else if (is_audio) {
        is_allowed_media_type = starts_nocase(content_type, "audio/") ||
            starts_nocase(content_type, "application/ogg") ||
            starts_nocase(content_type, "application/octet-stream") ||
            starts_nocase(content_type, "application/mp4");
    } else {
        is_allowed_media_type = starts_nocase(content_type, "video/") ||
            starts_nocase(content_type, "application/octet-stream") ||
            starts_nocase(content_type, "application/mp4") ||
            starts_nocase(content_type, "application/x-matroska");
    }
    curl_easy_cleanup(curl);
    close_result = fclose(file);

    if (result != CURLE_OK || response_code < 200L || response_code >= 300L || close_result != 0 ||
        is_html || is_manifest || !is_allowed_media_type) {
        if (sink.too_large)
            set_error(error, error_capacity, "Media exceeds the 512 MiB download limit");
        else if (is_manifest)
            set_error(error, error_capacity, "Unsupported streaming manifest; HLS VOD requires an .m3u8 URL");
        else if (is_html)
            set_error(error, error_capacity, "The URL returned a text/HTML page, not a media file");
        else if (!is_allowed_media_type)
            set_error(error, error_capacity, is_audio ? "The response MIME type is not recognized as audio" :
                      "The response MIME type is not recognized as video");
        else if (response_code < 200L || response_code >= 300L) {
            if (error != NULL && error_capacity > 0U)
                (void)snprintf(error, error_capacity, "Media server returned HTTP %ld", response_code);
        } else if (curl_error[0] != '\0')
            set_error(error, error_capacity, curl_error);
        else if (result != CURLE_OK)
            set_error(error, error_capacity, curl_easy_strerror(result));
        else
            set_error(error, error_capacity, "Could not finish writing the media file");
        (void)remove(destination);
        return 0;
    }
    if (sink.bytes == 0U) {
        (void)remove(destination);
        set_error(error, error_capacity, "Media server returned an empty file");
        return 0;
    }
    if (is_youtube_resolved && !youtube_download_has_mp4_signature(destination)) {
        (void)remove(destination);
        set_error(error, error_capacity,
                  "The resolved YouTube stream did not contain a valid MP4 ftyp header; file discarded.");
        return 0;
    }
    if (error != NULL && error_capacity > 0U) error[0] = '\0';
    (void)kind_name;
    return 1;
}

int web_engine_download_video(const char *url, const char *destination, char *error, size_t error_capacity)
{
    return web_engine_download_media(url, destination, "video", error, error_capacity);
}
