# Xbox 360 target — X360Browser 4.0.0

The xSDK target connects the first-party XenonWeb DOM/CSS/layout engine, bounded XenonScript interpreter and XenonMedia decoder primitives to the Xbox visual renderer. XenonScript is a limited experimental subset, not full ECMAScript. The old nonfunctional NetSurf adapter was removed from the active build; XenonWeb is the only page-engine route.

The native request/loading code is maintained in this repository and feeds XenonWeb; it is not a separate third-party browser engine. VisualLite remains an in-project compatibility layout path for cases where the current layout builder cannot emit a frame. HTTP/HTTPS transport and TLS still rely on libcurl/Mbed TLS, the CA bundle and xSDK.

See `../../docs/XENONWEB-ENGINE.md`, `../../docs/XENONMEDIA-ENGINE.md`, `../../docs/STATUS.md` and `../../docs/ENGINE-GAP-AUDIT-3.5.0.md`. The PowerPC build and physical Xbox validation remain release gates.
