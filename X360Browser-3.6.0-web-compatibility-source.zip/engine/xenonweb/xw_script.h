#ifndef XW_SCRIPT_H
#define XW_SCRIPT_H

#include "xw_dom.h"
#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

#define XW_SCRIPT_MAX_SOURCE 32768U
#define XW_SCRIPT_MAX_STATEMENTS 2048U
#define XW_SCRIPT_MAX_VARIABLES 64U
#define XW_SCRIPT_MAX_LOOP_ITERATIONS 64U
#define XW_SCRIPT_MAX_LOOP_DEPTH 4U

typedef struct {
    size_t script_elements;
    size_t executed_scripts;
    size_t statements;
    size_t dom_mutations;
    size_t console_calls;
    size_t alert_calls;
    size_t errors;
    int budget_exhausted;
    int truncated;
} XwScriptStats;

/*
 * XenonScript is a deliberately bounded, first-party JavaScript subset, not an
 * ECMAScript-complete runtime. It runs eligible inline scripts only. Supported
 * constructs are documented in docs/XENONSCRIPT.md. No network, filesystem,
 * dynamic code generation, host calls, unbounded loops, or arbitrary native access exists.
 */
int xw_script_run_document(XwDocument *document, size_t instruction_budget,
                           XwScriptStats *stats);
/* Run an inline event-handler body against the currently loaded document/global scope. */
int xw_script_execute_code(XwDocument *document, const char *code, size_t code_length,
                           size_t instruction_budget, XwScriptStats *stats);

#ifdef __cplusplus
}
#endif
#endif
