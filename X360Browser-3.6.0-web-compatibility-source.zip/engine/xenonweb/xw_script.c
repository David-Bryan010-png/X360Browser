#include "xw_script.h"
#include "xw_css.h"

#include <ctype.h>
#include <math.h>
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>

#define XW_JS_TEXT_CAP 256U
#define XW_JS_NAME_CAP 48U
#define XW_JS_MAX_DEPTH 32U
#define XW_JS_MAX_TOKENS 20000U

typedef enum {
    TOK_END = 0, TOK_ID, TOK_NUMBER, TOK_STRING, TOK_PUNCT, TOK_OPERATOR, TOK_BAD
} XwTokenKind;

typedef struct {
    XwTokenKind kind;
    char text[XW_JS_TEXT_CAP];
    double number;
} XwToken;

typedef enum {
    VAL_UNDEFINED = 0, VAL_NUMBER, VAL_STRING, VAL_BOOL, VAL_NODE,
    VAL_DOCUMENT, VAL_CONSOLE, VAL_ALERT, VAL_STYLE, VAL_CLASSLIST
} XwValueType;

typedef enum {
    REF_NONE = 0, REF_VARIABLE, REF_NODE_TEXT, REF_NODE_ATTRIBUTE, REF_DOCUMENT_TITLE,
    REF_NODE_STYLE_PROPERTY
} XwRefKind;

typedef struct {
    XwValueType type;
    XwRefKind ref_kind;
    unsigned int ref_index;
    uint16_t node_index;
    double number;
    int boolean;
    char string[XW_JS_TEXT_CAP];
    char ref_name[32];
} XwValue;

typedef struct {
    char name[XW_JS_NAME_CAP];
    XwValue value;
} XwVariable;

typedef struct {
    XwDocument *document;
    const char *source;
    size_t source_length;
    size_t position;
    size_t token_start;
    size_t tokens;
    size_t remaining;
    unsigned int depth;
    int execute;
    int failed;
    XwToken token;
    XwVariable variables[XW_SCRIPT_MAX_VARIABLES];
    size_t variable_count;
    XwScriptStats *stats;
} XwParser;

static XwParser g_parser;
static XwParser g_eval_parser;
static XwParser g_loop_parsers[XW_SCRIPT_MAX_LOOP_DEPTH];
static size_t g_loop_depth;

static XwValue value_undefined(void)
{
    XwValue value;
    memset(&value, 0, sizeof(value));
    value.type = VAL_UNDEFINED;
    value.node_index = XW_DOM_NONE;
    return value;
}

static XwValue value_string(const char *text)
{
    XwValue value = value_undefined();
    value.type = VAL_STRING;
    if (text != NULL) (void)snprintf(value.string, sizeof(value.string), "%s", text);
    return value;
}

static XwValue value_number(double number)
{
    XwValue value = value_undefined();
    value.type = VAL_NUMBER;
    value.number = number;
    return value;
}

static XwValue value_bool(int boolean)
{
    XwValue value = value_undefined();
    value.type = VAL_BOOL;
    value.boolean = boolean != 0;
    return value;
}

static void clear_reference(XwValue *value)
{
    value->ref_kind = REF_NONE;
    value->ref_index = 0U;
    value->ref_name[0] = '\0';
}

static void skip_ignored(XwParser *parser)
{
    while (parser->position < parser->source_length) {
        char c = parser->source[parser->position];
        if (isspace((unsigned char)c)) {
            ++parser->position;
            continue;
        }
        if (c == '/' && parser->position + 1U < parser->source_length &&
            parser->source[parser->position + 1U] == '/') {
            parser->position += 2U;
            while (parser->position < parser->source_length && parser->source[parser->position] != '\n')
                ++parser->position;
            continue;
        }
        if (c == '/' && parser->position + 1U < parser->source_length &&
            parser->source[parser->position + 1U] == '*') {
            parser->position += 2U;
            while (parser->position + 1U < parser->source_length &&
                   !(parser->source[parser->position] == '*' && parser->source[parser->position + 1U] == '/'))
                ++parser->position;
            if (parser->position + 1U >= parser->source_length) {
                parser->failed = 1;
                return;
            }
            parser->position += 2U;
            continue;
        }
        break;
    }
}

static void next_token(XwParser *parser)
{
    size_t start;
    size_t length;
    char c;
    memset(&parser->token, 0, sizeof(parser->token));
    skip_ignored(parser);
    parser->token_start = parser->position;
    if (parser->failed || parser->position >= parser->source_length) {
        parser->token.kind = TOK_END;
        return;
    }
    if (++parser->tokens > XW_JS_MAX_TOKENS) {
        parser->failed = 1;
        parser->token.kind = TOK_BAD;
        return;
    }
    c = parser->source[parser->position];
    if (isalpha((unsigned char)c) || c == '_' || c == '$') {
        start = parser->position++;
        while (parser->position < parser->source_length) {
            c = parser->source[parser->position];
            if (!(isalnum((unsigned char)c) || c == '_' || c == '$')) break;
            ++parser->position;
        }
        length = parser->position - start;
        if (length >= sizeof(parser->token.text)) { parser->failed = 1; parser->token.kind = TOK_BAD; return; }
        memcpy(parser->token.text, parser->source + start, length);
        parser->token.kind = TOK_ID;
        return;
    }
    if (isdigit((unsigned char)c) || (c == '.' && parser->position + 1U < parser->source_length &&
                                       isdigit((unsigned char)parser->source[parser->position + 1U]))) {
        char number[64];
        char *end = NULL;
        start = parser->position++;
        while (parser->position < parser->source_length) {
            c = parser->source[parser->position];
            if (!(isalnum((unsigned char)c) || c == '.' || c == '+' || c == '-')) break;
            if ((c == '+' || c == '-') && parser->position > start &&
                parser->source[parser->position - 1U] != 'e' && parser->source[parser->position - 1U] != 'E') break;
            ++parser->position;
        }
        length = parser->position - start;
        if (length >= sizeof(number)) { parser->failed = 1; parser->token.kind = TOK_BAD; return; }
        memcpy(number, parser->source + start, length);
        number[length] = '\0';
        parser->token.number = strtod(number, &end);
        if (end == number || *end != '\0' || !isfinite(parser->token.number)) {
            parser->failed = 1; parser->token.kind = TOK_BAD; return;
        }
        parser->token.kind = TOK_NUMBER;
        (void)snprintf(parser->token.text, sizeof(parser->token.text), "%s", number);
        return;
    }
    if (c == '\'' || c == '"') {
        char quote = c;
        size_t out = 0U;
        ++parser->position;
        while (parser->position < parser->source_length && parser->source[parser->position] != quote) {
            c = parser->source[parser->position++];
            if (c == '\\') {
                if (parser->position >= parser->source_length) { parser->failed = 1; break; }
                c = parser->source[parser->position++];
                if (c == 'n') c = '\n';
                else if (c == 'r') c = '\r';
                else if (c == 't') c = '\t';
                else if (c != '\\' && c != '\'' && c != '"') { parser->failed = 1; break; }
            }
            if (out + 1U >= sizeof(parser->token.text)) { parser->failed = 1; break; }
            parser->token.text[out++] = c;
        }
        if (parser->position >= parser->source_length || parser->source[parser->position] != quote)
            parser->failed = 1;
        else ++parser->position;
        parser->token.kind = parser->failed ? TOK_BAD : TOK_STRING;
        return;
    }
    {
        static const char *const multi_ops[] = {
            "===", "!==", "++", "--", "+=", "-=", "*=", "/=", "==", "!=", "<=", ">=", "&&", "||"
        };
        size_t i;
        for (i = 0U; i < sizeof(multi_ops) / sizeof(multi_ops[0]); ++i) {
            size_t n = strlen(multi_ops[i]);
            if (parser->position + n <= parser->source_length &&
                memcmp(parser->source + parser->position, multi_ops[i], n) == 0) {
                memcpy(parser->token.text, multi_ops[i], n + 1U);
                parser->token.kind = TOK_OPERATOR;
                parser->position += n;
                return;
            }
        }
    }
    parser->token.text[0] = c;
    parser->token.text[1] = '\0';
    parser->token.kind = strchr("(){};,.", c) != NULL ? TOK_PUNCT :
                         strchr("+-*/!<>=", c) != NULL ? TOK_OPERATOR : TOK_BAD;
    if (parser->token.kind == TOK_BAD) parser->failed = 1;
    ++parser->position;
}

static int token_is(const XwParser *parser, const char *text)
{
    return strcmp(parser->token.text, text) == 0;
}

static int accept(XwParser *parser, const char *text)
{
    if (!token_is(parser, text)) return 0;
    next_token(parser);
    return 1;
}

static int expect(XwParser *parser, const char *text)
{
    if (!accept(parser, text)) { parser->failed = 1; return 0; }
    return 1;
}

static int value_truthy(const XwValue *value)
{
    if (value->type == VAL_UNDEFINED) return 0;
    if (value->type == VAL_BOOL) return value->boolean;
    if (value->type == VAL_NUMBER) return value->number != 0.0 && !isnan(value->number);
    if (value->type == VAL_STRING) return value->string[0] != '\0';
    return 1;
}

static void value_to_string(const XwValue *value, char *output, size_t capacity)
{
    if (capacity == 0U) return;
    output[0] = '\0';
    switch (value->type) {
    case VAL_STRING: (void)snprintf(output, capacity, "%s", value->string); break;
    case VAL_NUMBER: (void)snprintf(output, capacity, "%.15g", value->number); break;
    case VAL_BOOL: (void)snprintf(output, capacity, "%s", value->boolean ? "true" : "false"); break;
    case VAL_NODE: (void)snprintf(output, capacity, "[object Element]"); break;
    case VAL_DOCUMENT: (void)snprintf(output, capacity, "[object Document]"); break;
    case VAL_CONSOLE: (void)snprintf(output, capacity, "[object Console]"); break;
    case VAL_ALERT: (void)snprintf(output, capacity, "[function alert]"); break;
    case VAL_STYLE: (void)snprintf(output, capacity, "[object CSSStyleDeclaration]"); break;
    case VAL_CLASSLIST: (void)snprintf(output, capacity, "[object DOMTokenList]"); break;
    default: (void)snprintf(output, capacity, "undefined"); break;
    }
}

static XwValue *find_variable(XwParser *parser, const char *name, int create)
{
    size_t i;
    for (i = 0U; i < parser->variable_count; ++i)
        if (strcmp(parser->variables[i].name, name) == 0) return &parser->variables[i].value;
    if (!create || parser->variable_count >= XW_SCRIPT_MAX_VARIABLES || strlen(name) >= XW_JS_NAME_CAP)
        return NULL;
    (void)snprintf(parser->variables[parser->variable_count].name,
                   sizeof(parser->variables[parser->variable_count].name), "%s", name);
    parser->variables[parser->variable_count].value = value_undefined();
    return &parser->variables[parser->variable_count++].value;
}


static XwValue parse_expression(XwParser *parser, int min_precedence);
static void parse_statement(XwParser *parser);

static int operator_precedence(const char *op)
{
    if (strcmp(op, "||") == 0) return 1;
    if (strcmp(op, "&&") == 0) return 2;
    if (strcmp(op, "==") == 0 || strcmp(op, "===") == 0 || strcmp(op, "!=") == 0 || strcmp(op, "!==") == 0) return 3;
    if (strcmp(op, "<") == 0 || strcmp(op, ">") == 0 || strcmp(op, "<=") == 0 || strcmp(op, ">=") == 0) return 4;
    if (strcmp(op, "+") == 0 || strcmp(op, "-") == 0) return 5;
    if (strcmp(op, "*") == 0 || strcmp(op, "/") == 0) return 6;
    return 0;
}

static double value_to_number(const XwValue *value)
{
    char *end = NULL;
    if (value->type == VAL_NUMBER) return value->number;
    if (value->type == VAL_BOOL) return value->boolean ? 1.0 : 0.0;
    if (value->type == VAL_STRING) {
        double number = strtod(value->string, &end);
        return end != value->string && *end == '\0' ? number : 0.0;
    }
    return 0.0;
}

static XwValue apply_operator(const char *op, XwValue left, XwValue right)
{
    char a[XW_JS_TEXT_CAP], b[XW_JS_TEXT_CAP], joined[XW_JS_TEXT_CAP];
    int result = 0;
    clear_reference(&left);
    clear_reference(&right);
    if (strcmp(op, "+") == 0 && (left.type == VAL_STRING || right.type == VAL_STRING)) {
        value_to_string(&left, a, sizeof(a)); value_to_string(&right, b, sizeof(b));
        {
            size_t a_len = strlen(a);
            size_t b_len = strlen(b);
            if (a_len >= sizeof(joined)) a_len = sizeof(joined) - 1U;
            if (b_len > sizeof(joined) - a_len - 1U) b_len = sizeof(joined) - a_len - 1U;
            memcpy(joined, a, a_len);
            memcpy(joined + a_len, b, b_len);
            joined[a_len + b_len] = '\0';
        }
        return value_string(joined);
    }
    if (strcmp(op, "||") == 0) return value_bool(value_truthy(&left) || value_truthy(&right));
    if (strcmp(op, "&&") == 0) return value_bool(value_truthy(&left) && value_truthy(&right));
    if (strcmp(op, "==") == 0 || strcmp(op, "===") == 0 ||
        strcmp(op, "!=") == 0 || strcmp(op, "!==") == 0) {
        if (left.type == right.type && left.type == VAL_STRING) result = strcmp(left.string, right.string) == 0;
        else if (left.type == VAL_BOOL && right.type == VAL_BOOL) result = left.boolean == right.boolean;
        else result = value_to_number(&left) == value_to_number(&right);
        if (strcmp(op, "!=") == 0 || strcmp(op, "!==") == 0) result = !result;
        return value_bool(result);
    }
    if (left.type == VAL_STRING && right.type == VAL_STRING &&
        (strcmp(op, "<") == 0 || strcmp(op, ">") == 0 || strcmp(op, "<=") == 0 || strcmp(op, ">=") == 0)) {
        int cmp = strcmp(left.string, right.string);
        if (strcmp(op, "<") == 0) result = cmp < 0;
        else if (strcmp(op, ">") == 0) result = cmp > 0;
        else if (strcmp(op, "<=") == 0) result = cmp <= 0;
        else result = cmp >= 0;
        return value_bool(result);
    }
    {
        double x = value_to_number(&left), y = value_to_number(&right);
        if (strcmp(op, "+") == 0) return value_number(x + y);
        if (strcmp(op, "-") == 0) return value_number(x - y);
        if (strcmp(op, "*") == 0) return value_number(x * y);
        if (strcmp(op, "/") == 0) return y == 0.0 ? value_undefined() : value_number(x / y);
        if (strcmp(op, "<") == 0) result = x < y;
        else if (strcmp(op, ">") == 0) result = x > y;
        else if (strcmp(op, "<=") == 0) result = x <= y;
        else if (strcmp(op, ">=") == 0) result = x >= y;
        else return value_undefined();
        return value_bool(result);
    }
}

static int style_property_name(const char *javascript_name, char *css_name, size_t capacity)
{
    static const struct { const char *js; const char *css; } names[] = {
        {"color", "color"}, {"backgroundColor", "background-color"},
        {"background", "background"}, {"display", "display"},
        {"fontSize", "font-size"}, {"fontWeight", "font-weight"},
        {"fontStyle", "font-style"}, {"textAlign", "text-align"},
        {"textDecoration", "text-decoration"}, {"textTransform", "text-transform"},
        {"lineHeight", "line-height"}, {"margin", "margin"},
        {"marginTop", "margin-top"}, {"marginBottom", "margin-bottom"},
        {"marginLeft", "margin-left"}, {"marginRight", "margin-right"},
        {"padding", "padding"}, {"border", "border"},
        {"borderColor", "border-color"}, {"borderWidth", "border-width"},
        {"width", "width"}
    };
    size_t i;
    if (css_name == NULL || capacity == 0U || javascript_name == NULL) return 0;
    for (i = 0U; i < sizeof(names) / sizeof(names[0]); ++i) {
        if (strcmp(javascript_name, names[i].js) == 0) {
            (void)snprintf(css_name, capacity, "%s", names[i].css);
            return 1;
        }
    }
    return 0;
}

static int find_inline_style_value(const char *style, const char *wanted, char *output, size_t capacity)
{
    const char *cursor = style;
    if (output == NULL || capacity == 0U) return 0;
    output[0] = '\0';
    while (cursor != NULL && *cursor != '\0') {
        const char *end = strchr(cursor, ';');
        const char *colon;
        size_t segment_length = end != NULL ? (size_t)(end - cursor) : strlen(cursor);
        char name[64];
        const char *name_start = cursor;
        const char *name_end;
        const char *value_start;
        const char *value_end;
        size_t n;
        while (segment_length > 0U && isspace((unsigned char)*name_start)) { ++name_start; --segment_length; }
        colon = memchr(name_start, ':', segment_length);
        if (colon != NULL) {
            name_end = colon;
            while (name_end > name_start && isspace((unsigned char)name_end[-1])) --name_end;
            n = (size_t)(name_end - name_start);
            if (n < sizeof(name)) {
                memcpy(name, name_start, n); name[n] = '\0';
                if (strcasecmp(name, wanted) == 0) {
                    value_start = colon + 1;
                    value_end = cursor + (end != NULL ? (size_t)(end - cursor) : strlen(cursor));
                    while (value_start < value_end && isspace((unsigned char)*value_start)) ++value_start;
                    while (value_end > value_start && isspace((unsigned char)value_end[-1])) --value_end;
                    n = (size_t)(value_end - value_start);
                    if (n >= capacity) n = capacity - 1U;
                    memcpy(output, value_start, n); output[n] = '\0';
                    return 1;
                }
            }
        }
        cursor = end != NULL ? end + 1 : NULL;
    }
    return 0;
}

static int write_inline_style_value(XwDocument *document, uint16_t node, const char *name, const char *value)
{
    char new_style[512];
    const char *old_style = xw_dom_attribute(document, node, "style");
    const char *cursor = old_style != NULL ? old_style : "";
    size_t used = 0U;
    int found = 0;
    if (strlen(name) >= 64U || strlen(value) >= 192U || strlen(cursor) >= 480U) return 0;
    new_style[0] = '\0';
    while (*cursor != '\0') {
        const char *end = strchr(cursor, ';');
        const char *colon;
        size_t length = end != NULL ? (size_t)(end - cursor) : strlen(cursor);
        const char *start = cursor;
        const char *name_end;
        char current_name[64];
        size_t n;
        int replace_this = 0;
        while (length > 0U && isspace((unsigned char)*start)) { ++start; --length; }
        colon = memchr(start, ':', length);
        if (colon != NULL) {
            name_end = colon;
            while (name_end > start && isspace((unsigned char)name_end[-1])) --name_end;
            n = (size_t)(name_end - start);
            if (n < sizeof(current_name)) {
                memcpy(current_name, start, n); current_name[n] = '\0';
                if (strcasecmp(current_name, name) == 0) { found = 1; replace_this = 1; }
            }
        }
        if (!replace_this && length > 0U) {
            if (used + length + 2U >= sizeof(new_style)) return 0;
            memcpy(new_style + used, start, length); used += length;
            new_style[used++] = ';'; new_style[used++] = ' ';
            new_style[used] = '\0';
        }
        cursor = end != NULL ? end + 1 : cursor + strlen(cursor);
    }
    (void)found;
    if (used + strlen(name) + strlen(value) + 5U >= sizeof(new_style)) return 0;
    used += (size_t)snprintf(new_style + used, sizeof(new_style) - used, "%s: %s;", name, value);
    (void)used;
    return xw_dom_set_attribute(document, node, "style", new_style);
}

static XwValue read_style_property(XwParser *parser, XwValue value, const char *property)
{
    char css_name[64];
    char current[160];
    if (value.type != VAL_STYLE || value.node_index >= parser->document->node_count ||
        !style_property_name(property, css_name, sizeof(css_name))) return value_undefined();
    (void)find_inline_style_value(xw_dom_attribute(parser->document, value.node_index, "style"),
                                  css_name, current, sizeof(current));
    {
        uint16_t node_index = value.node_index;
        value = value_string(current);
        value.ref_kind = REF_NODE_STYLE_PROPERTY;
        value.ref_index = node_index;
        (void)snprintf(value.ref_name, sizeof(value.ref_name), "%.31s", css_name);
    }
    return value;
}

static int class_token_valid(const char *token)
{
    size_t i;
    size_t length;
    if (token == NULL || token[0] == '\0') return 0;
    length = strlen(token);
    if (length >= 48U) return 0;
    for (i = 0U; i < length; ++i) if (isspace((unsigned char)token[i])) return 0;
    return 1;
}

static size_t class_tokens_read(const char *source, char tokens[32][48])
{
    size_t count = 0U;
    const char *cursor = source != NULL ? source : "";
    while (*cursor != '\0' && count < 32U) {
        const char *start;
        size_t length;
        while (isspace((unsigned char)*cursor)) ++cursor;
        if (*cursor == '\0') break;
        start = cursor;
        while (*cursor != '\0' && !isspace((unsigned char)*cursor)) ++cursor;
        length = (size_t)(cursor - start);
        if (length == 0U || length >= sizeof(tokens[0])) continue;
        memcpy(tokens[count], start, length);
        tokens[count][length] = '\0';
        ++count;
    }
    return count;
}

static int class_token_find(char tokens[32][48], size_t count, const char *wanted)
{
    size_t i;
    for (i = 0U; i < count; ++i) if (strcmp(tokens[i], wanted) == 0) return (int)i;
    return -1;
}

static int class_list_apply(XwDocument *document, uint16_t node_index, const char *method,
                            const char *arguments[8], size_t argument_count,
                            int has_force, int force_value, int *boolean_result)
{
    char tokens[32][48];
    char output[512];
    size_t count = class_tokens_read(xw_dom_attribute(document, node_index, "class"), tokens);
    size_t i;
    int changed = 0;
    if (boolean_result != NULL) *boolean_result = 0;
    if (strcmp(method, "contains") == 0) {
        if (argument_count != 1U || !class_token_valid(arguments[0])) return 0;
        if (boolean_result != NULL) *boolean_result = class_token_find(tokens, count, arguments[0]) >= 0;
        return 1;
    }
    if (strcmp(method, "toggle") == 0) {
        int present;
        int want;
        if (argument_count < 1U || argument_count > 2U || !class_token_valid(arguments[0])) return 0;
        present = class_token_find(tokens, count, arguments[0]) >= 0;
        want = has_force ? force_value : !present;
        if (want && !present && count < 32U) {
            (void)snprintf(tokens[count++], sizeof(tokens[0]), "%s", arguments[0]);
            changed = 1;
        } else if (!want && present) {
            size_t index = (size_t)class_token_find(tokens, count, arguments[0]);
            for (i = index; i + 1U < count; ++i) memcpy(tokens[i], tokens[i + 1U], sizeof(tokens[i]));
            --count; changed = 1;
        }
        if (boolean_result != NULL) *boolean_result = want;
    } else if (strcmp(method, "add") == 0 || strcmp(method, "remove") == 0) {
        if (argument_count == 0U) return 0;
        for (i = 0U; i < argument_count; ++i) {
            int found;
            if (!class_token_valid(arguments[i])) return 0;
            found = class_token_find(tokens, count, arguments[i]);
            if (strcmp(method, "add") == 0) {
                if (found < 0 && count < 32U) {
                    (void)snprintf(tokens[count++], sizeof(tokens[0]), "%s", arguments[i]);
                    changed = 1;
                }
            } else if (found >= 0) {
                size_t index = (size_t)found;
                size_t j;
                for (j = index; j + 1U < count; ++j) memcpy(tokens[j], tokens[j + 1U], sizeof(tokens[j]));
                --count; changed = 1;
            }
        }
    } else return 0;
    if (changed) {
        size_t used = 0U;
        output[0] = '\0';
        for (i = 0U; i < count; ++i) {
            size_t length = strlen(tokens[i]);
            if (used + length + (i != 0U ? 1U : 0U) >= sizeof(output)) return 0;
            if (i != 0U) output[used++] = ' ';
            memcpy(output + used, tokens[i], length);
            used += length;
            output[used] = '\0';
        }
        if (!xw_dom_set_attribute(document, node_index, "class", output)) return 0;
    }
    return 1;
}

static XwValue read_node_property(XwParser *parser, XwValue value, const char *property)
{
    const char *attribute_name = NULL;
    char text[XW_JS_TEXT_CAP];
    if (value.type == VAL_DOCUMENT) {
        if (strcmp(property, "nodeType") == 0) return value_number(9.0);
        if (strcmp(property, "nodeName") == 0) return value_string("#document");
        if (strcmp(property, "title") == 0) {
            size_t i;
            for (i = 0U; i < parser->document->node_count; ++i) {
                if (parser->document->nodes[i].type == XW_NODE_ELEMENT &&
                    strcasecmp(xw_dom_string(parser->document, parser->document->nodes[i].name_offset), "title") == 0) {
                    xw_dom_text_content(parser->document, (uint16_t)i, text, sizeof(text));
                    value = value_string(text);
                    value.ref_kind = REF_DOCUMENT_TITLE;
                    return value;
                }
            }
            value = value_string(""); value.ref_kind = REF_DOCUMENT_TITLE; return value;
        }
        if (strcmp(property, "body") == 0) {
            size_t i;
            for (i = 0U; i < parser->document->node_count; ++i)
                if (parser->document->nodes[i].type == XW_NODE_ELEMENT &&
                    strcasecmp(xw_dom_string(parser->document, parser->document->nodes[i].name_offset), "body") == 0) {
                    XwValue node = value_undefined(); node.type = VAL_NODE; node.node_index = (uint16_t)i; return node;
                }
        }
        if (strcmp(property, "documentElement") == 0) {
            uint16_t child = parser->document->nodes[parser->document->root].first_child;
            while (child != XW_DOM_NONE) {
                if (parser->document->nodes[child].type == XW_NODE_ELEMENT) {
                    value = value_undefined(); value.type = VAL_NODE; value.node_index = child; return value;
                }
                child = parser->document->nodes[child].next_sibling;
            }
        }
        return value_undefined();
    }
    if (value.type != VAL_NODE || value.node_index >= parser->document->node_count) return value_undefined();
    if (strcmp(property, "textContent") == 0 || strcmp(property, "innerText") == 0) {
        {
            uint16_t node_index = value.node_index;
            xw_dom_text_content(parser->document, node_index, text, sizeof(text));
            value = value_string(text);
            value.ref_kind = REF_NODE_TEXT;
            value.ref_index = node_index;
            return value;
        }
    }
    if (strcmp(property, "nodeValue") == 0) {
        const uint16_t node_index = value.node_index;
        const XwDomNode *node = &parser->document->nodes[node_index];
        if (node->type == XW_NODE_TEXT) {
            value = value_string(xw_dom_string(parser->document, node->value_offset));
            value.ref_kind = REF_NODE_TEXT;
            value.ref_index = node_index;
            return value;
        }
        return value_undefined();
    }
    if (strcmp(property, "style") == 0 || strcmp(property, "classList") == 0) {
        uint16_t node_index = value.node_index;
        value = value_undefined();
        value.type = strcmp(property, "style") == 0 ? VAL_STYLE : VAL_CLASSLIST;
        value.node_index = node_index;
        return value;
    }
    if (strcmp(property, "nodeType") == 0) {
        const uint8_t node_type = parser->document->nodes[value.node_index].type;
        return value_number(node_type == XW_NODE_ELEMENT ? 1.0 :
                            node_type == XW_NODE_TEXT ? 3.0 : 9.0);
    }
    if (strcmp(property, "tagName") == 0 || strcmp(property, "nodeName") == 0) {
        const char *name = xw_dom_string(parser->document, parser->document->nodes[value.node_index].name_offset);
        size_t i;
        (void)snprintf(text, sizeof(text), "%s", name);
        if (strcmp(property, "tagName") == 0 &&
            parser->document->nodes[value.node_index].type != XW_NODE_ELEMENT) return value_undefined();
        for (i = 0U; text[i] != '\0'; ++i) text[i] = (char)toupper((unsigned char)text[i]);
        return value_string(text);
    }
    if (strcmp(property, "parentElement") == 0 || strcmp(property, "parentNode") == 0) {
        uint16_t parent = parser->document->nodes[value.node_index].parent;
        if (parent != XW_DOM_NONE && parent < parser->document->node_count &&
            (strcmp(property, "parentNode") == 0 ||
             parser->document->nodes[parent].type == XW_NODE_ELEMENT)) {
            value = value_undefined(); value.type = VAL_NODE; value.node_index = parent; return value;
        }
        return value_undefined();
    }
    if (strcmp(property, "firstChild") == 0 || strcmp(property, "lastChild") == 0 ||
        strcmp(property, "firstElementChild") == 0 || strcmp(property, "lastElementChild") == 0) {
        const int element_only = strstr(property, "Element") != NULL;
        const int last = strncmp(property, "last", 4U) == 0;
        uint16_t child = parser->document->nodes[value.node_index].first_child;
        uint16_t found = XW_DOM_NONE;
        while (child != XW_DOM_NONE) {
            if (!element_only || parser->document->nodes[child].type == XW_NODE_ELEMENT) {
                found = child;
                if (!last) break;
            }
            child = parser->document->nodes[child].next_sibling;
        }
        if (found != XW_DOM_NONE) { value = value_undefined(); value.type = VAL_NODE; value.node_index = found; return value; }
        return value_undefined();
    }
    if (strcmp(property, "nextSibling") == 0 || strcmp(property, "nextElementSibling") == 0 ||
        strcmp(property, "previousSibling") == 0 || strcmp(property, "previousElementSibling") == 0) {
        const int element_only = strstr(property, "Element") != NULL;
        const int previous = strncmp(property, "previous", 8U) == 0;
        const XwDomNode *node = &parser->document->nodes[value.node_index];
        uint16_t found = XW_DOM_NONE;
        uint16_t cursor;
        if (!previous) {
            cursor = node->next_sibling;
            while (cursor != XW_DOM_NONE) {
                if (!element_only || parser->document->nodes[cursor].type == XW_NODE_ELEMENT) { found = cursor; break; }
                cursor = parser->document->nodes[cursor].next_sibling;
            }
        } else if (node->parent != XW_DOM_NONE && node->parent < parser->document->node_count) {
            cursor = parser->document->nodes[node->parent].first_child;
            while (cursor != XW_DOM_NONE && cursor != value.node_index) {
                if (!element_only || parser->document->nodes[cursor].type == XW_NODE_ELEMENT) found = cursor;
                cursor = parser->document->nodes[cursor].next_sibling;
            }
        }
        if (found != XW_DOM_NONE) { value = value_undefined(); value.type = VAL_NODE; value.node_index = found; return value; }
        return value_undefined();
    }
    if (strcmp(property, "childElementCount") == 0) {
        uint16_t child = parser->document->nodes[value.node_index].first_child;
        size_t count = 0U;
        while (child != XW_DOM_NONE) {
            if (parser->document->nodes[child].type == XW_NODE_ELEMENT) ++count;
            child = parser->document->nodes[child].next_sibling;
        }
        return value_number((double)count);
    }
    if (strcmp(property, "id") == 0) attribute_name = "id";
    else if (strcmp(property, "className") == 0) attribute_name = "class";
    else if (strcmp(property, "value") == 0) attribute_name = "value";
    else if (strcmp(property, "href") == 0) attribute_name = "href";
    else if (strcmp(property, "src") == 0) attribute_name = "src";
    else if (strcmp(property, "checked") == 0) attribute_name = "checked";
    else if (strcmp(property, "disabled") == 0) attribute_name = "disabled";
    else if (strcmp(property, "selected") == 0) attribute_name = "selected";
    else if (strcmp(property, "required") == 0) attribute_name = "required";
    else if (strcmp(property, "name") == 0) attribute_name = "name";
    else if (strcmp(property, "type") == 0) attribute_name = "type";
    else if (strcmp(property, "placeholder") == 0) attribute_name = "placeholder";
    else if (strcmp(property, "title") == 0) attribute_name = "title";
    else if (strcmp(property, "alt") == 0) attribute_name = "alt";
    else if (strcmp(property, "target") == 0) attribute_name = "target";
    else if (strcmp(property, "rel") == 0) attribute_name = "rel";
    else if (strcmp(property, "readonly") == 0 || strcmp(property, "readOnly") == 0) attribute_name = "readonly";
    else if (strcmp(property, "multiple") == 0) attribute_name = "multiple";
    if (attribute_name != NULL) {
        {
            uint16_t node_index = value.node_index;
            const char *current = xw_dom_attribute(parser->document, node_index, attribute_name);
            if (strcmp(property, "checked") == 0 || strcmp(property, "disabled") == 0 ||
                strcmp(property, "selected") == 0 || strcmp(property, "required") == 0 ||
                strcmp(property, "readOnly") == 0 || strcmp(property, "readonly") == 0 ||
                strcmp(property, "multiple") == 0) {
                XwValue boolean_value = value_bool(current != NULL);
                boolean_value.ref_kind = REF_NODE_ATTRIBUTE;
                boolean_value.ref_index = node_index;
                (void)snprintf(boolean_value.ref_name, sizeof(boolean_value.ref_name), "%s", attribute_name);
                return boolean_value;
            }
            value = value_string(current != NULL ? current : "");
            value.ref_kind = REF_NODE_ATTRIBUTE;
            value.ref_index = node_index;
            (void)snprintf(value.ref_name, sizeof(value.ref_name), "%s", attribute_name);
            return value;
        }
    }
    return value_undefined();
}

static XwValue parse_primary(XwParser *parser)
{
    XwValue value = value_undefined();
    if (++parser->depth > XW_JS_MAX_DEPTH) { parser->failed = 1; --parser->depth; return value; }
    if (parser->token.kind == TOK_NUMBER) {
        value = value_number(parser->token.number);
        next_token(parser);
    } else if (parser->token.kind == TOK_STRING) {
        value = value_string(parser->token.text);
        next_token(parser);
    } else if (accept(parser, "(")) {
        value = parse_expression(parser, 1);
        (void)expect(parser, ")");
        clear_reference(&value);
    } else if (accept(parser, "!")) {
        XwValue inner = parse_primary(parser);
        value = value_bool(!value_truthy(&inner));
    } else if (accept(parser, "-")) {
        XwValue inner = parse_primary(parser);
        value = value_number(-value_to_number(&inner));
    } else if (token_is(parser, "++") || token_is(parser, "--")) {
        int decrement = token_is(parser, "--");
        next_token(parser);
        if (parser->token.kind != TOK_ID) parser->failed = 1;
        else {
            char name[XW_JS_NAME_CAP];
            XwValue *stored;
            size_t name_length = strlen(parser->token.text);
            if (name_length >= sizeof(name)) {
                parser->failed = 1;
                --parser->depth;
                return value;
            }
            memcpy(name, parser->token.text, name_length + 1U);
            next_token(parser);
            stored = find_variable(parser, name, 0);
            if (stored == NULL) parser->failed = 1;
            else {
                double number = value_to_number(stored) + (decrement ? -1.0 : 1.0);
                if (parser->execute) *stored = value_number(number);
                value = value_number(number);
            }
        }
    } else if (parser->token.kind == TOK_ID) {
        char identifier[XW_JS_TEXT_CAP];
        (void)snprintf(identifier, sizeof(identifier), "%s", parser->token.text);
        next_token(parser);
        if (strcmp(identifier, "true") == 0) value = value_bool(1);
        else if (strcmp(identifier, "false") == 0 || strcmp(identifier, "null") == 0 || strcmp(identifier, "undefined") == 0)
            value = strcmp(identifier, "false") == 0 ? value_bool(0) : value_undefined();
        else if (strcmp(identifier, "document") == 0) value.type = VAL_DOCUMENT;
        else if (strcmp(identifier, "console") == 0) value.type = VAL_CONSOLE;
        else if (strcmp(identifier, "alert") == 0) value.type = VAL_ALERT;
        else {
            XwValue *stored = find_variable(parser, identifier, 0);
            if (stored != NULL) value = *stored;
            value.ref_kind = REF_VARIABLE;
            /* Indexes are based on variable records, not the nested value subobjects. */
            {
                size_t i;
                value.ref_index = UINT_MAX;
                for (i = 0U; i < parser->variable_count; ++i)
                    if (strcmp(parser->variables[i].name, identifier) == 0) { value.ref_index = (unsigned int)i; break; }
                if (value.ref_index == UINT_MAX) value.ref_kind = REF_NONE;
            }
        }
    } else {
        parser->failed = 1;
    }

    while (!parser->failed) {
        if (accept(parser, ".")) {
            char property[XW_JS_TEXT_CAP];
            if (parser->token.kind != TOK_ID) { parser->failed = 1; break; }
            (void)snprintf(property, sizeof(property), "%s", parser->token.text);
            next_token(parser);
            if (value.type == VAL_CONSOLE && strcmp(property, "log") == 0) {
                value.type = VAL_CONSOLE;
            } else if (value.type == VAL_DOCUMENT &&
                (strcmp(property, "getElementById") == 0 || strcmp(property, "querySelector") == 0 ||
                 strcmp(property, "createElement") == 0 || strcmp(property, "createTextNode") == 0) &&
                accept(parser, "(")) {
                XwValue argument = parse_expression(parser, 1);
                char selector[XW_JS_TEXT_CAP];
                uint16_t node_index = XW_DOM_NONE;
                (void)expect(parser, ")");
                value_to_string(&argument, selector, sizeof(selector));
                if (strcmp(property, "getElementById") == 0) node_index = xw_dom_find_by_id(parser->document, selector);
                else if (strcmp(property, "querySelector") == 0) node_index = xw_css_query_selector(parser->document, selector);
                else if (parser->execute && strcmp(property, "createElement") == 0)
                    node_index = xw_dom_create_element(parser->document, selector);
                else if (parser->execute && strcmp(property, "createTextNode") == 0)
                    node_index = xw_dom_create_text_node(parser->document, selector);
                value = value_undefined();
                if (node_index != XW_DOM_NONE) { value.type = VAL_NODE; value.node_index = node_index; }
            } else if (value.type == VAL_NODE &&
                (strcmp(property, "querySelector") == 0 || strcmp(property, "closest") == 0 ||
                 strcmp(property, "matches") == 0) && accept(parser, "(")) {
                XwValue argument = parse_expression(parser, 1);
                char selector[XW_JS_TEXT_CAP];
                uint16_t node_index = value.node_index;
                uint16_t match = XW_DOM_NONE;
                int matches = 0;
                value_to_string(&argument, selector, sizeof(selector));
                (void)expect(parser, ")");
                if (strcmp(property, "querySelector") == 0)
                    match = xw_css_query_selector_within(parser->document, node_index, selector);
                else if (strcmp(property, "closest") == 0) {
                    uint16_t cursor = node_index;
                    size_t depth = 0U;
                    while (cursor != XW_DOM_NONE && cursor < parser->document->node_count && depth++ < XW_DOM_MAX_DEPTH) {
                        if (xw_css_matches_selector(parser->document, cursor, selector)) { match = cursor; break; }
                        cursor = parser->document->nodes[cursor].parent;
                    }
                } else matches = xw_css_matches_selector(parser->document, node_index, selector);
                if (strcmp(property, "matches") == 0) value = value_bool(matches);
                else {
                    value = value_undefined();
                    if (match != XW_DOM_NONE) { value.type = VAL_NODE; value.node_index = match; }
                }
            } else if (value.type == VAL_NODE && strcmp(property, "remove") == 0 && accept(parser, "(")) {
                uint16_t node_index = value.node_index;
                uint16_t parent_index = parser->document->nodes[node_index].parent;
                if (!token_is(parser, ")")) parser->failed = 1;
                (void)expect(parser, ")");
                if (parser->execute && parent_index != XW_DOM_NONE &&
                    xw_dom_remove_child(parser->document, parent_index, node_index)) ++parser->stats->dom_mutations;
                value = value_undefined();
            } else if (value.type == VAL_NODE &&
                (strcmp(property, "appendChild") == 0 || strcmp(property, "removeChild") == 0) &&
                accept(parser, "(")) {
                XwValue argument = parse_expression(parser, 1);
                uint16_t parent_index = value.node_index;
                uint16_t child_index = argument.type == VAL_NODE ? argument.node_index : XW_DOM_NONE;
                const int is_append = strcmp(property, "appendChild") == 0;
                (void)expect(parser, ")");
                if (parser->execute && child_index != XW_DOM_NONE &&
                    (is_append ? xw_dom_append_child(parser->document, parent_index, child_index)
                               : xw_dom_remove_child(parser->document, parent_index, child_index))) {
                    ++parser->stats->dom_mutations;
                    value = argument;
                } else value = value_undefined();
            } else if (value.type == VAL_CLASSLIST &&
                (strcmp(property, "add") == 0 || strcmp(property, "remove") == 0 ||
                 strcmp(property, "contains") == 0 || strcmp(property, "toggle") == 0) &&
                accept(parser, "(")) {
                XwValue args[8];
                const char *arg_text[8];
                char arg_buffers[8][XW_JS_TEXT_CAP];
                size_t arg_count = 0U;
                int bool_result = 0;
                int ok;
                uint16_t node_index = value.node_index;
                const int is_contains = strcmp(property, "contains") == 0;
                const int is_toggle = strcmp(property, "toggle") == 0;
                while (!parser->failed && !token_is(parser, ")") && arg_count < 8U) {
                    args[arg_count] = parse_expression(parser, 1);
                    value_to_string(&args[arg_count], arg_buffers[arg_count], sizeof(arg_buffers[arg_count]));
                    arg_text[arg_count] = arg_buffers[arg_count];
                    ++arg_count;
                    if (!accept(parser, ",")) break;
                }
                if (arg_count == 8U && !token_is(parser, ")")) parser->failed = 1;
                (void)expect(parser, ")");
                ok = parser->execute ? class_list_apply(parser->document, node_index, property,
                    arg_text, arg_count, is_toggle && arg_count > 1U,
                    arg_count > 1U ? value_truthy(&args[1]) : 0, &bool_result) : 1;
                if (!ok) parser->failed = 1;
                else {
                    if (parser->execute && !is_contains) ++parser->stats->dom_mutations;
                    value = is_contains || is_toggle ? value_bool(bool_result) : value_undefined();
                }
            } else if (value.type == VAL_NODE &&
                (strcmp(property, "setAttribute") == 0 || strcmp(property, "getAttribute") == 0 ||
                 strcmp(property, "hasAttribute") == 0 || strcmp(property, "removeAttribute") == 0) &&
                accept(parser, "(")) {
                XwValue name = parse_expression(parser, 1), attr_value;
                char name_text[64], value_text[XW_JS_TEXT_CAP];
                uint16_t node_index = value.node_index;
                const int is_set = strcmp(property, "setAttribute") == 0;
                const int is_has = strcmp(property, "hasAttribute") == 0;
                const int is_remove = strcmp(property, "removeAttribute") == 0;
                value_to_string(&name, name_text, sizeof(name_text));
                if (is_set) {
                    (void)expect(parser, ",");
                    attr_value = parse_expression(parser, 1);
                    value_to_string(&attr_value, value_text, sizeof(value_text));
                    (void)expect(parser, ")");
                    if (parser->execute && xw_dom_set_attribute(parser->document, node_index, name_text, value_text))
                        ++parser->stats->dom_mutations;
                    value = value_undefined();
                } else {
                    (void)expect(parser, ")");
                    if (is_has) value = value_bool(xw_dom_has_attribute(parser->document, node_index, name_text));
                    else if (is_remove) {
                        if (parser->execute && xw_dom_remove_attribute(parser->document, node_index, name_text))
                            ++parser->stats->dom_mutations;
                        value = value_undefined();
                    } else {
                        const char *current = xw_dom_attribute(parser->document, node_index, name_text);
                        value = value_string(current != NULL ? current : "");
                    }
                }
            } else if (value.type == VAL_NODE && strcmp(property, "style") == 0) {
                value = read_node_property(parser, value, property);
            } else if (value.type == VAL_STYLE) {
                value = read_style_property(parser, value, property);
            } else {
                value = read_node_property(parser, value, property);
            }
        } else if (accept(parser, "(")) {
            if (value.type == VAL_CONSOLE || value.type == VAL_ALERT) {
                int is_alert = value.type == VAL_ALERT;
                if (!token_is(parser, ")")) {
                    (void)parse_expression(parser, 1);
                    while (accept(parser, ",")) (void)parse_expression(parser, 1);
                }
                (void)expect(parser, ")");
                if (parser->execute) {
                    if (is_alert) ++parser->stats->alert_calls;
                    else ++parser->stats->console_calls;
                }
                value = value_undefined();
            } else {
                parser->failed = 1;
                break;
            }
        } else if (token_is(parser, "++") || token_is(parser, "--")) {
            int decrement = token_is(parser, "--");
            if (value.ref_kind != REF_VARIABLE || value.ref_index >= parser->variable_count) {
                parser->failed = 1;
                break;
            }
            if (parser->execute) {
                XwValue *stored = &parser->variables[value.ref_index].value;
                *stored = value_number(value_to_number(stored) + (decrement ? -1.0 : 1.0));
            }
            next_token(parser);
            clear_reference(&value);
        } else break;
    }
    --parser->depth;
    return value;
}

static XwValue parse_expression(XwParser *parser, int min_precedence)
{
    XwValue left = parse_primary(parser);
    while (!parser->failed && parser->token.kind == TOK_OPERATOR) {
        char op[XW_JS_TEXT_CAP];
        int precedence = operator_precedence(parser->token.text);
        XwValue right;
        if (precedence < min_precedence || precedence == 0) break;
        (void)snprintf(op, sizeof(op), "%s", parser->token.text);
        next_token(parser);
        right = parse_expression(parser, precedence + 1);
        left = apply_operator(op, left, right);
    }
    return left;
}

static int assign_value(XwParser *parser, const XwValue *left, XwValue right)
{
    char text[XW_JS_TEXT_CAP];
    value_to_string(&right, text, sizeof(text));
    if (!parser->execute) return 1;
    switch (left->ref_kind) {
    case REF_VARIABLE:
        if (left->ref_index < parser->variable_count) {
            parser->variables[left->ref_index].value = right;
            clear_reference(&parser->variables[left->ref_index].value);
            return 1;
        }
        return 0;
    case REF_NODE_TEXT:
        if (xw_dom_set_text_content(parser->document, (uint16_t)left->ref_index, text)) {
            ++parser->stats->dom_mutations; return 1;
        }
        return 0;
    case REF_NODE_ATTRIBUTE:
        if (strcmp(left->ref_name, "checked") == 0 || strcmp(left->ref_name, "disabled") == 0 ||
            strcmp(left->ref_name, "selected") == 0 || strcmp(left->ref_name, "required") == 0 ||
            strcmp(left->ref_name, "readonly") == 0 || strcmp(left->ref_name, "multiple") == 0) {
            const int result = value_truthy(&right) ?
                xw_dom_set_attribute(parser->document, (uint16_t)left->ref_index, left->ref_name, "") :
                xw_dom_remove_attribute(parser->document, (uint16_t)left->ref_index, left->ref_name);
            if (result) { ++parser->stats->dom_mutations; return 1; }
            return !value_truthy(&right) && !xw_dom_has_attribute(parser->document,
                (uint16_t)left->ref_index, left->ref_name);
        }
        if (xw_dom_set_attribute(parser->document, (uint16_t)left->ref_index, left->ref_name, text)) {
            ++parser->stats->dom_mutations; return 1;
        }
        return 0;
    case REF_NODE_STYLE_PROPERTY:
        if (write_inline_style_value(parser->document, (uint16_t)left->ref_index, left->ref_name, text)) {
            ++parser->stats->dom_mutations; return 1;
        }
        return 0;
    case REF_DOCUMENT_TITLE: {
        size_t i;
        for (i = 0U; i < parser->document->node_count; ++i) {
            if (parser->document->nodes[i].type == XW_NODE_ELEMENT &&
                strcasecmp(xw_dom_string(parser->document, parser->document->nodes[i].name_offset), "title") == 0) {
                if (xw_dom_set_text_content(parser->document, (uint16_t)i, text)) {
                    ++parser->stats->dom_mutations; return 1;
                }
                return 0;
            }
        }
        return 0;
    }
    default: return 0;
    }
}

static void parse_block(XwParser *parser)
{
    if (!expect(parser, "{")) return;
    while (!parser->failed && parser->token.kind != TOK_END && !token_is(parser, "}")) {
        size_t before = parser->position;
        parse_statement(parser);
        if (parser->position == before && !parser->failed) { parser->failed = 1; break; }
    }
    (void)expect(parser, "}");
}

static int find_block_end(const char *source, size_t length, size_t start, size_t *after_end)
{
    size_t i = start;
    unsigned int braces = 0U;
    char quote = '\0';
    int escaped = 0;
    if (start >= length || source[start] != '{') return 0;
    while (i < length) {
        char c = source[i];
        if (quote != '\0') {
            if (escaped) escaped = 0;
            else if (c == '\\') escaped = 1;
            else if (c == quote) quote = '\0';
            ++i;
            continue;
        }
        if (c == '\'' || c == '"' || c == '`') { quote = c; ++i; continue; }
        if (c == '/' && i + 1U < length && source[i + 1U] == '/') {
            i += 2U; while (i < length && source[i] != '\n') ++i; continue;
        }
        if (c == '/' && i + 1U < length && source[i + 1U] == '*') {
            i += 2U;
            while (i + 1U < length && !(source[i] == '*' && source[i + 1U] == '/')) ++i;
            if (i + 1U >= length) return 0;
            i += 2U; continue;
        }
        if (c == '{') ++braces;
        else if (c == '}') {
            if (braces == 0U) return 0;
            --braces;
            ++i;
            if (braces == 0U) { *after_end = i; return 1; }
            continue;
        }
        ++i;
    }
    return 0;
}

static int eval_expression_slice(XwParser *parser, size_t start, size_t end, XwValue *result)
{
    XwParser *eval = &g_eval_parser;
    if (start > end || end > parser->source_length || end - start > XW_SCRIPT_MAX_SOURCE) return 0;
    *eval = *parser;
    eval->source = parser->source + start;
    eval->source_length = end - start;
    eval->position = 0U;
    eval->token_start = 0U;
    eval->tokens = 0U;
    eval->depth = 0U;
    eval->failed = 0;
    eval->execute = 0;
    next_token(eval);
    *result = parse_expression(eval, 1);
    return !eval->failed && eval->token.kind == TOK_END;
}

static int run_statement_slice(XwParser *parser, size_t start, size_t end, int execute, int block)
{
    XwParser *runner;
    size_t index;
    if (g_loop_depth >= XW_SCRIPT_MAX_LOOP_DEPTH || start > end || end > parser->source_length) {
        parser->failed = 1;
        return 0;
    }
    index = g_loop_depth++;
    runner = &g_loop_parsers[index];
    *runner = *parser;
    runner->source = parser->source + start;
    runner->source_length = end - start;
    runner->position = 0U;
    runner->token_start = 0U;
    runner->tokens = parser->tokens;
    runner->depth = 0U;
    runner->failed = 0;
    runner->execute = execute;
    next_token(runner);
    if (block) parse_block(runner);
    else parse_statement(runner);
    if (!runner->failed && runner->token.kind != TOK_END) runner->failed = 1;
    parser->tokens = runner->tokens;
    parser->remaining = runner->remaining;
    parser->variable_count = runner->variable_count;
    memcpy(parser->variables, runner->variables, sizeof(parser->variables));
    if (runner->failed) parser->failed = 1;
    --g_loop_depth;
    return !parser->failed;
}

static void parse_for_statement(XwParser *parser)
{
    int parent_execute = parser->execute;
    size_t condition_start, condition_end, increment_start, increment_end;
    size_t body_start, body_end;
    size_t iteration = 0U;
    XwValue condition;
    (void)expect(parser, "for");
    if (!expect(parser, "(")) return;
    /* The initializer parser consumes its own semicolon, like a normal statement. */
    parse_statement(parser);
    if (parser->failed) return;
    condition_start = parser->token_start;
    parser->execute = 0;
    (void)parse_expression(parser, 1);
    condition_end = parser->token_start;
    if (!expect(parser, ";")) { parser->execute = parent_execute; return; }
    increment_start = parser->token_start;
    {
        size_t saved_remaining = parser->remaining;
        parse_statement(parser);
        increment_end = parser->token_start;
        parser->remaining = saved_remaining;
    }
    if (!expect(parser, ")")) { parser->execute = parent_execute; return; }
    if (parser->token.kind != TOK_PUNCT || !token_is(parser, "{")) {
        /* Only block-bodied for loops are accepted; this keeps re-execution boundaries unambiguous. */
        parser->failed = 1; parser->execute = parent_execute; return;
    }
    body_start = parser->token_start;
    if (!find_block_end(parser->source, parser->source_length, body_start, &body_end)) {
        parser->failed = 1; parser->execute = parent_execute; return;
    }
    parser->position = body_end;
    next_token(parser);
    if (!parent_execute) {
        (void)run_statement_slice(parser, body_start, body_end, 0, 1);
        parser->execute = parent_execute;
        return;
    }
    if (condition_start == condition_end) { parser->failed = 1; parser->execute = parent_execute; return; }
    for (;;) {
        if (!eval_expression_slice(parser, condition_start, condition_end, &condition)) {
            parser->failed = 1; break;
        }
        if (!value_truthy(&condition)) break;
        if (iteration >= XW_SCRIPT_MAX_LOOP_ITERATIONS) {
            parser->stats->budget_exhausted = 1;
            parser->failed = 1;
            break;
        }
        if (!run_statement_slice(parser, body_start, body_end, 1, 1)) break;
        if (increment_start < increment_end &&
            !run_statement_slice(parser, increment_start, increment_end, 1, 0)) break;
        ++iteration;
        if (parser->remaining == 0U || parser->stats->statements >= XW_SCRIPT_MAX_STATEMENTS) {
            parser->stats->budget_exhausted = 1;
            parser->failed = 1;
            break;
        }
    }
    parser->execute = parent_execute;
    (void)accept(parser, ";");
}

static void parse_statement(XwParser *parser)
{
    int is_declaration = 0;
    char variable_name[XW_JS_NAME_CAP];
    XwValue left;
    if (parser->failed || parser->token.kind == TOK_END) return;
    if (parser->stats->statements >= XW_SCRIPT_MAX_STATEMENTS || parser->remaining == 0U) {
        parser->stats->budget_exhausted = 1;
        parser->failed = 1;
        return;
    }
    ++parser->stats->statements;
    --parser->remaining;
    if (accept(parser, ";")) return;
    if (accept(parser, "{")) {
        while (!parser->failed && parser->token.kind != TOK_END && !token_is(parser, "}"))
            parse_statement(parser);
        (void)expect(parser, "}");
        return;
    }
    if (parser->token.kind == TOK_ID &&
        (token_is(parser, "var") || token_is(parser, "let") || token_is(parser, "const"))) {
        next_token(parser);
        if (parser->token.kind != TOK_ID) {
            parser->failed = 1; return;
        }
        {
            const size_t name_length = strlen(parser->token.text);
            if (name_length >= sizeof(variable_name)) { parser->failed = 1; return; }
            memcpy(variable_name, parser->token.text, name_length + 1U);
        }
        next_token(parser);
        is_declaration = 1;
        if (accept(parser, "=")) {
            XwValue value = parse_expression(parser, 1);
            if (parser->execute) {
                XwValue *stored = find_variable(parser, variable_name, 1);
                if (stored == NULL) parser->failed = 1;
                else { *stored = value; clear_reference(stored); }
            }
        } else if (parser->execute) {
            XwValue *stored = find_variable(parser, variable_name, 1);
            if (stored == NULL) parser->failed = 1;
        }
        (void)accept(parser, ";");
        return;
    }
    if (token_is(parser, "for")) {
        parse_for_statement(parser);
        return;
    }
    if (accept(parser, "if")) {
        XwValue condition;
        int parent_execute = parser->execute;
        (void)expect(parser, "(");
        condition = parse_expression(parser, 1);
        (void)expect(parser, ")");
        parser->execute = parent_execute && value_truthy(&condition);
        if (token_is(parser, "{")) parse_block(parser); else parse_statement(parser);
        parser->execute = parent_execute && !value_truthy(&condition);
        if (accept(parser, "else")) {
            if (token_is(parser, "{")) parse_block(parser); else parse_statement(parser);
        }
        parser->execute = parent_execute;
        (void)accept(parser, ";");
        return;
    }
    if (token_is(parser, "while") || token_is(parser, "function") ||
        token_is(parser, "return") || token_is(parser, "import") || token_is(parser, "export")) {
        parser->failed = 1;
        return;
    }
    left = parse_expression(parser, 1);
    if (accept(parser, "=")) {
        XwValue right = parse_expression(parser, 1);
        if (left.ref_kind != REF_NONE && !assign_value(parser, &left, right)) parser->failed = 1;
    } else if (token_is(parser, "+=") || token_is(parser, "-=") ||
               token_is(parser, "*=") || token_is(parser, "/=")) {
        char op[3];
        XwValue right;
        op[0] = parser->token.text[0]; op[1] = '\0'; op[2] = '\0';
        next_token(parser);
        right = parse_expression(parser, 1);
        right = apply_operator(op, left, right);
        if (left.ref_kind != REF_NONE && !assign_value(parser, &left, right)) parser->failed = 1;
    }
    (void)is_declaration;
    (void)accept(parser, ";");
}

static int script_type_allowed(const char *type)
{
    return type == NULL || type[0] == '\0' || strcasecmp(type, "text/javascript") == 0 ||
           strcasecmp(type, "application/javascript") == 0 || strcasecmp(type, "text/ecmascript") == 0 ||
           strcasecmp(type, "application/ecmascript") == 0;
}

int xw_script_run_document(XwDocument *document, size_t instruction_budget,
                           XwScriptStats *stats)
{
    /* Renderer is synchronous and single-page: keep the interpreter arena off the small console stack. */
    XwParser *parser = &g_parser;
    size_t i;
    int all_ok = 1;
    XwScriptStats local_stats;
    if (document == NULL) return 0;
    if (stats == NULL) stats = &local_stats;
    memset(stats, 0, sizeof(*stats));
    memset(parser, 0, sizeof(*parser));
    parser->document = document;
    parser->remaining = instruction_budget > 0U ? instruction_budget : 1U;
    parser->execute = 1;
    parser->stats = stats;
    for (i = 0U; i < document->node_count; ++i) {
        const char *tag;
        const char *type;
        const char *src;
        uint16_t child;
        size_t code_length;
        if (document->nodes[i].type != XW_NODE_ELEMENT) continue;
        tag = xw_dom_string(document, document->nodes[i].name_offset);
        if (strcasecmp(tag, "script") != 0) continue;
        ++stats->script_elements;
        type = xw_dom_attribute(document, (uint16_t)i, "type");
        src = xw_dom_attribute(document, (uint16_t)i, "src");
        if ((src != NULL && src[0] != '\0') || !script_type_allowed(type)) continue;
        child = document->nodes[i].first_child;
        while (child != XW_DOM_NONE && document->nodes[child].type != XW_NODE_TEXT)
            child = document->nodes[child].next_sibling;
        if (child == XW_DOM_NONE) { ++stats->executed_scripts; continue; }
        /* A previous malformed conditional must not suppress a later script. */
        parser->execute = 1;
        parser->source = xw_dom_string(document, document->nodes[child].value_offset);
        code_length = strlen(parser->source);
        if (code_length > XW_SCRIPT_MAX_SOURCE) {
            ++stats->errors; stats->truncated = 1; all_ok = 0; continue;
        }
        parser->source_length = code_length;
        parser->position = 0U;
        parser->tokens = 0U;
        parser->failed = 0;
        parser->depth = 0U;
        next_token(parser);
        while (!parser->failed && parser->token.kind != TOK_END) {
            size_t old_pos = parser->position;
            parse_statement(parser);
            if (parser->position == old_pos && !parser->failed) parser->failed = 1;
        }
        ++stats->executed_scripts;
        if (parser->failed) {
            ++stats->errors;
            all_ok = 0;
            if (stats->budget_exhausted) break;
        }
    }
    return all_ok;
}


int xw_script_execute_code(XwDocument *document, const char *code, size_t code_length,
                           size_t instruction_budget, XwScriptStats *stats)
{
    XwScriptStats local_stats;
    XwParser *parser = &g_parser;
    int all_ok = 1;
    if (stats == NULL) stats = &local_stats;
    memset(stats, 0, sizeof(*stats));
    if (document == NULL || code == NULL) { ++stats->errors; return 0; }
    if (code_length > XW_SCRIPT_MAX_SOURCE) {
        stats->truncated = 1;
        ++stats->errors;
        return 0;
    }
    if (parser->document != document) {
        memset(parser, 0, sizeof(*parser));
        parser->document = document;
    }
    parser->source = code;
    parser->source_length = code_length;
    parser->position = 0U;
    parser->tokens = 0U;
    parser->remaining = instruction_budget > 0U ? instruction_budget : 1U;
    parser->depth = 0U;
    parser->execute = 1;
    parser->failed = 0;
    parser->stats = stats;
    next_token(parser);
    while (!parser->failed && parser->token.kind != TOK_END) {
        size_t old_position = parser->position;
        parse_statement(parser);
        if (parser->position == old_position && !parser->failed) parser->failed = 1;
    }
    if (parser->failed) {
        ++stats->errors;
        if (stats->budget_exhausted) all_ok = 0;
        else all_ok = 0;
    }
    return all_ok;
}
