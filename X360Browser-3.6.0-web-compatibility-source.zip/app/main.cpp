#include "x360browser/browser_session.hpp"

#include <cstdlib>
#include <iostream>
#include <sstream>
#include <string>

namespace {
constexpr const char* kProfilePath = "x360browser.profile";

void print_help() {
    std::cout << "\nComandos do X360Browser 3.6.0-web-compatibility-preview\n"
              << "  digite um endereço ou uma pesquisa para preparar a navegação\n"
              << "  :home                 abrir a página inicial no estado de navegação\n"
              << "  :back / :forward      voltar / avançar no histórico\n"
              << "  :history              mostrar histórico e posição atual\n"
              << "  :clear-history        apagar o histórico em memória\n"
              << "  :add [título]         salvar a página atual nos favoritos\n"
              << "  :bookmarks            listar favoritos\n"
              << "  :open N               abrir o favorito N (começa em 1)\n"
              << "  :remove N             remover o favorito N\n"
              << "  :homepage URL         definir página inicial\n"
              << "  :theme dark|light|high-contrast\n"
              << "  :save                 salvar configurações, favoritos e histórico\n"
              << "  :help                 mostrar esta ajuda\n"
              << "  :quit                 salvar e sair\n\n"
              << "Observação: esta demonstração testa o núcleo. O motor que baixa e desenha páginas\n"
              << "ainda precisa ser integrado para navegar/renderizar sites de verdade.\n\n";
}

bool parse_index(const std::string& value, std::size_t& index) {
    if (value.empty()) return false;
    std::istringstream in(value);
    long long parsed = 0;
    char extra = 0;
    if (!(in >> parsed) || (in >> extra) || parsed < 1) return false;
    index = static_cast<std::size_t>(parsed - 1);
    return true;
}

void show_navigation(const x360browser::BrowserSession& session) {
    if (session.state().current_url().empty()) {
        std::cout << "Nenhuma página no histórico.\n";
        return;
    }
    std::cout << "URL atual: " << session.state().current_url() << '\n';
    std::cout << "Histórico: " << session.state().history().size() << " entrada(s) | "
              << (session.state().can_back() ? "voltar disponível" : "sem voltar") << " | "
              << (session.state().can_forward() ? "avançar disponível" : "sem avançar") << '\n';
    std::cout << "[O motor de páginas não está conectado nesta demonstração.]\n";
}
}

int main() {
    x360browser::BrowserSession browser;
    std::string load_error;
    if (browser.load_profile(kProfilePath, &load_error)) {
        std::cout << "Perfil carregado: " << kProfilePath << '\n';
    }
    std::cout << "X360Browser 3.6.0-web-compatibility-preview — núcleo experimental\n"
              << "Digite :help para ver comandos.\n";

    std::string line;
    while (std::cout << "x360> " && std::getline(std::cin, line)) {
        if (line.empty()) continue;
        if (line == ":quit") {
            std::string error;
            if (browser.save_profile(kProfilePath, &error)) std::cout << "Perfil salvo.\n";
            else std::cerr << "Aviso: não foi possível salvar: " << error << '\n';
            return EXIT_SUCCESS;
        }
        if (line == ":help") { print_help(); continue; }
        if (line == ":home") {
            std::cout << (browser.home() ? "Página inicial selecionada.\n" : "Página inicial inválida.\n");
            show_navigation(browser); continue;
        }
        if (line == ":back" || line == ":forward") {
            const bool ok = line == ":back" ? browser.back() : browser.forward();
            std::cout << (ok ? "Navegação do histórico atualizada.\n" : "Não há entrada nessa direção.\n");
            show_navigation(browser); continue;
        }
        if (line == ":history") {
            const auto& history = browser.state().history();
            if (history.empty()) std::cout << "Histórico vazio.\n";
            for (std::size_t i = 0; i < history.size(); ++i)
                std::cout << (i == browser.state().history_position() ? "* " : "  ") << (i + 1) << ". " << history[i] << '\n';
            continue;
        }
        if (line == ":clear-history") { browser.clear_history(); std::cout << "Histórico limpo.\n"; continue; }
        if (line == ":bookmarks") {
            const auto& items = browser.bookmarks().items();
            if (items.empty()) std::cout << "Nenhum favorito salvo.\n";
            for (std::size_t i = 0; i < items.size(); ++i)
                std::cout << (i + 1) << ". " << items[i].title << " — " << items[i].url << '\n';
            continue;
        }
        if (line.rfind(":add", 0) == 0 && (line.size() == 4 || line[4] == ' ')) {
            const std::string title = line.size() > 5 ? line.substr(5) : std::string{};
            std::string error;
            if (browser.add_current_bookmark(title, &error)) std::cout << "Favorito salvo.\n";
            else std::cout << error << '\n';
            continue;
        }
        if (line.rfind(":open ", 0) == 0 || line.rfind(":remove ", 0) == 0) {
            const bool remove = line.rfind(":remove ", 0) == 0;
            const std::string arg = line.substr(remove ? 8 : 6);
            std::size_t index = 0;
            if (!parse_index(arg, index)) { std::cout << "Use um número de favorito válido.\n"; continue; }
            const bool ok = remove ? browser.remove_bookmark(index) : browser.open_bookmark(index);
            std::cout << (ok ? (remove ? "Favorito removido.\n" : "Favorito selecionado.\n") : "Favorito não encontrado.\n");
            if (!remove && ok) show_navigation(browser);
            continue;
        }
        if (line.rfind(":homepage ", 0) == 0) {
            std::string error;
            if (browser.set_homepage(line.substr(10), &error)) std::cout << "Página inicial atualizada.\n";
            else std::cout << error << '\n';
            continue;
        }
        if (line.rfind(":theme ", 0) == 0) {
            x360browser::Theme theme;
            if (!x360browser::parse_theme(line.substr(7), theme)) std::cout << "Temas: dark, light ou high-contrast.\n";
            else { browser.set_theme(theme); std::cout << "Tema salvo na sessão: " << x360browser::theme_name(theme) << '\n'; }
            continue;
        }
        if (line == ":save") {
            std::string error;
            if (browser.save_profile(kProfilePath, &error)) std::cout << "Perfil salvo em " << kProfilePath << ".\n";
            else std::cout << "Falha ao salvar: " << error << '\n';
            continue;
        }

        const auto result = browser.navigate(line);
        if (!result.accepted) { std::cout << "Erro: " << result.error << '\n'; continue; }
        std::cout << (result.is_search ? "Pesquisa preparada: " : "Endereço preparado: ") << result.url << '\n';
        show_navigation(browser);
    }
    return EXIT_SUCCESS;
}
