#!/usr/bin/env python3
"""Fail-fast integrity checks for the X360Browser 3.6.0 web compatibility preview source package."""
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
EXPECTED_VERSION = "3.6.0-web-compatibility-preview"
REQUIRED = [
    "VERSION", "CMakeLists.txt", "README.md", "CHANGELOG.md", "TEST-RESULTS.txt",
    "THIRD_PARTY_NOTICES.md", "X360Browser-video-config.example.txt",
    "tests/run_host_tests.py", "tests/validate_project_integrity.py",
    "tests/web_engine_fixture_server.py", "tests/test_web_engine_native.c",
    "tests/test_web_engine_dispatch.c", "tests/test_visual_layout.c",
    "tests/test_xenonweb.c", "tests/test_xenonweb_layout.c", "tests/test_xenonscript.c",
    "tests/test_xenonmedia.c", "tests/jpeg_baseline_fixture.h",
    "examples/media-playback.html", "examples/responsive-layout-leap.html",
    "include/x360browser/version.hpp", "engine/xenonweb/xw_dom.c",
    "engine/xenonweb/xw_css.c", "engine/xenonweb/xw_css.h",
    "engine/xenonweb/xw_script.c", "engine/xenonweb/xw_layout.c",
    "engine/xenonmedia/xm_media.c", "engine/xenonmedia/xm_media.h",
    "engine/xenonmedia/xm_playback.c", "engine/xenonmedia/xm_playback.h",
    "platform/xbox360/xsdk/main.c", "platform/xbox360/xsdk/web_engine.c",
    "platform/xbox360/xsdk/web_engine.h", "platform/xbox360/xsdk/web_engine_dispatch.c",
    "platform/xbox360/xsdk/visual_renderer.c", "platform/xbox360/xsdk/CMakeLists.txt",
    "tools/build_xbox_shell.sh", ".github/workflows/build-xex-from-zip.yml",
    "docs/MEDIA-PLAYBACK.md", "docs/COMPATIBILITY-3.5.0-native-web-media.md",
    "docs/COMPATIBILITY-3.6.0-web-compatibility-preview.md",
    "docs/ENGINE-GAP-AUDIT-3.5.0.md", "docs/XENONMEDIA-ENGINE.md",
    "docs/XENONWEB-ENGINE.md", "docs/STATUS.md", "docs/ARCHITECTURE.md",
    "docs/RESUMO-3.6.0-pt-BR.md",
    "docs/TESTING.md", "docs/XBOX_BUILD.md", "docs/50-LACUNAS-PRIORITARIAS-pt-BR.md",
]
missing = [name for name in REQUIRED if not (ROOT / name).is_file() or (ROOT / name).stat().st_size == 0]
if missing:
    print("FAIL: source package is incomplete:", file=sys.stderr)
    for name in missing:
        print(f"  - {name}", file=sys.stderr)
    raise SystemExit(2)


def read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8", errors="replace")

version = read("VERSION").strip()
if version != EXPECTED_VERSION:
    raise SystemExit(f"FAIL: VERSION must be {EXPECTED_VERSION!r}, found {version!r}")

cmake = read("CMakeLists.txt")
platform_cmake = read("platform/xbox360/xsdk/CMakeLists.txt")
workflow = read(".github/workflows/build-xex-from-zip.yml")
version_header = read("include/x360browser/version.hpp")
build_script = read("tools/build_xbox_shell.sh")
main = read("platform/xbox360/xsdk/main.c")
renderer = read("platform/xbox360/xsdk/visual_renderer.c")
css = read("engine/xenonweb/xw_css.c")
css_header = read("engine/xenonweb/xw_css.h")
media = read("engine/xenonmedia/xm_media.c")
media_header = read("engine/xenonmedia/xm_media.h")
test_media = read("tests/test_xenonmedia.c")
test_css = read("tests/test_xenonweb.c")
dispatch = read("platform/xbox360/xsdk/web_engine_dispatch.c")
test_dispatch = read("tests/test_web_engine_dispatch.c")
audit = read("docs/ENGINE-GAP-AUDIT-3.5.0.md")
priority_gaps_pt = read("docs/50-LACUNAS-PRIORITARIAS-pt-BR.md")
compat = read("docs/COMPATIBILITY-3.6.0-web-compatibility-preview.md")
media_doc = read("docs/MEDIA-PLAYBACK.md")
config = read("X360Browser-video-config.example.txt")
third_party = read("THIRD_PARTY_NOTICES.md")

markers = [
    ("CMakeLists.txt", cmake, "project(X360Browser VERSION 3.6.0"),
    ("platform/xbox360/xsdk/CMakeLists.txt", platform_cmake, "project(X360Browser VERSION 3.6.0"),
    ("include/x360browser/version.hpp", version_header, '#define X360BROWSER_VERSION_STRING "3.6.0-web-compatibility-preview"'),
    ("include/x360browser/version.hpp", version_header, "#define X360BROWSER_VERSION_MINOR 6"),
    ("tools/build_xbox_shell.sh", build_script, "X360Browser 3.6.0-web-compatibility-preview"),
    ("engine/xenonweb/xw_css.h", css_header, "XW_CSS_MAX_CUSTOM_PROPERTIES"),
    ("engine/xenonweb/xw_css.c", css, "css_resolve_vars"),
    ("engine/xenonweb/xw_css.c", css, "css_collect_root_custom_properties"),
    ("tests/test_xenonweb.c", test_css, "CSS :root custom properties resolve through var()"),
    ("engine/xenonmedia/xm_media.h", media_header, "XM_CODEC_IMA_ADPCM"),
    ("engine/xenonmedia/xm_media.h", media_header, "xm_media_webvtt_find_active_cue"),
    ("engine/xenonmedia/xm_media.c", media, "xm_media_decode_wav_pcm16"),
    ("engine/xenonmedia/xm_media.c", media, "xm_media_webvtt_find_active_cue"),
    ("tests/test_xenonmedia.c", test_media, "IMA ADPCM stereo blocks decode"),
    ("tests/test_xenonmedia.c", test_media, "WebVTT active-cue lookup"),
    ("platform/xbox360/xsdk/visual_renderer.c", renderer, "xm_media_decode_image_rgba"),
    ("platform/xbox360/xsdk/visual_renderer.c", renderer, "xw_layout_page(page, scroll_pixels, &frame)"),
    ("platform/xbox360/xsdk/web_engine.h", read("platform/xbox360/xsdk/web_engine.h"), "WEB_ENGINE_SOURCE_HTML_CAP (4U * 1024U * 1024U)"),
    ("engine/xenonweb/xw_layout.c", read("engine/xenonweb/xw_layout.c"), "YouTube embed is not inline yet"),
    ("platform/xbox360/xsdk/web_engine_dispatch.c", dispatch, "XenonWeb + XenonNet transport"),
    ("tests/test_web_engine_dispatch.c", test_dispatch, "first-party XenonWeb page engine"),
    ("workflow", workflow, "X360Browser-3.6.0-web-compatibility-source.zip"),
    ("workflow", workflow, "default: false"),
    ("workflow", workflow, "docs/ENGINE-GAP-AUDIT-3.5.0.md"),
]
for rel, content, marker in markers:
    if marker not in content:
        raise SystemExit(f"FAIL: missing expected implementation marker in {rel}: {marker}")


source_transport_test = read("tests/test_web_engine_native.c")
if re.search(r'\(\s*void\s*\)\s*fread\s*\(', source_transport_test):
    raise SystemExit("FAIL: native test source must validate fread return values")

# 164 unique items are the engineering inventory, not a claim of 164 completed features.
gap_ids = set(re.findall(r"\bGAP-(\d{3})\b", audit))
if len(gap_ids) != 164:
    raise SystemExit(f"FAIL: gap audit should contain exactly 164 unique IDs; found {len(gap_ids)}")
if "Total inventariado: 164 itens" not in audit:
    raise SystemExit("FAIL: gap audit total should be updated alongside its items")
if len(re.findall(r"\bGAP-\d{3}\b", priority_gaps_pt)) < 50:
    raise SystemExit("FAIL: Portuguese priority-gap list must include at least 50 IDs")
for gap_marker in ("GAP-032", "GAP-043", "GAP-109", "GAP-127"):
    if gap_marker not in audit:
        raise SystemExit(f"FAIL: audit must reflect new media/CSS status for {gap_marker}")

# Browser/page/media engines must be first-party by default; TLS and platform support are declared separately.
if "netsurf_backend_stub.c" in platform_cmake or (ROOT / "platform/xbox360/xsdk/netsurf_backend_stub.c").exists():
    raise SystemExit("FAIL: nonfunctional NetSurf adapter must not be in active source/build")
if "netsurf_backend_" in dispatch or "WEB_ENGINE_BACKEND_NETSURF" in read("platform/xbox360/xsdk/web_engine.h"):
    raise SystemExit("FAIL: active dispatcher/header must not advertise a fake third-party browser engine")
if re.search(r'#define\s+VIDEO_PLAYER_PATH\s+""', main) is None:
    raise SystemExit("FAIL: external media player must be disabled by default")
if "if (!external_media_player_enabled())" not in main:
    raise SystemExit("FAIL: external-player launch paths must guard disabled state")
if "stb_image" in platform_cmake or "X360BROWSER_WITH_STB_IMAGE" in platform_cmake:
    raise SystemExit("FAIL: third-party raster decoder integration must be removed")
if "stb_image" in renderer or "stbi_" in renderer or "stb_image" in build_script:
    raise SystemExit("FAIL: third-party raster decoder must not be called or fetched")
meaningful_config = [line.strip() for line in config.splitlines() if line.strip() and not line.lstrip().startswith(("#", ";"))]
if not meaningful_config or meaningful_config[0].lower() != "disabled":
    raise SystemExit("FAIL: example media config must disable external-player handoff by default")
for marker in ("libcurl", "Mbed TLS", "xSDK"):
    if marker.lower() not in third_party.lower():
        raise SystemExit(f"FAIL: third-party boundary must disclose {marker}")
for marker in ("not a promise", "not ecmascript-complete", "not implemented", "youtube"):
    if marker.lower() not in compat.lower():
        raise SystemExit(f"FAIL: compatibility doc must explain limitation: {marker}")
for marker in ("WebVTT", "IMA ADPCM", "H.264", "subtitle overlay", "not yet an integrated"):
    if marker.lower() not in media_doc.lower():
        raise SystemExit(f"FAIL: media documentation missing boundary marker: {marker}")

print(
    f"PASS: package integrity; {len(REQUIRED)} required files; version={version}; "
    f"{len(gap_ids)} unique historical gap IDs; DOM/CSS renderer integration, large HTML capacity, CSS vars, WAV IMA ADPCM, WebVTT and first-party dispatch verified; "
    "external player disabled by default; XEX build remains opt-in"
)
