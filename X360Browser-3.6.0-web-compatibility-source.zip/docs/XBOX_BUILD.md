# X360Browser 3.6.0 — source validation and optional Xbox build

The workflow `.github/workflows/build-xex-from-zip.yml` resolves a source root by `platform/xbox360/xsdk/main.c` and `VERSION`, or extracts the committed `X360Browser-3.6.0-web-compatibility-source.zip`. It reports an explicit error if the repository has only the YAML and no complete source tree/archive.

## Default validation (no XEX compilation)

1. Commit the ZIP to the repository root or commit the full extracted source tree.
2. Run **Actions → X360Browser 3.6.0 Web Compatibility Preview — validation (XEX opt-in)** with `build_xex=false`.
3. Inspect the validation artifact/log before attempting a console build.

## Optional cross-build

Only turn `build_xex=true` on a deliberate manual run after source validation and after setting up the expected xSDK/PowerPC dependencies. A passing host build does not guarantee a successful XEX or startup on hardware. This milestone has not performed the PowerPC build or physical Xbox test.
