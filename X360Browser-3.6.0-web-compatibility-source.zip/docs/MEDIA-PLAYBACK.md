# X360Browser 3.6.0 — media support and playback boundaries


## 3.6.0 status

The 3.6.0 preview improves the HTML/CSS rendering path and exposes unsupported iframe URLs as controller-focusable top-level navigation. It does **not** add integrated audio/video presentation. XenonMedia still provides bounded format probing, selected raster decoders, WAV PCM/IMA ADPCM decoding primitives, basic AVI/MP4 metadata parsing and WebVTT parsing, but those primitives are not a complete real-time browser media pipeline.

YouTube: the current watch-page/player relies on modern JavaScript and media APIs that are missing; YouTube playback is not supported. An embedded URL can be opened separately as a fallback, not played inline.

Poki: most games rely on Canvas/WebGL, WASM, workers or modern JavaScript. These APIs are absent, so most Poki games cannot run in this build.

## Internally implemented now

`XenonMedia` contains first-party decoders for bounded BMP, QOI, PPM, selected PNG/GIF/JPEG profiles, WAV PCM U8/S16LE and WAV Microsoft IMA ADPCM to PCM16. It also has an AVI parser for uncompressed BI_RGB frames, bounded MP4/MP3/AAC/TS/HLS parsers, a caller-clock playback state machine and a WebVTT cue parser/active-cue lookup.

These are tested primitives, **not yet an integrated in-browser audio/video experience**. The Xbox audio output device is not connected to PCM buffers; AVI frames are not presented on a synchronized playback clock; WebVTT cues are not drawn as subtitles; modern compressed codecs such as H.264/AAC/VP9/AV1 are not decoded. The full MP4 sample-table family and adaptive playback are incomplete.

## External player stays disabled by default

The project contains a legacy media-launch compatibility pathway, but `VIDEO_PLAYER_PATH` is empty and the example config is `disabled`. No player executable is shipped and it will not be launched automatically. This version's direction is first-party media code, not relying on an external player as the browser's media engine.

## Historical changes introduced in 3.5.0

- WAV Microsoft IMA ADPCM can be decoded into bounded PCM16 buffers. It still needs a first-party Xbox audio-device/output path.
- WebVTT cues can be parsed and looked up by playback timestamp. They still need subtitle layout/painting and clock integration.
- CSS variables now handle bounded `:root` declarations and `var()` fallbacks. This improves style-based media controls but does not add full CSS scope or modern HTMLMediaElement APIs.

## Major missing pieces

Native H.264/HEVC/VP8/VP9/AV1 video decode, compressed MP3/AAC/Vorbis/Opus/FLAC decode, complete MP4 demux/sample extraction, HLS live/adaptive playback, HTTP range streaming, Xbox audio output, frame presentation scheduling, A/V synchronization, buffering and seek UI, subtitle overlay/track selection, and a full `HTMLMediaElement` remain pending. YouTube watch-page playback and DRM support are not claimed.

The 164-item list in `ENGINE-GAP-AUDIT-3.5.0.md` tracks media and non-media gaps.
