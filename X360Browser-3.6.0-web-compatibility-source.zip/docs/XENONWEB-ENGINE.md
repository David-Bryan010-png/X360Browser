# XenonWeb engine — 3.6.0 renderer integration

In 3.6.0, the Xbox GPU renderer now calls `xw_layout_page()` first. The production draw path can therefore consume the DOM/CSS/XenonScript layout output, while the old VisualLite parser remains a fallback if the XenonWeb layout path rejects a page. The implementation remains bounded and is not a WHATWG-compliant browser engine.

The retained HTML budget is 4 MiB. DOM and visual frame capacities are raised but capped. CSS Grid/flexbox and common selectors are partial implementations. JavaScript is XenonScript, a restricted JavaScript-like runtime; it is not a substitute for full ECMAScript or browser APIs such as Canvas, WebGL, workers or WebAssembly.

The detailed 3.6.0 page/game/video matrix is in `COMPATIBILITY-3.6.0-web-compatibility-preview.md`.

# XenonWeb — first-party HTML, CSS and layout engine

XenonWeb is the project's own bounded engine. It currently parses the page into a fixed-capacity DOM, computes a supported subset of CSS, and emits text/rectangle/link/image records for the existing Xbox visual renderer.

## 3.5.0 advancements

- A viewport-aware CSS entry point evaluates bounded `@media` conditions (`min/max-width`, `min/max-height`, orientation, comma lists and simple `and` / `not`). The existing public collector remains available for default viewport behavior.
- The cascade tracks `!important` per property and resolves important declarations separately from normal specificity/source order.
- Selector support includes selected structural pseudos such as `:first-of-type`, `:last-of-type` and `:nth-of-type`, in addition to earlier type/class/ID/attribute/child/descendant selectors and pseudos.
- Flexbox-like layout adds row/column, bounded `gap`, `justify-content` and wrapping; CSS Grid supports bounded equal tracks (1–4 columns). Both are explicitly approximations to fit predictable memory/time budgets.
- Pixel and percentage `width` values, `min-width`, and `max-width` flow into rendered block bounds; four-side padding affects actual content coordinates; `margin: 0 auto` centers constrained-width blocks. Regression fixtures verify these behaviors in the actual output frame. Shorthand/side declarations also preserve `!important` precedence per side.

## CSS custom properties in 3.5.0

`XwStylesheet` now collects bounded custom-property declarations from `:root`/`html` rules. `var(--name)` and `var(--name, fallback)` are substituted when declarations are computed/parsed, including nested fallbacks and values used inside shorthands. Property count/name/value and recursion/output lengths are capped. The implementation does **not** yet support full custom-property scope per arbitrary element, computed values inherited through the DOM, or complete CSS tokenization; unresolved values without fallback invalidate only the affected declaration.

## Media integration in 3.5.0

The primary layout now renders `video` and `audio` elements as controller-focusable cards. It finds the direct `src` or first supported child `source`, maps that URL back to the page resource list, and routes activation to the browser's external-player handoff. This improves usability and resource selection but is not an in-page HTMLMediaElement implementation.

## Implementation boundaries

The CSS parser is not a complete browser CSS parser. Unsupported at-rules and declarations are ignored or skipped within bounds; intrinsic sizing, full cascade/inheritance rules, full flex/grid algorithms, scoped CSS variables, `calc()`, transforms, sticky/fixed positioning, table layout and typography shaping are incomplete. The renderer currently emits simplified visual records rather than a browser-grade compositing pipeline.

DOM parsing includes common recovery behaviors and handles raw script/style plus textarea/title text specially, but is not a complete HTML Living Standard parser. The old NetSurf adapter has been removed from the active build. Do not infer modern-site compatibility solely from host tests.
