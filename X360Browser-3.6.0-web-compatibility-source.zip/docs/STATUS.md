# X360Browser 3.6.0 — implementation status

## Completed in this source preview

- The Xbox production renderer now tries `xw_layout_page()` before legacy VisualLite. XenonWeb's DOM/CSS/script-backed layout can generate the visible frame used by the Xenos GPU texture path.
- HTML transport and source retention increased to 4 MiB each; CSS/network/resource arrays and visual output capacities are larger but remain bounded.
- Added test coverage for HTML larger than 612 KiB, CSS beyond the previous small external-sheet size, and iframe URL fallback navigation.
- Browser control focus can select iframe fallback URLs and open them as top-level navigations.
- Existing first-party image decoders, DOM/CSS tests, script-subset tests, media probing and HLS safety checks remain in the test suite.

## Partial or unavailable

- HTML parsing and CSS layout are bounded subsets, not a full browser-standard implementation.
- XenonScript does not implement the full ECMAScript language, modern event loop, promises/async modules or the complete standard browser environment.
- `iframe` content cannot render as a nested live frame. It is represented as an openable top-level link.
- Canvas/WebGL/WebAssembly/workers are not implemented; therefore current Poki games and similar game frameworks are not promised to run.
- Video/audio demux/probing and bounded file download are not integrated playback. Codec decoding, frame presentation, audio output, A/V sync, HLS/DASH adaptive playback and current YouTube playback remain open work.
- The PowerPC/XSDK build and physical Xbox 360 test are required before calling a package console-validated.

See [`COMPATIBILITY-3.6.0-web-compatibility-preview.md`](COMPATIBILITY-3.6.0-web-compatibility-preview.md) for the support matrix.
