# X360Browser 3.6.0 — Web Compatibility Preview

X360Browser is a homebrew browser experiment for Xbox 360. The 3.6.0 preview connects the Xbox GPU renderer to its first-party XenonWeb DOM/CSS layout pipeline and increases bounded page/resource capacity. This is a major step beyond the previous text-oriented rendering path, but it is **not yet a standards-complete modern browser**.

## What changed in 3.6.0

- The Xbox page renderer uses XenonWeb DOM/CSS/XenonScript layout first; legacy VisualLite is retained as a failure fallback.
- HTML downloading supports documents up to 4 MiB. The 4 MiB retained-source buffer, DOM/CSS memory, rendered frame and resource arrays remain bounded; oversized pages may be marked partially rendered.
- Increased DOM nodes, attributes, CSS rules, external stylesheet budget, links, images and visual-layout items.
- A regression test verifies a complete HTML document above 612 KiB and an external stylesheet larger than 4 KiB.
- Unsupported iframe contents appear as a controller-selectable link, so the URL can be opened as a top-level page instead of becoming a dead placeholder.
- Existing bounded first-party raster decoders, media resource detection, HLS policy checks and optional external player handoff are preserved.

## Current compatibility boundary

XenonWeb supports a useful HTML/CSS subset including DOM construction, selectors, inline/external stylesheet processing, block/text layout, responsive media queries, flex, bounded CSS Grid, controls, links, images and the bounded XenonScript interpreter. It does not implement the full WHATWG HTML parsing model, a complete CSS engine or standard ECMAScript.

**Poki:** simple pages may display, but most Poki games rely on Canvas/WebGL, modern JavaScript APIs, workers or WebAssembly. Those game runtimes are not implemented, so a generic claim of Poki game support would be false.

**YouTube/video:** video and audio sources can be detected and linked; media resources can be downloaded within configured limits and handed to an explicitly configured external player. The browser does not currently decode/present H.264/AAC in an integrated HTMLMediaElement, and YouTube's current watch page/player does not work as an in-page video player. An iframe URL can be opened as a top-level page, but that is a fallback, not YouTube playback.

## Build and test

Run `python3 tests/run_host_tests.py` for the first-party host tests. Run `python3 tests/validate_project_integrity.py` for package checks. The Xbox 360 XEX is built with the PowerPC/xSDK toolchain by `tools/build_xbox_shell.sh`; successful host tests do not prove that the XEX was cross-compiled or tested on hardware.

## Project docs

- [`docs/COMPATIBILITY-3.6.0-web-compatibility-preview.md`](docs/COMPATIBILITY-3.6.0-web-compatibility-preview.md) — current feature matrix and limitations.
- [`docs/STATUS.md`](docs/STATUS.md) — current implementation status.
- [`docs/MEDIA-PLAYBACK.md`](docs/MEDIA-PLAYBACK.md) — media boundaries and next steps.
- [`docs/ENGINE-GAP-AUDIT-3.5.0.md`](docs/ENGINE-GAP-AUDIT-3.5.0.md) — historical 3.5.0 gap inventory.
- [`docs/XBOX_BUILD.md`](docs/XBOX_BUILD.md) — cross-build guidance.
- [`THIRD_PARTY_NOTICES.md`](THIRD_PARTY_NOTICES.md) — dependency/licence boundaries.
