# UI do X360Browser 0.7.0

A UI real do Xbox está em `platform/xbox360/xsdk/main.c`. O arquivo `app/main.cpp` é apenas um demo de host para o núcleo C++ portable.

No XEX, o controle alterna entre três vistas: **Leitura**, **Links** e **Recursos**. A vista de recursos mostra URLs encontrados em HTML/CSS e fontes de mídia; não é uma galeria nem um player nesta versão. O desenho atual usa texto xSDK e não desenha layout CSS da página.
