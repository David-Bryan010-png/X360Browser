#!/usr/bin/env bash
set -euo pipefail

# Builds X360Browser 0.7.0 Dual-Engine Foundation for Xbox 360.
# The output is a native XEX plus the CA bundle needed for verified HTTPS.
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
XSDK_DIR="${XSDK_DIR:-$HOME/xsdk}"
GLSLANG_DIR="${GLSLANG_DIR:-$HOME/glslang-xenon}"
MBEDTLS_XENON_DIR="${MBEDTLS_XENON_DIR:-$HOME/mbedtls-xenon}"
CURL_XENON_DIR="${CURL_XENON_DIR:-$HOME/curl-xenon}"
PREFIX="${PREFIX:-$HOME/xsdk-gcc}"
WORK="${WORK:-$HOME/xsdk-gcc-work}"
JOBS="${JOBS:-2}"

for cmd in git cmake ninja make python3 curl; do
    command -v "$cmd" >/dev/null 2>&1 || {
        echo "Missing build command: $cmd" >&2
        exit 2
    }
done

clone_if_missing() {
    local repository="$1"
    local destination="$2"
    local branch="${3:-}"

    # Clone recursive submodules: mbedtls-xenon requires its framework
    # submodule, including the mbedtls_framework Python package.
    if [[ ! -d "$destination/.git" ]]; then
        if [[ -n "$branch" ]]; then
            git clone --depth 1 --recurse-submodules --shallow-submodules \
                --branch "$branch" "$repository" "$destination"
        else
            git clone --depth 1 --recurse-submodules --shallow-submodules \
                "$repository" "$destination"
        fi
    fi

    # Also repair incomplete checkouts left by an earlier failed build.
    git -C "$destination" submodule sync --recursive
    git -C "$destination" submodule update --init --recursive --depth 1
}

clone_if_missing https://github.com/xenosworks/xsdk.git "$XSDK_DIR"
clone_if_missing https://github.com/xenosworks/glslang-xenon.git "$GLSLANG_DIR" xenon
clone_if_missing https://github.com/xenosworks/mbedtls-xenon.git "$MBEDTLS_XENON_DIR" xenon
clone_if_missing https://github.com/xenosworks/curl-xenon.git "$CURL_XENON_DIR" xenon

# Fail early with a clear diagnostic rather than letting CMake or config.py
# fail later with "No module named mbedtls_framework".
if [[ ! -s "$MBEDTLS_XENON_DIR/framework/CMakeLists.txt" ]]; then
    echo "ERROR: Mbed TLS framework submodule is missing." >&2
    echo "Submodule status:" >&2
    git -C "$MBEDTLS_XENON_DIR" submodule status --recursive >&2 || true
    exit 4
fi

export PATH="$PREFIX/bin:$PATH"

if [[ ! -x "$PREFIX/bin/powerpc-xsdk-elf-gcc" ]]; then
    echo "== Building the Xbox 360 PowerPC toolchain (first build can take several minutes) =="
    PREFIX="$PREFIX" WORK="$WORK" JOBS="$JOBS" \
        bash "$XSDK_DIR/tools/toolchain/build.sh"
fi

if [[ ! -x "$GLSLANG_DIR/build/StandAlone/glslang" ]]; then
    echo "== Building glslang-xenon =="
    (cd "$GLSLANG_DIR" && python3 update_glslang_sources.py)
    cmake -S "$GLSLANG_DIR" -B "$GLSLANG_DIR/build" -G Ninja \
        -DCMAKE_BUILD_TYPE=Release \
        -DENABLE_OPT=ON \
        -DSPIRV_SKIP_EXECUTABLES=ON \
        -DGLSLANG_TESTS=OFF
    cmake --build "$GLSLANG_DIR/build" --parallel "$JOBS"
fi
cp "$GLSLANG_DIR/build/StandAlone/glslang" "$PREFIX/bin/glslang"

if [[ ! -f "$XSDK_DIR/build/libxsdk.a" || ! -f "$XSDK_DIR/build/host/libxsc.so" ]]; then
    echo "== Building the xSDK libraries =="
    make -C "$XSDK_DIR" -j"$JOBS" TOOLCHAIN="$PREFIX/bin/powerpc-xsdk-elf-"
fi

if [[ ! -s "$MBEDTLS_XENON_DIR/programs/xsdk/cacert.pem" ]]; then
    echo "ERROR: trusted CA bundle not found in mbedtls-xenon." >&2
    exit 4
fi

echo "== Building X360Browser web engine =="
cmake -S "$ROOT_DIR/platform/xbox360/xsdk" -B "$ROOT_DIR/build-xbox360" -G Ninja \
    -DCMAKE_TOOLCHAIN_FILE="$XSDK_DIR/cmake/xsdk.cmake" \
    -DXSDK_TOOLCHAIN="$PREFIX" \
    -DMBEDTLS_XENON_DIR="$MBEDTLS_XENON_DIR" \
    -DCURL_XENON_DIR="$CURL_XENON_DIR" \
    -DCMAKE_BUILD_TYPE=Release
cmake --build "$ROOT_DIR/build-xbox360" --parallel "$JOBS"

XEX="$ROOT_DIR/build-xbox360/X360Browser.xex"
CA_BUNDLE="$ROOT_DIR/build-xbox360/cacert.pem"
if [[ ! -s "$XEX" ]]; then
    echo "ERROR: XEX build completed without creating $XEX" >&2
    exit 3
fi
if [[ ! -s "$CA_BUNDLE" ]]; then
    echo "ERROR: XEX built, but the HTTPS CA bundle is missing: $CA_BUNDLE" >&2
    exit 5
fi

cp "$CURL_XENON_DIR/COPYING" "$ROOT_DIR/build-xbox360/LICENSE-curl.txt"
cp "$MBEDTLS_XENON_DIR/LICENSE" "$ROOT_DIR/build-xbox360/LICENSE-mbedTLS.txt"
cp "$XSDK_DIR/LICENSE" "$ROOT_DIR/build-xbox360/LICENSE-xsdk.txt"

echo "XEX: $XEX"
echo "CA bundle: $CA_BUNDLE"
echo "X360Browser 0.7.0: dispatcher, NativePlus resource discovery and NetSurf adapter contract built."
echo "Limit: NetSurf renderer, CSS layout, image rendering and audio/video playback are not linked yet."
