# NetSurf — backend preferencial planejado

A 0.7.0 contém um contrato de backend e um stub em `platform/xbox360/xsdk/netsurf_backend_stub.c`; o NetSurf real **não está dentro do XEX ainda**. O dispatcher já chama este backend primeiro quando `netsurf_backend_init()` reportar sucesso e usa NativePlus se o carregamento falhar.

Para substituir o stub, é necessário compilar as dependências NetSurf para `powerpc-xsdk-elf`, portar a camada de fetch/event loop e conectar a API de plotter/renderização à tela xSDK. A integração precisa manter limites de memória/tempo e validar imagens e CSS no console.

Fontes oficiais:
- https://www.netsurf-browser.org/
- https://github.com/netsurf-browser/netsurf
- https://www.netsurf-browser.org/projects/libnsfb/
