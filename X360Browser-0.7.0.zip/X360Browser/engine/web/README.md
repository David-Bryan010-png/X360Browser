# NativePlus Reader (0.7.0)

NativePlus é a rota de compatibilidade pequena do X360Browser. Usa libcurl/curl-xenon para HTTP(S), Mbed TLS para certificados e um parser HTML simplificado.

## O que reconhece

- Título, descrição, texto, links de âncora e quebras de blocos comuns.
- Cabeçalhos, formulários, scripts, iframes e links para folhas CSS.
- Imagens em `img`, `srcset`, `data-srcset`, poster de vídeo, ícones, metadados sociais e `url(...)` de CSS inline/interno.
- URLs diretas de vídeo e áudio, tipos MIME e embeds.
- Respostas não HTML pela cabeçalho `Content-Type`; o corpo é abortado após a identificação para não baixar mídia inteira para a RAM.

## O que não faz

A descoberta dos recursos não faz download completo, decodificação, desenho ou reprodução. O leitor não interpreta CSS como layout, não executa JavaScript, não implementa DOM completo e não renderiza aplicações SPA. Para um navegador visual é necessário integrar um motor como NetSurf e ligar o rendering ao frontend gráfico xSDK.
