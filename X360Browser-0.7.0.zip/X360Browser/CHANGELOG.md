# Changelog

## 0.7.0 — Console Compatibility and Direct Media
- Rebased on the richer NativePlus resource inventory from 0.5.0: responsive image candidates, CSS URLs, metadata, stylesheet/script/form/embed/media discovery and direct-resource recognition.
- Added search-address handling, safer URL normalization, forward/back navigation and persistent favorites.
- Added direct video source selection, bounded background downloads (512 MiB), MIME/HTML/manifest rejection and optional external player handoff.
- Added a three-line video player path configuration file and UTF-8 keyboard conversion.
- Added regression coverage for resource discovery, actual direct-video download, HTML masquerading as video and partial-file cleanup.
- NetSurf remains a documented stub; no CSS layout or JavaScript execution is claimed.

## 0.5.0 — NativePlus Web Resource Inventory
- Added resource inventory for images, CSS URLs, scripts, stylesheets, forms, iframe embeds and media.
- Added a backend dispatcher with NativePlus fallback when real NetSurf is unavailable.

## 0.4.0 — Web Engine Alpha
- Added real HTTP/HTTPS transport, TLS certificate validation and text/link extraction.
