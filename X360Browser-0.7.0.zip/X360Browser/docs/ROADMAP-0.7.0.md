# Roadmap after 0.7.0

1. Port NetSurf parserutils, hubbub, libcss and libdom for the xSDK PowerPC toolchain and add a real framebuffer frontend.
2. Bind fetches/timers/events to the existing network layer; set conservative arena limits and test common static CSS pages on hardware.
3. Add image decoding and clipping/rasterization that work with Xbox 360 memory limits.
4. Integrate Duktape only after HTML/CSS rendering works, then validate a limited ECMAScript/DOM subset.
5. Implement forms and keyboard focus, then audio/media APIs.
6. Treat Canvas 2D, WebSockets, WebAssembly, GPU/WebGL and games as distinct later projects with their own test pages.

A modern Chrome-class browser is not feasible as a single patch. Each compatibility claim must be backed by actual host tests and target-console verification.
