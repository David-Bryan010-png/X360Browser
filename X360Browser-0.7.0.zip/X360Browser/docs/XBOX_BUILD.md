# Build X360Browser 0.7.0 for Xbox 360

This project can be built from an Android phone using GitHub Actions; no local PowerPC compiler is required.

1. Upload `X360Browser-0.7.0.zip` to the repository root.
2. Place the external workflow file `build-xex-from-zip-0.7.0.yml` at `.github/workflows/build-xex-from-zip.yml`.
3. Run **Build X360Browser 0.7.0 — Console Edition** under Actions. Host tests must pass before the Xbox cross-build starts.
4. Download `X360Browser-0.7.0-web-engine.zip` after the build succeeds.

The package contains the XEX, `cacert.pem`, notices and the example video-player config. A green build does not prove compatibility with all web sites or with an external FFPlay build. NetSurf remains a stub; CSS layout, JavaScript and in-page media are not implemented.
