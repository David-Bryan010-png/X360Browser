# Testes do X360Browser 0.7.0

## Testes automatizados do motor web

Execute `python3 tests/run_host_tests.py`. O runner compila C17 com `-Wall -Wextra -Wshadow -Wconversion -Werror`, inicia um servidor HTTP local e verifica:

- título, descrição, texto e link relativo;
- imagens, `srcset`, recursos detectados em `style` e `<style>`;
- contadores de CSS, scripts, formulário, heading e iframe;
- catálogo de fontes de vídeo/áudio/embeds e download de um vídeo local sintético;
- rejeição de HTML servido como MP4, arquivos parciais após falha e manifestos HLS;
- o shell Xbox passa por uma verificação C17 de sintaxe com stubs das assinaturas xSDK.
- dispatcher seleciona NativePlus quando NetSurf não está vinculado, sem reportar falsamente um fallback durante a página.

## Testes do núcleo portable

```sh
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release -DX360BROWSER_BUILD_TESTS=ON
cmake --build build --parallel 2
ctest --test-dir build --output-on-failure
```

## Ainda exige teste físico

- compilação final de `X360Browser.xex` pelo workflow 0.7.0;
- conexão/DNS/HTTPS no Xbox 360 real;
- teclado Xbox, navegação por controle, memória e sessões longas.
