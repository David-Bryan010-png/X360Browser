# Compatibility matrix — 0.7.0

| Capability | State |
|---|---|
| HTTP/HTTPS transport | Implemented in source; hardware DNS/TLS test required |
| HTTPS certificate checking | Enabled; keep cacert.pem beside the XEX |
| Static HTML text/title/link extraction | Implemented (lightweight parser) |
| Relative links and resource URLs | Basic handling |
| Image URL/srcset and CSS URL discovery | Inventory only; image pixels are not drawn |
| Stylesheet/script/form/iframe references | Inventory only; JS and CSS layout not executed |
| Direct video source inventory | Implemented for common HTML video/source nodes |
| Direct video-file download | Implemented in source, max 512 MiB, MIME/HTML/manifest guard |
| External player launch | Optional dependency; must be tested with installed player |
| Bookmarks/search/history | Implemented in source |
| CSS layout/responsive rendering | Not implemented |
| JavaScript/DOM and modern SPA frameworks | Not implemented |
| Embedded audio/video, HLS/DASH, DRM | Not supported |
| Canvas/WebGL/WebAssembly/WebSockets/game compatibility | Not implemented |
| Real NetSurf backend | Stub only |

Discovered resource references are not equivalent to rendering those resources.
