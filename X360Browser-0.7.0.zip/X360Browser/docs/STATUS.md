# X360Browser 0.7.0 status

## Implemented in source
- HTTP/HTTPS page fetch with certificate verification and bounded HTML download.
- NativePlus HTML resource inventory for links, image URL/srcset, CSS URLs, stylesheets, script references, forms, headings, iframe embeds and audio/video URLs.
- Plain-text reading with metadata, image alt-label fallback and relative URL handling.
- Address search, back/forward navigation and persistent favorites.
- Direct-video source selection, 512 MiB bounded download, MIME and manifest guards, and optional XEX player launch-data handoff.
- Host regression suite for the parser, dispatcher and media-download validation.

## Not implemented
- Actual CSS layout, JavaScript/DOM, drawing image pixels, embedded player, Canvas/WebGL, WebAssembly, WebSockets, HLS/DASH or DRM.
- Real NetSurf: `netsurf_backend_stub.c` is still a stub; NativePlus is the actual fallback.

## Verification still required
Run the bundled host test workflow, then verify the PowerPC XEX build and physical console operation. External FFPlay path/launch-data compatibility depends on the user's installed player. Do not treat host test success as full website compatibility.
