# X360Browser 0.7.0 — arquitetura

## Camadas do navegador Xbox

- **UI xSDK** (`platform/xbox360/xsdk/main.c`): interface 720p, controle Xbox, barra de endereço, histórico em memória e três telas (leitor, links, recursos).
- **Dispatcher** (`web_engine_dispatch.c`): inicializa os backends e tenta NetSurf primeiro quando o adaptador reporta disponibilidade. Uma falha de carregamento passa ao NativePlus.
- **NetSurf adapter** (`netsurf_backend_stub.c`): contrato e stub de segurança. O backend retorna indisponível até que as bibliotecas NetSurf e o frontend de desenho sejam realmente compilados e ligados.
- **NativePlus** (`web_engine.c`): libcurl HTTP/HTTPS, TLS verificado, limite de HTML, parser leve, texto/links e inventário de recursos.
- **xSDK graphics/text**: no momento desenha a UI e o texto extraído, não os pixels das páginas web.

## Fluxo de carregamento

1. A UI valida o esquema HTTP(S) e inicia uma thread de rede.
2. O dispatcher tenta o motor NetSurf real apenas se o backend estiver ligado e pronto.
3. Se NetSurf falhar no carregamento, o dispatcher passa o endereço a NativePlus.
4. NativePlus baixa HTML limitado, identifica metadados e links, cataloga URLs de recursos e expõe uma visualização de leitura.
5. O cabeçalho HTTP `Content-Type` permite parar logo um download que seja imagem, áudio ou vídeo em vez de guardá-lo como HTML.

**Estado atual:** como o backend NetSurf nesta versão é um stub, a navegação parte diretamente para NativePlus. Portanto, o fallback automático está preparado no código, mas o primeiro renderer não está ativo nesta build.

## Limites e segurança

- Só são aceitos endereços HTTP/HTTPS na UI; a engine bloqueia protocolos diferentes na configuração do libcurl.
- Verificação de hostname/certificado TLS permanece ativa e usa `cacert.pem`.
- HTML é limitado a 512 KiB; redirects, tempo de conexão e tempo total são limitados.
- JavaScript não é executado. URLs encontradas em `<script>` são catalogadas, mas não processadas como código.
- O leitor não decodifica imagens nem reproduz mídia. CSS e `srcset` são usados apenas para descobrir URLs, não para calcular layout.
- Uma integração real de NetSurf requer portar parserutils, hubbub, libcss, libdom, libnsutils, libwapcaplet, decodificadores e o frontend de desenho para o xSDK, depois medir RAM/tempo no console.
