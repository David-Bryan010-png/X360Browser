#include "../platform/xbox360/xsdk/web_engine.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>

static int fail(const char *message)
{
    fprintf(stderr, "FAIL: %s\n", message);
    return 1;
}

int main(void)
{
    WebEnginePage *page = (WebEnginePage *)calloc(1U, sizeof(*page));
    char error[192] = {0};
    int result;
    if (page == NULL)
        return fail("page allocation");
    if (!web_engine_native_init()) {
        free(page);
        return fail("libcurl init");
    }

    result = web_engine_native_fetch("http://127.0.0.1:18765/page.html", page,
                                     error, sizeof(error));
    if (!result) {
        fprintf(stderr, "fetch error: %s\n", error);
        web_engine_native_shutdown();
        free(page);
        return 1;
    }
    if (strcmp(page->title, "X360Browser Test") != 0)
        return fail("title extraction");
    if (strcmp(page->description, "Fixture page for NativePlus") != 0)
        return fail("meta description");
    {
        size_t i;
        int found_relative = 0;
        int found_video = 0;
        int exposed_manifest = 0;
        for (i = 0U; i < page->link_count; ++i) {
            if (strcmp(page->links[i].url, "http://127.0.0.1:18765/next") == 0)
                found_relative = 1;
            if (strcmp(page->links[i].url, "http://127.0.0.1:18765/clip.mp4") == 0 &&
                page->links[i].is_video != 0)
                found_video = 1;
            if (strstr(page->links[i].url, "playlist.m3u8") != NULL)
                exposed_manifest = 1;
        }
        if (!found_relative)
            return fail("relative link resolution");
        if (!found_video)
            return fail("direct HTML video source is selectable");
        if (exposed_manifest)
            return fail("HLS manifest is not mislabelled as a direct video file");
    }
    if (page->image_count < 5U)
        return fail("image/source discovery count");
    {
        size_t i;
        int found_main = 0;
        int found_srcset = 0;
        int found_css = 0;
        for (i = 0U; i < page->image_count; ++i) {
            if (strcmp(page->images[i].url, "http://127.0.0.1:18765/assets/picture.png") == 0)
                found_main = 1;
            if (strcmp(page->images[i].url, "http://127.0.0.1:18765/assets/picture-small.png") == 0)
                found_srcset = 1;
            if (strcmp(page->images[i].url, "http://127.0.0.1:18765/assets/background.webp") == 0 ||
                strcmp(page->images[i].url, "http://127.0.0.1:18765/assets/inline.png") == 0)
                found_css = 1;
        }
        if (!found_main || !found_srcset || !found_css)
            return fail("img, srcset and CSS url(...) discovery");
    }
    if (page->media_count < 4U)
        return fail("stylesheet/script/video/audio/embed extraction");
    if (page->stylesheet_count != 1U || page->script_count != 1U || page->form_count != 1U || page->heading_count != 1U)
        return fail("page capability counters");
    if (strstr(page->text, "[Image: Sample photo]") == NULL)
        return fail("image alt placeholder");

    memset(page, 0, sizeof(*page));
    result = web_engine_native_fetch("http://127.0.0.1:18765/big.bin", page,
                                     error, sizeof(error));
    if (!result || !page->is_direct_resource || strstr(page->text, "video/mp4") == NULL)
        return fail("direct media is detected and body is not parsed as HTML");

    {
        const char *download_path = "x360browser-test-video.bin";
        FILE *download;
        char payload[64] = { 0 };
        size_t got;
        (void)remove(download_path);
        if (!web_engine_download_video("http://127.0.0.1:18765/clip.mp4", download_path,
                                       error, sizeof(error))) {
            fprintf(stderr, "video download error: %s\n", error);
            return fail("bounded direct video download");
        }
        download = fopen(download_path, "rb");
        if (download == NULL) return fail("downloaded video file exists");
        got = fread(payload, 1U, sizeof(payload) - 1U, download);
        (void)fclose(download);
        (void)remove(download_path);
        if (got != strlen("FAKE-MP4-V0.7") || memcmp(payload, "FAKE-MP4-V0.7", got) != 0)
            return fail("downloaded video bytes match fixture");

        (void)remove(download_path);
        if (web_engine_download_video("http://127.0.0.1:18765/html-looks-like-video.mp4", download_path,
                                      error, sizeof(error)))
            return fail("HTML response must not be accepted as a video file");
        download = fopen(download_path, "rb");
        if (download != NULL) { (void)fclose(download); return fail("failed video download leaves no partial file"); }
        if (errno != ENOENT)
            return fail("failed video file cleanup status");

        (void)remove(download_path);
        if (web_engine_download_video("http://127.0.0.1:18765/playlist.m3u8", download_path,
                                      error, sizeof(error)))
            return fail("HLS manifest must not be accepted as a direct video file");
        download = fopen(download_path, "rb");
        if (download != NULL) { (void)fclose(download); return fail("manifest rejection removes the partial file"); }
        if (errno != ENOENT)
            return fail("manifest cleanup status");
    }

    web_engine_native_shutdown();
    free(page);
    puts("PASS: HTML metadata, links/video sources, img/srcset/CSS URL discovery, resource inventory, direct-resource guard and direct-video download validation");
    return 0;
}
