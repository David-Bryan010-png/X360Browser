#include "kernel.h"
NTSTATUS xsdk_gpu_open(void); NTSTATUS xsdk_gpu_close(void); void xsdk_gpu_set_target(uint32_t,uint32_t); void xsdk_gpu_resolve(uint32_t,uint32_t,uint32_t,uint32_t);
