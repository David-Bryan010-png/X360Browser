# X360Browser 0.7.0 — Console Edition

A native Xbox 360 homebrew browser/reader for RGH/JTAG. This release is a larger compatibility update built on the resource-aware NativePlus engine.

## New in 0.7.0
- More extensive HTML resource discovery: links, responsive image URLs (`srcset`), CSS `url(...)`, stylesheet and script references, forms, heading counts, iframes and video/audio sources.
- Direct HTML video source rows are selectable; common direct media file URLs can be downloaded in the background with a 512 MiB cap and sent to an optional external FFPlay-compatible XEX.
- Address-bar search, improved UTF-8 keyboard conversion, safer URL checks, forward/back history and persistent saved favorites.
- Cookie persistence where the console's working directory is writable.
- A pre-build host test suite now checks HTML resource extraction and direct-video download rejection cases.

## Controls
- D-pad Up/Down: scroll page or select the current links/resources/favorites list.
- LB/RB: scroll by one screen.
- A: open address keyboard or selected link/resource.
- X: cycle reader → links → discovered resources.
- Y: reload; in Favorites view, remove selected favorite.
- B / D-pad Left: go back; D-pad Right: go forward.
- Start: home. Left Thumb: save current page. Right Thumb: toggle Favorites. Back: exit.

## Video setup
`X360Browser-video-config.txt` is optional and contains exactly three lines: external player XEX path, browser return XEX path and destination video path. The default values are listed in `X360Browser-video-config.example.txt`. The player is NOT bundled. Playback only works if the external player accepts the launch-data format (filename and calling-app path) and supports the downloaded container/codecs. Direct MP4/MKV/AVI/WebM-like files are the target. HLS/DASH manifests, DRM, segmented streaming and JavaScript-based video sites are not supported. A file is capped at 512 MiB and partial downloads are removed after errors.

## Compatibility boundaries
This is still a text-oriented reader, not a full modern browser. It discovers resource URLs but does not decode/draw image pixels, execute JavaScript/DOM, apply CSS layout, or play audio/video inside the webpage surface. It cannot currently run modern SPAs, Canvas/WebGL, WebAssembly or browser games such as Among Us web ports. The NetSurf backend in this build is a capability stub; the dispatcher only falls back to NativePlus. Integrating real NetSurf, CSS layout and a JS engine must be a separate porting milestone.

## Build and verification
The GitHub Actions workflow is intended to run strict host C tests and the portable C++ core tests before cross-compiling the Xbox XEX. Host tests do not prove successful PowerPC linkage or console hardware behavior. DNS, HTTPS, controller UI, writable save paths and the external video-player handoff must be tested on the actual Xbox. Keep `cacert.pem` beside `X360Browser.xex`; keep the console date/time correct.

## Third-party projects
- xSDK: https://github.com/xenosworks/xsdk
- curl-xenon: https://github.com/xenosworks/curl-xenon
- mbedtls-xenon: https://github.com/xenosworks/mbedtls-xenon
- NetSurf (not linked in this release): https://www.netsurf-browser.org/
