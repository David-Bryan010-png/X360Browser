# Xbox 360 target — X360Browser 0.7.0

O XEX é um shell nativo xSDK com libcurl/Mbed TLS e o leitor NativePlus. As telas disponíveis são leitura de texto HTML, links e inventário de recursos detectados.

O dispatcher dá preferência ao NetSurf quando o backend real estiver disponível e usa NativePlus quando o motor não existir ou falhar. Nesta distribuição, o NetSurf ainda é um stub e não há renderização visual completa das páginas.

Consulte `../docs/STATUS.md` para a matriz exata do que está implementado, o que foi testado em host e o que ainda precisa ser validado no Xbox real.
