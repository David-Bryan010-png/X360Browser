X360Browser 0.7.0 — Console Edition

Keep cacert.pem in the same directory as X360Browser.xex. The external video player is optional and not bundled.

Controls: D-pad Up/Down scroll/select; LB/RB page scroll; A opens/activates; X cycles page/links/resources; Y reloads or removes a favorite; B/D-pad Left back; D-pad Right forward; Start home; Left Thumb favorite; Right Thumb favorite list; Back exit.

Video: direct media URLs can be downloaded to the configured path (default game:\X360Browser-video.mp4), with a 512 MiB limit and HTTPS certificate checks. A compatible external player is launched with basic launch data containing video path and return target. HLS/DASH, DRM and JavaScript video players are not supported.

This is a resource-aware text reader, not a full modern browser: no executed JS, CSS layout, image-pixel renderer, or embedded video playback. NetSurf remains a stub.
