#include "web_engine.h"

#include <curl/curl.h>
#include <ctype.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>

#define WEB_ENGINE_MAX_HTML (512U * 1024U)
#define WEB_ENGINE_MAX_VIDEO (512U * 1024U * 1024U)
#define HTML_ATTR_CAP 512U

typedef struct {
    FILE *file;
    size_t bytes;
    int too_large;
} VideoFileSink;

static size_t receive_video_file(char *incoming, size_t unit_size, size_t count, void *user_data)
{
    VideoFileSink *sink = (VideoFileSink *)user_data;
    size_t bytes;
    size_t written;
    if (unit_size != 0U && count > SIZE_MAX / unit_size)
        return 0U;
    bytes = unit_size * count;
    if (sink->bytes > WEB_ENGINE_MAX_VIDEO || bytes > WEB_ENGINE_MAX_VIDEO - sink->bytes) {
        sink->too_large = 1;
        return 0U;
    }
    written = fwrite(incoming, 1U, bytes, sink->file);
    sink->bytes += written;
    return written;
}

typedef struct {
    char *data;
    size_t length;
    size_t capacity;
    int too_large;
    int direct_resource;
    char content_type[WEB_ENGINE_CONTENT_TYPE_CAP];
} HtmlBuffer;

static size_t receive_html(char *incoming, size_t unit_size, size_t count, void *user_data)
{
    HtmlBuffer *buffer = (HtmlBuffer *)user_data;
    size_t bytes;
    size_t required;
    size_t next_capacity;
    char *next;

    if (unit_size != 0U && count > SIZE_MAX / unit_size)
        return 0U;
    bytes = unit_size * count;
    if (bytes == 0U)
        return 0U;
    /* Do not waste console RAM downloading image/video payloads into the HTML buffer. */
    if (buffer->direct_resource)
        return 0U;
    if (bytes > WEB_ENGINE_MAX_HTML - buffer->length) {
        buffer->too_large = 1;
        return 0U;
    }

    required = buffer->length + bytes + 1U;
    if (required > buffer->capacity) {
        next_capacity = buffer->capacity == 0U ? 8192U : buffer->capacity;
        while (next_capacity < required) {
            if (next_capacity > WEB_ENGINE_MAX_HTML / 2U) {
                next_capacity = WEB_ENGINE_MAX_HTML + 1U;
                break;
            }
            next_capacity *= 2U;
        }
        if (next_capacity > WEB_ENGINE_MAX_HTML + 1U)
            next_capacity = WEB_ENGINE_MAX_HTML + 1U;
        next = (char *)realloc(buffer->data, next_capacity);
        if (next == NULL)
            return 0U;
        buffer->data = next;
        buffer->capacity = next_capacity;
    }

    memcpy(buffer->data + buffer->length, incoming, bytes);
    buffer->length += bytes;
    buffer->data[buffer->length] = '\0';
    return bytes;
}

static size_t receive_header(char *incoming, size_t unit_size, size_t count, void *user_data)
{
    HtmlBuffer *buffer = (HtmlBuffer *)user_data;
    size_t bytes;
    const char *value;
    size_t length;
    if (unit_size != 0U && count > SIZE_MAX / unit_size)
        return 0U;
    bytes = unit_size * count;
    if (bytes == 0U)
        return 0U;
    if (bytes < 13U || strncasecmp(incoming, "Content-Type:", 13U) != 0)
        return bytes;
    value = incoming + 13U;
    while ((size_t)(value - incoming) < bytes && (*value == ' ' || *value == '\t'))
        ++value;
    length = bytes - (size_t)(value - incoming);
    while (length > 0U && (value[length - 1U] == '\r' || value[length - 1U] == '\n' ||
                           value[length - 1U] == ' ' || value[length - 1U] == '\t'))
        --length;
    if (length >= sizeof(buffer->content_type))
        length = sizeof(buffer->content_type) - 1U;
    memcpy(buffer->content_type, value, length);
    buffer->content_type[length] = '\0';
    /* Redirects can change MIME type; do not carry an earlier response's flag forward. */
    buffer->direct_resource = buffer->content_type[0] != '\0' &&
        strncasecmp(buffer->content_type, "text/html", 9U) != 0 &&
        strncasecmp(buffer->content_type, "application/xhtml+xml", 21U) != 0 &&
        strncasecmp(buffer->content_type, "text/plain", 10U) != 0;
    return bytes;
}

static int ascii_equal_nocase(char left, char right)
{
    return tolower((unsigned char)left) == tolower((unsigned char)right);
}

static int starts_nocase(const char *text, const char *prefix)
{
    while (*prefix != '\0') {
        if (*text == '\0' || !ascii_equal_nocase(*text, *prefix))
            return 0;
        ++text;
        ++prefix;
    }
    return 1;
}

static const char *find_nocase(const char *text, const char *needle)
{
    const char *candidate;
    if (text == NULL || needle == NULL || *needle == '\0')
        return NULL;
    for (candidate = text; *candidate != '\0'; ++candidate) {
        if (starts_nocase(candidate, needle))
            return candidate;
    }
    return NULL;
}

static void set_error(char *error, size_t capacity, const char *message)
{
    if (error == NULL || capacity == 0U)
        return;
    (void)snprintf(error, capacity, "%s", message != NULL ? message : "Unknown error");
}

static void append_utf8(char *destination, size_t capacity, size_t *length, unsigned int codepoint)
{
    char encoded[4];
    size_t count = 0U;

    if (capacity == 0U || *length >= capacity - 1U)
        return;
    if (codepoint == 0U || (codepoint < 0x20U && codepoint != '\n' && codepoint != '\t'))
        codepoint = '?';
    if (codepoint <= 0x7FU) {
        encoded[count++] = (char)codepoint;
    } else if (codepoint <= 0x7FFU) {
        encoded[count++] = (char)(0xC0U | (codepoint >> 6U));
        encoded[count++] = (char)(0x80U | (codepoint & 0x3FU));
    } else if (codepoint <= 0xFFFFU) {
        encoded[count++] = (char)(0xE0U | (codepoint >> 12U));
        encoded[count++] = (char)(0x80U | ((codepoint >> 6U) & 0x3FU));
        encoded[count++] = (char)(0x80U | (codepoint & 0x3FU));
    } else if (codepoint <= 0x10FFFFU) {
        encoded[count++] = (char)(0xF0U | (codepoint >> 18U));
        encoded[count++] = (char)(0x80U | ((codepoint >> 12U) & 0x3FU));
        encoded[count++] = (char)(0x80U | ((codepoint >> 6U) & 0x3FU));
        encoded[count++] = (char)(0x80U | (codepoint & 0x3FU));
    }
    if (*length + count >= capacity)
        return;
    memcpy(destination + *length, encoded, count);
    *length += count;
    destination[*length] = '\0';
}

static unsigned int decode_entity(const char *entity, size_t length)
{
    size_t i;
    unsigned int value = 0U;
    unsigned int base = 10U;

    if (length == 0U)
        return 0U;
    if (entity[0] == '#') {
        i = 1U;
        if (i < length && (entity[i] == 'x' || entity[i] == 'X')) {
            base = 16U;
            ++i;
        }
        if (i == length)
            return 0U;
        for (; i < length; ++i) {
            unsigned int digit;
            unsigned char c = (unsigned char)entity[i];
            if (c >= '0' && c <= '9')
                digit = (unsigned int)(c - '0');
            else if (base == 16U && c >= 'a' && c <= 'f')
                digit = (unsigned int)(c - 'a' + 10);
            else if (base == 16U && c >= 'A' && c <= 'F')
                digit = (unsigned int)(c - 'A' + 10);
            else
                return 0U;
            if (digit >= base || value > (0x10FFFFU - digit) / base)
                return 0U;
            value = value * base + digit;
        }
        return value <= 0x10FFFFU ? value : 0U;
    }
    if (length == 3U && memcmp(entity, "amp", 3U) == 0) return '&';
    if (length == 2U && memcmp(entity, "lt", 2U) == 0) return '<';
    if (length == 2U && memcmp(entity, "gt", 2U) == 0) return '>';
    if (length == 4U && memcmp(entity, "quot", 4U) == 0) return '"';
    if (length == 4U && memcmp(entity, "apos", 4U) == 0) return '\'';
    if (length == 4U && memcmp(entity, "nbsp", 4U) == 0) return ' ';
    if (length == 5U && memcmp(entity, "mdash", 5U) == 0) return 0x2014U;
    if (length == 5U && memcmp(entity, "ndash", 5U) == 0) return 0x2013U;
    if (length == 6U && memcmp(entity, "hellip", 6U) == 0) return 0x2026U;
    if (length == 4U && memcmp(entity, "copy", 4U) == 0) return 0x00A9U;
    return 0U;
}

static void append_normalized(char *destination, size_t capacity, size_t *length,
                              unsigned int codepoint, int keep_newline)
{
    if (codepoint == '\r')
        return;
    if (codepoint == '\n' && keep_newline) {
        if (*length > 0U && destination[*length - 1U] != '\n' && *length < capacity - 1U) {
            destination[(*length)++] = '\n';
            destination[*length] = '\0';
        }
        return;
    }
    if (codepoint == '\t' || codepoint == '\n' || codepoint == ' ')
        codepoint = ' ';
    if (codepoint == ' ') {
        if (*length == 0U || destination[*length - 1U] == ' ' || destination[*length - 1U] == '\n')
            return;
    }
    append_utf8(destination, capacity, length, codepoint);
}

static void append_decoded_text(WebEnginePage *page, const char *text, size_t bytes,
                                int in_title, int active_link)
{
    size_t i = 0U;
    while (i < bytes) {
        unsigned int codepoint = (unsigned char)text[i];
        if (text[i] == '&') {
            size_t end = i + 1U;
            while (end < bytes && end - i <= 12U && text[end] != ';' &&
                   text[end] != '<' && !isspace((unsigned char)text[end]))
                ++end;
            if (end < bytes && text[end] == ';' && end > i + 1U) {
                unsigned int decoded = decode_entity(text + i + 1U, end - i - 1U);
                if (decoded != 0U) {
                    codepoint = decoded;
                    i = end + 1U;
                } else {
                    ++i;
                }
            } else {
                ++i;
            }
        } else if ((codepoint & 0xE0U) == 0xC0U && i + 1U < bytes &&
                   (((unsigned char)text[i + 1U]) & 0xC0U) == 0x80U) {
            codepoint = ((codepoint & 0x1FU) << 6U) | (((unsigned char)text[i + 1U]) & 0x3FU);
            i += 2U;
        } else if ((codepoint & 0xF0U) == 0xE0U && i + 2U < bytes &&
                   (((unsigned char)text[i + 1U]) & 0xC0U) == 0x80U &&
                   (((unsigned char)text[i + 2U]) & 0xC0U) == 0x80U) {
            codepoint = ((codepoint & 0x0FU) << 12U) |
                        ((((unsigned char)text[i + 1U]) & 0x3FU) << 6U) |
                        (((unsigned char)text[i + 2U]) & 0x3FU);
            i += 3U;
        } else if ((codepoint & 0xF8U) == 0xF0U && i + 3U < bytes &&
                   (((unsigned char)text[i + 1U]) & 0xC0U) == 0x80U &&
                   (((unsigned char)text[i + 2U]) & 0xC0U) == 0x80U &&
                   (((unsigned char)text[i + 3U]) & 0xC0U) == 0x80U) {
            codepoint = ((codepoint & 0x07U) << 18U) |
                        ((((unsigned char)text[i + 1U]) & 0x3FU) << 12U) |
                        ((((unsigned char)text[i + 2U]) & 0x3FU) << 6U) |
                        (((unsigned char)text[i + 3U]) & 0x3FU);
            i += 4U;
        } else {
            ++i;
        }

        if (in_title) {
            size_t title_length = strlen(page->title);
            append_normalized(page->title, sizeof(page->title), &title_length, codepoint, 0);
        } else {
            append_normalized(page->text, sizeof(page->text), &page->text_length, codepoint, 0);
            if (active_link >= 0 && (size_t)active_link < page->link_count) {
                WebEngineLink *link = &page->links[(size_t)active_link];
                size_t label_length = strlen(link->label);
                append_normalized(link->label, sizeof(link->label), &label_length, codepoint, 0);
            }
        }
    }
}

static void append_line_break(WebEnginePage *page)
{
    if (page->text_length == 0U)
        return;
    if (page->text[page->text_length - 1U] != '\n' && page->text_length < sizeof(page->text) - 1U) {
        page->text[page->text_length++] = '\n';
        page->text[page->text_length] = '\0';
    }
}

static int is_block_tag(const char *name)
{
    static const char *const block_tags[] = {
        "address", "article", "aside", "blockquote", "br", "dd", "div", "dl", "dt",
        "fieldset", "figcaption", "figure", "footer", "form", "h1", "h2", "h3", "h4",
        "h5", "h6", "header", "hr", "li", "main", "nav", "ol", "p", "pre", "section",
        "table", "tr", "ul"
    };
    size_t i;
    for (i = 0U; i < sizeof(block_tags) / sizeof(block_tags[0]); ++i) {
        if (strcmp(name, block_tags[i]) == 0)
            return 1;
    }
    return 0;
}

static void decode_attribute_entities(char *value, size_t capacity)
{
    size_t read_pos = 0U;
    size_t write_pos = 0U;
    size_t length;
    if (value == NULL || capacity == 0U) return;
    length = strlen(value);
    while (read_pos < length && write_pos + 1U < capacity) {
        if (value[read_pos] == '&') {
            size_t end = read_pos + 1U;
            while (end < length && end - read_pos <= 12U && value[end] != ';' &&
                   value[end] != '<' && !isspace((unsigned char)value[end])) ++end;
            if (end < length && value[end] == ';' && end > read_pos + 1U) {
                unsigned int cp = decode_entity(value + read_pos + 1U, end - read_pos - 1U);
                if (cp != 0U) {
                    char encoded[4];
                    size_t n = 0U;
                    if (cp <= 0x7FU) encoded[n++] = (char)cp;
                    else if (cp <= 0x7FFU) { encoded[n++] = (char)(0xC0U | (cp >> 6U)); encoded[n++] = (char)(0x80U | (cp & 0x3FU)); }
                    else if (cp <= 0xFFFFU) { encoded[n++] = (char)(0xE0U | (cp >> 12U)); encoded[n++] = (char)(0x80U | ((cp >> 6U) & 0x3FU)); encoded[n++] = (char)(0x80U | (cp & 0x3FU)); }
                    else { encoded[n++] = (char)(0xF0U | (cp >> 18U)); encoded[n++] = (char)(0x80U | ((cp >> 12U) & 0x3FU)); encoded[n++] = (char)(0x80U | ((cp >> 6U) & 0x3FU)); encoded[n++] = (char)(0x80U | (cp & 0x3FU)); }
                    if (write_pos + n >= capacity) break;
                    memmove(value + write_pos + n, value + end + 1U, length - end);
                    memcpy(value + write_pos, encoded, n);
                    length = length - (end + 1U - read_pos) + (write_pos - read_pos) + n;
                    write_pos += n;
                    read_pos = write_pos;
                    continue;
                }
            }
        }
        value[write_pos++] = value[read_pos++];
    }
    value[write_pos] = '\0';
}

static int copy_attribute(const char *tag, size_t length, const char *wanted,
                          char *out, size_t out_capacity)
{
    size_t i = 0U;
    size_t wanted_length = strlen(wanted);
    while (i < length && !isspace((unsigned char)tag[i]) && tag[i] != '/')
        ++i;
    while (i < length) {
        size_t name_start;
        size_t name_length;
        size_t value_start;
        size_t value_length;
        char quote = '\0';
        while (i < length && (isspace((unsigned char)tag[i]) || tag[i] == '/'))
            ++i;
        name_start = i;
        while (i < length && !isspace((unsigned char)tag[i]) && tag[i] != '=' && tag[i] != '/')
            ++i;
        name_length = i - name_start;
        if (name_length == 0U) {
            if (i < length) ++i;
            continue;
        }
        while (i < length && isspace((unsigned char)tag[i])) ++i;
        if (i >= length || tag[i] != '=')
            continue;
        ++i;
        while (i < length && isspace((unsigned char)tag[i])) ++i;
        if (i < length && (tag[i] == '\'' || tag[i] == '"')) {
            quote = tag[i++];
            value_start = i;
            while (i < length && tag[i] != quote) ++i;
            value_length = i - value_start;
            if (i < length) ++i;
        } else {
            value_start = i;
            while (i < length && !isspace((unsigned char)tag[i]) && tag[i] != '>') ++i;
            value_length = i - value_start;
        }
        if (name_length == wanted_length &&
            strncasecmp(tag + name_start, wanted, wanted_length) == 0) {
            size_t copy_length = value_length < out_capacity - 1U ? value_length : out_capacity - 1U;
            memcpy(out, tag + value_start, copy_length);
            out[copy_length] = '\0';
            decode_attribute_entities(out, out_capacity);
            return 1;
        }
    }
    out[0] = '\0';
    return 0;
}

static void resolve_link_url(const char *base, const char *href,
                             char *out, size_t out_capacity)
{
    const char *scheme_end;
    const char *host_end;
    const char *last_slash;
    size_t origin_length;
    size_t base_directory_length;
    size_t scheme_length;

    if (out_capacity == 0U)
        return;
    out[0] = '\0';
    if (href == NULL || href[0] == '\0' || href[0] == '#')
        return;
    if (starts_nocase(href, "javascript:") || starts_nocase(href, "mailto:") ||
        starts_nocase(href, "data:"))
        return;
    if (starts_nocase(href, "http://") || starts_nocase(href, "https://")) {
        (void)snprintf(out, out_capacity, "%s", href);
        return;
    }
    scheme_end = strstr(base, "://");
    if (scheme_end == NULL) {
        (void)snprintf(out, out_capacity, "%s", href);
        return;
    }
    scheme_length = (size_t)(scheme_end - base);
    if (starts_nocase(href, "//")) {
        (void)snprintf(out, out_capacity, "%.*s:%s", (int)scheme_length, base, href);
        return;
    }
    host_end = strchr(scheme_end + 3, '/');
    origin_length = host_end == NULL ? strlen(base) : (size_t)(host_end - base);
    if (href[0] == '/') {
        (void)snprintf(out, out_capacity, "%.*s%s", (int)origin_length, base, href);
        return;
    }
    last_slash = strrchr(base, '/');
    if (last_slash == NULL || last_slash < scheme_end + 3) {
        base_directory_length = strlen(base);
        (void)snprintf(out, out_capacity, "%.*s/%s", (int)base_directory_length, base, href);
    } else {
        base_directory_length = (size_t)(last_slash - base + 1);
        (void)snprintf(out, out_capacity, "%.*s%s", (int)base_directory_length, base, href);
    }
}

static int contains_nocase(const char *text, const char *needle)
{
    return text != NULL && needle != NULL && find_nocase(text, needle) != NULL;
}

static int url_has_suffix(const char *url, const char *suffix)
{
    const char *query;
    const char *fragment;
    const char *end;
    size_t url_length;
    size_t suffix_length;
    if (url == NULL || suffix == NULL)
        return 0;
    query = strchr(url, '?');
    fragment = strchr(url, '#');
    end = url + strlen(url);
    if (query != NULL && query < end) end = query;
    if (fragment != NULL && fragment < end) end = fragment;
    url_length = (size_t)(end - url);
    suffix_length = strlen(suffix);
    return url_length >= suffix_length &&
           strncasecmp(end - suffix_length, suffix, suffix_length) == 0;
}

static unsigned int parse_dimension(const char *value)
{
    unsigned long parsed;
    char *end = NULL;
    if (value == NULL || value[0] == '\0')
        return 0U;
    parsed = strtoul(value, &end, 10);
    if (end == value || (*end != '\0' && *end != 'p' && *end != '%') || parsed > 8192UL)
        return 0U;
    return (unsigned int)parsed;
}

static void add_page_image(WebEnginePage *page, const char *base_url,
                           const char *raw_url, const char *alt,
                           unsigned int width, unsigned int height)
{
    char resolved[WEB_ENGINE_RESOURCE_URL_CAP];
    size_t i;
    if (raw_url == NULL || raw_url[0] == '\0' || page->image_count >= WEB_ENGINE_IMAGE_COUNT)
        return;
    resolve_link_url(base_url, raw_url, resolved, sizeof(resolved));
    if (resolved[0] == '\0')
        return;
    for (i = 0U; i < page->image_count; ++i) {
        if (strcmp(page->images[i].url, resolved) == 0)
            return;
    }
    {
        WebEngineImage *image = &page->images[page->image_count++];
        (void)snprintf(image->url, sizeof(image->url), "%s", resolved);
        (void)snprintf(image->alt, sizeof(image->alt), "%s",
                       alt != NULL && alt[0] != '\0' ? alt : "Image without alt text");
        image->width = width;
        image->height = height;
    }
}

static void add_page_media(WebEnginePage *page, const char *base_url,
                           const char *raw_url, const char *kind,
                           const char *mime_type)
{
    char resolved[WEB_ENGINE_RESOURCE_URL_CAP];
    size_t i;
    if (raw_url == NULL || raw_url[0] == '\0' || page->media_count >= WEB_ENGINE_MEDIA_COUNT)
        return;
    resolve_link_url(base_url, raw_url, resolved, sizeof(resolved));
    if (resolved[0] == '\0')
        return;
    for (i = 0U; i < page->media_count; ++i) {
        if (strcmp(page->media[i].url, resolved) == 0)
            return;
    }
    {
        WebEngineMedia *media = &page->media[page->media_count++];
        (void)snprintf(media->url, sizeof(media->url), "%s", resolved);
        (void)snprintf(media->kind, sizeof(media->kind), "%s",
                       kind != NULL && kind[0] != '\0' ? kind : "media");
        (void)snprintf(media->mime_type, sizeof(media->mime_type), "%s",
                       mime_type != NULL && mime_type[0] != '\0' ? mime_type : "unknown/type");
    }
}

static int is_manifest_url_or_type(const char *url, const char *mime_type)
{
    return (url != NULL && (url_has_suffix(url, ".m3u8") || url_has_suffix(url, ".mpd"))) ||
           (mime_type != NULL && (contains_nocase(mime_type, "mpegurl") || contains_nocase(mime_type, "dash+xml")));
}

static void add_video_link(WebEnginePage *page, const char *base_url,
                           const char *raw_url, const char *label, const char *mime_type)
{
    char resolved[WEB_ENGINE_LINK_URL_CAP];
    size_t i;
    if (raw_url == NULL || raw_url[0] == '\0' || page->link_count >= WEB_ENGINE_LINK_COUNT ||
        is_manifest_url_or_type(raw_url, mime_type)) return;
    resolve_link_url(base_url, raw_url, resolved, sizeof(resolved));
    if (resolved[0] == '\0' || is_manifest_url_or_type(resolved, mime_type)) return;
    for (i = 0U; i < page->link_count; ++i)
        if (strcmp(page->links[i].url, resolved) == 0) return;
    (void)snprintf(page->links[page->link_count].url, sizeof(page->links[page->link_count].url), "%s", resolved);
    (void)snprintf(page->links[page->link_count].label, sizeof(page->links[page->link_count].label), "VIDEO: %.100s", label != NULL && label[0] != '\0' ? label : resolved);
    page->links[page->link_count].is_video = 1;
    ++page->link_count;
}

static const char *guess_media_kind(const char *url, const char *mime_type)
{
    if (mime_type != NULL) {
        if (starts_nocase(mime_type, "video/")) return "video";
        if (starts_nocase(mime_type, "audio/")) return "audio";
        if (starts_nocase(mime_type, "image/")) return "image";
    }
    if (url != NULL && (url_has_suffix(url, ".mp4") || url_has_suffix(url, ".m4v") ||
        url_has_suffix(url, ".webm") || url_has_suffix(url, ".ogv") ||
        url_has_suffix(url, ".mov") || url_has_suffix(url, ".m3u8") ||
        url_has_suffix(url, ".mpd"))) return "video";
    if (url != NULL && (url_has_suffix(url, ".mp3") || url_has_suffix(url, ".m4a") ||
        url_has_suffix(url, ".aac") || url_has_suffix(url, ".ogg") ||
        url_has_suffix(url, ".wav") || url_has_suffix(url, ".flac"))) return "audio";
    if (url != NULL && (url_has_suffix(url, ".png") || url_has_suffix(url, ".jpg") ||
        url_has_suffix(url, ".jpeg") || url_has_suffix(url, ".gif") ||
        url_has_suffix(url, ".webp") || url_has_suffix(url, ".bmp") ||
        url_has_suffix(url, ".svg") || url_has_suffix(url, ".avif"))) return "image";
    return NULL;
}

static void extract_srcset(WebEnginePage *page, const char *base_url,
                           const char *srcset, const char *label)
{
    const char *cursor = srcset;
    if (cursor == NULL)
        return;
    while (*cursor != '\0' && page->image_count < WEB_ENGINE_IMAGE_COUNT) {
        const char *candidate_start;
        const char *candidate_end;
        char candidate[HTML_ATTR_CAP];
        size_t length;
        while (*cursor == ',' || isspace((unsigned char)*cursor))
            ++cursor;
        if (*cursor == '\0')
            break;
        candidate_start = cursor;
        while (*cursor != '\0' && *cursor != ',' && !isspace((unsigned char)*cursor))
            ++cursor;
        candidate_end = cursor;
        length = (size_t)(candidate_end - candidate_start);
        if (length == 0U)
            continue;
        if (length >= sizeof(candidate))
            length = sizeof(candidate) - 1U;
        memcpy(candidate, candidate_start, length);
        candidate[length] = '\0';
        if (!starts_nocase(candidate, "data:"))
            add_page_image(page, base_url, candidate, label, 0U, 0U);
        while (*cursor != '\0' && *cursor != ',')
            ++cursor;
        if (*cursor == ',')
            ++cursor;
    }
}

static void extract_css_urls(WebEnginePage *page, const char *base_url, const char *css)
{
    const char *cursor = css;
    while (cursor != NULL && *cursor != '\0' && page->image_count < WEB_ENGINE_IMAGE_COUNT) {
        const char *start = find_nocase(cursor, "url(");
        const char *end;
        char raw[HTML_ATTR_CAP];
        const char *kind;
        size_t length;
        if (start == NULL)
            break;
        start += 4;
        while (*start != '\0' && isspace((unsigned char)*start))
            ++start;
        if (*start == '\'' || *start == '"') {
            char quote = *start++;
            end = strchr(start, quote);
            if (end == NULL)
                break;
        } else {
            end = strchr(start, ')');
            if (end == NULL)
                break;
            while (end > start && isspace((unsigned char)end[-1]))
                --end;
        }
        length = (size_t)(end - start);
        if (length == 0U) {
            cursor = end + 1;
            continue;
        }
        if (length >= sizeof(raw))
            length = sizeof(raw) - 1U;
        memcpy(raw, start, length);
        raw[length] = '\0';
        kind = guess_media_kind(raw, NULL);
        if (kind != NULL && strcmp(kind, "image") == 0 && !starts_nocase(raw, "data:"))
            add_page_image(page, base_url, raw, "CSS background image", 0U, 0U);
        cursor = end;
        while (*cursor != '\0' && *cursor != ')')
            ++cursor;
        if (*cursor == ')')
            ++cursor;
    }
}

static void append_image_alt(WebEnginePage *page, const char *alt, int active_link)
{
    static const char prefix[] = "[Image: ";
    static const char suffix[] = "]";
    size_t length;
    if (alt == NULL || alt[0] == '\0')
        return;
    append_decoded_text(page, prefix, sizeof(prefix) - 1U, 0, active_link);
    append_decoded_text(page, alt, strlen(alt), 0, active_link);
    append_decoded_text(page, suffix, sizeof(suffix) - 1U, 0, active_link);
    length = page->text_length;
    append_normalized(page->text, sizeof(page->text), &length, ' ', 0);
    page->text_length = length;
}

static void parse_html(const char *html, size_t html_length, const char *base_url,
                       WebEnginePage *page)
{
    size_t i = 0U;
    int in_title = 0;
    int active_link = -1;
    int in_video = 0;
    int in_audio = 0;

    while (i < html_length && page->text_length < sizeof(page->text) - 8U) {
        if (html[i] != '<') {
            size_t start = i;
            while (i < html_length && html[i] != '<') ++i;
            append_decoded_text(page, html + start, i - start, in_title, active_link);
            continue;
        }
        if (i + 3U < html_length && memcmp(html + i, "<!--", 4U) == 0) {
            const char *end_comment = strstr(html + i + 4U, "-->");
            if (end_comment == NULL) break;
            i = (size_t)(end_comment - html) + 3U;
            continue;
        }
        {
            size_t tag_start = i + 1U;
            size_t tag_end = tag_start;
            size_t name_start;
            size_t name_end;
            size_t name_length;
            int closing = 0;
            char name[32];
            char href[HTML_ATTR_CAP];
            char *tag_copy;
            size_t tag_length;
            while (tag_end < html_length && html[tag_end] != '>' && tag_end - tag_start < 2048U)
                ++tag_end;
            if (tag_end >= html_length || html[tag_end] != '>') {
                ++i;
                continue;
            }
            tag_length = tag_end - tag_start;
            tag_copy = (char *)malloc(tag_length + 1U);
            if (tag_copy == NULL) break;
            memcpy(tag_copy, html + tag_start, tag_length);
            tag_copy[tag_length] = '\0';
            name_start = 0U;
            while (name_start < tag_length && isspace((unsigned char)tag_copy[name_start])) ++name_start;
            if (name_start < tag_length && tag_copy[name_start] == '/') {
                closing = 1;
                ++name_start;
            }
            while (name_start < tag_length && (tag_copy[name_start] == '!' || tag_copy[name_start] == '?'))
                ++name_start;
            name_end = name_start;
            while (name_end < tag_length && (isalnum((unsigned char)tag_copy[name_end]) ||
                   tag_copy[name_end] == '-')) ++name_end;
            name_length = name_end - name_start;
            if (name_length >= sizeof(name)) name_length = sizeof(name) - 1U;
            memcpy(name, tag_copy + name_start, name_length);
            name[name_length] = '\0';
            {
                size_t n;
                for (n = 0U; name[n] != '\0'; ++n) name[n] = (char)tolower((unsigned char)name[n]);
            }

            if (!closing) {
                char inline_style[HTML_ATTR_CAP];
                if (copy_attribute(tag_copy, tag_length, "style", inline_style, sizeof(inline_style)))
                    extract_css_urls(page, base_url, inline_style);
            }
            if (!closing && (strcmp(name, "script") == 0 || strcmp(name, "style") == 0)) {
                char close_tag[40];
                const char *close_position;
                if (strcmp(name, "script") == 0) {
                    char script_src[HTML_ATTR_CAP];
                    ++page->script_count;
                    (void)copy_attribute(tag_copy, tag_length, "src", script_src, sizeof(script_src));
                    if (script_src[0] != '\0')
                        add_page_media(page, base_url, script_src, "script", "application/javascript");
                }
                (void)snprintf(close_tag, sizeof(close_tag), "</%s", name);
                close_position = find_nocase(html + tag_end + 1U, close_tag);
                if (close_position != NULL && strcmp(name, "style") == 0) {
                    size_t css_length = (size_t)(close_position - (html + tag_end + 1U));
                    char *css_text = (char *)malloc(css_length + 1U);
                    if (css_text != NULL) {
                        memcpy(css_text, html + tag_end + 1U, css_length);
                        css_text[css_length] = '\0';
                        extract_css_urls(page, base_url, css_text);
                        free(css_text);
                    }
                }
                free(tag_copy);
                if (close_position == NULL) break;
                i = (size_t)(close_position - html);
                continue;
            }
            if (strcmp(name, "video") == 0) {
                if (closing) {
                    in_video = 0;
                } else {
                    char src[HTML_ATTR_CAP];
                    char type[WEB_ENGINE_RESOURCE_TYPE_CAP];
                    char poster[HTML_ATTR_CAP];
                    in_video = 1;
                    (void)copy_attribute(tag_copy, tag_length, "src", src, sizeof(src));
                    (void)copy_attribute(tag_copy, tag_length, "type", type, sizeof(type));
                    (void)copy_attribute(tag_copy, tag_length, "poster", poster, sizeof(poster));
                    if (src[0] != '\0') {
                        add_page_media(page, base_url, src, "video", type);
                        add_video_link(page, base_url, src, "HTML video source", type);
                    }
                    if (poster[0] != '\0')
                        add_page_image(page, base_url, poster, "Video poster", 0U, 0U);
                }
            } else if (strcmp(name, "audio") == 0) {
                if (closing) {
                    in_audio = 0;
                } else {
                    char src[HTML_ATTR_CAP];
                    char type[WEB_ENGINE_RESOURCE_TYPE_CAP];
                    in_audio = 1;
                    (void)copy_attribute(tag_copy, tag_length, "src", src, sizeof(src));
                    (void)copy_attribute(tag_copy, tag_length, "type", type, sizeof(type));
                    if (src[0] != '\0')
                        add_page_media(page, base_url, src, "audio", type);
                }
            } else if (!closing && strcmp(name, "img") == 0) {
                char src[HTML_ATTR_CAP];
                char alt[WEB_ENGINE_RESOURCE_LABEL_CAP];
                char width[32];
                char height[32];
                (void)copy_attribute(tag_copy, tag_length, "src", src, sizeof(src));
                char srcset[HTML_ATTR_CAP];
                if (src[0] == '\0')
                    (void)copy_attribute(tag_copy, tag_length, "data-src", src, sizeof(src));
                if (src[0] == '\0')
                    (void)copy_attribute(tag_copy, tag_length, "data-original", src, sizeof(src));
                (void)copy_attribute(tag_copy, tag_length, "alt", alt, sizeof(alt));
                (void)copy_attribute(tag_copy, tag_length, "width", width, sizeof(width));
                (void)copy_attribute(tag_copy, tag_length, "height", height, sizeof(height));
                (void)copy_attribute(tag_copy, tag_length, "srcset", srcset, sizeof(srcset));
                if (src[0] == '\0' && srcset[0] != '\0') {
                    /* A responsive image may only specify srcset; keep the first viable candidate. */
                    const char *end = srcset;
                    size_t n;
                    while (*end != '\0' && *end != ',' && !isspace((unsigned char)*end)) ++end;
                    n = (size_t)(end - srcset);
                    if (n >= sizeof(src)) n = sizeof(src) - 1U;
                    memcpy(src, srcset, n);
                    src[n] = '\0';
                }
                add_page_image(page, base_url, src, alt, parse_dimension(width), parse_dimension(height));
                extract_srcset(page, base_url, srcset, alt[0] != '\0' ? alt : "Responsive image candidate");
                {
                    char data_srcset[HTML_ATTR_CAP];
                    (void)copy_attribute(tag_copy, tag_length, "data-srcset", data_srcset, sizeof(data_srcset));
                    extract_srcset(page, base_url, data_srcset, alt[0] != '\0' ? alt : "Lazy image candidate");
                }
                append_image_alt(page, alt, active_link);
            } else if (!closing && strcmp(name, "source") == 0) {
                char src[HTML_ATTR_CAP];
                char type[WEB_ENGINE_RESOURCE_TYPE_CAP];
                const char *kind;
                char srcset[HTML_ATTR_CAP];
                (void)copy_attribute(tag_copy, tag_length, "src", src, sizeof(src));
                (void)copy_attribute(tag_copy, tag_length, "srcset", srcset, sizeof(srcset));
                (void)copy_attribute(tag_copy, tag_length, "type", type, sizeof(type));
                kind = guess_media_kind(src, type);
                extract_srcset(page, base_url, srcset, "Responsive picture source");
                if (in_video || (kind != NULL && strcmp(kind, "video") == 0)) {
                    add_page_media(page, base_url, src, "video", type);
                    add_video_link(page, base_url, src, "HTML video source", type);
                }
                else if (in_audio || (kind != NULL && strcmp(kind, "audio") == 0))
                    add_page_media(page, base_url, src, "audio", type);
                else if (kind != NULL && strcmp(kind, "image") == 0)
                    add_page_image(page, base_url, src, "Responsive image source", 0U, 0U);
            } else if (!closing && strcmp(name, "iframe") == 0) {
                char src[HTML_ATTR_CAP];
                (void)copy_attribute(tag_copy, tag_length, "src", src, sizeof(src));
                if (src[0] != '\0') {
                    ++page->iframe_count;
                    add_page_media(page, base_url, src, "embed", "text/html");
                }
            } else if (!closing && strcmp(name, "form") == 0) {
                ++page->form_count;
            } else if (!closing && (strcmp(name, "h1") == 0 || strcmp(name, "h2") == 0 ||
                                   strcmp(name, "h3") == 0 || strcmp(name, "h4") == 0 ||
                                   strcmp(name, "h5") == 0 || strcmp(name, "h6") == 0)) {
                ++page->heading_count;
            } else if (!closing && strcmp(name, "link") == 0) {
                char rel[64];
                char link_href[HTML_ATTR_CAP];
                char mime[WEB_ENGINE_RESOURCE_TYPE_CAP];
                (void)copy_attribute(tag_copy, tag_length, "rel", rel, sizeof(rel));
                (void)copy_attribute(tag_copy, tag_length, "href", link_href, sizeof(link_href));
                (void)copy_attribute(tag_copy, tag_length, "type", mime, sizeof(mime));
                if (contains_nocase(rel, "stylesheet")) {
                    ++page->stylesheet_count;
                    add_page_media(page, base_url, link_href, "stylesheet",
                                   mime[0] != '\0' ? mime : "text/css");
                }
                if (contains_nocase(rel, "icon") || contains_nocase(rel, "apple-touch-icon"))
                    add_page_image(page, base_url, link_href, "Site icon", 0U, 0U);
            } else if (!closing && strcmp(name, "meta") == 0) {
                char meta_name[64];
                char property[64];
                char content[HTML_ATTR_CAP];
                (void)copy_attribute(tag_copy, tag_length, "name", meta_name, sizeof(meta_name));
                (void)copy_attribute(tag_copy, tag_length, "property", property, sizeof(property));
                (void)copy_attribute(tag_copy, tag_length, "content", content, sizeof(content));
                if (starts_nocase(meta_name, "description") && page->description[0] == '\0')
                    (void)snprintf(page->description, sizeof(page->description), "%.255s", content);
                if (starts_nocase(property, "og:image") || starts_nocase(meta_name, "twitter:image"))
                    add_page_image(page, base_url, content, "Social preview image", 0U, 0U);
                if (starts_nocase(property, "og:video") || starts_nocase(meta_name, "twitter:player"))
                    add_page_media(page, base_url, content, "video", "unknown/video");
            }
            if (strcmp(name, "title") == 0) {
                in_title = closing ? 0 : 1;
            } else if (strcmp(name, "a") == 0) {
                if (closing) {
                    active_link = -1;
                } else if (page->link_count < WEB_ENGINE_LINK_COUNT &&
                           copy_attribute(tag_copy, tag_length, "href", href, sizeof(href))) {
                    WebEngineLink *link = &page->links[page->link_count];
                    resolve_link_url(base_url, href, link->url, sizeof(link->url));
                    if (link->url[0] != '\0') {
                        link->label[0] = '\0';
                        link->is_video = 0;
                        active_link = (int)page->link_count;
                        ++page->link_count;
                    }
                }
            }
            if (is_block_tag(name)) append_line_break(page);
            free(tag_copy);
            i = tag_end + 1U;
        }
    }

    while (page->text_length > 0U &&
           (page->text[page->text_length - 1U] == ' ' || page->text[page->text_length - 1U] == '\n')) {
        page->text[--page->text_length] = '\0';
    }
    if (page->title[0] == '\0')
        (void)snprintf(page->title, sizeof(page->title), "Web page");
    {
        size_t j;
        for (j = 0U; j < page->link_count; ++j) {
            if (page->links[j].label[0] == '\0')
                (void)snprintf(page->links[j].label, sizeof(page->links[j].label), "Link %u", (unsigned)(j + 1U));
        }
    }
}

int web_engine_native_init(void)
{
    return curl_global_init(CURL_GLOBAL_DEFAULT) == CURLE_OK ? 1 : 0;
}

void web_engine_native_shutdown(void)
{
    curl_global_cleanup();
}

int web_engine_native_fetch(const char *url, WebEnginePage *page, char *error, size_t error_capacity)
{
    CURL *curl;
    CURLcode result;
    HtmlBuffer html;
    long response_code = 0L;
    char curl_error[CURL_ERROR_SIZE];
    char *effective_url = NULL;
    char *response_content_type = NULL;

    if (page == NULL || url == NULL || url[0] == '\0') {
        set_error(error, error_capacity, "No URL provided");
        return 0;
    }
    memset(page, 0, sizeof(*page));
    memset(&html, 0, sizeof(html));
    memset(curl_error, 0, sizeof(curl_error));

    curl = curl_easy_init();
    if (curl == NULL) {
        set_error(error, error_capacity, "libcurl could not initialize");
        return 0;
    }

    (void)curl_easy_setopt(curl, CURLOPT_URL, url);
    (void)curl_easy_setopt(curl, CURLOPT_USERAGENT, "Mozilla/5.0 (Xbox 360; X360Browser/0.7.0) AppleWebKit/537.36 Safari/537.36");
    (void)curl_easy_setopt(curl, CURLOPT_COOKIEFILE, "X360Browser-cookies.txt");
    (void)curl_easy_setopt(curl, CURLOPT_COOKIEJAR, "X360Browser-cookies.txt");
    (void)curl_easy_setopt(curl, CURLOPT_NOSIGNAL, 1L);
    (void)curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, receive_html);
    (void)curl_easy_setopt(curl, CURLOPT_WRITEDATA, &html);
    (void)curl_easy_setopt(curl, CURLOPT_HEADERFUNCTION, receive_header);
    (void)curl_easy_setopt(curl, CURLOPT_HEADERDATA, &html);
    (void)curl_easy_setopt(curl, CURLOPT_ERRORBUFFER, curl_error);
    (void)curl_easy_setopt(curl, CURLOPT_BUFFERSIZE, 16384L);
    (void)curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1L);
    (void)curl_easy_setopt(curl, CURLOPT_MAXREDIRS, 8L);
    (void)curl_easy_setopt(curl, CURLOPT_CONNECTTIMEOUT, 15L);
    (void)curl_easy_setopt(curl, CURLOPT_TIMEOUT, 25L);
    (void)curl_easy_setopt(curl, CURLOPT_LOW_SPEED_LIMIT, 1L);
    (void)curl_easy_setopt(curl, CURLOPT_LOW_SPEED_TIME, 10L);
    (void)curl_easy_setopt(curl, CURLOPT_ACCEPT_ENCODING, "identity");
    (void)curl_easy_setopt(curl, CURLOPT_CAINFO, "cacert.pem");
    (void)curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 1L);
    (void)curl_easy_setopt(curl, CURLOPT_SSL_VERIFYHOST, 2L);
    (void)curl_easy_setopt(curl, CURLOPT_PROTOCOLS_STR, "http,https");
    (void)curl_easy_setopt(curl, CURLOPT_REDIR_PROTOCOLS_STR, "http,https");

    result = curl_easy_perform(curl);
    (void)curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &response_code);
    (void)curl_easy_getinfo(curl, CURLINFO_EFFECTIVE_URL, &effective_url);
    (void)curl_easy_getinfo(curl, CURLINFO_CONTENT_TYPE, &response_content_type);
    page->http_status = response_code;
    page->html_bytes = html.length;
    if (response_content_type != NULL)
        (void)snprintf(page->content_type, sizeof(page->content_type), "%s", response_content_type);
    else if (html.content_type[0] != '\0')
        (void)snprintf(page->content_type, sizeof(page->content_type), "%s", html.content_type);

    if (result != CURLE_OK && (html.direct_resource ||
        (response_content_type != NULL &&
         !starts_nocase(response_content_type, "text/html") &&
         !starts_nocase(response_content_type, "application/xhtml+xml") &&
         !starts_nocase(response_content_type, "text/plain")))) {
        const char *mime = response_content_type != NULL ? response_content_type : html.content_type;
        const char *kind = guess_media_kind(effective_url != NULL ? effective_url : url, mime);
        page->is_direct_resource = 1;
        (void)snprintf(page->title, sizeof(page->title), "%s",
                       kind != NULL && strcmp(kind, "video") == 0 ? "Video resource" :
                       kind != NULL && strcmp(kind, "audio") == 0 ? "Audio resource" :
                       kind != NULL && strcmp(kind, "image") == 0 ? "Image resource" :
                       "Direct web resource");
        (void)snprintf(page->text, sizeof(page->text),
                       "Resource detected: %s\n\nNativePlus stopped the body download after identifying a non-HTML content type, saving memory and bandwidth.\n\nThis build does not yet include a full image decoder or audio/video playback pipeline.\n\nHTTP status: %ld",
                       mime != NULL ? mime : "unknown/type", response_code);
        page->text_length = strlen(page->text);
        curl_easy_cleanup(curl);
        free(html.data);
        if (error != NULL && error_capacity > 0U) error[0] = '\0';
        return 1;
    }

    if (result != CURLE_OK) {
        if (html.too_large)
            set_error(error, error_capacity, "Page exceeded the 512 KiB HTML download limit");
        else if (curl_error[0] != '\0')
            set_error(error, error_capacity, curl_error);
        else
            set_error(error, error_capacity, curl_easy_strerror(result));
        curl_easy_cleanup(curl);
        free(html.data);
        return 0;
    }
    if (response_content_type != NULL &&
        !starts_nocase(response_content_type, "text/html") &&
        !starts_nocase(response_content_type, "application/xhtml+xml") &&
        !starts_nocase(response_content_type, "text/plain")) {
        const char *kind = guess_media_kind(effective_url != NULL ? effective_url : url,
                                            response_content_type);
        page->is_direct_resource = 1;
        (void)snprintf(page->title, sizeof(page->title), "%s",
                       kind != NULL && strcmp(kind, "video") == 0 ? "Video resource" :
                       kind != NULL && strcmp(kind, "audio") == 0 ? "Audio resource" :
                       kind != NULL && strcmp(kind, "image") == 0 ? "Image resource" :
                       "Direct web resource");
        (void)snprintf(page->text, sizeof(page->text),
                       "Resource detected: %s\n\nNativePlus correctly identified the response type, but this build does not yet include a full image decoder or audio/video playback pipeline.\n\nThe resource was not interpreted as HTML.\n\nHTTP status: %ld\nDownloaded bytes: %lu",
                       response_content_type, response_code, (unsigned long)html.length);
        page->text_length = strlen(page->text);
        curl_easy_cleanup(curl);
        free(html.data);
        if (error != NULL && error_capacity > 0U) error[0] = '\0';
        return 1;
    }
    if (html.data == NULL || html.length == 0U) {
        set_error(error, error_capacity, "The server returned an empty page");
        curl_easy_cleanup(curl);
        free(html.data);
        return 0;
    }

    if (starts_nocase(response_content_type != NULL ? response_content_type : "", "text/plain")) {
        size_t copy_length = html.length < sizeof(page->text) - 1U ? html.length : sizeof(page->text) - 1U;
        memcpy(page->text, html.data, copy_length);
        page->text[copy_length] = '\0';
        page->text_length = copy_length;
        (void)snprintf(page->title, sizeof(page->title), "Plain text");
    } else {
        parse_html(html.data, html.length, effective_url != NULL ? effective_url : url, page);
    }
    if (page->text_length == 0U)
        (void)snprintf(page->text, sizeof(page->text), "The page loaded, but this basic renderer found no visible text.\nHTML: %lu bytes.",
                       (unsigned long)html.length);
    curl_easy_cleanup(curl);
    free(html.data);

    if (response_code >= 400L) {
        if (error != NULL && error_capacity > 0U)
            (void)snprintf(error, error_capacity, "HTTP %ld", response_code);
    } else if (error != NULL && error_capacity > 0U) {
        error[0] = '\0';
    }
    return 1;
}

int web_engine_download_video(const char *url, const char *destination, char *error, size_t error_capacity)
{
    CURL *curl;
    CURLcode result;
    FILE *file;
    VideoFileSink sink;
    long response_code = 0L;
    char curl_error[CURL_ERROR_SIZE] = { 0 };
    char *content_type = NULL;
    int close_result;
    int is_html;
    int is_manifest;
    int is_allowed_media_type;

    if (url == NULL || destination == NULL || url[0] == '\0' || destination[0] == '\0') {
        set_error(error, error_capacity, "No video URL or destination provided");
        return 0;
    }
    file = fopen(destination, "wb");
    if (file == NULL) {
        set_error(error, error_capacity, "Cannot create the video file on console storage");
        return 0;
    }
    memset(&sink, 0, sizeof(sink));
    sink.file = file;
    curl = curl_easy_init();
    if (curl == NULL) {
        (void)fclose(file);
        (void)remove(destination);
        set_error(error, error_capacity, "libcurl could not initialize the video transfer");
        return 0;
    }
    (void)curl_easy_setopt(curl, CURLOPT_URL, url);
    (void)curl_easy_setopt(curl, CURLOPT_USERAGENT, "X360Browser/0.7.0 Xbox 360 homebrew");
    (void)curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, receive_video_file);
    (void)curl_easy_setopt(curl, CURLOPT_WRITEDATA, &sink);
    (void)curl_easy_setopt(curl, CURLOPT_ERRORBUFFER, curl_error);
    (void)curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1L);
    (void)curl_easy_setopt(curl, CURLOPT_MAXREDIRS, 8L);
    (void)curl_easy_setopt(curl, CURLOPT_CONNECTTIMEOUT, 15L);
    (void)curl_easy_setopt(curl, CURLOPT_TIMEOUT, 180L);
    (void)curl_easy_setopt(curl, CURLOPT_LOW_SPEED_LIMIT, 1L);
    (void)curl_easy_setopt(curl, CURLOPT_LOW_SPEED_TIME, 20L);
    (void)curl_easy_setopt(curl, CURLOPT_ACCEPT_ENCODING, "identity");
    (void)curl_easy_setopt(curl, CURLOPT_COOKIEFILE, "X360Browser-cookies.txt");
    (void)curl_easy_setopt(curl, CURLOPT_COOKIEJAR, "X360Browser-cookies.txt");
    (void)curl_easy_setopt(curl, CURLOPT_CAINFO, "cacert.pem");
    (void)curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 1L);
    (void)curl_easy_setopt(curl, CURLOPT_SSL_VERIFYHOST, 2L);
    (void)curl_easy_setopt(curl, CURLOPT_PROTOCOLS_STR, "http,https");
    (void)curl_easy_setopt(curl, CURLOPT_REDIR_PROTOCOLS_STR, "http,https");

    result = curl_easy_perform(curl);
    (void)curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &response_code);
    (void)curl_easy_getinfo(curl, CURLINFO_CONTENT_TYPE, &content_type);
    is_html = content_type != NULL &&
        (starts_nocase(content_type, "text/") || starts_nocase(content_type, "application/xhtml+xml"));
    is_manifest = is_manifest_url_or_type(url, content_type) != 0;
    is_allowed_media_type = content_type == NULL ||
        starts_nocase(content_type, "video/") ||
        starts_nocase(content_type, "application/octet-stream") ||
        starts_nocase(content_type, "application/mp4") ||
        starts_nocase(content_type, "application/x-matroska");
    curl_easy_cleanup(curl);
    close_result = fclose(file);

    if (result != CURLE_OK || response_code < 200L || response_code >= 300L || close_result != 0 || is_html || is_manifest || !is_allowed_media_type) {
        if (sink.too_large)
            set_error(error, error_capacity, "Video exceeds the 512 MiB download limit");
        else if (is_manifest)
            set_error(error, error_capacity, "HLS/DASH streams are not direct video files in this version");
        else if (is_html)
            set_error(error, error_capacity, "The URL returned a text/HTML page, not a direct video file");
        else if (!is_allowed_media_type)
            set_error(error, error_capacity, "The content type is not a recognized direct video format");
        else if (response_code < 200L || response_code >= 300L) {
            if (error != NULL && error_capacity > 0U)
                (void)snprintf(error, error_capacity, "Video server returned HTTP %ld", response_code);
        } else if (curl_error[0] != '\0')
            set_error(error, error_capacity, curl_error);
        else if (result != CURLE_OK)
            set_error(error, error_capacity, curl_easy_strerror(result));
        else
            set_error(error, error_capacity, "Could not finish writing the video file");
        (void)remove(destination);
        return 0;
    }
    if (sink.bytes == 0U) {
        (void)remove(destination);
        set_error(error, error_capacity, "Video server returned an empty file");
        return 0;
    }
    if (error != NULL && error_capacity > 0U) error[0] = '\0';
    return 1;
}

